import 'dart:async';
import 'package:vyaparlive/model/product_model/BatchPriceDAO.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:flutter/material.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Product/EditMyProduct.dart';
import 'package:vyaparlive/Product/TransitDesign.dart';
import 'package:vyaparlive/Product/inventory_view/InventoryLocationBatchView.dart';
import 'package:vyaparlive/Product/raw_inventory_view/RawInventoryExpandedPage.dart';
import 'package:vyaparlive/Product/suppliers_view/SupplierExpandedPage.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/components/privileges/product_privileges.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/InventoryManagmentModel.dart';
import 'package:vyaparlive/model/OffersModel.dart';
import 'package:vyaparlive/model/PriceModel.dart';
import 'package:vyaparlive/model/ProductAttributeModel.dart';
import 'package:vyaparlive/model/product_model/InventoryDetailsDAO.dart';
import 'package:vyaparlive/model/product_model/ProductModel.dart';
import 'package:vyaparlive/model/RawInventory.dart';
import 'package:vyaparlive/model/SupplierModel.dart';
import 'package:vyaparlive/model/product_model/QuantityAdjustmentDAO.dart';
import 'package:vyaparlive/model/product_model/TransitDetailsDAO.dart';
import 'package:vyaparlive/service/bu_list_grpc_service.dart';
import 'package:vyaparlive/service/product_services.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';

class BasicProductDetails extends StatefulWidget {
  final String? productId;
  final bool isShowBasicDetails;
  final String? currentBuId;
  final bool isFromRawProductsPage;

  BasicProductDetails(
      {this.productId,
      this.isShowBasicDetails = false,
      this.currentBuId,
      this.isFromRawProductsPage = false});
  @override
  _BasicProductDetailsState createState() => _BasicProductDetailsState();
}

class _BasicProductDetailsState extends State<BasicProductDetails>
    with SingleTickerProviderStateMixin {
  final format = DateFormat("yyyy-MM-dd");
  DateTime fromdate1 = DateTime.now();
  DateTime todate2 = DateTime.now();

  DateFormat formatter = DateFormat("yyyy-MM-dd");
  String formatttedOfferStartDate = "";
  String formattedOfferEndDate = "";
  String formattedManufactureDate = "";
  String formattedExpireDate = "";
  String formattedReleaseDate = "";
  List<ProductAttributeModel> attributesList = [];
  List<OffersModel> _offersList = [];
  List<SupplierModel> _suppliersList = [];
  List<InventoryManagementModel> _inventoryList = [];
  late AnimationController _animationController;
  late Animation _animation;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  List<BuProductModal> _productDataList = [];
  String? buId = "";
  bool isLoading = false;
  ProductPrivileges? _productPrivileges =
      AppController.instance.getProductPrivileges;
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  late ProductService _productService;
  List<PriceModel> _priceList = [];
  num totalBatchQuantity = 0;
  List<RawInventory> rawInventoryList = [];
  String? orgCurrencySymbol = "";
  List<QuantityAdjustmentDAO> adjustQuanityList = [];
  late BuListGrpcService _transactionService;
  List<TransitDetailsDAO> _transitList = [];
  List<QuantityAdjustmentDAO> responseAdjustmentList = [];
  List tempListItems = [
    {"name": Constants.PRODUCT_DETAILS_STR, "isChecked": true},
    {"name": Constants.PRICE_DETAILS, "isChecked": false},
    {"name": Constants.TAX_DETAILS, "isChecked": false},
    {"name": Constants.ITEM_DETAILS, "isChecked": false},
    // {"name": Constants.CATEGORIES_C, "isChecked": false},
    // {"name": Constants.FEATURES, "isChecked": false},
    {"name": Constants.MANUFACTURER_DETAILS, "isChecked": false},

    {"name": Constants.AVAILABLE_LOCATIONS, "isChecked": false},
    {"name": Constants.OFFERS_C, "isChecked": false},
    {"name": Constants.QUANTITY_ADJUSTMENT_C, "isChecked": false},
    {"name": Constants.TRANSIT_DETAILS_C, "isChecked": false},
  ];
  ScrollController _scrollController = ScrollController();

  String? selectedText = Constants.PRODUCT_DETAILS_STR;
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    _animationController =
        AnimationController(vsync: this, duration: Duration(seconds: 2));
    _animation = Tween(begin: 50.0, end: 200.0).animate(_animationController)
      ..addStatusListener((state) {
        if (state == AnimationStatus.completed) {
        } else if (state == AnimationStatus.dismissed) {}
      })
      ..addListener(() {
        setState(() {});
      });
    theme = AppTheme.vyaparTheme;
    _animationController.forward();
    _productService = ProductService();
    _transactionService = BuListGrpcService();
    buId = widget.currentBuId;

    loadProductData();
    // orgCurrencySymbol = AppController.instance.getBuCurrencySymbol;

    String? symbol = AppController.instance.getBuCurrencySymbol;
    orgCurrencySymbol = (symbol != null && symbol.isNotEmpty && symbol != "-")
        ? symbol
        : "\u20B9";
  }

  loadProductData() async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
      });

      this.getProuctById().then((value) {
        _productDataList.addAll(value);
        if (_productDataList.length > 0) {
          this.bindProductData(_productDataList[0]);
        }
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<BuProductModal>> getProuctById() async {
    _productDataList.clear();
    _priceList.clear();
    _offersList.clear();
    _suppliersList.clear();
    rawInventoryList.clear();
    _inventoryList.clear();
    adjustQuanityList.clear();
    totalBatchQuantity = 0;
    String body = json.encode({"id": widget.productId, "buId": buId});

    var response = await _productService
        .getProductDetailsByProductId_grpc(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          "$onError",
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<BuProductModal> data = [];

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      data.add(BuProductModal.fromJson(resObj[0]));
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    return data;
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
      body: Stack(
        children: [
          SafeArea(
            child: Scaffold(
              key: _scaffoldkey,
              backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
              appBar: AppBar(
                  centerTitle: true,
                  elevation: 0,
                  iconTheme: IconThemeData(color: theme.colorScheme.primary),
                  title: AppbarName(
                      title: Language().getString(
                          (widget.isFromRawProductsPage)
                              ? Constants.RAW_MATERIAL_DETAILS
                              : Constants.PRODUCT_DETAILS,
                          selectedLang),
                      buName: AppController.instance.getBuName),
                  actions: <Widget>[
                    // this.showEditButton(),
                    // AppUtills.homeButton(context),
                  ],
                  backgroundColor: Colors.transparent //(Constants.APP_COLOR),
                  ),
              body: (_productDataList.length == 0)
                  ? Container(
                      child: Center(
                        child: Text(Language()
                            .getString(Constants.NO_DATA_FOUND, selectedLang)),
                      ),
                    )
                  : Container(
                      // padding: EdgeInsets.zero,
                      child: this.scrollViewProductData(),
                    ),
            ),
          ),
          AppUtills.showLoadingView(
              context: context,
              message: Language().getString(progressMessage, selectedLang),
              isLoading: isLoadingProgress),
        ],
      ),
    );
  }

  Widget createPriceDetailsDynamic() {
    return Column(children: <Widget>[
      for (int i = 0; i < _priceList.length; i++) this.showPriceExpandView(null)
    ]);
  }

  Widget showPriceExpandView(BatchPriceDAO? priceData) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(5),
          side:
              BorderSide(color: theme.colorScheme.primaryContainer, width: 1)),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            // productDetilsNewDesign(Constants.BATCH_NO, priceData?.batchNumber),
            productDetilsNewDesign(Constants.PRICE, "${priceData?.price}"),
            // productDetilsNewDesign(Constants.QUANTITY,
            //     "${priceData?.quantity} ${priceData?.quantityIn}"),
            // productDetilsNewDesign(Constants.NET_RATE, "${priceData?.netRate}"),
            productDetilsNewDesign(Constants.MRP, "${priceData?.mrp}"),
            // productDetilsNewDesign(
            //     Constants.MANUFACTURE_DATE, priceData?.manufactureDate),
            // productDetilsNewDesign(
            // Constants.EXPIRE_DATE_STR, priceData?.expiryDate),
          ],
        ),
      ),
    );
  }

  showTransitDetails() {
    return Column(
      children: [
        for (int i = 0; i < _transitList.length; i++)
          TransitCardDesign(
            invoiceNo: _transitList[i].invoiceNumber.toString(),
            quantity: _transitList[i].productQuantity.toString(),
            onPress: () {},
          )
      ],
    );
  }

  mainText(String text) {
    return Container(
        padding: EdgeInsets.all(5.0),
        child: Text(
          Language().getString(text, selectedLang),
          style: TextStyle(
              fontSize: 15.0,
              letterSpacing: 2.0,
              color: theme.colorScheme.primary,
              fontWeight: StyleView.fontSemiBold),
        ));
  }

  productDetilsNewDesign(String text, String? content) {
    return Container(
        margin: EdgeInsets.symmetric(vertical: 5.0),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                child: Text(
                  Language().getString(text, selectedLang),
                  style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 14.0,
                      color: Colors.black),
                ),
              ),
            ),
            Container(child: Text(": ")),
            Expanded(
              child: Container(
                  child: Text(
                "$content",
                style: TextStyle(fontSize: 14.0),
              )),
            )
          ],
        ));
  }

  _createDynamicOfferTable() {
    return Column(children: <Widget>[
      for (int i = 0; i < _offersList.length; i++)
        Card(
          elevation: 3,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                productDetilsNewDesign(
                    Constants.ACTIVE_STRING,
                    _offersList[i].isOfferActive!
                        ? Constants.ACTIVE_STRING
                        : Constants.IN_ACTIVE),
                productDetilsNewDesign(
                    Constants.OFFER_NAME, _offersList[i].offerName),
                productDetilsNewDesign(
                    Constants.OFFER_QTY, "${_offersList[i].offerQuantity}"),
                productDetilsNewDesign(
                    Constants.MIN_ORDER, "${_offersList[i].minOrder}"),
                productDetilsNewDesign(
                    Constants.MAX_ORDER, "${_offersList[i].maxOrder}"),
                productDetilsNewDesign(
                    Constants.START_DATE, "${_offersList[i].startDate}"),
                productDetilsNewDesign(
                    Constants.END_DATE, "${_offersList[i].endDate}"),
                productDetilsNewDesign(
                    Constants.DETAILS, "${_offersList[i].details}"),

                // OfferExpandedPage(
                //   title: Language().getString(Constants.OFFER, selectedLang),
                //   offersModel: null, //_offersList[i],
                //   editPage: () {},
                //   removeItem: () {},
                // ),
              ],
            ),
          ),
        )
    ]);
  }

  _createDynamicInventoryTable() {
    return Column(children: <Widget>[
      for (int i = 0; i < _inventoryList.length; i++)
        if (_inventoryList[i].locationBatchList!.length > 0)
          Column(
            children: <Widget>[
              SizedBox(height: 5.0),
              Container(
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      border: Border.all(color: Colors.grey)),
                  child: ExpansionTile(
                    title: Text(
                      Language().getString(Constants.LOCATION, selectedLang) +
                          " : ${_inventoryList[i].locationName}",
                      style: TextStyle(
                          color: Color(Constants.APP_COLOR),
                          fontFamily: StyleView.FONT_TITLE),
                    ),
                    children: <Widget>[
                      SizedBox(
                        height: 1,
                        child:
                            new Container(color: Color(Constants.GREY_COLOR)),
                      ),
                      InventoryLocationBatchView(
                        isShowLocationDetails: true,
                        locationsList: _inventoryList[i].locationBatchList,
                        strBatchNumber: Language()
                            .getString(Constants.BATCH_NO, selectedLang),
                        strQuantity: Language()
                            .getString(Constants.QUANTITY, selectedLang),
                        strUpdatedBy: Language()
                            .getString(Constants.UPDATED_BY, selectedLang),
                        strUpdatedDate: Language()
                            .getString(Constants.UPDATED_DATE, selectedLang),
                        strAdjustedQuantity: Language().getString(
                            Constants.ADJUSTED_QUANTITY, selectedLang),
                        strReason: Language()
                            .getString(Constants.REASON, selectedLang),
                      )
                    ],
                  ))
            ],
          )
    ]);
  }

  _createDynamicSupplierTable() {
    return Column(children: <Widget>[
      for (int i = 0; i < _suppliersList.length; i++)
        Container(
          margin: EdgeInsets.symmetric(
            vertical: 5.0,
          ),
          child: Column(
            children: [
              SupplierExpandedPage(
                strCity: Language()
                    .getString(Constants.CITY_NAME_STRING, selectedLang),
                strDistrict: Language()
                    .getString(Constants.DISTRICT_STRING, selectedLang),
                strLocality: Language().getString(
                    Constants.COLONY_SELECTOR_AREA_LOCALITY_STRING,
                    selectedLang),
                strContactNum: Language()
                    .getString(Constants.CONTACT_NUMBER, selectedLang),
                title: Language().getString(Constants.SUPPLIER, selectedLang) +
                    " : ${_suppliersList[i].name}",
                supplierModel: _suppliersList[i],
                editPage: () {},
                removeItem: () {},
              )
            ],
          ),
        )
    ]);
  }

  buildTableListRowContent(String textName, textFormName) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Expanded(
              flex: 3,
              child: Container(
                  child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(textName,
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_15,
                            fontFamily: 'IndianRupee'))),
              )),
            ),
            Container(
              child: Text(':'),
            ),
            Expanded(
                flex: 5,
                child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5),
                  child: Text(
                    textFormName,
                  ),
                ))
          ],
        ));
  }

  createDynamicRawInventory() {
    return Column(children: <Widget>[
      for (int i = 0; i < rawInventoryList.length; i++)
        Container(
          margin: EdgeInsets.symmetric(
            vertical: 5.0,
          ),
          child: RawInventoryExpandedPage(
            title: Language().getString(Constants.ISSUED_TO, selectedLang) +
                " : ${rawInventoryList[i].issuedTo}",
            managementModel: rawInventoryList[i],
          ),
        ),
    ]);
  }

  createDynamicQuantityAdjustData() {
    return Column(children: <Widget>[
      for (int i = 0; i < adjustQuanityList.length; i++)
        if (adjustQuanityList[i].quantityAdjustLocationsList!.length > 0)
          Column(
            children: <Widget>[
              SizedBox(height: (i == 0) ? 10 : 20.0),
              Container(
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      border: Border.all(color: theme.colorScheme.primary)),
                  child: ExpansionTile(
                    title: Text(
                      Language().getString(Constants.LOCATION, selectedLang) +
                          " : ${adjustQuanityList[i].locationName}",
                      style: TextStyle(
                          color: Color(Constants.APP_COLOR),
                          fontFamily: StyleView.FONT_TITLE),
                    ),
                    children: <Widget>[
                      SizedBox(
                        height: 1,
                        child:
                            new Container(color: Color(Constants.GREY_COLOR)),
                      ),
                      InventoryLocationBatchView(
                        isShowLocationDetails: true,
                        locationsList:
                            adjustQuanityList[i].quantityAdjustLocationsList,
                        adjustmentReason: adjustQuanityList[i].reason,
                        isShowAdjustmentReason: true,
                        updateDate: adjustQuanityList[i].updatedDate,
                        updatedBy: adjustQuanityList[i].updatedBy,
                        strBatchNumber: Language()
                            .getString(Constants.BATCH_NO, selectedLang),
                        strQuantity: Language()
                            .getString(Constants.QUANTITY, selectedLang),
                        strUpdatedBy: Language()
                            .getString(Constants.UPDATED_BY, selectedLang),
                        strUpdatedDate: Language()
                            .getString(Constants.UPDATED_DATE, selectedLang),
                        strAdjustedQuantity: Language().getString(
                            Constants.ADJUSTED_QUANTITY, selectedLang),
                        strReason: Language()
                            .getString(Constants.REASON, selectedLang),
                      )
                    ],
                  ))
            ],
          )
    ]);
  }

  bindProductData(BuProductModal _data) {
    for (int p = 0; p < _data.batchPrice!.length; p++) {
      totalBatchQuantity = totalBatchQuantity + _data.batchPrice![p].quantity!;
      _priceList.add(PriceModel(
          batchNumber: _data.batchPrice![p].batchNumber,
          currencyName: _data.batchPrice![p].currencyName,
          expireDate: _data.batchPrice![p].expiryDate,
          manufacturDate: _data.batchPrice![p].manufactureDate,
          mrp: _data.batchPrice![p].mrp.toString(),
          netRate: _data.batchPrice![p].netRate.toString(),
          price: _data.batchPrice![p].price.toString(),
          priceIn: _data.batchPrice![p].unitPrice,
          quantity: _data.batchPrice![p].quantity.toString(),
          quantityIn: _data.batchPrice![p].quantityIn,
          issuedTo: _data.batchPrice![p].issuedTo,
          isRawMaterial: _data.batchPrice![p].isRawMaterial,
          isActualProduct: _data.batchPrice![p].isActualProduct));
    }

    for (int i = 0; i < _data.offers!.length; i++) {
      _offersList.add(OffersModel(
          offerName: _data.offers![i].offerName,
          offerQuantity: _data.offers![i].offerQuantity,
          minOrder: _data.offers![i].minOrder,
          maxOrder: _data.offers![i].maxOrder,
          startDate: _data.offers![i].startDate,
          endDate: _data.offers![i].endDate,
          details: _data.offers![i].details,
          offerDiscount: _data.offers![i].offerType,
          isOfferActive: _data.offers![i].isOfferActive,
          isOfferExpired: _data.offers![i].isOfferExpired));
    }

    for (int j = 0; j < _data.suppliers!.length; j++) {
      _suppliersList.add(SupplierModel(
          id: _data.suppliers![j].id,
          name: _data.suppliers![j].name,
          city: _data.suppliers![j].city,
          district: _data.suppliers![j].district,
          locality: _data.suppliers![j].locality,
          contact: _data.suppliers![j].phoneNo));
    }

    for (int k = 0; k < _data.rawInventoryData!.length; k++) {
      rawInventoryList.add(RawInventory(
          issuedTo: _data.rawInventoryData![k].issuedTo,
          quantity: _data.rawInventoryData![k].quantity));
    }

    for (int k = 0; k < _data.inventoryData!.length; k++) {
      List<InventoryDetailsDAO> _locationBatchList = [];
      for (int m = 0;
          m < _data.inventoryData![k].locationBatchList!.length;
          m++) {
        _locationBatchList.add(InventoryDetailsDAO(
            batchNumber:
                _data.inventoryData![k].locationBatchList![m].batchNumber,
            quantity: _data.inventoryData![k].locationBatchList![m].quantity,
            quantityIn:
                _data.inventoryData![k].locationBatchList![m].quantityIn,
            updatedUser:
                _data.inventoryData![k].locationBatchList![m].updatedUser,
            updatedDate:
                _data.inventoryData![k].locationBatchList![m].updatedDate));
      }

      _inventoryList.add(InventoryManagementModel(
          locationName: _data.inventoryData![k].locationName,
          locationId: _data.inventoryData![k].locationId,
          locationBatchList: _locationBatchList));
    }

    // adjustQuanityList.addAll(_data.quantityAdjustList);

    for (int j = 0; j < responseAdjustmentList.length; j++) {
      for (int k = 0; k < _inventoryList.length; k++) {
        if (responseAdjustmentList[j].locationId ==
            _inventoryList[k].locationId) {
          adjustQuanityList.add(QuantityAdjustmentDAO(
              locationId: _inventoryList[k].locationId,
              locationName: _inventoryList[k].locationName,
              quantityAdjustLocationsList:
                  responseAdjustmentList[j].quantityAdjustLocationsList,
              reason: responseAdjustmentList[j].reason,
              updatedBy: responseAdjustmentList[j].updatedBy,
              updatedDate: AppUtills.getDateFormate(
                  responseAdjustmentList[j].updatedDate)));
        }
      }
    }
  }

  showEditButton() {
    if (_productPrivileges != null &&
        _productPrivileges!.edit_product &&
        !widget.isShowBasicDetails &&
        _productDataList.length > 0) {
      return IconButton(
          icon: Icon(
            FeatherIcons.edit,
            size: 18,
          ),
          onPressed: () {
            Navigator.push(
                context,
                PageTransition(
                  context: context,
                  page: EditMyProductPage(
                    title: Constants.UPDATE_PRODUCT,
                    buId: _productDataList[0].buId,
                    productId: _productDataList[0].id,
                    isFromRawMaterialPage: widget.isFromRawProductsPage,
                    rawMaterialTitle: Constants.UPDATE_RAW_MATERIAL,
                  ),
                )).then((value) => this.loadProductData());
          });
    }
    return Container();
  }

  scrollViewProductData() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        // Expanded(
        //   child: Container(
        //       width: MediaQuery.of(context).size.width,
        //       child: this.displayProductImage()),
        // ),
        // this.showTempListView(),
        Expanded(
            child: SingleChildScrollView(
          child: Column(
            children: [
              // if (selectedText == Constants.PRODUCT_DETAILS_STR)
              this.productDetails(),
              // if (selectedText == Constants.FEATURES) this.showAttributesView(),
              // if (selectedText == Constants.CATEGORIES_C)
              //   this.showCategoryDetails(),
              // if (selectedText == Constants.MANUFACTURER_DETAILS)
              //   this.showManufacturerDetails(),
              // if (selectedText == Constants.PRICE_DETAILS)
              //   for (int i = 0; i < _productDataList[0].batchPrice!.length; i++)
              //     this.showPriceExpandView(_productDataList[0].batchPrice![i]),
              // if (selectedText == Constants.TAX_DETAILS)
              //   this.showTaxDetailsView(),
              // if (selectedText == Constants.ITEM_DETAILS)
              //   this.showItemDetailsView(),
              // if (selectedText == Constants.OFFERS_C)
              //   this._createDynamicOfferTable(),
              // if (selectedText == Constants.AVAILABLE_LOCATIONS)
              //   _createDynamicInventoryTable(),
              // if (selectedText == Constants.QUANTITY_ADJUSTMENT_C)
              //   showQuantityAdjustmentView(),
              // if (selectedText == Constants.TARNSIT_DETAILS_C)
              //   showTransitDetailsView()
            ],
          ),
        ))
      ],
    );
  }

  Widget displayProductImage() {
    if (_productDataList.length > 0 && _productDataList[0].images != null) {
      return Card(
        elevation: 0,
        // shape:
        //     new RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
        child: AspectRatio(
          aspectRatio: 16 / 9,
          child: ClipRRect(
            borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(5),
                bottomRight: Radius.circular(5)),
            child: Image.network(
              '${Constants.IAMGE_BUCKET_URL}${_productDataList[0].images}',
              fit: BoxFit.contain,
              errorBuilder: (BuildContext context, Object exception,
                  StackTrace? stackTrace) {
                return Image.asset(
                  'assets/images/no_image.jpg',
                );
              },
            ),
          ),
        ),
      );
    } else {
      return Card(
        elevation: 5,
        shape:
            new RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
        child: AspectRatio(
          aspectRatio: 16 / 9,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(5),
            child: Image.asset(
              'assets/images/no_image.jpg',
            ),
          ),
        ),
      );
    }
  }

  showProductNamePriceView() {
    return Container(
      padding: EdgeInsets.all(10.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Container(
            child: Row(children: <Widget>[
              Container(
                child: Text(
                    _productDataList.length > 0
                        ? _productDataList[0].name!
                        : "",
                    style: TextStyle(
                        fontSize: 17.0,
                        fontWeight: FontWeight.bold,
                        color: Color(Constants.APP_COLOR))),
              ),
            ]),
          ),
          Container(
              child: Text(
            "$orgCurrencySymbol"
            // +
            //     CommonMethods.getAvailablePrice(_productDataList.length > 0
            //         ? _productDataList[0].batchPrice
            //         : ""
            ,
            style: TextStyle(
                fontSize: 14.0,
                fontWeight: FontWeight.bold,
                color: Color(Constants.APP_COLOR)),
          ))
        ],
      ),
    );
  }

  showAttributesView() {
    if (_productDataList[0].attributes!.length > 0) {
      return Container(
        margin: EdgeInsets.symmetric(vertical: 5.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            for (int i = 0; i < _productDataList[0].attributes!.length; i++)
              Container(
                  margin: EdgeInsets.symmetric(horizontal: 5.0),
                  child: Card(
                    elevation: 3.0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(50.0),
                    ),
                    child: Container(
                      decoration: BoxDecoration(
                          border: Border.all(color: Color(Constants.APP_COLOR)),
                          borderRadius: BorderRadius.circular(50.0)),
                      padding: EdgeInsets.all(8.0),
                      child: Text(
                        "${_productDataList[0].attributes![i].entries.toList()[0].key} : ${_productDataList[0].attributes![i].entries.toList()[0].value}",
                        style:
                            TextStyle(fontSize: 14.0, color: Colors.grey[700]),
                      ),
                    ),
                  )),
          ],
        ),
      );
    } else {
      return Container();
    }
  }

  void _scrollToCenter(int index) {
    double screenWidth = MediaQuery.of(context).size.width;
    double totalTabsWidth = tempListItems.length * 150.0;
    double offset = (index * 150.0) - (screenWidth / 2) + (150.0 / 2);

    if (offset < 0) {
      offset = 0;
    } else if (offset > totalTabsWidth - screenWidth) {
      offset = totalTabsWidth - screenWidth;
    }

    _scrollController.animateTo(
      offset,
      duration: Duration(milliseconds: 500),
      curve: Curves.easeInOut,
    );
  }

  showTempListView() {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 10.0),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        controller: _scrollController,
        child: Row(
          children: <Widget>[
            for (int i = 0; i < tempListItems.length; i++)
              InkWell(
                onTap: () {
                  _scrollToCenter(i);
                  setState(() {
                    for (int j = 0; j < tempListItems.length; j++) {
                      if (i == j) {
                        selectedText = tempListItems[j]['name'];
                        tempListItems[j]['isChecked'] = true;
                      } else {
                        tempListItems[j]['isChecked'] = false;
                      }
                    }
                  });
                },
                child: Container(
                    margin: EdgeInsets.symmetric(horizontal: 5.0),
                    child: Container(
                      decoration: BoxDecoration(
                          color: (tempListItems[i]['isChecked'])
                              ? Colors.black
                              : Color(0xff9C9C9C),
                          borderRadius: BorderRadius.circular(5)),
                      padding: EdgeInsets.all(8.0),
                      child: Text(
                        tempListItems[i]['name'],
                        style: TextStyle(
                            fontSize: 12.0,
                            color: Colors.white,
                            fontWeight: StyleView.fontMedium),
                      ),
                    )),
              )
          ],
        ),
      ),
    );
  }

  showCategoryDetails() {
    return Card(
      elevation: 5,
      margin: EdgeInsets.only(top: 10),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(children: [
          productDetilsNewDesign(Constants.PRODUCT_SECTOR,
              "${_productDataList.length > 0 ? _productDataList[0].productSector : ""}"),
          productDetilsNewDesign(Constants.PRODUCT_SEGMENT,
              "${_productDataList.length > 0 ? _productDataList[0].productSegment : ""}"),
          productDetilsNewDesign(Constants.PRODUCT_CATEGORY,
              "${_productDataList.length > 0 ? _productDataList[0].productCategory : ""}"),
          productDetilsNewDesign(Constants.PRODUCT_SUB_CATEGORY,
              "${_productDataList.length > 0 ? _productDataList[0].productSubCategory : ""}")
        ]),
      ),
    );
  }

  showManufacturerDetails() {
    return Card(
        elevation: 3,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              productDetilsNewDesign(Constants.MOBILE_NUMBER,
                  _productDataList[0].manufactureDetails?.modelNumber),
              productDetilsNewDesign(Constants.RELEASE_DATE,
                  "${_productDataList[0].manufactureDetails?.releaseDate}"),
              productDetilsNewDesign(Constants.NAME_STRING,
                  _productDataList[0].manufactureDetails?.name),
              productDetilsNewDesign(Constants.PLOT_NO,
                  _productDataList[0].manufactureDetails?.area),
              productDetilsNewDesign(Constants.BULIDING,
                  _productDataList[0].manufactureDetails?.buildiName),
              // productDetilsNewDesign(Constants.BUILDING_STREET_NAME_STRING,
              //     _productDataList[0].manufactureDetails?.manufacturerAddress),
              productDetilsNewDesign(Constants.COUNTRY_NAME_STRING,
                  _productDataList[0].manufactureDetails?.country),
              productDetilsNewDesign(Constants.STATE_NAME_STRING,
                  _productDataList[0].manufactureDetails?.state),
              productDetilsNewDesign(Constants.DISTRICT_STRING,
                  _productDataList[0].manufactureDetails?.district),
              productDetilsNewDesign(Constants.CITY_NAME_STRING,
                  _productDataList[0].manufactureDetails?.city),
              productDetilsNewDesign(Constants.PIN_CODE,
                  _productDataList[0].manufactureDetails?.pin),
            ],
          ),
        ));
  }

  showItemDetailsView() {
    return Card(
        elevation: 3,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              productDetilsNewDesign(Constants.HEIGHT,
                  _productDataList[0].shippingDetails?.height),
              productDetilsNewDesign(
                  Constants.WIDTH, _productDataList[0].shippingDetails?.width),
              productDetilsNewDesign(
                  Constants.DEPTH, _productDataList[0].shippingDetails?.depth),
              productDetilsNewDesign(Constants.VOLUME,
                  _productDataList[0].shippingDetails?.volume),
              productDetilsNewDesign(Constants.WEIGHT,
                  _productDataList[0].shippingDetails?.weight),
            ],
          ),
        ));
  }

  showTaxDetailsView() {
    return Card(
        elevation: 3,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              productDetilsNewDesign(
                  Constants.TAX_TYPE, _productDataList[0].tax?.type),
              productDetilsNewDesign(
                  Constants.HSN_CODE, "${_productDataList[0].tax?.value}"),
              productDetilsNewDesign(
                  Constants.HSN_CODE, _productDataList[0].tax?.hsnCode),
            ],
          ),
        ));
  }

  showTotalQuantityView() {
    if (!widget.isShowBasicDetails && _priceList.length > 0) {
      return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(
          padding: EdgeInsets.all(10.0),
          child: productDetilsNewDesign(
              Constants.TOTAL_QUANTITY_STRING, "$totalBatchQuantity"),
        ),
        mainText(Constants.PRICE_DETAILS),
        Padding(
            padding: EdgeInsets.all(10.0), child: createPriceDetailsDynamic()),
      ]);
    } else {
      return Container();
    }
  }

  showOffersView() {
    // if (_productDataList.length > 0 &&
    //     _productDataList[0].offers.length > 0 &&
    //     !widget.isShowBasicDetails &&
    //     !_productDataList[0].isRawProduct) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: EdgeInsets.all(10.0),
          child: _createDynamicOfferTable(),
        ),
      ],
    );
    // } else {
    //   return Container();
    // }
  }

  showSuppliersView() {
    if (_productDataList.length > 0 &&
        _productDataList[0].suppliers!.length > 0 &&
        !widget.isShowBasicDetails) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          mainText(Constants.SUPPLIERS_C),
          Container(
            padding: EdgeInsets.all(10.0),
            child: _createDynamicSupplierTable(),
          ),
        ],
      );
    } else {
      return Container();
    }
  }

  showRawInventoryView() {
    if (_productDataList.length > 0 &&
        _productDataList[0].isRawProduct! &&
        rawInventoryList.length > 0) {
      return Column(
        children: [
          mainText(Constants.RAW_MATERIALS_C),
          Container(
            padding: EdgeInsets.all(10.0),
            child: createDynamicRawInventory(),
          )
        ],
      );
    } else {
      return Container();
    }
  }

  showLocationsView() {
    if (_inventoryList.length > 0 && !widget.isShowBasicDetails) {
      return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        mainText(Constants.AVAILABLE_LOCATIONS),
        Container(
          padding: EdgeInsets.all(10.0),
          child: _createDynamicInventoryTable(),
        ),
      ]);
    } else {
      return Container();
    }
  }

  showQuantityAdjustmentView() {
    if (adjustQuanityList.length > 0 && !widget.isShowBasicDetails) {
      return Card(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.only(left: 10, top: 10),
              child: mainText(Constants.QUANTITY_ADJUSTMENT),
            ),
            Container(
              padding: EdgeInsets.all(10.0),
              child: createDynamicQuantityAdjustData(),
            ),
          ],
        ),
      );
    } else {
      return Container(
        padding: EdgeInsets.only(top: 50),
        child: Center(
          child:
              Text(Language().getString(Constants.NO_DATA_FOUND, selectedLang)),
        ),
      );
    }
  }

  showTransitDetailsView() {
    if (!widget.isShowBasicDetails &&
        _productDataList.length > 0 &&
        !_productDataList[0].isRawProduct! &&
        _transitList.length > 0) {
      return Card(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Padding(
            padding: EdgeInsets.only(left: 10, top: 10),
            child: mainText(Language()
                .getString(Constants.TRANSIT_DETAILS_C, selectedLang)),
          ),
          Container(
              padding: EdgeInsets.all(10.0), child: this.showTransitDetails()),
        ]),
      );
    } else {
      return Container();
    }
  }

  productDetails() {
    return Container(
      color: Colors.white,
      // margin: EdgeInsets.only(top: 10),
      child: Container(
          // padding: EdgeInsets.all(10.0),
          child: Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                Container(
                    width: MediaQuery.of(context).size.width,
                    child: displayProductImage()),
                SizedBox(height: 20),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 10),
                  child: Column(
                    children: [
                      productDetilsNewDesign(
                          Constants.PRODUCT_NAME,
                          _productDataList.length > 0
                              ? _productDataList[0].name
                              : ""),
                      productDetilsNewDesign(
                          Constants.BRAND,
                          _productDataList.length > 0
                              ? _productDataList[0].brand
                              : ""),
                      productDetilsNewDesign(
                          Constants.DESCRIPTION_STRING,
                          _productDataList.length > 0
                              ? _productDataList[0].description
                              : ""),
                    ],
                  ),
                ),
                if (_productDataList[0].attributes!.length > 0)
                  Container(
                    width: MediaQuery.of(context).size.width,
                    child: Card(
                      elevation: 0,
                      margin: EdgeInsets.only(top: 10),
                      child: Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Padding(
                              padding: EdgeInsets.only(bottom: 10),
                              child: Container(
                                alignment: Alignment.centerLeft,
                                child: Text(
                                  Constants.ATTRIBUTES,
                                  style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: StyleView.fontSemiBold,
                                      color: theme.colorScheme.primary),
                                ),
                              ),
                            ),
                            for (int i = 0;
                                i < _productDataList[0].attributes!.length;
                                i++)
                              Container(
                                  margin: EdgeInsets.symmetric(vertical: 10),
                                  child: Container(
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                            color: Color(Constants.APP_COLOR)),
                                        borderRadius:
                                            BorderRadius.circular(50.0)),
                                    padding: EdgeInsets.all(8.0),
                                    child: Text(
                                      "${_productDataList[0].attributes![i].entries.toList()[0].key} : ${_productDataList[0].attributes![i].entries.toList()[0].value}",
                                      style: TextStyle(
                                          fontSize: 14.0,
                                          color: Colors.grey[700]),
                                    ),
                                  )),
                          ],
                        ),
                      ),
                    ),
                  ),

                // if (selectedText == Constants.PRICE_DETAILS)
                Padding(
                  padding: EdgeInsets.only(top: 10, bottom: 20, left: 10),
                  child: Container(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      Language()
                          .getString(Constants.PRICE_DETAILS, selectedLang),
                      style: TextStyle(
                          fontSize: 14,
                          fontWeight: StyleView.fontSemiBold,
                          color: theme.colorScheme.primary),
                    ),
                  ),
                ),
                for (int i = 0; i < _productDataList[0].batchPrice!.length; i++)
                  this.showPriceExpandView(_productDataList[0].batchPrice![i]),
                // productDetilsNewDesign(Constants.PRODUCT_SECTOR,
                //     "${_productDataList.length > 0 ? _productDataList[0].productSector : ""}"),
                // // productDetilsNewDesign(Constants.PRODUCT_SEGMENT,
                // //     "${_productDataList.length > 0 ? _productDataList[0].productSegment : ""}"),
                // productDetilsNewDesign(Constants.PRODUCT_CATEGORY,
                //     "${_productDataList.length > 0 ? _productDataList[0].productCategory : ""}"),
                // productDetilsNewDesign(Constants.PRODUCT_SUB_CATEGORY,
                //     "${_productDataList.length > 0 ? _productDataList[0].productSubCategory : ""}")
              ],
            ),
          ),
        ],
      )),
    );
  }
}
