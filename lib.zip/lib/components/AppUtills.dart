import 'dart:convert';
import 'dart:io';
import 'package:flutter_native_contact_picker/flutter_native_contact_picker.dart';
import 'package:flutter_native_contact_picker/model/contact.dart';
import 'package:vyaparlive/animations/loader_animation/animation.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/image_hero/ImageHeroView.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:date_format/date_format.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
// import 'package:fluttercontactpicker/fluttercontactpicker.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:vyaparlive/Home/HomePageView.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/model/PrivilegesDAO.dart';
import 'package:vyaparlive/model/RolesDAO.dart';
import 'package:url_launcher/url_launcher.dart';

class AppUtills {
  static String selectedLang = "en";
  static String getDateFormate(String? date, {bool convertToUtc = true}) {
    if (date != null && date != "null" && date.isNotEmpty) {
      DateFormat format = DateFormat("yyyy-MM-dd hh:mm aa");
      DateTime _timeStamp = DateTime.parse(date);
      return format.format(_timeStamp.toLocal()).toString();
    } else {
      return "";
    }
  }

  static boxDecoration(
      {Color customContainerColor = Colors.transparent,
      Color customBorderColor = Colors.grey,
      num customBorderRadius = 5.0}) {
    return BoxDecoration(
        border: Border.all(
          color: customBorderColor,
        ),
        borderRadius: BorderRadius.circular(
          customBorderRadius as double,
        ),
        color: customContainerColor);
  }

  static sendMessageDesign() {
    return BoxDecoration(
      color: AppTheme
          .learningTheme.colorScheme.secondaryContainer, // Color(0xfff7ffe6),

      // boxShadow: [
      //   BoxShadow(offset: Offset(0, 2), blurRadius: 2.0, color: Colors.grey)
      // ],
      border: Border.all(
          color: AppTheme.learningTheme.colorScheme.secondaryContainer,
          strokeAlign: 3.0),
      borderRadius: BorderRadius.only(
        topLeft: Radius.circular(15),
        bottomLeft: Radius.circular(15),
        bottomRight: Radius.circular(15),
      ),
    );
  }

  static receiveMessageDesign() {
    return BoxDecoration(
      border: Border.all(
          color: AppTheme.learningTheme.colorScheme.primaryContainer,
          strokeAlign: 3.0),
      // boxShadow: [
      //   BoxShadow(
      //       offset: Offset(0, 2),
      //       blurRadius: 2.0,
      //       color: AppTheme.theme.colorScheme.primaryContainer)
      // ],
      color:
          Colors.white, //AppTheme.learningTheme.colorScheme.primaryContainer,
      borderRadius: BorderRadius.only(
        topRight: Radius.circular(10),
        bottomLeft: Radius.circular(10),
        bottomRight: Radius.circular(10),
      ),
    );
  }

  static showMsgDetails(String? userName, String msgDate) {
    return Container(
        child: Row(
      children: [
        userName != null && userName.isNotEmpty
            ? Container(
                child: Text(
                  "$userName  ",
                  style: TextStyle(fontSize: 10.0, color: Colors.black),
                ),
              )
            : new Container(),
        Container(
          child: Text(
            msgDate,
            style: TextStyle(fontSize: 10.0, color: Colors.black),
          ),
        ),
      ],
    ));
  }

  static Future<String> getSelectedDate(BuildContext context,
      {bool isShowIntialDate = false,
      int initialYear = 2019,
      bool isShowTodayDate = false}) async {
    DateFormat formatter = DateFormat("yyyy-MM-dd");
    DateTime initialDate = DateTime.now();
    String myDate = "";

    DateTime? picked = await showDatePicker(
        context: context,
        initialDate: initialDate,
        firstDate: (isShowIntialDate) ? initialDate : DateTime(initialYear),
        lastDate: (isShowTodayDate) ? initialDate : DateTime(2222));
    if (picked != null) {
      initialDate = picked;
      myDate = formatter.format(initialDate);
    } else {
      myDate = formatter.format(initialDate);
    }

    // await DatePicker.showDatePicker(context, showTitleActions: true,
    //     onConfirm: (date) {
    //   myDate = formatter.format(date);
    // }, currentTime: DateTime.now());
    return myDate;
  }

  static Future<String> getSelectedTime(BuildContext context) async {
    TimeOfDay selectedTime = TimeOfDay.now();
    String pickedTime = "";
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: selectedTime,
    );
    if (picked != null) {
      selectedTime = picked;
      pickedTime = formatDate(
          DateTime(0, 0, 0, selectedTime.hour, selectedTime.minute),
          [hh, ':', nn, " ", am]).toString();
    } else {
      pickedTime = formatDate(
          DateTime(0, 0, 0, selectedTime.hour, selectedTime.minute),
          [hh, ':', nn, " ", am]).toString();
    }
    return pickedTime;
  }

  static showSnackBar(GlobalKey<ScaffoldState> key, String message,
      {Color snackBarBgColor = Colors.red,
      Color messageColor = Colors.white,
      Color buttonColor = Colors.black}) {
    final snackBar = SnackBar(
      backgroundColor: snackBarBgColor,
      content: Text(
        message,
        style: TextStyle(color: messageColor),
      ),
      action: SnackBarAction(
        textColor: buttonColor,
        label: 'OK',
        onPressed: () {},
      ),
    );
    try {
      // key.currentState!.showSnackBar(snackBar);
    } catch (e) {
      print(e.toString());
    }
  }

  static String? getNotificationMessage(
      String? notificationSender, String? notificationType, String? buId) {
    String? message = "";

    List notificationMessage = [
      {
        "type": Constants.PUSH_TRANSACTION_STARTED,
        "buyer_message":
            "New transaction record is created with $notificationSender",
        "seller_message":
            "New transaction record is created by $notificationSender"
      },
      {
        "type": Constants.PUSH_TRANSACTION_PACKING,
        "buyer_message":
            "$notificationSender has updated packing details for your order",
        "seller_message":
            "Packing details are updated for $notificationSender order"
      },
      {
        "type": Constants.PUSH_DISCUSSION_STARTED,
        "buyer_message":
            "You have started new order discussion with $notificationSender",
        "seller_message":
            "$notificationSender has started a new order discussion"
      },
      {
        "type": Constants.PUSH_TRANSACTION_ORDER,
        "buyer_message": "You have placed new order to $notificationSender",
        "seller_message": "$notificationSender has placed new order"
      },
      {
        "type": Constants.PUSH_TRANSACTION_INVOICE,
        "buyer_message":
            "Invoice has been generated for your order by $notificationSender",
        "seller_message":
            "Invoice has been generated for order from $notificationSender"
      },
      {
        "type": Constants.PUSH_TRANSACTION_DELIVERY,
        "buyer_message":
            "Delivery details of your Invoice have been updated by $notificationSender",
        "seller_message":
            "Delivery details has been update for $notificationSender"
      },
      {
        "type": Constants.PUSH_STOCK_RECONCILIATION_STARTED,
        "buyer_message":
            "You have marked stocks receipt as Discrepancy for delivered goods from $notificationSender",
        "seller_message":
            "$notificationSender has marked received stocks as Discrepancy for delivered goods"
      },
      {
        "type": Constants.PUSH_STOCK_RECONCILIATION_NOT_RESOLVED,
        "buyer_message":
            "You have marked stocks reconciliation as not resolved for the delivered goods from $notificationSender",
        "seller_message":
            "$notificationSender have marked stocks reconciliation as not resolved for the delivered goods"
      },
      {
        "type": Constants.PUSH_STOCK_RECONCILIATION_RESOLVED,
        "buyer_message":
            "You have marked stocks reconciliation as resolved for the delivered goods from $notificationSender",
        "seller_message":
            "$notificationSender have marked stocks reconciliation as resolved for the delivered goods"
      },
      {
        "type": Constants.PUSH_PAYMENT_RECONCILIATION_STARTED,
        "buyer_message":
            "You have marked stocks receipt as Discrepancy for invoice from $notificationSender",
        "seller_message":
            "$notificationSender have marked stocks receipts as Discrepancy for invoice"
      },
      {
        "type": Constants.PUSH_PAYMENT_RECONCILIATION_NOT_RESOLVED,
        "buyer_message":
            "You have marked stocks reconciliation as not resolved for invoice from $notificationSender",
        "seller_message":
            "$notificationSender have marked stocks reconciliation as not resolved for invoice"
      },
      {
        "type": Constants.PUSH_PAYMENT_RECONCILIATION_RESOLVED,
        "buyer_message":
            "You have marked stocks reconciliation as resolved for invoice from $notificationSender",
        "seller_message":
            "$notificationSender have marked stocks reconciliation as resolved for invoice"
      },
      {
        "type": Constants.PUSH_TRANSACTION_MENU_ORDER,
        "buyer_message":
            "You have accepted In-Person Order from $notificationSender and new Transaction is initiated",
        "seller_message":
            "$notificationSender have accepted new In-Person Order and new Transaction is initiated"
      },
      {
        "type": Constants.PUSH_TRANSACTION_ASSIGN,
        "buyer_message": "New Packing task is assigned by $notificationSender",
        "seller_message": "New Packing task is assigned"
      },
      {
        "type": Constants.PUSH_TRANSACTION_ORDER_ACCEPTED,
        "buyer_message": "Your order has been accepted by $notificationSender",
        "seller_message": "A New order accepted for $notificationSender"
      },
      {
        "type": Constants.PUSH_TRANSACTION_ORDER_REJECTED,
        "buyer_message": "Your order has been rejected by $notificationSender",
        "seller_message": "You have rejected a order for $notificationSender"
      },
      {
        "type": Constants.PUSH_CREATE_OFFLINE_ORDER,
        "buyer_message": "Your offline order has been created by $notificationSender",
        "seller_message": "A new offline order has been created for $notificationSender"
      },
    ];

    for (int i = 0; i < notificationMessage.length; i++) {
      if (notificationMessage[i]['type'] == notificationType) {
        if (buId == AppController.instance.getMyBuId) {
          message = notificationMessage[i]["buyer_message"];
        } else {
          message = notificationMessage[i]["seller_message"];
        }
      }
    }

    return message;
  }

  static Gradient getLinearGradient({required List<Color?> colors}) {
    return LinearGradient(
        colors: colors as List<Color>,
        begin: Alignment.topLeft,
        end: Alignment.bottomRight);
  }

  static connectivityResult() async {
    var connectivityResult = await (Connectivity().checkConnectivity());
    if (connectivityResult == ConnectivityResult.mobile) {
      print("Connected to Mobile Network");
    } else if (connectivityResult == ConnectivityResult.wifi) {
      print("Connected to WiFi");
    } else {
      print("Unable to connect. Please Check Internet Connection");
    }
  }

  static displayImage(String? imageUrl, {required BuildContext context}) {
    if (imageUrl == null || imageUrl.isEmpty) {
      return Image.asset(
        'assets/images/no_image.jpg',
        width: MediaQuery.of(context).size.width,
        height: 40,
        gaplessPlayback: true,
        fit: BoxFit.cover,
      );
    } else {
      return CachedNetworkImage(
          imageUrl: '${Constants.IAMGE_BUCKET_URL}$imageUrl',
          width: MediaQuery.of(context).size.width,
          height: 40,
          errorWidget: (context, url, error) => Image.asset(
                'assets/images/no_image.jpg',
                width: MediaQuery.of(context).size.width,
                height: 40,
                gaplessPlayback: true,
              ));
    }
  }

  static imageAspectRatio(String? imageURL,
      {dynamic aspectRatio = 10 / 5, required BuildContext context}) {
    if (imageURL == 'null' || imageURL == null || imageURL.isEmpty) {
      return AspectRatio(
          aspectRatio: aspectRatio,
          child: ClipRRect(
              borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(5),
                  bottomRight: Radius.circular(5)),
              child: Image.asset(
                'assets/images/no_image.jpg',
                // width: MediaQuery.of(context).size.width,
                // height: 40,
                gaplessPlayback: true,
                fit: BoxFit.contain,
              )));
    } else {
      return AspectRatio(
        aspectRatio: aspectRatio,
        child: ClipRRect(
            borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(5),
                bottomRight: Radius.circular(5)),
            child: CachedNetworkImage(
                imageUrl: '${Constants.IAMGE_BUCKET_URL}$imageURL',
                // width: MediaQuery.of(context).size.width,
                // height: 40,
                fit: BoxFit.contain,
                errorWidget: (context, url, error) => Image.asset(
                      'assets/images/no_image.jpg',
                      // width: MediaQuery.of(context).size.width,
                      // height: 40,
                      fit: BoxFit.contain,
                      gaplessPlayback: true,
                    ))

            // Image.network(
            //   '${Constants.IAMGE_BUCKET_URL}$imageURL',
            //   fit: BoxFit.contain,
            //   gaplessPlayback: true,
            //   errorBuilder: (BuildContext context, Object exception,
            //       StackTrace? stackTrace) {
            //     return Image.asset(
            //       'assets/images/no_image.jpg',
            //       gaplessPlayback: true,
            //       fit: BoxFit.contain,
            //       // height: 100,
            //     );
            //   },
            // ),
            ),
      );
    }
  }

  static displayStockImage(String? imageUrl) {
    if (imageUrl == null || imageUrl == "") {
      return Image.asset(
        'assets/images/empty.jpg',
        width: 50,
        height: 50,
        gaplessPlayback: true,
      );
    } else {
      return Image.network(
        '${Constants.IAMGE_BUCKET_URL}$imageUrl',
        headers: {
          'Content-type': 'application/json',
          'Accept': 'application/json',
          'authorization': AppController.instance.getAuthorizationKey
        },
        gaplessPlayback: true,
        width: 80.0,
        height: 80.0,
        fit: BoxFit.fill,
        errorBuilder:
            (BuildContext context, Object exception, StackTrace? stackTrace) {
          return Image.asset(
            'assets/images/empty.jpg',
            width: 40,
            height: 40,
            gaplessPlayback: true,
          );
        },
      );
    }
  }

  static getContactFromPhoneBook() async {
    final FlutterNativeContactPicker _contactPicker =
        FlutterNativeContactPicker();
    Contact? contact = await _contactPicker.selectContact();
    // final PhoneContact contact = await FlutterContactPicker.pickPhoneContact();
    return contact;
  }

  static showTransactionStageMessage() {
    return Center(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
              margin: EdgeInsets.symmetric(horizontal: 5.0),
              child: Text(
                Language().getString(Constants.HINT_MESSAGE, selectedLang),
                style: TextStyle(
                    color: Colors.black, fontWeight: StyleView.fontRegular),
              )),
          Container(
            margin: EdgeInsets.only(
              top: 20.0,
            ),
            height: 10.0,
            width: 10.0,
            decoration:
                BoxDecoration(shape: BoxShape.circle, color: Colors.orange),
          )
        ],
      ),
    );
  }

  static showTransactionNotApplicableMessage() {
    return Center(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
              margin: EdgeInsets.symmetric(horizontal: 5.0),
              child: Text(
                Language().getString(Constants.NOT_APPLICABLE, selectedLang),
                style: TextStyle(
                    color: Colors.black, fontWeight: StyleView.fontRegular),
              )),
          Container(
            margin: EdgeInsets.only(
              top: 20.0,
            ),
            height: 10.0,
            width: 10.0,
            decoration:
                BoxDecoration(shape: BoxShape.circle, color: Colors.orange),
          )
        ],
      ),
    );
  }

  static appBackgroundWithImage() {
    return BoxDecoration(color: Colors.transparent
        // image: DecorationImage(
        //     image: AssetImage("assets/images/app_bg.png"), fit: BoxFit.cover),
        );
  }

  static Widget showLoadingView(
      {required BuildContext context,
      required String? message,
      required bool isLoading}) {
    return isLoading
        ? Scaffold(
            backgroundColor: Colors.transparent,
            body: Container(
              height: MediaQuery.of(context).size.height, //width * 0.30,
              width: MediaQuery.of(context).size.width, //width * 0.28,
              color: Colors.white.withOpacity(0.9),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Palse(loading: ValueNotifier(isLoading)),
                  SizedBox(height: 10),
                  Text(
                    message!,
                    style: TextStyle(
                        fontSize: 15,
                        fontWeight: StyleView.fontMedium,
                        color: Colors.black,
                        fontFamily: StyleView.FONT_TITLE),
                  ),
                ],
              ),
            ),
          )
        : Container();
  }

  static List<PrivilegesDAO> getPrivilegesList(Permissions? permissions) {
    List<PrivilegesDAO> _permissions = [];

    _permissions.addAll(
        permissions != null ? permissions.transactionsPermissions! : []);
    _permissions
        .addAll(permissions != null ? permissions.connectionPermissions! : []);
    _permissions
        .addAll(permissions != null ? permissions.productPermissions! : []);
    _permissions.addAll(
        permissions != null ? permissions.subscriptionPermissions! : []);
    _permissions.addAll(
        permissions != null ? permissions.inPersonOrderPermissions! : []);
    _permissions
        .addAll(permissions != null ? permissions.usersPermissions! : []);
    _permissions
        .addAll(permissions != null ? permissions.invitationsPermissions! : []);
    _permissions.addAll(permissions != null ? permissions.buPermissions! : []);
    _permissions.addAll(
        permissions != null ? permissions.productConsumptionPrivileges! : []);
    _permissions.addAll(
        permissions != null ? permissions.assetManagementPrivileges! : []);
    _permissions
        .addAll(permissions != null ? permissions.reportsPrivileges! : []);
    _permissions
        .addAll(permissions != null ? permissions.retailSalesPrivileges! : []);
    _permissions
        .addAll(permissions != null ? permissions.expensesPrivileges! : []);

    return _permissions;
  }

  static groupItems(List<PrivilegesDAO> _currentPrivilegesList) {
    // _assignedRolePermissions.clear();
    List<dynamic> _assignedRolePermissions = [];
    for (int i = 0; i < Constants.featureGroupItems.length; i++) {
      /// Adding feature group type
      bool isExists = false;
      _currentPrivilegesList.forEach((item) {
        if (item.featureGroup == Constants.featureGroupItems[i]) {
          isExists = true;
        }
      });

      if (isExists) {
        _assignedRolePermissions.add(Constants.featureGroupItems[i]);
      }

      for (int j = 0; j < _currentPrivilegesList.length; j++) {
        if (Constants.featureGroupItems[i] ==
            _currentPrivilegesList[j].featureGroup) {
          /// Adding feature value
          _assignedRolePermissions.add(_currentPrivilegesList[j]);
        }
      }
    }

    return _assignedRolePermissions;
  }

  static homeButton(BuildContext context) {
    return IconButton(
        icon: Icon(Icons.home_outlined),
        onPressed: () {
          Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => HomePageView()),
              (Route<dynamic> route) => false);
        });
  }

  static getOneDayAddedDate(String date) {
    String finalDate = "";
    var convertDate;
    DateFormat formatter = DateFormat("yyyy-MM-dd");
    var convert = DateTime.parse(date);
    convertDate = new DateTime(convert.year, convert.month, convert.day + 1);
    finalDate = formatter.format(convertDate);
    return finalDate;
  }

  static openPDF(sourcePdf, BuildContext context) async {
    final ByteData data = await rootBundle.load(sourcePdf);
    final List<int> bytes = data.buffer.asUint8List();
    return bytes;
  }

  static getCameraImage(String source, BuildContext context,
      {bool pdfRead = false}) async {
    ImagePicker _imagePicker = ImagePicker();
    File? resultImage;
    FilePickerResult? result;
    var selectedImage;
    if (source == Constants.CAMERA) {
      selectedImage = await _imagePicker.pickImage(source: ImageSource.camera);
      if (selectedImage != null) {
        resultImage = File(selectedImage.path);
      }
    } else {
      if (pdfRead) {
        result = await FilePicker.platform.pickFiles(
          type: FileType.custom,
          allowedExtensions: ['jpg', 'jpeg', 'png', 'pdf'],
        );

        if (result != null && result.files.isNotEmpty) {
          String filePath = result.files.first.path!;
          resultImage = File(filePath);
        }
      } else {
        selectedImage =
            await _imagePicker.pickImage(source: ImageSource.gallery);
        if (selectedImage != null) {
          // && selectedImage.path.endsWith("png")) {
          resultImage = File(selectedImage.path);
        }
      }
    }
    print("resultImage $resultImage");
    return resultImage;
  }

  static getBase64Image(File file, BuildContext context) {
    String base64Image = "";
    String convertFileToBytes = base64Encode(file.readAsBytesSync());
    base64Image = 'data:image/jpeg;base64,' + convertFileToBytes;
    return base64Image;
  }

  static Future<void> launchURL(String _url) async {
    print("BULK_PRODUCTS_UPLOAD $_url");
    if (await canLaunchUrl(Uri.parse(_url))) {
      await launchUrl(Uri.parse(_url));
    } else {
      throw 'Could not launch $_url';
    }
  }

  static displaySendStockImage(
      BuildContext context,
      int index,
      String? imageString,
      String? imageFrom,
      String? senderName,
      String? messageDate) {
    return GestureDetector(
      onTap: () {
        if (kIsWeb) {
          launchURL('${Constants.IAMGE_BUCKET_URL}$imageString');
        } else {
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => ImageHeroView(
                      tagName: "",
                      fileUrl: '${Constants.IAMGE_BUCKET_URL}$imageString',
                    )),
          );
        }
      },
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          ClipRRect(
              borderRadius: BorderRadius.circular(10.0),
              child: CachedNetworkImage(
                  imageUrl: '${Constants.IAMGE_BUCKET_URL}$imageString',
                  // placeholder: (context, url) => SizedBox(
                  //       width: 20,
                  //       height: 20,
                  //       child: CircularProgressIndicator(),
                  //     ),
                  errorWidget: (context, url, error) => Icon(Icons.error),
                  width: 80.0,
                  height: 80.0,
                  fit: BoxFit.cover)),
          Container(
            padding: EdgeInsets.only(top: 8.0),
            child: AppUtills.showMsgDetails(
              senderName,
              AppUtills.getDateFormate(messageDate),
            ),
          ),
        ],
      ),
    );
  }

  static displayReceiveStockImage(
      BuildContext context,
      int index,
      String? imageString,
      String? imageFrom,
      String? senderName,
      String messageDate) {
    return GestureDetector(
      onTap: () {
        if (kIsWeb) {
          launchURL('${Constants.IAMGE_BUCKET_URL}$imageString');
        } else {
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => ImageHeroView(
                      tagName: "",
                      fileUrl: '${Constants.IAMGE_BUCKET_URL}$imageString',
                    )),
          );
        }
      },
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
              borderRadius: BorderRadius.circular(10.0),
              child: CachedNetworkImage(
                  imageUrl: '${Constants.IAMGE_BUCKET_URL}$imageString',
                  // placeholder: (context, url) => SizedBox(
                  //       width: 20,
                  //       height: 20,
                  //       child: CircularProgressIndicator(),
                  //     ),
                  errorWidget: (context, url, error) => Icon(Icons.error),
                  width: 80.0,
                  height: 80.0,
                  fit: BoxFit.cover)),
          Container(
            padding: EdgeInsets.only(top: 8.0),
            child: AppUtills.showMsgDetails(
              senderName,
              AppUtills.getDateFormate(messageDate),
            ),
          ),
        ],
      ),
    );
  }

  static Future<String> getSelectedDateAndTime(BuildContext context) async {
    DateTime initialDate = DateTime.now();
    String myDate = "";

    DateTime? picked = await showDatePicker(
        context: context,
        initialDate: initialDate,
        firstDate: DateTime(1990),
        lastDate: DateTime(2222));
    if (picked != null) {
      initialDate = picked;
      myDate = initialDate.toString();
    }

    return myDate;
  }

  static String convertDateTimeToUtc(
      {required String selectedDate, required String? selectedTime}) {
    String convertedDate = "";
    if (selectedDate.isNotEmpty && selectedTime!.isNotEmpty) {
      String inputDateTimeString = "$selectedDate $selectedTime";
      final inputFormat = DateFormat('yyyy-MM-dd hh:mm a', 'en_US');
      DateTime inputDateTime = inputFormat.parse(inputDateTimeString);
      DateTime utcDateTime = inputDateTime.toUtc();
      final outputFormat = DateFormat('yyyy-MM-ddTHH:mm:ss.sss',
          'en_US'); //DateFormat('yyyy-MM-dd HH:mm:ss', 'en_US');
      convertedDate = outputFormat.format(utcDateTime);

      // DateTime newDate = DateTime.parse(selectedDate);
      // final format = DateFormat.jm();
      // TimeOfDay newTime = TimeOfDay.fromDateTime(format.parse(selectedTime));
      // convertedDate = DateTime(newDate.year, newDate.month, newDate.day,
      //         newTime.hour, newTime.minute)
      //     .toIso8601String();
    }

    return convertedDate;
  }

  // static String getISTTime(String? time) {
  //   if (time != null && time != "null" && time.isNotEmpty) {
  //     var dateTime = DateFormat("yyyy-MM-dd HH:mm:ss").parse(time, true);
  //     var dateLocal = dateTime.toLocal();
  //     var dateFormat = DateFormat("yyyy-MM-dd hh:mm aa");
  //     // print(dateFormat.format(dateLocal));
  //     return dateFormat.format(dateLocal).toString();
  //   } else {
  //     return '';
  //   }
  // }

  static String getISTTime(String? time) {
    if (time != null && time != "null" && time.isNotEmpty) {
      try {
        DateTime dateTime;
        if (time.contains('T')) {
          // ISO 8601 with Z
          dateTime = DateTime.parse(time).toLocal();
        } else {
          // Custom format
          dateTime =
              DateFormat("yyyy-MM-dd HH:mm:ss").parse(time, true).toLocal();
        }
        return DateFormat("yyyy-MM-dd hh:mm aa").format(dateTime);
      } catch (e) {
        print("Date parse error: $e, value: $time");
        return '';
      }
    }
    return '';
  }

  static bool parseBool(dynamic value) {
    if (value is bool) return value;

    if (value is String) {
      final lower = value.toLowerCase();
      return lower == 'true' || lower == 'yes' || lower == '1';
    }

    if (value is num) return value != 0;

    return false;
  }

  static List<Map<String, dynamic>> convertToObject(String input) {
    // Step 1: Add double quotes around keys
    String jsonString = input.replaceAllMapped(
        RegExp(r'(\w+)\s*:'), (match) => '"${match[1]}":');

    // Step 2: Add quotes around string values (NOT numbers)
    jsonString = jsonString.replaceAllMapped(RegExp(r':\s*([A-Za-z ]+)([,\}])'),
        (match) => ':"${match[1]}"${match[2]}');

    // Step 3: Decode JSON
    return List<Map<String, dynamic>>.from(jsonDecode(jsonString));
  }

  static String capitalize(String text) {
    if (text.isEmpty) return text;
    return text[0].toUpperCase() + text.substring(1);
  }

  static num getUnitMultiplier(String? unit) {
    switch (unit?.toLowerCase()) {
      case "kg":
        return 1;
      case "gram":
        return 0.001;
      case "litre":
        return 1;
      case "ml":
        return 0.001;
      default:
        return 1; // default for items like pcs, box, etc.
    }
  }

  static String sanitizeUnit(String? unit, String quantityIn) {
    if (unit == null) return quantityIn;

    final u = unit.trim().toLowerCase();

    if (quantityIn == "kg") {
      return (u == "kg" || u == "gram") ? u : "kg";
    }

    if (quantityIn == "litre") {
      return (u == "litre" || u == "ml") ? u : "litre";
    }

    return quantityIn;
  }
}
