import 'package:vyaparlive/Organization/OrganizationFieldsData.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/privileges/Expenses_privileges.dart';
import 'package:vyaparlive/components/privileges/RetailSalesPrivileges.dart';
import 'package:vyaparlive/components/privileges/asset_management_privileges.dart';
import 'package:vyaparlive/components/privileges/product_consumption_privileges.dart';
import 'package:vyaparlive/components/privileges/reports_privileges.dart';
import 'package:vyaparlive/dao/LanguageDao.dart';
import 'package:vyaparlive/model/BuBasicDataModel.dart';
import 'package:vyaparlive/model/Contacts.dart';
import 'package:vyaparlive/model/InvitationFieldsData.dart';
import 'package:vyaparlive/model/BusinessUnitModel.dart';
import 'package:vyaparlive/model/TransactionsModel.dart';
import 'package:vyaparlive/components/privileges/bu_privileges.dart';
import 'package:vyaparlive/components/privileges/connection_privileges.dart';
import 'package:vyaparlive/components/privileges/inperson_order_privileges.dart';
import 'package:vyaparlive/components/privileges/invitation_privileges.dart';
import 'package:vyaparlive/components/privileges/product_privileges.dart';
import 'package:vyaparlive/components/privileges/subscription_prviliges.dart';
import 'package:vyaparlive/components/privileges/transaction_privileges.dart';
import 'package:vyaparlive/components/privileges/users_privileges.dart';
import 'package:vyaparlive/proto/Assets_management/Assets.messages.pbgrpc.dart';
import 'package:vyaparlive/proto/Invitation.messages.pbgrpc.dart';
import 'package:vyaparlive/proto/bu_list_transaction/transactions.messages.pbgrpc.dart';
import 'package:vyaparlive/proto/bu_proto/BU.messages.pbgrpc.dart';
import 'package:vyaparlive/proto/product_consumption/product_consumption.messages.pbgrpc.dart';
import 'package:vyaparlive/proto/product_proto/Products.messages.pbgrpc.dart';
import 'package:vyaparlive/proto/retail/retail.messages.pbgrpc.dart';
import 'package:vyaparlive/proto/services/services.messages.pbgrpc.dart';
import 'package:vyaparlive/proto/user/User.messages.pbgrpc.dart';
import 'package:vyaparlive/proto/version_controller/version_control.messages.pbgrpc.dart';
import 'package:vyaparlive/service/grpc_service.dart';

import '../model/bu_model/LocationsModel.dart';

class AppController {
  AppController._privateConstructor();
  static final AppController instance = AppController._privateConstructor();

  InvitationFieldsData? invitationFieldsData;
  OrganizationFieldsData? organizationFieldsData;
  Contacts? _contacts;
  BuBasicDataModel? buData;
  BusinessUnitModel? businessUnitModel;
  String? myBuId;
  bool isOrganizationCreate = false;
  bool isChildCreate = false;
  bool? isOrganizationUpdate = false;
  String? buName;
  String? currentOrgId;
  String? currentOrgName;
  String? sellerIdInDiscussion = "";
  List<BuBasicDataModel>? buList = [];
  TransactionsModel? _transactionData;
  List<String?> notificationsViewedList = [];
  String? fromDate;
  String? endDate;
  String? connectionName;
  String? transactionStatus;
  String? txnFilterOption;

  String? invitationName;
  String? inviterMobileNumber;
  String? invitationStatus;

  TransactionPrivileges? transactionPrivileges;
  ConnectionPrivileges? connectionPrivileges;
  ProductPrivileges? productPrivileges;
  SubscriptionPrivileges? subscriptionPrivileges;
  InPersonOrderPrivileges? inPersonOrderPrivileges;
  UserPrivileges? userPrivileges;
  InvitationPrivileges? invitationPrivileges;
  BuPrivileges? buPrivileges;
  String? authorizationKey;
  bool isShowCreateBuProgressDialog = false;
  InvitationServiceClient? _invitationGrpcClient;
  OrganizationServiceClient? _organizationServiceClient;
  ProductServiceClient? _productServiceClient;
  RetailerServiceClient? _retailerServiceClient;
  UserServiceClient? _userServiceClient;
  bool? isInpersonOrderAccept;
  String? loginUserRoleId;
  AssetsServiceClient? _assetsGrpcService;
  ServicesServiceClient? _servicesGrpcClient;
  ConsumableProductServiceClient? _consumableProductServiceClient;
  AppServiceClient? _versionCheckService;
  TransactionServiceClient? _transactionServiceClient;

  AssetManagementPrivileges? assetManagementPrivileges;
  ProductConsumptionPrivileges? productConsumptionPrivileges;
  String? orgCurrencySymbol;
  String? orgCountryCode;
  String? orgCountryDialCode;
  ReportsPrivileges? reportsPrivileges;
  RetailSalesPrivileges? retailSalesPrivileges;
  ExpensesPrivileges? expensesPrivileges;
  String? loginUserRoleName;

  List<LanguageDao> languageData = [];
  bool islanguageFileLoaded = false;
  String selectedLanguage = "en";

  List<Map>? tempStockReturnDicussionData;
  List<Map>? tempStockReturnProductsData;
  Map? tempStockReturPackingData;
  Map? tempStockReturnDeliveryData;
  Map? tempStockReturnReceivedData;
  Map? tempStockReturnReconiliationDicussionData;
  List<Map>? tempStockReceivedProducts;
  List<Locations> locationsList = [];
  String? buLogoImagePath;

  set setCreateBuProgress(bool isShowCreateBuProgressDialog) =>
      this.isShowCreateBuProgressDialog = isShowCreateBuProgressDialog;
  get getCreateBuProgress => this.isShowCreateBuProgressDialog;

  set setAuthorizationKey(String? authKey) => this.authorizationKey = authKey;
  get getAuthorizationKey => this.authorizationKey;

  set setTransactionPriviliges(TransactionPrivileges _tPriviliges) =>
      this.transactionPrivileges = _tPriviliges;
  get getTransactionPrivileges => this.transactionPrivileges;

  set setConnectionPrivileges(ConnectionPrivileges _cPrivileges) =>
      this.connectionPrivileges = _cPrivileges;
  get getConnectionPrivileges => this.connectionPrivileges;

  set setProductPrivileges(ProductPrivileges _pPrivileges) =>
      this.productPrivileges = _pPrivileges;
  get getProductPrivileges => this.productPrivileges;

  set setSubScriptionPrivileges(SubscriptionPrivileges _sPrivileges) =>
      this.subscriptionPrivileges = _sPrivileges;
  get getSubScriptionPrivileges => this.subscriptionPrivileges;

  set setInpersonOrderPrivileges(InPersonOrderPrivileges _iPrivileges) =>
      this.inPersonOrderPrivileges = _iPrivileges;
  get getInpersonOrderPrivileges => this.inPersonOrderPrivileges;

  set setUserPrivileges(UserPrivileges _uPrivileges) =>
      this.userPrivileges = _uPrivileges;
  get getUserPrivileges => this.userPrivileges;

  set setInvitationPrivileges(InvitationPrivileges _iPrivileges) =>
      this.invitationPrivileges = _iPrivileges;
  get getInvitationPrivileges => this.invitationPrivileges;

  set setBuPrivileges(BuPrivileges _bPrivileges) =>
      this.buPrivileges = _bPrivileges;
  get getBuPrivileges => this.buPrivileges;

  set setInvitationName(String invitationName) =>
      this.invitationName = invitationName;
  get getInvitationName => this.invitationName;

  set setInviterMobileNumber(String inviterMobileNumber) =>
      this.inviterMobileNumber = inviterMobileNumber;

  get getInviterMobileNumber => this.inviterMobileNumber = inviterMobileNumber;

  set setInvitationStatus(String? invitationStatus) => this.invitationStatus;
  get getInvitationStatus => this.invitationStatus;

  set setFromDate(String? fromDate) => this.fromDate = fromDate;
  get getFromDate => this.fromDate;
  set setToDate(String? toDate) => this.endDate = toDate;
  get getToDate => this.endDate;
  set setConnectionName(String? connectionName) =>
      this.connectionName = connectionName;
  get getConnectionName => this.connectionName;
  set setTransactionStatus(String? status) => this.transactionStatus = status;
  get getTransactionSatus => this.transactionStatus;

  set setTxnFilterOption(String? option) => txnFilterOption = option;

  get getTxnFilterOption => this.txnFilterOption;

  set setBuList(List<BuBasicDataModel> buList) {
    this.buList = buList;
  }

  get getBuList => this.buList;

  set setOrganizationFieldsData(OrganizationFieldsData data) =>
      organizationFieldsData = data;

  get getOrganizationFieldsData => this.organizationFieldsData;

  set setConnectionsData(Contacts data) => _contacts = data;

  get getConnectionsData => this._contacts;

  set setBuData(BuBasicDataModel data) => this.buData = data;

  get getBuData => this.buData;

  set setTransactionData(TransactionsModel data) => _transactionData = data;

  get getTransactionData => this._transactionData;

  set setBusinessUnitData(BusinessUnitModel data) => businessUnitModel = data;

  get getBusinessUnitData => this.businessUnitModel;

  set setIsOrgCreation(bool value) => this.isOrganizationCreate = value;
  get getIsOrganizationCretaion => this.isOrganizationCreate;
  set setIsChildCreate(bool value) => this.isChildCreate = value;
  get getIsChildCreate => this.isChildCreate;

  set setMyBuId(String? buId) {
    myBuId = buId;
  }

  get getMyBuId => this.myBuId;

  set setBuName(String? buName) {
    this.buName = buName;
  }

  get getBuName => this.buName;

  set setSellerId(String? sellerId) {
    this.sellerIdInDiscussion = sellerId;
  }

  get getSellerId => this.sellerIdInDiscussion;

  set saveCurrentOrgId(String? orgId) {
    this.currentOrgId = orgId;
  }

  get getCurrentOrgId => this.currentOrgId;

  set saveCurrentOrgName(String? orgName) {
    this.currentOrgName = orgName;
  }

  get getCurrentOrgName => this.currentOrgName;

  set setInvitationFieldsData(InvitationFieldsData data) =>
      invitationFieldsData = data;

  get getInvitationFieldsData => this.invitationFieldsData;

  set setViewednotification(String? notificationId) {
    notificationsViewedList.add(notificationId);
  }

  get viewedNotificationsList => this.notificationsViewedList;

  /// ConfirmationProducts page Socket variables
  String? cnfTransactionId;
  String? cnfType;
  String? cnfBuId;
  String? cnfMessage;
  String? userName;
  bool isFromConfirmationPage = false;

  set setCnfTransactionId(String? txnId) => this.cnfTransactionId = txnId;
  get getCnfTransactionId => this.cnfTransactionId;

  set setCnfType(String? type) => this.cnfType = type;
  get getCnfType => this.cnfType;

  set setCnfBuId(String? cnfbuId) => this.cnfBuId = cnfbuId;
  get getCnfBuId => this.cnfBuId;

  set setCnfMessage(String? cnfmessage) => this.cnfMessage = cnfmessage;
  get getCnfMessage => this.cnfMessage;

  set setCnfUserName(String? user) => this.userName = user;
  get getCnfUserName => this.userName;

  set setIsFromConfirmationPage(bool page) =>
      this.isFromConfirmationPage = page;
  get getIsFromConfirmationPage => this.isFromConfirmationPage;

  InvitationServiceClient? invitationGrpcClient() {
    if (_invitationGrpcClient == null) {
      print("CREATE INVITATION CLIENT");
      GRPCService _grpc = GRPCService(Constants.INVITATION_GRPC_URL,
          Constants.INVITATION_PORT as int); // 80);
      _invitationGrpcClient = InvitationServiceClient(_grpc.getChannel);
      return _invitationGrpcClient;
    } else {
      return _invitationGrpcClient;
    }
  }

  OrganizationServiceClient? organizationGrpcClient() {
    if (_organizationServiceClient == null) {
      GRPCService _grpc =
          GRPCService(Constants.BU_GRPC_URL, Constants.BU_PORT as int);
      _organizationServiceClient = OrganizationServiceClient(_grpc.getChannel);

      return _organizationServiceClient;
    } else {
      return _organizationServiceClient;
    }
  }

  ProductServiceClient? productGrpcClient() {
    if (_productServiceClient == null) {
      GRPCService _grpc = GRPCService(
          Constants.PRODUCT_GRPC_URL, Constants.PRODUCTS_PORT as int);
      _productServiceClient = ProductServiceClient(_grpc.getChannel);
      return _productServiceClient;
    } else {
      return _productServiceClient;
    }
  }

  RetailerServiceClient? retailGrpcClient() {
    if (_retailerServiceClient == null) {
      GRPCService _grpc = GRPCService(
          Constants.RETAIL_GRPC_URL, Constants.RETAILER_PORT as int);
      _retailerServiceClient = RetailerServiceClient(_grpc.getChannel);
      return _retailerServiceClient;
    } else {
      return _retailerServiceClient;
    }
  }

  UserServiceClient? userGrpcClient() {
    if (_userServiceClient == null) {
      GRPCService _grpc =
          GRPCService(Constants.USER_GRPC_URL, Constants.USER_PORT as int);
      _userServiceClient = UserServiceClient(_grpc.getChannel);
      return _userServiceClient;
    } else {
      return _userServiceClient;
    }
  }

  set setInpersonOrdeerAccept(bool? isAccept) =>
      this.isInpersonOrderAccept = isAccept;
  get getInpersonOrdeerAccept => this.isInpersonOrderAccept;

  set setLoginUserRoleId(String? roleId) => this.loginUserRoleId = roleId;
  get getLoginUserRoleId => this.loginUserRoleId;

  AssetsServiceClient? assetsManagementGrpcClient() {
    if (_assetsGrpcService == null) {
      GRPCService _grpc = GRPCService(Constants.ASSETS_MANAGEMENT_GRPC_URL, 80);
      _assetsGrpcService = AssetsServiceClient(_grpc.getChannel);
      return _assetsGrpcService;
    } else {
      return _assetsGrpcService;
    }
  }

  ServicesServiceClient? servicesGrpcClient() {
    if (_servicesGrpcClient == null) {
      GRPCService _grpc = GRPCService(Constants.SERVICES_GRPC_URL, 80);
      _servicesGrpcClient = ServicesServiceClient(_grpc.getChannel);
      return _servicesGrpcClient;
    } else {
      return _servicesGrpcClient;
    }
  }

  ConsumableProductServiceClient? consumableGrpcClient() {
    if (_consumableProductServiceClient == null) {
      GRPCService _grpc =
          GRPCService(Constants.CONSUMABLE_PRODUCTS_GRPC_URL, 80);
      _consumableProductServiceClient =
          ConsumableProductServiceClient(_grpc.getChannel);
      return _consumableProductServiceClient;
    } else {
      return _consumableProductServiceClient;
    }
  }

  TransactionServiceClient? transactionGrpcClient() {
    if (_transactionServiceClient == null) {
      GRPCService _grpc = GRPCService(
          Constants.BULIST_GRPC_URL, Constants.TRANSACTION_PORT as int);
      _transactionServiceClient = TransactionServiceClient(_grpc.getChannel);
      return _transactionServiceClient;
    } else {
      return _transactionServiceClient;
    }
  }

  AppServiceClient? appVersionCheckGrpcClient() {
    if (_versionCheckService == null) {
      GRPCService _grpc = GRPCService(Constants.APP_VERSION_CHECK_GRPC_URL, 80);
      _versionCheckService = AppServiceClient(_grpc.getChannel);
      return _versionCheckService;
    } else {
      return _versionCheckService;
    }
  }

  set setAssetManagementPrivileges(
          AssetManagementPrivileges _assetPrivileges) =>
      this.assetManagementPrivileges = _assetPrivileges;
  get getAssetManagementPrivileges => this.assetManagementPrivileges;

  set setProductConsumptionPrivileges(
          ProductConsumptionPrivileges _conumptionPrivileges) =>
      this.productConsumptionPrivileges = _conumptionPrivileges;
  get getProductConsumptionPrivileges => this.productConsumptionPrivileges;

  set setBuCurrencySymbol(String? currencySymbol) =>
      this.orgCurrencySymbol = currencySymbol;
  // get getBuCurrencySymbol => this.orgCurrencySymbol;

  String get getBuCurrencySymbol {
    if (orgCurrencySymbol == null ||
        orgCurrencySymbol!.trim().isEmpty ||
        orgCurrencySymbol == "-") {
      return "₹"; // default rupee symbol
    }
    return orgCurrencySymbol!;
  }

  set setBuCountryCode(String? countryCode) =>
      this.orgCountryCode = countryCode;
  get getBuCountryCode => this.orgCountryCode;
  set setBuCountryDialCode(String? dialCode) =>
      this.orgCountryDialCode = dialCode;
  get getBuCountryDialCode => this.orgCountryDialCode;

  set setReportsPrivileges(ReportsPrivileges _reportsPrivileges) =>
      this.reportsPrivileges = _reportsPrivileges;

  get getReportsPrivileges => this.reportsPrivileges;

  set setRetailSalesPrivileges(RetailSalesPrivileges _retailSalesPrivileges) =>
      this.retailSalesPrivileges = _retailSalesPrivileges;

  get getRetailSalesPrivileges => this.retailSalesPrivileges;

  set setExpensesPrivileges(ExpensesPrivileges _expensesPrivileges) =>
      this.expensesPrivileges = _expensesPrivileges;

  get getExpensesPrivileges => this.expensesPrivileges;

  set setLoginUserRole(String? name) => this.loginUserRoleName = name;
  get getLoginUserRole => this.loginUserRoleName;

  set setlanguageData(List<LanguageDao> languageList) =>
      this.languageData = languageList;
  get getLanguageData => this.languageData;

  set setIsLanguageFileLoaded(bool isLoaded) =>
      this.islanguageFileLoaded = isLoaded;
  get isLanguageFileLoaded => this.islanguageFileLoaded;

  set setSelectedLanguage(String language) => this.selectedLanguage = language;
  get getSelectedlanguage => this.selectedLanguage;
  set setTempStockReturnDiscussionData(List<Map> json) =>
      this.tempStockReturnDicussionData = json;
  get getTempStockReturnDiscussionData => this.tempStockReturnDicussionData;

  set setTempStockReturnProductsData(List<Map> json) =>
      this.tempStockReturnProductsData = json;
  get getTempStockReturnProductsData => this.tempStockReturnProductsData;

  set setTempStockReturnPackingData(Map json) =>
      this.tempStockReturPackingData = json;
  get getTempStockReturnPackingData => this.tempStockReturPackingData;

  set setTempStockReturnDeliveryData(Map json) =>
      this.tempStockReturnDeliveryData = json;
  get getTempStockReturnDeliveryData => this.tempStockReturnDeliveryData;

  set setTempStockReturnReceivedData(Map json) =>
      this.tempStockReturnReceivedData = json;
  get getTempStockReturnReceivedData => this.tempStockReturnReceivedData;

  set setTempStockReturnReconciliationDiscussionData(Map json) =>
      this.tempStockReturnReconiliationDicussionData = json;
  get getTempStockReturnReconciliationDiscussionData =>
      this.tempStockReturnReconiliationDicussionData;

  set setTempStockReceivedProductsData(List<Map> json) =>
      this.tempStockReceivedProducts = json;
  get getTempStockReceivedProductsData => this.tempStockReceivedProducts;
  set setLocations(List<Locations> _locations) {
    this.locationsList = _locations;
  }

  get getLocations => this.locationsList;

  set setBuLogoImagePath(String? imagePath) =>
      this.buLogoImagePath = imagePath!;
  get getBuLogoImagePath => this.buLogoImagePath;
}
