import 'dart:io';

import 'package:flutter/material.dart';

class ShowImageView extends StatelessWidget {
  ShowImageView({this.tagName, this.fileImage});
  final String? tagName;
  final File? fileImage;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
            backgroundColor: Colors.black12,
            title: Text(
              tagName!,
              style: TextStyle(fontSize: 14.0),
            )),
        body: GestureDetector(
            onTap: () {
              Navigator.pop(context);
            },
            child: Container(
                child: Center(
                    child: Hero(
              tag: tagName!,
              child: Image.file(fileImage!),
            )))));
  }
}
