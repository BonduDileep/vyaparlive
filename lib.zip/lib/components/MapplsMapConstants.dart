class MapplsMapConstants {
  static const String MAP_SDK_KEY = "31c42d5d76d8b52acca1240895ae3047";
  static const String MAP_CLIENT_ID =
      "96dHZVzsAutABCF3k2gFN2Xnp2Im-R4YSTlEKK9RKLr9bfXu9rrUflg6rY_BRIiiXXQPtcjpsm4B0MvvzXLG4Q==";
  static const String MAP_CLIENT_SECRET_KEY =
      "lrFxI-iSEg_DHCidH2fZvlW-85VD2KXitJKujU79oeMqI8PG2Vw80oR5zuR3HvaWYDTkevl4MYXO8rESAm3b4C2nrYTpsX_K";
}
