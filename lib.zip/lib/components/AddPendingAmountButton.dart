import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:vyaparlive/components/text_styles.dart';

import '../config/Language.dart';
import '../model/GRPCResponse.dart';
import '../service/retail_grpc_service.dart';
import 'AppController.dart';
import 'Constants.dart';
import 'Dialog.dart';

class AddPendingAmountButton extends StatelessWidget {
  final String buttonText;
  final String retailId;
  final String buId;
  final String selectedLang;
  final RetailGrpcService retailGrpcService;
  final Function(String field) onChange;
  final String? value;
  final num currentInvoiceAmount;
  final VoidCallback? onHistoryClick;
  final buttonTextColor;

  const AddPendingAmountButton(
      {Key? key,
      required this.buttonText,
      required this.onChange,
      this.value,
      required this.retailId,
      required this.buId,
      required this.selectedLang,
      required this.retailGrpcService,
      this.currentInvoiceAmount = 0.0,
      this.onHistoryClick,
      this.buttonTextColor})
      : super(key: key);

  Future<void> getpendingAmount(BuildContext context) async {
    Map data = {"buyerId": retailId, "sellerId": buId};

    String body = json.encode(data);
    var response = await retailGrpcService
        .getPendingInvoiceAmount(
            body, AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObject = json.decode(_grpcResponse.message!);
      num pendingAmount = resObject['pending_amount'];
      num invoiceAmount = resObject['InvoiceTotalAmount'];
      num paidAmount = resObject['invoicePaidAmount'];
      if (pendingAmount > 0)
        _showDialog(context, pendingAmount, invoiceAmount, paidAmount);
      else
        Dialogs.yesCancelDialog(
            context,
            Language().getString(Constants.INFO, selectedLang),
            "There is no pending amount.",
            Language().getString(Constants.OKAY_STR, selectedLang),
            "",
            false);
    } else {
      // print("${_grpcResponse.message}");
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.INFO, selectedLang),
          "There is no pending amount.",
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: InkWell(
        onTap: () => getpendingAmount(context),
        child: Text(buttonText,
            style: buttonTextColor != null
                ? CustomTextStyle.textButtonStyle(
                    color: buttonTextColor, decoration: TextDecoration.none)
                : CustomTextStyle.textButtonStyle()),
      ),
    );
  }

  renderPaymentCardRow(String label, String value, {bool canClick = false}) {
    return Row(children: [
      Expanded(
        flex: 3,
        child: Text(
          label,
          style: TextStyle(fontSize: 14, color: Colors.black),
        ),
      ),
      Expanded(
        child: InkWell(
          onTap: () {
            if (canClick) onHistoryClick!();
          },
          child: Row(
            children: [
              Text(
                ": $value",
                style: TextStyle(
                    fontSize: 14,
                    color: canClick ? Colors.blue : Colors.black,
                    decoration: canClick
                        ? TextDecoration.underline
                        : TextDecoration.none),
              ),
              if (canClick)
                SizedBox(
                  width: 5,
                ),
              if (canClick)
                Icon(
                  Icons.visibility,
                  color: Colors.blue,
                ),
            ],
          ),
        ),
      )
    ]);
  }

  void _showDialog(BuildContext context, num pendingAmount, num invoiceAmount,
      num paidAmount) {
    final TextEditingController fieldController =
        TextEditingController(text: '$currentInvoiceAmount');
    TextSelection.fromPosition(
        TextPosition(offset: fieldController.text.length));
    num amount = pendingAmount;

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(Language()
                      .getString(Constants.MAKE_PAYMENT, selectedLang)),
                  SizedBox(
                    height: 10,
                  ),
                  renderPaymentCardRow(
                      Language()
                          .getString("Previous Pending Amount", selectedLang),
                      "${amount - currentInvoiceAmount}",
                      canClick: true),
                  renderPaymentCardRow(
                      Language()
                          .getString("Current Invoice Amount", selectedLang),
                      "$currentInvoiceAmount"),
                  renderPaymentCardRow(
                      Language()
                          .getString("Total Pending Amount", selectedLang),
                      "$amount"),
                ],
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    keyboardType:
                        const TextInputType.numberWithOptions(decimal: true),
                    inputFormatters: [
                      FilteringTextInputFormatter.allow(
                          RegExp(r'^\d+\.?\d{0,2}')),
                    ],
                    controller: fieldController,
                    onChanged: (text) {
                      // if (text.isNotEmpty) {
                      //   setState(() {
                      //     amount = pendingAmount - num.parse(text);
                      //   });
                      // } else {
                      //   setState(() {
                      //     amount = pendingAmount;
                      //   });
                      // }
                    },
                    decoration: InputDecoration(
                        labelText: Language()
                            .getString(Constants.AMOUNT, selectedLang)),
                  ),
                ],
              ),
              actions: [
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(Constants.APP_COLOR),
                  ),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: Text(
                      Language().getString(Constants.STR_CANCEL, selectedLang)),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(Constants.APP_COLOR),
                  ),
                  onPressed: () {
                    final field = fieldController.text;
                    if (field.isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                            backgroundColor: Colors.red,
                            content: Text(
                              Language().getString(
                                  "Please enter Amount.", selectedLang),
                              textAlign: TextAlign.center,
                            )),
                      );
                      return;
                    }

                    if (num.parse(field) > currentInvoiceAmount) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                            backgroundColor: Colors.red,
                            content: Text(
                              Language().getString(
                                  "Please enter valid Amount.", selectedLang),
                              textAlign: TextAlign.center,
                            )),
                      );
                      return;
                    }

                    onChange(field);
                    Navigator.of(context).pop();
                  },
                  child: Text(Language()
                      .getString(Constants.STR_COLLECT, selectedLang)),
                ),
              ],
            );
          },
        );
      },
    );
  }
}
