// import 'package:dio/dio.dart';
// import 'package:flutter/material.dart';
// import 'package:google_places_flutter/DioErrorHandler.dart';
// import 'package:google_places_flutter/model/prediction.dart';

// import '../../Organization/component/PlaceDetails.dart';
// import '../../config/Language.dart';
// import '../AppUtills.dart';
// import '../Constants.dart';
// import '../StyleView.dart';
// import '../common_methods.dart';

// class SearchGeoLocation extends StatelessWidget {
//   final String? selectedLang;
//   final Dio _dio = Dio();

//   SearchGeoLocation({Key? key, this.selectedLang}) : super(key: key);
//   @override
//   Widget build(BuildContext context) {
//     return TextButton.icon(
//       icon: Icon(Icons.my_location_rounded, size: 18),
//       onPressed: () {
//         CommonMethods.hideKeyboard(context);
//         searchLocationFromMap(context);
//       },
//       label: Text(
//         Language()
//             .getString(Constants.SEARCH_LOCATION_FROM_DIRECTORY, selectedLang),
//         style: TextStyle(
//             decoration: TextDecoration.underline,
//             color: Colors.blue,
//             fontSize: 15,
//             fontWeight: StyleView.fontSemiBold),
//       ),
//     );
//   }

//   searchLocationFromMap(BuildContext context) {
//     TextEditingController searchLocation = new TextEditingController();
//     List<Prediction> _elocation = [];
//     return showDialog(
//         barrierColor: Colors.black54,
//         context: context,
//         builder: (context) =>
//             StatefulBuilder(builder: (context, StateSetter setState) {
//               return Container(
//                 margin: EdgeInsets.symmetric(
//                     vertical: MediaQuery.of(context).size.height * 0.05,
//                     horizontal: MediaQuery.of(context).size.width * 0.05),
//                 decoration: BoxDecoration(
//                     borderRadius: BorderRadius.circular(5.0),
//                     color: Colors.white),
//                 child: Padding(
//                   padding: const EdgeInsets.all(8.0),
//                   child: Scaffold(
//                     backgroundColor: Colors.transparent,
//                     body: Padding(
//                       padding:
//                           const EdgeInsets.only(top: 10.0, left: 12, right: 12),
//                       child: Column(
//                         children: [
//                           Container(
//                               height: 50,
//                               decoration: AppUtills.boxDecoration(
//                                   customBorderColor: Colors.black),
//                               margin: EdgeInsets.symmetric(vertical: 3.0),
//                               child: Row(
//                                 children: [
//                                   Expanded(
//                                     child: Container(
//                                       child: new TextFormField(
//                                           style: TextStyle(
//                                               fontFamily: StyleView.FONT_TITLE),
//                                           controller: searchLocation,
//                                           textInputAction: TextInputAction.done,
//                                           decoration: InputDecoration(
//                                               contentPadding:
//                                                   EdgeInsets.only(left: 8),
//                                               border: InputBorder.none,
//                                               hintText: Language().getString(
//                                                   Constants.SEARCH_PLACES,
//                                                   selectedLang),
//                                               hintStyle: TextStyle(
//                                                   color: Colors.grey,
//                                                   fontWeight:
//                                                       StyleView.fontMedium)),
//                                           onChanged: (text) {
//                                             if (text.trim().isEmpty) {
//                                               _elocation.clear();
//                                             }

//                                             setState(() {});
//                                             getLocation(text.trim(), setState);
//                                           }),
//                                     ),
//                                   ),
//                                   IconButton(
//                                       onPressed: () => {
//                                             setState(() {
//                                               _elocation.clear();
//                                             }),
//                                             if (searchLocation.text.isNotEmpty)
//                                               {searchLocation.clear()}
//                                             else
//                                               {
//                                                 Navigator.of(context).pop(),
//                                               }
//                                           },
//                                       icon: Icon(
//                                         Icons.close,
//                                         color: Colors.red,
//                                       ))
//                                 ],
//                               )),
//                           renderSuggestions()
//                         ],
//                       ),
//                     ),
//                   ),
//                 ),
//               );
//             }));
//   }

//   renderSuggestions(List<Prediction> locationList) {
//     return Container(
//       child: locationList.length > 0
//           ? Expanded(
//               child: Container(
//                   margin: EdgeInsets.only(top: 16),
//                   decoration: const BoxDecoration(color: Colors.white),
//                   child: ListView.builder(
//                       itemCount: locationList.length,
//                       itemBuilder: (context, index) {
//                         return ListTile(
//                           contentPadding: const EdgeInsets.all(12),
//                           focusColor: Colors.white,
//                           title: Text(locationList[index].description ?? ''),
//                           subtitle: Text(locationList[index].description ?? '',
//                               maxLines: 2),
//                           onTap: () {
//                             CommonMethods.hideKeyboard(context);
//                             getPlaceDetailsFromPlaceId(locationList[index]);
//                           },
//                         );
//                       })),
//             )
//           : Container(),
//     );
//   }

//   Future<void> getPlaceDetailsFromPlaceId(Prediction prediction) async {
//     var url =
//         "${Constants.NEW_BASE_URL}lookup/places/placeDetails?placeid=${prediction.placeId}";
//     try {
//       Response response = await _dio.get(url);

//       Map data = response.data;
//       PlaceDetails placeDetails = PlaceDetails.fromJson(data["data"]);

//       prediction.lat = placeDetails.result!.geometry!.location!.lat.toString();
//       prediction.lng = placeDetails.result!.geometry!.location!.lng.toString();

//       // latitude = double.parse(prediction.lat!);
//       // longitude = double.parse(prediction.lng!);

// //send data to callback
//       // updateSelectedLocation_geo(placeDetails, prediction);
//     } catch (e) {
//       var errorHandler = ErrorHandler.internal().handleError(e);
//     }
//   }

//   getLocation(String text, StateSetter setState) async {
//     String apiURL = "${Constants.NEW_BASE_URL}lookup/places?input=${text}";
//     try {
//       Response response = await _dio.get(apiURL);
//       Map map = response.data;
//       // print("data of geocode: ${map.toString()}");

//       PlacesAutocompleteResponse subscriptionResponse =
//           PlacesAutocompleteResponse.fromJson(map["data"]);

//       if (subscriptionResponse.predictions != null &&
//           subscriptionResponse.predictions!.length > 0) {
//         setState(() {
//           _elocation = subscriptionResponse.predictions!;
//         });
//         // getPlaceDetailsFromPlaceId(subscriptionResponse.predictions![0]);
//       }
//       if (map.containsKey("error_message")) {
//         throw response.data;
//       }
//     } catch (e) {
//       var errorHandler = ErrorHandler.internal().handleError(e);
//     }
//   }
// }

// mixin _elocation {
// }
