import 'package:flutter/cupertino.dart';
import 'package:vyaparlive/invoice_view/InvoiceDesingView.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';

class CommonNavigation {
  static navigationToInvoiceDesign(
      BuildContext context,
      String? transactionName,
      String? transactionId,
      String? transactionDate,
      String invoiceNo,
      String? invoiceId) {
    Navigator.push(
      context,
      PageTransition(
        context: context,
        page: InvoiceDesingPage(
          invoiceNo: invoiceNo,
          invoiceId: invoiceId,
          transactionName: transactionName,
          transactionId: transactionId,
          transactionDate: transactionDate,
        ),
      ),
    );
  }
}
