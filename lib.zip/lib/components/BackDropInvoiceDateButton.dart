import 'package:flutter/material.dart';

import './text_styles.dart';
import 'AppUtills.dart';
import 'common_methods.dart';

class BackDropInvoiceDateButton extends StatelessWidget {
  final String buttonText;
  final String selectedLang;
  final Function(String date) onSelected;

  const BackDropInvoiceDateButton(
      {Key? key,
      required this.buttonText,
      required this.onSelected,
      required this.selectedLang})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.centerLeft,
      child: InkWell(
        onTap: () async {
          CommonMethods.hideKeyboard(context);
          String selectedDate =
              await AppUtills.getSelectedDate(context, isShowTodayDate:true);
          onSelected(selectedDate);
        },
        child: Text(buttonText, style: CustomTextStyle.textButtonStyle()),
      ),
    );
  }
}
