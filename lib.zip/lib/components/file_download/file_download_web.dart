import 'dart:convert';

import 'dart:html' as html;
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import '../AppController.dart';
import '../Constants.dart';
import '../Dialog.dart';
import '../common_methods.dart';

Future<String> downloadReports(
    {BuildContext? context,
    required String url,
    Map? mapData,
    String? fileName}) async {
  String requiredFilepath = "";
  var response = await http
      .post(Uri.parse(url), body: utf8.encode(json.encode(mapData)), headers: {
    'Content-Type': "application/json; charset=UTF-8",
    "authorization": AppController.instance.getAuthorizationKey
  });
  if (response.statusCode == 200) {
    var bytes = response.bodyBytes;
    try {
      requiredFilepath = "downloaded";

      if (kIsWeb) {
        final content = base64Encode(bytes);
        final anchor = html.AnchorElement(
            href: 'data:application/octet-stream;base64,$content')
          ..target = 'blank';
        anchor.download = '$fileName.xlsx';
        html.document.body!.append(anchor);
        anchor.click();
        anchor.remove();
      } else if (Platform.isAndroid || Platform.isIOS) {
        // Save using path_provider + dio or file write
        final dir = await getApplicationDocumentsDirectory();
        requiredFilepath = "${dir.path}/$fileName.xlsx";
        File(requiredFilepath).writeAsBytesSync(bytes);
        return requiredFilepath;
      }
    } catch (e) {
      print("DOWNLOAD REPORTS EXCEPTION : " + e.toString());
    }
  } else if (response.statusCode == 401) {
    CommonMethods.handleUnauthorizedAccess(context!);
  } else {
    Dialogs.yesCancelDialog(
        context!, Constants.ERROR, "response", Constants.OKAY_STR, "", false);
  }

  return requiredFilepath;
}
