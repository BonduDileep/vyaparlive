import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../AppController.dart';
import '../Constants.dart';
import '../Dialog.dart';
import '../common_methods.dart';

Future<String> downloadReports(
      {BuildContext? context,
      required String url,
      Map? mapData,
      String? fileName}) async {
    String requiredFilepath = "";
    HttpClient httpClient = new HttpClient();
    File file;
    String filePath = '';
    HttpClientRequest request = await httpClient.postUrl(Uri.parse(url));
    request.headers
        .set(HttpHeaders.contentTypeHeader, "application/json; charset=UTF-8");
    request.headers.set(HttpHeaders.authorizationHeader,
        AppController.instance.getAuthorizationKey);
    request.add(utf8.encode(json.encode(mapData)));
    HttpClientResponse response = await request.close();
    try {
      if (response.statusCode == 200) {
        var bytes = await consolidateHttpClientResponseBytes(response);
        try {
          filePath = '/storage/emulated/0/Download/$fileName.xlsx';
          file = File(filePath);
          file.writeAsBytes(bytes);
          requiredFilepath = file.absolute.path;
        } catch (e) {
          print("DOWNLOAD REPORTS EXCEPTION : " + e.toString());
        }
      } else if (response.statusCode == 401) {
        CommonMethods.handleUnauthorizedAccess(context!);
      } else {
        Dialogs.yesCancelDialog(context!, Constants.ERROR, "response",
            Constants.OKAY_STR, "", false);
      }
    } catch (e) {
      print(e);
    }

    return requiredFilepath;
  }