export 'file_download_web.dart'
    if (dart.library.io) 'file_download_mobile.dart';  // Mobile implementation