class Previlage {
  static Map permissions = {
    "BU_VIEW": {"WRITE": true, "READ": true},
    "BU_CREATE": {"WRITE": false, "READ": false},
    "BU_EDIT": {"WRITE": false, "READ": false},
    "BU_DELETE": {"WRITE": false, "READ": false},
    "BU_ROLES_VIEW": {"WRITE": false, "READ": false},
    "BU_ROLES_CREATE": {"WRITE": false, "READ": false},
    "PRODUCT_ADD": {"WRITE": false, "READ": false},
    "PRODUCT_EDIT": {"WRITE": false, "READ": false},
    "PRODUCT_DELETE": {"WRITE": false, "READ": false},
    "INVITATION_CREATE": {"WRITE": false, "READ": false},
    "INVITATION_VIEW": {"WRITE": false, "READ": false},
    "INVITATION_ACCEPT": {"WRITE": false, "READ": false},
    "INVITATION_REJECT": {"WRITE": false, "READ": false},
    "CONNECTION_VIEW": {"WRITE": false, "READ": false},
    "CONNECTION_REJECT": {"WRITE": false, "READ": false},
    "CONNECTION_PRODUCTS_VIEW": {"WRITE": false, "READ": false},
    "CONNECTION_DETAILS_VIEW": {"WRITE": false, "READ": false},
    "CONNECTION_START_DISCUSSION": {"WRITE": false, "READ": false},
    "CONNECTION_TRANSACTION": {"WRITE": false, "READ": false},
    "CONNECTION_PLACE_ORDER": {"WRITE": false, "READ": false},
    "USER_VIEW": {"WRITE": false, "READ": false},
    "USER_CREATION": {"WRITE": false, "READ": false},
    "USER_EDIT": {"WRITE": false, "READ": false},
    "USER_DELETE": {"WRITE": false, "READ": false},
    "BU_ROLE_VIEW": {"WRITE": false, "READ": false},
    "BU_ROLE_EDIT": {"WRITE": false, "READ": false},
    "BU_ROLE_DELETE": {"WRITE": false, "READ": false},
    "BU_ROLE_CREATE": {"WRITE": false, "READ": false},
    "BU_LOCATION_CREATE": {"WRITE": false, "READ": false},
    "BU_LOCATION_VIEW": {"WRITE": false, "READ": false},
    "BU_LOCATION_EDIT": {"WRITE": false, "READ": false},
    "BU_LOCATION_DELETE": {"WRITE": false, "READ": false},
    "BU_PRODUCT_VIEW": {"WRITE": false, "READ": false},
    "BU_PRODUCT_OFFER_VIEW": {"WRITE": false, "READ": false},
    "BU_PACKAGE_VIEW": {"WRITE": false, "READ": false},
    "PRODUCT_VIEW": {"WRITE": false, "READ": false},
    "PRODUCT_TRANSACTION": {"WRITE": false, "READ": false},
    "PRODUCT_LOCATION_EDIT": {"WRITE": false, "READ": false},
    "PRODUCT_OFFER_CREATE": {"WRITE": false, "READ": false},
    "PRODUCT_OFFER_EDIT": {"WRITE": false, "READ": false},
    "PRODUCT_OFFER_DELETE": {"WRITE": false, "READ": false},
    "PACKAGE_OFFER_CREATE": {"WRITE": false, "READ": false},
    "PACKAGE_OFFER_EDIT": {"WRITE": false, "READ": false},
    "PACKAGE_OFFER_DELETE": {"WRITE": false, "READ": false},
  };

  void setPermissions(String? code) {
    switch (code) {
      case 'add_product':
        permissions['PRODUCT_ADD']['WRITE'] = true;
        permissions['PRODUCT_ADD']['READ'] = true;
        break;

      case 'edit_product':
        permissions['PRODUCT_EDIT']['WRITE'] = true;
        permissions['PRODUCT_EDIT']['READ'] = true;
        break;

      case 'edit_bu':
        permissions['BU_EDIT']['WRITE'] = true;
        permissions['BU_EDIT']['READ'] = true;
        break;

      case 'delete_bu':
        permissions['BU_DELETE']['WRITE'] = true;
        permissions['BU_DELETE']['READ'] = true;
        break;

      case 'add_bu':
        permissions['BU_CREATE']['WRITE'] = true;
        permissions['BU_CREATE']['READ'] = true;
        break;

      case 'delete_product':
        permissions['PRODUCT_DELETE']['WRITE'] = true;
        permissions['PRODUCT_DELETE']['READ'] = true;
        break;

      case 'invitation_create':
        permissions['INVITATION_CREATE']['WRITE'] = true;
        permissions['INVITATION_CREATE']['READ'] = true;
        break;

      case 'invitation_view':
        permissions['INVITATION_VIEW']['WRITE'] = true;
        permissions['INVITATION_VIEW']['READ'] = true;
        break;

      case 'invitation_accept':
        permissions['INVITATION_ACCEPT']['WRITE'] = true;
        permissions['INVITATION_ACCEPT']['READ'] = true;
        break;

      case 'invitation_reject':
        permissions['INVITATION_REJECT']['WRITE'] = true;
        permissions['INVITATION_REJECT']['READ'] = true;
        break;

      case 'connection_view':
        permissions['CONNECTION_VIEW']['WRITE'] = true;
        permissions['CONNECTION_VIEW']['READ'] = true;
        break;

      case 'connection_reject':
        permissions['CONNECTION_REJECT']['WRITE'] = true;
        permissions['CONNECTION_REJECT']['READ'] = true;
        break;

      case 'connection_product_view':
        permissions['CONNECTION_PRODUCTS_VIEW']['WRITE'] = true;
        permissions['CONNECTION_PRODUCTS_VIEW']['READ'] = true;
        break;

      case 'connection_details_view':
        permissions['CONNECTION_DETAILS_VIEW']['WRITE'] = true;
        permissions['CONNECTION_DETAILS_VIEW']['READ'] = true;
        break;

      case 'connection_start_discussion':
        permissions['CONNECTION_START_DISCUSSION']['WRITE'] = true;
        permissions['CONNECTION_START_DISCUSSION']['READ'] = true;
        break;

      case 'connection_place_order':
        permissions['CONNECTION_PLACE_ORDER']['WRITE'] = true;
        permissions['CONNECTION_PLACE_ORDER']['READ'] = true;
        break;

      case 'user_view':
        permissions['USER_VIEW']['WRITE'] = true;
        permissions['USER_VIEW']['READ'] = true;
        break;

      case 'user_creation':
        permissions['USER_CREATION']['WRITE'] = true;
        permissions['USER_CREATION']['READ'] = true;
        break;

      case 'user_edit':
        permissions['USER_EDIT']['WRITE'] = true;
        permissions['USER_EDIT']['READ'] = true;
        break;

      case 'user_delete':
        permissions['USER_DELETE']['WRITE'] = true;
        permissions['USER_DELETE']['READ'] = true;
        break;

      case 'bu_role_view':
        permissions['BU_ROLE_VIEW']['WRITE'] = true;
        permissions['BU_ROLE_VIEW']['READ'] = true;
        break;

      case 'bu_role_edit':
        permissions['BU_ROLE_EDIT']['WRITE'] = true;
        permissions['BU_ROLE_EDIT']['READ'] = true;
        break;

      case 'bu_role_delete':
        permissions['BU_ROLE_DELETE']['WRITE'] = true;
        permissions['BU_ROLE_DELETE']['READ'] = true;
        break;

      case 'bu_role_create':
        permissions['BU_ROLE_CREATE']['WRITE'] = true;
        permissions['BU_ROLE_CREATE']['READ'] = true;
        break;

      case 'bu_location_create':
        permissions['BU_LOCATION_CREATE']['WRITE'] = true;
        permissions['BU_LOCATION_CREATE']['READ'] = true;
        break;

      case 'bu_location_view':
        permissions['BU_LOCATION_VIEW']['WRITE'] = true;
        permissions['BU_LOCATION_VIEW']['READ'] = true;
        break;

      case 'bu_location_edit':
        permissions['BU_LOCATION_EDIT']['WRITE'] = true;
        permissions['BU_LOCATION_EDIT']['READ'] = true;
        break;

      case 'bu_location_delete':
        permissions['BU_LOCATION_DELETE']['WRITE'] = true;
        permissions['BU_LOCATION_DELETE']['READ'] = true;
        break;

      case 'bu_product_view':
        permissions['BU_PRODUCT_VIEW']['WRITE'] = true;
        permissions['BU_PRODUCT_VIEW']['READ'] = true;
        break;

      case 'bu_product_offer_view':
        permissions['BU_PRODUCT_OFFER_VIEW']['WRITE'] = true;
        permissions['BU_PRODUCT_OFFER_VIEW']['READ'] = true;
        break;

      case 'bu_package_view':
        permissions['BU_PACKAGE_VIEW']['WRITE'] = true;
        permissions['BU_PACKAGE_VIEW']['READ'] = true;
        break;

      case 'products_view':
        permissions['PRODUCT_VIEW']['WRITE'] = true;
        permissions['PRODUCT_VIEW']['READ'] = true;
        break;

      case 'product_transaction':
        permissions['PRODUCT_TRANSACTION']['WRITE'] = true;
        permissions['PRODUCT_TRANSACTION']['READ'] = true;
        break;

      case 'product_location_edit':
        permissions['PRODUCT_LOCATION_EDIT']['WRITE'] = true;
        permissions['PRODUCT_LOCATION_EDIT']['READ'] = true;
        break;

      case 'product_offer_create':
        permissions['PRODUCT_OFFER_CREATE']['WRITE'] = true;
        permissions['PRODUCT_OFFER_CREATE']['READ'] = true;
        break;

      case 'product_offer_edit':
        permissions['PRODUCT_OFFER_EDIT']['WRITE'] = true;
        permissions['PRODUCT_OFFER_EDIT']['READ'] = true;
        break;

      case 'product_offer_delete':
        permissions['PRODUCT_OFFER_DELETE']['WRITE'] = true;
        permissions['PRODUCT_OFFER_DELETE']['READ'] = true;
        break;

      case 'package_offer_create':
        permissions['PACKAGE_OFFER_CREATE']['WRITE'] = true;
        permissions['PACKAGE_OFFER_CREATE']['READ'] = true;
        break;

      case 'package_offer_edit':
        permissions['PACKAGE_OFFER_EDIT']['WRITE'] = true;
        permissions['PACKAGE_OFFER_EDIT']['READ'] = true;
        break;

      case 'package_offer_delete':
        permissions['PACKAGE_OFFER_DELETE']['WRITE'] = true;
        permissions['PACKAGE_OFFER_DELETE']['READ'] = true;
        break;

      default:
    }
  }

  void setAllPermissions() {
    permissions = {
      "BU_VIEW": {"WRITE": true, "READ": true},
      "BU_CREATE": {"WRITE": true, "READ": true},
      "BU_EDIT": {"WRITE": true, "READ": true},
      "BU_DELETE": {"WRITE": true, "READ": true},
      "BU_ROLES_VIEW": {"WRITE": true, "READ": true},
      "BU_ROLES_CREATE": {"WRITE": true, "READ": true},
      "PRODUCT_ADD": {"WRITE": true, "READ": true},
      "PRODUCT_EDIT": {"WRITE": true, "READ": true},
      "PRODUCT_DELETE": {"WRITE": true, "READ": true},
      "INVITATION_CREATE": {"WRITE": true, "READ": true},
      "INVITATION_VIEW": {"WRITE": true, "READ": true},
      "INVITATION_ACCEPT": {"WRITE": true, "READ": true},
      "INVITATION_REJECT": {"WRITE": true, "READ": true},
      "CONNECTION_VIEW": {"WRITE": true, "READ": true},
      "CONNECTION_REJECT": {"WRITE": true, "READ": true},
      "CONNECTION_PRODUCTS_VIEW": {"WRITE": true, "READ": true},
      "CONNECTION_DETAILS_VIEW": {"WRITE": true, "READ": true},
      "CONNECTION_START_DISCUSSION": {"WRITE": true, "READ": true},
      "CONNECTION_PLACE_ORDER": {"WRITE": true, "READ": true},
      "USER_VIEW": {"WRITE": true, "READ": true},
      "USER_CREATION": {"WRITE": true, "READ": true},
      "USER_EDIT": {"WRITE": true, "READ": true},
      "USER_DELETE": {"WRITE": true, "READ": true},
      "BU_ROLE_VIEW": {"WRITE": true, "READ": true},
      "BU_ROLE_EDIT": {"WRITE": true, "READ": true},
      "BU_ROLE_DELETE": {"WRITE": true, "READ": true},
      "BU_ROLE_CREATE": {"WRITE": true, "READ": true},
      "BU_LOCATION_CREATE": {"WRITE": true, "READ": true},
      "BU_LOCATION_VIEW": {"WRITE": true, "READ": true},
      "BU_LOCATION_EDIT": {"WRITE": true, "READ": true},
      "BU_LOCATION_DELETE": {"WRITE": true, "READ": true},
      "BU_PRODUCT_VIEW": {"WRITE": true, "READ": true},
      "BU_PRODUCT_OFFER_VIEW": {"WRITE": true, "READ": true},
      "BU_PACKAGE_VIEW": {"WRITE": true, "READ": true},
      "PRODUCT_VIEW": {"WRITE": true, "READ": true},
      "PRODUCT_TRANSACTION": {"WRITE": true, "READ": true},
      "PRODUCT_LOCATION_EDIT": {"WRITE": true, "READ": true},
      "PRODUCT_OFFER_CREATE": {"WRITE": true, "READ": true},
      "PRODUCT_OFFER_EDIT": {"WRITE": true, "READ": true},
      "PRODUCT_OFFER_DELETE": {"WRITE": true, "READ": true},
      "PACKAGE_OFFER_CREATE": {"WRITE": true, "READ": true},
      "PACKAGE_OFFER_EDIT": {"WRITE": true, "READ": true},
      "PACKAGE_OFFER_DELETE": {"WRITE": true, "READ": true},
    };
  }
}

class PermissionObj {
  String? id;
  String? name;
  String? code;
  String? feature_group;
  String? description;

  PermissionObj(
      {this.id, this.name, this.code, this.feature_group, this.description});

  factory PermissionObj.fromJson(Map<String, dynamic> json) => PermissionObj(
        id: json.containsKey("id") ? json['id'] : "",
        name: json.containsKey("name") ? json['name'] : "",
        code: json.containsKey("code") ? json['code'] : "",
        feature_group:
            json.containsKey("feature_group") ? json['feature_group'] : "",
        description: json.containsKey("description") ? json['description'] : "",
      );
}
