import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:vyaparlive/components/AppUtills.dart';

class TransactionDetailsViewPage extends StatelessWidget {
  final String? transactionName;
  final String? transactionId;
  final String? transactionDate;
  final List<Map> namesData;
  TransactionDetailsViewPage(
      {this.transactionId,
      this.transactionDate,
      this.transactionName,
      required this.namesData});
  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      color: Colors.white,
      shadowColor: AppTheme.theme.colorScheme.primary, //Colors.white,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(5),
          side: BorderSide(color: AppTheme.theme.colorScheme.primaryContainer)),
      child: Padding(
        padding: EdgeInsets.all(8.0),
        child: (namesData.length > 0)
            ? Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                    this.cardView(namesData[0]['name'], transactionName),
                    this.cardView(namesData[1]['name'], transactionId),
                    this.cardView(namesData[2]['name'],
                        AppUtills.getDateFormate(transactionDate))
                  ])
            : Container(),
      ),
    );
  }

  cardView(String title, String? value) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 3.0),
      child: Row(children: <Widget>[
        Expanded(
          child: Text(title,
              style: TextStyle(
                  fontWeight: StyleView.fontSemiBold, color: Colors.black)),
        ),
        Text(":   "),
        Expanded(
            flex: 2,
            child: Text("$value",
                style: TextStyle(
                    fontSize: 12.5,
                    fontWeight: StyleView.fontMedium,
                    color: Colors.black))),
      ]),
    );
  }

  bool isDateUtc(String date) {
    if (DateTime.parse(date).isUtc) {
      return true;
    } else {
      return false;
    }
  }
}
