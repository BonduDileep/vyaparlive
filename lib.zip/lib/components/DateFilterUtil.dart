import 'package:vyaparlive/components/StyleView.dart';
import 'package:flutter/material.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';

class DateFilterUtill extends StatelessWidget {
  final Function(String)? onFromDateSelected;
  final Function(String)? onToDateSelected;
  final VoidCallback? onSearchParms;
  final String? fromDate;
  final String? toDate;
  final VoidCallback? searchFilters;
  final bool isFromRawAndFinishReports;
  final TextEditingController? fromDateController;
  final TextEditingController? toDateController;
  final bool? isShowSearchButton;
  DateFilterUtill(
      {this.onFromDateSelected,
      this.onToDateSelected,
      this.onSearchParms,
      this.fromDate,
      this.toDate,
      this.searchFilters,
      this.isFromRawAndFinishReports = false,
      this.fromDateController,
      this.toDateController,
      this.isShowSearchButton = false});
  @override
  Widget build(BuildContext context) {
    return Container(
      // margin: EdgeInsets.symmetric(vertical: 5.0),
      decoration: BoxDecoration(
          // color: Colors.grey,
          border: Border.all(
            color: Colors.grey,
          ),
          borderRadius: BorderRadius.circular(5.0)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
              child: Container(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(5.0),
                            bottomLeft: Radius.circular(5.0))),
                    height: 40,
                    alignment: Alignment.centerLeft,
                    child: Padding(
                      padding: const EdgeInsets.all(5.0),
                      child: TextField(
                        controller: fromDateController,
                        enabled: false,
                        style: TextStyle(
                            fontWeight: StyleView.fontRegular,
                            color: Colors.black),
                        decoration: InputDecoration(
                            hintStyle: TextStyle(
                                fontWeight: StyleView.fontRegular,
                                color: Colors.black,
                                fontSize: 14.0),
                            hintText: Constants.FROM_DATE_STRING,
                            border: InputBorder.none,
                            contentPadding: EdgeInsets.only(
                                bottom: 15.0, left: 5, right: 0)),
                      ),
                    ),
                  ),
                ),
                Container(
                  height: 40,
                  width: 30,
                  color: Colors.white,
                  child: IconButton(
                      padding: EdgeInsets.only(left: 0, right: 5),
                      icon: Icon(
                        Icons.calendar_today,
                        color: Color(Constants.APP_COLOR),
                      ),
                      onPressed: () async {
                        String value = await AppUtills.getSelectedDate(context,
                            isShowTodayDate: true);
                        this.onFromDateSelected!(value);
                      }),
                ),
              ],
            ),
          )),
          SizedBox(
            height: 40,
            width: 1.0,
            child: Container(
              color: Colors.grey,
            ),
          ),
          Expanded(
              child: Container(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Container(
                    alignment: Alignment.centerLeft,
                    height: 40,
                    color: Colors.white,
                    child: Padding(
                      padding: const EdgeInsets.all(5.0),
                      child: TextField(
                        enabled: false,
                        style: TextStyle(
                            fontWeight: StyleView.fontRegular,
                            color: Colors.black),
                        controller: toDateController,
                        decoration: InputDecoration(
                            hintStyle: TextStyle(
                                fontWeight: StyleView.fontRegular,
                                color: Colors.black,
                                fontSize: 14.0),
                            hintText: Constants.TODATE_STRING,
                            border: InputBorder.none,
                            contentPadding:
                                EdgeInsets.only(bottom: 15.0, left: 5)),
                      ),
                    ),
                  ),
                ),
                Container(
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                            topRight: Radius.circular(5.0),
                            bottomRight: Radius.circular(5.0))),
                    height: 40,
                    width: 30,
                    child: IconButton(
                        padding: EdgeInsets.only(left: 0, right: 5),
                        icon: Icon(
                          Icons.calendar_today,
                          color: Color(Constants.APP_COLOR),
                        ),
                        onPressed: () async {
                          String value = await AppUtills.getSelectedDate(
                              context,
                              isShowTodayDate: true);
                          this.onToDateSelected!(value);
                        })),
              ],
            ),
          )),
          if (isShowSearchButton!)
            SizedBox(
              height: 40,
              width: 1.0,
              child: Container(
                color: Colors.grey,
              ),
            ),
          if (isShowSearchButton!)
            Container(
              height: 40,
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                      topRight: Radius.circular(5.0),
                      bottomRight: Radius.circular(5.0))),
              child: IconButton(
                  icon: Icon(Icons.search),
                  onPressed: () {
                    bool isInvalidDate = CommonMethods.dateRangeValidation(
                        startDate: fromDateController!.text,
                        endDate: toDateController!.text);

                    if (isInvalidDate) {
                      Dialogs.yesCancelDialog(
                          context,
                          Constants.ERROR,
                          Constants.DATE_RANGE_VALIDATION,
                          Constants.OKAY_STR,
                          "",
                          false);
                    } else {
                      onSearchParms!();
                    }
                  }),
            ),
        ],
      ),
    );
  }
}
