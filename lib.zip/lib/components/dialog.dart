import 'dart:async';
import 'dart:io';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/login_view/LoginPage.dart';
import 'package:vyaparlive/utills/SharePref.dart';
import 'package:flutx/flutx.dart';
import 'package:image_picker/image_picker.dart';

enum DialogAction { yes, cancel }

class Dialogs {
  static Future<DialogAction> yesCancelDialog(
    BuildContext context,
    String? title,
    String? body,
    String? okButtonText,
    String? cancelButtonText,
    bool showCancel,
  ) async {
    final action = await showGeneralDialog(
        barrierColor: Color.fromARGB(221, 34, 34, 34),
        transitionBuilder: (context, a1, a2, widget) {
          return Transform.scale(
            scale: a1.value,
            child: Opacity(
              opacity: a1.value,
              child: AlertDialog(
                elevation: 100.0,
                // backgroundColor: Color(0XFFE0E0E0),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(
                    Radius.circular(10.0),
                  ),
                ),
                title: Text(
                  title!,
                  style: TextStyle(
                      color: AppTheme.vyaparTheme.colorScheme
                          .primary, //Color(Constants.APP_COLOR),
                      fontFamily: StyleView.FONT_TITLE),
                ),
                content: Text(
                  body != null
                      ? ((body == Constants.FORBIDEN_TEXT)
                          ? "You have logged-in from another device"
                          : "$body")
                      : Constants.UNKNOWN_ERROR,
                  style: TextStyle(
                      color: Colors.black, //Color(Constants.APP_COLOR),
                      fontFamily: StyleView.FONT_TITLE),
                ),
                actions: <Widget>[
                  showCancel
                      ? TextButton(
                          onPressed: () =>
                              Navigator.of(context).pop(DialogAction.cancel),
                          child: Text(
                            cancelButtonText!.isEmpty
                                ? Constants.STR_CANCEL
                                : cancelButtonText,
                            style: TextStyle(
                              fontSize: 20.0,
                              fontFamily: StyleView.FONT_TITLE,
                              color: AppTheme.vyaparTheme.colorScheme
                                  .primary, //Color(Constants.APP_COLOR),
                            ),
                          ))
                      : new Container(),
                  FxButton.medium(
                      // padding: EdgeInsets.fromLTRB(24, 5, 24, 5),
                      borderRadiusAll: Constants.buttonRadius.large,
                      splashColor: AppTheme.vyaparTheme.colorScheme.onPrimary
                          .withAlpha(40),
                      backgroundColor: AppTheme.vyaparTheme.colorScheme.primary,
                      onPressed: () {
                        if (body == Constants.FORBIDEN_TEXT) {
                          AppController.instance.setMyBuId = "";
                          AppController.instance.setBuName = "";
                          AppController.instance.setAuthorizationKey = "";
                          SharePref().savePhoneNumber('');
                          SharePref().savePassword('');
                          SharePref().saveFirebaseToken("");
                          SharePref().saveHomePageSelectedBuId('');
                          navigateLoginPage(context);
                        } else {
                          Navigator.of(context).pop(DialogAction.yes);
                        }
                      },
                      child: FxText.displaySmall(
                        okButtonText!.isEmpty
                            ? Constants.OKAY_STR
                            : okButtonText,
                        style: TextStyle(
                          // fontSize: 20.0,
                          fontFamily: StyleView.FONT_TITLE,
                          color: Colors.white, //Color(Constants.APP_COLOR),
                        ),
                      ))
                  // TextButton(

                  //   onPressed: () {
                  //     if (body == Constants.FORBIDEN_TEXT) {
                  //       AppController.instance.setMyBuId = "";
                  //       AppController.instance.setBuName = "";
                  //       AppController.instance.setAuthorizationKey = "";
                  //       SharePref().savePhoneNumber('');
                  //       SharePref().savePassword('');
                  //       SharePref().saveFirebaseToken("");
                  //       SharePref().saveHomePageSelectedBuId('');
                  //       navigateLoginPage(context);
                  //     } else {
                  //       Navigator.of(context).pop(DialogAction.yes);
                  //     }
                  //   },
                  //   child: Text(
                  //     okButtonText!.isEmpty ? Constants.OKAY_STR : okButtonText,
                  //     style: TextStyle(
                  //       fontSize: 20.0,
                  //       fontFamily: StyleView.FONT_TITLE,
                  //       color: AppTheme.learningTheme.colorScheme
                  //           .primary, //Color(Constants.APP_COLOR),
                  //     ),
                  //   ),
                  // )
                ],
              ),
            ),
          );
        },
        transitionDuration: Duration(milliseconds: 250),
        barrierDismissible: false,
        barrierLabel: 'hello',
        context: context,
        pageBuilder: (context, a1, a2) {
          return Text("Test");
        });

    return (action != null
        ? action as FutureOr<DialogAction>
        : DialogAction.cancel);
  }

  static Future<DialogAction> showOffer(
      BuildContext context,
      num? discount,
      String? offerName,
      num? minOrder,
      num? maxOrder,
      String? offerType) async {
    final action = await showGeneralDialog(
        barrierColor: Colors.black54,
        transitionBuilder: (context, a1, a2, widget) {
          return Transform.scale(
              scale: a1.value,
              child: Opacity(
                opacity: a1.value,
                child: AlertDialog(
                  elevation: 100.0,
                  contentPadding: EdgeInsets.fromLTRB(15.0, 0, 0.0, 0),
                  backgroundColor: Color(0XFFE0E0E0),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(
                      Radius.circular(
                        7.0,
                      ),
                    ),
                  ),
                  title: Text(
                    "Offer Details",
                    // Language().getString(Constants.OFFER_DETAILS_STR, selectedLang),
                    style: TextStyle(
                      color: Color(Constants.APP_COLOR),
                    ),
                  ),
                  titlePadding: EdgeInsets.fromLTRB(17.0, 24.0, 0.0, 5.0),
                  content: RichText(
                      text: TextSpan(children: <TextSpan>[
                    TextSpan(
                        text: "Offer Name: $offerName",
                        style: TextStyle(
                          fontFamily: StyleView.FONT_TITLE,
                          fontSize: 17.0,
                          color: Colors.green,
                        )),
                    (offerType == "Discount in amount")
                        ? TextSpan(
                            text: "\n$offerType : $discount rupees",
                            style: TextStyle(
                              color: Color(Constants.APP_COLOR),
                              fontFamily: StyleView.FONT_TITLE,
                              fontSize: 13.0,
                            ))
                        : TextSpan(
                            text: "\n$offerType : $discount",
                            style: TextStyle(
                              color: Color(Constants.APP_COLOR),
                              fontFamily: StyleView.FONT_TITLE,
                              fontSize: 13.0,
                            )),
                    TextSpan(
                        text: "\nMin Order : $minOrder Units",
                        style: TextStyle(
                          color: Color(Constants.APP_COLOR),
                          fontFamily: StyleView.FONT_TITLE,
                          fontSize: 13.0,
                        )),
                    TextSpan(
                        text: "\nMax Order : $maxOrder Units",
                        style: TextStyle(
                          color: Color(Constants.APP_COLOR),
                          fontFamily: StyleView.FONT_TITLE,
                          fontSize: 13.0,
                        ))
                  ])),
                  actions: [
                    TextButton(
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      child: Text(
                        Constants.OKAY_STR,
                        style: TextStyle(
                          fontSize: 20.0,
                          color: Color(Constants.APP_COLOR),
                        ),
                      ),
                    ),
                  ],
                ),
              ));
        },
        transitionDuration: Duration(milliseconds: 350),
        barrierDismissible: false,
        barrierLabel: 'hello',
        context: context,
        pageBuilder: (context, a1, a2) {
          return Text("Test");
        });

    return (action != null
        ? action as FutureOr<DialogAction>
        : DialogAction.cancel);
  }

  static Future<DialogAction> removeItem(
      BuildContext context, String? itemName, String? warning, String? text,
      {required String cancel, required String yes}) async {
    final action = await showGeneralDialog(
        barrierColor: Colors.black54,
        transitionBuilder: (context, a1, a2, widget) {
          return Transform.scale(
              scale: a1.value,
              child: Opacity(
                  opacity: a1.value,
                  child: AlertDialog(
                    elevation: 100.0,
                    contentPadding: EdgeInsets.fromLTRB(15.0, 0, 0.0, 0),
                    backgroundColor: Color(0XFFE0E0E0),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(
                        Radius.circular(
                          7.0,
                        ),
                      ),
                    ),
                    title: Text(
                      warning!,
                      style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                      ),
                    ),
                    titlePadding: EdgeInsets.fromLTRB(17.0, 24.0, 0.0, 5.0),
                    content: RichText(
                        text: TextSpan(children: <TextSpan>[
                      TextSpan(
                          text: text,
                          style: TextStyle(
                            fontFamily: StyleView.FONT_TITLE,
                            fontSize: 15.0,
                            color: Color(Constants.APP_COLOR),
                          )),
                      TextSpan(
                          text: " $itemName",
                          style: TextStyle(
                            color: Colors.red,
                            fontFamily: StyleView.FONT_TITLE,
                            fontSize: 17.0,
                          )),
                      TextSpan(
                          text: "?",
                          style: TextStyle(
                            color: Color(Constants.APP_COLOR),
                            fontFamily: StyleView.FONT_TITLE,
                            fontSize: 15.0,
                          ))
                    ])),
                    actions: [
                      TextButton(
                        onPressed: () {
                          Navigator.of(context).pop(DialogAction.cancel);
                        },
                        child: Text(
                          cancel,
                          style: TextStyle(
                            color: Color(Constants.APP_COLOR),
                          ),
                        ),
                      ),
                      TextButton(
                        onPressed: () {
                          Navigator.of(context).pop(DialogAction.yes);
                        },
                        child: Text(
                          yes,
                          style: TextStyle(
                            color: Color(Constants.APP_COLOR),
                          ),
                        ),
                      )
                    ],
                  )));
        },
        transitionDuration: Duration(milliseconds: 350),
        barrierDismissible: false,
        barrierLabel: '',
        context: context,
        pageBuilder: (context, a1, a2) {
          return Text("Test");
        });

    return (action != null
        ? action as FutureOr<DialogAction>
        : DialogAction.cancel);
  }

  static Future<DialogAction?> openBottomSheet(
      {required BuildContext context,
      Function(File)? openCamera,
      Function(File)? openGallery,
      bool pdfRead = false}) {
    return showModalBottomSheet(
        context: context,
        builder: (BuildContext context) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              ListTile(
                leading: Icon(Icons.photo, color: Colors.purple),
                title: Text(Constants.GALLERY),
                onTap: () async {
                  final file = await AppUtills.getCameraImage(
                      Constants.GALLERY, context,
                      pdfRead: pdfRead);
                  if (file != null) {
                    openGallery!(file);
                  }

                  // try {
                  //   List<File> _paths = await FilePicker.getMultiFile(
                  //       // Or getFile
                  //       type: FileType.custom,
                  //       allowedExtensions: ['png']);
                  //   if (_paths != null) {
                  //     openGallery(_paths[0]);
                  //   }
                  // } on PlatformException catch (e) {
                  //   print("Unsupported operation: " + e.toString());
                  // }
                },
              ),
              ListTile(
                  leading: Icon(
                    Icons.camera,
                    color: Colors.pinkAccent,
                  ),
                  title: Text(Constants.CAMERA),
                  onTap: () async {
                    final file = await AppUtills.getCameraImage(
                        Constants.CAMERA, context);
                    if (file != null) {
                      openCamera!(file);
                    }
                  }),
            ],
          );
        });
  }

  static Future<XFile?> getWebImage() async {
    final _picker = ImagePicker();
    final XFile? pickedFile =
        await _picker.pickImage(source: ImageSource.gallery);

    // print("xfile $pickedFile");
    return pickedFile;
  }

  static navigateLoginPage(context) {
    return Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => LoginPage()),
        (Route<dynamic> route) => false);
  }
}
