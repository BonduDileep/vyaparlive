import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../StyleView.dart';

class DisplayAttachedFile extends StatelessWidget {
  final String? imageRelativePath;
  final String fileType;
  final String fileName;
  final VoidCallback onRemove;
  final VoidCallback onPress;
  const DisplayAttachedFile(
      {super.key,
      required this.imageRelativePath,
      required this.fileType,
      required this.fileName,
      required this.onPress,
      required this.onRemove});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        InkWell(
          onTap: () => onPress(),
          child: (fileType == 'application/pdf')
              ? Text(
                  fileName,
                  style: TextStyle(
                      decoration: TextDecoration.underline,
                      color: Colors.black,
                      fontWeight: StyleView.fontRegular),
                )
              : ClipRRect(
                  borderRadius: BorderRadius.all(Radius.circular(8)),
                  child: Container(
                      height: MediaQuery.of(context).size.height * 0.2,
                      child: CachedNetworkImage(
                        imageUrl: imageRelativePath!,
                        height: MediaQuery.of(context).size.height * 0.2,
                        errorWidget: (context, url, error) => Icon(Icons.error),
                      )),
                ),
        ),
        if (imageRelativePath!.isNotEmpty)
          TextButton(
              onPressed: () => onRemove(),
              child: Text(
                "Remove",
                style: TextStyle(
                    color: Colors.red,
                    fontWeight: StyleView.fontMedium,
                    decoration: TextDecoration.underline),
              ))
      ],
    );
  }
}
