import 'package:flutter/material.dart';
import 'package:vyaparlive/components/Constants.dart';

class CustomTextStyle {
  static TextStyle regularTextStyle(
      {Color color = Colors.black,
      double fontSize = Constants.REGULAR_FONT_SIZE,
      FontWeight fontWeight = FontWeight.normal}) {
    return TextStyle(color: color, fontSize: fontSize, fontWeight: fontWeight);
  }

  static TextStyle headerTextStyle(
      {Color color = const Color(Constants.APP_COLOR),
      double fontSize = Constants.HEADER_FONT_SIZE,
      FontWeight fontWeigt = FontWeight.bold}) {
    return TextStyle(
      fontWeight: fontWeigt,
      color: color,
      fontSize: fontSize,
    );
  }

  static TextStyle subHeaderTextStyle(
      {Color color = const Color(Constants.APP_COLOR),
      double fontSize = Constants.SUB_HEADER_FONT_SIZE,
      FontWeight fontWeigt = FontWeight.w600}) {
    return TextStyle(
      fontWeight: fontWeigt,
      color: color,
      fontSize: fontSize,
    );
  }

  static TextStyle lHeaderTextStyle(
      {Color color = const Color(Constants.APP_COLOR),
      double fontSize = Constants.LARGE_FONT_SIZE,
      FontWeight fontWeigt = FontWeight.bold}) {
    return TextStyle(
      fontWeight: fontWeigt,
      color: color,
      fontSize: fontSize,
    );
  }

  static TextStyle xlHeaderTextStyle(
      {Color color = const Color(Constants.APP_COLOR),
      double fontSize = Constants.EXTRA_LARGE_FONT_SIZE,
      FontWeight fontWeigt = FontWeight.bold}) {
    return TextStyle(
      fontWeight: fontWeigt,
      color: color,
      fontSize: fontSize,
    );
  }

  static TextStyle textButtonStyle(
      {Color color = const Color(Constants.APP_COLOR),
      double fontSize = Constants.EXTRA_LARGE_FONT_SIZE,
      FontWeight fontWeigt = FontWeight.bold,TextDecoration decoration = TextDecoration.underline}) {
    return TextStyle(
      decoration: decoration,
      fontWeight: fontWeigt,
      color: color,
      fontSize: fontSize,
    );
  }
}
