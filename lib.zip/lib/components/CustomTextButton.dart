import 'package:flutx/widgets/text/text.dart';
import 'package:flutter/material.dart';
import 'StyleView.dart';

class CustomTextButton extends StatelessWidget {
  final String text;
  final VoidCallback onPressed;
  
  CustomTextButton({Key? key, required this.text, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return TextButton(
      onPressed: () => this.onPressed(),
      child: Row(
        children: [
          FxText.displayMedium(this.text,
              style: TextStyle(
                  fontSize: 13,
                  fontFamily: StyleView.FONT_TITLE,
                  color: Colors.black,
                  decoration: TextDecoration.underline,
                  fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }
}
