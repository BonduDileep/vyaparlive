import 'package:vyaparlive/components/Constants.dart';
import 'package:flutter/material.dart';
import 'StyleView.dart';

class CustomSearchView extends StatelessWidget {
  final Function(String)? onReadText;
  final String hintText;
  final String searchText;
  final TextEditingController searchController;
  final VoidCallback onClear;
  final bool isShowClear;
  CustomSearchView(
      {Key? key,
      this.onReadText,
      required this.hintText,
      required this.searchText,
      required this.searchController,
      required this.onClear,
      required this.isShowClear})
      : super(key: key);
  @override
  Widget build(BuildContext context) {
    // searchController.text = searchText;
    // searchController.selection = TextSelection.fromPosition(
    //     TextPosition(offset: searchController.text.length));

    return Container(
      height: 50.0,
      child: Padding(
        padding: const EdgeInsets.only(left: 0),
        child: Card(
          elevation: 2.5,
          shape: new RoundedRectangleBorder(
              borderRadius: new BorderRadius.circular(8),
              side: new BorderSide(
                  color: Color(Constants.APP_COLOR), strokeAlign: 0.01)),
          child: Row(
            children: <Widget>[
              Expanded(
                child: Container(
                  padding: EdgeInsets.only(left: 8),
                  child: TextFormField(
                    controller: searchController,
                    onChanged: onReadText!,
                    style: TextStyle(
                        fontWeight: StyleView.fontMedium,
                        color: Colors.black,
                        fontSize: 15),
                    decoration: InputDecoration(
                        contentPadding: EdgeInsets.only(bottom: 8),
                        border: InputBorder.none,
                        hintText: hintText,
                        hintStyle: TextStyle(
                            color: Colors.black,
                            fontSize: 15,
                            fontWeight: StyleView.fontMedium)),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
