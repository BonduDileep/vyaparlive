class ProductPrivileges {
  bool import_excel = false;
  bool get_products_from_yr = false;
  bool copy_form_organization = false;
  bool delete_product = false;
  bool add_product = false;
  bool edit_product = false;
  bool products_view = false;
  bool product_transaction = false;
  bool product_location_edit = false;
  bool product_offer_create = false;
  bool product_offer_edit = false;
  bool product_offer_delete = false;
  bool package_offer_edit = false;
  bool package_offer_create = false;
  bool package_offer_delete = false;
  bool viewInventoryList = false;

  bool get importexcel => import_excel;

  set importexcel(bool value) => import_excel = value;

  bool get getproducts_from_yr => get_products_from_yr;

  set getproducts_from_yr(bool value) => get_products_from_yr = value;

  bool get copyform_organization => copy_form_organization;

  set copyform_organization(bool value) => copy_form_organization = value;

  bool get deleteproduct => delete_product;

  set deleteproduct(bool value) => delete_product = value;

  bool get addproduct => add_product;

  set addproduct(bool value) => add_product = value;

  bool get editproduct => edit_product;

  set editproduct(bool value) => edit_product = value;

  bool get productsview => products_view;

  set productsview(bool value) => products_view = value;

  bool get producttransaction => product_transaction;

  set producttransaction(bool value) => product_transaction = value;

  bool get productlocation_edit => product_location_edit;

  set productlocation_edit(bool value) => product_location_edit = value;

  bool get productoffer_create => product_offer_create;

  set productoffer_create(bool value) => product_offer_create = value;

  bool get productoffer_edit => product_offer_edit;

  set productoffer_edit(bool value) => product_offer_edit = value;

  bool get productoffer_delete => product_offer_delete;

  set productoffer_delete(bool value) => product_offer_delete = value;

  bool get packageoffer_edit => package_offer_edit;

  set packageoffer_edit(bool value) => package_offer_edit = value;

  bool get packageoffer_create => package_offer_create;

  set packageoffer_create(bool value) => package_offer_create = value;

  bool get packageoffer_delete => package_offer_delete;

  set packageoffer_delete(bool value) => package_offer_delete = value;

  set viewproductinventory(bool value) => this.viewInventoryList = value;
  bool get viewproductinventory => this.viewInventoryList;
}
