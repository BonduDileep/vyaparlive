class AssetManagementPrivileges {
  bool view_asset_management = false;
  bool view_create_asset_group = false;
  bool view_asset_list = false;
  bool view_disposed_list = false;
  bool view_scrap_list = false;

  set viewasset_management(bool value) => this.view_asset_management = value;

  bool get viewasset_management => this.view_asset_management;

  set viewcreate_asset_group(bool value) =>
      this.view_create_asset_group = value;

  bool get viewcreate_asset_group => this.view_create_asset_group;

  set viewasset_list(bool value) => this.view_asset_list = value;

  bool get viewasset_list => this.view_asset_list;

  set viewdisposed_list(bool value) => this.view_disposed_list = value;
  bool get viewdisposed_list => this.view_disposed_list;

  set viewscrap_list(bool value) => this.view_scrap_list = value;
  bool get viewscrap_list => this.view_scrap_list;
}
