class ReportsPrivileges {
  bool viewReports = false;
  bool viewSellReports = false;
  bool viewBuyReports = false;
  bool viewFieldSalesTeamReports = false;
  bool viewRetailSalesReports = false;
  bool viewProductsReports = false;
  bool viewProductLogReports = false;
  bool viewAnalysisReports = false;

  set viewreports(bool value) => this.viewReports = value;
  bool get viewreports => this.viewReports;

  set viewsellreports(bool value) => this.viewSellReports = value;
  bool get viewsellreports => this.viewSellReports;

  set viewbuyreports(bool value) => this.viewBuyReports = value;
  bool get viewbuyreports => this.viewBuyReports;

  set viewfieldsalesteamreports(bool value) =>
      this.viewFieldSalesTeamReports = value;
  bool get viewfieldsalesteamreports => this.viewFieldSalesTeamReports;

  set viewretailsalesreports(bool value) => this.viewRetailSalesReports = value;
  bool get viewretailsalesreports => this.viewRetailSalesReports;

  set viewproductsreports(bool value) => this.viewProductsReports = value;
  bool get viewproductsreports => this.viewProductsReports;

  set viewproductlogreports(bool value) => this.viewProductLogReports = value;
  bool get viewproductlogreports => this.viewProductLogReports;

  set viewanalysisreports(bool value) => this.viewAnalysisReports = value;
  bool get viewanalysisreports => this.viewAnalysisReports;
}
