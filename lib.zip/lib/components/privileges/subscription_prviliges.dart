class SubscriptionPrivileges {
  bool edit_update_subscription = false;
  bool view_subscription = false;
  bool edit_subscription = false;

  bool get editupdate_subscription => edit_update_subscription;

  set editupdate_subscription(bool value) => edit_update_subscription = value;

  bool get viewsubscription => view_subscription;

  set viewsubscription(bool value) => view_subscription = value;

  bool get editsubscription => edit_subscription;

  set editsubscription(bool value) => edit_subscription = value;
}
