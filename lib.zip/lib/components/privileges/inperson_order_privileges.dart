class InPersonOrderPrivileges {
  bool delete_in_person_order = false;
  bool update_in_person_order = false;
  bool edit_in_person_order = false;
  bool add_in_person_order = false;
  bool viewInpersonOrders = false;
  bool viewBuyOrders = false;
  bool viewSellOrders = false;
  bool viewDistributorOrders = false;
  bool createDistributorOrder = false;

  bool get deletein_person_order => delete_in_person_order;

  set deletein_person_order(bool value) => delete_in_person_order = value;

  bool get updatein_person_order => update_in_person_order;

  set updatein_person_order(bool value) => update_in_person_order = value;

  bool get editin_person_order => edit_in_person_order;

  set editin_person_order(bool value) => edit_in_person_order = value;

  bool get addin_person_order => add_in_person_order;

  set addin_person_order(bool value) => add_in_person_order = value;

  set viewinpersonorders(bool value) => this.viewInpersonOrders = value;
  bool get viewinpersonorders => this.viewInpersonOrders;

  set viewbuyorders(bool value) => this.viewBuyOrders = value;
  bool get viewbuyorders => this.viewBuyOrders;

  set viewsellorders(bool value) => this.viewSellOrders = value;
  bool get viewsellorders => this.viewSellOrders;

  set viewdistributorsorders(bool value) => this.viewDistributorOrders = value;
  bool get viewdistributorsorders => this.viewDistributorOrders;

  set createdistributororder(bool value) => this.viewDistributorOrders = value;
  bool get createdistributororder => this.viewDistributorOrders;
}
