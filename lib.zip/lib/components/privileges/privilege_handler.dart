import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/privileges/Expenses_privileges.dart';
import 'package:vyaparlive/components/privileges/RetailSalesPrivileges.dart';
import 'package:vyaparlive/components/privileges/asset_management_privileges.dart';
import 'package:vyaparlive/components/privileges/bu_privileges.dart';
import 'package:vyaparlive/components/privileges/connection_privileges.dart';
import 'package:vyaparlive/components/privileges/inperson_order_privileges.dart';
import 'package:vyaparlive/components/privileges/invitation_privileges.dart';
import 'package:vyaparlive/components/privileges/product_consumption_privileges.dart';
import 'package:vyaparlive/components/privileges/product_privileges.dart';
import 'package:vyaparlive/components/privileges/reports_privileges.dart';
import 'package:vyaparlive/components/privileges/subscription_prviliges.dart';
import 'package:vyaparlive/components/privileges/transaction_privileges.dart';
import 'package:vyaparlive/components/privileges/users_privileges.dart';
import 'package:vyaparlive/model/PrivilegesDAO.dart';

class PrivilegeHandler {
  void setTransactionPrivileges(var data) {
    TransactionPrivileges transactionPrivileges = TransactionPrivileges();
    if (data == null) {
      AppController.instance.setTransactionPriviliges = transactionPrivileges;
      return;
    }

    List<PrivilegesDAO> permissionsList = getPermissionsList(data);

    for (PrivilegesDAO permission in permissionsList) {
      switch (permission.code) {
        case 'view_transaction':
          transactionPrivileges.view_transaction = true;
          break;
        case 'view_payment_details':
          transactionPrivileges.view_payment_details = true;
          break;
        case 'stock_add_update_resolution':
          transactionPrivileges.stock_add_update_resolution = true;
          break;
        case 'view_resolution':
          transactionPrivileges.view_resolution = true;
          break;
        case 'receive_stocks':
          transactionPrivileges.receive_stocks = true;
          break;
        case 'view_payment_reconciliation':
          transactionPrivileges.view_payment_reconciliation = true;
          break;
        case 'view_stock_reconciliation':
          transactionPrivileges.view_stock_reconciliation = true;
          break;
        case 'view_reconciliation':
          transactionPrivileges.view_reconciliation = true;
          break;
        case 'in_direct_delivery':
          transactionPrivileges.in_direct_delivery = true;
          break;
        case 'direct_delivery':
          transactionPrivileges.direct_delivery = true;
          break;
        case 'add_edit_delivery':
          transactionPrivileges.add_edit_delivery = true;
          break;
        case 'view_delivery':
          transactionPrivileges.view_delivery = true;
          break;
        case 'self_packing':
          transactionPrivileges.self_packing = true;
          break;
        case 'assign_user':
          transactionPrivileges.assign_user = true;
          break;
        case 'update_packing':
          transactionPrivileges.update_packing = true;
          break;
        case 'add_edit_packing':
          transactionPrivileges.add_edit_packing = true;
          break;
        case 'view_packing':
          transactionPrivileges.view_packing = true;
          break;
        case 'view_invoice':
          transactionPrivileges.view_invoice = true;
          break;
        case 'generate_invoice':
          transactionPrivileges.generate_invoice = true;
          break;
        case 'reject_po':
          transactionPrivileges.reject_po = true;
          break;
        case 'accept_po':
          transactionPrivileges.accept_po = true;
          break;
        case 'view_po':
          transactionPrivileges.view_po = true;
          break;
        case 'accept_confirmation_message':
          transactionPrivileges.accept_confirmation_message = true;
          break;
        case 'update_confirmation_order':
          transactionPrivileges.update_confirmation_order = true;
          break;
        case 'edit_confirmation_message':
          transactionPrivileges.edit_confirmation_message = true;
          break;
        case 'view_confirmation_message':
          transactionPrivileges.view_confirmation_message = true;
          break;
        case 'add_discussion':
          transactionPrivileges.add_discussion = true;
          break;
        case 'view_discussion':
          transactionPrivileges.view_discussion = true;
          break;
        case 'connection_start_discussion':
          transactionPrivileges.connection_start_discussion = true;
          break;
        case 'connection_place_order':
          transactionPrivileges.connection_place_order = true;
          break;
      }
    }
    AppController.instance.setTransactionPriviliges = transactionPrivileges;
  }

  void setConnectionPermissions(var data) {
    ConnectionPrivileges connectionPrivileges = ConnectionPrivileges();
    if (data == null) {
      AppController.instance.setConnectionPrivileges = connectionPrivileges;
      return;
    }
    List<PrivilegesDAO> permissionsList = getPermissionsList(data);

    for (var permission in permissionsList) {
      switch (permission.code) {
        case "place_order_to_connections":
          connectionPrivileges.place_order_to_connections = true;
          break;
        case "add_connection_products_to_catalogue":
          connectionPrivileges.add_connection_products_to_catalogue = true;
          break;
        case "add_edit_connection_sales_terms":
          connectionPrivileges.add_edit_connection_sales_terms = true;
          break;
        case "connection_product_view":
          connectionPrivileges.connection_product_view = true;
          break;
        case "view_connection":
          connectionPrivileges.connection_view = true;
          break;
        case "connection_details_view":
          connectionPrivileges.connection_details_view = true;
          break;

        case "create_offline_connection":
          connectionPrivileges.createOfflineConnection = true;
          break;
        case "edit_offline_connection":
          connectionPrivileges.editOfflineConnection = true;
          break;

        case "remove_offline_connection":
          connectionPrivileges.removeOfflineConnection = true;
          break;

        case "connection_offline_list_view":
          connectionPrivileges.viewOfflineConnectionsList = true;
          break;

        case "view_connection_transactions_history":
          connectionPrivileges.viewConnectionTransactionHistory = true;
          break;

        case "view_add_assign_user":
          connectionPrivileges.viewAddAssignUser = true;
          break;

        case "view_add_distributor":
          connectionPrivileges.viewAddDistributor = true;
          break;
        case "view_direct_order":
          connectionPrivileges.viewDirectOrder = true;
          break;
      }
    }
    AppController.instance.setConnectionPrivileges = connectionPrivileges;
  }

  void setProductPrivileges(var data) {
    ProductPrivileges privileges = ProductPrivileges();
    if (data == null) {
      AppController.instance.setProductPrivileges = privileges;
      return;
    }
    List<PrivilegesDAO> permissionsList = getPermissionsList(data);

    for (var permission in permissionsList) {
      switch (permission.code) {
        case "import_excel":
          privileges.import_excel = true;
          break;
        case "get_products_from_yr":
          privileges.get_products_from_yr = true;
          break;
        case "copy_form_organization":
          privileges.copy_form_organization = true;
          break;
        case "delete_product":
          privileges.delete_product = true;
          break;
        case "add_product":
          privileges.add_product = true;
          break;
        case "edit_product":
          privileges.edit_product = true;
          break;
        case "products_view":
          privileges.products_view = true;
          break;
        case "product_transaction":
          privileges.product_transaction = true;
          break;
        case "product_location_edit":
          privileges.product_location_edit = true;
          break;
        case "product_offer_create":
          privileges.product_offer_create = true;
          break;
        case "product_offer_edit":
          privileges.product_offer_edit = true;
          break;
        case "product_offer_delete":
          privileges.product_offer_delete = true;
          break;
        case "package_offer_edit":
          privileges.package_offer_edit = true;
          break;
        case "package_offer_create":
          privileges.package_offer_create = true;
          break;
        case "package_offer_delete":
          privileges.package_offer_delete = true;
          break;
        case "view_inventory_location":
          privileges.viewInventoryList = true;
          break;
      }
    }
    AppController.instance.setProductPrivileges = privileges;
  }

  void setSubscriptionPrivileges(var data) {
    SubscriptionPrivileges privileges = SubscriptionPrivileges();
    if (data == null) {
      AppController.instance.setSubScriptionPrivileges = privileges;
      return;
    }
    List<PrivilegesDAO> permissionsList = getPermissionsList(data);

    for (var permission in permissionsList) {
      switch (permission.code) {
        case "edit_update_subscription":
          privileges.edit_update_subscription = true;
          break;
        case "view_subscription":
          privileges.view_subscription = true;
          break;
        case "edit_subscription":
          privileges.edit_subscription = true;
          break;
      }
    }
    AppController.instance.setSubScriptionPrivileges = privileges;
  }

  void setInPersonOrderPrivileges(var data) {
    InPersonOrderPrivileges privileges = InPersonOrderPrivileges();
    if (data == null) {
      AppController.instance.setInpersonOrderPrivileges = privileges;
      return;
    }
    List<PrivilegesDAO> permissionsList = getPermissionsList(data);

    for (var permission in permissionsList) {
      switch (permission.code) {
        case "delete_in_person_order":
          privileges.delete_in_person_order = true;
          break;
        case "update_in_person_order":
          privileges.update_in_person_order = true;
          break;
        case "edit_in_person_order":
          privileges.edit_in_person_order = true;
          break;
        case "add_in_person_order":
          privileges.add_in_person_order = true;
          break;

        case "view_in_person_order":
          privileges.viewInpersonOrders = true;
          break;
        case "create_distributors_order":
          privileges.createDistributorOrder = true;
          break;
        case "view_distributors_order":
          privileges.viewDistributorOrders = true;
          break;
      }
    }
    AppController.instance.setInpersonOrderPrivileges = privileges;
  }

  void setUsersPrivileges(var data) {
    UserPrivileges privileges = UserPrivileges();
    if (data == null) {
      AppController.instance.setUserPrivileges = privileges;
      return;
    }
    List<PrivilegesDAO> permissionsList = getPermissionsList(data);

    for (var permission in permissionsList) {
      switch (permission.code) {
        case "user_view":
          privileges.user_view = true;
          break;
        case "user_creation":
          privileges.user_creation = true;
          break;
        case "user_edit":
          privileges.user_edit = true;
          break;
        case "user_delete":
          privileges.user_delete = true;
          break;
      }
    }
    AppController.instance.setUserPrivileges = privileges;
  }

  void setInvitationPrivileges(var data) {
    InvitationPrivileges privileges = InvitationPrivileges();
    if (data == null) {
      AppController.instance.setInvitationPrivileges = privileges;
      return;
    }
    List<PrivilegesDAO> permissionsList = getPermissionsList(data);

    for (var permission in permissionsList) {
      switch (permission.code) {
        case "invitation_reject":
          privileges.invitation_reject = true;
          break;
        case "invitation_accept":
          privileges.invitation_accept = true;
          break;
        case "invitation_view":
          privileges.invitation_view = true;
          break;
        case "invitation_create":
          privileges.invitation_create = true;
          break;
      }
    }
    AppController.instance.setInvitationPrivileges = privileges;
  }

  void setBuPrivileges(var data) {
    BuPrivileges privileges = BuPrivileges();
    if (data == null) {
      AppController.instance.setBuPrivileges = privileges;
      return;
    }
    List<PrivilegesDAO> permissionsList = getPermissionsList(data);

    for (var permission in permissionsList) {
      switch (permission.code) {
        case "business_unit_package_view":
          privileges.business_unit_package_view = true;
          break;
        case "bu_product_offer_view":
          privileges.bu_product_offer_view = true;
          break;
        case "bu_product_view":
          privileges.bu_product_view = true;
          break;
        case "bu_location_delete":
          privileges.bu_location_delete = true;
          break;
        case "bu_location_edit":
          privileges.bu_location_edit = true;
          break;
        case "bu_location_view":
          privileges.bu_location_view = true;
          break;
        case "business_unit_view":
          privileges.business_unit_view = true;
          break;
        case "business_unit_role_view":
          privileges.business_unit_role_view = true;
          break;
        case "business_unit_role_edit":
          privileges.business_unit_role_edit = true;
          break;
        case "business_unit_role_delete":
          privileges.business_unit_role_delete = true;
          break;
        case "business_unit_role_create":
          privileges.business_unit_role_create = true;
          break;
        case "business_unit_location_create":
          privileges.business_unit_location_create = true;
          break;
        case "edit_business_unit":
          privileges.edit_business_unit = true;
          break;
        case "delete_business_unit":
          privileges.delete_business_unit = true;
          break;
        case "add_business_unit":
          privileges.add_business_unit = true;
          break;
      }
    }
    AppController.instance.setBuPrivileges = privileges;
  }

  List<PrivilegesDAO> getPermissionsList(var data) {
    var listOfData = (data);
    List<PrivilegesDAO> permissionsList = [];
    for (var item in listOfData) {
      permissionsList.add(PrivilegesDAO.fromJson(item));
    }
    return permissionsList;
  }

  void setPermissions(Map<String, dynamic>? permissions) {
    if (permissions != null && permissions.isNotEmpty) {
      if (permissions.containsKey("TRANSACTION")) {
        setTransactionPrivileges(permissions['TRANSACTION']);
      } else {
        setTransactionPrivileges(null);
      }

      if (permissions.containsKey("CONNECTIONS")) {
        setConnectionPermissions(permissions['CONNECTIONS']);
      } else {
        setConnectionPermissions(null);
      }

      if (permissions.containsKey("PRODUCT")) {
        setProductPrivileges(permissions['PRODUCT']);
      } else {
        setProductPrivileges(null);
      }

      if (permissions.containsKey("SUBSCRIPTION")) {
        setSubscriptionPrivileges(permissions['SUBSCRIPTION']);
      } else {
        setSubscriptionPrivileges(null);
      }

      if (permissions.containsKey("IN_PERSON_ORDER")) {
        setInPersonOrderPrivileges(permissions['IN_PERSON_ORDER']);
      } else {
        setInPersonOrderPrivileges(null);
      }

      if (permissions.containsKey("USERS")) {
        setUsersPrivileges(permissions['USERS']);
      } else {
        setUsersPrivileges(null);
      }

      if (permissions.containsKey("INVITATION")) {
        setInvitationPrivileges(permissions['INVITATION']);
      } else {
        setInvitationPrivileges(null);
      }

      if (permissions.containsKey("BUSINESS_UNIT")) {
        setBuPrivileges(permissions['BUSINESS_UNIT']);
      } else {
        setBuPrivileges(null);
      }

      if (permissions.containsKey("ASSETS_MANAGEMENT")) {
        setAssetManagementPermissions(permissions['ASSETS_MANAGEMENT']);
      } else {
        setAssetManagementPermissions(null);
      }

      if (permissions.containsKey("PRODUCTION_CONSUMPTION")) {
        setProductConsumptionPermissions(permissions['PRODUCTION_CONSUMPTION']);
      } else {
        setProductConsumptionPermissions(null);
      }

      if (permissions.containsKey("REPORTS")) {
        setReportsPermissions(permissions["REPORTS"]);
      } else {
        setReportsPermissions(null);
      }

      if (permissions.containsKey("RETAIL_SALES")) {
        setRetailSalesPermissions(permissions["RETAIL_SALES"]);
      } else {
        setRetailSalesPermissions(null);
      }

      if (permissions.containsKey("EXPENSES")) {
        setExpensesPermissions(permissions["EXPENSES"]);
      } else {
        setExpensesPermissions(null);
      }
    }
  }

  void resetPermissions() {
    setTransactionPrivileges(null);
    setConnectionPermissions(null);
    setProductPrivileges(null);
    setSubscriptionPrivileges(null);
    setInPersonOrderPrivileges(null);
    setUsersPrivileges(null);
    setInvitationPrivileges(null);
    setBuPrivileges(null);
    setAssetManagementPermissions(null);
    setProductConsumptionPermissions(null);
    setReportsPermissions(null);
    setRetailSalesPermissions(null);
    setExpensesPermissions(null);
  }

  void setAssetManagementPermissions(var data) {
    AssetManagementPrivileges assetManagementPrivileges =
        AssetManagementPrivileges();
    if (data == null) {
      AppController.instance.setAssetManagementPrivileges =
          assetManagementPrivileges;
      return;
    }
    List<PrivilegesDAO> permissionsList = getPermissionsList(data);

    for (var permission in permissionsList) {
      switch (permission.code) {
        case "view_asset_management":
          assetManagementPrivileges.view_asset_management = true;
          break;
        case "view_create_asset_group":
          assetManagementPrivileges.view_create_asset_group = true;
          break;
        case "view_asset_list":
          assetManagementPrivileges.view_asset_list = true;
          break;
        case "view_disposed_list":
          assetManagementPrivileges.view_disposed_list = true;
          break;
        case "view_scrap_list":
          assetManagementPrivileges.view_scrap_list = true;
          break;
      }
    }
    AppController.instance.setAssetManagementPrivileges =
        assetManagementPrivileges;
  }

  void setProductConsumptionPermissions(var data) {
    ProductConsumptionPrivileges productConsumptionPrivileges =
        ProductConsumptionPrivileges();
    if (data == null) {
      AppController.instance.setProductConsumptionPrivileges =
          productConsumptionPrivileges;
      return;
    }
    List<PrivilegesDAO> permissionsList = getPermissionsList(data);

    for (var permission in permissionsList) {
      switch (permission.code) {
        case "view_product_consumption":
          productConsumptionPrivileges.view_product_consumption = true;
          break;
        case "view_raw_material":
          productConsumptionPrivileges.view_raw_material = true;
          break;
        case "view_product_consumption_management":
          productConsumptionPrivileges.view_product_consumption_management =
              true;
          break;
        case "view_product_consumption_report":
          productConsumptionPrivileges.view_product_consumption_report = true;
          break;

        case "view_raw_material_issue_list":
          productConsumptionPrivileges.view_raw_material_issue_list = true;
          break;

        case "view_raw_finished_product_reports":
          productConsumptionPrivileges.view_raw_finished_product_reports = true;
          break;

        case "view_from_raw_material":
          productConsumptionPrivileges.view_from_raw_material = true;
          break;

        case "view_create_raw_issue_note":
          productConsumptionPrivileges.view_create_raw_issue_note = true;
          break;
        case "view_raw_material_request_form":
          productConsumptionPrivileges.viewRawMaterialRequestForm = true;
          break;
      }
    }
    AppController.instance.setProductConsumptionPrivileges =
        productConsumptionPrivileges;
  }

  void setReportsPermissions(var data) {
    ReportsPrivileges _reportsPrivileges = new ReportsPrivileges();

    if (data == null) {
      AppController.instance.setReportsPrivileges = _reportsPrivileges;
      return;
    }
    List<PrivilegesDAO> permissionsList = getPermissionsList(data);

    for (var permission in permissionsList) {
      switch (permission.code) {
        case "view_analysis_reports":
          _reportsPrivileges.viewAnalysisReports = true;
          break;
        case "view_buy_reports":
          _reportsPrivileges.viewBuyReports = true;
          break;
        case "view_fields_sales_team_reports":
          _reportsPrivileges.viewFieldSalesTeamReports = true;
          break;
        case "view_product_log_reports":
          _reportsPrivileges.viewProductLogReports = true;
          break;
        case "view_product_reports":
          _reportsPrivileges.viewProductsReports = true;
          break;
        case "view_reports":
          _reportsPrivileges.viewReports = true;
          break;
        case "view_retail_sales_reports":
          _reportsPrivileges.viewRetailSalesReports = true;
          break;
        case "view_sell_reports":
          _reportsPrivileges.viewSellReports = true;
          break;
      }
    }

    AppController.instance.setReportsPrivileges = _reportsPrivileges;
  }

  void setRetailSalesPermissions(var data) {
    RetailSalesPrivileges _retailPrivileges = new RetailSalesPrivileges();

    if (data == null) {
      AppController.instance.setRetailSalesPrivileges = _retailPrivileges;
      return;
    }
    List<PrivilegesDAO> permissionsList = getPermissionsList(data);

    for (var permission in permissionsList) {
      switch (permission.code) {
        case "view_retail_sales":
          _retailPrivileges.viewRetailSales = true;

          break;
        case "create_retail_customers":
          _retailPrivileges.createRetailCustomer = true;
          break;

        case "create_retail_order":
          _retailPrivileges.createRetailOrder = true;
          break;

        case "delete_retail_customers":
          _retailPrivileges.removeRetailCustomer = true;
          break;
        case "update_retail_customers":
          _retailPrivileges.updateRetailCustomer = true;
          break;

        case "view_retail_customers":
          _retailPrivileges.viewRetailCustomers = true;
          break;
      }
    }
    AppController.instance.setRetailSalesPrivileges = _retailPrivileges;
  }

  void setExpensesPermissions(var data) {
    ExpensesPrivileges _expensesPrivileges = new ExpensesPrivileges();

    if (data == null) {
      AppController.instance.setExpensesPrivileges = _expensesPrivileges;
      return;
    }
    List<PrivilegesDAO> permissionsList = getPermissionsList(data);

    for (var permission in permissionsList) {
      switch (permission.code) {
        case "view_expenses":
          _expensesPrivileges.view_expenses = true;

          break;
        case "add_expenses":
          _expensesPrivileges.add_expenses = true;
          break;

        case "edit_expenses":
          _expensesPrivileges.edit_expenses = true;
          break;

        case "delete_expenses":
          _expensesPrivileges.delete_expenses = true;
          break;
      }
    }
    AppController.instance.setExpensesPrivileges = _expensesPrivileges;
  }
}
