class RetailSalesPrivileges {
  bool viewRetailSales = false;
  bool createRetailOrder = false;
  bool viewRetailCustomers = false;
  bool createRetailCustomer = false;
  bool updateRetailCustomer = false;
  bool removeRetailCustomer = false;

  set viewretailsales(bool value) => this.viewRetailSales = value;
  bool get viewretailsales => this.viewRetailSales;

  set viewretailcustomers(bool value) => this.viewRetailCustomers = value;
  bool get viewretailcustomers => this.viewRetailCustomers;

  set createretailorder(bool value) => this.createRetailOrder = value;
  bool get createretailorder => this.createRetailOrder;

  set createretailcustomer(bool value) => this.createRetailCustomer = value;
  bool get createretailcustomer => this.createRetailCustomer;

  set updateretailcustomer(bool value) => this.updateRetailCustomer = value;
  bool get updateretailcustomer => this.updateRetailCustomer;

  set removeretailcustomer(bool value) => this.removeRetailCustomer = value;
  bool get removeretailcustomer => this.removeRetailCustomer;
}
