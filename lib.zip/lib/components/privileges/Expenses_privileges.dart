class ExpensesPrivileges {
  bool viewExpenses = false;
  bool addExpenses = false;
  bool editExpenses = false;
  bool deleteExpenses = false;

  set view_expenses(bool value) => this.viewExpenses = value;
  bool get view_expenses => this.viewExpenses;

  set add_expenses(bool value) => this.addExpenses = value;
  bool get add_expenses => this.addExpenses;

  set edit_expenses(bool value) => this.editExpenses = value;
  bool get edit_expenses => this.editExpenses;

  set delete_expenses(bool value) => this.deleteExpenses = value;
  bool get delete_expenses => this.deleteExpenses;
}
