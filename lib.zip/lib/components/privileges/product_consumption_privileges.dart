class ProductConsumptionPrivileges {
  bool view_product_consumption = false;
  bool view_raw_material = false;
  bool view_product_consumption_management = false;
  bool view_product_consumption_report = false;

  bool view_raw_material_issue_list = false;
  bool view_raw_finished_product_reports = false;
  bool view_from_raw_material = false;
  bool view_create_raw_issue_note = false;
  bool viewRawMaterialRequestForm = false;

  set viewproduct_consumption(bool value) =>
      this.view_product_consumption = value;

  bool get viewproduct_consumption => this.view_product_consumption;

  set viewraw_material(bool value) => this.view_raw_material = value;

  bool get viewraw_material => this.view_raw_material;

  set viewproduct_consumption_management(bool value) =>
      this.view_product_consumption_management = value;

  bool get viewproduct_consumption_management =>
      this.view_product_consumption_management;

  set viewproduct_consumption_report(bool value) =>
      this.view_product_consumption_report = value;

  bool get viewproduct_consumption_report =>
      this.view_product_consumption_report;

  set viewrawMaterialIssueList(bool value) =>
      this.view_raw_material_issue_list = value;

  bool get viewrawMaterialIssueList => this.view_raw_material_issue_list;

  set viewfromRawMaterial(bool value) => this.view_from_raw_material = value;

  bool get viewfromRawMaterial => this.view_from_raw_material;

  set viewcreateRawIssuenote(bool value) =>
      this.view_create_raw_issue_note = value;

  bool get viewcreateRawIssuenote => this.view_create_raw_issue_note;

  set viewrawFinishedProductReports(bool value) =>
      this.view_raw_finished_product_reports = value;

  bool get viewrawFinishedProductReports =>
      this.view_raw_finished_product_reports;

  set viewrawmaterialrequestform(bool value) =>
      this.viewRawMaterialRequestForm = value;

  bool get viewrawmaterialrequestform => this.viewRawMaterialRequestForm;
}
