class ConnectionPrivileges {
  bool place_order_to_connections = false;
  bool add_connection_products_to_catalogue = false;
  bool add_edit_connection_sales_terms = false;
  bool connection_product_view = false;
  bool connection_view = false;
  bool connection_details_view = false;
  bool viewOfflineConnectionsList = false;
  bool createOfflineConnection = false;
  bool editOfflineConnection = false;
  bool removeOfflineConnection = false;
  bool viewConnectionTransactionHistory = false;
  bool viewAddAssignUser = false;
  bool viewAddDistributor = false;
  bool viewDirectOrder = false;

  bool get placeorder_to_connections => place_order_to_connections;

  set placeorder_to_connections(bool value) =>
      place_order_to_connections = value;

  bool get addconnection_products_to_catalogue =>
      add_connection_products_to_catalogue;

  set addconnection_products_to_catalogue(bool value) =>
      add_connection_products_to_catalogue = value;

  bool get addedit_connection_sales_terms => add_edit_connection_sales_terms;

  set addedit_connection_sales_terms(bool value) =>
      add_edit_connection_sales_terms = value;

  bool get connectionproduct_view => connection_product_view;

  set connectionproduct_view(bool value) => connection_product_view = value;

  bool get connectionview => connection_view;

  set connectionview(bool value) => connection_view = value;

  bool get connectiondetails_view => connection_details_view;

  set connectiondetails_view(bool value) => connection_details_view = value;

  set viewofflineconnectionslist(bool value) =>
      this.viewOfflineConnectionsList = value;
  bool get viewofflineconnectionslist => this.viewOfflineConnectionsList;

  set createofflineconnection(bool value) =>
      this.createOfflineConnection = value;
  bool get createofflineconnection => this.createOfflineConnection;

  set editofflineconnection(bool value) => this.editOfflineConnection = value;
  bool get editofflineconnection => this.editOfflineConnection;

  set removeofflineconnection(bool value) =>
      this.removeOfflineConnection = value;
  bool get removeofflineconnection => this.removeOfflineConnection;

  set viewconnectiontransactionhistory(bool value) =>
      this.viewConnectionTransactionHistory = value;
  bool get viewconnectiontransactionhistory =>
      this.viewConnectionTransactionHistory;

  set viewaddassignuser(bool value) => this.viewAddAssignUser = value;
  bool get viewaddassignuser => this.viewAddAssignUser;

  set viewadddistributor(bool value) => this.viewAddDistributor = value;
  bool get viewadddistributor => this.viewAddDistributor;

  set viewdirectorder(bool value) => this.viewDirectOrder = value;
  bool get viewdirectorder => this.viewDirectOrder;
}
