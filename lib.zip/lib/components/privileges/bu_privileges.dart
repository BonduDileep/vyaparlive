class BuPrivileges {
  bool business_unit_package_view = false;
  bool bu_product_offer_view = false;
  bool bu_product_view = false;
  bool bu_location_delete = false;
  bool bu_location_edit = false;
  bool bu_location_view = false;
  bool business_unit_view = false;
  bool business_unit_role_view = false;
  bool business_unit_role_edit = false;
  bool business_unit_role_delete = false;
  bool business_unit_role_create = false;
  bool business_unit_location_create = false;
  bool edit_business_unit = false;
  bool delete_business_unit = false;
  bool add_business_unit = false;

  bool get businessunit_package_view => business_unit_package_view;

  set businessunit_package_view(bool value) =>
      business_unit_package_view = value;

  bool get buproduct_offer_view => bu_product_offer_view;

  set buproduct_offer_view(bool value) => bu_product_offer_view = value;

  bool get buproduct_view => bu_product_view;

  set buproduct_view(bool value) => bu_product_view = value;

  bool get bulocation_delete => bu_location_delete;

  set bulocation_delete(bool value) => bu_location_delete = value;

  bool get bulocation_edit => bu_location_edit;

  set bulocation_edit(bool value) => bu_location_edit = value;

  bool get bulocation_view => bu_location_view;

  set bulocation_view(bool value) => bu_location_view = value;

  bool get businessunit_view => business_unit_view;

  set businessunit_view(bool value) => business_unit_view = value;

  bool get businessunit_role_view => business_unit_role_view;

  set businessunit_role_view(bool value) => business_unit_role_view = value;

  bool get businessunit_role_edit => business_unit_role_edit;

  set businessunit_role_edit(bool value) => business_unit_role_edit = value;

  bool get businessunit_role_delete => business_unit_role_delete;

  set businessunit_role_delete(bool value) => business_unit_role_delete = value;

  bool get businessunit_role_create => business_unit_role_create;

  set businessunit_role_create(bool value) => business_unit_role_create = value;

  bool get businessunit_location_create => business_unit_location_create;

  set businessunit_location_create(bool value) =>
      business_unit_location_create = value;

  bool get editbusiness_unit => edit_business_unit;

  set editbusiness_unit(bool value) => edit_business_unit = value;

  bool get deletebusiness_unit => delete_business_unit;

  set deletebusiness_unit(bool value) => delete_business_unit = value;

  bool get addbusiness_unit => add_business_unit;

  set addbusiness_unit(bool value) => add_business_unit = value;
}
