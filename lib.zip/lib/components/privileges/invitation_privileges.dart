class InvitationPrivileges {
  bool invitation_reject = false;
  bool invitation_accept = false;
  bool invitation_view = false;
  bool invitation_create = false;

  bool get invitationreject => invitation_reject;

  set invitationreject(bool value) => invitation_reject = value;

  bool get invitationaccept => invitation_accept;

  set invitationaccept(bool value) => invitation_accept = value;

  bool get invitationview => invitation_view;

  set invitationview(bool value) => invitation_view = value;

  bool get invitationcreate => invitation_create;

  set invitationcreate(bool value) => invitation_create = value;
}
