class TransactionPrivileges {
  bool view_transaction = false;
  bool view_payment_details = false;
  bool stock_add_update_resolution = false;
  bool view_resolution = false;
  bool receive_stocks = false;
  bool view_payment_reconciliation = false;
  bool view_stock_reconciliation = false;
  bool view_reconciliation = false;
  bool in_direct_delivery = false;
  bool direct_delivery = false;
  bool add_edit_delivery = false;
  bool view_delivery = false;
  bool self_packing = false;
  bool assign_user = false;
  bool update_packing = false;
  bool add_edit_packing = false;
  bool view_packing = false;
  bool view_invoice = false;
  bool generate_invoice = false;
  bool reject_po = false;
  bool accept_po = false;
  bool view_po = false;
  bool accept_confirmation_message = false;
  bool update_confirmation_order = false;
  bool edit_confirmation_message = false;
  bool view_confirmation_message = false;
  bool add_discussion = false;
  bool view_discussion = false;
  bool connection_start_discussion = false;
  bool connection_place_order = false;

  bool get viewtransaction => view_transaction;

  set viewtransaction(bool value) => view_transaction = value;

  bool get viewpayment_details => view_payment_details;

  set viewpayment_details(bool value) => view_payment_details = value;

  bool get stockadd_update_resolution => stock_add_update_resolution;

  set stockadd_update_resolution(bool value) =>
      stock_add_update_resolution = value;

  bool get viewresolution => view_resolution;

  set viewresolution(bool value) => view_resolution = value;

  bool get receivestocks => receive_stocks;

  set receivestocks(bool value) => receive_stocks = value;

  bool get viewpayment_reconciliation => view_payment_reconciliation;

  set viewpayment_reconciliation(bool value) =>
      view_payment_reconciliation = value;

  bool get viewstock_reconciliation => view_stock_reconciliation;

  set viewstock_reconciliation(bool value) => view_stock_reconciliation = value;

  bool get viewreconciliation => view_reconciliation;

  set viewreconciliation(bool value) => view_reconciliation = value;

  bool get indirect_delivery => in_direct_delivery;

  set indirect_delivery(bool value) => in_direct_delivery = value;

  bool get directdelivery => direct_delivery;

  set directdelivery(bool value) => direct_delivery = value;

  bool get addedit_delivery => add_edit_delivery;

  set addedit_delivery(bool value) => add_edit_delivery = value;

  bool get viewdelivery => view_delivery;

  set viewdelivery(bool value) => view_delivery = value;

  bool get selfpacking => self_packing;

  set selfpacking(bool value) => self_packing = value;

  bool get assignuser => assign_user;

  set assignuser(bool value) => assign_user = value;

  bool get updatepacking => update_packing;

  set updatepacking(bool value) => update_packing = value;

  bool get addedit_packing => add_edit_packing;

  set addedit_packing(bool value) => add_edit_packing = value;

  bool get viewpacking => view_packing;

  set viewpacking(bool value) => view_packing = value;

  bool get viewinvoice => view_invoice;

  set viewinvoice(bool value) => view_invoice = value;

  bool get generateinvoice => generate_invoice;

  set generateinvoice(bool value) => generate_invoice = value;

  bool get rejectpo => reject_po;

  set rejectpo(bool value) => reject_po = value;

  bool get acceptpo => accept_po;

  set acceptpo(bool value) => accept_po = value;

  bool get viewpo => view_po;

  set viewpo(bool value) => view_po = value;

  bool get acceptconfirmation_message => accept_confirmation_message;

  set acceptconfirmation_message(bool value) =>
      accept_confirmation_message = value;

  bool get updateconfirmation_order => update_confirmation_order;

  set updateconfirmation_order(bool value) => update_confirmation_order = value;

  bool get editconfirmation_message => edit_confirmation_message;

  set editconfirmation_message(bool value) => edit_confirmation_message = value;

  bool get viewconfirmation_message => view_confirmation_message;

  set viewconfirmation_message(bool value) => view_confirmation_message = value;

  bool get adddiscussion => add_discussion;

  set adddiscussion(bool value) => add_discussion = value;

  bool get viewdiscussion => view_discussion;

  set viewdiscussion(bool value) => view_discussion = value;

  bool get connectionstart_discussion => connection_start_discussion;

  set connectionstart_discussion(bool value) =>
      connection_start_discussion = value;

  bool get connectionplace_order => connection_place_order;

  set connectionplace_order(bool value) => connection_place_order = value;

  setDefaultTvalues() {}
}
