class UserPrivileges {
  bool user_view = false;
  bool user_creation = false;
  bool user_edit = false;
  bool user_delete = false;

  bool get userview => user_view;

  set userview(bool value) => user_view = value;

  bool get usercreation => user_creation;

  set usercreation(bool value) => user_creation = value;

  bool get useredit => user_edit;

  set useredit(bool value) => user_edit = value;

  bool get userdelete => user_delete;

  set userdelete(bool value) => user_delete = value;
}
