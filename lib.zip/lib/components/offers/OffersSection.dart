import 'package:flutter/material.dart';

import '../../config/Language.dart';
import '../../model/OffersModel.dart';
import '../Constants.dart';
import '../text_styles.dart';

class OffersSection extends StatelessWidget {
  final String buttonText;
  final String selectedLang;
  final String currencySymbol;
  final List<OffersModel> offers;
  final OffersModel? selectedOffer;
  final ValueChanged<OffersModel> onOfferSelected;

  const OffersSection({
    super.key,
    required this.buttonText,
    required this.selectedLang,
    required this.currencySymbol,
    required this.offers,
    required this.onOfferSelected,
    this.selectedOffer,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      alignment: Alignment.centerLeft,
      child: InkWell(
        onTap: () => _showOffers(context),
        child: Text(
          selectedOffer?.offerName != null
              ? "Offer: ${selectedOffer?.offerName} applied"
              : buttonText,
          style: CustomTextStyle.textButtonStyle(
              color: selectedOffer?.offerName != null
                  ? const Color.fromARGB(255, 19, 158, 23)
                  : const Color(Constants.APP_COLOR)),
        ),
      ),
    );
  }

  Future<void> _showOffers(BuildContext context) async {
    final selected = await showDialog<OffersModel>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(Language().getString(Constants.OFFERS, selectedLang)),
        content: SizedBox(
          width: double.maxFinite,
          child: offers.isEmpty
              ? Text(Language().getString("No offers available", selectedLang))
              : ConstrainedBox(
                  constraints: BoxConstraints(
                    maxHeight: MediaQuery.of(context).size.height * 0.6,
                  ),
                  child: ListView.separated(
                    shrinkWrap: true,
                    itemCount: offers.length,
                    separatorBuilder: (context, index) =>
                        const Divider(height: 1),
                    itemBuilder: (context, index) {
                      final offer = offers[index];
                      final isPercentage =
                          offer.offerDiscount == Constants.OFFER_IN_PERCENTAGE;
                      final discountLabel = isPercentage
                          ? "${offer.offerQuantity} %"
                          : "$currencySymbol ${offer.offerQuantity}";
                      final details = (offer.details ?? "").trim();

                      return ListTile(
                        title: Text(offer.offerName ?? ""),
                        subtitle: Text([
                          discountLabel,
                          if (details.isNotEmpty) details,
                        ].join(" - ")),
                        trailing: offer == selectedOffer
                            ? const Icon(Icons.check, color: Colors.green)
                            : null,
                        onTap: () => Navigator.of(context).pop(offer),
                      );
                    },
                  ),
                ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text(Language().getString("Close", selectedLang)),
          ),
        ],
      ),
    );

    if (selected != null) {
      onOfferSelected(selected);
    }
  }
}
