import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../config/Language.dart';
import '../Constants.dart';
import '../text_styles.dart';

class AdditionalChargeButton extends StatelessWidget {
  final String buttonText;
  final String selectedLang;
  final Function(String field1, String field2) onAdd;

  const AdditionalChargeButton(
      {Key? key,
      required this.buttonText,
      required this.onAdd,
      required this.selectedLang})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      alignment: Alignment.centerLeft,
      child: InkWell(
        onTap: () => _showDialog(context),
        child: Text(buttonText, style: CustomTextStyle.textButtonStyle()),
      ),
    );
  }

  void _showDialog(BuildContext context) {
    final TextEditingController field1Controller = TextEditingController();
    final TextEditingController field2Controller = TextEditingController();

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(Language().getString("Additional Charges", selectedLang)),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: field1Controller,
                textCapitalization: TextCapitalization.sentences,
                decoration: InputDecoration(
                    labelText: Language()
                        .getString("Additional charge for", selectedLang)),
              ),
              const SizedBox(height: 10),
              TextField(
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                inputFormatters: [
                  FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d{0,2}')),
                ],
                controller: field2Controller,
                decoration: InputDecoration(
                    labelText: Language().getString("Amount", selectedLang)),
              ),
            ],
          ),
          actions: [
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(Constants.APP_COLOR),
              ),
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text(Language().getString("Close", selectedLang)),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(Constants.APP_COLOR),
              ),
              onPressed: () {
                final field1 = field1Controller.text;
                final field2 = field2Controller.text;
                if (field1.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                        backgroundColor: Colors.red,
                        content: Text(
                          Language().getString(
                              'Please enter Additional charge for.',
                              selectedLang),
                          textAlign: TextAlign.center,
                        )),
                  );
                  return;
                }
                if (field2.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                        backgroundColor: Colors.red,
                        content: Text(
                          Language()
                              .getString('Please enter Amount.', selectedLang),
                          textAlign: TextAlign.center,
                        )),
                  );
                  return;
                }
                final formattedField2 = double.parse(field2).toStringAsFixed(2);
                onAdd(field1, formattedField2);
                Navigator.of(context).pop();
              },
              child: Text(Language().getString("Add", selectedLang)),
            ),
          ],
        );
      },
    );
  }
}
