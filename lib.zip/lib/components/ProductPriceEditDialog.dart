import 'package:flutter/services.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:flutter/material.dart';
import '../config/Language.dart';
import '../utills/CommonButtonsView.dart';
import 'StyleView.dart';

Future<void> productPricdeEditDialog(
    {required BuildContext context,
    required String price,
    required VoidCallback onEdit,
    required VoidCallback onCancel,
    required Function(String)? onReadText,
    required String? selectedLang}) async {
  return showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        actions: [
          Container(
            width: MediaQuery.of(context).size.width,
            padding: EdgeInsets.only(bottom: 10),
            child: CommonButtonsView(
              context: context,
              b1Text: Language().getString(Constants.STR_CANCEL, selectedLang),
              b2Text:
                  Language().getString(Constants.UPDATE_PRICE, selectedLang),
              onb1Action: () => onCancel(),
              onb2Action: () => onEdit(),
            ),
          )
        ],
        title: Container(
          child: Text(Language().getString(Constants.EDIT_PRODUCT_PRICE, "en"),
              style: TextStyle(fontSize: 15.0, fontWeight: FontWeight.bold)),
        ),
        content: Container(
          height: 50.0,
          child: Padding(
            padding: const EdgeInsets.only(left: 0),
            child: Card(
              elevation: 2.5,
              shape: new RoundedRectangleBorder(
                  borderRadius: new BorderRadius.circular(8),
                  side: new BorderSide(
                      color: Color(Constants.APP_COLOR), strokeAlign: 0.01)),
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: Container(
                      padding: EdgeInsets.only(left: 8),
                      child: TextFormField(
                        onChanged: onReadText!,
                        keyboardType: TextInputType.number,
                        inputFormatters: <TextInputFormatter>[
                          FilteringTextInputFormatter
                              .digitsOnly, // Allows only digits
                        ],
                        initialValue: price,
                        style: TextStyle(
                            fontWeight: StyleView.fontMedium,
                            color: Colors.black,
                            fontSize: 15),
                        decoration: InputDecoration(
                            contentPadding: EdgeInsets.only(bottom: 8),
                            border: InputBorder.none,
                            hintText: "hintText",
                            hintStyle: TextStyle(
                                color: Colors.black,
                                fontSize: 15,
                                fontWeight: StyleView.fontMedium)),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    },
  );
}
