import 'package:connectivity_plus/connectivity_plus.dart';

class NetworkStatus {
  // static Future<bool> getInternetStatus() async {
  //   var connectivityResult = await (Connectivity().checkConnectivity());
  //   if (connectivityResult == ConnectivityResult.mobile) {
  //     return true;
  //   } else if (connectivityResult == ConnectivityResult.wifi) {
  //     return true;
  //   }
  //   return false;
  // }

  static Future<bool> getInternetStatus() async {
    final List<ConnectivityResult> results =
        await Connectivity().checkConnectivity();

    // Check if any of the results indicate internet connectivity
    if (results.contains(ConnectivityResult.mobile) ||
        results.contains(ConnectivityResult.wifi) ||
        results.contains(ConnectivityResult.ethernet)) {
      return true;
    }
    return false;
  }
}
