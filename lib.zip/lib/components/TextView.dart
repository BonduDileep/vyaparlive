import 'package:flutter/material.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:flutx/widgets/widgets.dart';

class TextView extends StatelessWidget {
  final String? title;
  final String? value;
  final double? titleFontSize;
  final double? valueFontsize;
  TextView(
      {required this.title,
      required this.value,
      this.titleFontSize = 14.0,
      this.valueFontsize = 14.0});
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Row(
        children: <Widget>[
          Expanded(
            child: Container(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                      child: FxText.displayMedium("$title",
                          style: TextStyle(
                              fontSize: titleFontSize,
                              color: Colors.black,
                              fontWeight: StyleView.fontSemiBold))),
                )),
          ),
          Text(" : "),
          Expanded(
              flex: 1,
              child: Container(
                alignment: Alignment.centerLeft,
                child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: FxText.displayMedium("${value != null ? value : ""}",
                        style: TextStyle(
                            fontSize: valueFontsize,
                            color: Colors.black,
                            fontWeight: StyleView.fontMedium))),
              )),
        ],
      ),
    );
  }
}
