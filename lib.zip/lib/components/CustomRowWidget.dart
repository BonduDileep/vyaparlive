import 'package:flutter/material.dart';
import 'package:vyaparlive/components/Constants.dart';

class CustomRowWidget extends StatelessWidget {
  final String? title;
  final String? value;
  final double titleTextSize;
  final FontWeight titleFont;
  final Color titleColor;
  final double valueTextSize;
  final FontWeight valueFont;
  final Color? valueColor;
  final num titleFlex;
  final num valueFlex;
  final double titlePadding;
  final double valuePadding;
  const CustomRowWidget({
    required this.title,
    required this.value,
    this.titleColor = const Color(Constants.APP_COLOR),
    this.titleFont = FontWeight.w800,
    this.titleTextSize = 15.0,
    this.valueColor = const Color(Constants.APP_COLOR),
    this.valueFont = FontWeight.w400,
    this.valueTextSize = 13.0,
    this.titleFlex = 1,
    this.valueFlex = 2,
    this.titlePadding = 2.0,
    this.valuePadding = 2.0,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Row(
        // crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
              child: Padding(
            padding: EdgeInsets.all(titlePadding),
            child: Text(
              "$title",
              style: TextStyle(
                  color: titleColor,
                  fontSize: titleTextSize,
                  fontWeight: titleFont),
            ),
          )),
          Text("  : "),
          Expanded(
              flex: valueFlex as int,
              child: Padding(
                padding: EdgeInsets.all(valuePadding),
                child: Text(
                  "$value",
                  style: TextStyle(
                      color: valueColor,
                      fontSize: valueTextSize,
                      fontWeight: valueFont),
                ),
              )),
        ],
      ),
    );
  }
}
