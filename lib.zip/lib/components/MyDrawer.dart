import 'dart:convert';
import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:mime/mime.dart';
import 'package:vyaparlive/Reports/ConsumableGoodsReports.dart';
import 'package:vyaparlive/Reports/ProfitLossReport.dart';
import 'package:vyaparlive/challan/ChallanView.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Dialog.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/core/enums/privilleges_enum.dart';
import 'package:vyaparlive/help/HelpChatScreenView.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/ondc_menu/OndcInvoiceView.dart';
import 'package:vyaparlive/order_form/OrderFormOrders.dart';
import 'package:vyaparlive/product_consumption_view/raw_material_view/RawMaterialInventoryPage.dart';
import 'package:vyaparlive/quotation/QuotationView.dart';
import 'package:vyaparlive/redux/actions/reset_data.dart';
import 'package:vyaparlive/retailer_view/ssf_crm/RetailOffers.dart';
import 'package:vyaparlive/service/api_service/UploadImageApiService.dart';
import 'package:vyaparlive/service/user_services.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Home/HomeInventory.dart';
import 'package:vyaparlive/Home/HomePageView.dart';
import 'package:vyaparlive/Invitation/DashboardView.dart';
import 'package:vyaparlive/Invitation/InviteDashboard.dart';
import 'package:vyaparlive/Organization/AllBUListPage.dart';
import 'package:vyaparlive/Reports/analysis_reports_view/StockReturnReports.dart';
import 'package:vyaparlive/Reports/analysis_reports_view/AnalysisReportsTopics.dart';
import 'package:vyaparlive/Reports/BuyReports.dart';
import 'package:vyaparlive/Reports/ConsumableProductReports.dart';
import 'package:vyaparlive/Reports/RawAndFinalProductReports.dart';
import 'package:vyaparlive/Reports/SalesReports.dart';
import 'package:vyaparlive/Reports/distributor_reports/UserReportsPage.dart';
import 'package:vyaparlive/Reports/products_reports/ProductLogReports.dart';
import 'package:vyaparlive/Reports/products_reports/ProductReports.dart';
import 'package:vyaparlive/Reports/retail_customer_reports/RetailCustomerReports.dart';
import 'package:vyaparlive/Users/UsersDetailsPage.dart';
import 'package:vyaparlive/offline_connections/OfflineConnections.dart';
import 'package:vyaparlive/offline_connections/CreateOfflineCustomerPage.dart';
import 'package:vyaparlive/notifications_view/NotificationPage.dart';
import 'package:vyaparlive/orders_view/OrdersPage.dart';
import 'package:vyaparlive/Product/ProductsMenuPage.dart';
import 'package:vyaparlive/Subscription/SubscriptionScreen.dart';
import 'package:vyaparlive/Transaction/TransactionsPage.dart';
import 'package:vyaparlive/Users/UsersListPage.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/BuBasicDataModel.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:vyaparlive/product_consumption_view/CosumableProductList.dart';
import 'package:vyaparlive/product_consumption_view/raw_material_view/ConfigureRawTemplate.dart';
import 'package:vyaparlive/product_consumption_view/raw_material_view/RawMaterialTabView.dart';
import 'package:vyaparlive/product_consumption_view/raw_material_view/RawProductsList.dart';
import 'package:vyaparlive/product_consumption_view/raw_material_view/request_form/CreateRawRequestForm.dart';
import 'package:vyaparlive/retailer_view/RetailerDashboard.dart';
import 'package:vyaparlive/roles_view/RolesList.dart';
import 'package:vyaparlive/services_management/services_list_page.dart';
import 'package:vyaparlive/splash_view/MoreOptionsPage.dart';
import 'package:vyaparlive/stock_returns_view/StockReturnsPage.dart';
import 'package:vyaparlive/utills/SharePref.dart';
import 'package:vyaparlive/connections_view/ContactsPage.dart';

import '../Reports/RawMaterialIOReport.dart';
import '../expenses_view/ExpensesPage.dart';
import '../login_view/LoginPage.dart';
import '../ondc_menu/OndcOrdersView.dart';
import '../ondc_menu/OndcProfile.dart';
import '../product_consumption_view/consumable_goods_view/ConfigureConsumableTemplate.dart';
import '../product_consumption_view/consumable_goods_view/ConsumableInventoryPage.dart';
import '../product_consumption_view/consumable_goods_view/ConsumableProductsList.dart';
import '../product_consumption_view/consumable_goods_view/ConsumableTabView.dart';
import '../product_consumption_view/consumable_goods_view/request_form/CreateConsumableRequestForm.dart';
import '../redux/state/app_state.dart';

class MyDrawer extends StatefulWidget {
  final List<BuBasicDataModel>? buList;
  MyDrawer({this.buList});
  @override
  MyDrawerState createState() => MyDrawerState();
}

class MyDrawerState extends State<MyDrawer> with TickerProviderStateMixin {
  String? out;
  bool isActiveLanguage = false;
  String? selectedLang = AppController.instance.getSelectedlanguage; // 'en';
  late SharedPreferences sharedPreferences;
  String? userMobile = "";
  String? getVersion;
  double? _elevation;
  String? userId = "";
  String? userName = "";
  String? loginUserRole = "";
  Color? iconsColor; //= Color(Constants.APP_COLOR);
  Color? itemsColor; //= Colors.black;
  FontWeight? itemFontWeight;
  double? itemsFontSize;
  late bool isShowMultiLevelMenu = false;
  bool isSelectCaptureChoice = false;
  Uint8List? _webImage;
  File? imageFile;
  String? imageBlob = '';
  String? buId = "";
  bool isLoadingProgress = false;
  bool isImageUpdated = false;
  String? profile_pic = "";

  late UserService _userService;

  @override
  void initState() {
    super.initState();
    _userService = UserService();
    itemsFontSize = 13.0;
    _elevation = 0;
    iconsColor = Colors.black;
    itemsColor = Colors.black;
    itemFontWeight = StyleView.fontSemiBold;
    if (AppController.instance.getLoginUserRole != null) {
      loginUserRole = AppController.instance.getLoginUserRole;
    }
    SharePref().getPhoneNumber().then((onValue) {
      if (mounted) {
        setState(() {
          userMobile = onValue;
        });
      }
    });

    SharePref().getUserId().then((value) {
      if (mounted) {
        setState(() {
          userId = value;
        });
      }
    });
    SharePref().getUserName().then((value) {
      if (mounted) {
        setState(() {
          userName = value;
        });
      }
    });
    SharePref().getProfilePic().then((value) {
      if (mounted) {
        setState(() {
          profile_pic = value;
        });
      }
    });
  }

  @override
  void dispose() {
    super.dispose();
  }

  showAlert(String message) {
    return showDialog(
        barrierDismissible: false,
        context: (context),
        builder: (context) {
          return AlertDialog(
            content: Text(Language().getString(message, selectedLang)),
            actions: <Widget>[
              TextButton(
                child: new Text(
                    Language().getString(Constants.OKAY_STR, selectedLang),
                    style: TextStyle(
                        color: Color(Constants.APP_COLOR), fontSize: 18.0)),
                onPressed: () {
                  Navigator.pop(context);
                  Navigator.of(context).pop();
                },
              ),
            ],
          );
        });
  }

  Future<void> uploadImage(
      {required var fileImage,
      required String fileName,
      required String fileType,
      required String locationName}) async {
    if (!kIsWeb && mounted) {
      Navigator.of(context).pop();
    }
    if (fileImage != null) {
      if (mounted) {
        setState(() {
          // imageFile = fileImage;
          isLoadingProgress = true;
        });
      }
      // List<String> fileName = imageFile!.path.split('/');
      final String fetchRelativeImagePath = await UploadImageApiService.instance
          .fileUpload(
              imageData: fileImage,
              fileName: fileName,
              fileType: fileType,
              location: locationName);
      if (mounted) {
        setState(() => isLoadingProgress = false);
      }
      if (fetchRelativeImagePath.isNotEmpty && mounted) {
        // imageRelativePath = fetchRelativeImagePath;
        updateUserProfilePic(fetchRelativeImagePath);
      }
    }
  }

  updateUserProfilePic(String profilePic) async {
    Map data = {
      "id": userId,
      "profile_pic": profilePic,
    };
    String body = json.encode(data);

    var response = await _userService
        .updateUser_grpc(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      if (mounted) {
        setState(() {
          isLoadingProgress = false;
        });
        await Dialogs.yesCancelDialog(
            context,
            Language().getString(Constants.ERROR, selectedLang),
            onError.toString(),
            Language().getString(Constants.OKAY_STR, selectedLang),
            "",
            false);
      }
    });

    if (mounted) {
      setState(() {
        isLoadingProgress = false;
      });
    }

    if (!mounted) return;

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      SharePref().saveProfilePic(profilePic);
      if (mounted) {
        setState(() {
          profile_pic = profilePic;
        });
      }
      if (mounted) {
        Dialogs.yesCancelDialog(
            context,
            Language().getString(Constants.SUCCESS, selectedLang),
            Language().getString(Constants.USER_UPDATE_SUCCESS, selectedLang),
            Language().getString(Constants.OKAY_STR, selectedLang),
            "",
            false);
      }
    } else {
      if (mounted) {
        Dialogs.yesCancelDialog(
            context,
            Language().getString(Constants.ERROR, selectedLang),
            _grpcResponse.message!,
            Language().getString(Constants.OKAY_STR, selectedLang),
            "",
            false);
      }
    }
  }

  Widget displayImageView() {
    return InkWell(
      onTap: () async {
        if (kIsWeb) {
          final _file = await Dialogs.getWebImage();
          if (_file != null) {
            _webImage = await _file.readAsBytes();
            setState(() {
              isSelectCaptureChoice = true;
            });
            uploadImage(
                fileImage: _webImage,
                fileName: "profile_pic_${_file.name}",
                fileType: _file.mimeType == 'pdf'
                    ? 'application/pdf'
                    : 'image/${_file.mimeType}',
                locationName: "profile_pic");
          }
        } else {
          this.openBottomSheet(context);
        }
      },
      child: AspectRatio(
        aspectRatio: 10 / 9,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: _buildImage(),
        ),
      ),
    );
    // child: isSelectCaptureChoice
    //     ? Container(
    //         child: (kIsWeb)
    //             ? AspectRatio(
    //                 aspectRatio: 10 / 9,
    //                 child: ClipRRect(
    //                     borderRadius: BorderRadius.circular(20),
    //                     child: Image.memory(_webImage!)))
    //             : AspectRatio(
    //                 aspectRatio: 10 / 9,
    //                 child: ClipRRect(
    //                   borderRadius: BorderRadius.circular(20),
    //                   child: Image.file(
    //                     imageFile!,
    //                     fit: BoxFit.fitWidth,
    //                     gaplessPlayback: true,
    //                   ),
    //                 )))
    //     : AspectRatio(
    //         aspectRatio: 10 / 9,
    //         child: ClipRRect(
    //             borderRadius: BorderRadius.circular(20),
    //             child: Image.asset('assets/images/empty.jpg',
    //                 fit: BoxFit.cover,
    //                 gaplessPlayback: true,
    //                 height: 150,
    //                 width: MediaQuery.of(context).size.width))));
  }

  Widget _buildImage() {
    // /// 1️⃣ Picked image (Web)
    // if (kIsWeb && isSelectCaptureChoice && _webImage != null) {
    //   return Image.memory(
    //     _webImage!,
    //     fit: BoxFit.cover,
    //   );
    // }

    // /// 2️⃣ Picked image (Mobile)
    // if (!kIsWeb && isSelectCaptureChoice && imageFile != null) {
    //   return Image.file(
    //     imageFile!,
    //     fit: BoxFit.cover,
    //     gaplessPlayback: true,
    //   );
    // }

    /// 3️⃣ Existing network image
    if (profile_pic != null && profile_pic!.isNotEmpty) {
      print("profile_pic $profile_pic");
      return CachedNetworkImage(
        imageUrl: '${Constants.IAMGE_BUCKET_URL}$profile_pic',
        fit: BoxFit.fitWidth,
        // height: MediaQuery.of(context).size.height * 0.2,
        errorWidget: (context, url, error) => Icon(Icons.error),
      );
    }

    /// 4️⃣ Default asset image
    return _emptyImage();
  }

  Widget _emptyImage() {
    return Image.asset(
      'assets/images/empty.jpg',
      fit: BoxFit.cover,
    );
  }

  openBottomSheet(BuildContext context) {
    return Dialogs.openBottomSheet(
        context: context,
        openCamera: (myPicture) async {
          this.updateProductImage(myPicture);
        },
        openGallery: (myPicture) async {
          this.updateProductImage(myPicture);
        });
  }

  void updateProductImage(var fileImage) {
    if (fileImage != null) {
      if (mounted) {
        setState(() {
          imageFile = fileImage;
          isSelectCaptureChoice = true;
          isImageUpdated = true;
          imageBlob = AppUtills.getBase64Image(fileImage, context);
        });
      }
      List<String> fileName = fileImage!.path.split('/');
      uploadImage(
          fileImage: fileImage,
          fileName: "profile_pic_${fileName.last}",
          fileType: lookupMimeType(imageFile!.path)!,
          locationName: "profile_pic");
    }
    if (mounted) {
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Drawer(
            backgroundColor: Colors.white,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0)),
            child: Column(
              children: [
                DrawerHeader(
                  child: UserAccountsDrawerHeader(
                    decoration: BoxDecoration(
                        color: AppTheme.theme.colorScheme.primaryContainer,
                        borderRadius: BorderRadius.circular(10)),
                    accountName: Padding(
                        padding: EdgeInsets.only(top: 10),
                        child: Text(
                          "$userName" +
                              (loginUserRole != null &&
                                      loginUserRole!.isNotEmpty
                                  ? "($loginUserRole)"
                                  : ""),
                          style: TextStyle(
                            fontSize: 15,
                            fontWeight: StyleView.fontSemiBold,
                            color: Colors.black,
                          ),
                        )),
                    accountEmail: Text(
                      userMobile!,
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.black,
                        fontWeight: StyleView.fontMedium,
                      ),
                    ),
                    currentAccountPictureSize: Size.square(45),
                    currentAccountPicture: CircleAvatar(
                        backgroundColor: Colors.black45,
                        child: displayImageView()),
                  ),
                ),
                Expanded(
                  child: ListView(
                    padding: EdgeInsets.zero,
                    children: <Widget>[
                      Container(
                          margin: EdgeInsets.symmetric(horizontal: 7),
                          child: (AppController.instance.buList != null &&
                                  AppController.instance.buList!.length == 0)
                              ? showDummyMenu()
                              : showActualMenu()),
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.symmetric(vertical: 16.0),
                  alignment: Alignment.bottomCenter,
                  child: Text(
                    Language().getString("Version", selectedLang) +
                        " ${Constants.APP_VERSION}",
                    style: TextStyle(
                        color: Colors.black, fontWeight: StyleView.fontMedium),
                  ),
                )
              ],
            )),
      ),
    );
  }

  showDummyMenu() {
    return Column(children: [
      homeCardView(),
      ourOrganizationCardView(),
      ourPeopleCardView(),
      transactionsCardView(),
      retailSalesCardView(),
      logoutCardView(),
    ]);
  }

  showActualMenu() {
    return Column(children: [
      if (CommonMethods.isPrivillegeExist(context, PrivillegesActions.KEY_HOME))
        homeCardView(),
      if (CommonMethods.isPrivillegeExist(
          context, PrivillegesActions.KEY_MY_COMPANY))
        ourOrganizationCardView(),
      if (CommonMethods.isPrivillegeExist(
          context, PrivillegesActions.KEY_WORK_FORCE))
        ourPeopleCardView(),
      if (CommonMethods.isPrivillegeExist(
          context, PrivillegesActions.KEY_PRODUCTS))
        productAndInventoryCardView(),
      servicesCardView(),
      if (CommonMethods.isPrivillegeExist(
          context, PrivillegesActions.KEY_TRANSACTIONS))
        transactionsCardView(),
      if (CommonMethods.isPrivillegeExist(
          context, PrivillegesActions.KEY_ORDERS))
        ordersCardView(),
      if (CommonMethods.isPrivillegeExist(
          context, PrivillegesActions.KEY_QUOTATIONS))
        quotationCardView(),
      // if (CommonMethods.isPrivillegeExist(
      //     context, PrivillegesActions.KEY_TRANSACTIONS))
      //   challanCardView(),
      if (CommonMethods.isPrivillegeExist(
          context, PrivillegesActions.KEY_CUSTOMERS))
        businessConnectionsCardView(),
      // fieldSalesInpersonOrdersCardView(),
      if (CommonMethods.isPrivillegeExist(
          context, PrivillegesActions.KEY_MENU_ONDC_TAB))
        ondcCardView(),
      if (CommonMethods.isPrivillegeExist(
          context, PrivillegesActions.SSF_CRM_MENU))
        ssfCRMOptions(),
      if (CommonMethods.isPrivillegeExist(
          context, PrivillegesActions.KEY_RETAIL_SALES))
        retailSalesCardView(),
      if (CommonMethods.isPrivillegeExist(
          context, PrivillegesActions.KEY_RAW_MATERIAL_TAB))
        rawMaterialCardView(),
      if (CommonMethods.isPrivillegeExist(
          context, PrivillegesActions.KEY_CONSUMABLE_MATERIAL_TAB))
        consumableMaterialCardView(),
      // this.stockReturnsCardView(),
      if (CommonMethods.isPrivillegeExist(
          context, PrivillegesActions.KEY_REPORTS))
        reportsCardView(),
      if (CommonMethods.isPrivillegeExist(
          context, PrivillegesActions.KEY_MORE_GENERAL_EXPENCES))
        generalExpensesCardView(),
      // this.notificationsView(),
      this.subscriptionCardView(),
      // needHelpCardView(),
      if (CommonMethods.isPrivillegeExist(context, PrivillegesActions.KEY_MORE))
        moreCardView(),

      logoutCardView(),
    ]);
  }

  Widget needHelpCardView() {
    return Card(
      elevation: _elevation,
      child: ListTile(
        title: Text(
            Language().getString(Constants.STR_NEED_HELP_CAPS, selectedLang),
            style: TextStyle(
                fontWeight: itemFontWeight,
                fontSize: itemsFontSize,
                color: itemsColor)),
        leading: Icon(Icons.support_agent, color: Colors.black),
        onTap: () {
          if (AppController.instance.buList != null &&
              AppController.instance.buList!.length == 0) {
            showAlert(Constants.CREATE_BU_INFO);
          } else {
            Navigator.pop(context);
            Navigator.push(context,
                PageTransition(context: context, page: HelpChatScreenView()));
          }
        },
      ),
    );
  }

  Widget servicesCardView() {
    return Card(
      elevation: _elevation,
      child: ListTile(
        title: Text('Services',
            style: TextStyle(
                fontWeight: itemFontWeight,
                fontSize: itemsFontSize,
                color: itemsColor)),
        leading: Icon(Icons.home_repair_service, color: iconsColor),
        onTap: () {
          if (AppController.instance.buList != null &&
              AppController.instance.buList!.isEmpty) {
            showAlert(Constants.CREATE_BU_INFO);
          } else {
            Navigator.pop(context);
            Navigator.push(
                context,
                PageTransition(
                    context: context, page: const ServicesListPage()));
          }
        },
      ),
    );
  }

  Widget generalExpensesCardView() {
    return Card(
      elevation: _elevation,
      child: ListTile(
        title: Text(
            Language()
                .getString(Constants.STR_GENERAL_EXPENSES_CAPS, selectedLang),
            style: TextStyle(
                fontWeight: itemFontWeight,
                fontSize: itemsFontSize,
                color: itemsColor)),
        leading: Icon(Icons.chrome_reader_mode, color: Colors.black),
        onTap: () {
          if (AppController.instance.buList != null &&
              AppController.instance.buList!.length == 0) {
            showAlert(Constants.CREATE_BU_INFO);
          } else {
            Navigator.pop(context);
            Navigator.push(context,
                PageTransition(context: context, page: ExpensesView()));
          }
        },
      ),
    );
  }

  Widget homeCardView({bool isDummy = false}) {
    return Card(
      elevation: _elevation,
      child: ListTile(
        title: Text(Language().getString(Constants.HOME_STR, selectedLang),
            style: TextStyle(
                fontSize: itemsFontSize,
                color: Colors.black,
                fontWeight: itemFontWeight)),
        leading: Image.asset(
          'assets/images/home_icon.png',
          // color: iconsColor,
          height: 25.0,
          width: 25.0,
        ),
        //  Icon(Icons.home, color: Colors.black),
        onTap: () {
          if (isDummy) {
            return;
          }
          if (!kIsWeb) {
            CommonMethods.hideKeyboard(context);
          }
          Navigator.pop(context);
          Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => HomePageView()),
              (route) => false);
        },
      ),
    );
  }

  Widget ourOrganizationCardView() {
    return Card(
      elevation: _elevation,
      child: ListTile(
        leading: Image.asset(
          'assets/images/my_company_icon.png',
          // color: iconsColor,
          height: 30.0,
          width: 30.0,
        ),
        // Icon(
        //   Icons.list,
        //   color: iconsColor,
        // ),
        title: Container(
          child: Text(
            Language().getString(Constants.STR_MY_COMPANY, selectedLang),
            style: TextStyle(
                fontSize: itemsFontSize,
                color: itemsColor,
                fontWeight: itemFontWeight),
          ),
        ),
        onTap: () {
          if (AppController.instance.buList != null &&
              AppController.instance.buList!.length == 0) {
            showAlert(Constants.CREATE_BU_INFO);
          } else {
            Navigator.pop(context);
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => AllBUListView(
                          title: Constants.BUSINESS_UNIT_LIST_STRING,
                        )));
          }
        },
      ),
    );
  }

  Widget userRolesCardView() {
    return ListTile(
        leading: Icon(Icons.add, color: Color(Constants.APP_COLOR)),
        title: Container(
          child: Text(
            Language().getString(
                Constants.STR_USER_ROLE_AUTHORISATIONS, selectedLang),
            style: TextStyle(
                fontSize: StyleView.FONT_SIZE_15,
                color: Color(Constants.APP_COLOR)),
          ),
        ),
        onTap: () {
          Navigator.pop(context);
          Navigator.push(
              context,
              PageTransition(
                  context: context,
                  page: RolesListView(
                    buId: AppController.instance.getMyBuId,
                    buName: AppController.instance.getBuName,
                  )));
        });
  }

  Widget subscriptionCardView() {
    return Card(
      elevation: _elevation,
      child: ListTile(
        title: Text(
            Language().getString(Constants.SUBSCRIPTION_STR, selectedLang),
            style: TextStyle(
                fontWeight: itemFontWeight,
                fontSize: itemsFontSize,
                color: itemsColor)),
        leading: Image.asset(
          "assets/images/subscription_icon.png",
          width: 30,
          height: 30,
        ),
        onTap: () {
          if (AppController.instance.buList != null &&
              AppController.instance.buList!.length == 0) {
            showAlert(Constants.CREATE_BU_INFO);
          } else {
            Navigator.pop(context);
            Navigator.push(context,
                PageTransition(context: context, page: SubscriptionScreen()));
          }
        },
      ),
    );
  }

  Widget ourPeopleCardView() {
    return Card(
      elevation: _elevation,
      child: ListTile(
        title: Text(
            Language().getString(Constants.STR_OUR_PEOPLE, selectedLang),
            style: TextStyle(
                fontSize: itemsFontSize,
                color: itemsColor,
                fontWeight: itemFontWeight)),
        leading: Image.asset(
          'assets/images/work_force_icon.png',
          // color: iconsColor,
          height: 30.0,
          width: 30.0,
        ),
        // Icon(Icons.supervised_user_circle, color: iconsColor),
        onTap: () {
          if (AppController.instance.buList != null &&
              AppController.instance.buList!.length == 0) {
            showAlert(Constants.CREATE_BU_INFO);
          } else {
            Navigator.pop(context);
            Navigator.push(context,
                PageTransition(context: context, page: UsersStatusView()));
          }
        },
      ),
    );
  }

  Widget createUserCardView() {
    return ListTile(
      title: Text(
          Language().getString(Constants.ADD_NEW_USER_STRING, selectedLang),
          style: TextStyle(
              fontSize: StyleView.FONT_SIZE_15,
              color: Color(Constants.APP_COLOR))),
      leading: Icon(Icons.add, color: Color(Constants.APP_COLOR)),
      onTap: () {
        if (AppController.instance.buList != null &&
            AppController.instance.buList!.length == 0) {
          showAlert(Constants.CREATE_BU_INFO);
        } else {
          Navigator.pop(context);
          Navigator.push(
              context,
              PageTransition(
                  context: context,
                  page: UsersDetailsView(
                      userId: "", title: "", isUserEdit: false)));
        }
      },
    );
  }

  Widget productAndInventoryCardView() {
    return Card(
        elevation: _elevation,
        child: ExpansionTile(
            trailing: Icon(Icons.expand_more, color: iconsColor),
            leading: Image.asset(
              'assets/images/products_icon.png',
              height: 30.0,
              width: 30.0,
            ),
            title: Text(
              Language().getString(Constants.STR_PRODUCTS, selectedLang),
              style: TextStyle(
                  fontSize: itemsFontSize,
                  color: itemsColor,
                  fontWeight: itemFontWeight),
            ),
            children: <Widget>[
              Container(
                  padding: EdgeInsets.only(left: 20, right: 20),
                  color: Colors.white,
                  child: Column(children: <Widget>[
                    if (CommonMethods.isPrivillegeExist(
                        context, PrivillegesActions.KEY_PRODUCT_LIST))
                      productsListCardView(),
                    if (CommonMethods.isPrivillegeExist(
                        context, PrivillegesActions.KEY_INVENTORY_LOCATION))
                      productInventoryCardView()
                  ]))
            ]));
  }

  Widget rawMaterialFormCardView() {
    return ListTile(
      leading: Image.asset(
        'assets/images/list_icon.png',
        color: iconsColor,
        height: 25.0,
        width: 25.0,
      ),
      title: Container(
        child: Text(
          Language().getString("Raw Material Request Form", selectedLang),
          style: TextStyle(fontSize: StyleView.FONT_SIZE_15, color: itemsColor),
        ),
      ),
      onTap: () {
        if (AppController.instance.buList != null &&
            AppController.instance.buList!.length == 0) {
          showAlert(Constants.CREATE_BU_INFO);
        } else {
          Navigator.pop(context);
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => RawmaterialFormPage()));
        }
      },
    );
  }

  Widget consumableFormCardView() {
    return ListTile(
      leading: Image.asset(
        'assets/images/list_icon.png',
        color: iconsColor,
        height: 25.0,
        width: 25.0,
      ),
      title: Container(
        child: Text(
          Language()
              .getString(Constants.CONSUMABLE_GOODS_REQUEST_FORM, selectedLang),
          style: TextStyle(fontSize: StyleView.FONT_SIZE_15, color: itemsColor),
        ),
      ),
      onTap: () {
        if (AppController.instance.buList != null &&
            AppController.instance.buList!.length == 0) {
          showAlert(Constants.CREATE_BU_INFO);
        } else {
          Navigator.pop(context);
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => ConsumableFormPage()));
        }
      },
    );
  }

  Widget consumableProductsCardView() {
    return ListTile(
        leading: Image.asset(
          'assets/images/consumable_product_icon.png',
          color: Color(Constants.APP_COLOR),
          height: 25.0,
          width: 25.0,
        ),
        title: Container(
          child: Text(
            Language().getString(Constants.CONSUMABLE_PRODUCTS, selectedLang),
            style: TextStyle(
                fontSize: StyleView.FONT_SIZE_15,
                color: Color(Constants.APP_COLOR)),
          ),
        ),
        onTap: () {
          Navigator.pop(context);
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => ConsumableProductList()));
        });
  }

  Widget rawMaterialIssuanceCardView() {
    return ListTile(
      leading: Image.asset(
        'assets/images/list_icon.png',
        color: iconsColor,
        height: 25.0,
        width: 25.0,
      ),
      title: Container(
        child: Text(
          Language().getString(Constants.RAW_MARETIAL_ISSUE, selectedLang),
          style: TextStyle(fontSize: StyleView.FONT_SIZE_15, color: itemsColor),
        ),
      ),
      onTap: () {
        if (AppController.instance.buList != null &&
            AppController.instance.buList!.length == 0) {
          showAlert(Constants.CREATE_BU_INFO);
        } else {
          Navigator.pop(context);
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) =>
                      RawMaterialTabView(isFromDrawer: true)));
        }
      },
    );
  }

  Widget configureConsumableRequestFormTemplateCardView() {
    return ListTile(
      leading: Image.asset(
        'assets/images/list_icon.png',
        color: iconsColor,
        height: 25.0,
        width: 25.0,
      ),
      title: Container(
        child: Text(
          Language().getString(Constants.CONFIGURE, selectedLang),
          style: TextStyle(fontSize: StyleView.FONT_SIZE_15, color: itemsColor),
        ),
      ),
      onTap: () {
        if (AppController.instance.buList != null &&
            AppController.instance.buList!.length == 0) {
          showAlert(Constants.CREATE_BU_INFO);
        } else {
          Navigator.pop(context);
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => ConfigureRawTemplate()));
        }
      },
    );
  }

  Widget consumableInventory() {
    return ListTile(
        leading: Image.asset(
          'assets/images/inventory_icon.png',
          height: 30.0,
          width: 30.0,
        ),
        title: Container(
          child: Text(
            Language().getString(Constants.INVENTORY, selectedLang),
            style:
                TextStyle(fontSize: StyleView.FONT_SIZE_15, color: itemsColor),
          ),
        ),
        onTap: () {
          if (AppController.instance.buList != null &&
              AppController.instance.buList!.length == 0) {
            showAlert(Constants.CREATE_BU_INFO);
          } else {
            Navigator.pop(context);
            Navigator.push(
                context,
                PageTransition(
                    context: context,
                    page: ConsumableMaterialInventoryPage(
                      isAppBarVisible: true,
                    )));
          }
        });
  }

  Widget consumableMaterialIssuanceCardView() {
    return ListTile(
      leading: Image.asset(
        'assets/images/list_icon.png',
        color: iconsColor,
        height: 25.0,
        width: 25.0,
      ),
      title: Container(
        child: Text(
          Language()
              .getString(Constants.CONSUMABLE_GOODS_ISSUANCE, selectedLang),
          style: TextStyle(fontSize: StyleView.FONT_SIZE_15, color: itemsColor),
        ),
      ),
      onTap: () {
        if (AppController.instance.buList != null &&
            AppController.instance.buList!.length == 0) {
          showAlert(Constants.CREATE_BU_INFO);
        } else {
          Navigator.pop(context);
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) =>
                      ConsumableMaterialTabView(isFromDrawer: true)));
        }
      },
    );
  }

  Widget consumableMaterialCardView() {
    return Card(
        elevation: _elevation,
        child: ExpansionTile(
            trailing: Icon(Icons.expand_more, color: iconsColor),
            leading: Image.asset(
              'assets/images/raw_materials_icon.png',
              // color: iconsColor,
              height: 25.0,
              width: 25.0,
            ),
            title: Text(
              Language().getString("CONSUMABLE GOODS", selectedLang),
              style: TextStyle(
                  fontWeight: itemFontWeight,
                  fontSize: itemsFontSize,
                  color: itemsColor),
            ),
            children: [
              Container(
                  padding: EdgeInsets.only(left: 20, right: 20),
                  color: Colors.white,
                  child: Column(children: [
                    if (CommonMethods.isPrivillegeExist(
                        context,
                        PrivillegesActions
                            .CONSUMABLE_MATERIAL_MENU_CONSUMABLE_MATERIALS))
                      ListTile(
                        leading: Image.asset(
                          'assets/images/raw_material.png',
                          color: iconsColor,
                          height: 25.0,
                          width: 25.0,
                        ),
                        title: Container(
                          child: Text(
                            Language().getString(
                                Constants.CONSUMABLE_GOODS, selectedLang),
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                color: itemsColor),
                          ),
                        ),
                        onTap: () {
                          if (AppController.instance.buList != null &&
                              AppController.instance.buList!.length == 0) {
                            showAlert(Constants.CREATE_BU_INFO);
                          } else {
                            Navigator.pop(context);
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        ConsumableProductsListPage()));
                          }
                        },
                      ),
                    if (CommonMethods.isPrivillegeExist(
                        context,
                        PrivillegesActions
                            .CONSUMABLE_MATERIAL_MENU_CONSUMABLE_MATERIAL_REQUEST_FORM))
                      this.consumableFormCardView(),
                    if (CommonMethods.isPrivillegeExist(
                        context,
                        PrivillegesActions
                            .CONSUMABLE_MATERIAL_MENU_CONSUMABLE_MATERIAL_ISSUANCE))
                      this.consumableMaterialIssuanceCardView(),
                    if (CommonMethods.isPrivillegeExist(context,
                        PrivillegesActions.CONSUMABLE_MATERIAL_MENU_INVENTORY))
                      this.consumableInventory()
                  ]))
            ]));
  }

  Widget rawMaterialCardView() {
    return Card(
        elevation: _elevation,
        child: ExpansionTile(
            trailing: Icon(Icons.expand_more, color: iconsColor),
            leading: Image.asset(
              'assets/images/raw_materials_icon.png',
              // color: iconsColor,
              height: 25.0,
              width: 25.0,
            ),
            title: Text(
              Language().getString("RAW MATERIALS", selectedLang),
              style: TextStyle(
                  fontWeight: itemFontWeight,
                  fontSize: itemsFontSize,
                  color: itemsColor),
            ),
            children: [
              Container(
                  padding: EdgeInsets.only(left: 20, right: 20),
                  color: Colors.white,
                  child: Column(children: [
                    if (CommonMethods.isPrivillegeExist(context,
                        PrivillegesActions.RAW_MATERIAL_MENU_RAW_MATERIALS))
                      ListTile(
                        leading: Image.asset(
                          'assets/images/raw_material.png',
                          color: iconsColor,
                          height: 25.0,
                          width: 25.0,
                        ),
                        title: Container(
                          child: Text(
                            Language().getString(
                                Constants.RAW_MATERIALS, selectedLang),
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                color: itemsColor),
                          ),
                        ),
                        onTap: () {
                          if (AppController.instance.buList != null &&
                              AppController.instance.buList!.length == 0) {
                            showAlert(Constants.CREATE_BU_INFO);
                          } else {
                            Navigator.pop(context);
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        RawProductsListPage()));
                          }
                        },
                      ),
                    if (CommonMethods.isPrivillegeExist(
                        context,
                        PrivillegesActions
                            .RAW_MATERIAL_MENU_RAW_MATERIAL_REQUEST_FORM))
                      this.rawMaterialFormCardView(),
                    if (CommonMethods.isPrivillegeExist(
                        context,
                        PrivillegesActions
                            .RAW_MATERIAL_MENU_RAW_MATERIAL_ISSUANCE))
                      this.rawMaterialIssuanceCardView(),
                    if (CommonMethods.isPrivillegeExist(context,
                        PrivillegesActions.RAW_MATERIAL_MENU_CONFIGURE))
                      this.configureConsumableRequestFormTemplateCardView(),
                    if (CommonMethods.isPrivillegeExist(context,
                        PrivillegesActions.RAW_MATERIAL_MENU_INVENTORY))
                      this.rawMaterialInventory()
                    // this.consumableProductsCardView(),
                  ]))
            ]));
  }

  Widget transactionsCardView() {
    return Card(
        elevation: _elevation,
        child: ListTile(
          title: Text(
              Language().getString(Constants.STR_SALES_PURCHASES, selectedLang),
              style: TextStyle(
                  fontWeight: itemFontWeight,
                  fontSize: itemsFontSize,
                  color: itemsColor)),
          leading: Image.asset(
            'assets/images/transactions_icon.png',
            // color: iconsColor,
            height: 30.0,
            width: 30.0,
          ),
          // Icon(Icons.payment, color: iconsColor),
          onTap: () {
            if (AppController.instance.buList != null &&
                AppController.instance.buList!.length == 0) {
              showAlert(Constants.CREATE_BU_INFO);
            } else {
              Navigator.pop(context);
              // Navigator.push(context,
              // PageTransition(context: context, page: TransactionsView()));

              Navigator.push(
                context,
                MaterialPageRoute(
                  settings: RouteSettings(arguments: "TransactionsView"),
                  builder: (_) => TransactionsView(),
                ),
              );
            }
          },
        ));
  }

  Widget quotationCardView() {
    return Card(
        elevation: _elevation,
        child: ListTile(
          title: Text(
              Language().getString(Constants.STR_QUOTATION, selectedLang),
              style: TextStyle(
                  fontWeight: itemFontWeight,
                  fontSize: itemsFontSize,
                  color: itemsColor)),
          leading: Image.asset(
            'assets/images/transactions_icon.png',
            // color: iconsColor,
            height: 30.0,
            width: 30.0,
          ),
          // Icon(Icons.payment, color: iconsColor),
          onTap: () {
            if (AppController.instance.buList != null &&
                AppController.instance.buList!.length == 0) {
              showAlert(Constants.CREATE_BU_INFO);
            } else {
              Navigator.pop(context);
              Navigator.push(context,
                  PageTransition(context: context, page: QuotationView()));
            }
          },
        ));
  }

  Widget ordersCardView() {
    return Card(
        elevation: _elevation,
        child: ListTile(
          title: Text(Language().getString(Constants.STR_ORDERS, selectedLang),
              style: TextStyle(
                  fontWeight: itemFontWeight,
                  fontSize: itemsFontSize,
                  color: itemsColor)),
          leading: Image.asset(
            'assets/images/transactions_icon.png',
            // color: iconsColor,
            height: 30.0,
            width: 30.0,
          ),
          // Icon(Icons.payment, color: iconsColor),
          onTap: () {
            if (AppController.instance.buList != null &&
                AppController.instance.buList!.length == 0) {
              showAlert(Constants.CREATE_BU_INFO);
            } else {
              Navigator.pop(context);
              Navigator.push(
                  context,
                  PageTransition(
                      context: context, page: OrderFormOrdersView()));
            }
          },
        ));
  }

  Widget challanCardView() {
    return Card(
        elevation: _elevation,
        child: ListTile(
          title: Text(Language().getString(Constants.STR_CHALLAN, selectedLang),
              style: TextStyle(
                  fontWeight: itemFontWeight,
                  fontSize: itemsFontSize,
                  color: itemsColor)),
          leading: Image.asset(
            'assets/images/transactions_icon.png',
            // color: iconsColor,
            height: 30.0,
            width: 30.0,
          ),
          // Icon(Icons.payment, color: iconsColor),
          onTap: () {
            if (AppController.instance.buList != null &&
                AppController.instance.buList!.length == 0) {
              showAlert(Constants.CREATE_BU_INFO);
            } else {
              Navigator.pop(context);
              Navigator.push(context,
                  PageTransition(context: context, page: ChallanView()));
            }
          },
        ));
  }

  Widget fieldSalesInpersonOrdersCardView() {
    return Card(
      elevation: _elevation,
      child: ListTile(
        title: Text(
            Language().getString(Constants.STR_ON_SITE_ORERS, selectedLang),
            style: TextStyle(
                fontWeight: itemFontWeight,
                fontSize: itemsFontSize,
                color: itemsColor)),
        leading: Image.asset(
          'assets/images/on_site_icon.png',
          // color: iconsColor,
          height: 30.0,
          width: 30.0,
        ),
        // ImageIcon(
        //   AssetImage("assets/images/order_list.png"),
        //   size: 30,
        //   color: iconsColor,
        // ),
        onTap: () {
          if (AppController.instance.buList != null &&
              AppController.instance.buList!.length == 0) {
            showAlert(Constants.CREATE_BU_INFO);
          } else {
            Navigator.pop(context);
            Navigator.push(
                context, PageTransition(context: context, page: OrdersPage()));
          }
        },
      ),
    );
  }

  Widget ssfCRMOptions() {
    return Card(
        elevation: _elevation,
        child: ExpansionTile(
            trailing: Icon(Icons.expand_more, color: iconsColor),
            leading: Image.asset(
              'assets/images/retail_icon.png',
              height: 30.0,
              width: 30.0,
            ),
            title: Text(
              Language().getString(Constants.STR_SSF, selectedLang),
              style: TextStyle(
                  fontSize: itemsFontSize,
                  color: itemsColor,
                  fontWeight: itemFontWeight),
            ),
            children: <Widget>[
              Container(
                  padding: EdgeInsets.only(left: 20, right: 20),
                  color: Colors.white,
                  child: Column(children: <Widget>[
                    ssfOffersCardView(),
                  ]))
            ]));
  }

  Widget ssfOffersCardView() {
    return ListTile(
        leading: Icon(
          Icons.call_made,
          color: iconsColor,
        ),
        title: Container(
          child: Text(
            Language().getString(Constants.OFFERS, selectedLang),
            style:
                TextStyle(fontSize: StyleView.FONT_SIZE_15, color: itemsColor),
          ),
        ),
        onTap: () {
          if (AppController.instance.buList != null &&
              AppController.instance.buList!.length == 0) {
            showAlert(Constants.CREATE_BU_INFO);
          } else {
            Navigator.pop(context);
            Navigator.push(
                context,
                PageTransition(
                  context: context,
                  page: RetailOffers(),
                ));
          }
        });
  }

  Widget retailSalesCardView() {
    return Card(
      elevation: _elevation,
      child: ListTile(
        title: Text(
            Language().getString(Constants.STR_RETAIL_SALES, selectedLang),
            style: TextStyle(
                fontWeight: itemFontWeight,
                fontSize: itemsFontSize,
                color: itemsColor)),
        leading: Image.asset(
          'assets/images/retail_icon.png',
          // color: iconsColor,
          height: 30.0,
          width: 30.0,
        ),
        // Icon(Icons.satellite, color: iconsColor),
        onTap: () {
          if (AppController.instance.buList != null &&
              AppController.instance.buList!.length == 0) {
            showAlert(Constants.CREATE_BU_INFO);
          } else {
            Navigator.pop(context);
            Navigator.push(
                context,
                PageTransition(
                    context: context,
                    page: RetailerDashboard(
                      retailCustomerId: "",
                      retailName: "",
                    )));
          }
        },
      ),
    );
  }

  Widget businessConnectionsCardView() {
    return Card(
        elevation: _elevation,
        child: ExpansionTile(
            trailing: Icon(Icons.expand_more, color: iconsColor),
            leading: Image.asset(
              'assets/images/customer_icon.png',
              // color: iconsColor,
              height: 30.0,
              width: 30.0,
            ),
            // Icon(Icons.mediation, color: iconsColor),
            title: Text(
                Language()
                    .getString(Constants.STR_CUSTOMERS_LIST, selectedLang),
                style: TextStyle(
                    fontWeight: itemFontWeight,
                    fontSize: itemsFontSize,
                    color: itemsColor)),
            children: [
              Container(
                  padding: EdgeInsets.only(left: 20, right: 20),
                  color: Colors.white,
                  child: Column(children: [
                    if (CommonMethods.isPrivillegeExist(
                        context, PrivillegesActions.KEY_ONLINE_CONNECTIONS))
                      connectionsCardView(),
                    if (CommonMethods.isPrivillegeExist(
                        context, PrivillegesActions.KEY_OFFLINE_CONNECTIONS))
                      offlineConnectionsCardView(),
                    invitationsCardView()
                  ]))
            ]));
  }

  Widget addfflineCustomer() {
    return ListTile(
      title: Text(
          Language().getString(Constants.ADD_OFFLINE_CUSTOMER, selectedLang),
          style: TextStyle(
              fontSize: StyleView.FONT_SIZE_15,
              color: Color(Constants.APP_COLOR))),
      leading: Icon(Icons.add, color: Color(Constants.APP_COLOR)),
      onTap: () {
        if (AppController.instance.buList != null &&
            AppController.instance.buList!.length == 0) {
          showAlert(Constants.CREATE_BU_INFO);
        } else {
          Navigator.pop(context);
          Navigator.push(
              context,
              PageTransition(
                  context: context,
                  page: CreateOfflineCustomerPage(
                    isFromDrawer: true,
                  )));
        }
      },
    );
  }

  Widget addNewConnectionCardView() {
    return ListTile(
      title: Text(
          Language().getString(Constants.STR_ADD_NEW_CONNECTION, selectedLang),
          style: TextStyle(
              fontSize: StyleView.FONT_SIZE_15,
              color: Color(Constants.APP_COLOR))),
      leading: Icon(Icons.add, color: Color(Constants.APP_COLOR)),
      onTap: () {
        if (AppController.instance.buList != null &&
            AppController.instance.buList!.length == 0) {
          showAlert(Constants.CREATE_BU_INFO);
        } else {
          Navigator.pop(context);
          Navigator.push(
              context, PageTransition(context: context, page: DashboardView()));
        }
      },
    );
  }

  Widget reportsCardView() {
    return Card(
      elevation: _elevation,
      child: ExpansionTile(
        trailing: Icon(Icons.expand_more, color: iconsColor),
        leading: Image.asset(
          "assets/images/report_icon.png",
          width: 30,
          height: 30,
        ),
        title: InkWell(
          child: Text(
            Language().getString(Constants.REPORTS_STR, selectedLang),
            style: TextStyle(
                fontWeight: itemFontWeight,
                fontSize: itemsFontSize,
                color: itemsColor),
          ),
        ),
        children: <Widget>[
          Container(
            padding: EdgeInsets.only(left: 20, right: 20),
            color: Colors.white,
            child: Column(
              children: <Widget>[
                if (CommonMethods.isPrivillegeExist(
                    context, PrivillegesActions.KEY_REPORTS_BUY_REPORTS))
                  buyReportsCardView(),
                if (CommonMethods.isPrivillegeExist(
                    context, PrivillegesActions.KEY_REPORTS_SELL_REPORTS))
                  sellReportsCardView(),
                if (CommonMethods.isPrivillegeExist(context,
                    PrivillegesActions.KEY_REPORTS_FIELD_SALES_TEAM_REPORTS))
                  salesTeamReportsCardView(),
                if (CommonMethods.isPrivillegeExist(context,
                    PrivillegesActions.KEY_REPORTS_RETAIL_SALES_REPORTS))
                  retailSalesReportsCardView(),
                // this.consumableProductsReportsCardView(),
                if (CommonMethods.isPrivillegeExist(
                    context,
                    PrivillegesActions
                        .KEY_REPORTS_RAW_MATERIAL_VS_FINISHED_PRODUCTS))
                  rawFinishedProductsCardView(),
                if (CommonMethods.isPrivillegeExist(
                    context, PrivillegesActions.KEY_REPORTS_PRODUCT_REPORTS))
                  productsReportCardView(),
                if (CommonMethods.isPrivillegeExist(context,
                    PrivillegesActions.KEY_REPORTS_PRODUCT_LOG_REPORTS))
                  productLogReportsCardView(),
                if (CommonMethods.isPrivillegeExist(
                    context, PrivillegesActions.KEY_REPORTS_ANALYSIS_REPORTS))
                  analysisReportsCardView(),
                if (CommonMethods.isPrivillegeExist(context,
                    PrivillegesActions.KEY_REPORTS_STOCK_RETURN_REPORTS))
                  stockReturnReportsView(),
                if (CommonMethods.isPrivillegeExist(context,
                    PrivillegesActions.KEY_REPORTS_RAW_MATERIAL_IO_REPORTS))
                  rawMaterialIOReportCardView(),
                consumableGoodsReportCardView(),
                ProfitLossReportsCardView()
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget ondcCardView() {
    return Card(
      elevation: _elevation,
      child: ExpansionTile(
        trailing: Icon(Icons.expand_more, color: iconsColor),
        leading: Image.asset(
          "assets/images/ondc_marketplace.png",
          width: 30,
          height: 30,
        ),
        title: Text(
          Language().getString(Constants.ONDC_STR, selectedLang),
          style: TextStyle(
              fontWeight: itemFontWeight,
              fontSize: itemsFontSize,
              color: itemsColor),
        ),
        children: <Widget>[
          Container(
            padding: EdgeInsets.only(left: 20, right: 20),
            color: Colors.white,
            child: Column(
              children: <Widget>[
                // ondcProfileCardview(),
                ondcOrdersview(),
                ondcInvoiceListview()
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget ondcOrdersview() {
    return ListTile(
      leading: Icon(
        Icons.call_made,
        color: iconsColor,
      ),
      title: Container(
        child: Text(
          Language().getString(Constants.ORDERS, selectedLang),
          style: TextStyle(fontSize: StyleView.FONT_SIZE_15, color: itemsColor),
        ),
      ),
      onTap: () {
        if (AppController.instance.buList != null &&
            AppController.instance.buList!.length == 0) {
          showAlert(Constants.CREATE_BU_INFO);
        } else {
          if (!kIsWeb) {
            CommonMethods.hideKeyboard(context);
          }
          Navigator.pop(context);
          Navigator.pushAndRemoveUntil(
              context,
              PageTransition(context: context, page: OndcOrdersView()),
              (route) => false);
        }
      },
    );
  }

  Widget ondcProfileCardview() {
    return ListTile(
      leading: Icon(
        Icons.call_made,
        color: iconsColor,
      ),
      title: Container(
        child: Text(
          Language().getString(Constants.ONDC_PROFILE, selectedLang),
          style: TextStyle(fontSize: StyleView.FONT_SIZE_15, color: itemsColor),
        ),
      ),
      onTap: () {
        if (AppController.instance.buList != null &&
            AppController.instance.buList!.length == 0) {
          showAlert(Constants.CREATE_BU_INFO);
        } else {
          if (!kIsWeb) {
            CommonMethods.hideKeyboard(context);
          }
          Navigator.pop(context);
          Navigator.pushAndRemoveUntil(
              context,
              PageTransition(context: context, page: OndcProfileView()),
              (route) => false);
        }
      },
    );
  }

  Widget ondcInvoiceListview() {
    return ListTile(
      leading: Icon(
        Icons.call_made,
        color: iconsColor,
      ),
      title: Container(
        child: Text(
          Language().getString(Constants.INVOICE_LIST, selectedLang),
          style: TextStyle(fontSize: StyleView.FONT_SIZE_15, color: itemsColor),
        ),
      ),
      onTap: () {
        if (AppController.instance.buList != null &&
            AppController.instance.buList!.length == 0) {
          showAlert(Constants.CREATE_BU_INFO);
        } else {
          if (!kIsWeb) {
            CommonMethods.hideKeyboard(context);
          }
          Navigator.pop(context);
          Navigator.pushAndRemoveUntil(
              context,
              PageTransition(context: context, page: OndcInvoiceView()),
              (route) => false);
        }
      },
    );
  }

  Widget logoutCardView() {
    return ListTile(
      title: Text(Language().getString(Constants.STR_LOGOUT, selectedLang),
          style:
              TextStyle(fontSize: StyleView.FONT_SIZE_15, color: Colors.black)),
      leading: ImageIcon(
        AssetImage("assets/images/logout.png"),
        size: 30,
        color: Colors.black,
      ),
      onTap: () async {
        final action = await Dialogs.yesCancelDialog(
            context,
            Language().getString(Constants.CONFIRMATION, selectedLang),
            Language().getString(Constants.LOGOUT_CONFIRMATION, selectedLang),
            Language().getString(Constants.YES_STRING, selectedLang),
            Language().getString(Constants.NO_STRING, selectedLang),
            true);

        if (action == DialogAction.yes) {
          setState(() => isLoadingProgress = true);
          StoreProvider.of<AppState>(context).dispatch(ResetData());
          AppController.instance.setBuList = [];
          AppController.instance.setMyBuId = null;
          SharePref().insertUserId('');
          SharePref().savePhoneNumber('');
          SharePref().savePassword('');
          SharePref().saveUserName('');
          SharePref().saveProfilePic('');
          await CommonMethods.clearAppData(context);
          Future.delayed(Duration(seconds: 3));
          setState(() {
            isLoadingProgress = false;
          });
          Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => LoginPage()),
              (Route<dynamic> route) => false);
        }
      },
    );
  }

  Widget moreCardView() {
    return Card(
      elevation: _elevation,
      child: ListTile(
        title: Text(Language().getString("MORE", selectedLang),
            style: TextStyle(
                fontWeight: itemFontWeight,
                fontSize: itemsFontSize,
                color: itemsColor)),
        leading: Image.asset(
          "assets/images/more_icon.png",
          width: 25,
          height: 25,
        ),
        onTap: () {
          Navigator.pop(context);
          Navigator.push(context,
              PageTransition(page: MoreOptionsPage(), context: context));
        },
      ),
    );
  }

  Widget analysisReportsCardView() {
    return ListTile(
      leading: Icon(
        Icons.call_made,
        color: iconsColor,
      ),
      title: Container(
        child: Text(
          Language().getString(Constants.ANALYSIS_REPORTS, selectedLang),
          style: TextStyle(fontSize: StyleView.FONT_SIZE_15, color: itemsColor),
        ),
      ),
      onTap: () {
        if (AppController.instance.buList != null &&
            AppController.instance.buList!.length == 0) {
          showAlert(Constants.CREATE_BU_INFO);
        } else {
          if (!kIsWeb) {
            CommonMethods.hideKeyboard(context);
          }
          Navigator.pop(context);
          Navigator.pushAndRemoveUntil(
              context,
              PageTransition(context: context, page: AnalysisReportsTopics()),
              (route) => false);
        }
      },
    );
  }

  Widget productLogReportsCardView() {
    return ListTile(
      leading: Icon(
        Icons.call_made,
        color: iconsColor,
      ),
      title: Container(
        child: Text(
          Language().getString(Constants.PRODUCT_LOG_REPORTS, selectedLang),
          style: TextStyle(fontSize: StyleView.FONT_SIZE_15, color: itemsColor),
        ),
      ),
      onTap: () {
        if (AppController.instance.buList != null &&
            AppController.instance.buList!.length == 0) {
          showAlert(Constants.CREATE_BU_INFO);
        } else {
          if (!kIsWeb) {
            CommonMethods.hideKeyboard(context);
          }
          Navigator.pop(context);
          Navigator.pushAndRemoveUntil(
              context,
              PageTransition(context: context, page: ProductLogReportsView()),
              (route) => false);
        }
      },
    );
  }

  Widget productsReportCardView() {
    return ListTile(
      leading: Icon(
        Icons.call_made,
        color: iconsColor,
      ),
      title: Container(
        child: Text(
          Language().getString(Constants.PRODUCT_REPORTS, selectedLang),
          style: TextStyle(fontSize: StyleView.FONT_SIZE_15, color: itemsColor),
        ),
      ),
      onTap: () {
        if (AppController.instance.buList != null &&
            AppController.instance.buList!.length == 0) {
          showAlert(Constants.CREATE_BU_INFO);
        } else {
          if (!kIsWeb) {
            CommonMethods.hideKeyboard(context);
          }
          Navigator.pop(context);
          Navigator.pushAndRemoveUntil(
              context,
              PageTransition(context: context, page: ProductReportsView()),
              (route) => false);
        }
      },
    );
  }

  Widget rawFinishedProductsCardView() {
    return ListTile(
      leading: Image.asset(
        'assets/images/list_icon.png',
        color: iconsColor,
        height: 25.0,
        width: 25.0,
      ),
      title: Container(
        child: Text(
          Language().getString(Constants.RAW_VS_FINISHED_PRODUCT, selectedLang),
          style: TextStyle(fontSize: StyleView.FONT_SIZE_15, color: itemsColor),
        ),
      ),
      onTap: () {
        if (AppController.instance.buList != null &&
            AppController.instance.buList!.length == 0) {
          showAlert(Constants.CREATE_BU_INFO);
        } else {
          if (!kIsWeb) {
            CommonMethods.hideKeyboard(context);
          }
          Navigator.pop(context);
          Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(
                  builder: (context) => RawAndFinalProductReportPage()),
              (route) => false);
        }
      },
    );
  }

  Widget consumableGoodsReportCardView() {
    return ListTile(
      leading: Image.asset(
        'assets/images/list_icon.png',
        color: iconsColor,
        height: 25.0,
        width: 25.0,
      ),
      title: Container(
        child: Text(
          Language()
              .getString(Constants.CONSUMABLE_GOODS_REPORTS, selectedLang),
          style: TextStyle(fontSize: StyleView.FONT_SIZE_15, color: itemsColor),
        ),
      ),
      onTap: () {
        if (AppController.instance.buList != null &&
            AppController.instance.buList!.length == 0) {
          showAlert(Constants.CREATE_BU_INFO);
        } else {
          if (!kIsWeb) {
            CommonMethods.hideKeyboard(context);
          }
          Navigator.pop(context);
          Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(
                  builder: (context) => ConsumableGoodsReportPage()),
              (route) => false);
        }
      },
    );
  }

  Widget rawMaterialIOReportCardView() {
    return ListTile(
      leading: Image.asset(
        'assets/images/list_icon.png',
        color: iconsColor,
        height: 25.0,
        width: 25.0,
      ),
      title: Container(
        child: Text(
          Language().getString(Constants.RAW_MATERIAL_IO_REPORT, selectedLang),
          style: TextStyle(fontSize: StyleView.FONT_SIZE_15, color: itemsColor),
        ),
      ),
      onTap: () {
        if (AppController.instance.buList != null &&
            AppController.instance.buList!.length == 0) {
          showAlert(Constants.CREATE_BU_INFO);
        } else {
          if (!kIsWeb) {
            CommonMethods.hideKeyboard(context);
          }
          Navigator.pop(context);
          Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => RawMaterialIOReport()),
              (route) => false);
        }
      },
    );
  }

  Widget consumableProductsReportsCardView() {
    return ListTile(
        leading: Icon(Icons.timelapse, color: Color(Constants.APP_COLOR)),
        title: Container(
          child: Text(
            Language().getString(
                Constants.MANUFACTURING_CONSUMPTION_REPORTS, selectedLang),
            style: TextStyle(
                fontSize: StyleView.FONT_SIZE_15,
                color: Color(Constants.APP_COLOR)),
          ),
        ),
        onTap: () {
          if (AppController.instance.buList != null &&
              AppController.instance.buList!.length == 0) {
            showAlert(Constants.CREATE_BU_INFO);
          } else {
            Navigator.pop(context);
            Navigator.push(
                context,
                PageTransition(
                    context: context, page: ConsumableProductReportsPage()));
          }
        });
  }

  Widget retailSalesReportsCardView() {
    return ListTile(
      leading: Icon(
        Icons.list,
        color: iconsColor,
      ),
      title: Container(
        child: Text(
          Language()
              .getString(Constants.STR_RETAIL_SALES_REPORTS, selectedLang),
          style: TextStyle(fontSize: StyleView.FONT_SIZE_15, color: itemsColor),
        ),
      ),
      onTap: () {
        if (AppController.instance.buList != null &&
            AppController.instance.buList!.length == 0) {
          showAlert(Constants.CREATE_BU_INFO);
        } else {
          if (!kIsWeb) {
            CommonMethods.hideKeyboard(context);
          }
          Navigator.pop(context);
          Navigator.pushAndRemoveUntil(
              context,
              PageTransition(
                context: context,
                page: RetailCustomerReportsPage(
                  isForSalesReport: true,
                  appBarText: Constants.SELL_REPORTS,
                ),
              ),
              (route) => false);
        }
      },
    );
  }

  Widget salesTeamReportsCardView() {
    return ListTile(
      leading: Icon(
        Icons.trending_up,
        color: iconsColor,
      ),
      title: Container(
        child: Text(
          Language().getString(Constants.SALES_TEAM_REPORTS, selectedLang),
          style: TextStyle(fontSize: StyleView.FONT_SIZE_15, color: itemsColor),
        ),
      ),
      onTap: () {
        if (AppController.instance.buList != null &&
            AppController.instance.buList!.length == 0) {
          showAlert(Constants.CREATE_BU_INFO);
        } else {
          if (!kIsWeb) {
            CommonMethods.hideKeyboard(context);
          }
          Navigator.pop(context);
          Navigator.pushAndRemoveUntil(
              context,
              PageTransition(context: context, page: UserReportsPage()),
              (route) => false);
        }
      },
    );
  }

  Widget sellReportsCardView() {
    return ListTile(
      leading: Icon(
        Icons.call_made,
        color: iconsColor,
      ),
      title: Container(
        child: Text(
          Language().getString(Constants.SELL_REPORTS, selectedLang),
          style: TextStyle(fontSize: StyleView.FONT_SIZE_15, color: itemsColor),
        ),
      ),
      onTap: () {
        if (AppController.instance.buList != null &&
            AppController.instance.buList!.length == 0) {
          showAlert(Constants.CREATE_BU_INFO);
        } else {
          if (!kIsWeb) {
            CommonMethods.hideKeyboard(context);
          }
          Navigator.pop(context);
          Navigator.pushAndRemoveUntil(
              context,
              PageTransition(context: context, page: SalesReportsPage()),
              (route) => false);
        }
      },
    );
  }

  Widget buyReportsCardView() {
    return ListTile(
        leading: Icon(Icons.storage_outlined, color: iconsColor),
        title: Container(
          child: Text(
            Language().getString(Constants.BUY_REPORTS, selectedLang),
            style:
                TextStyle(fontSize: StyleView.FONT_SIZE_15, color: itemsColor),
          ),
        ),
        onTap: () {
          if (AppController.instance.buList != null &&
              AppController.instance.buList!.length == 0) {
            showAlert(Constants.CREATE_BU_INFO);
          } else {
            if (!kIsWeb) {
              CommonMethods.hideKeyboard(context);
            }
            Navigator.pop(context);
            Navigator.pushAndRemoveUntil(
                context,
                PageTransition(context: context, page: BuyReportsPage()),
                (route) => false);
          }
        });
  }

  Widget ProfitLossReportsCardView() {
    return ListTile(
        leading: Icon(Icons.storage_outlined, color: iconsColor),
        title: Container(
          child: Text(
            Language().getString(Constants.PROFIT_LOSS_REPORT, selectedLang),
            style:
                TextStyle(fontSize: StyleView.FONT_SIZE_15, color: itemsColor),
          ),
        ),
        onTap: () {
          if (AppController.instance.buList != null &&
              AppController.instance.buList!.length == 0) {
            showAlert(Constants.CREATE_BU_INFO);
          } else {
            if (!kIsWeb) {
              CommonMethods.hideKeyboard(context);
            }
            Navigator.pop(context);
            Navigator.pushAndRemoveUntil(
                context,
                PageTransition(context: context, page: ProfitLossReport()),
                (route) => false);
          }
        });
  }

  Widget connectionsCardView() {
    return ListTile(
      title: Text(
          Language().getString(Constants.ONLINE_CONNECTIONS, selectedLang),
          style:
              TextStyle(fontSize: StyleView.FONT_SIZE_15, color: itemsColor)),
      leading: Image.asset(
        'assets/images/connections_icon.png',
        height: 30.0,
        width: 30.0,
      ),
      onTap: () {
        if (AppController.instance.buList != null &&
            AppController.instance.buList!.length == 0) {
          showAlert(Constants.CREATE_BU_INFO);
        } else {
          Navigator.pop(context);
          Navigator.push(
              context, PageTransition(context: context, page: ContactsView()));
        }
      },
    );
  }

  Widget offlineConnectionsCardView() {
    return ListTile(
      title: Text(
          Language().getString(Constants.OFFLINE_CONNECTIONS, selectedLang),
          style:
              TextStyle(fontSize: StyleView.FONT_SIZE_15, color: itemsColor)),
      leading: Image.asset(
        'assets/images/offline_connection_icon.png',
        height: 30.0,
        width: 30.0,
      ),
      onTap: () {
        if (AppController.instance.buList != null &&
            AppController.instance.buList!.length == 0) {
          showAlert(Constants.CREATE_BU_INFO);
        } else {
          Navigator.pop(context);
          Navigator.push(context,
              PageTransition(context: context, page: OfflineConnections()));
        }
      },
    );
  }

  Widget invitationsCardView() {
    return ListTile(
      title: Text(
          Language()
              .getString(Constants.STR_INVITATION_STATUS_LIST, selectedLang),
          style:
              TextStyle(fontSize: StyleView.FONT_SIZE_15, color: itemsColor)),
      leading: Image.asset(
        'assets/images/invitations_icon.png',
        height: 30.0,
        width: 30.0,
      ),
      onTap: () {
        if (AppController.instance.buList != null &&
            AppController.instance.buList!.length == 0) {
          showAlert(Constants.CREATE_BU_INFO);
        } else {
          Navigator.pop(context);
          Navigator.push(
              context, PageTransition(context: context, page: InviteView()));
        }
      },
    );
  }

  Widget productsListCardView() {
    return ListTile(
        leading: Image.asset(
          'assets/images/products_list.png',
          height: 30.0,
          width: 30.0,
        ),
        title: Container(
          child: Text(
            Language().getString(Constants.PRODUCT_LIST_STR, selectedLang),
            style:
                TextStyle(fontSize: StyleView.FONT_SIZE_15, color: itemsColor),
          ),
        ),
        onTap: () {
          if (AppController.instance.buList != null &&
              AppController.instance.buList!.length == 0) {
            showAlert(Constants.CREATE_BU_INFO);
          } else {
            Navigator.pop(context);
            Navigator.push(
                context,
                PageTransition(
                  context: context,
                  page: ProductsMenuPage(),
                ));
          }
        });
  }

  Widget productInventoryCardView() {
    return ListTile(
        leading: Image.asset(
          'assets/images/inventory_icon.png',
          height: 30.0,
          width: 30.0,
        ),
        title: Container(
          child: Text(
            Language().getString(Constants.INVENTORY_LOCATION, selectedLang),
            style:
                TextStyle(fontSize: StyleView.FONT_SIZE_15, color: itemsColor),
          ),
        ),
        onTap: () {
          if (AppController.instance.buList != null &&
              AppController.instance.buList!.length == 0) {
            showAlert(Constants.CREATE_BU_INFO);
          } else {
            Navigator.pop(context);
            Navigator.push(
                context,
                PageTransition(
                    context: context,
                    page: HomeInventoryPage(
                      isAppBarVisible: true,
                    )));
          }
        });
  }

  Widget configureRequestFormTemplateCardView() {
    return ListTile(
      leading: Image.asset(
        'assets/images/list_icon.png',
        color: iconsColor,
        height: 25.0,
        width: 25.0,
      ),
      title: Container(
        child: Text(
          Language().getString(Constants.CONFIGURE, selectedLang),
          style: TextStyle(fontSize: StyleView.FONT_SIZE_15, color: itemsColor),
        ),
      ),
      onTap: () {
        if (AppController.instance.buList != null &&
            AppController.instance.buList!.length == 0) {
          showAlert(Constants.CREATE_BU_INFO);
        } else {
          Navigator.pop(context);
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => ConfigureConsumableTemplate()));
        }
      },
    );
  }

  Widget rawMaterialInventory() {
    return ListTile(
        leading: Image.asset(
          'assets/images/inventory_icon.png',
          height: 30.0,
          width: 30.0,
        ),
        title: Container(
          child: Text(
            Language().getString(Constants.INVENTORY, selectedLang),
            style:
                TextStyle(fontSize: StyleView.FONT_SIZE_15, color: itemsColor),
          ),
        ),
        onTap: () {
          if (AppController.instance.buList != null &&
              AppController.instance.buList!.length == 0) {
            showAlert(Constants.CREATE_BU_INFO);
          } else {
            Navigator.pop(context);
            Navigator.push(
                context,
                PageTransition(
                    context: context,
                    page: RawMaterialInventoryPage(
                      isAppBarVisible: true,
                    )));
          }
        });
  }

  Widget notificationsView() {
    return Card(
      elevation: _elevation,
      child: ListTile(
        title: Text(
            Language().getString(Constants.NOTIFICATIONS_STR, selectedLang),
            style: TextStyle(
                fontWeight: itemFontWeight,
                fontSize: itemsFontSize,
                color: itemsColor)),
        leading: Icon(Icons.notifications, color: iconsColor),
        onTap: () {
          Navigator.push(context,
              PageTransition(page: NotificationPageView(), context: context));
        },
      ),
    );
  }

  Widget stockReturnsCardView() {
    return Card(
        elevation: _elevation,
        child: ListTile(
          title: Text(
              Language().getString(Constants.STOCK_RETURN, selectedLang),
              style: TextStyle(
                  fontWeight: itemFontWeight,
                  fontSize: itemsFontSize,
                  color: itemsColor)),
          leading: Icon(Icons.payment, color: iconsColor),
          onTap: () {
            if (AppController.instance.buList != null &&
                AppController.instance.buList!.length == 0) {
              showAlert(Constants.CREATE_BU_INFO);
            } else {
              Navigator.pop(context);
              Navigator.push(context,
                  PageTransition(context: context, page: StockReturnsPage()));
            }
          },
        ));
  }

  Widget stockReturnReportsView() {
    return ListTile(
      leading: Icon(
        Icons.call_made,
        color: iconsColor,
      ),
      title: Container(
        child: Text(
          Language().getString("Stock Return Reports", selectedLang),
          style: TextStyle(fontSize: StyleView.FONT_SIZE_15, color: itemsColor),
        ),
      ),
      onTap: () {
        if (AppController.instance.buList != null &&
            AppController.instance.buList!.length == 0) {
          showAlert(Constants.CREATE_BU_INFO);
        } else {
          if (!kIsWeb) {
            CommonMethods.hideKeyboard(context);
          }
          Navigator.pop(context);
          Navigator.pushAndRemoveUntil(
              context,
              PageTransition(context: context, page: StockReturnReports()),
              (route) => false);
        }
      },
    );
  }
}
