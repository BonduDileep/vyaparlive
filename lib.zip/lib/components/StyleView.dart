import 'package:flutter/material.dart';
import 'package:vyaparlive/components/Constants.dart';

class StyleView {
  static const double FONT_SIZE_20 = 20;
  static const double FONT_SIZE_25 = 25;
  static const double FONT_SIZE_15 = 15;
  static const double FONT_SIZE_16 = 16;
  static const double FONT_SIZE_18 = 18;
  static const double FONT_SIZE_13 = 13;
  static const double HEIGHT_5 = 5;
  static const double HEIGHT_10 = 10;
  static const double HEIGHT_14 = 14;
  static const double HEIGHT_20 = 20;
  static const String FONT_TITLE = "Montserrat";
  static const String FONT_TEXT = 'Montserrat-Regular';
  static const FontWeight fontRegular = FontWeight.w400;
  static const FontWeight fontMedium = FontWeight.w500;
  static const FontWeight fontSemiBold = FontWeight.w600;
  static const FontWeight fontBold = FontWeight.w700;
  static Color helperColor = Color(0xff787878);
  static Color primaryColor = Color(0xff00b27f);
  static Color secondaryColor = Color(0xFFC5C5C5); //083e64);
  static Color baseColor = Color(0xff4a4a4a);
  static Color lightGrayColor = Color(0xffe6e6e6);
  static Color grayColor = Color(0xff505050);
  static Color darkGrayColor = Color(0xff2d2d2d);
  static Color errorColor = Color(0xffea6060);
  static const int BLACK_COLOR = 0xff000000;
  static Color? offerColor = Colors.green;

  static InputDecoration getInputDecoration(
      {String? helper,
      Color customHelperColor = Colors.grey,
      String? hintTex = ""}) {
    return InputDecoration(
      hintText: hintTex!.isEmpty ? helper : hintTex,
      isDense: true,
      labelText: helper,
      labelStyle: TextStyle(color: Colors.black),
      border: OutlineInputBorder(),
      enabledBorder:
          OutlineInputBorder(borderSide: BorderSide(color: Colors.grey)),
      focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(color: StyleView.secondaryColor)),
    );
  }

  static TextStyle getProgressMessageStyle() {
    return TextStyle(
        color: Colors.black, fontSize: 15.0, fontWeight: FontWeight.w200);
  }

  buildSimpleText(String _simpleText) {
    return Text(_simpleText,
        style: TextStyle(
            fontSize:
                _simpleText == Constants.PLEASE_FILL_INVITE_FORM_TITLE_STRING
                    ? StyleView.FONT_SIZE_18
                    : StyleView.FONT_SIZE_15,
            color: _simpleText ==
                        Constants.COMMERCIAL_RELATIONSHIP_TITLE_STRING ||
                    _simpleText == Constants.BASIC_DETAILS_STRING ||
                    _simpleText == Constants.RELATION_SHIP_TITLE_NAME_STRING ||
                    _simpleText == Constants.INVITEE_CONTACT_DETAILS_STRING ||
                    _simpleText == Constants.OUR_BU_DETAILS ||
                    _simpleText ==
                        Constants.PLEASE_FILL_INVITE_FORM_TITLE_STRING ||
                    _simpleText == "INVITEE BASIC DETAILS"
                ? Colors.black
                : Colors.grey,
            fontWeight: _simpleText ==
                        Constants.COMMERCIAL_RELATIONSHIP_TITLE_STRING ||
                    _simpleText == Constants.BASIC_DETAILS_STRING ||
                    _simpleText == Constants.RELATION_SHIP_TITLE_NAME_STRING ||
                    _simpleText == Constants.INVITEE_CONTACT_DETAILS_STRING ||
                    _simpleText == Constants.OUR_BU_DETAILS ||
                    _simpleText == "INVITEE BASIC DETAILS"
                ? FontWeight.bold
                : null));
  }
}
