import 'dart:convert';
// import 'dart:io';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/model/bu_model/AddressDetailsModel.dart';
import 'package:vyaparlive/redux/actions/menu_action.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:flutx/flutx.dart';
import 'package:intl/intl.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Home/HomePageView.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/login_view/LoginPage.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/product_model/BatchPriceDAO.dart';
import 'package:vyaparlive/model/product_model/PriceDetailsDAO.dart';
import 'package:vyaparlive/model/product_model/ProductModel.dart';
import 'package:vyaparlive/utills/SharePref.dart';
import 'package:http/http.dart' as http;
import 'package:vyaparlive/utills/vyapar_info.dart';
import '../components/file_download/download_utils.dart';

import '../redux/state/app_state.dart';

class CommonMethods {
  static List<BuProductModal> getProductsFromResponse(var data) {
    List<BuProductModal> products = [];
    bool isString = false;
    if (data is String) {
      isString = true;
    }
    if (!isString) {
      List<dynamic> array = data;
      for (var i in array) {
        products.add(BuProductModal.fromJson(i));
      }
    }
    return products;
  }

  static handleUnauthorizedAccess(BuildContext context) async {
    final action = await Dialogs.yesCancelDialog(
        context,
        "Message",
        "You have been logged in from other device",
        Constants.OKAY_STR,
        "",
        false);

    if (action == DialogAction.yes) {
      AppController.instance.setMyBuId = "";
      AppController.instance.setBuName = "";
      AppController.instance.setAuthorizationKey = "";
      SharePref().savePhoneNumber('');
      SharePref().savePassword('');
      SharePref().saveFirebaseToken("");
      SharePref().saveHomePageSelectedBuId('');
      return Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (context) => LoginPage()),
          (Route<dynamic> route) => false);
    }
  }

  static getMRPPrice(PriceDetailsDAO pricing) {
    num returnNum = -1;
    var price = pricing.price;
    if (price != null) {
      returnNum = price;
    }
    return returnNum;
  }

  static hideKeyboard(BuildContext context) {
    FocusScopeNode currentFocus = FocusScope.of(context);

    if (!currentFocus.hasPrimaryFocus) {
      currentFocus.unfocus();
    }
  }

  static Future<bool> onBackPress(BuildContext context) async {
    return (await Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => HomePageView()),
        (Route<dynamic> route) => false));
  }

  static bool isNumeric(String text) {
    return double.tryParse(text) != null;
  }

  static loadLanguage(String? selectedLanguage) async {
    SharedPreferences sharedPreferences;

    sharedPreferences = await SharedPreferences.getInstance();
    if (sharedPreferences.getString(Constants.LANGUAGE_SELECTED) != null) {
      // setState(() {
      selectedLanguage =
          sharedPreferences.getString(Constants.LANGUAGE_SELECTED);
      // });
    }
  }

  static invoiceUpdateTickMark({required bool isUpdated}) {
    if (isUpdated) {
      return Container(
          margin: EdgeInsets.symmetric(
            horizontal: 10.0,
          ),
          child: Icon(Icons.check, color: Colors.green));
    } else {
      return Container();
    }
  }

  static String captilizeText(String s) {
    if (s.isNotEmpty) {
      return "${s[0].toUpperCase()}${s.substring(1)}";
    } else {
      return "";
    }
  }

  static Color? transactionStatusColorHandling(String? status) {
    if (status == Constants.DISCUSSION_STARTED) {
      return Colors.blue;
    } else if (status == Constants.DISCUSSION_NOT_ACCEPTED_BY_SELLER ||
        status == Constants.DISCUSSION_NOT_ACCEPTED_BY_BUYER) {
      return Colors.red;
    } else if (status == Constants.DISCUSSION_ACCEPTED ||
        status == Constants.ORDER_ACCEPTED) {
      return Colors.green;
    } else if (status == Constants.ORDER_PLACED) {
      return Colors.orange;
    } else if (status == Constants.ORDER_REJECTED) {
      return Colors.red;
    } else if (status == Constants.INVOICE_GENERATED) {
      return Colors.yellow[800];
    } else if (status == Constants.PACKING_COMPLETED) {
      return Colors.cyan;
    } else if (status == Constants.PACKING_ASSIGNED) {
      return Colors.cyan;
    } else if (status == Constants.STOCKS_DISPATCHED) {
      //Constants.READY_FOR_DELIVERY) {
      return Colors.green;
    } else if (status == Constants.STOCK_NOT_RESOLVED) {
      return Colors.red;
    } else if (status == Constants.STOCK_RESOLVED) {
      return Colors.green;
    } else if (status == Constants.STOCK_RECEIVED) {
      return Colors.blue;
    } else if (status == Constants.PAYMENT_NOT_RESOLVED) {
      return Colors.red;
    } else if (status == Constants.PAYMENT_RESOLVED) {
      return Colors.green;
    } else if (status == Constants.PO_GENERATED) {
      return Colors.purpleAccent[700];
    } else {
      return Colors.pink;
    }
  }

  static getGRPCUtilBody(String endpoint, String method, String body) {
    return json.encode({"endpoint": endpoint, "method": method, "body": body});
  }

  static Future<GRPCResponse> bypassGRPCIifWeb(
      String body, String? token) async {
    var response =
        await http.post(Uri.parse(Constants.GRPC_UTIL), body: body, headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'authorization': token!
    });

    if (response.statusCode == 200) {
      var data = json.decode(response.body);
      return VyaparInfo.parseGrpcMessage(VyaparInfo.decryptData(data['data']));
    } else {
      return VyaparInfo.generateErrorResponse("UNKNOWN ERROR");
    }
  }

  static Future<bool> setAppControllerData() async {
    String? buName = AppController.instance.buName;

    if (buName == null)
      AppController.instance.setBuName = await SharePref().getBuName();

    String? buId = AppController.instance.myBuId;
    if (buId == null)
      AppController.instance.setMyBuId =
          await SharePref().getHomePageSelectedBuId();
    String? authToken = AppController.instance.authorizationKey;
    if (authToken == null)
      AppController.instance.setAuthorizationKey =
          await SharePref().getAuthToken();

    return true;
  }

  static getRouteData(String path, Map<String, String> data) {
    return Uri(path: path, queryParameters: data).toString();
  }

  Future<PlatformFile?> getFileUpload(BuildContext mContext,
      {bool isForMultiFile = false, bool isForPdf = false}) async {
    FilePickerResult? selectedFile;
    PlatformFile? resultImage;
    if (isForMultiFile) {
      selectedFile = await FilePicker.platform.pickFiles(
          type: FileType.custom,
          allowedExtensions: ['jpg', 'png', 'pdf', 'jpeg']);
    } else if (isForPdf) {
      selectedFile = await FilePicker.platform
          .pickFiles(type: FileType.custom, allowedExtensions: ['pdf']);
    } else {
      selectedFile = await FilePicker.platform.pickFiles(
          type: FileType.custom, allowedExtensions: ['jpg', 'png', 'jpeg']);
    }
    if (selectedFile != null && selectedFile.files.isNotEmpty) {
      resultImage = selectedFile.files.first;
    }
    return resultImage;
  }

  // static String getCurrencyValues(dynamic value) {
  //   String? currencyValue = "";
  //   String? country = AppController.instance.getBuCountryCode;
  //   NumberFormat _format;
  //   if (country == Constants.INDIA) {
  //     _format = NumberFormat.currency(locale: "en_IN", symbol: "");
  //   } else if (country == Constants.UK) {
  //     _format = NumberFormat.currency(locale: "en_UK", symbol: "");
  //   } else {
  //     _format = NumberFormat.currency(locale: "en_US", symbol: "");
  //   }
  //   if (currencyValue != "0") {
  //     currencyValue = _format.format(value);
  //   } else {
  //     currencyValue = value;
  //   }

  //   return "$currencyValue";
  // }

  static String getCurrencyValues(dynamic value) {
    if (value == null) return "0.00";

    // Convert dynamic to num safely
    num numericValue = num.tryParse(value.toString()) ?? 0;

    String country = AppController.instance.getBuCountryCode;
    NumberFormat format;

    if (country == Constants.INDIA) {
      format =
          NumberFormat.currency(locale: "en_IN", symbol: "", decimalDigits: 2);
    } else if (country == Constants.UK) {
      format =
          NumberFormat.currency(locale: "en_UK", symbol: "", decimalDigits: 2);
    } else {
      format =
          NumberFormat.currency(locale: "en_US", symbol: "", decimalDigits: 2);
    }

    return format.format(numericValue);
  }

  // Future<String> _downloadReports(
  //     {BuildContext? context,
  //     required String url,
  //     Map? mapData,
  //     String? fileName}) async {
  //   String requiredFilepath = "";
  //   HttpClient httpClient = new HttpClient();
  //   File file;
  //   String filePath = '';
  //   HttpClientRequest request = await httpClient.postUrl(Uri.parse(url));
  //   request.headers
  //       .set(HttpHeaders.contentTypeHeader, "application/json; charset=UTF-8");
  //   request.headers.set(HttpHeaders.authorizationHeader,
  //       AppController.instance.getAuthorizationKey);
  //   request.add(utf8.encode(json.encode(mapData)));
  //   HttpClientResponse response = await request.close();
  //   try {
  //     if (response.statusCode == 200) {
  //       var bytes = await consolidateHttpClientResponseBytes(response);
  //       try {
  //         filePath = '/storage/emulated/0/Download/$fileName.xlsx';
  //         file = File(filePath);
  //         file.writeAsBytes(bytes);
  //         requiredFilepath = file.absolute.path;
  //       } catch (e) {
  //         print("DOWNLOAD REPORTS EXCEPTION : " + e.toString());
  //       }
  //     } else if (response.statusCode == 401) {
  //       CommonMethods.handleUnauthorizedAccess(context!);
  //     } else {
  //       Dialogs.yesCancelDialog(context!, Constants.ERROR, "response",
  //           Constants.OKAY_STR, "", false);
  //     }
  //   } catch (e) {
  //     print(e);
  //   }

  //   return requiredFilepath;
  // }

  static String addressValidation(String? landmark, String? city) {
    String address = "";

    if (landmark != '') {
      address = "$landmark";
    }
    if (city != null && city != '') {
      address = address + ",$city";
    }
    if (address.startsWith(',')) {
      address = address.substring(1);
    }

    return address;
  }

  static ButtonStyle elevatedButtonStyle(
      {Color customButtonColor = const Color(Constants.APP_COLOR),
      double customPadding = 5}) {
    return ElevatedButton.styleFrom(
        backgroundColor: customButtonColor,
        padding: EdgeInsets.all(customPadding));
  }

  static bool checkResponseType(var data) {
    bool isString = false;
    if (data is String) {
      isString = true;
    } else {
      isString = false;
    }

    return isString;
  }

  static String? getInvoiceIdFromRes(Map<String, dynamic> json) {
    if (json.containsKey('invoice_id')) {
      return json['invoice_id'];
    } else if (json.containsKey('invoiceId')) {
      return json['invoiceId'];
    }

    return "";
  }

  static FilteringTextInputFormatter inputTextFormatter(
      {bool isNumber = false, bool isDouble = false}) {
    dynamic formatter = "";
    if (isNumber) {
      formatter = "[0-9]";
    } else if (isDouble) {
      formatter = r'^\d*\.?\d{0,2}';
    } else {
      formatter = "[a-zA-Z0-9]";
    }

    return FilteringTextInputFormatter.allow(RegExp(formatter));
  }

  static String? getRawIssueCretaedDateFromRes(Map<String, dynamic> json) {
    if (json.containsKey('created_dt')) {
      return json['created_dt'];
    } else if (json.containsKey('created_date')) {
      return json['created_date'];
    }

    return "";
  }

  static bool validateEmail(String value) {
    Pattern pattern =
        r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
    RegExp regex = new RegExp(pattern as String);
    return (!regex.hasMatch(value)) ? false : true;
  }

  static clearAppData(BuildContext mContext) async {
    AppController.instance.setMyBuId = null;
    AppController.instance.setBuName = "";
    AppController.instance.setAuthorizationKey = "";
    SharePref().savePhoneNumber('');
    SharePref().savePassword('');
    SharePref().saveFirebaseToken("");
    SharePref().saveHomePageSelectedBuId('');
    SharePref().clear();
  }

  static String? getTransactionIdFromRes(Map<String, dynamic> json) {
    if (json.containsKey('transactionId')) {
      return json['transactionId'];
    } else if (json.containsKey('txnId')) {
      return json['txnId'];
    } else if (json.containsKey('transaction_id')) {
      return json["transaction_id"];
    } else if (json.containsKey('id')) {
      return json["id"];
    }

    return "";
  }

  static String? getBatchNumberFromRes(Map<String, dynamic> json) {
    if (json.containsKey('batch_no')) {
      return json['batch_no'];
    } else if (json.containsKey('batch_number')) {
      return json['batch_number'];
    }

    return "";
  }

  static String getAvailablePrice(List<BatchPriceDAO> batchList,
      {bool isShowCurrencySymbol = true}) {
    bool isPriceAvailable = false;
    int index = 0;

    if (batchList.length > 0) {
      for (int j = 0; j < batchList.length; j++) {
        if (batchList[j].quantity != 0 && batchList[j].price != 0) {
          isPriceAvailable = true;
          index = j;
          break;
        }
      }
    }

    if (isPriceAvailable) {
      if (isShowCurrencySymbol) {
        return CommonMethods.getCurrencyValues(batchList[index].price);
      } else {
        return "${batchList[index].price}";
      }
    } else {
      return "0";
    }
  }

  static dynamic getValueFromJSON(
      Map<String, dynamic> json, String key, String type) {
    if (type == Constants.TYPE_STRING) {
      return json.containsKey(key) && json[key] != null ? json[key] : "";
    }
    if (type == Constants.TYPE_NUMBER) {
      return json.containsKey(key) && json[key] != null ? json[key] : 0;
    }
  }

  static EdgeInsetsGeometry textInputControllerPadding() {
    if (kIsWeb) {
      return EdgeInsets.fromLTRB(0, 0, 0, 20.0);
    } else {
      return EdgeInsets.fromLTRB(0, 0, 0, 15.0);
    }
  }

  static bool dateRangeValidation(
      {required String startDate, required String endDate}) {
    bool isDateValid = false;
    if (DateTime.parse(endDate).isBefore(DateTime.parse(startDate))) {
      isDateValid = true;
    }

    return isDateValid;
  }

  static String? getProductNameFromRes(Map<String, dynamic> json) {
    if (json.containsKey('name')) {
      return json['name'];
    } else if (json.containsKey('product_name')) {
      return json['product_name'];
    }

    return "";
  }

  static List<BatchPriceDAO> getProductBatchListFromRes(
      Map<String, dynamic> json) {
    if (json.containsKey('batch_pricing')) {
      return List<BatchPriceDAO>.from(
          json["batch_pricing"].map((e) => BatchPriceDAO.fromJson(e)));
    } else if (json.containsKey('batches')) {
      return List<BatchPriceDAO>.from(
          json["batches"].map((e) => BatchPriceDAO.fromJson(e)));
    }

    return [];
  }

  static String? getCountryCodeFromRes(Map<String, dynamic> json) {
    if (json.containsKey('country_code')) {
      return json['country_code'];
    } else if (json.containsKey('dial_code')) {
      return json['dial_code'];
    }

    return "";
  }

  static InputDecoration textFieldDecorationTheme(String labelText,
      {IconData? prefixIcon, Widget? sufixIcon}) {
    return InputDecoration(
      floatingLabelBehavior: FloatingLabelBehavior.never,
      filled: true,
      isDense: true,
      fillColor: Colors.white, //AppTheme.theme.colorScheme.primaryContainer,
      suffixIcon: sufixIcon,
      prefixIcon: Icon(prefixIcon, color: AppTheme.theme.colorScheme.onSurface),
      hintText: labelText,
      enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.all(
              Radius.circular(Constants.textFieldRadius.medium)),
          borderSide: BorderSide(color: Colors.transparent)),
      focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.all(
              Radius.circular(Constants.textFieldRadius.medium)),
          borderSide: BorderSide(color: Colors.transparent)),
      border: OutlineInputBorder(
          borderRadius: BorderRadius.all(
              Radius.circular(Constants.textFieldRadius.medium)),
          borderSide: BorderSide(color: Colors.transparent)),
      contentPadding: FxSpacing.all(16),
      labelStyle: TextStyle(
          fontWeight: StyleView.fontRegular,
          fontSize: 14.0,
          color: Colors.black),
      hintStyle: TextStyle(
          fontWeight: StyleView.fontRegular,
          color: Colors.black), //FxTextStyle.bodyMedium(color: Colors.black38),
      isCollapsed: true,
      labelText: labelText,
    );
  }

  static String getAddressData({required Address? address}) {
    String result = '';
    if (address != null) {
      if (address.plotNo!.isNotEmpty && address.plotNo != null) {
        result = "${address.plotNo},";
      }
      if (address.buildinghousenumber!.isNotEmpty &&
          address.buildinghousenumber != null) {
        result = result + "${address.buildinghousenumber},";
      }
      if (address.buildingNo!.isNotEmpty && address.buildingNo != null) {
        result = result + "${address.buildingNo},";
      }

      if (address.buildingstreetname!.isNotEmpty &&
          address.buildingstreetname != null) {
        result = result + "${address.buildingstreetname},";
      }

      if (address.villagetowncity != null) {
        result = result + "${address.villagetowncity},";
      }

      if (address.landmark!.isNotEmpty && address.landmark != null) {
        result = result + "${address.landmark},";
      }
      if (address.district != null && address.district!.isNotEmpty) {
        result = result + "${address.district},";
      }

      if (address.state != null) {
        result = result + "${address.state},";
      }

      if (address.postcode!.isNotEmpty && address.postcode != null) {
        result = result + "${address.postcode},";
      }

      if (address.country != null) {
        result = result + "${address.country}";
      }
    }
    if (result.startsWith(',')) {
      result = result.substring(1);
    }
    return result;
  }

  static checkStoragePermissions(BuildContext context) async {
    PermissionStatus storagePermission = await Permission.storage.status;

    if (storagePermission.isGranted) {
      return true;
    } else {
      await Permission.storage.request();
    }
  }

  static downloadExcelReports(
      {required BuildContext? context,
      required String? reqUrl,
      required String? fileName,
      required Map<String, dynamic>? mapData}) async {
    String requiredFilePath = "";
    if (kIsWeb) {
      requiredFilePath = await downloadReports(
          context: context, url: reqUrl!, mapData: mapData, fileName: fileName);
    } else {
      requiredFilePath = await downloadReports(
          context: context, url: reqUrl!, mapData: mapData, fileName: fileName);
    }

    return requiredFilePath;
  }

  static bool isPrivillegeExist(BuildContext context, String key) {
    MenuAppState? menuAppState =
        StoreProvider.of<AppState>(context, listen: false).state.mapData;
    if (menuAppState == null) {
      return false;
    }
    final List<dynamic> reduxStore = menuAppState.featureMenu;
    bool isExist = false;
    isExist = reduxStore.any((element) => element == key);
    return isExist;
  }

  static String? getProductId(Map<String, dynamic> json) {
    if (json.containsKey('product_id')) {
      return json['product_id'];
    } else if (json.containsKey('id')) {
      return json['id'];
    }

    return "";
  }

  static String? getTransactionType(Map<String, dynamic> json) {
    if (json.containsKey('transaction_type')) {
      return json['transaction_type'];
    } else if (json.containsKey('type')) {
      return json['type'];
    }

    return "";
  }
}
