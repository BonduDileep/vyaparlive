import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

class Constants {
  static MaterialRadius buttonRadius =
      MaterialRadius(xs: 4, small: 8, medium: 16, large: 24);
  static MaterialRadius textFieldRadius =
      MaterialRadius(xs: 4, small: 8, medium: 16, large: 24);
  static MaterialRadius containerRadius =
      MaterialRadius(xs: 4, small: 8, medium: 16, large: 24);

  static ColorData softColors = ColorData();
  static const num SOCKET_PORT = 4010;
  static const num ASSETS_PORT = 8089;
  static String? APP_VERSION = dotenv.env['APP_VERSION'];
  static const bool isOndcEnable = false;
  static String? BASE_URL_2 = dotenv.env['BASE_URL'];
  static String? CHAT_URL = dotenv.env['CHAT_URL'];
  //'65.1.45.201'; //'3.7.248.184'; //'15.206.187.54'; //'3.110.108.53';
  static String? BASE_URL = dotenv.env['BASE_URL'];
  static String? HTTP_URL_PREFIX = dotenv.env['HTTP_URL_PREFIX'];
  static String? GRPC_URL_PREFIX = dotenv.env['GRPC_URL_PREFIX'];
  static String? URL_POSTFIX = dotenv.env['URL_POSTFIX'];
  static String? URL_POSTFIX_V2 = dotenv.env['URL_POSTFIX_V2'];
  static String? ENV_BULK_PRODUCTS = dotenv.env['BULK_PRODUCTS_UPLOAD'];
  static String? URL_BULK_PRODUCTS_UPLOAD =
      HTTP_URL_PREFIX! + ENV_BULK_PRODUCTS!;
  static const VERSION_LOOKUP = "lookup/yrApk/version";
  static String APK_URL = HTTP_URL_PREFIX! + BASE_URL! + "/apk/vypar_live.apk";
  static String APK_VERSION_CHECK_URL =
      HTTP_URL_PREFIX! + BASE_URL! + URL_POSTFIX! + VERSION_LOOKUP;
  static String NEW_BASE_URL = HTTP_URL_PREFIX! + BASE_URL! + URL_POSTFIX!;
  static String GRPC_UTIL =
      HTTP_URL_PREFIX! + BASE_URL! + URL_POSTFIX! + 'http-utils/grpc';
  static num LOOKUP_PORT = 8085;
  static String LOOKUP_BASE_URL = '$HTTP_URL_PREFIX$BASE_URL$URL_POSTFIX';

  static String ASSETS_BASE_URL =
      '$HTTP_URL_PREFIX$BASE_URL$URL_POSTFIX'; //'$HTTP_URL_PREFIX$BASE_URL_2:$ASSETS_PORT/';
  static String USER_GRPC_URL = (kIsWeb) ? "users." + BASE_URL! : BASE_URL_2!;
  static String PRODUCT_PRESIGNED_URL =
      '$HTTP_URL_PREFIX$BASE_URL/file'; //'$HTTP_URL_PREFIX$BASE_URL_2:4010/file';
  static num USER_PORT = 4022;
  static String INVITATION_GRPC_URL =
      (kIsWeb) ? GRPC_URL_PREFIX! + "invitation." + BASE_URL! : BASE_URL_2!;
  static num INVITATION_PORT = 8989;
  static String ASSETS_MANAGEMENT_GRPC_URL =
      GRPC_URL_PREFIX! + "assets." + BASE_URL!;
  static String SERVICES_GRPC_URL = GRPC_URL_PREFIX! + "services." + BASE_URL!;
  static num TRANSACTION_PORT = 4025;
  static String BULIST_GRPC_URL =
      (kIsWeb) ? GRPC_URL_PREFIX! + "transaction." + BASE_URL! : BASE_URL_2!;
  static num RETAILER_PORT = 4027;
  static String RETAIL_GRPC_URL =
      (kIsWeb) ? GRPC_URL_PREFIX! + "retail." + BASE_URL! : BASE_URL_2!;
  static num PRODUCTS_PORT = 4024;
  static String PRODUCT_GRPC_URL =
      (kIsWeb) ? GRPC_URL_PREFIX! + "products." + BASE_URL! : BASE_URL_2!;
  static String BU_GRPC_URL =
      (kIsWeb) ? GRPC_URL_PREFIX! + "organization." + BASE_URL! : BASE_URL_2!;
  static num BU_PORT = 4023;
  static String CONSUMABLE_PRODUCTS_GRPC_URL =
      GRPC_URL_PREFIX! + "consumableproducts." + BASE_URL!;
  static String APP_VERSION_CHECK_GRPC_URL =
      GRPC_URL_PREFIX! + "yrappapi." + BASE_URL!;
  static const String GET_INVITATIONCODE_URl = "code/";
  static const String USER_API_URL = "user";
  static const String LOGIN_API_STR = '/login';
  static String CHAT_COMMUNICATION_URL =
      '$HTTP_URL_PREFIX$BASE_URL/communication'; //"http://$BASE_URL_2:$SOCKET_PORT/communication";
  static String LANGUAGE_FILE_URL = HTTP_URL_PREFIX! +
      BASE_URL! +
      URL_POSTFIX! +
      "http-utils/assets/public/language_strings_vyapar_live.xlsx";
  static String BULK_PRODUCT_UPLOAD_URL = "$HTTP_URL_PREFIX" +
      GRPC_URL_PREFIX! +
      "productbulkupdate." +
      BASE_URL! +
      "/bulk/";
  static const UPLOAD_IMAGE_PORT = 4010;
  static String UPLOAD_IMAGE =
      '$HTTP_URL_PREFIX$BASE_URL_2:$UPLOAD_IMAGE_PORT/uploadurl';
  static String IAMGE_BUCKET_URL =
      'https://vyapar-data.s3.ap-south-1.amazonaws.com/';

  static String SSF_BASE_URL = "https://apis.demo.vyaparlive.com";

  static String WHATSAPP_INVOICE_URL = '$HTTP_URL_PREFIX$BASE_URL/pdfs/';
  static String? SHARE_ORDER_FORM_URL = dotenv.env['SHARE_ORDER_FORM_URL'];
  static const int APP_COLOR = 0xFF083e64;
  static const int APP_COLOR_GRADIENT = 0xff396583;
  static const int APP_BACKGROUND_COLOR =
      0x00000000; //0xffffffff; //0xffe6e7e8;
  static const int STEPPER_INDICATOR_COLOR = 0xffc0c0c0;
  static const int GREY_COLOR = 0xffA9A9A9;
  static const int GREY_COLOR_LIGHT = 0xffd8d8d8;
  static const int YELLOW = 0xffF5BE17;
  static const int BG_GREY = 0xffE5E8EE;
  static const int BORDER_GREY = 0xffC5C5C5;
  static const String INVOICE = 'Invoice';
  static const String DATE_FROM = 'DateFrom=';
  static const String DATE_TO = 'DateTo=';
  static const String SIGN_IN_STRING = 'Sign In';
  static const String SIGN_UP_STRING = 'Sign Up';
  static const String USER_STRING = 'User name';
  static const String FULL_NAME = 'Full name';
  static const String OR_STRING = 'Or';
  static const String FORGOT_PASSWORD_STRING = 'Forgot Password';
  static const String USERNAME_AND_PASSWORD_ALERT_STRING =
      'Please Enter User Name and Password';
  static const String USER_NAME_ALERT_STRING = 'Please Enter User Name';
  static const String PASSWORD_ALERT_STRING = 'Please Enter Password';
  static const String INVIKTATION_TITLE_STRING = 'New Invitation';
  static const String ROLE_IN_THE_RELATIONSHIP = 'Role in the Relationship';
  static const String RELATIONSHIPTYPE_TITLE_STRING = 'Select Relationship';
  static const String ABLE_TO_INVITE_TITLE_STRING = 'Able To Invitee';
  static const String SELECT_INVITE_CHOICE_TITLE_STRING = 'Select Invitee';
  static const String BUSINESS_NAME_TITLE_STRING = 'Business Name';
  static const String NEXT_BUTTON_TITLE_STRING = 'Next';
  static const String ABD_WIDGETS_INC_STRING = 'ABD Widgets Inc';
  static const String RECEIVERS_BUYERS_STRING = 'Receivers(Buyers)';
  static const String SUPPLIER_SELLER_STRING = 'Supplier(Seller)';
  static const String DIRECT_NAME_STRING = 'Direct';
  static const String REVIEW_THE_INVITE_FORM_STRING = 'Review the invitation';
  static const String CONFIRM_SEND_INVITE_STRING =
      'Confirm and send invite to ';
  static const String SEND_VIA_SMS_STRING = 'Send Via SMS';
  static const String SEND_VIA_EMAIL_STRING = 'Send Via Email';
  static const String INVITATION_SUCUSSESSFULLY_MESSAGE_STRING =
      'Invitation sent Successfully!';
  static const String TRACK_THE_INVITATION_STATUS_LINK =
      'Track the Invitation Status in the List';
  static const String UNIT_OR_TEAM_NAME_STRING = 'Business Unit/Team';
  static const String SELECT_STRING = 'Select';
  static const String CURRENCY_STRING = 'Currency';
  static const String INVITEE_NAME_STRING = 'Name';
  static const String ENTER_INVITEE_NAME__STRING = ' Invitee Name';
  static const String ENTER_EMAIL_ID = ' Email ID';
  static const String CONTACT_DETAILS_STRING = "CONTACT DETAILS";
  static const String ADDRESS_FORMAT_STRING = "Address Format";
  static const String BUSINESS_LOCATION_NUMBER_STRING = "Location";
  static const String TALUK_STRING = "Taluk";
  static const String POST_CODE_STRING = "Pin Code";
  static const String TAX_INFO_STRING = "TAX INFO";
  static const String TAX_NAME_STRING = "Tax Name";
  static const String EXCEMPTION_REASON_STRING = "Excemption Reason";
  static const String ADDRESS_OF_RECEIVER_STRING = "ADDRESS OF RECEIVER";
  static const String NAME_STRING = "Name";
  static const String ADDRESS_OF_SENDER_STRING = "ADDRESS OF SENDER";
  static const String SUBSCRIPTIONS_STRING = "Subscriptions";
  static const String SUBSCRIPTION_STR = "Vyapar Live Subscription";
  static const String SUCCESSFULL_MSG = "Successfully logged in";
  static const String OKAY_STR = 'OK';
  static const String PROCESSING = "Processing...";
  static const String CREATE_PRODUCT_STRING = 'Create Product List';
  static const String KEY_INVITATION_CODE = "Key_Invitation_Code";
  static const String USER_ID = "user_id";
  static const String KEY_RELATION = "key_Relation";
  static const String KEY_ROLE_RELATION = "key_Role_Relation";
  static const String KEY_INVITE = "key_Invite";
  static const String KEY_COUNTRY = "key_Country";
  static const String KEY_STATE = "key_State";
  static const String KEY_CITY = "key_City";
  static const String KEY_CURENCY = "key_Rupess";
  static const String KEY_TF_INVITE = "Key_Invite";
  static const String KEY_BUSINESS_NAME = "Key_Business";
  static const String KEY_UNIT_NAME = "Key_Unit_Name";
  static const String KEY_EMAIL = "Key_Email";
  static const String KEY_PHONE = "Key_Phone";
  static const String KEY_USER_PHONE = "Key_USER_Phone";
  static const String KEY_COUNTRY_CODE = "Key_Country_code";
  static const String KEY_PASSWORD = "Key_Password";
  static const String KEY_FIREBASE_TOKEN = "Key_firebase_token";
  static const String KEY_USER_NAME = "Key_User_Name";
  static const String KEY_USER_PROFILE_PIC = "Key_User_Profile_Pic";
  static const String SP_AUTH_TOKEN = "sp_auth_token";
  static const List<String> USER_STATUS_LIST = <String>["Active", "In Active"];
  static const List<String> SPR_CONTACT_PREFIX = ['Mr.', 'Mrs.', 'Ms.', 'Sri'];
  static const String CREATE_PRODUCT_LIST_STRING = 'Import Product List';
  static const String CREATE_BU = "Create Bu";
  static const String BU_LIST = "Bu List";
  static const String PRODUCT_NAME_STRING = 'Product Name';
  static const SELECT_BU_Unit = 'Select Business Unit';
  static const String PLEASE_SELECT_ATLEAST_ANY_PRODUCT_ALERT_STRING =
      'Please Select Atleast One Product';
  static const String GALLERY_STRING = 'Select from gallery';
  static const String SHIPPING_ADDRESS = "Shipping address";
  static const String SHIPPING_TO = "Shipping To";
  static const String CHANGE_ADDRESS = "Change address";
  static const String SELECT_SHIP_TO_ADDRESS = 'Select ship to address';
  static const String CAMERA_STRING = 'Take a picture';
  static const String MAKEACHOICE_STRING = 'Make a Choice:';
  static const String FROM_DATE_GREATERTHAN_END_DATE_STRING =
      'To Date Can not be less than From Date';
  static const String FROM_DATE_LESSTHAN_OR_EQUAL_STRING =
      'From Date should be less than or equal to Current Date';
  static const String TODATE_LESSTHAN_OR_EQUAL_STRING =
      'To Date should be less than or equal to Current Date';
  static const String DETAILS_TITLE_STRING = 'DETAILS';
  static const String HISTORY_STRING = 'History';
  static const String SALE_PRICE_STRING = 'Sale Price';
  static const String PRODUCT_PHOTO_STRING = 'Product Photo';
  static const String QUANTITY_STRING = 'Quantity';
  static const String PRICE_STRING = 'Price';
  static const String ADD_TO_CART_STRING = 'Add to Cart';
  static const String VIEW_CART_STRING = 'View Cart';
  static const String ORDER_NOW_STRING = 'Order Now';
  static const String ITEMS_STRING = 'Items';
  static const String ORDER_PLACED_SUCCSESSFULLY_ALERT_STRING =
      'Order Placed Successfully';
  static const String OK_STRING = 'OK';
  static const String NO_IMAGE_SELECTED_STRING = 'No Image Selected';
  static const String ADD_PRODUCTS_STRING = 'Add Products';
  static const String PRODUCT_ADDED_SUCCESS_FULLY_ALERT_STRING =
      'Product Added Successfully';
  static const String PACKAGE_CREATED_SUCCESS_FULLY =
      "Package created successfully.";
  static const String DISCUSSIONS_STRING = 'Discussions';
  static const String GOOD = "Good";
  static const String AVERAGE = "Average";
  static const String Medium = "Medium";
  static const String BATCH_1 = "Batch 1";
  static const String BATCH_2 = "Batch 2";
  static const String BATCH_3 = "Batch 3";
  static const String BATCH_4 = "Batch 4";
  static const String ADD = "Add";

  static const String ORDER_STRING = 'Order';
  static const String CONFIRM_ORDER_STRING = 'Confirm Order';
  static const String SELECTED_PRODUCTS_STRING = 'Selected Products';
  static const String SERIAL_NUMBER_STRING = 'S.No';
  static const String PAYAMOUNT_STRING = 'Pay Amount';
  static const String TOTAL_QUANTITY_STRING = 'Total Quantity';

  static const String GOOD_STRING = 'Good';
  static const String AVERAGE_STRING = 'Average';
  static const String MEDIUM_STRING = 'Medium';
  static const String SETTINGS_STRING = 'Settings';
  static const String MOBILE_NUMBER_STRING = 'MOBILE_NUMBER';

  static const String MOBILE_NUMBER = 'Mobile number';
  static const String CHANGE_LANGUAGE = 'Change Language';
  static const String HINDI_STRING = 'Hindi';
  static const String ENGLISH_STRING = 'English';
  static const String TELUGU_STRING = 'Telugu';
  static const String ALREADY_HAVE_AN_ACCOUNT_STRING =
      'Already have an account? Click here';
  static const String INVITATION_CODE_STRING = 'Invitation Code';
  static const String HAVE_AN_INVITATION_CODE_STRING =
      'Have an invitation code? Click here';

  static const String PROFILE_STRING = 'Profile';
  static const String BUSINESS_UNIT_LIST_STRING = 'Business Unit List';
  static const String TRANSACTION_STRING = 'Transaction';
  static const String BUY_LIST_STRING = 'Purchases';
  static const String SELL_LIST_STRING = 'Sales';
  static const String ORGANIZATION_NAME_STRING = 'Organization Name';
  static const String DATE_STRING = 'Date';
  static const String DISCUSSION_STRING = 'Discussion';
  static const String INVOICE_STRING = 'Invoice';
  static const String TRACK_STRING = 'Track';
  static const String ADD_TRANSACTION_STRING = 'Add Transaction';
  static const String BUY_STRING = 'Buy';
  static const String SELL_STRING = 'Sell';
  static const String NO_DATAFOUND_STRING = 'No Data Found';
  static const String SEND_A_MESSAGE_STRING = 'Send a message';
  static const String ACCEPT_INVITATION_STRING = 'Accept Invitation';
  static const String CATEGORY_STRING = 'Category';
  static const String ORDER_FROM_STRING = 'Order From';
  static const String ADD_SELECTED_STRING = 'Add Selected';
  static const String NEW_INVITATIONS_STRING = 'New Invitations';
  static const String MY_INVITEES_STRING = 'My Invitees';
  static const String VIEWDETAILS_STRING = 'View Details';
  static const String INVITATION_PROFILE_STRING = 'Invitation Profile';
  static const String MY_INVITEES_PROFILE_STRING = 'My Invitees Profile';

  static const RELTION_TYPE_STRING = 'Relation Type';
  static const String RELATION_ROLE_STRING = 'Relation Role';
  static const String INVITEE_DETAILS_STRING = 'INVITEE DETAILS';
  static const String REJECT_STRING = 'Reject';
  static const String SEEPRODUCTS_STRING = 'See Products';
  static const String ACCEPT_STRING = 'Accept';
  static const String SAVE_AND_EXIT_STRING = 'Save & Exit';

  static const String DELETE_PRODUCT_STRING = 'Do you want to Delete Product.';
  static const String USER_DETAILS_STRING = 'USERS DETAILS';
  static const String EDIT_USER_PROFILE_STRING = 'Edit User Profile';
  static const String USER_LIST_STRING = 'User List';
  static const String ADD_NEW_USER_STRING = 'Add New User';

  static const String EDIT_USER_STRING = 'Edit User';
  static const String USER_DETAIL_STRING = 'User Details';
  static const String ROLES_AND_PREVLEGES_STRING = 'Role & Privileges';
  static const String YOUR_ORGANIZATION_SETUP_IS_DONE_STRING =
      'Your Organization Setup Is Done';
  static const String DELETE_STRING = 'Delete';

  static const String PLEASE_ENTER_PERSON_IDENTIFICATION_SCHEME_NAME =
      'Please enter person identification scheme name';
  static const String PLAEASE_ENTER_PERSON_IDENTIFICATION_NUMBER_STRING =
      'Please enter person identification number';
  static const String PLEASE_ENTER_DIGITAL_SIGNATURE =
      'Please enter digital signature';
  static const String SELECT_BUSSINESS_TYPE_STRING = 'Select Business Type';
  static const String SELECT_COUNTRY_CODE_STRING = 'Select Country Code';
  static const String SELECT_CURRENCY_CODE_STRING = 'Select Currency Code';
  static const String PAYMENT_DETAILS_STRING = 'Payment Details';
  static const String RECEIVE_DETAILS_STRING = 'Receive Details';

  static const String IMPORT_STRING = 'Imports';

  static const String EXPORT_STRING = 'Exports';
  static const String REGULATION_STR = 'Regulation';
  static const String TAX_SCHEME_STR = 'Tax Scheme';
  static const String SELECT_SCHEME_STR = 'Select Scheme';
  static const String SELECT_ENTITY_TYPE_STR = 'Select Entity Type';
  static const String BU_DETAILS_UPDATED_STRING =
      'Business unit details updated';
  static const String YOUR_BU_SETUP_IS_DONE_STRING = 'Your BU Setup Is Done';
  static const String SHOW_MORE_STRING = 'Show more';
  static const String FROM_STRING = 'From';
  static const String SHOW_ALL = "Show All";

  static const String TAX_SCHEME_NUMBER_STR = 'Enter Value';
  static const String TAX_SCHEME_NAME_STR = 'Tax Scheme Name';
  static const String TAX_EXEMPTION_STR = 'Tax Exemption';
  static const String RECEIVES_STR = 'Receives';

  static const String CONNECTIONS_STR = 'Connections';

  static const String EXPENSES = 'Expenses';
  static const String RETAILER_STR = 'Retail Invoices';
  static const String OFFLINE_CONNECTIONS = 'B2B connections';

  static const String FOR_SALE_TRUE = '?for_sale=true';
  static const String TEMP_USER_IMAGE_URL =
      "https://picsstocks.com/wp-content/uploads/2019/09/PicsArt_09_06_03.28.21-VQ0tf7fs-829x1024.jpg";
  static const String TEMP_USER_NAME = "abcd(Admin)";
  static const String TEMP_USER_EMAIL = "abcd@gmail.com";
  static const String LANGUAGE_SELECTED = "languageselected";
  static const String STEP_ONE = "1";
  static const String STEP_TWO = "2";
  static const String STEP_THREE = "3";
  static const String STEP_FOUR = "4";
  static const String TEMP_ORGANIZATION_NAME = "SLN Projects";
  static const String TEMP_UNIT_NAME = "Sales Team";
  static const String TEMP_CITY = "Hyderabad";
  static const String TEMP_STATE = "Telangana";
  static const String TEMP_COUNTRY = "India";
  static const String TEMP_COUNTRY_CODE = "+91";
  static const String TEMP_CURRENCY = "Rupees";
  static const String TEMP_PHN = "9786543210";
  static const String TEMP_RELATION_TYPE = "Direct";
  static const String TEMP_RELATION_ROLE = "Supplier(Seller)";
  static const String TEMP_ABLE_INVITEE = "Receivers(Buyers)";
  static const String TEMP_TYPE = "Type";

  static const String TEMP_DATE = "17/02/2020";
  static const String SELL_DISCUSSION = "Sell Discussion";
  static const String TEMP_QUANTITY = "12";
  static const String TEMP_PRICE = "Rs.20";
  static const String EDIT_BUSINESS_UNIT = "Edit Business Unit";
  static const String TEMP_BRANCH_NAME = "Swagruha foods";
  static const String ADD_BU_UNIT = 'Add Business Unit';
  static const String MR = "Mr.";
  static const String TEMP_DESIGNATION = "Software";
  static const String TEMP_DEPT = "Mobile Application";
  static const String TEMP_BU_MARKETING = "BU: Marketing";
  static const String COMPLETED = "Completed";

  static const String ENTER_EPAY = 'Please enter epay code';
  static const String ENTER_PANALITY_AMOUNT = 'Please enter penalty amount';
  static const String ENTER_SWIFT_CODE = 'Please enter SWIFT code';
  static const String ENTER_MICR_CODE = 'Please enter MICR code';
  static const String SELECT_TYPE_OF_DETAILS_STR = 'Select Type Of Details';
  //  , ,
  static const String STOCK_DETAILS_STR = 'Stock Details';
  static const String PURCHASE_DETAILS_STR = 'Purchase Details';
  static const String OFFER_DETAILS_STR = 'Offer Details';

  /// Suppliers Details

  static const String SUP_ITEM_NUMBER = "Item Number";
  static const String SUP_ADDRESS = "Supplier Address";
  static const String SUP_BUILD_NUM = "Building Number";
  static const String CONTACTS_STR = "Contacts";
  static const String ENTER_CODE_HERE_STR = 'Enter code here';

  static const String PRODUCT_DETAILS_STR = "PRODUCT DETAILS";
  static const String RELEASE_DATE = "Release Date";
  static const String MOBILE_STR = "Model Number";
  static const List<String> STATUS = ["Pending", "Completed"];
  static const List<String> DELIVERY_TYPE = [
    "Challan",
    "Courier",
    "Gatepass and similar documents",
    "LR No"
  ];
  static const String ORDER_IS_IN_PROGRESS = "Your order is in progress...";

  // ignore: non_constant_identifier_names
  static List<String> NUMBEROFDAYS = [
    "0",
    "1",
    "2",
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    "9",
    "10",
    "11",
    "12",
    "13",
    "14",
    "15",
    "16",
    "17",
    "18",
    "19",
    "20",
    "21",
    "22",
    "23",
    "24",
    "25",
    "26",
    "27",
    "28",
    "29",
    "30",
    "31",
    "32",
    "33",
    "34",
    "35",
    "36",
    "37",
    "38",
    "39",
    "40",
    "41",
    "42",
    "43",
    "44",
    "45",
    "46",
    "47",
    "48",
    "49",
    "50",
    "51",
    "52",
    "53",
    "54",
    "55",
    "56",
    "57",
    "58",
    "59",
    "60",
    "61",
    "62",
    "63",
    "64",
    "65",
    "66",
    "67",
    "68",
    "69",
    "70",
    "71",
    "72",
    "73",
    "74",
    "75",
    "76",
    "77",
    "78",
    "79",
    "80",
    "81",
    "82",
    "83",
    "84",
    "85",
    "86",
    "87",
    "88",
    "89",
    "90",
    "91",
    "92",
    "93",
    "94",
    "95",
    "96",
    "97",
    "98",
    "99",
    "100",
    "101",
    "102",
    "103",
    "104",
    "105",
    "106",
    "107",
    "108",
    "109",
    "110",
    "111",
    "112",
    "113",
    "114",
    "115",
    "116",
    "117",
    "118",
    "119",
    "120"
  ];
  // ignore: non_constant_identifier_names
  static List<String> PERCENTAGELIST = [
    "0 %",
    "1 %",
    "2 %",
    "3 %",
    "4 %",
    "5 %",
    "6 %",
    "7 %",
    "8 %",
    "9 %",
    "10 %",
    "11 %",
    "12 %",
    "13 %",
    "14 %",
    "15 %",
    "16 %",
    "17 %",
    "18 %",
    "19 %",
    "20 %",
    "21 %",
    "22 %",
    "23 %",
    "24 %",
    "25 %",
    "26 %",
    "27 %",
    "28 %",
    "29 %",
    "30 %",
    "31 %",
    "32 %",
    "33 %",
    "34 %",
    "35 %",
    "36 %",
    "37 %",
    "38 %",
    "39 %",
    "40 %",
    "41 %",
    "42 %",
    "43 %",
    "44 %",
    "45 %",
    "46 %",
    "47 %",
    "48 %",
    "49 %",
    "50 %",
    "51 %",
    "52 %",
    "53 %",
    "54 %",
    "55 %",
    "56 %",
    "57 %",
    "58 %",
    "59 %",
    "60 %",
    "61 %",
    "62 %",
    "63 %",
    "64 %",
    "65 %",
    "66 %",
    "67 %",
    "68 %",
    "69 %",
    "70 %",
    "71 %",
    "72 %",
    "73 %",
    "74 %",
    "75 %",
    "76 %",
    "77 %",
    "78 %",
    "79 %",
    "80 %",
    "81 %",
    "82 %",
    "83 %",
    "84 %",
    "85 %",
    "86 %",
    "87 %",
    "88 %",
    "89 %",
    "90 %",
    "91 %",
    "92 %",
    "93 %",
    "94 %",
    "95 %",
    "96 %",
    "97 %",
    "98 %",
    "99 %",
    "100 %",
  ];

  static const List<String> MessageTypes = [
    "MESSAGE_TEXT",
    "MESSAGE_PRODUCT",
    "MESSAGE_IMAGE"
  ];

  static const List<String> UNIT_PRICE = [
    "bottle",
    "box",
    "can",
    "dozen",
    "each",
    "gallon",
    "grams",
    "kg",
    "lb",
    "litre",
    "milli-litre",
    "oz",
    "pallet",
    "pint",
    "strip",
    "tablet",
    "tray",
    "unit",
    "bag"
  ];

  static const List<String> PAYMENT_TERMS = [
    "PIA (Payment in advance)",
    "Net 7 (Payment seven days after invoice date)",
    "Net 10 (Payment ten days after invoice date)",
    "Net 30 (Payment 30 days after invoice date)",
    "Net 60 (Payment 60 days after invoice date)",
    "Net 90 (Payment 90 days after invoice date )",
    "EOM (End of month)",
    "21 MFI (21st of the month following invoice date)",
    "1% 10 Net 30 (1% discount if payment received within ten days otherwise payment 30 days after invoice date)",
    "COD (Cash on delivery)",
    "Cash account (Account conducted on a cash basis, no credit)",
    "Letter of credit (A documentary credit confirmed by a bank, often used for export)",
    "Bill of exchange (A promise to pay at a later date, usually supported by a bank)",
    "CND (Cash next delivery)",
    "CBS (Cash before shipment)",
    "CIA (Cash in advance)",
    "CWO (Cash with order)",
    "1MD (Monthly credit payment of a full month's supply)",
    "2MD (As above plus an extra calendar month)",
    "Contra (Payment from the customer offset against the value of supplies purchased from the customer)",
    "Stage payment (Payment of agreed amounts at stage)"
  ];

  static const List<String> measurementsList = [
    "cm",
    "feet",
    "inch",
    "meter",
    "mm"
  ];
  static const List<String> weightMeasurementsList = ["kg", "grams"];
  static const List<String> volumeMeasurementsList = ["litre", "ml"];
  static const List<String> taxTypes = ["GST", "VAT"];
  static const List<String> taxRateValues = [
    "0 %",
    "1 %",
    "2 %",
    "3 %",
    "4 %",
    "5 %",
    "6 %",
    "7 %",
    "8 %",
    "9 %",
    "10 %",
    "11 %",
    "12 %",
    "13 %",
    "14 %",
    "15 %",
    "16 %",
    "17 %",
    "18 %",
    "19 %",
    "20 %",
    "21 %",
    "22 %",
    "23 %",
    "24 %",
    "25 %",
    "26 %",
    "27 %",
    "28 %",
    "29 %",
    "30 %",
    "31 %",
    "32 %",
    "33 %",
    "34 %",
    "35 %",
    "36 %",
    "37 %",
    "38 %",
    "39 %",
    "40 %",
    "41 %",
    "42 %",
    "43 %",
    "44 %",
    "45 %",
    "46 %",
    "47 %",
    "48 %",
    "49 %",
    "50 %"
  ];

  /// Transaction status

  static const String DISCUSSION_STARTED = "Discussion started";
  static const String DISCUSSION_ACCEPTED = "Discussion accepted";
  static const String DISCUSSION_NOT_ACCEPTED_BY_SELLER =
      "Discussion not accepted by seller";
  static const String DISCUSSION_NOT_ACCEPTED_BY_BUYER =
      "Discussion not accepted by buyer";
  static const String ORDER_PLACED = "Order Placed";
  static const String ORDER_ACCEPTED = "Order Accepted";
  static const String ORDER_REJECTED = "Order Rejected";
  static const String INVOICE_GENERATED = "Invoice generated";
  static const String PACKING_COMPLETED = "Packing completed";
  static const String PACKING_ASSIGNED = "Packing assigned";
  static const String READY_FOR_DELIVERY = "Ready for delivery";
  static const String STOCK_NOT_RESOLVED = "Stock not resolved";
  static const String STOCK_RESOLVED = "Stock resolved";
  static const String STOCK_RECEIVED = "Stock received";
  static const String PAYMENT_NOT_RESOLVED = "Payment not resolved";
  static const String PAYMENT_RESOLVED = "Payment resolved";
  static const String PO_GENERATED = "PO generated";
  static const String CTR1 = "CTR1";
  static const String CTR3 = "CTR3";

  static const List<String> transactionsStatusList = [
    DISCUSSION_STARTED,
    DISCUSSION_ACCEPTED,
    DISCUSSION_NOT_ACCEPTED_BY_SELLER,
    DISCUSSION_NOT_ACCEPTED_BY_BUYER,
    ORDER_PLACED,
    ORDER_ACCEPTED,
    ORDER_REJECTED,
    INVOICE_GENERATED,
    PACKING_COMPLETED,
    PACKING_ASSIGNED,
    READY_FOR_DELIVERY,
    STOCK_NOT_RESOLVED,
    STOCK_RESOLVED,
    STOCK_RECEIVED,
    PAYMENT_NOT_RESOLVED,
    PAYMENT_RESOLVED,
    STOCKS_DISPATCHED
  ];

  /// Push notification status
  static const String PUSH_TRANSACTION_STARTED = "TRANSACTION_START";
  static const String PUSH_DISCUSSION_STARTED = "TRANSACTION_DISCUSSION";
  static const String PUSH_TRANSACTION_PACKING = "TRANSACTION_PACKING";
  static const String PUSH_TRANSACTION_ORDER = "TRANSACTION_ORDER";
  static const String PUSH_TRANSACTION_INVOICE = "TRANSACTION_INVOICE";
  static const String PUSH_TRANSACTION_DELIVERY = "TRANSACTION_DELIVERY";
  static const String PUSH_STOCK_RECONCILIATION_STARTED =
      "TRANSACTION_STOCK_RECONCILIATION";
  static const String PUSH_STOCK_RECONCILIATION_NOT_RESOLVED =
      "TRANSACTION_STOCK_RECONCILIATION_NOT_RESOLVED";
  static const String PUSH_STOCK_RECONCILIATION_RESOLVED =
      "TRANSACTION_STOCK_RECONCILIATION_RESOLVED";
  static const String PUSH_PAYMENT_RECONCILIATION_STARTED =
      "TRANSACTION_PAYMENT_RECONCILIATION";
  static const String PUSH_PAYMENT_RECONCILIATION_NOT_RESOLVED =
      "TRANSACTION_PAYMENT_RECONCILIATION_NOT_RESOLVED";
  static const String PUSH_PAYMENT_RECONCILIATION_RESOLVED =
      "TRANSACTION_PAYMENT_RECONCILIATION_RESOLVED";
  static const String PUSH_TRANSACTION_MENU_ORDER = "TRANSACTION_MENU_ORDER";
  static const String PUSH_TRANSACTION_ASSIGN = "TRANSACTION_ASSIGN";
  static const String PUSH_TRANSACTION_ORDER_ACCEPTED =
      "TRANSACTION_ORDER_ACCEPTED";
  static const String PUSH_TRANSACTION_ORDER_REJECTED =
      "TRANSACTION_ORDER_REJECTED";
  static const String PUSH_CREATE_OFFLINE_ORDER = "CREATE_OFFLINE_ORDER";

  static const double HEADER_FONT_SIZE = 13;
  static const double SUB_HEADER_FONT_SIZE = 13;
  static const double REGULAR_FONT_SIZE = 12;
  static const double LARGE_FONT_SIZE = 15;
  static const double EXTRA_LARGE_FONT_SIZE = 16;

  static List<Color?> linearGradientcolors = [
    Colors.white,
    Colors.blue[50],
    Colors.blue[100],
    Colors.blue[300],
    Colors.blueAccent
  ];

  static const String FCM_MESSAGE_LIST_SP_KEY = "FCM_MESSAGE_LIST_SP_KEY";
  static const String SELECTE_HOME_PAGE_BU_ID_SP_KEY =
      "SELECTED_HOME_PAGE_BU_ID_SP_KEY";
  static const String BUY_REPORTS = "Buy Reports";
  static const String SELL_REPORTS = "Sell Reports";
  static const String SALES_TEAM_REPORTS = "Field Sales Team Reports";
  static const String DELIVERY_PENDING_REPORTS = "Delivery Pending Reports";
  static const String PACKING_PENDING_REPORTS = "Packing Pending Reports";
  static const String GST_REPORTS = "GST Reports";
  static const String PRODUCT_REPORTS = "Products Reports";
  static const String SUBSCRIPTION_EXCEED = "Subscription limit exceeded";
  static const String CAMERA = "Camera";
  static const String GALLERY = "Gallery";

  static const List<String> featureGroupItems = [
    "transactions",
    "connections",
    "product",
    "subscription",
    "In Person Order",
    "user",
    "invitation",
    "business_unit",
    "product_consumption",
    "assets",
    "reports",
    "retail_sales",
    "expenses"
  ];

  static const List<String> featureGroupItemKey = [
    "TRANSACTION",
    "CONNECTIONS",
    "PRODUCT",
    "SUBSCRIPTION",
    "IN_PERSON_ORDER",
    "USERS",
    "INVITATION",
    "BUSINESS_UNIT",
    "PRODUCTION_CONSUMPTION",
    "ASSETS_MANAGEMENT",
    "REPORTS",
    "RETAIL_SALES",
    "EXPENSES"
  ];

  ///Subscription Payment Status

  static const String NOT_INITIATED = "not_initiated";
  static const String CANCELLED_BY_USER = "cancelled_by_user";
  static const String FAILED_AT_YR = "failed_at_yr";
  static const String FAILDED_AT_UPI = "failed_at_upi";
  static const String PENDING_AT_UPI = "pending_at_upi";
  static const String SUBSCRIPTION_DONE = "SUCCESS";
  static const String EXPIRED = "EXPIRED";

  static const String GALLERY_IMAGE = "gallery_image";
  static const String SERVER_IMAGE = "server_image";
  static const String INVOCIE_IMAGE = "invoice_image";

  /// product
  static const String PRODUCT_NAME = "Product Name";
  static const String QUANTITY = "Quantity";
  static const String PRICE = "Price";
  static const String PRICE_UNIT = "Unit Price";
  static const String TOTAL_AMOUNT = "Total Amount";
  static const String PRODUCT = "Product";
  static const String BARCODE = "Barcode";
  static const String PACK_SIZE = "Pack Size";

  /// Home Page Constants
  static const String YOUR_BU = "Your BU\'s";
  static const String IN_PERSON_ORDERS = 'In-Person Orders';
  static const String HOME_STR = "HOME";
  static const String INVENTORY = 'Inventory';
  static const String ORDERS = 'Orders';
  static const String PAYMENT_REMINDER = 'Payment Reminder';
  static const String STOCK_DELIVERY = 'Stock Delivery';
  static const String OFFLINE_PURCHASE_ORDER = 'Offline Purchase Orders';
  static const String INVITATIONS_STRING = 'Invitations';
  static const String RECENT_ACTIVITY = 'Recent Activity';
  static const String NO_ACTIVITY = 'No Activity Today';
  static const String ARE_YOU_SURE_STRING = 'Are you sure?';
  static const String DO_YOU_WANT_EXIT_APP_STRING =
      'Do you want to exit the App.';
  static const String NO_STRING = 'No';
  static const String YES_STRING = 'Yes';

  /// Organization Page Constants
  static const String LOCATIONS = "Locations";
  static const String ROLES = "Roles";
  static const String USERS_STR = "Users";
  static const String PRODUCTS_STR = 'Products';
  static const String SUPPLIER_PRODUCTS_STR = 'Supplier Products';
  static const String TRANSACTIONS_STR = "Transactions";
  static const String STR_COUNTRY_DETAILS = 'COUNTRY DETAILS';
  static const String OFFICE_NUMBER = 'Office Number';
  static const String REG_CITY = "REGISTER";
  static const String RECEIVE_TAX = "RECEIVE TAX";
  static const String BASIC_DETAILS_STRING = "BASIC DETAILS";
  static const String BUSSINESS_INPUT_STRING = "Business Name";
  static const String SHORT_NAME_STRING = "Short Name";
  static const String SELECT_NUMBER_OF_DAYS = "Select Number Of Days";
  static const String FILE_UPLAODED = "File uploaded!";
  static const String CONTAIN_DATA = "contain data";
  static const String WEBSITE_STRING = "Website";
  static const String BUSINESS_TYPE = "Business Type";
  static const String COUNTRY_CODE_STRING = "Country Code";
  static const String CURRENCY_CODE_STRING = "Currency Code";
  static const String BUSSINESS_DETAILS_STRING = "PARENT DETAILS";
  static const String BUSINESS_UNIT_STRING = "Business Unit";
  static const String BUSSINESS_UNIT_WEBSITE_NAME_STRING = "Business Website";
  static const String HEAD_OF_BUSSINESS_UNIT_STRING = "Head Of Business";
  static const String SAVE_AND_NEXT = "Save & Next";
  static const String ADDRESS_DETAILS = "ADDRESS DETAILS";
  static const String PLOT_NO = "Plot No";
  static const String BULIDING = 'Building';
  static const String PIN_CODE = "Pin Code";
  static const String BUILDING_HOUSE_NUMBER_STRING = "House No";
  static const String BUILDING_STREET_NAME_STRING = "Street Name";
  static const String COLONY_SELECTOR_AREA_LOCALITY_STRING = "Locality";
  static const String LAND_MARK_STRING = "Landmark";
  static const String STATE_NAME_STRING = 'State';
  static const String COUNTRY_NAME_STRING = 'Country';
  static const String CITY_NAME_STRING = 'City';
  static const String DISTRICT_STRING = "District";
  static const String REGISTRATION_HEADER_STRING = "REGISTRATION DETAILS";
  static const String COMPANY_NAME = "Company Name";
  static const String LEGAL_ENTITY_STRING = "LEGAL TYPE";
  static const String GOV_REGISTERATION_SCHEME_STRING = "Scheme";
  static const String REGISTRATION_DATE_STRING = "Registration Date";
  static const String REGISTRATION_COUNTRY_STRING = "Registration Country";
  static const String REGISTRATION_CITY_STRING = "Registration City";
  static const String REGISTRATION_STATE_STRING = "Registration State";
  static const String LEGAL_ENTITY_TYPE = "Legal Entity Type";
  static const String DIRECTOR = "Director";
  static const String DIRECTOR_NAME = "Director Name";
  static const String SELECT_ID = "Select ID";

  static const String TAX_SCHEME_STRING = "TAX ID";
  static const String TAX = "Tax";
  static const String TAX_TYPE = "Tax Type";
  static const String TAX_ID = "Tax ID";
  static const String TAX_SCHEME = "Tax Scheme";
  static const String REGULATION = "Regulation";
  static const String UPDATE_REGULATION = "Update Regulation";
  static const String ADD_REGULATION = "Add New Regulation";
  static const String ADD_DIRECTOR = "Add New Director";
  static const String REGULATION_NAME = "Regulation Name";
  static const String REGULA_ID = "Regulation ID";
  static const String EXPORTS = "Exports";
  static const String IMPORTS = "Imports";
  static const String IMPORT_DETAILS = 'Imports Details';
  static const String EXPORT_DETAILS = 'Exports/Imports Details';
  static const String REGISTRATION_NAME = "Registration Name";
  static const String REGISTRATION_ID = "Registration ID";
  static const String EXPORTS_ID = "EXPORTS/IMPORTS IDs"; //"EXPORTS ID";
  static const String IMPORTS_ID = "IMPORTS ID";
  static const String LOCATION_NAME = "Location Name";

  static const String CONTACT_PERSON = "Contact Person";
  static const String LOCATION_PHONE_NUMBER = "Location Phone Number";
  static const String STOCK_DISPATCH_LOCATIONS = "STOCK DISPATCH LOCATION";
  static const String STOCK_RECIVERS_LOCATIONS =
      "STOCK/OFFICE LOCATION"; //"STOCK RECEIVE LOCATION";
  static const String STOCK_DISPATCH = 'Stock Dispatch';
  static const String STOCK_RECEIVE = 'Stock/Office Details';
  static const String BANK_DETAILS = "BANK DETAILS";
  static const String BANK_NAME = "Bank Name";
  static const String BANK_ACCOUNT_NAME = "Account Name";
  static const String BANK_ACCOUNT_NUMBER = "Account Number";
  static const String EPAY = "UPID";
  static const String SWIFT_CODE = "SWIFT Code";
  static const String MICR_CODE = "MICR Code";
  static const String IFSC_CODE = "IFSC Code";
  static const String PAYMENT_TERMS_STRING = "PAYMENT TERMS";
  static const String INVOICE_CURRENCY_CODE_STRING = "Invoice Currency Code";
  static const String PAYMENT_PERIOD_CODE_STRING = "Payment Period Code";
  static const String INVOICE_DESCRIPTION_STRING = "Invoice Description";
  static const String PENALTY_AMOUNT = "Penalty Amount";
  static const String DESCRIPTION_STRING = "Description";
  static const String PENALTY_BASIC_AMOUNT_STRING = "Penalty Basis Amount";
  static const String INVOICE_PAYMENT_TERMS = "Invoice payment terms";
  static const String CUST_REMARKS = "Custom remarks for invoice";
  static const String TERMS_CONDITIONS = "Terms & Conditions";
  static const String ADVANCE_PAYMENT = "Advance Payment";
  static const String SELECT_DATE = "Select Date";
  static const String SELECT_BUSINESS_TYPE = "Select Business Type";
  static const String SELECT_LEGEL_ENTITY = "Select Entity Type";
  static const String DIRECTORS_NAME_STRING = "DIRECTORS";
  static const String ENTER_DIRECTOR_NAME = "Please enter director name";
  static const String NUMBER = "Number";
  static const String DIGITAL_SIGNATURE = "Digital Signature";
  static const String ADDRESS = "Address";
  static const String ENTER_BANK_NAME = 'Please enter bank name';
  static const String ENTER_ACCOUNT_NUMBER = 'Please enter a/c number';
  static const String IDENTIFICATION_SCHEME_STRING = "Identification Scheme";
  static const String IDENTIFICATION_NUMBER_STRING = "Identification Number";
  static const String GOVT_TAX_NUMBER_STRING = "Tax Number";
  static const String BUSINESS_SCHEME_NAME = 'Business Scheme Name';
  static const String ADD_BANK = 'Add Bank Details';
  static const String SELECT_PERCENTAGE = "Select percentage";
  static const String SELECT_PAYMNET_TERMS = "Select payment term";
  static const String REASON = "Reason";
  static const String TERM = "Term";
  static const String TERM_TYPE = "Term Type";
  static const String ADD_NEW_TERM = "Add New Term";
  static const String TYPE = "Type";
  static const String ENTER_TYPE = "Enter Type";

  /// Users page constants

  static const String USER_STATUS = "User Status";
  static const String USER_LOCATION = "User Location";
  static const String CONTACT_PREFIX = 'Prefix';
  static const String CONTACT_NAME = 'Name';
  static const String CONTACT_BUSINESS_DESIGNATION = 'Designation';
  static const String CONTACT_DEPT = 'Department';
  static const String CONTACT_BU_EMAIL = 'Business Email';
  static const String CONTACT_MOBILE = 'Mobile Number';
  static const String USER_DOJ = 'Date Of Joining';
  static const String USER_DOB = 'Date Of Birth';
  static const String USER_ORGANIZATION = 'Organization';
  static const String USER_ORGANIZATION_MY = "My Organization";
  static const String PERSONAL_DETAILS = "PERSONAL DETAILS";
  static String? SELECT_PREFIX = 'Mr.';
  static const String PASSWORD = 'Password';
  static const String PHONE_NUMBER = 'Phone Number';
  static const String BUSINESS_DETAILS = 'BUSINESS DETAILS';
  static const String BUSINESS_LOCATION = 'Business Location';
  static const String ROLE_ASSIGN = 'ROLE ASSIGN';
  static const String ROLE = 'Role';
  static const String SELECT_ROLE = "Select Role";
  static const String NO_PERMISSION_ROLE =
      "No Permissions added for this Role.";
  static const String ADD_STRING = 'ADD';
  static const String UPDATE_STRING = 'Update';
  static const String STR_CANCEL = "Cancel";

  /// Products page constants
  static const String PRODUCT_LIST_STR = "Product List";
  static const String SORT_BY_STR = "Sort By";
  static const String OFFER = "Offer";
  static const String SUPPLIER = "Supplier";
  static const String NOT_IN_STOCK = "Not In-Stock";
  static const String NOT_FOR_SALE = "Not For Sale";
  static const String APPLY_FILTER = "Apply Filter";
  static const CREATE_PRODUCT = 'Create Products';
  static const String ADD_PRODUCT = 'Add Product';
  static const String UPDATE_PRODUCT = 'Update Product';
  static const String INFO = 'Info';
  static const String NO_BUSINESS_UNITS = "You have no internal business units";
  static const String NO_DISTRIBUTORS = "You have no distributors";

  static const String ERROR = 'Error';
  static const String HAVE_NO_PRODUCTS =
      'You do not have products. Please create products.';
  static const String OFFERS = 'Offers';
  static const String SUPPLIERS = 'Suppliers';

  static const String DETAILS = "Details";
  static const String SUPPLIER_DETAILS = "Supplier Details";
  static const String EDIT = 'Edit';
  static const String WRITE = "Write";
  static const String READ = "Read";
  static const String PASSWORD_MINIMUM_CONS_4_LETTERS =
      "Password Minimum Consists 4 Letters";
  static const String NO_INTERNET = "No Internet Connection";
  static const String PRODUCT_DETAILS = 'Product Details';
  static const String INDIAN_RUPEE = 'IndianRupee';
  static const String PACKAGE_NAME = "Package Name";
  static const String SHARE_USER_DATA = "Share User Data";
  static const String SHARE_INVITATION = "Share Invitation";
  static const String NO_DATA_FOUND = "No Data Found";
  static const String ATTRIBUTES = "ATTRIBUTES";
  static const String PRODUCTDETAILS = "PRODUCT DETAILS";
  static const String BRAND = "Brand";
  static const String MODEL = "Model";
  static const String THIS_PRODUCT_HAVE_NO_MRP = "This product have no MRP";
  static const String THIS_SELECTED_PRODUCT_HAS_NO_QUANTITY =
      "The selected product has no quantity.";
  static const String BATCH_NO = "Batch Number";
  static const String ADD_TO_CONTACT_LIST = "Add to contact list";
  static const String QUANTITY_SHOULD_NOT_BE_MORE_THAN_ACTUAL_QUANTITY =
      "Quantity should not be more than actual quantity";
  static const String QUANTITY_SHOULD_NOT_BE_EMPTY =
      "Quantity should not be empty";
  static const String PLEASE_SELECT_INVENTORY_ =
      "Please Select The Inventory Type For";
  static const String PLEASE_ENTER_BATCH_NO_ = "Please Enter Batch Number For";
  static const String ENTER_UNIT_PRICE_NO = "Please Enter Unit Price For";
  static const String INVOICE_NO_PLEASE = "Please Enter Invoice Number";
  static const String PRODUCT_SEGMENT = "Product Segment";
  static const String PRODUCT_CATEGORY = "Product Category";
  static const String PRODUCT_SUB_CATEGORY = "Product Sub-Category";
  static const String MANUFACTURER_DETAILS = "MANUFACTURER DETAILS";
  static const String MANUFACTURER_NAME = "Manufacturer Name";
  static const String MANUFACTURE_DATE = "Manufacture Date";
  static const String MANUFACTURER_ADDRESS = "Manufacturer Address";
  static const String ITEM_DETAILS = "ITEM DETAILS";
  static const String ONDC_FORM = "ONDC FORM";
  static const String HEIGHT = "Height";
  static const String WIDTH = "Width";
  static const String DEPTH = "Depth";
  static const String VOLUME = "Volume";
  static const String WEIGHT = "Weight";
  static const String HSN_CODE = "HSN Code";
  static const String RATE = "Rate";
  static const String PRICE_C = "PRICE";
  static const String UNIT = "Unit";
  static const String PER = "Per:";
  static const String SELECT_UNIT = "Select unit";
  static const String CURRENCY_NAME = "Currency Name";
  static const String HAVE_NO_OFFERS = "This product have no offers.";
  static const String HAVE_NO_SUPPLIERS = "This product have no suppliers";
  static const String OFFER_NAME = "Offer Name";
  static const String OFFER_QTY = "Offer Quantity";
  static const String MIN_ORDER = "Minimum Order";
  static const String MAX_ORDER = "Maximum Order";
  static const String START_DATE = "Start Date";
  static const String END_DATE = "End Date";
  static const String SUPPLY_TIME = "Supply Time";
  static const String OFFER_DETAILS = "Details";
  static const String CREATE_RETURN_DOC_NOTE = "Create Return Document Note";
  static const String OFFER_IN_PERCENTAGE = "Discount In Percentage";
  static const String OFFER_IN_AMOUNT = "Discount In Amount";

  static const String OFFER_IN_PERCENTAGE_SSF = "percentage";
  static const String OFFER_IN_AMOUNT_SSF = "amount";

  static const String OFFER_IN_QUANTITY = "Offer Quantity";
  static const String CONTACT_NUMBER = "Contact Number";
  static const String AVAILABLE_LOCATIONS = "AVAILABLE LOCATIONS";
  static const String NO_DETAILS = "no details available.";
  static const String LOCATION = "Location";
  static const String TRANSIT_DETAILS_C = "TRANSIT DETAILS";
  static const String IS_SUCCESSFULLY_REMOVE_DIS =
      "is successfully removed from distributors list.";
  static const String IS_SUCCESSFULLY_ADDED_AS_DIS =
      "is successfully added as distributor.";
  static const String BACK_BUTTION_MESSAGE =
      "Do you want to leave this screen as you may lose your changes.";
  static const String QUANTITY_NOT_ASSIGNED_TO_LOCATION =
      'Balance quantity not assigned to any location';
  static const String QUANTITY_ADJUSTED_SUCCESSFULLY =
      'Quantity Adjusted Successfully!';
  static const String ARE_YOU_SURE_ADD_ENTER_QUANTITY_TO_INVENTORY =
      'Are You Sure, Do You Want To Add Entered Quantity To';
  static const String PRODUCT_BASIC_DETAILS = "PRODUCT BASIC DETAILS";
  static const String EXPIRE_DATE_STR = "Expiration Date";
  static const String IN_STOCK = "In Stock";
  static const String FOR_SALE = "For Sale";
  static const String FEATURES = "FEATURES";
  static const String BATCHES_IN_LOC = "Batches in Location";
  static const String TOTAL_AVAILABLE_QUAN_FOR_BATCH =
      "Total Available Quantity for batch";
  static const String YOU_HAVE_NO_INVENTORY_LOC =
      "You have no inventory locations.";
  static const String INVENTORY_QUANTITY_SHOULD_NOT_BE_MOREACTUAL_QUAN =
      "Inventory quantity should not be more than actual quantity";
  static const String ADD_NEW_FEATURE = "Add New Feature";
  static const String ASSIGNED_QUANTITY_TO_LOCATION =
      'Assigned Quantity To Locations';
  static const String FEATURE_NAME = "Feature Name";
  static const String FEATURE_DETAILS = "Feature Details";
  static const String UNIT_STRING = "unit";
  static const String INVENTORY_QUANTITY = "Inventory Quantity";
  static const String BATCH_DETAILAS_AT_DIFF_LOC =
      "Batch Details at Different Locations:";
  static const String YOU_HAVE_NO_RAW_MATERIAL_LIST =
      "You have no raw material issuance list";

  static const String STOCK_AT_DIFF_LOC = "Stock at Different Locations:";

  static const String NET_RATE = "Net Rate (Our purchase Price)";
  static const String DO_YOU_WANT_TO_ADD_ENTERED_QUANTITY =
      "Are you sure, Do you want add entered quantity to";
  static const String RAW_MATERIAL_ISSUANCE_NOTE = "Raw Material Issuance Note";
  static const String NO_RAW_MATERIAL_ISSUANCE_LIST =
      "No Raw Material Issuance Note List";
  static const String MRP = "MRP";
  static const String TAX_DETAILS = "TAX DETAILS";
  static const String UPDATE_INVENTORY = "Update Inventory";
  static const String ADD_INVENTORY = "Add New Inventory";
  static const String REMAINING_QUANTITY = "Remaining quantity";
  static const String INVALID_QUANTITY = "Invalid quantity";
  static const String SELECT_SEGMENT = "Select segment";
  static const String SELECT_CATEGORY = "Select Category";
  static const String SELECT_SUB_CATEGORY = "Select Sub-Category";
  static const String SELECT_COUNTRY = "Select Country";
  static const String SELECT_STATE = "Select State";
  static const String SELECT_CITY = "Select City";
  static const String SELECT_DISTRICT = "Select District";
  static const String SELECT = "Select";
  static const String OFFER_DATA = "Offer Data..";
  static const String UPDATE_OFFER = "Update Offer";
  static const String SAVE_CHANGES = "Save Changes";
  static const String ADD_OFFER = "Add Offer";
  static const String UPDATE_SUPPLIER = "Update Supplier";
  static const String ADD_SUPPLIER = "Add Supplier";
  static const String STR_SAVE = "Save";
  static const String VALUE = "Value";
  static const String ACTIVE_STRING = 'Active';
  static const String Min_ORDER = "Min order";
  static const String Max_ORDER = 'Max order';
  static const String CREATE_OFFER = "Create Offer";
  static const String IN_ACTIVE = 'In-Active';
  static const String WARNING = "Warning";
  static const String WARNING_TEXT = "Are you sure? Do you want to remove";
  static const String OFFERS_C = 'OFFERS';
  static const String SUPPLIERS_C = 'SUPPLIERS';
  static const String EMAIL_ID_STRING = 'Email Id';
  static const String STATUS_STRING = 'Status';
  static const String SELECT_LOCATION = "Select Location";
  static const String SELECT_BU_LOCATION = "Select Bu Location";
  static const String SELECT_DEPARTMENT = "Select Department";
  static const String USER_CREATION = "User Creation";
  static const String USER_CREATION_SUCCESS = "User Created Successfully!";
  static const String USER_UPDATE = "User Update";
  static const String USER_UPDATE_SUCCESS = "User updated succesfully!";
  static const String ENTER_USER_NAME = "Please Enter User Name";
  static const String ENTER_MOBILE_NUMBER = "Please Enter Mobile Number";
  static const String ENTER_VALID_MOBILE_NUMBER =
      "Please Enter Valid Mobile Number";
  static const String ENTER_PASSWORD = "Please Enter Password";
  static const String SELECT_BUSINESS_UNIT = "Please Select Business Unit";
  static const String PLEASE_SELECT_ROLE = "Please Select Role";
  static const String SELECT_USER = "Select User";
  static const String PRODUCT_OFFERS = "Product Offers";
  static const String PRODUCT_SUPPLIER = "Product Supplier";
  static const String PENDING_ORDERS = "Pending Orders";
  static const String ORDER_HISTORY = "Order History";
  static const String CLEAR_FILTERS = "Clear Filters";
  static const String PRODUCT_HISTORY = "Product History";
  static const String SEARCH = "Search";
  static const String DATE = "Date";
  static const String TO = "To";
  static const String SUPPLIER_DATA = "Supplier Data..";
  static const String SEARCH_WITH_DOT = "Search.....";
  static const String FROM_TO = "To/From";
  static const String CATEGORY = "Category";
  static const String SEARCH_BY_NAME = "Search By Name";
  static const String SEARCH_BY_REQUESTER_NAME = "Search By Requester Name";
  static const String PLEASE_SELECT_CONNECTION = "Please select connection";
  static const String BATCHES_IN_LOCATIONS = "Batches in Location";
  static const String BATCH_DETAILS_AT_DIFF_LOCATIONS =
      "Batch Details at Different Locations :";
  static const String YOU_HAVE_NO_INVENTIORY_LOCATIONS =
      "You have no inventory locations.";
  static const String INTERNAL_BUSINESS_UNIT = "Internal busines unit";
  static const String SELECT_BU = "Select Business Unit";
  static const String TOTAL_AVALABILE_QUANTITY_FOR_BATCH =
      "Total Available Quantity for batch at selected location";
  static const String SEARCH_BY_USER = "Search by user name";
  static const String UPDATE_LOCATION = "Update Location";
  static const String QUANTITY_SHOULD_NOT_MORETHAN_AVAIL_ =
      "Quantity should not be more than available quantity";
  static const String ADD_LOCATION = "Add Location";
  static const String CREATING = "Creating...";
  static const String UPDATING = "Updating…";
  static const String GETTING_DATA = "Getting data";
  static const String ROLES_LIST = "Roles List";
  static const String EDIT_ROLE = "Edit Role";
  static const String ADD_ROLE = "Add Role";
  static const String MANAGE_ROLE = "Manage Role";
  static const String ROLE_PERMISSION = "Role Permissions";
  static const String UPDATE_ROLE = "Update Role";
  static const String CREATE_ROLE = "Create Role";
  static const String ROLE_NAME = "Role Name";
  static const String SELECT_ALL = "Select All";
  static const String PLEASE_ENTER_REASON = "Please enter a reason";
  static const String PRODUCT_CREATED = "Product created successfully";
  static const String PRODUCT_UPDATED = "Product updated successfully";
  static const String PLEASE_ENTER_PRODUCT_NAME = "Please Enter Product Name";
  static const String PLEASE_ENTER_HSN_CODE = "Please Enter HSN Code";
  static const String PLEASE_ENTER_HEIGHT = "Please Enter Height";
  static const String PLEASE_ENTER_WIDTH = "Please Enter Width";
  static const String PLEASE_ENTER_DEPTH = "Please Enter Depth";
  static const String PLEASE_ENTER_VOLUM = "Please Enter Volum";
  static const String PERCENT_SYMBOL = "%";
  static const String PLEASE_ENTER_QUANTITY = "Please Enter Quantity";
  static const String PLEASE_SELECT_TAX_TYPE = "Please Select Tax Type";
  static const String PLEASE_SELECT_TAX_VALUE = "Please Select Tax Value";
  static const String PLEASE_ENTER_TAX_HSN_CODE = "Please Enter Tax HSN Code";
  static const String PLEASE_ENTER_VALID_PRICE = "Please Enter Valid Price";
  static const String PLEASE_ENTER_PACKAGE_NAME = "Please Enter Package Name";
  static const String PLEASE_ENTER_WEIGHT = "Please Enter Weight";
  static const String PLEASE_SELECT_HEIGHT = "Please Select Height";
  static const String PLEASE_SELECT_WIDTH = "Please Select Width";
  static const String PLEASE_SELECT_DEPTH = "Please Select Depth";
  static const String PLEASE_SELECT_VOLUM = "Please Select Volum";
  static const String PLEASE_SELECT_QUANTITY = "Please Select quantity";
  static const String PLEASE_SELECT_WEIGHT = "Please Select Weight";
  static const String PLEASE_ENTER_PRICE = "Please Enter Price";
  static const String PLEASE_ENTER_MRP = "Please Enter MRP";
  static const String PLEASE_ENTER_NET_RATE = "Please Enter Net Rate";
  static const String PLEASE_ENTER_BATCH_NO = "Please Enter Batch No";
  static const String UPDATE_PRICE = "Update Price";
  static const String PLEASE_ENTER_PACK_SIZE = "Please Enter Pack Size";
  static const String PLEASE_SELECT_PACK_UNIT = "Please Select Pack Unit";

  /// Login page constannts
  static const String APANAVYAPAR = "VYAPAR LIVE"; //"APANA VYAPAR";
  static const String ACCEPT_INVITATION = "Accept invitation";
  static const String HAVE_ACCOUNT = "Already have an account?";
  static const String CLICK_HERE = "Click here";
  static const String INVITATION_ERROR = "Invitation Error";
  static const String NETWORK_ERROR = "Network Error";
  static const String CHECK_INTERNET = "Please check your internet";
  static const String SUBMIT_STRING = 'Submit';
  static const String LOGIN = 'Login';
  static const String HAVE_INVITATION = "Have an invitation code?";
  static const String LOGIN_ERROR = "Login Error";
  static const String SUCCESS = "Success";
  static const String SENT_EMAIL_SUCCESS =
      "Your message sent successfully. Our team will reach out to you.";
  static const String SERVER_ERROR_MESSAGE =
      "Server not reachable. Please try after some time.";

  /// Registration page constants
  static const String WELCOME_TO = 'Welcome to';
  // static const String SET_PASSWORD =
  //     "Please set username and password to create your account";
  static const String TERMS_AND_CONDITIONS = 'Terms & Conditions';

  ///In-Person orders page constants
  static const String BUY_ORDERS = "Buy Orders";
  static const String SELL_ORDERS = "Sell Orders";
  static const String DISTRIBUTORS = "Distributors";
  static const String DONE = "Done";
  static const String CHOOSE_DISTRIBUTOR = "Choose Distributor";
  static const String CHOOSE_CONNECTION = "Choose Connection";
  static const String SELLER = "Seller";
  static const String BUYER = "Buyer";
  static const String SELECT_DISTRIBUTOR = "Select Distributors";
  static const String CREATE_TRANSACTION = "Create Transaction";
  static const String NOT_BE_SAME = "Seller and Buyer should not be same";
  static const String FILL_ORDER_FORM = "Fill Order Form";

  ///reports constats

  static const String TOTAL_SALES = "Total Sales";
  static const String TEAM_REPORTS = "Team Reports";
  static const String FROM_DATE_STRING = 'From Date';
  static const String TODATE_STRING = 'To Date';
  static const String SEARCH_BY_DISTRIBUTOR = "Search by distributor name...";
  static const String SEARCH_BY_PRODUCT = "Search By Product Name";
  static const String TOTAL_PRODUCTS_SALES = "Total Product Sales";
  static const String INVOICE_AMOUNT = "Invoice Amount";
  static const String SOLD_TO = "Sold To";
  static const String BUY_FROM = "Buy From";
  static const String FILTER_BY_INVOICE_TYPE = "Filter by Invoice Type";
  static const String CANCELLED = "cancelled";
  static const String PAID = "Paid";
  static const String NOT_PAID = "Not Paid";
  static const String DELIVERY_STATUS = "Delivery Status";
  static const String PACKING_STATUS = "Packing Status";
  static const String LOADING = "Loading..";
  static const String TOTAL = "Total";
  static const String CGST = "CGST";
  static const String SGST = "SGST";
  static const String IGST = "IGST";
  static const String TOTAL_GST = "Total GST";
  static const String SALES_IN_UNIT = "Sales in Unit";
  static const String SEARCH_BY_BUSINESS = "Search By Business Unit";
  static const String PAID_AMOUNT = "Paid Amount";
  static const String TOTAL_PENDING_AMOUNT = "Total Pending Amount";
  static const String TOTAL_PAID_AMOUNT = "Total Paid Amount";

  /// Invitations
  static const String SENT = "Sent";
  static const String RECEIVE = "Receive";
  static const String SEARCH_BY_INVITATION_NAME = "Search by invitation name";
  static const String SORT_INVITATIONS_BY = "Sort Invitations By";
  static const String PENDING_INVITATIONS = "Pending Invitations";
  static const String REJECT_INVITATIONS = "Rejected Invitations";
  static const String ACCEPTED_INVITATIONS = "Accepted Invitations";
  static const String MR_MRS = "Mr/Ms.";
  static const String TO_YOUR_MOBILE_NUMBER = "to your mobile number";
  static const String SEND_INVITATIONS_VYAPARLIVE_MOBILE_NUMBER =
      "has sent you an invitation for Vyapar live from mobile number";
  static const String INVITATION_DELETE_TEXT =
      "Do you want to delete this Invitation?";
  static const String INVITATION_STATUS = "Invitation Status:";
  static const String RELATION_DETAILS_STRING = 'RELATION DETAILS';
  static const String BUSINESS_RELATION = "Business Relation";
  static const String INVITER_DETAILS = "INVITER DETAILS";
  static const String INVITEE_DETAILS = "INVITEE DETAILS";
  static const String ORGANIZATION = "Organization";
  static const String EMAIL = "Email";
  static const String SELECT_UNIT_TEAM = "Select Unit/Team";
  static const String BUSINESS_UNIT_OR_TEAM_STRING = 'Unit/Team';
  static const String OUR_BU_DETAILS = "Our Business Details";
  static const String INVITEE_CONTACT_DETAILS_STRING =
      'INVITEE DETAILS FOR BUSINESS';
  static const String NEXT = "Next";
  static const String PLEASE_ENTER_EMAIL = "Please enter valid email";
  static const String PLEASE_ENTER_INVITEE_NAME = "Please enter invitee name";
  static const String PLEASE_ENTER_INVITEE_EMAIL = "Please enter invitee email";
  static const String PLEASE_ENTER_INVITEE_MOBILE =
      "Please enter invitee mobile number";
  static const String USER_ALREADY_EXIST =
      "User already exists with mobile number : ";
  static const String PLEASE_ENTER_VALID_MOBILE =
      "Please enter valid mobile number";
  static const String CLOSE = "Close";
  static const String INVITATION_SENT_SUCCESSFULLY_ALERT_STRING =
      'Invitation Created Successfully!';
  static const String SHARE = "Share";
  static const String APANAVYAPAR_INVITATION = "VYAPAR LIVE INVITATION";
  static const String COMMERCIAL_RELATIONSHIP_TITLE_STRING =
      'Commercial Relationship';
  static const String ADD_NEW_INVITE_STRING = 'Add New Invite';
  static const String PLEASE_FILL_INVITE_FORM_TITLE_STRING =
      'PLEASE FILL THE INVITE FORM';
  static const String RELATION_SHIP_TITLE_NAME_STRING =
      'COMMERCIAL RELATIONSHIP DETAILS';
  static const String INVOICE_NO = "Invoice Number";
  static const String ORDER_DETAILS = "Order Details";
  static const String PO = "PO";
  static const String SHIP_TO = "Ship To";
  static const String SOLD_BY = "Sold By";
  static const String PRINT_VIEW = "Print";
  static const String RETAIL_REPORTS = "Retail Reports";
  static const String CREATE_BU_INFO =
      "Please create BU to perform this operation";
  static const String TOTAL_EXPENSES = "Total Expenses";
  static const String DATE_AND_TIME = "Date & Time";
  static const String AMOUNT = "Amount";
  static const String ADD_EXPENSES = "Add Expenses";
  static const String CHOOSE_ONE = "Choose One";
  static const String EDIT_EXPENSES = "Edit Expense";
  static const String DELETE_EXPENSES = "Delete Expense";

  /// Retail customer constants
  static const String INVOICE_LIST = "Invoice List";
  static const String NEW_ORDER_C = "NEW ORDER";
  static const String NEW_ORDER = "New Order";
  static const String CUSTOMER_LIST_C = "CUSTOMER LIST";
  static const String CUSTOMER_LIST = "Customer List";
  static const String GENERATE_INVOICE = "Generate Invoice";
  static const String ENTER_RETAIL_NUMBER = "Please enter customer number";
  static const String RETAILER_SEARCH = "Search by number";
  static const String ENTER_RETAIL_NAME = "Please enter customer name";
  static const String SELECT_PRODUCTS = "Please Select Products";
  static const String SELECT_PRODUCT_FURTHER_ACTION =
      "Please select product for further action";
  static const String YOUR_GENERATE_INVOICE_IS = "Your generate invoice is";
  static const String INVOICE_GENERATED_SUCCESSFULLY =
      "Invoice Generated successfully";
  static const String CONTINUE = "Continue";
  static const String CUSTOMER_NAME = "Customer Name";
  static const String CUSTOMER_MOBILE = "Customer Mobile Number";
  static const String ADD_ADDITIONAL_DISCOUNT =
      "Do you want to add additional discount?";
  static const String DISCOUNT = "Discount";
  static const String DISCOUNT_TYPE = "Discount Type";
  static const String NO_RETAIL_FOUND = "No Customer Found With This Number";
  static const String ENTER_VALID_QUANTITY = "Please enter valid quantity";
  static const String TOTAL_PRICE = "Total Price";
  static const String SHARE_INVOICE = "You Can Share Your Invoice";
  static const String OPEN = "Open";
  static const String YR_INVOICE = "Vyapar Live INVOICE";
  static const String YOUR_GENERATED_INVOICE = "Your generated invoice is";
  static const String RETAIL_UPDATED = "Customer Updated Successfully";
  static const String RETAIL_CREATED = "Customer Created Successfully";
  static const String RETAIL_REMOVED = "Customer Removed";
  static const String INVOICE_DETAILS = "Invoice Details";
  static const String PRODUCT_COST = "Product Cost";
  static const String ADDITIONAL_DISCOUNT = "Additional Discount";
  static const String QUANTITY_IN = "Quantity In";
  static const String ADD_AMOUNT = "Add Amount";
  static const String ADD_AMOUNT_C = "ADD AMOUNT";
  static const String MAKE_PAYMENT = "Collect Payment";
  static const String RETAIL_ACCOUNT_HISTORY = "Account History";
  static const String RETAIL_ACCOUNT_HISTORY_C = "History";

  static const String STR_COLLECT = "Collect";

  static const String RETAIL_PAYMENT_HISTORY = "Payment History";

  /// Offline bu constants

  static const String RECORD_DELETED = "Record deleted";
  static const String UPDATED = "Updated";
  static const String CONTACT_CREATED = "Contact Created";
  static const String PLEASE_ENTERPERSON_NAME_STRING = 'Please Enter Name';
  static const String PLEASE_SELECT_COUNTRY = "Please Select Country";
  static const String PLEASE_SELECT_STATE = "Please Select State";
  static const String PLEASE_SELECT_DISTRICT = "Please Select District";
  static const String PLEASE_SELECT_CITY = "Please Select City";
  static const String CONFIRM = "Confirm";
  static const String CUSTOMER_BU_DETAILS = "Customer Business Details";

  static const String BUY_PRODUCTS = "Buy Products";
  static const String SELL_PRODUCTS = "Sell Products";
  static const String PLACE_ORDER_STR = 'Place Order';
  static const String TRANSACTION_CREATED = "Transaction created successfully";
  static const String SEARCH_BY_CATEGORY = "Search By Category";
  static const String FILTER = "Filter";
  static const String CLEAR_AND_CANCEL = "Clear & Cancel";
  static const String SEARCH_BY_CONNECTION = "Search by connection..";
  static const String EDIT_PRODUCTS = "Edit Products";
  static const String EDIT_ORDER = "Edit Order";
  static const String UPDATE_ORDER = "Update Order";
  static const String ADD_MORE_PRODUCTS = "Add More Products";
  static const String ORDER_UPDATED = "Order Update Successfully";
  static const String ORDER_STATUS_STRING = 'Order Status';
  static const String ENTER_REASON = "Enter A Reason";
  static const String PASS_MUST_BE = "Password must be minimum 4 digit";

  static const String EDIT_PRODUCT_PRICE = "Edit Price";

  static const String ACCEPT_TERMS = "Please accept terms & conditions";
  static const String USER_REG_MESSAGE =
      "Congratulations, you have registered successfully";
  static const String ENTER_CONTACT_NUMBER = "Please enter contact number";

  static const String ENTER_INVITATION_CODE = "Please enter invitation code";
  static const String VALIDATING_INVITATION_CODE = "Validating invitation code";
  static const String LOGGING_IN = "Logging in";
  static const String ROLE_CREATED = "Role Created Successfully";
  static const String ROLE_UPDATED = "Role Updated Successfully";
  static const String LOCATION_CREATED = "Location created successfully.";
  static const String LOCATION_UPDATED = "Location updated successfully.";
  static const String ENTER_QUANTITY = "Enter Quantity";
  static const String SELECT_TIME = "Select Time";
  static const String DOWN_LOADING = "Downloading...";
  static const String PRODUCT_SALES_HISTORY = "Product Sales History";
  static const String PRODUCT_BUY_HISTORY = "Product Buy History";
  static const String RETAIL_INVOICE_LIST = "Retail Invoice List";
  static const String RETAIL_SALES = "Retail Sales";
  static const String GST_NO = "GST No";
  static const String PAYMENT_STATUS = "Payment Status";
  static const String RECEIVABLE = "Receivable";
  static const String ORGANIZE_IMAGE = "organization_invoice_template.png";
  static const String PAYABLE = "Payable";
  static const String TOTAL_PURCHASE = "Total Purchase";
  static const String ASSETS_MANAGEMENT = "ASSET MANAGEMENT";
  static const String ADD_ASSETS = "Create Asset Group";
  static const String UPDATE_ASSETS = "Update Asset Group";
  static const String ASSETS_LIST = "Asset List";
  static const String LIABILITY_LIST = "Disposed Of List";
  static const String SCRAP_LIST = "Scrap  List";
  static const String ENTER_ASSERT_NAME = "Enter Asset Name";
  static const String ATTCH_FILE = "Attach File";
  static const String LIFE_DURATION = "Useful Life Duration";
  static const String IS_SCRAP = "Is Scrap";
  static const String SCRAP_DECLARED_DATE = "Scrap Declared Date";
  static const String DISPOSED = "Disposed";
  static const String DISPOSED_DATE = "Disposed Date";
  static const String DISPOSED_VALUE = "Disposed Amount Received";
  static const String USEFUL_LIFE_REMAINING = "Useful Life Remaining";
  static const String DEPRECIATION_EXPENSE = "Depreciation Expense";
  static const String DEPRECIATION = "Depreciation";
  static const String CREATE_ASSETS_GROUP = "Create Asset Group";
  static const String UPDATE_ASSETS_GROUP = "Update Asset Group";
  static const String NON_DISPOSED = "Non Disposed";
  static const String ASSET_NAME = "Asset Name";
  static const String GROUP = "Group";
  static const String ASSET_DETAILS = "Asset Details";
  static const String ASSET_BASIC_DETAILS = "Asset Basic Details";
  static const String CREATE_CONSUMABLE_PRODUCTS = "Create Consumable Product";
  static const String UPDATE_CONSUMABLE_PRODUCTS = "Update Consumable Product";
  static const String CONSUMABLE = "Consumable";
  static const String NON_CONSUMABLE = "Non Consumable";
  static const String CONSUMABLE_PRODUCTS = "Consumable Products";
  static const String RAW_MATERIAL = "Raw Material";
  static const String PRODUCT_CONSUMPTION = "Product Consumption";
  static const String ISSUED_DATE = "Issued Date";
  static const String ISSUED_TO = "Issued To";
  static const String PURPOSE = "Purpose";
  static const String APPROVED_BY = "Approved By";
  static const String ISSUED_QUANTITY = "Issued Quantity";
  static const String ISSUE_DETAILS = "Issued Details";
  static const String ADD_ISSUE_DETAILS = "Add Issue Details";
  static const String UPDATE_ISSUE_DETAILS = "Update Issue Details";
  static const String ENTER_GROUP_NAME = "Enter Group Name";
  static const String SELECT_GROUP = "Select Group";
  static const String CONSUMABLE_PRODUCT_LIST = "Consumable Product List";
  static const String RESIDUAL_VALUE = "Residual Value";
  static const String NET_COST = "Net Cost";
  static const String YEAR = "Year";
  static const String MONTH = "Month";
  static const String SCRAP_DETAILS = "Scrap Details";
  static const String LIABILITY_DETAILS = "Disposed Details";
  static const String PRODUCT_CONSUMABLE_REPORTS = "Consumable Product Reports";
  static const String RAW_MATERIAL_LIST = "Raw Material List";
  static const String CREATE_RAW_MATERIAL_PRODUCT = "Create Raw Product";
  static const String UPDATE_RAW_MATERIAL_PRODUCT = "Update Raw Product";
  static const String KEY_RAW_MATERIAL = "raw material";
  static const String KEY_ACTUAL_TARNSACTION = "Actual Transaction";
  static const String KEY_ACTUAL_PRODUCTS = "Actual Products";
  static const String TRANSACTION_TYPE = "Transaction Type";
  static const String RAW_MARETIAL_ISSUE = "Raw Material Issuance";
  static const String FINAL_PRODUCT = "Final Product";
  static const String RAW_ISSUE_DETAILS = "Issuance Details";
  static const String RAW_MATERIALS = "Raw Materials";
  static const String ISSUING_DETAILS = "Issuancing Details";
  static const String RAW_VS_FINISHED_PRODUCT =
      "Raw Material v/s Finished Product";
  static const String FINISHED_PRODUCT = "Finished Product";
  static const String FROM_RAW_MATERIAL = "From Raw Material";
  static const String ADDED_BY = "Added By";
  static const String ISSUANCE_NOTES = "Issuance Notes";
  static const String RAW_INVENTORY = "Raw Inventory";
  static const String ISUUED_NOTE_ID = "Issued Note Id";
  static const String ISUUED_DATE = "Issued Date";
  static const String INVENTORY_ADDED_DATE = "Inventory Added Date";
  static const String SELECT_RAW_MATERIAL_NOTE =
      "Map To Raw Material Issuance Note";
  static const String BUY_IN_UNIT = "Buy in Unit";

  static const String RAW_MATERIAL_IO_REPORT = "Raw Material I/O Report";

  static const String STR_OUR_ORGANIZATION = "OUR ORGANISATION";
  static const String STR_USER_ROLE_AUTHORISATIONS =
      "Create User Role with Authorisations";
  static const String STR_OUR_BU_LIST = "Our Business Unit List";
  static const String STR_OUR_PEOPLE = "WORKFORCE"; //"OUR PEOPLE";
  static const String STR_BU_CONNECTIONS = "BUSINESS CONNECTIONS";
  static const String STR_CONNECTIONS_RETAIL_CUSTOMERS =
      "Connections - RealTime";
  static const String STR_INVITATION_STATUS_LIST = "Invitations List";
  static const String STR_ADD_NEW_CONNECTION = "Add New Connection";
  static const String DELIVER = "Deliver";
  static const String STATUS_ = "Status :";
  static const String ORDER_ACCEPTE_SUCCESS = "Order accepted successfully!";
  static const String STR_OFFLINE_CUSTOMERS_LIST = "Offline Connections List";
  static const String STR_TRANSACTION_ORDER_STATUS = "TRANSACTIONS - ORDERS";
  static const String GETTING_LOACTION_DATA = "Getting Locations Data";
  static const String STR_FIELD_SALES_IN_PERSON_ORDERS =
      "FIELD SALES - IN-PERSON ORDERS";
  static const String NOTIFICATIONS_STR = 'NOTIFICATIONS';
  static const String REPORTS_STR = "REPORTS";
  static const String ONDC_STR = "ONDC";
  static const String STR_RETAIL_SALES_REPORTS = "Retail Sales Reports";
  static const String MANUFACTURING_CONSUMPTION_REPORTS =
      "Consumable Products Reports";
  static const String STR_PRODUCT_LIST_INVENTORY = "PRODUCTS AND INVENTORY";
  static const String STR_PRODUCT_INVENTORY = "Product Inventory";
  static const String STR_RETAIL_SALES = "RETAIL SALES";
  static const String STR_FINANCE = "FINANCE";
  static const String STR_GENERAL_EXPENSES = "General Expenses";
  static const String STR_GENERAL_EXPENSES_CAPS = "GENERAL EXPENSES";
  static const String STR_MANUFACTURAL_CONSUMABLE_DATA =
      "Manufacture - Consumables Data";
  static const String STR_INPUT_PRODUCTS = "Input Products";
  static const String STR_LANGUAGE = "LANGUAGE";
  static const String STR_LOGOUT = "Logout";
  static const String STR_HELP = "Help";
  static const String HOW_TO_REGISTER = "How To do Registration?";
  static const String HOW_TO_CREATE_BU = "How To Create New Business Unit?";
  static const String HOW_TO_CREATE_USER = "How To Create Users?";
  static const String HOW_TO_CREATE_PRODUCT = "How To Create Products?";
  static const String CUSTOME_REMARKS = "Customer Remarks For The Invoice";
  static const String INVOIVE_PAYMENT_TERMS = "Invoice payment terms";
  static const String ADDITIONAL_TERMS_CONDITIONS =
      "Additional Terms & Conditions";
  static const String UPDATE_TERMS = "Update Terms";
  static const String SUGGEST = "Suggest";
  static const String CONFIRMATION = "Confirmation";
  static const String GO_TO_CATALOGUE = "Go to Catalogue";
  static const String ROLE_ASSIGNED = 'ROLE ASSIGNED';
  static const String PRICE_PER_UNIT = 'Price Per Unit';
  static const String B2B_SALES_PRICE = "B2B Sale Price";
  static const String OFFER_VALUE = 'Offer Value';
  static const String SHARE_OFFLINE_PO = "You Can Share Your PO";
  static const String OFFLINE_CUSTOMER_ORDER = "B2B Customer Order";
  static const String ADD_RAW_MATERIAL = "Add Raw Material";
  static const String UPDATE_RAW_MATERIAL = "Update Raw Material";
  static const String ADD_INVOICE_TEMPLATE = "Add Invoice Template";
  static const String SELECT_INVOICE_TEMPLATE = "Select Invoice Template";
  static const String RAW_MATERIAL_LIST_INVENTORY =
      "Raw Materials List and Inventory";

  static const String CONSUMABLE_PRODUCT_DETAILS = "Consumable Product Details";
  static const String ADD_OFFLINE_CUSTOMER = "Add B2B Connection";
  static const String UPDATE_OFFLINE_CUSTOMER = "Update B2B Connection";
  static const String INDIA = "IN";
  static const String UK = "UK";
  static const String US = "US";
  static const String ORDER_FOR = "Order For";
  static const String SALABLE_PRODUCTS = "Salable Products";
  static const String PURCHASED_PRODUCTS = "Purchased Product";
  static const String MANUFACTURED_INHOUSE = "Manufactured Inhouse";
  static const String CALL = "Call";
  static const String CONTACT_US = "Contact Us";
  static const String ENTER_NAME = "Enter your name";
  static const String ENTER_SUBJECT = "Enter subject";
  static const String ENTER_EMAIL = "Enter email address";
  static const String ENTER_MESSAGE = "Enter message";
  static const String HOW_TO_UPDATE_BU = "How To Update Business Unit?";
  static const String HOW_TO_CREATE_CHILD_BU =
      "How To Create Child Business Unit?";

  static const String PRIVACY_POLICY = "Privacy Policy";
  static const String PAYMENT_HISTORY = "Payment History";
  static const String OR = "....... OR .......";
  static const String SPEAK_TO_SUPPORT = "Speak To Our Customer Support";
  static const String SEND_EMAIL = "Send Email";
  static const String SEARCH_BY_ORGANIZATION_NAME =
      "Search By Organization Name";
  static const String PLEASE_SELECT_INVOICE_TEMPLATE =
      "Please Select Invocie Template";
  static const String STOCK_DIS_STATES = "stock_dispatch_states";
  static const String STOCK_REC_STATES = "stock_receive_states";
  static const String PLEASE_ENTER_HOB = "Please Enter HOB";
  static const String PLEASE_SELECT_BUSINESS_TYPE =
      "Please select Business Type";
  static const String PLEASE_ENTER_BUSINESS_NAME = "Please Enter Business Name";
  static const String PLEASE_ENTER_OFFICE_NUMBER = "Please Enter Office Number";
  static const String INVOICE_TEMPLATE_UPDATED = "Invoice template updated";
  static const String TEST_BU = "Test BU";
  static const String UPDATE_PASSWORD = "Update Password";
  static const String ADD_LOGO = "Add Logo";
  static const String FORGOT_PASSWORD = "Forgot Password?";
  static const String CONFIRM_PASSWORD = "Confirm Password";
  static const String ENTER_NEW_PASSWORD = "Enter new password";
  static const String ENTER_CURRENT_PASSWORD = "Enter current password";
  static const String ENTER_CONFIRM_PASSWORD = "Enter confirm password";
  static const String ENTER_OTP = "Enter OTP";
  static const String ENTER_REGISTERED_MOBILE_NUMBER =
      "Enter registered mobile number";
  static const String PLEASE_ENTER_REGISTERED_MOBILE_NUMBER =
      "Please enter registered mobile number";
  static const String PLEASE_ENTER_NEW_PASSWORD = "Please enter new password";
  static const String PLEASE_ENTER_CURRENT_PASSWORD =
      "Please enter current password";
  static const String PLEASE_ENTER_CONFIRM_PASSWORD =
      "Please enter confirm password";
  static const String CONFIRM_PASSWORD_MIS_MATCHED =
      "Confirm password mismatched";
  static const String PLEASE_ENTER_OTP = "Please enter OTP";
  static const String INVENTORY_LOCATION = "Inventory Location";
  static const String PRICE_DETAILS = "QUANTITY & PRICE DETAILS";
  static const String QUANTITY_ADJUSTMENT = "Quantity Adjustment";
  static const List<String> adjustmentReasonList = [
    "Theft",
    "Damage",
    "Stock Adjustment",
    "Short Shipment"
  ];
  static const String UPDATED_BY = "Updated By";
  static const String UPDATED_DATE = "Updated Date";
  static const String SET_PASSWORD =
      "Please enter your name and the password for the selected mobile number.";
  static const String PRODUCT_PURCHASE_REPORTS = "Product Purchase Report";
  static const String PRODUCT_SALE_REPORTS = "Product Sale Report";
  static const String AVAILABLE_QUANTITY = "Available Quantity";
  static const String TOTAL_SOLD_QUANTITY = "Total Sold Quantity";
  static const String TOTAL_PURCHASED_QUANTITY = "Total Purchased Quantity";
  static const String TOTAL_NUMBER_OF_BATCHES = "Total Number of Batches";
  static const String PRODUCT_LOG_REPORTS = "Product Log Reports";
  static const String OFFER_AMOUNT = "Offer Amount";
  static const String TOTAL_OFFER_AMOUNT = "Product Total With Offer";
  static const String GST_TOTAL = "GST Total";
  static const String PRODUCT_AMOUNT_TOTAL = "Product Amount Total";
  static const String TOTAL_OFFER = "Total Offer";
  static const String SUB_TOTAL = "Sub Total";
  static const String IGST_TOTAL = "IGST Total";
  static const String SGST_TOTAL = "SGST Total";
  static const String CGST_TOTAL = "CGST Total";
  static const String AMOUNT_PAID = "Amount Paid";
  static const String INVOICE_BALANCE_DUE = "Invoice Balance Due";
  static const String REPLACED_PRODUCTS = "Replaced Products :";
  static const String QUANTITY_AT_LOCATION = "Quantity At Location";
  static const String FORBIDEN_TEXT = "Access forbidden";
  static const String UNKNOWN_ERROR = "Unknown Error";
  static const String GETTING_BATCH_PRICING_DATA =
      "Getting Batch Pricing Data..";
  static const String INVOICE_NOT_SELECTED = "Invoice not selected";
  static const String SELF = "Self";
  static const String ASSIGN_TASK = "Assign Task";
  static const String ASSIGN_USER = "Assign User";
  static const String DISPATCH_DATE = "Dispatch Date";
  static const String DISPATCH_TIME = "Dispatch Time";
  static const String PACKING_DETAILS = "Packing Details";
  static const String NO_OF_BOXES = "No.of Boxes";
  static const String PLEASE_SELECT_USER = "Please select user";
  static const String RESOLVED = "Resolved";
  static const String NOT_RESOLVED = "Not Resolved";
  static const String DELIVERED = "Delivered";
  static const String RETURNED = "Returned";
  static const String PIN_TO_RESOLVE =
      'Request Resolve'; //"Ping to Request Resolve";
  static const String UPDATE_INVOICE = "Update Invoice";
  static const String STOCK_RECONCILIATION = "Stock Reconciliation";
  static const String PAYMENT_RECONCILIATION = "Payment Reconciliation";
  static const String RESOLUTION = "Resolution";
  static const String RE_GENERATE_INVOICE = "Re Generate Invoice";
  static const String STOCk_RECEIVED_STATUS = "Stock Received Status";
  static const String RECEIVED_BY = "Received By";
  static const String DOC_TYPE = "Doc Type";
  static const String GRN_NUMBER = "GRN No";
  static const String ACTUAL_DELIVERY_DATE = "Actual Delivery Date";
  static const String DELIVERY_DUE_DATE = "Expected Delivery Date/Time";
  static const String GO_TO_RECONCILIATION_DISCUSSION =
      "Go to Reconciliation Discussion";
  static const String INVOICE_CANCELLED = "Invoice Cancelled";
  static const String PAYMENT_DUE_DATE = "Payment Due Date";
  static const String PART_PAYMENT = "Part Payment";
  static const String PART_PAYMENT_DATE = "Part Payment Date";
  static const String PENDING_AMOUNT = "Pending Amount";
  static const String PAYMENT_RECEIVED = "Payment Received";
  static const String PAYMENT_SENT = "Payment Sent";
  static const String BATCH_PRICING_DETAILS = "Batch and Quantity Details";
  static const String INVENTORY_LOCATION_C = "INVENTORY LOCATION";
  static const String QUANTITY_ADJUSTMENT_C = "QUANTITY ADJUSTMENT";
  static const String E_G_COLOR = "@E.g Colour";
  static const String E_G_RED = "@E.g Red";
  static const String TOTAL_QUANTITY_C = 'TOTAL QUANTITY';
  static const String CATEGORIES_C = 'CATEGORIES';
  static const String UPDATE_PASSWORD_C = 'Update Password';
  static const String CODE = 'Country Code';
  static const String SELECT_PRODUCT_SECTOR = 'Select Product Sector';
  static const String SELECT_PRODUCT_CATEGORY = 'Select Product Category';
  static const String SELECT_PRODUCT_SUB_CATEGORY =
      'Select Product Sub Category';
  static const String PRODUCT_SECTOR = 'Product Sector';
  static const String PICK_UP = 'Pick up';
  static const String DELIVERY_TO = 'Delivery To';
  static const String CURRENCY_SYMBOL = "Currency Symbol";
  static const String NO_CONNECTIONS_FOUND = "No connections found.";
  static const String SELECT_CONNECTION = "Select connection";
  static const String START_DISCUSSION_STRING = 'Start Discussion';
  static const String DIRECT_ORDER = 'Direct Order';
  static const String DIRECT_BUY_ORDER = 'Direct buy order';
  static const String PLEASE_SELECT_ANY_OPTION = "Please select anyone option";
  static const String GETTING_BUY_TRANSACTIONS = "Getting Buy Transactions..";
  static const String GETTING_SELL_TRANSACTIONS = "Getting Sell Transactions..";
  static const String MODIFIED_DATE = "Modified Date";
  static const String ORDER_DISCUSSION = "Order Discussions";
  static const String ENTER_PRODUCT_NAME = "Enter Product Name";
  static const String UNKNOWN_ERROR_CAPTIAL = "UNKNOWN ERROR";
  static const String DO_YOU_WANT_PRODUCT_WHICH_IS_NOT_PRODUCT_LIST =
      "Do you want to order new product, which is not in your product list.";
  static const String CONFIRMATION_MESSSAGES = "Confirmation Messages";
  static const String PURCHANSE_ORDER = "PO (Purchase Order)";
  static const String PACKING_INSPECTION = "Packing & Inspection";
  static const String DELIVERY_TRACKING = "Delivery Tracking";
  static const String COMPLETE = "Complete";
  static const String ADD_NEW_PRODUCT = "Add New Product";
  static const String SEARCH_AND_ADD_PRODUCT_ORDER =
      "Search And Add Product To Order";
  static const String CANCELLED_INVOICES = "Cancelled Invoices";
  static const String NO_OF_INVOICES = "Number Of Invoices";
  static const String PENDING = "Pending";
  static const String MORE = "More";
  static const String MORE_C = "MORE";
  static const String CODE_COMMENTED = "Code commented";
  static const String Packages = "Packages";
  static const String PLEASE_SELECT_PRODUCT_SECTOR =
      "Please Select Product Sector";
  static const String HINT_MESSAGE =
      "Stage not yet reached\nGo to stage marked active";
  static const String MESSAGES_CONFIRMED = "Messages Confirmed";
  static const String CONFIRMED_MESSAGES_TO_DO =
      "When buyer and seller both accept these discussions, only then is invoice generation allowed";
  static const String OPTIONS_FOR_CONFIRMATION_MESSAGES =
      "Options for Confirmation Messages";
  static const String HINT_UPDATE_CONFIRMATION_MESSAGES =
      "Do you want to update confirmation messsages, this will override previous confirmation messages";
  static const String VIEW_AND_UPDATE = "View and Update";
  static const String UPDATE_PURCHASE_ORDER = "Update purchase order";
  static const String PLEASE_SELECT_CONFIRMATION_MESSAGES =
      "Please select confirm messages";
  static const String LOST_SELECTED_MESSAGES =
      "You Will loss Your Selected Messages";
  static const String PRODUCTS_LIST = "Products List";
  static const String CONFIRM_DISCUSSIONS = "Confirm Discussions";
  static const String SELECT_PRODUCTS_AND_PLACE_ORDER =
      "Select Products & Place Order";
  static const String YOUR_SELECTED_MESSAGES = "Your Selected Messages";
  static const String SENDING_PRODUCTS = "Sending Products..";
  static const String SENDING_MESSAGES = "Sending Messages..";
  static const String MESSAGES_UPDATED_SUCCESSFULLY =
      "Messages updated successfully";
  static const String CONFIRM_AND_PLACE_ORDER = "Confirm & Place Order";
  static const String SHIP_TO_LOCATION = "Ship to location";
  static const String SELECT_SHIP_TO_LOCATION = "Select Ship To Location";
  static const String CONFIRMATION_MESSAGES_ACCEPTED =
      "Confirmation messages  accepted";
  static const String ENTER_A_REASON = "Enter a reason";
  static const String ORDER_REJECTING = "Order Rejecting..";
  static const String ORDER_ACCEPTING = "Order Accepting..";
  static const String MESSAGE = "Message";
  static const String OFFER_APPLIED = "Offer applied";
  static const String VIEW_CONFIRM_MESAGES = 'View confirmation messages';
  static const String PLEASE_GENERATE_INVOICE = "Please generate Invoices";
  static const String PENDING_PRODUCTS = "Pending Products";
  static const String ALL_INVOICED_NONE_PENDING = "All Invoiced, None Pending";
  static const String INVOICE_GENERATION = "Invoice Generation";
  static const String ADDRESS_DETAILS_S = "Address details";
  static const String CONFIRMATION_PENDING = "Confirmation Pending";
  static const String RECEIVE_PRODUCTS = "Receive Products";
  static const String GO_TO_PACKING = "Go To Packing";
  static const String FOR_FURTHER_ACTION =
      "Please select prodct for further action";
  static const String QUANTITY_WARNINIG =
      "Quantity should not be more than ordered quantity";
  static const String NO_ACTIVE_OFFER = "No active offer";
  static const String GETTING_BATCH_PRICING = "Getting Batch Pricing Data..";
  static const String GENERATING_INVOICE = "Generating Invoice..";
  static const String ENTER_AMOUNT = "Enter amount";
  static const String INVOICE_UPDATED_SUCCESSFULLY =
      "Invoice updated successfully";
  static const String PENALTY_REASON = "Penalty Reason";
  static const String PLEASE_ENTER_NO_BOXES = "Please enter no of boxes";
  static const String PLEASE_ENTER_WEIGHT_DETAILS =
      "Please enter weight details";
  static const String PACKING_COMPLETED_SUCCESSFULLY =
      "Packing Completed Successfully";
  static const String ASSIGNED_PACKING_TO = "You have assigned this invoice to";
  static const String PACKING_DETAILS_NOT_UPDATED =
      "Packing details not updated yet.";
  static const String DELIVERY_DETAILS = "Delivery Details";
  static const String DIRECT_DELIVERY = "Direct Delivery";
  static const String INDIRECT_DELIVERY = "Indirect Delivery";
  static const String SELECT_STATUS = "Select Status";
  static const String PLEASE_SELECT_INVOICE = "Please Select Invoice";
  static const String PLEASE_SELECT_TRACKING_STATUS =
      "Please select tracking status";
  static const String DELIVERY_TIME = "Expected Delivery Time";
  static const String DISPATCH_DELIVERY_DATE_TIME =
      'Dispatch Delivery Date Time';
  static const String PLEASE_SELECT_DISPATCH_DATE_TIME =
      "Please Select Dispatch Date Time";
  static const String SELECT_TYPE = "Select Type";
  static const String DELIVERY_DATE = "Expected Delivery Date";
  static const String DELIVERY_DETAILS_UPDATED_SUCCESSFULLY =
      "Delivery details updated successfully";
  static const String TRACKING_DETAILS = "Tracking Details";
  static const String SELECT_A_USER = "Select a user";
  static const String DOCUMENT_TYPE = "Document Type";
  static const String PLEASE_SELECT_DOCUMENT_TYPE =
      "Please select document type";
  static const String PLEASE_SELECT_DOCUMENT_NUMBER =
      "Please select document number";
  static const String DOCUMENT_NUMBER = "Document Number";
  static const String PLEASE_FILL_DETAILS_THIRD_PARTY =
      "Please fill details for delivery by thrid party and place order to third party.";
  static const String FROM_ADDRESS = "From Address";
  static const String TO_ADDRESS = "To Address";
  static const String PLEASE_SELECT_CONTACT_PERSON =
      "Please Select Contact Person";
  static const String PLEASE_ENTER_CONTACT_NUMBER =
      "Please enter contact number";
  static const String PLEASE_SELECT_INDIRECT_CONNECTION =
      "Please select indirect connection";
  static const String PLEASE_ENTER_CONTACT_PERSON_NUMBER =
      "Please Enter Contact Person Number";
  static const String PLEASE_ENTER_FROM_LOCATION = "Please enter from location";
  static const String PLEASE_ENTER_TO_LOCATION = "Please enter from location";
  static const String ORDER_NOT_PACKED_YET = "Your order not packed yet";
  static const String PICK_UP_LOCATION = "Pick up Location";
  static const String SELECT_PICK_UP_LOCATION = "Select pick up Location";
  static const String PLEASE_SELECT_PICK_UP_LOCATION =
      "Please Select pick up Location";
  static const String REF_INVOICE = "Ref.Invoice";
  static const String NO_LOCATIONS_ADDED = 'No locations added';
  static const String VIEW_MORE_BATCHES = "View more batches";
  static const String TOTAL_AT_LOCATION = "Total At Location";
  static const String PERCENTAGE = "Percentage";
  static const String INVENTORY_BATCHES = "Inventory Batches";
  static const String RAW_MATERIAL_ISSUE_NOTE_ID = "Raw Material Issue Note Id";
  static const String FROM_DELIVERY = "From Delivery";
  static const String ADJUSTED_QUANTITY = "Adjusted Quantity";
  static const String TO_DELIVERY = "To Delivery";
  static const String ENTER_PRICE = "Enter Price";
  static const String OFFER_EXPIRED = "Offer Expired";
  static const String ADD_DESCRIPTION = 'Add Description';
  static const String PACKING_LOCATION = "Packing Location";
  static const String INDIRECT_DELIVERY_DETAILS = "Indirect Delivery Details";
  static const String CUSTOMER_DETAILS = "Customer Details";
  static const String CUSTOMER_INVOICE = "Customer Invoice";
  static const String SERVICE = "Service";
  static const String PARTICULARS = "Particulars";
  static const String CHARGES = "Charges";
  static const String TRANSPORT = "Transport";
  static const String GRAND_TOTAL = "Grand Total";
  static const String EXPECTED_DELIVERY_DATE = "Expected Delivery Date";
  static const String EXPECTED_DELIVERY_TIME = "Expected Delivery Time";
  static const String DELIVERY_DETAILS_NOT_UPDATED_YET =
      "Delivery details not updated yet.";
  static const String PLEASE_SELECT_SHIP_TO_LOCATION =
      "Please Select Ship To Location";
  static const String STOCK_RECEIVED_BY_BUYER = "Stocks received by buyer";
  static const String PAYMENT_RECEIVED_DATE = "Payment received date";
  static const String DO_YOU_WANT_ADD_THIS_PAYMENT =
      "Do you want to add this payment ?";
  static const String THIS_INVOICE_CANCELLED = "This invoice is cancelled";
  static const String PLEASE_UPDATE_STATUS = "Please update status";
  static const String PLEASE_SELECT_ACTUAL_DELIVERY_TIME =
      "Please select actual delivery time";
  static const String PLEASE_SELECT_ACTUAL_DELIVERY_DATE =
      "Please select actual delivery date";
  static const String STOCK_DETAILS_NOT_UPDATED_YET =
      "Stock details not updated yet";
  static const String ATTACH_FILE_OR_PHOTO = "Attach file / photo";
  static const String PLEASE_SELECT_DATE = "Please select date";
  static const String PLEASE_ENTER_AMOUNT = "Please enter amount";
  static const String YOUR_ORDER_IS_BEING_PROCESS = "Your order being process.";
  static const String RECONCILIATION_DISCUSSION = "Reconciliation Discussion";
  static const String START_DISCUSSION_BY_CLICK =
      "Please start the discussion by clicking on Not Resolve button";
  static const String NEED_TO_INITIATE_DISCUSSION =
      "need to initiate the discussion";
  static const String INFO_MESSAGES = "Info Messages";
  static const String ARE_YOU_SURE_DO_YOU_WANT_REMOVE =
      "Are you sure do you want remove?";
  static const String INFO_MESSAGE = "Info Message";
  static const String DO_YOU_WANT_TO_SEND_THIS_MESSAGE =
      "Do you want to send this message";
  static const String STOCK_RESOLVE_COMPLETE =
      "Do you want to mark stock delivery as Resolved and Completed?";
  static const String PAYMENT_RESOLVE_COMPLETE =
      "Do you want to mark payment reconciliation as Resolved and Completed?";
  static const String SEND = "Send";
  static const String ADDRESS_PRINT_ON_INVOICE =
      "This address will be printed on invoices";
  static const String SELECT_DIN = "Select DIN";
  static const String DO_YOU_WANT_ADD = "Do you want to add";
  static const String AS_STOCK_RECEIVE_ADDRESS = "as Stock Receive address?";
  static const String MAIN_ADDRESS = "Main Address";
  static const String AS_STOCK_DISPATCH_ADDRESS = "as Stock Dispatch address?";
  static const String STOCK_RECEIVE_ADDRESS = "Stock Receive address";
  static const String STOCK_DISPATCH_ADDRESS = "Stock Dispatch address";
  static const String AS = "as";
  static const String SHOW_BANK_DETAILS_IN_INVOICE =
      "Show bank details in invoice";
  static const String BUYER_MUST_ACCEPT_IN_PERSON_ORDER =
      "When we sell, Buyer must accept in-person orders ?"; //"Buyer must accept in-person orders ?";
  static const String ORG_CREATED_SUCCESSFULLY =
      "Your Organization Created Successfully";
  static const String GETTING_STATES = "Getting States";
  static const String GETTING_TERMS = "Getting terms";
  static const String GETTING_PENALTY_LIST = "Getting penalty list";
  static const String GETTING_BUSINESS_TYPES = "Getting Business Types";
  static const String PLEASE_SELECT_LOCATION = "Please Select Location";
  static const String PLEASE_SELECT_BATCH_NO = "Please Select Batch Number";
  static const String PLEASE_SELECT_UPDATED_DATE = "Please select updated date";
  static const String PLEASE_ADD_PRICE_DETAILS = "Please Add Price Details";
  static const String CONNECTION_ASSIGNED_SUCCESSFULLY =
      "Connection assigned successfully to";
  static const String PLEASE_SELECT_COUNTRY_CODE = "Please Select Country Code";
  static const String PLEASE_SELECT_PAYMENT_TERMS =
      "Please Select Payment Terms";
  static const String PLEASE_SELECT_PENALTY_REASON =
      "Please Select Penality Reason";
  static const String PLEASE_SELECT_PENALTY_PERCENTAGE =
      "Please Select Penality Percentage";
  static const String COMMENT = "Comment";
  static const String SUCCESSFULLY_ADDED_TERMS_CONDITINS =
      "Successfully added terms & conditions for";
  static const String SELECTED_PRODUCTS_TO_CATELOGUE =
      "Add selected products to your catalogue";
  static const String START_DISCUSSION_WITH_THESE_PRODUCTS =
      "Do you want to start a discussion with these product?";
  static const String ANALYSIS_REPORTS = "Analysis Reports";
  static const String FAST_MOVING_PRODUCTS = "Fast Moving Products";
  static const String SLOW_MOVING_PRODUCTS = "Slow Moving Products";
  static const String DEAD_STOCK = "Dead Stock";
  static const String STOCK_DELIVERY_DELAYS = "Stock Delivery Delays";
  static const String STOCK_RECEIPT_DISCREPANCIES = "Stock Discrepancies List";
  static const String PAYMENT_RECEIPT_DISCREPANCIES =
      "Payment Discrepancies List";
  static const String DELAYED_PAYMENTS = "Delayed Payments";
  static const String TEAM_PERFORMANCE_REPORTS = "Team Performance Report";
  static const String OUR_SALES_TEAM = "Our Sales Terms";
  static const String START_ORDER_DISCUSSION = "Start Order Discussion";
  static const String TRANSACTION_HISTORY = "Transaction History";
  static const String BU_DETAILS = "Business Unit Details";
  static const String ASSIGN_TO_USER = "Assign To User";
  static const String TXN_INITIATED_DATE = "Txn Initiated Date";
  static const String TXN_ID = "Txn Id";
  static const String DEPARTMENT = "Department";
  static const String ADD_TO_DISTRIBUTOR = "Add As Distributor";
  static const String DISTRIBUTORS_LIST = "Distributors List";
  static const String SUBSCRIPTION_TYPE = "Subscription Type";
  static const String SUBSCRIPTION_START = "Subscription Start";
  static const String NO_OF_USERS = "No of Users";
  static const String NO_OF_ACTIVE_USERS = "No of Active Users";
  static const String SUBSCRIPTION_AMOUNT = "Subscription Amount";
  static const String NEXT_RENEWAL_DATE = "Next Renewal Date";
  static const String YOU_HAVE_NO_SUBSCRIPTION = "You have no subscription";
  static const String LAST_PAYMENT_DETAILS = "Last Payment Details";
  static const String REFRESH = "Refresh";
  static const String START_SUBSCRIPTION = "Start Subscription";
  static const String PAY_NOW_USING_UPI = "Pay Now Using UPI";
  static const String PLEASE_ENTER_YOUR_UPI = "Please enter your UPI handle";
  static const String PAYNOW = "Pay Now";
  static const String UPI_HANDLE = "UPI Handle";
  static const String TRANSACTION_INITIATED_SUCCESSFULLY =
      "Transaction initiated successfully";
  static const String CREATE_INVITATION = "Create Invitation";
  static const String REQUEST_FORMS = "Request Forms";
  static const String USER_MOBILE_NUMBER = "User Mobile Number :";
  static const String DOWNLOAD_VYAPAR_LIVE_APK = "Download Vyapar Live apk :";
  static const String ACCEPTED = "Accepted";
  static const String REJECTED = "Rejected";
  static const String REQUESTED_BY = "Request By";
  static const String REQUESTED_ID = "Request ID";
  static const String NEW_REQUEST_FORM = "New Request Form";
  //////////////////////////////////////////
  static const String DOWNLOAD = "Download";
  static const String CREATE_ASSETS_LIST = "Add Asset";
  static const String UPDATE_ASSETS_LIST = "Update Asset";
  static const String PURCHASED_DATE = "Purchase Date";
  static const String INVOICE_ATTACH = "Invoice Attached";
  static const String IS_LIABILITY = "Disposal";
  static const String REMOVE_FROM_DISTRIBUTOR = "Remove Distributor";
  static const String THIS_CONNECTION_IS_DISTRIBUTOR =
      "This Connection Is Distributor";
  static const String REMOVE_DISTRIBUTOR =
      "Do You Want To Remove This From Distributor?";
  static const String DISCREPANCY_TYPE = "Discrepancy Type";
  static const String STR_ATTRIBUTES = "Attributes";
  static const String ACTUAL_VALUE = "Actual Value";
  static const String UPDATED_VALUE = "Updated Value";
  static const String SALE_COUNT = "Sale Count";
  static const String STOCK_RECEIVED_DATE = "Stock Received Date";
  static const String STOCK_DELIVERY_DATE = "Stock Delivery Date";
  static const String COUNT = "Count";
  static const String NO_PENDING_ORDERS = "You Have No Pending Orders";
  static const String APPROVAL_DATE = "Approval Date";
  static const String ISSUANCE_ID = "Issuance ID";
  static const String OFFER_START_DATE = "Offer start date";
  static const String OFFER_END_DATE = "Issuance end date";
  static const String SELECT_ONE_OPTION = "Select One Option";
  static const String PLEASE_ENTER_VALID_OFFER_NAME =
      "Please Enter Valid Offer Name";
  static const String PLEASE_ENTER_OFFER_VALUE = "Please Enter Offer Value";
  static const String PLEASE_SELECT_MINIMUM_ORDER_VALUE =
      "Please Select Minimum Order Value";
  static const String PLEASE_SELECT_OFFER_START_DATE =
      "Please Select Offer Start Date";
  static const String PLEASE_SELECT_OFFER_END_DATE =
      "Please Select Offer End Date";
  static const String PLEASE_SELECT_OFFER_PERCENTAGE =
      "Please Select Offer Percentage";
  static const String FIELD_SALES = "Field Sales Reports";
  static const String REQUEST_FORM_TEMPLATE = "Request Form Template";
  static const String CONFIGURE = "Configure";
  static const String TEMPLATE_NAME = "Template Name";
  static const String FINISHED_PRODUCTS = "Finished Products";
  static const String CREATE_TEMPLATE = "Create Request Form Template";
  static const String EDIT_TEMPLATE = "Edit Request Form Template";
  static const String SELECT_TEMPLATE = "Select Template";
  static const String ADD_NEW_TAX = 'Add New Tax ID';
  static const String REGULATION_ID = "REGULATIONS IDs";
  static const String GOVT_BUSSINESS_SCHEME_ID = "Regulation ID";
  static const String RAW_MATERIAL_DETAILS = "Raw Material Details";
  static const String RAW_MATERIAL_DETAILS_C = "RAW MATERIAL DETAILS";
  static const String RAW_MATERIALS_C = "RAW MATERIALS";
  static const String REQUEST_FORM_DETAILS = "Request Form Details";
  static const String EDIT_REQUEST = "Edit Request Form";
  static const String SEARCH_BY_RAW_MATERIAL_NAME =
      "Search by raw material name..";
  static const String BULK_PRODUCTS_INFO =
      '*** For Bulk creation of Product List please fill the spreadsheet at link below and submit.';
  static const String ALL = "All";
  static const String SHOW_BU_PRODUCTS = "Business Unit Products";
  static const String SHOW_RAW_PRODUCTS = "Raw Materials";
  static const String ROLE_FIELD_OFFICER = "FIELD OFFICER";
  static const String REQUEST_ID = "Request ID";
  static const String VIEW_BU_DETAILS = "Business Unit Details";
  static const String INVITED_DATE = "Invited Date";
  static const String ACCEPTED_DATE = "Accepted Date";
  static const String CREATE_BUSINESS_UNIT = "Add Business Unit";
  static const String ADD_USER = "Add User";
  static const CREATE_FROM_ORG = "Copy Products From Another BU";
  static const COPY = "Copy";
  static const COPIED_TO_CLIPBOARD = "copied to clipboard";
  static const PLEASE_ENTER_LOCATION_NAME = "Please Enter Location Name";
  static const USER_CONNECTIONS = "User Connections";
  static const PLEASE_ENTER_ROLE_NAME = "Please Enter Role Name";
  static const THIS_USER_HAVE_NO_CONNECTIONS = "This user have no connections";
  static const String CREATE_FOR = "Add Product";
  static const String YOU_CAN_EDIT_ROLE_NAME =
      '***You can\'t\ edit role name***';
  static const String CREATE_FOR_PACKAGE = 'Add Package for';
  static const String CREATE_PACKAGE = "Create Package";
  static const String VIEW = 'View';
  static const String ORDER_FOR_ = "Order for :";
  static const String REVIEW_PRODUCTS = "Review Products";
  static const String YOU_ARE_NOW_VYAPAR_LIVE_USER =
      "You are now Vyapar Live user\n\n";
  static const String ASSIGNED_TO = "Delivery by";
  static const String BATCH_DETAILS = "Batch Details";
  static const String MOVE_TO_RAW_PRODUCT = "Move To Raw Materials List";
  static const String DISCOUNT_AMOUNT = 'Discount in amount';
  static const String DISCOUNT_IN_PERCENTAGE = 'Discount in percentage';
  static const String MOVE_TO_PRODUCT = "Move To Business Unit Products List";
  static const String MAIN_OFFICE = "MAIN OFFICE";
  static const String TOTAAL_AVAILABLITY_QUANTITY_BATCH =
      "Total Available Quantity for batch";
  static const String PRODUCT_ADDED_SUCCESSFULY_TO_RAW_MATERIAL =
      "Product added successfully in Raw Material List";
  static const String PRODUCT_ADDED_SUCCESSFULY_TO_BU_PRODUCT_LIST =
      "Product added successfully in Raw Material List";
  static const String ARE_YOU_SURE_ADD_PRODUCT_TO_RAW_MATERIAL =
      "Are You Sure Do You Want To Move This Product In Raw Material List?";
  static const String ARE_YOU_SURE_ADD_RAW_MATERIAL_TO_BU_PRODUCT =
      "Are you sure do you want to move this Raw Material Product in Business Unit Products List?";
  static const String PRODUCTS_IN_BUILK = "Add Products By Bulk Upload";
  static const String QUANTITY_ADJUSTMENT_INFO =
      'Are you sure, Do you want Adjust Entered Quantity At';
  static const String FIELD_OFFICERS_LIST = "Field Officers List";
  static const String PLEASE_CONTACT_ADMIN = "Please contact your ADMIN";
  static const String MENU = "Menu";
  static const String VIEW_CONNECTIONS = "View Connections";
  static const String INVENTORY_ALLOCATION = "Inventory Allocation";
  static const String PLEASE_ENTER_QUANTITY_AND_PRICE =
      "Please Enter Quantity & Price Details";
  static const String MUST_SELECT_ALL_INVENTORY_ALLOCATIONS =
      "You must select all Inventory Allocations";
  static const String LOCATION_DETAILS = "Location Details";
  static const String BACK = "Back";
  static const String QUANTITY_CONSUMED = "Quantity Consumed";
  static const String OPENING_BALANCE = "Opening Balance";
  static const String TOTAL_ISSUED = "Total Issued";
  static const String AVAILABLE_BALANCE = "Available Balance";
  static const String TOTAL_SOLD = "Total Sold";
  static const String RAW_ISSUANCE_REPORTS = "RawMaterial Issued Reports";
  static const String MANUFACTURE_IN_HOUSE_QUANTITY =
      "Manufacture in house quantity";
  static const String KEY_STOCK_RECEIVE = "STOCK_RECEIVE";
  static const String KEY_STOCK_DISPATCH = "STOCK_DISPATCH";
  static const String KEY_MAIN_OFFICE = "MAIN_OFFICE";
  static const String TOTAL_COMPLETED = "Total Completed";
  static const String CONTACT_PERSON_DISPATCH = "Contact Person at Dispatch";
  static const String CONTACT_NUMBER_DISPATCH = "Contact Phone at Dispatch";
  static const String CONTACT_PERSON_RECEIVER = "Contact Person at Receiver";
  static const String CONTACT_NUMBER_RECEIVER = "Contact Phone at Receiver";
  static const String MANUALLY_QUANTITY_CHANGED = "Quantity Updated Manually";

  static const String TYPE_NUMBER = "TYPE_NUMBER";
  static const String TYPE_STRING = "TYPE_STRING";
  static const String TYPE_OBJECT = "TYPE_OBJECT";
  static const String TYPE_ARRAY = "TYPE_ARRAY";

  static const String MANUAL_UPDATE_KEY = "manual_update";
  static const String QUANTITY_ADJUSTMENT_KEY = "quantity_adjustment";
  static const String REQUEST_DATE = "Request Date";
  static const String STOCK_PICKUP_DATE_TIME = "Pick-up date time";
  static const String STOCKS_DISPATCHED = "Stocks dispatched";
  static const String EXPECTED_DELIVERY_DATE_TIME =
      "Expected delivery date time";
  static const String SCHEDULED_PICKUP_DATE_TIME = "Scheduled pickup date time";
  static const String DELIVERED_DATE_TIME = "Delivered date time";
  static const String TRANSPOTER_EXPECTED_DELIVERY_DATE_TIME =
      "Transpoter expected delivery date time";
  static const String SELECT_DATE_AND_TIME = "Select date and time";
  static String BULK_RAW_PRODUCT_UPLOAD_URL = "${Constants.HTTP_URL_PREFIX}" +
      GRPC_URL_PREFIX! +
      "rawmaterialbulkupdate." +
      BASE_URL! +
      "/bulk/";
  static String DATE_RANGE_VALIDATION =
      "End Date should be greater than Start Date";
  static const String RETURN_PRODUCTS = "Return Of Products";
  static const String RE_CALL_PRODUCTS = "Recall Of Products";
  static const String DIRECT_SELL_ORDERS = "Direct sell order";
  static const String INVOICE_QUANTITY = "Invoice Quantity";
  static const String RETURN_QUANTITY = "Return Quantity";
  static const String PAN = "PAN";
  static const String CIN = "CIN";
  static const String GOODS_RETURNS = "Goods Returns";
  static const String RETURN = "Return";
  static const String RECALL = "Recall";
  static const String STOCK_RETURN = "Stock Return";
  static const List<String> goodsReturnOptions = [
    "Damage to Product Container",
    "Damage to Outer Packaging",
    "Wrong Product Delivered per Invoice List",
    "Wrong Product Price on Invoice",
    "Wrong Delivery /Invoice - Buyer refuses",
    "Product Near to Expiry Date",
    "Product Physically Disintegrated",
    "Product Spilled",
    "Product Other Quality Issue",
    "Return by Buyer due to Season Over",
    "Recall of Product(s) by Supplier"
  ];
  static const String CREATE_RETURN_DOC = "Create Return Goods Document";
  static const String AVAILABLE_BATCHES = "Available Batches";
  static const String NO_RETURN_DOCUMENT =
      "Create Return Goods Document By Click On \"+\"";
  static const String RETURN_GOODS_DOCUMENT = "Return Goods Document";
  static const String GOODS_RETURN_RECONCILIATION =
      "Goods Return Reconciliation";
  static const String CREDIT_NOTES = "Credit Notes";
  static const String GST_STRING = "GST";
  static const String RETURN_COUNT_OF_RECEIVED = "Return Count of Received";
  static const String RETURN_COUNT_OF_ACCEPTED = "Return Count of Accepted";
  static const String BUYER_RETURNS = "Buyer Returns";
  static const String NET_QUANTITY = "Net Quantity";
  static const String GOODS_RETURN_DISCUSSION = "Goods Return Discussion";
  static const int bottomSheet_duration = 800;
  static const int bottomSheet_reverse_duration = 400;

  static const String STR_SSF = "SSF";
  static const String STR_PRODUCTS = "PRODUCTS";
  static const String STR_ORDERS = "ORDERS";
  static const String STR_RETAIL = "RETAIL";
  static const String STR_OFFLINE_PUR_ORDERS = "B2B PURCHASE ORDERS";
  static const String STR_ON_SITE_ORERS = "ON-SITE ORDER";
  static const String STR_CUSTOMERS_LIST = "CUSTOMERS LIST";
  static const String STR_MY_COMPANY = "MY COMPANY";
  static const String STR_SHARE_ORDER_FORM = "SHARE ORDER FORM";
  static const String NEW_RETAIL_ORDER = "New Retail Order";
  static const String RETAIL_CUSTOMER_LIST = "Retail Customer List";
  static const String CREATE_NEW_RETAIL_CUS = "Create New Retail Customer";
  static const String STR_RETAIL_NAME = "Please Enter Retail Name";
  static const String STR_RETAIL_NUMBER = "Please Enter Retail Number";
  static const String STR_RETAILER_NUMBER = "Retailer Number";
  static const String STR_RETAILER_NAME = "Retailer Name";
  static const String STR_EXTERNAL = "External";
  static const String STR_INTERNAL = "Internal";
  static const String STR_TYPING = "Typing...";
  static const String STR_COPY_TO_SHARE = "Copy to Share";
  static const String STR_THIS_CONFIRM_MSGS_APPLY_ORDER_SELCT_PRODUCTS =
      "These confirmation messages apply to the order. Continue to select products and place the order.";
  static const String STR_THEY_ARE_STORED_AS_PART_OF_ORDER_CONFIMATION =
      "They are stored as part of Order Confirmation";
  static const String STR_CONFIRMATION_MSG_ARE_EXACT_DISCUSSION_MSGS =
      "Confirmation Messages are the exact discussion messages, that you select, as relevant to your order.";
  static const String STR_SELECT_THOSE_MSGS_THAT_APPLY_ORDER =
      "Select those messages that apply to your order. Then press";
  static const String STR_DISCUSSION_FOR = "Discussion For";
  static const String PAYMENT_TERMS_STR = "Payment Terms";
  static const String SELECT_PRODUCTS_STR = "Select Products";
  static const String SELLERS_PRODCUTS = "Seller's Products";
  static const String SELECT_PRODUCTS_BY_CATEGORY =
      "Select Products by Category";
  static const String UPDATE_CONNECTION_SPECIFIC_TERMS_STR =
      "Update Connection-Specific Terms";
  static const String STR_ARE_YOU_SURE_DEL_CUSTO_RECORD =
      "Are you sure, you want to delete this customer record?";
  static const String STR_INVOICE_WITH_CUST_NAME =
      "Search invoice by customer name";
  static const String STR_ERROR_IMAGE_RELATIVE_PATH_OFFLINE_INVOICE =
      'Please Upload Seller Invoice';

  static const String SELLER_ORIGINAL_INVOICE = 'Seller Original Invoice';
  static const String REPLICA_INVOICE = 'Our Replica Invoice';
  static const String NO_PREVIOUS_ORDERS = "No Previous Orders";
  static const String REVIEW_PRODUCTS_ORDER = "Review products order";
  static const ORDER_TO = 'Order To';
  static const UPLOAD_SELLER_INVOICE = 'Upload Seller Invoice';
  static const STR_CREATE_PURCHASE_ORDER = 'CREATE PURCHASE ORDER';
  static const ONLINE_CONNECTIONS = 'Online connections';
  static const STR_ONLINE_CONNECTIONS = 'ONLINE CONNECTIONS';
  static const STR_OFFLINE_CONNECTIONS = 'B2B CONNECTIONS';
  static const CREATE_PURCHASE_ORDER = 'Create Purchase Order';
  static const STR_REGISTRATION = 'Registration';
  static const STR_GO_TO_REGISTRATION = 'Go To Registration';
  static const TIMEOUT_EXCEPTION =
      "Request timed out. Please verify your network connection.";
  static const String ONDC_PROFILE = "ONDC Profile";
  static const String BUYER_APP = "Buyer app";
  static const String ORDER_ITEMS = 'Order items';
  static const String LOGISTIC_PROVIDER = "Logistic provider";
  static const String KEY_LOGISTIC_PROVIDER = "logistic_provider";
  static const String SELF_DELIVERY = "Self delivery";
  static const String KEY_SELF_DELIVERY = "self_delivery";
  static const String KEY_NEW_RETAIL_USER = "Create new retail customer";

  static const String CANCEL_REASON = "Reason For Cancellation";
  static const String SEARCH_BY_TRANSACTION_STATUS =
      "Search by transaction status";
  static const String PLEASE_SELECT_BUSSINESS_UNIT =
      "Please select business unit";
  static const String SELECT_OFFLINE_CONNECTION = "Select B2B connection";
  static const String SEARCH_LOCATION_FROM_DIRECTORY =
      "Search your location from directory";
  static const String SEARCH_PLACES = "Search places";
  static const String HOUSE_BUILDING = "House / Building";
  static const String PLEASE_SELECT_PRODUCT_CATEGORY =
      "Please select product category";
  static const String DISCOUNT_IN = "Discount in";
  static const String RETAILER_DETAILS = "Retailer details";
  static const String SOLD_IN_30_DAYS = "Sold in 30 days";
  static const String PURCHASE_QUANTITY = "Purchase quantity";
  static const String USER_HAS_NO_OFFLINE_CONNECTIONS =
      "This user has no B2B connections";
  static const String USER_HAS_NO_ONLINE_CONNECTIONS =
      "This user has no online connections";
  static const String BUSSINESS_UNIT_HAS_NO_LOCATIONS =
      "This Business Unit has no locations";
  static const String PLEASE_WAIT = "Please wait..";
  static const String IMAGE_UPLOAD_SUCCESSFULLY = "Image uploaded successfully";
  static const String GROUP_CREATED_SUCCESSFULLY = "Group created successfully";
  static const String LOGOUT_CONFIRMATION = "Are you sure, you want to logout?";
  static const String ARE_YOU_SURE_DO_YOU_WANT_TO =
      "Are you sure? do you want to add";
  static const String AS_DISTRIBUTOR = "as distributor";
  static const String IS_ASSIGNED_TO = "is assined to";
  static const String FAILED_TO_ASSIGN_USER = "Failed to assign usser";
  static const String CONNECTION_HAS_NO_FIELD_OFFICERS =
      "This connection has no field officers";
  static const String THIS_PRODUCT = "This product";
  static const String HAS_ZERO_QUANTITY_PLEASE_UPDATE =
      "has zero quantity, please update quantity";
  static const String GENERATE_INVOICE_PRICE_CHANGE =
      "The price may change as stock being taken from more than one batch";
  static const String CONNECTION_UPDATED = "Connection updated successfully";
  static const String QUANTITY_NOT_AVAILABLE = "Entered quantity not available";
  static const String PAYMENT_FAILED = "Payment failed";
  static const String PLEASE_SELECT_PROVIDER = "Please select provider";
  static const String PLEASE_SELECT_PRODUCT_SUB_CATEGORY =
      "Please select product sub category";
  static const String PINCODE_MANDATORY = "Pincode mandatory";
  static const String FAILED_TO_UPDATE_LOCATION =
      "Failed to update location, please try again";
  static const String FAILED_TO_CREATE_LOCATION =
      "Failed to create location, please try again";
  static const String INCORRECT_OTP = "Incorrect OTP";
  static const String PASSOWRD_UPDATED_LOGIN_AGAIN =
      "Password Updated, Please Login again";
  static const String PLEASE_SELECT_RAW_MATERIALS =
      "Please select raw materials";
  static const String PLEASE_SELECT_DEPARTMENT = "Please select department";
  static const String PLEASE_SELECT_PRODUCT_FURTHER_ACTION =
      "Please select prodUct for further action";
  static const String REJECT_INFO = "Are you sure, you want to reject?";
  static const String REQUEST_FORM_REJECTED =
      "Request form rejected successfully";
  static const String ISSUANCE_CREATED = "Issuance note created successfully";
  static const String RAW_MATERIAL_ISSUED_SUCCESSFULLY =
      "Raw material issued Successfully";
  static const String REMINDER_SENT_TO_EMAIL =
      "Reminder sent successfully to registered email";
  static const String FILE_DOWNLOADED_SUCCESSFULLY =
      "File download successfully";
  static const String DOWNLOAD_UN_SUCCESS = "Download unsuccessfull";
  static const String NO_INVENTORY = "You have no inventory";
  static const String MOBILE_NO_SHOULD_BE_10_DIGITS =
      "Mobile number should be 10 digits";
  static const String GENERATE_INVOICE_INFO =
      "Are you sure, do you want to generate invoice?";
  static const String DOCUMENT_CREATED_SUCCESSFULLY =
      "Documnet created successfully";
  static const String DRAFT_NOTE_CREATED_SUCCESSFULLY =
      "Draft note created successfully";
  static const String ACCEPTED_DRAFT_CREDIT_NOTE =
      "You have successfully accepted draft credit note";
  static const String STOCK_RECEIVED_BY = "Stock received by";
  static const String NOT_AUTHORIZED_FEATURE =
      "You are not authorized to access this feature";
  static const String INVOICE_PACKING_DETAILS_ALREADY_UPDATED =
      "Packing Details already entered for this invoice.If changes are required press Update";
  static const String INVOICE_ALREADY_ASSIGNED =
      "This invoice is already assigned to";
  static const String USERS_NOT_FOUND = "Users data not found";

  static const String SEND_OTP = "Send OTP";
  static const String SELECT_FROM_TEMPLATE = "Select from template";
  static const String CONTINUE_TO_SELECT_PRODUCTS =
      "Continue to select products";
  static const String CREATE_FINAL_NOTE = "Create final note";
  static const String CREATE_DRAFT_CREDIT_NOTE = "Create draft credit note";
  static const String OPEN_CAMERA = "Open Camera";
  static const String PLACE_ORDER_FOR_DELIVERY_SERVICE =
      "Place order for delivery service";
  static const String VIEW_DRAFT_CREDIT_NOTE = "View daft credit note";
  static const String STOCK_REVIEW_CREATE_DRAFT_CREDIT_NOTE =
      "Stock review & create draft credit note";
  static const String RENEWAL_SUBSCRIPTION = "Renewal subscription";
  static const String PURCHASE_OFFLINE_ORDERS = "Purchase B2B orders";
  static const String RAW_MATERIAL_REQUEST_FORM = "Raw material request form";
  static const String STOCK_RETURN_REPORT = "Stock returns report";
  static const String DOCUMENT_VIEW = "Document view";
  static const String GOODS_RETURN_DOCUMENT_LIST = "Goods return document list";
  static const String FINAL_CREDIT_NOTE_VIEW = "Final credit note view";
  static const String FORMULA = "Formula";
  static const String DEPRECIATION_METHOD = "Depreciation Method";
  static const String DELIVERY_PARTNER_DETAILS = "Delivery partener details";
  static const String AVAILABLE_PROVIDERS = "Available providers";
  static const String PURE_VEG = "Pure Veg";
  static const String NON_VEG = "Non-Veg";
  static const String YOU_HAVE_NO_RAW_TEMPLATES = "You have no raw templates";

  static const String GET_NEW_PROVIDER = "Get new provider";

  static const String DELETE_ACCOUNT = "Delete Account";

  static const String GET_OTP = "Get OTP";

  // Consumable Goods

  static const String CONSUMABLE_GOODS = "Consumable Goods";
  static const String CONSUMABLE_GOODS_REQUEST_FORM =
      "Consumable Goods Request Form";
  static const String CONSUMABLE_GOODS_ISSUANCE = "Consumable Goods Issuance";

  static const String CONSUMABLE_REQUEST_FORM = "Consumable goods request form";
  static const String CONSUMABLE_MATERIAL_LIST = "Consumable Goods List";
  static const String ADD_CONSUMABLE_MATERIAL = "Add Cosnumable Material";
  static const String CONSUMABLE_MATERIAL_DETAILS_C =
      "CONSUMABLE MATERIAL DETAILS";
  static const String UPDATE_CONSUMABLE_MATERIAL = "Update Consumable Material";
  static const String CONSUMABLE_GOODS_REPORTS = "Consumable Goods Reports";

  static const String PLEASE_ADD_LOCATION = "Please add location.";
  static const String PLEASE_ADD_BU_LOCATION =
      "Please add business location details.";

  static const String CANCEL_ORDER = "Cancel Order";

  static const String COMPLETED_C = "completed";
  static const String PENDING_C = "pending";
  static const String CANCELLED_STR = "Cancelled";

  static const String ALERT = "Alert";

  static const String STR_SKIP = "Skip";
  static const String STR_SKIPPED = "Skipped";

  static const String ARE_YOU_SURE_DO_YOU_WANT_CANCEL_INVOICE =
      "Are you sure do you want cancel order?";

  static const double CONTENT_PADDING_18_15 = (kIsWeb) ? 18 : 15;
  static const double CONTENT_PADDING_18_13 = (kIsWeb) ? 18 : 13;

  static const String ISSUE_GRIEVANCE = "Issue & Grievance";
  static const String STR_RESOLVE = "Resolve";
  static const String STR_SEND_RESOLUTION = "Send Resolution";
  static const String STR_REPLY = "Reply";

  static const String STR_OWNER = "Owner";

  static const String PRODUCT_DELETED_SUCCESSFULY =
      "Product deleted successfully.";

  static const String STR_SALES_PURCHASES = "SALES - PURCHASES";

  static const String NOT_APPLICABLE = "Not applicable.";

  static const String PROFIT_LOSS_REPORT = "Profit And Loss Report";
  static const String SALE_STR = "Sale(+)";
  static const String CR_SALE_RETURN_STR = "Cr. Note/Sale Return(-)";
  static const String PURCHASE_STR = "Purchase(-)";
  static const String DR_PURCHASE_RETURN_STR = "Dr. Note/Purchase Return(+)";
  static const String TAX_PAYABLE_STR = "Tax Payable(-)";
  static const String TAX_RECEIVABLE_STR = "Tax Receivable(+)";
  static const String OPENING_STOCK_STR = "Opening Stock(-)";
  static const String CLOSING_STOCK_STR = "Closing Stock(+)";
  static const String GROSS_PROFIT_STR = "Gross Profit";
  static const String OTHER_INCOME_STR = "Other Income(+)";
  static const String INDIRECT_EXPENSES_STR = "Indirect Expenses(-)";
  static const String NET_PROFIT_STR = "Net Profit";

  static const String STR_NEED_HELP_CAPS = "NEED HELP?";
  static const String STR_SUPPORT = "Support";
  static const String SHIP_TO_BUYER_LOCATION = "Ship to buyer location";

  static const String STR_QUOTATION = "QUOTATION";
  static const String QUOTATION = "Quotation";
  static const String QUOTATIONS_STR = "Quotations";
  static const String QUOTATIONS_RECEIVED_STR = "Quotations Received";
  static const String QUOTATIONS_SENT_STR = "Quotations Sent";
  static const String GENERATE_QUOTATION = "Generate Quotation";
  static const String STR_CHALLAN = "CHALLAN";
  static const String CHALLAN = "Challan";
  static const String CHALLANS_STR = "Challans";
  static const String CHALLANS_RECEIVED_STR = "Challans Received";
  static const String CHALLANS_SENT_STR = "Challans Sent";
  static const String GENERATE_CHALLAN = "Generate Challan";
  static const String QUOTATION_GENERATED_SUCCESSFULLY =
      "Quotation Generated successfully";
  static const String CHALLAN_GENERATED_SUCCESSFULLY =
      "Challan Generated successfully";

  static const String STR_TOTAL_PROFIT = "Total Profit";
  static const String ADD_UPID = "Add UPID";
  static const String UPI_DETAILS =
      "UPID / QR CODE (To add QR code in Invoice add UPI ID )";

  static const String GENERATE_INVOICE_FOR = "Generate Invoice for";

  static const String SELECT_PRODUCTS_AND_GENERATE_QUOTATION =
      "Select Products & Generate Quotation";
  static const String BUYER_NOT_YET_ACCEPTED_QUOTATION =
      "Buyer not yet accepted the quotation";
  static const String BUYER_MUST_ACCEPT_QUOTATION =
      "Buyer must accept Quotation";
  static const String STR_SKIP_THIS_STEP = "Skip This Step";

  static const String
      STR_THIS_CONFIRM_MSGS_APPLY_ORDER_SELECT_PRODUCTS_OFFLINE =
      "These finalized messages apply to the order. Continue to select products and generate quotation.";

  static const String ORDER_ID_STR = "Order ID";
  static const String ORDER_DATE_STR = "Order Date";
  static const String EDIT_QUOTATION = "Edit Quotation";
  static const String STR_ASK_HELP = "Help?";

  static const String STR_STOCK_VALUE = "Stock Value";

  static const String REMINDER_SENT_TO_WHATSAPP =
      "Reminder sent successfully to registered WhatsApp number";
}

class MaterialRadius {
  late double xs, small, medium, large;

  MaterialRadius(
      {this.xs = 4, this.small = 8, this.medium = 16, this.large = 24});
}

class ColorData {
  final Color star = Color(0xffFFC233);

  final ColorGroup pink = ColorGroup(Color(0xffFFC2D9), Color(0xffF5005E));
  final ColorGroup violet = ColorGroup(Color(0xffD0BADE), Color(0xff4E2E60));
  final ColorGroup blue = ColorGroup(Color(0xffADD8FF), Color(0xff004A8F));
  final ColorGroup green = ColorGroup(Color(0xffAFE9DA), Color(0xff165041));
  final ColorGroup orange = ColorGroup(Color(0xffFFCEC2), Color(0xffFF3B0A));

  final List<ColorGroup> list = [];

  ColorData() {
    list.addAll([pink, violet, blue, green, orange]);
  }
}

class ColorGroup {
  final Color color, onColor;

  ColorGroup(this.color, this.onColor);
}
