import 'package:flutter/services.dart';

class DecimalTextInputFormatter extends TextInputFormatter {
  final int decimalPlaces;

  DecimalTextInputFormatter({this.decimalPlaces = 1});

  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    final text = newValue.text;

    // Allow only digits and one decimal point
    if (text.isNotEmpty && !RegExp(r'^\d*\.?\d{0,' + decimalPlaces.toString() + r'}$').hasMatch(text)) {
      return oldValue; // Reject invalid input
    }

    return newValue; // Accept valid input
  }
}