import 'package:vyaparlive/components/BasicProductDetails.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/core/enums/privilleges_enum.dart';
import 'package:vyaparlive/service/bu_list_grpc_service.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Product/CategorySearchPage.dart';
import 'package:vyaparlive/Product/ProductsMenuPage.dart';
import 'package:vyaparlive/Transaction/buyer/DiscussionView.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/ModelProduct.dart';
import 'package:vyaparlive/model/product_model/ProductModel.dart';
import 'dart:convert';

import 'package:vyaparlive/service/product_services.dart';

class PlaceConnectionOrderPage extends StatefulWidget {
  final String? buName;
  final String? buId;
  final bool isFromProductList;
  final bool isInternalConnection;
  PlaceConnectionOrderPage(
      {this.buName,
      this.buId,
      this.isFromProductList = false,
      this.isInternalConnection = false});
  @override
  _PlaceConnectionOrderPageState createState() =>
      _PlaceConnectionOrderPageState();
}

class _PlaceConnectionOrderPageState extends State<PlaceConnectionOrderPage> {
  DateFormat formatter = DateFormat("yyyy-MM-dd");
  String? buName = "";
  String? buId = "";

  bool isLoading = false;
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  List<BuProductModal> _responseProducts = [];
  List<ModelProduct> _productsList = [];
  List<ModelProduct> _selectedProducts = [];
  List<ModelProduct> _discussionProducts = [];
  String? itemValue;
  bool isProductCheckBoxVisible = false;
  bool isSelectAllProducts = false;
  // bool isOfferActive = false;
  List<TextEditingController> _enterProductCount = [];
  TextEditingController _searchController = TextEditingController();
  bool isShowFilterButton = false;
  bool isLoadingProgress = true;
  String progressMessage = Constants.GETTING_DATA;
  static String showLoaderText = Constants.NO_DATA_FOUND;
  late ProductService _productService;
  String? orgCurrencySymbol = "";
  String? selectedLang = AppController.instance.getSelectedlanguage; // 'en';
  late SharedPreferences sharedPreferences;
  String? rawMaterialTransactionRadioValue;
  String? actualTransactionRadioValue;
  late ThemeData theme;
  late BuListGrpcService _transactionService;
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    buName = widget.buName;
    buId = widget.buId;
    _productService = ProductService();
    _transactionService = BuListGrpcService();
    loadProductData();
    // orgCurrencySymbol = AppController.instance.getBuCurrencySymbol;
    String? symbol = AppController.instance.getBuCurrencySymbol;
    orgCurrencySymbol = (symbol != null && symbol.isNotEmpty && symbol!="-") ? symbol : "\u20B9";
  }

  loadProductData(
      {String name = "",
      String? productSector = "",
      String? productSegment = "",
      String? productCategory = "",
      String? productSubCategory = ""}) async {
    if (await NetworkStatus.getInternetStatus()) {
      getProductsByBuId(
              name: name,
              productSector: productSector,
              productSegment: productSegment,
              productCategory: productCategory,
              productSubCategory: productSubCategory)
          .then((value) {
        _responseProducts.clear();
        _productsList.clear();
        _responseProducts.addAll(value);
        if (_responseProducts.length > 0) {
          if (widget.isFromProductList) {
            for (int i = 0; i < _responseProducts.length; i++) {
              bool isPriceAvailable = false;
              int index = -1;

              for (int j = 0;
                  j < _responseProducts[i].batchPrice!.length;
                  j++) {
                if (_responseProducts[i].batchPrice![j].quantity != 0 &&
                    _responseProducts[i].batchPrice![j].price != 0) {
                  isPriceAvailable = true;
                  index = j;
                  break;
                }
              }

              if (isPriceAvailable) {
                setState(() {
                  _productsList.add(ModelProduct(
                    offerList: _responseProducts[i].offers,
                    id: _responseProducts[i].id,
                    name: _responseProducts[i].name,
                    counter: 0,
                    isButton: false,
                    images: _responseProducts[i].images,
                    price: _responseProducts[i].batchPrice![index].price,
                    quantity: _responseProducts[i].batchPrice![index].quantity,
                    quantityIn:
                        _responseProducts[i].batchPrice![index].quantityIn,
                    batchPriceList: _responseProducts[i].batchPrice,
                    isItemSelected: false,
                  ));
                });
              }
            }
          } else {
            for (int i = 0; i < _responseProducts.length; i++) {
              // if (_responseProducts[i].batchPrice.length > 0) {

              bool isPriceAvailable = false;
              int index = -1;

              for (int j = 0;
                  j < _responseProducts[i].batchPrice!.length;
                  j++) {
                if (_responseProducts[i].batchPrice![j].price != 0) {
                  isPriceAvailable = true;
                  index = j;
                  break;
                }
              }
              if (isPriceAvailable) {
                setState(() {
                  _productsList.add(ModelProduct(
                    offerList: _responseProducts[i].offers,
                    id: _responseProducts[i].id,
                    name: _responseProducts[i].name,
                    counter: 0,
                    isButton: false,
                    images: _responseProducts[i].images,
                    price: _responseProducts[i].batchPrice![index].price,
                    quantity: _responseProducts[i].batchPrice![index].quantity,
                    quantityIn:
                        _responseProducts[i].batchPrice![index].quantityIn,
                    batchPriceList: _responseProducts[i].batchPrice,
                    isItemSelected: false,
                  ));
                });
              }

              // }
            }
          }
        } else {
          showLoaderText = Constants.NO_DATA_FOUND;
        }
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<BuProductModal>> getProductsByBuId(
      {String name = "",
      String? productSector = "",
      String? productSegment = "",
      String? productCategory = "",
      String? productSubCategory = ""}) async {
    Map filterObject = {
      "name": name,
      "product_sector": productSector,
      "product_segment": productSegment,
      "product_category": productCategory,
      "product_sub_category": productSubCategory
    };

    String body = "";
    if (!widget.isFromProductList) {
      filterObject['for_sale'] = true;
    }
    Map data = {"id": widget.buId, "filter": filterObject};
    body = json.encode(data);

    var response = await _productService
        .getProductByBuId_v2(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    isLoading = true;

    List<BuProductModal> _products = [];
    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      var data = resObj['results'];
      for (var i in data) {
        _products.add(BuProductModal.fromJson(i));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return _products;
  }

  List<PopupMenuEntry<String>> _buildMenuItems(BuildContext context) {
    return [
      if (CommonMethods.isPrivillegeExist(
          context,
          PrivillegesActions
              .KEY_ONLINE_CONNECTIONS_EXTERNAL_PRODUCTS_SELECT_PRODUCTS))
        PopupMenuItem(
          value: "1",
          child: Text(Language()
              .getString(Constants.SELECT_PRODUCTS_STR, selectedLang)),
        ),
      if (CommonMethods.isPrivillegeExist(
          context,
          PrivillegesActions
              .KEY_ONLINE_CONNECTIONS_EXTERNAL_PRODUCTS_SELECT_PRODUCTS_BY_CATEGORY))
        PopupMenuItem(
          value: "2",
          child: Text(Language()
              .getString(Constants.SELECT_PRODUCTS_BY_CATEGORY, selectedLang)),
        ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
        body: Stack(
      children: [
        SafeArea(
          child: Scaffold(
            key: _scaffoldkey,
            backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
            appBar: AppBar(
              backgroundColor: Colors.transparent,
              elevation: 0,
              iconTheme: IconThemeData(
                  color: theme.colorScheme.primary), //Color(Constants.APP_COLOR),
              title: AppbarName(
                  title:
                      Language().getString(Constants.PRODUCTS_STR, selectedLang),
                  buName: "$buName"),
              centerTitle: true,
              leading: IconButton(
                  icon: Icon(Icons.arrow_back),
                  onPressed: () {
                    if (isProductCheckBoxVisible) {
                      setState(() {
                        isProductCheckBoxVisible = false;
                        _selectedProducts.clear();
                        for (int i = 0; i < _productsList.length; i++) {
                          _productsList[i].isItemSelected = false;
                        }
                      });
                    } else {
                      Navigator.of(context).pop();
                    }
                  }),
              actions: [
                (isProductCheckBoxVisible)
                    ? this.showProductCheckBoxView()
                    : (_productsList.length > 0 && checkPrivilegeKey())
                        ? PopupMenuButton(
                            icon: Icon(Icons.more_vert),
                            onSelected: (dynamic value) async {
                              if (value == "1") {
                                CommonMethods.hideKeyboard(context);
                                setState(() {
                                  isProductCheckBoxVisible = true;
                                });
                              } else {
                                CommonMethods.hideKeyboard(context);
                                var parms = await Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => CategorySearchPage(
                                              buName: widget.buName,
                                            )));
          
                                if (parms != null) {
                                  isLoading = false;
                                  isShowFilterButton = true;
                                  isLoadingProgress = true;
                                  loadProductData(
                                      productSector: parms['product_sector'],
                                      productSegment: parms['product_segment'],
                                      productCategory: parms['product_category'],
                                      productSubCategory:
                                          parms['product_sub_category']);
                                }
                              }
                            },
                            itemBuilder: _buildMenuItems)
                        : Container(),
                AppUtills.homeButton(context),
              ],
            ),
            bottomNavigationBar:
                (widget.isFromProductList && _selectedProducts.length > 0)
                    ? new Container(
                        margin: EdgeInsets.symmetric(horizontal: 10.0),
                        child: ElevatedButton(
                          style: CommonMethods.elevatedButtonStyle(),
                          onPressed: () async {
                            if (widget.isFromProductList) {
                              if (await NetworkStatus.getInternetStatus()) {
                                this.serviceCallAddProductsToCatalouge();
                              } else {
                                AppUtills.showSnackBar(
                                    _scaffoldkey,
                                    Language().getString(
                                        Constants.NO_INTERNET, selectedLang),
                                    snackBarBgColor: Colors.black,
                                    messageColor: Colors.white,
                                    buttonColor: Colors.white);
                              }
                            } else {
                              Navigator.pop(context, _selectedProducts);
                            }
                          },
                          child: Text(
                            Language().getString(Constants.ADD, selectedLang),
                            style: TextStyle(
                              color: Colors.white,
                            ),
                          ),
                        ),
                      )
                    : null,
            floatingActionButton: renderFloatActionButton(),
            body: Container(
                margin: EdgeInsets.symmetric(horizontal: 10.0),
                child: _scrollContainer()),
          ),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    ));
  }

  bool checkPrivilegeKey() {
    if (CommonMethods.isPrivillegeExist(
            context,
            PrivillegesActions
                .KEY_ONLINE_CONNECTIONS_EXTERNAL_PRODUCTS_SELECT_PRODUCTS) ||
        CommonMethods.isPrivillegeExist(
            context,
            PrivillegesActions
                .KEY_ONLINE_CONNECTIONS_EXTERNAL_PRODUCTS_SELECT_PRODUCTS_BY_CATEGORY)) {
      return true;
    }

    return false;
  }

  _scrollContainer() {
    return Column(
      children: [
        Container(
            margin: EdgeInsets.symmetric(vertical: 5.0, horizontal: 5),
            child: buildSearchBarView()),
        (_productsList.length > 0)
            ? Expanded(
                child: Container(
                  height: (_selectedProducts.length > 0)
                      ? MediaQuery.of(context).size.height * 0.65
                      : MediaQuery.of(context).size.height * 0.75,
                  child: ListView.separated(
                    itemCount: _productsList.length,
                    itemBuilder: (BuildContext context, int index) {
                      return InkWell(
                        onTap: () {
                          if (!isProductCheckBoxVisible) {
                            CommonMethods.hideKeyboard(context);
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => BasicProductDetails(
                                        productId: _productsList[index].id,
                                        isShowBasicDetails: true,
                                        currentBuId: buId)));
                          }
                        },
                        child: productItemView(index),
                      );
                    },
                    separatorBuilder: (BuildContext context, int index) =>
                        new Divider(
                      height: 0.0,
                      color: Colors.transparent,
                    ),
                  ),
                ),
              )
            : Container(
                child: Center(
                  child:
                      Text(Language().getString(showLoaderText, selectedLang)),
                ),
              ),
      ],
    );
  }

  renderFloatActionButton() {
    if (!widget.isFromProductList && _selectedProducts.length > 0) {
      return FloatingActionButton(
        backgroundColor: theme.colorScheme.primary,
        child: Icon(Icons.more_vert),
        onPressed: () {
          buildPopupDialog();
        },
      );
    } else if (isShowFilterButton) {
      return FloatingActionButton(
        backgroundColor: theme.colorScheme.primary,
        child: Text(
          Language().getString(Constants.CLEAR_FILTERS, selectedLang),
          style: TextStyle(color: Colors.white, fontSize: 10.0),
          textAlign: TextAlign.center,
        ),
        onPressed: () {
          setState(() {
            isLoading = false;
            isShowFilterButton = false;
            isLoadingProgress = true;
            _searchController.clear();
          });

          loadProductData();
        },
      );
    } else {
      return null;
    }
  }

  showProductCheckBoxView() {
    return IconButton(
      icon: Icon(Icons.playlist_add_check),
      onPressed: () {
        if (isSelectAllProducts) {
          setState(() {
            isSelectAllProducts = false;
            _selectedProducts.clear();
            _discussionProducts.clear();
            for (int i = 0; i < _productsList.length; i++) {
              _productsList[i].isItemSelected = false;
            }
          });
        } else {
          setState(() {
            isSelectAllProducts = true;
            for (int i = 0; i < _productsList.length; i++) {
              _productsList[i].isItemSelected = true;
              _selectedProducts.add(_productsList[i]);
            }
          });
        }
      },
    );
  }

  buildSearchBarView() {
    return Container(
      decoration: AppUtills.boxDecoration(),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(5.0),
          color: Colors.white,
        ),
        padding: EdgeInsets.only(left: 5),
        child: TextFormField(
          controller: _searchController,
          onChanged: onSearchTextChanged,
          style: TextStyle(fontFamily: 'IndianRupee'),
          decoration: InputDecoration(
              border: InputBorder.none,
              hintText: Language()
                  .getString(Constants.SEARCH_BY_PRODUCT, selectedLang),
              hintStyle: TextStyle(
                fontSize: 13.0,
              )),
        ),
      ),
    );
  }

  Widget productItemView(int index) {
    bool isOfferActive = false;

    /// Checking offer either offer active or not
    for (int i = 0; i < _productsList[index].offerList!.length; i++) {
      if (_productsList[index].offerList![i].isOfferActive != null &&
          _productsList[index].offerList![i].isOfferActive! &&
          !_productsList[index].offerList![i].isOfferExpired!) {
        isOfferActive = true;
      } else {
        isOfferActive = false;
      }
    }

    var data = _productsList[index].images;
    // print('imagesd $data');

    return Container(
      height: 80.0,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(
          10.0,
        ),
      ),
      padding: EdgeInsets.all(
        5.0,
      ),
      child: Container(
        child: Row(
          children: <Widget>[
            Expanded(
              flex: 5,
              child: Container(
                decoration: BoxDecoration(color: Colors.white, boxShadow: [
                  BoxShadow(
                      offset: Offset(0, 0.5),
                      color: Colors.grey,
                      blurRadius: 2.0)
                ]),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                        flex: 2,
                        child: AppUtills.imageAspectRatio(
                            _productsList[index].images,
                            aspectRatio: 1 / 1,
                            context: context)),
                    Expanded(
                      flex: 5,
                      child: Container(
                        height: 60.0,
                        margin: EdgeInsets.symmetric(
                          horizontal: 5.0,
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            Expanded(
                              flex: 2,
                              child: Container(
                                child: Text(
                                  _productsList[index].name!,
                                  style: TextStyle(
                                    color: Color(Constants.APP_COLOR),
                                    fontWeight: FontWeight.bold,
                                    fontSize: 15.0,
                                  ),
                                ),
                              ),
                            ),
                            Expanded(
                              flex: 1,
                              child: Container(
                                child: Text(
                                  Language().getString(
                                          Constants.PRICE, selectedLang) +
                                      ' : $orgCurrencySymbol ' +
                                      CommonMethods.getAvailablePrice(
                                          _productsList[index].batchPriceList!),
                                  style: TextStyle(
                                    color: Color(Constants.APP_COLOR),
                                    fontSize: 11.0,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Expanded(
                        flex: 2,
                        child: Container(
                          margin: EdgeInsets.symmetric(
                            horizontal: 5.0,
                          ),
                          child: Column(
                              mainAxisAlignment: isProductCheckBoxVisible
                                  ? MainAxisAlignment.start
                                  : MainAxisAlignment.center,
                              children: <Widget>[
                                Visibility(
                                  visible: isProductCheckBoxVisible,
                                  child: InkWell(
                                    onTap: () {
                                      CommonMethods.hideKeyboard(context);

                                      /// Checking product checkbox status
                                      if (_productsList[index].isItemSelected) {
                                        setState(() {
                                          _productsList[index].isItemSelected =
                                              !_productsList[index]
                                                  .isItemSelected;
                                        });
                                      } else {
                                        setState(() {
                                          _productsList[index].isItemSelected =
                                              true;
                                        });
                                      }

                                      /// Adding selected products to list

                                      if (_productsList[index].isItemSelected) {
                                        setState(() {
                                          _selectedProducts
                                              .add(_productsList[index]);
                                        });
                                      } else {
                                        for (int i = 0;
                                            i < _selectedProducts.length;
                                            i++) {
                                          if (_productsList[index].id ==
                                              _selectedProducts[i].id) {
                                            setState(() {
                                              _selectedProducts.removeAt(i);
                                            });
                                          }
                                        }
                                      }
                                    },
                                    child: Container(
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                      ),
                                      child: Padding(
                                        padding: const EdgeInsets.all(10.0),
                                        child: _productsList[index]
                                                .isItemSelected
                                            ? Icon(
                                                Icons.check_circle,
                                                size: 20.0,
                                                color: Colors.green,
                                              )
                                            : Icon(
                                                Icons.radio_button_unchecked,
                                                size: 20.0,
                                                color: Colors.grey,
                                              ),
                                      ),
                                    ),
                                  ),
                                ),
                                (isOfferActive)
                                    ? Container(
                                        child: InkWell(
                                            onTap: () {
                                              CommonMethods.hideKeyboard(
                                                  context);
                                              this.offerFunctionality(index);
                                            },
                                            child: Container(
                                              child: Text(
                                                Language().getString(
                                                    Constants.OFFER,
                                                    selectedLang),
                                                style: TextStyle(
                                                    color:
                                                        Colors.redAccent[100],
                                                    decoration: TextDecoration
                                                        .underline),
                                              ),
                                            )),
                                      )
                                    : Container()
                              ]),
                        ))
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  offerFunctionality(int index) {
    for (int i = 0; i < _productsList[index].offerList!.length; i++) {
      if (_productsList[index].offerList![i].isOfferActive! &&
          !_productsList[index].offerList![i].isOfferExpired!) {
        Dialogs.showOffer(
            context,
            _productsList[index].offerList![i].offerQuantity,
            _productsList[index].offerList![i].offerName,
            _productsList[index].offerList![i].minOrder,
            _productsList[index].offerList![i].maxOrder,
            _productsList[index].offerList![i].offerType);
      }
    }
  }

  buildPopupDialog() {
    return showDialog(
        context: context,
        barrierColor: Colors.black54,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
              elevation: 100.0,
              contentPadding: EdgeInsets.fromLTRB(15.0, 0, 15.0, 0),
              backgroundColor: Color(0XFFE0E0E0),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(
                  Radius.circular(
                    7.0,
                  ),
                ),
              ),
              actions: [
                TextButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    child: Text(
                      Language().getString(Constants.CLOSE, selectedLang),
                      style: TextStyle(
                        color: Colors.redAccent,
                      ),
                    ))
              ],
              titlePadding: EdgeInsets.fromLTRB(17.0, 24.0, 0.0, 10.0),
              title: Text(
                Language().getString(Constants.SUGGEST, selectedLang),
                style: TextStyle(color: Color(Constants.APP_COLOR)),
              ),
              content: Container(
                height: 150.0,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (CommonMethods.isPrivillegeExist(
                        context,
                        PrivillegesActions
                            .KEY_ONLINE_CONNECTIONS_EXTERNAL_PRODUCTS_ADD_SELECTED_PRODUCTS_TO_YOUR_CATALOGUE))
                      InkWell(
                        onTap: () {
                          Navigator.of(context).pop();
                          Future.delayed(Duration.zero).then((value) async {
                            if (await NetworkStatus.getInternetStatus()) {
                              this.addToCatalougeFunctionality();
                            } else {
                              AppUtills.showSnackBar(
                                  _scaffoldkey,
                                  Language().getString(
                                      Constants.NO_INTERNET, selectedLang),
                                  snackBarBgColor: Colors.black,
                                  messageColor: Colors.white,
                                  buttonColor: Colors.white);
                            }
                          });
                        },
                        child: Container(
                          width: double.infinity,
                          child: Card(
                            child: Padding(
                              padding: const EdgeInsets.all(10.0),
                              child: Text(
                                Language().getString(
                                    Constants.SELECTED_PRODUCTS_TO_CATELOGUE,
                                    selectedLang),
                                style: TextStyle(
                                    color: Color(Constants.APP_COLOR)),
                              ),
                            ),
                          ),
                        ),
                      ),
                    if (!widget.isInternalConnection &&
                        CommonMethods.isPrivillegeExist(
                            context,
                            PrivillegesActions
                                .KEY_ONLINE_CONNECTIONS_EXTERNAL_PRODUCTS_PLACE_ORDER))
                      InkWell(
                        onTap: () async {
                          setState(() {
                            _discussionProducts.clear();
                          });

                          Navigator.of(context).pop();

                          if (await NetworkStatus.getInternetStatus()) {
                            this.addSelectedProductsToCart();
                          } else {
                            AppUtills.showSnackBar(
                                _scaffoldkey,
                                Language().getString(
                                    Constants.NO_INTERNET, selectedLang),
                                snackBarBgColor: Colors.black,
                                messageColor: Colors.white,
                                buttonColor: Colors.white);
                          }
                        },
                        child: Container(
                          width: double.infinity,
                          child: Card(
                            child: Padding(
                              padding: const EdgeInsets.all(10.0),
                              child: Text(
                                Language().getString(
                                    Constants.PLACE_ORDER_STR, selectedLang),
                                style: TextStyle(
                                    color: Color(Constants.APP_COLOR)),
                              ),
                            ),
                          ),
                        ),
                      )
                  ],
                ),
              ),
            ));
  }

  addToCatalougeFunctionality() {
    return showDialog(
        barrierColor: Colors.black54,
        barrierDismissible: false,
        context: context,
        builder: (context) => AlertDialog(
              elevation: 100.0,
              contentPadding: EdgeInsets.fromLTRB(15.0, 0, 15.0, 0),
              backgroundColor: Color(0XFFE0E0E0),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(
                  Radius.circular(
                    7.0,
                  ),
                ),
              ),
              titlePadding: EdgeInsets.fromLTRB(17.0, 24.0, 0.0, 5.0),
              title: Text(
                Language().getString(Constants.CONFIRMATION, selectedLang),
                style: TextStyle(
                  color: Color(Constants.APP_COLOR),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: Text(
                    Language().getString(Constants.STR_CANCEL, selectedLang),
                    style: TextStyle(color: Color(Constants.APP_COLOR)),
                  ),
                ),
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    this.serviceCallAddProductsToCatalouge();
                  },
                  child: Text(
                    Language().getString(Constants.CONFIRM, selectedLang),
                    style: TextStyle(color: Color(Constants.APP_COLOR)),
                  ),
                ),
              ],
              content: Container(
                child: Text(
                  Language()
                          .getString("Do you want to add these", selectedLang) +
                      " ${_selectedProducts.length} " +
                      Language().getString(
                          "product(s) to your catalogue.", selectedLang),
                  style: TextStyle(color: Color(Constants.APP_COLOR)),
                ),
              ),
            ));
  }

  addSelectedProductsToCart() {
    if (_selectedProducts.length > 0) {
      for (int i = 0; i < _selectedProducts.length; i++) {
        _enterProductCount.add(new TextEditingController());
      }
      return showDialog(
          barrierColor: Colors.black54,
          barrierDismissible: false,
          context: context,
          builder: (context) =>
              StatefulBuilder(builder: (context, StateSetter setState) {
                return AppBackgroundView(
                    body: Container(
                  margin:
                      EdgeInsets.symmetric(horizontal: 10.0, vertical: 20.0),
                  // color: Color(0XFFE0E0E0),
                  child: Scaffold(
                    backgroundColor: Colors.transparent,
                    bottomNavigationBar: Container(
                        padding: EdgeInsets.all(10),
                        child: CommonButtonsView(
                          context: context,
                          b1Text: Language()
                              .getString(Constants.STR_CANCEL, selectedLang),
                          b2Text: Language()
                              .getString(Constants.CONTINUE, selectedLang),
                          onb1Action: () {
                            setState(() {
                              _enterProductCount.clear();
                              _selectedProducts.clear();
                              for (int i = 0; i < _productsList.length; i++) {
                                _productsList[i].isItemSelected = false;
                              }
                            });
                            Navigator.of(context).pop();
                          },
                          onb2Action: () {
                            bool isProductsQuantityExist = false;
                            for (int i = 0; i < _selectedProducts.length; i++) {
                              if (_selectedProducts[i].counter != 0) {
                                isProductsQuantityExist = true;
                              }
                            }
                            if (!isProductsQuantityExist) {
                              Dialogs.yesCancelDialog(
                                  context,
                                  Language()
                                      .getString(Constants.ERROR, selectedLang),
                                  Language().getString(
                                      Constants.PLEASE_SELECT_QUANTITY,
                                      selectedLang),
                                  Language().getString(
                                      Constants.OKAY_STR, selectedLang),
                                  "",
                                  false);
                            } else {
                              Navigator.of(context).pop();
                              showDiscussionDialog(context);
                            }
                          },
                        )),
                    body: Container(
                      child: SingleChildScrollView(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Container(
                              margin: EdgeInsets.symmetric(
                                  vertical: 5.0, horizontal: 10.0),
                              padding: EdgeInsets.only(top: 10),
                              height: 40.0,
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: theme.colorScheme.primary,
                                    elevation: 0),
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                                child: Text(
                                  Language().getString(
                                      Constants.ADD_MORE_PRODUCTS,
                                      selectedLang),
                                  style: TextStyle(
                                    fontWeight: StyleView.fontRegular,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              height: MediaQuery.of(context).size.height * 0.75,
                              child: ListView.separated(
                                shrinkWrap: true,
                                separatorBuilder: (context, index) =>
                                    new Divider(
                                  color: Colors.transparent,
                                  height: 0.0,
                                ),
                                itemCount: _selectedProducts.length,
                                itemBuilder: (context, index) {
                                  return Container(
                                    margin: EdgeInsets.symmetric(
                                      vertical: 5.0,
                                    ),
                                    child: Card(
                                      margin:
                                          EdgeInsets.symmetric(horizontal: 5),
                                      child: Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Row(
                                          children: <Widget>[
                                            Expanded(
                                                flex: 2,
                                                child: AppUtills.displayImage(
                                                    _selectedProducts[index]
                                                        .images,
                                                    context: context)
                                                // this
                                                //     .showProductImage(index),
                                                ),
                                            Expanded(
                                              flex: 4,
                                              child: Padding(
                                                  padding: EdgeInsets.symmetric(
                                                      horizontal: 5),
                                                  child: this
                                                      .showProductNameAndPrice(
                                                          index)),
                                            ),
                                            Expanded(
                                                flex: 3,
                                                child: Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment.end,
                                                    children: <Widget>[
                                                      this.showRemoveIcon(
                                                          index, setState),
                                                      Container(
                                                        child: Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .end,
                                                          children: <Widget>[
                                                            Container(
                                                                child: InkWell(
                                                              onTap: () {
                                                                this.removeProductQuantity(
                                                                    index,
                                                                    setState);
                                                              },
                                                              child: Icon(
                                                                  Icons.remove),
                                                            )),
                                                            Container(
                                                                width: 50.0,
                                                                height: 25.0,
                                                                decoration:
                                                                    AppUtills
                                                                        .boxDecoration(),
                                                                child: this
                                                                    .showQuantityInputField(
                                                                        index)),
                                                            Container(
                                                                child: InkWell(
                                                              onTap: () {
                                                                this.addProductQuantity(
                                                                    index,
                                                                    setState);
                                                              },
                                                              child: Icon(
                                                                  Icons.add),
                                                            ))
                                                          ],
                                                        ),
                                                      ),
                                                    ]))
                                          ],
                                        ),
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ));
              }));
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.INFO, selectedLang),
          Language().getString(Constants.SELECT_PRODUCTS, selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  showDiscussionDialog(context) {
    return showDialog(
      context: context,
      barrierColor: Colors.black54,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        elevation: 100.0,
        contentPadding: EdgeInsets.fromLTRB(15.0, 0, 15.0, 0),
        backgroundColor: Color(0XFFE0E0E0),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(
            Radius.circular(
              7.0,
            ),
          ),
        ),
        titlePadding: EdgeInsets.fromLTRB(17.0, 24.0, 0.0, 5.0),
        content: Text(
            Language().getString(
                Constants.START_DISCUSSION_WITH_THESE_PRODUCTS, selectedLang),
            style: TextStyle(color: Color(Constants.APP_COLOR))),
        title: Text(
          Language().getString(Constants.INFO, selectedLang),
          style: TextStyle(color: Color(Constants.APP_COLOR)),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: Text(
                Language().getString(Constants.STR_CANCEL, selectedLang),
                style: TextStyle(color: Color(Constants.APP_COLOR))),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              serviceCallPlaceOrder();
            },
            child: Text(
                Language().getString(Constants.YES_STRING, selectedLang),
                style: TextStyle(color: Color(Constants.APP_COLOR))),
          ),
        ],
      ),
    );
  }

  showRemoveIcon(int index, StateSetter setState) {
    return Container(
      margin: EdgeInsets.symmetric(
        vertical: 10.0,
      ),
      child: InkWell(
        onTap: () async {
          // /// Removing item when discussion item removed
          final action = await Dialogs.removeItem(
            context,
            _selectedProducts[index].name,
            Language().getString(Constants.WARNING, selectedLang),
            Language().getString(Constants.WARNING_TEXT, selectedLang),
            cancel: Language().getString(Constants.STR_CANCEL, selectedLang),
            yes: Language().getString(Constants.YES_STRING, selectedLang),
          );

          if (action == DialogAction.yes) {
            setState(() {
              _selectedProducts.removeAt(index);
            });
          }
        },
        child: Icon(
          Icons.remove_circle_outline,
          color: Colors.red,
          size: 20.0,
        ),
      ),
    );
  }

  showQuantityInputField(int index) {
    return TextFormField(
      textAlign: TextAlign.center,
      controller: _enterProductCount[index],
      decoration: InputDecoration(
        hintText: "0",
        border: InputBorder.none,
      ),
      keyboardType: TextInputType.number,
      style: TextStyle(fontSize: 12.0),
      inputFormatters: [
        new LengthLimitingTextInputFormatter(7),
        FilteringTextInputFormatter.digitsOnly
      ],
      onChanged: (value) {
        /// Adding input value for product counter value
        if (value.isEmpty) {
          _selectedProducts[index].counter = 0;
        } else {
          _selectedProducts[index].counter = int.parse(value);
        }
      },
    );
  }

  showProductNameAndPrice(int index) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        new Text(
          _selectedProducts[index].name!,
          style: TextStyle(
            color: Color(Constants.APP_COLOR),
            fontWeight: FontWeight.bold,
            fontSize: 17.0,
          ),
        ),
        SizedBox(height: 5),
        Text(
          Language().getString(Constants.PRICE, selectedLang) +
              " : $orgCurrencySymbol" +
              CommonMethods.getCurrencyValues(_selectedProducts[index].price),
          style: TextStyle(fontSize: 11.0, color: Color(Constants.APP_COLOR)),
        ),
      ],
    );
  }

  showProductImage(int index) {
    return Image.memory(
      base64.decode(_selectedProducts[index]
          .images!
          .replaceFirst(RegExp(r'data:image/[^;]+;base64,'), '')
          .toString()),
      width: 30,
      height: 30,
      gaplessPlayback: true,
    );
  }

  addProductQuantity(int index, StateSetter setState) {
    setState(() {
      _selectedProducts[index].counter = _selectedProducts[index].counter! + 1;
      _enterProductCount[index] = TextEditingController(
          text: _selectedProducts[index].counter.toString());
      _enterProductCount[index].selection = TextSelection.fromPosition(
          TextPosition(offset: _enterProductCount[index].text.length));
    });
  }

  removeProductQuantity(int index, StateSetter setState) {
    if (_selectedProducts[index].counter != 0) {
      setState(() {
        _selectedProducts[index].counter =
            _selectedProducts[index].counter! - 1;
        _enterProductCount[index] = TextEditingController(
            text: _selectedProducts[index].counter.toString());
        _enterProductCount[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _enterProductCount[index].text.length));
      });
    } else {
      _selectedProducts[index].counter = 0;
      _enterProductCount[index].clear();
    }
  }

  removeDiscussionProducts(int index) {
    /// setState selected products and discussion products
    // for (int i = 0; i < _selectedProducts.length; i++) {
    //   if (_discussionProducts[index].id == _selectedProducts[i].id) {
    setState(() {
      // _discussionProducts.removeAt(index);
      _selectedProducts.removeAt(index);
    });
    //   }
    // }
  }

  showAddToCatelougeSuccessPopup() {
    return showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black54,
      builder: (context) => AlertDialog(
        elevation: 100.0,
        backgroundColor: Color(0XFFE0E0E0),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(
            Radius.circular(
              7.0,
            ),
          ),
        ),
        title: Text(Language().getString(Constants.SUCCESS, selectedLang),
            style: TextStyle(
              color: Color(Constants.APP_COLOR),
            )),
        titlePadding: EdgeInsets.fromLTRB(17.0, 24.0, 0.0, 5.0),
        contentPadding: EdgeInsets.fromLTRB(17.0, 10.0, 0.0, 5.0),
        content: Text(
            Language().getString(
                "Product(s) added successfully to your catalogue. Please add Quantity and Price for this products from catalogue.",
                selectedLang),
            style: TextStyle(
              color: Color(Constants.APP_COLOR),
            )),
        actions: [
          TextButton(
            onPressed: () {
              setState(() {
                _selectedProducts.clear();
                isProductCheckBoxVisible = false;
                isSelectAllProducts = false;
              });

              if (widget.isFromProductList) {
                Navigator.of(context).pop();
                Navigator.pop(context);
              } else {
                Navigator.push(
                  context,
                  new MaterialPageRoute(
                    builder: (context) => ProductsMenuPage(
                      isFromBuList: true,
                      currentBuId: AppController.instance.getMyBuId,
                      currentBuName: AppController.instance.getBuName,
                    ),
                  ),
                );
              }
            },
            child: Text(
                Language().getString(Constants.GO_TO_CATALOGUE, selectedLang),
                style: TextStyle(
                  color: Color(Constants.APP_COLOR),
                )),
          ),
          TextButton(
            onPressed: () {
              setState(() {
                _selectedProducts.clear();
                isProductCheckBoxVisible = false;
                isSelectAllProducts = false;
              });
              Navigator.of(context).pop();
            },
            child: Text(Language().getString(Constants.OKAY_STR, selectedLang),
                style: TextStyle(
                  color: Color(Constants.APP_COLOR),
                )),
          ),
        ],
      ),
    );
  }

  serviceCallAddProductsToCatalouge() async {
    setState(() {
      isLoadingProgress = true;
    });
    List<Map<String, dynamic>> _productsArray = [];
    var productObject;
    for (int i = 0; i < _selectedProducts.length; i++) {
      productObject = {
        "buId": widget.buId,
        "id": _selectedProducts[i].id,
        "filters": {}
      };
      _productsArray.add(productObject);
    }

    Map data = {
      "buId": AppController.instance.getMyBuId,
      "products": _productsArray
    };
    String body = json.encode(data);

    var response = await _productService
        .addProductsInConnectionBU_grpc(body,
            token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      showAddToCatelougeSuccessPopup();
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  serviceCallPlaceOrder() async {
    setState(() {
      isLoadingProgress = true;
    });
    List<Map<String, dynamic>> _productsArray = [];
    var productObject;

    for (int i = 0; i < _selectedProducts.length; i++) {
      if (_selectedProducts[i].counter != 0) {
        productObject = {
          "id": _selectedProducts[i].id,
          "quantity": _selectedProducts[i].counter,
          "quantity_in": _selectedProducts[i].quantityIn
        };
        _productsArray.add(productObject);
      }
    }

    Map data = {
      "buyer": {
        "id": AppController.instance.getMyBuId,
        "name": AppController.instance.getBuName
      },
      "seller": {"id": buId, "name": buName},
      "ctr": {"type": "", "Agent": "", "transaction_ref": ""},
      "discussion": {
        "initiator": buId,
        "initiator_user": buName,
        "message_start_date": "",
        "confirmation_message": [],
        "confirmation_status": ""
      },
      "rough_orders": {"products": _productsArray}
    };
    if (rawMaterialTransactionRadioValue != null) {
      data['transaction_type'] = Constants.KEY_RAW_MATERIAL;
    }
    String body = json.encode(data);

    // http.Response response = await _service.addProductsToDiscussion(body);
    var response = await _transactionService
        .connectionPlaceOrder(body: body, token: "")
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);

      /// Create transaction discussion
      sendMessageToServer(data); //["data"]);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  sendMessageToServer(String? transactionId) async {
    setState(() {
      isLoadingProgress = true;
    });
    List<Map<String, dynamic>> resultProducts = [];
    var productsObject;

    for (int i = 0; i < _selectedProducts.length; i++) {
      if (_selectedProducts[i].counter != 0) {
        productsObject = {
          "product_name": _selectedProducts[i].name,
          "product_image": _selectedProducts[i].images,
          "product_price": _selectedProducts[i].price,
          "product_quantity": _selectedProducts[i].counter
        };
        resultProducts.add(productsObject);
      }
    }

    String message = json.encode(resultProducts);
    Map data = {
      "bu": AppController.instance.getMyBuId,
      "messages": message,
      "id": transactionId,
      "user_name": AppController.instance.getBuName,
      "type": "PRODUCTS"
    };
    String body = json.encode(data);

    // http.Response response = await _service.discussioin_put(body);

    var response = await _transactionService
        .sedMessage(body: body, token: "")
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);
      setState(() {
        _productsList.clear();
        _responseProducts.clear();
        _discussionProducts.clear();
        _selectedProducts.clear();
        isSelectAllProducts = false;
        isProductCheckBoxVisible = false;
        isLoading = false;
        _enterProductCount.clear();
        isLoadingProgress = true;
      });

      Navigator.push(
        context,
        new MaterialPageRoute(
          builder: (context) => DiscussionView(
            transactionId: transactionId,
            transactionName: AppController.instance.getBuName,
            firebaseToken: "",
          ),
        ),
      ).then((value) => loadProductData());
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  onSearchTextChanged(String text) async {
    showLoaderText = Constants.LOADING;
    if (text.isEmpty) {
      isLoading = false;
      loadProductData();
    } else {
      loadProductData(name: text);
    }
  }
}
