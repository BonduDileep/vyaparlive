import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/core/enums/privilleges_enum.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'package:flutx/flutx.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:vyaparlive/Product/products_widget/PopupMenuItemDesign.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/common_methods.dart';

import 'package:vyaparlive/model/BuBasicDataModel.dart';
import 'package:vyaparlive/model/Contacts.dart';

class ConnectionCard extends StatelessWidget {
  ConnectionCard(this._isInternalConnection,
      {this.contacts,
      this.buBasicDataModel,
      this.onTermsClick,
      this.onProductsClick,
      this.onActivityClick,
      this.onStartDiscussionClick,
      this.onBuDetailsClick,
      this.onDirectOrder,
      this.onAssignToUser,
      this.namesMapData,
      this.addToDistributor,
      this.onUsersList,
      this.onRecallOfProducts,
      this.onReturnsOfProducts,
      this.onDirectSellOrder,
      this.onChatClick});

  final bool _isInternalConnection;
  final Contacts? contacts;
  final BuBasicDataModel? buBasicDataModel;
  final VoidCallback? onTermsClick;
  final VoidCallback? onProductsClick;
  final VoidCallback? onActivityClick;
  final VoidCallback? onStartDiscussionClick;
  final VoidCallback? onBuDetailsClick;
  final VoidCallback? onDirectOrder;
  final VoidCallback? onAssignToUser;
  final List<Map>? namesMapData;
  final VoidCallback? addToDistributor;
  final VoidCallback? onUsersList;
  final VoidCallback? onReturnsOfProducts;
  final VoidCallback? onRecallOfProducts;
  final VoidCallback? onDirectSellOrder;
  final VoidCallback? onChatClick;
  final ThemeData theme = AppTheme.vyaparTheme;
  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 5.0,
      shadowColor: theme.colorScheme.primary,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(5.0),
          side: BorderSide(
              color: theme.colorScheme.primaryContainer, strokeAlign: 1)),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
            child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
              Expanded(
                child: Container(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            child: Icon(
                              FeatherIcons.home,
                              size: 18,
                              color: Colors.black54,
                            ),
                          ),
                          FxSpacing.width(5.0),
                          Expanded(
                            child: Text(
                              !_isInternalConnection
                                  ? ((contacts!.buName != null)
                                      ? contacts!.buName!
                                      : "")
                                  : (buBasicDataModel!.businessName != null
                                      ? buBasicDataModel!.businessName!
                                      : ""),
                              style: TextStyle(
                                  color: Colors.black, //(Constants.APP_COLOR),
                                  fontWeight: StyleView.fontBold,
                                  fontSize: 15.0),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 10.0),
                      Row(
                        children: [
                          Container(
                            child: Icon(
                              FeatherIcons.mapPin,
                              size: 18,
                              color: Colors.black54,
                            ),
                          ),
                          FxSpacing.width(5.0),
                          Container(
                            child: (!_isInternalConnection)
                                ? Expanded(
                                    child: Text(
                                      CommonMethods.addressValidation(
                                          contacts!.landmark, contacts!.city),
                                      style: TextStyle(
                                          color: Colors.black,
                                          fontWeight: StyleView.fontSemiBold,
                                          fontSize: 13.0),
                                    ),
                                  )
                                : Text(
                                    CommonMethods.addressValidation(
                                        buBasicDataModel!.landmark,
                                        buBasicDataModel!.city),
                                    style: TextStyle(
                                      fontWeight: StyleView.fontSemiBold,
                                      color:
                                          Colors.black, //(Constants.APP_COLOR),
                                    ),
                                  ),
                          ),
                        ],
                      ),
                      SizedBox(height: 10.0),
                      Row(
                        children: [
                          Container(
                            child: Icon(
                              FeatherIcons.phoneCall,
                              size: 18.0,
                              color: Colors.black54,
                            ),
                          ),
                          FxSpacing.width(10.0),
                          Container(
                              child: InkWell(
                            onTap: () {
                              CommonMethods.hideKeyboard(context);
                              if (kIsWeb) {
                                return;
                              }
                              launchUrl(Uri.parse(
                                  "tel: " + contacts!.contactNumber!));
                            },
                            child: (!_isInternalConnection)
                                ? Text(
                                    contacts!.contactNumber!,
                                    style: TextStyle(
                                        color: Colors.black,
                                        decoration: TextDecoration.underline,
                                        decorationColor: Colors.black,
                                        fontWeight: StyleView.fontSemiBold,
                                        fontSize: 13.0),
                                  )
                                : Text(
                                    buBasicDataModel!.contactNumber!,
                                    style: TextStyle(
                                        color: Colors.black,
                                        decoration: TextDecoration.underline,
                                        fontWeight: StyleView.fontSemiBold,
                                        fontSize: 13.0),
                                  ),
                          )),
                        ],
                      ),
                      (contacts != null && contacts!.isDistributor!)
                          ? Container(
                              margin: EdgeInsets.symmetric(vertical: 5.0),
                              child: Text(
                                namesMapData![9]['name'],
                                style: TextStyle(color: Colors.amber[900]),
                              ),
                            )
                          : Container()
                    ],
                  ),
                ),
              ),
              // if (!_isInternalConnection)
              Container(
                child: PopupMenuButton<String>(
                    elevation: 5,
                    shadowColor: AppTheme.vyaparTheme.colorScheme.primary,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(10.0)),
                        side: new BorderSide(
                            color: AppTheme
                                .vyaparTheme.colorScheme.primaryContainer,
                            strokeAlign: 1)),
                    onSelected: (dynamic value) {
                      switch (value) {
                        case "TERMS_CONDITIONS":
                          onTermsClick!();
                          break;
                        case "PRODUCTS":
                          onProductsClick!();
                          break;
                        case "DISCUSSION":
                          onStartDiscussionClick!();
                          break;

                        case "TRANSACTION":
                          onActivityClick!();
                          break;
                        case "DETAILS":
                          onBuDetailsClick!();
                          break;
                        case "DIRECT ORDER":
                          onDirectOrder!();
                          break;
                        case "ASSIGN USER":
                          onAssignToUser!();
                          break;
                        case "DISTRIBUTOR":
                          addToDistributor!();
                          break;
                        case Constants.FIELD_OFFICERS_LIST:
                          onUsersList!();
                          break;
                        case Constants.RETURN_PRODUCTS:
                          onReturnsOfProducts!();
                          break;
                        case Constants.RE_CALL_PRODUCTS:
                          onRecallOfProducts!();
                          break;
                        case Constants.DIRECT_SELL_ORDERS:
                          onDirectSellOrder!();
                          break;
                        // case "CHAT":
                        //   onChatClick!();
                        //   break;
                        default:
                      }
                    },
                    icon: Icon(
                      Icons.more_vert,
                      color: theme.colorScheme.primary,
                    ),
                    itemBuilder: ((context) => _buildMenuItems(context))),
              )
            ])),
      ),
    );
  }

  List<PopupMenuEntry<String>> _buildMenuItems(BuildContext context) {
    return [
      if (!_isInternalConnection &&
          CommonMethods.isPrivillegeExist(context,
              PrivillegesActions.KEY_ONLINE_CONNECTIONS_EXTERNAL_SALES_TERMS))
        PopupMenuItem(
          child: PopupMenuItemDesingView(
              assetPath: "assets/images/terms.png",
              itemName: namesMapData![0]['name']),
          value: "TERMS_CONDITIONS",
        ),
      if (CommonMethods.isPrivillegeExist(
          context, PrivillegesActions.KEY_ONLINE_CONNECTIONS_EXTERNAL_PRODUCTS))
        PopupMenuItem(
          child: PopupMenuItemDesingView(
              assetPath: "assets/images/order_list.png",
              itemName: namesMapData![1]['name']),
          value: "PRODUCTS",
        ),
      if (!_isInternalConnection &&
          CommonMethods.isPrivillegeExist(
              context,
              PrivillegesActions
                  .KEY_ONLINE_CONNECTIONS_EXTERNAL_START_DISCUSSION))
        PopupMenuItem(
          child: PopupMenuItemDesingView(
              assetPath: "assets/images/discussion.png",
              itemName: namesMapData![2]['name']),
          value: "DISCUSSION",
        ),
      if (!_isInternalConnection &&
          CommonMethods.isPrivillegeExist(
              context,
              PrivillegesActions
                  .KEY_ONLINE_CONNECTIONS_EXTERNAL_TRANSACTION_HISTORY))
        PopupMenuItem(
            child: PopupMenuItemDesingView(
                assetPath: "assets/images/transaction_icon_product.png",
                itemName: namesMapData![3]['name']),
            value: "TRANSACTION"),
      if (CommonMethods.isPrivillegeExist(context,
          PrivillegesActions.KEY_ONLINE_CONNECTIONS_EXTERNAL_BU_DETAILS))
        PopupMenuItem(
            child: PopupMenuItemDesingView(
                assetPath: "assets/images/details.png",
                itemName: namesMapData![4]['name']),
            value: "DETAILS"),
      if (!_isInternalConnection &&
          CommonMethods.isPrivillegeExist(
              context,
              PrivillegesActions
                  .KEY_ONLINE_CONNECTIONS_EXTERNAL_DIRECT_PURCHASE_ORDER))
        PopupMenuItem(
            child: PopupMenuItemDesingView(
                assetPath: "assets/images/details.png",
                itemName: namesMapData![5]['name']),
            value: "DIRECT ORDER"),
      if (!_isInternalConnection &&
          CommonMethods.isPrivillegeExist(
              context,
              PrivillegesActions
                  .KEY_ONLINE_CONNECTIONS_EXTERNAL_ASSIGN_TO_USER))
        PopupMenuItem(
            child: PopupMenuItemDesingView(
                assetPath: "assets/images/social.png",
                itemName: namesMapData![6]['name']),
            value: "ASSIGN USER"),
      if (!_isInternalConnection &&
          CommonMethods.isPrivillegeExist(
              context,
              PrivillegesActions
                  .KEY_ONLINE_CONNECTIONS_EXTERNAL_ADD_AS_DISTRIBUTOR))
        PopupMenuItem(
            child: PopupMenuItemDesingView(
                assetPath: "assets/images/social.png",
                itemName: contacts!.isDistributor!
                    ? namesMapData![8]['name']
                    : namesMapData![7]['name']),
            value: "DISTRIBUTOR"),
      if (!_isInternalConnection &&
          CommonMethods.isPrivillegeExist(
              context,
              PrivillegesActions
                  .KEY_ONLINE_CONNECTIONS_EXTERNAL_FIELD_OFFICERS_LIST))
        PopupMenuItem(
            child: PopupMenuItemDesingView(
                assetPath: "assets/images/social.png",
                itemName: namesMapData![10]['name']),
            value: Constants.FIELD_OFFICERS_LIST),
      if (!_isInternalConnection &&
          CommonMethods.isPrivillegeExist(
              context,
              PrivillegesActions
                  .KEY_ONLINE_CONNECTIONS_EXTERNAL_RETURN_OF_PRODUCTS))
        PopupMenuItem(
            child: PopupMenuItemDesingView(
                assetPath: "assets/images/details.png",
                itemName: namesMapData![11]['name']),
            value: Constants.RETURN_PRODUCTS),
      if (!_isInternalConnection &&
          CommonMethods.isPrivillegeExist(
              context,
              PrivillegesActions
                  .KEY_ONLINE_CONNECTIONS_EXTERNAL_RECALL_OF_PRODUCTS))
        PopupMenuItem(
            child: PopupMenuItemDesingView(
                assetPath: "assets/images/details.png",
                itemName: namesMapData![12]['name']),
            value: Constants.RE_CALL_PRODUCTS),
      if (!_isInternalConnection &&
          CommonMethods.isPrivillegeExist(
              context,
              PrivillegesActions
                  .KEY_ONLINE_CONNECTIONS_EXTERNAL_DIRECT_SELL_ORDER))
        PopupMenuItem(
            child: PopupMenuItemDesingView(
                assetPath: "assets/images/details.png",
                itemName: namesMapData![13]['name']),
            value: Constants.DIRECT_SELL_ORDERS),
      // PopupMenuItem(
      //     child: PopupMenuItemDesingView(
      //         assetPath: "assets/images/discussion.png",
      //         itemName: "Chat"),
      //     value: "CHAT"),
    ];
  }

  clickableItem(String assetPath, String itemName) {
    return Row(
      children: [
        Container(
          margin: EdgeInsets.symmetric(horizontal: 2.0),
          child: ImageIcon(
            AssetImage(assetPath),
            size: 15,
            color: Color(Constants.APP_COLOR),
          ),
        ),
        Text(
          itemName,
          style: TextStyle(
              fontSize: 13.0,
              color: Color(Constants.APP_COLOR),
              fontWeight: FontWeight.w400),
        ),
      ],
    );
  }

  containerBoxDecoration() {
    return BoxDecoration(
        color: Colors.grey[200],
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(5.0),
          topRight: Radius.circular(4.0),
          bottomLeft: Radius.circular(5.0),
          bottomRight: Radius.circular(4.0),
        ));
  }
}
