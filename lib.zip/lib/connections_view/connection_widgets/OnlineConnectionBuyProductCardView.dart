import 'package:flutter/material.dart';

import 'package:vyaparlive/components/Constants.dart';

import '../../components/AppUtills.dart';

class OnlineConnectionBuyProductCardView extends StatelessWidget {
  final VoidCallback? onRemoveProductQuantit;
  final VoidCallback? onAddProductQuantity;
  final Widget? desingQuntityField;
  final VoidCallback? removeProduct;
  final String? productName;
  final num? productTotalPrice;
  final bool isFromRawProductIssuePage;
  final bool isShowRemove;
  final String productImage;
  OnlineConnectionBuyProductCardView(
      {this.onAddProductQuantity,
      this.desingQuntityField,
      this.onRemoveProductQuantit,
      this.removeProduct,
      this.productName,
      this.productTotalPrice,
      this.isFromRawProductIssuePage = false,
      this.isShowRemove = false,
      required this.productImage});
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Row(
          children: <Widget>[
            SizedBox(
              height: 75,width: 75,
              child: Container(
                  margin: EdgeInsets.only(left: 5.0,right: 5.0),
                  child: ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: AppUtills.imageAspectRatio(productImage,
                          aspectRatio: 16 / 12, context: context)),
                ),
            ),
            Expanded(
              child: Container(
                child: new Text(
                  "$productName",
                  style: TextStyle(
                    color: Color(Constants.APP_COLOR),
                    fontSize: 15.0,
                  ),
                ),
              ),
            ),
            Expanded(
              child: Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Container(
                        child: InkWell(
                      onTap: () {
                        onRemoveProductQuantit!();
                      },
                      child: Icon(Icons.remove),
                    )),
                    desingQuntityField!,
                    Container(
                        child: InkWell(
                      onTap: () {
                        onAddProductQuantity!();
                      },
                      child: Icon(Icons.add),
                    ))
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
