import 'package:vyaparlive/service/organization_service.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/BusinessUnitModel.dart';
import 'package:vyaparlive/model/CurrecyNameDAO.dart';
import 'package:http/http.dart' as http;
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/TermsAndConditionsDAO.dart';
import 'package:vyaparlive/model/bu_model/PaymentTermsDAO.dart';
import 'package:vyaparlive/model/bu_model/PenaltyAmountDAO.dart';
import 'dart:convert';
import 'package:vyaparlive/service/Service.dart';
import 'package:vyaparlive/service/invitation_services.dart';

class TermsAndConditionsPage extends StatefulWidget {
  TermsAndConditionsPage(
      {this.connectionId, this.connectionName, this.connectionBuId});
  final String? connectionName;
  final String? connectionId;
  final String? connectionBuId;
  @override
  _TermsAndConditionsPageState createState() => _TermsAndConditionsPageState();
}

class _TermsAndConditionsPageState extends State<TermsAndConditionsPage> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  List<CurrencyNameDAO> _currencyList = [];
  CurrencyNameDAO? currencyDropdown;
  String? advancePaymentPercentage;
  String? advancePaymentNoValue;
  String? _radioValue;
  String? choice;
  bool isPaymentVisible = false;
  final _commentController = TextEditingController();
  String? penaltyPercentage;
  late Service _service;
  EdgeInsetsGeometry dialogTitlePadding =
      EdgeInsets.fromLTRB(17.0, 24.0, 24.0, 5.0);
  List<TermsAndConditionsDAO> _termsData = [];
  List<BusinessUnitModel> _buList = [];
  bool isLoadingProgress = true;
  String progressMessage = Constants.GETTING_DATA;
  late InvitationService _invitationService;
  List<PaymentTermsDAO> paymentTermsList = [];
  PaymentTermsDAO? paymentTermDropdown;
  List<PenaltyAmountDAO> penaltyAmountList = [];
  PenaltyAmountDAO? penaltyAmountDropdown;
  String? selectedLang = AppController.instance.getSelectedlanguage; // 'en';
  late SharedPreferences sharedPreferences;
  late OrganizationService _organizationService;
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _service = Service();
    _organizationService = new OrganizationService();
    _invitationService = InvitationService();
    loadConnectionData();
    loadCurrencyData();
  }

  loadCurrencyData() async {
    if (await NetworkStatus.getInternetStatus()) {
      this.getCurrency().then((value) {
        setState(() {
          _currencyList.addAll(value);
          if (_termsData.length > 0 && _termsData[0].paymentTerms != null) {
            for (int i = 0; i < _currencyList.length; i++) {
              if (_termsData[0].paymentTerms!.invoicecurrencycode ==
                  _currencyList[i].code) {
                currencyDropdown = _currencyList[i];
              }
            }
          }
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  loadConnectionData() async {
    if (await NetworkStatus.getInternetStatus()) {
      await this.getPaymentTerms().then((value) {
        setState(() {
          paymentTermsList.clear();
          paymentTermsList.addAll(value);
        });
      });
      await this.getPenaltyAmountList().then((value) {
        setState(() {
          penaltyAmountList.clear();
          penaltyAmountList.addAll(value);
        });
      });
      await this.getConnectionDetails().then((value) {
        setState(() {
          _termsData.addAll(value);
          if (_termsData.length > 0 && _termsData[0].paymentTerms != null) {
            appendPaymentTermsData(_termsData[0].paymentTerms);
          } else {
            this.getBuData().then((value) {
              _buList.addAll(value);
              if (_buList.length > 0 && _buList[0].paymentTerms != null) {
                appendPaymentTermsData(_buList[0].paymentTerms);
              }
            });
          }
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
        body: Stack(
      children: [
        SafeArea(
          child: Scaffold(
            key: _scaffoldkey,
            backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
            appBar: AppBar(
              centerTitle: true,
              backgroundColor: Colors.transparent, //(Constants.APP_COLOR),
              elevation: 0,
              iconTheme: IconThemeData(color: theme.colorScheme.primary),
              title: AppbarName(
                  title: Language()
                      .getString(Constants.TERMS_AND_CONDITIONS, selectedLang),
                  buName: "${widget.connectionName!}"),
              actions: [
                AppUtills.homeButton(context),
              ],
            ),
            bottomNavigationBar: Container(
              padding: EdgeInsets.symmetric(horizontal: 10.0, vertical: 20),
              child: CommonButtonsView(
                context: context,
                b1Text: "",
                b2Text: Language().getString(
                    Constants.UPDATE_CONNECTION_SPECIFIC_TERMS_STR, selectedLang),
                onb2Action: () async {
                  String errorMessage = validateMandatoryFields();
                  if (errorMessage.isNotEmpty) {
                    Dialogs.yesCancelDialog(
                        context,
                        Language().getString(Constants.ERROR, selectedLang),
                        Language().getString(errorMessage, selectedLang),
                        Language().getString(Constants.OKAY_STR, selectedLang),
                        "",
                        false);
                  } else {
                    if (await NetworkStatus.getInternetStatus()) {
                      this.serviceCallAddTerms();
                    } else {
                      AppUtills.showSnackBar(
                          _scaffoldkey,
                          Language()
                              .getString(Constants.NO_INTERNET, selectedLang),
                          snackBarBgColor: Colors.black,
                          messageColor: Colors.white,
                          buttonColor: Colors.white);
                    }
                  }
                },
              ),
            ),
            body: SingleChildScrollView(
              child: Container(
                margin: EdgeInsets.symmetric(
                  vertical: 5.0,
                  horizontal: 10.0,
                ),
                child: Column(
                  children: [
                    buildTextField(Constants.PAYMENT_TERMS_STRING),
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(
                          5.0,
                        ),
                        border: Border.all(
                          color: Colors.grey,
                        ),
                      ),
                      child: Column(
                        children: [
                          buildPaymentTermsVew(),
                          SizedBox(
                            height: 1,
                            child:
                                new Container(color: Color(Constants.GREY_COLOR)),
                          ),
                          buildPaymentTermDropdown(
                              Constants.INVOICE_PAYMENT_TERMS),
                          SizedBox(
                            height: 1,
                            child:
                                new Container(color: Color(Constants.GREY_COLOR)),
                          ),
                          buildPenaltyPercentageDropdown(
                              Constants.PAYMENT_TERMS_STR),
                        ],
                      ),
                    ),
          
                    // buildTextField("Advance Payment"),
                    buildAdvancePaymentView(),
          
                    Visibility(
                        visible: isPaymentVisible, child: buildYesDropdown()),
                    buildTextField(Constants.CUSTOME_REMARKS),
                    buildCommentFieldView(_commentController),
                  ],
                ),
              ),
            ),
          ),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    ));
  }

  String validateMandatoryFields() {
    if (currencyDropdown == null) {
      return Language()
          .getString(Constants.PLEASE_SELECT_COUNTRY_CODE, selectedLang);
    } else if (paymentTermDropdown == null) {
      return Language()
          .getString(Constants.PLEASE_SELECT_PAYMENT_TERMS, selectedLang);
    } else if (penaltyAmountDropdown == null) {
      return Language()
          .getString(Constants.PLEASE_SELECT_PENALTY_REASON, selectedLang);
    } else if (penaltyPercentage == null) {
      return Language()
          .getString(Constants.PLEASE_SELECT_PENALTY_PERCENTAGE, selectedLang);
    } else {
      return "";
    }
  }

  buildText(String title, String subTitle) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(title,
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_15,
                            fontFamily: StyleView.FONT_TITLE))),
              )),
        ),
        Expanded(
          flex: 2,
          child: Container(
              color: Colors.white70,
              height: 50,
              padding: EdgeInsets.only(left: 5),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  subTitle,
                  style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                ),
              )),
        )
      ],
    );
  }

  buildRichText(String text, String value) {
    return RichText(
      text: TextSpan(
        children: [
          TextSpan(
            text: text,
            style: TextStyle(
              fontSize: 17.0,
              color: Colors.black,
              fontFamily: StyleView.FONT_TITLE,
            ),
          ),
          TextSpan(
            text: " : " + value,
            style: TextStyle(
              color: Colors.black,
              fontSize: 16.0,
              fontFamily: StyleView.FONT_TITLE,
            ),
          )
        ],
      ),
    );
  }

  buildAdvancePaymentView() {
    return Container(
      padding: EdgeInsets.only(top: 16),
      child: Row(
        children: [
          buildTextField(Constants.ADVANCE_PAYMENT),
          Radio(
            value: Constants.YES_STRING,
            groupValue: _radioValue,
            onChanged: radioButtonChanges,
          ),
          Text(Language().getString(Constants.YES_STRING, selectedLang)),
          Radio(
            value: Constants.NO_STRING,
            groupValue: _radioValue,
            onChanged: radioButtonChanges,
          ),
          Text(Language().getString(Constants.NO_STRING, selectedLang)),
        ],
      ),
    );
  }

  void radioButtonChanges(String? value) {
    setState(() {
      _radioValue = value;
      switch (value) {
        case Constants.YES_STRING:
          choice = value;
          isPaymentVisible = true;
          break;
        case Constants.NO_STRING:
          choice = value;
          isPaymentVisible = false;
          advancePaymentPercentage = null;
          break;
      }
    });
  }

  buildYesDropdown() {
    return Container(
        decoration: BoxDecoration(
          border: Border.all(
            color: Colors.grey,
          ),
          borderRadius: BorderRadius.circular(
            5.0,
          ),
          color: Colors.white70,
        ),
        padding: EdgeInsets.only(left: 5, right: 5),
        child: DropdownButton<String>(
            onTap: () {
              return CommonMethods.hideKeyboard(context);
            },
            value: advancePaymentPercentage,
            isExpanded: true,
            hint: Text(
                Language().getString(Constants.SELECT_PERCENTAGE, selectedLang),
                style: TextStyle(fontFamily: StyleView.FONT_TITLE)),
            underline: SizedBox(),
            onChanged: (String? data) {
              setState(() {
                advancePaymentPercentage = data;
              });
            },
            items: Constants.PERCENTAGELIST.map((String model) {
              return new DropdownMenuItem<String>(
                child: new Text(model,
                    style: TextStyle(fontFamily: StyleView.FONT_TITLE)),
                value: model,
              );
            }).toList()));
  }

  buildPaymentTermsVew() {
    return Container(
      child: Column(
        children: [
          buildcurrencyDropdown(Constants.INVOICE_CURRENCY_CODE_STRING),
        ],
      ),
    );
  }

  buildcurrencyDropdown(String text) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 55,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(Language().getString(text, selectedLang),
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: StyleView.FONT_TITLE))),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Row(
                children: [
                  Container(
                    height: 55.0,
                    color: Colors.white,
                    child: Padding(
                      padding: const EdgeInsets.all(5.0),
                      child: Center(
                        child: Text(
                          currencyDropdown != null
                              ? currencyDropdown!.htmlSymbol!
                              : "",
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Container(
                        height: 55.0,
                        color: Colors.white,
                        child: Padding(
                          padding: const EdgeInsets.all(5.0),
                          child: DropdownButton<CurrencyNameDAO>(
                              onTap: () {
                                return CommonMethods.hideKeyboard(context);
                              },
                              value: currencyDropdown,
                              isExpanded: true,
                              hint: Text(
                                  Language().getString(
                                      Constants.SELECT_CURRENCY_CODE_STRING,
                                      selectedLang),
                                  style: TextStyle(
                                      fontFamily: StyleView.FONT_TITLE)),
                              underline: SizedBox(),
                              onChanged: (CurrencyNameDAO? data) {
                                setState(() {
                                  currencyDropdown = data;
                                });
                              },
                              items: _currencyList.map((CurrencyNameDAO model) {
                                return new DropdownMenuItem<CurrencyNameDAO>(
                                  child: new Text(model.code!,
                                      style: TextStyle(
                                          fontFamily: StyleView.FONT_TITLE)),
                                  value: model,
                                );
                              }).toList()),
                        )),
                  ),
                ],
              ),
            )
          ],
        ));
  }

  buildPaymentTermDropdown(String text) {
    return Container(
        child: Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 55,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(Language().getString(text, selectedLang),
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_15,
                            fontFamily: StyleView.FONT_TITLE))),
              )),
        ),
        Expanded(
          flex: 2,
          child: Container(
              height: 55.0,
              color: Colors.white,
              padding: EdgeInsets.only(left: 5, right: 5),
              child: DropdownButton<PaymentTermsDAO>(
                  onTap: () {
                    return CommonMethods.hideKeyboard(context);
                  },
                  value: paymentTermDropdown,
                  isExpanded: true,
                  hint: Text(
                      Language().getString(
                          Constants.PLEASE_SELECT_PAYMENT_TERMS, selectedLang),
                      style: TextStyle(fontFamily: StyleView.FONT_TITLE)),
                  underline: SizedBox(),
                  onChanged: (PaymentTermsDAO? data) {
                    setState(() {
                      paymentTermDropdown = data;
                    });
                  },
                  items: paymentTermsList.map((PaymentTermsDAO model) {
                    return new DropdownMenuItem<PaymentTermsDAO>(
                      child: Container(
                        child: new Text(model.paymentTerm!,
                            style: TextStyle(fontFamily: StyleView.FONT_TITLE)),
                      ),
                      value: model,
                    );
                  }).toList())),
        )
      ],
    ));
  }

  splitDropDownText(String dropDownValue) {
    List splitedText = dropDownValue.split(".");
    return Container(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            child: Text(
              splitedText[0],
              style: TextStyle(
                color: Color(Constants.APP_COLOR),
              ),
            ),
          ),
          Container(
            child: Text(splitedText[1],
                style: TextStyle(
                  color: Colors.grey,
                  fontSize: 12.0,
                )),
          ),
        ],
      ),
    );
  }

  buildPenaltyPercentageDropdown(String title) {
    return Container(
      child: Row(children: <Widget>[
        Expanded(
          // flex: 1,
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      Language().getString(title, selectedLang),
                      style: TextStyle(
                          fontSize: StyleView.FONT_SIZE_15,
                          fontFamily: StyleView.FONT_TITLE,
                          color: Colors.black),
                    )),
              )),
        ),
        Expanded(
            flex: 1,
            child: Container(
                height: 50,
                color: Colors.white,
                margin: EdgeInsets.only(
                  right: 1.0,
                ),
                padding: EdgeInsets.only(left: 3),
                child: DropdownButton<PenaltyAmountDAO>(
                    onTap: () {
                      return CommonMethods.hideKeyboard(context);
                    },
                    value: penaltyAmountDropdown,
                    hint: new Text(
                        Language().getString(Constants.REASON, selectedLang)),
                    isExpanded: true,
                    underline: SizedBox(),
                    onChanged: (PenaltyAmountDAO? data) {
                      setState(() {
                        penaltyAmountDropdown = data;
                      });
                    },
                    items: penaltyAmountList.map((PenaltyAmountDAO model) {
                      return new DropdownMenuItem<PenaltyAmountDAO>(
                        child: new Text(model.reason!),
                        value: model,
                      );
                    }).toList()))),
        Expanded(
            flex: 1,
            child: Container(
                height: 50,
                color: Colors.white,
                margin: EdgeInsets.only(
                  left: 1.0,
                ),
                padding: EdgeInsets.only(left: 3),
                child: DropdownButton<String>(
                    onTap: () {
                      return CommonMethods.hideKeyboard(context);
                    },
                    value: penaltyPercentage,
                    hint: new Text("%"),
                    isExpanded: true,
                    underline: SizedBox(),
                    onChanged: (String? data) {
                      setState(() {
                        penaltyPercentage = data;
                      });
                    },
                    items: Constants.PERCENTAGELIST.map((String model) {
                      return new DropdownMenuItem<String>(
                        child: new Text(model),
                        value: model,
                      );
                    }).toList()))),
      ]),
    );
  }

  serviceCallAddTerms() async {
    setState(() {
      isLoadingProgress = true;
    });
    List<String> penaltyAmountValue = [];
    String penaltyAmountType = "";

    if (penaltyPercentage != null) {
      penaltyAmountValue = penaltyPercentage!.split(" %");
      penaltyAmountType = "percentage";
    }

    List<String> advancePaymentValue = [];
    String advancePaymentType = "";

    if (advancePaymentPercentage != null) {
      advancePaymentValue = advancePaymentPercentage!.split(" %");
      advancePaymentType = "percentage";
    }
    Map data = {
      "payment_terms": {
        "invoice_currency_code":
            currencyDropdown != null ? currencyDropdown!.code : "",
        "invoice_payment_terms":
            paymentTermDropdown != null ? paymentTermDropdown!.paymentTerm : "",
        "term_code":
            paymentTermDropdown != null ? paymentTermDropdown!.termCode : "",
        "days": paymentTermDropdown != null ? paymentTermDropdown!.days : "",
        "penalty_amount": {
          "code":
              penaltyAmountDropdown != null ? penaltyAmountDropdown!.code : "",
          "reason": penaltyAmountDropdown != null
              ? penaltyAmountDropdown!.reason
              : "",
          "value": penaltyAmountValue.length > 0
              ? int.parse(penaltyAmountValue[0])
              : null,
          "type": penaltyAmountType,
        },
        "comments": _commentController.text,
        "advance_payment": {
          "active": _radioValue == Constants.YES_STRING ? true : false,
          "value": advancePaymentValue.length > 0
              ? int.parse(advancePaymentValue[0])
              : null,
          "type": advancePaymentType
        },
        "terms": [],
        "invoice_currency_symbol":
            currencyDropdown != null ? currencyDropdown!.htmlSymbol : "",
      },
      "id": widget.connectionId,
      "buId": AppController.instance.getMyBuId
    };
    String body = json.encode(data);

    var response = await _invitationService
        .updateTermsInConnection_grpc(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      // var resObj = json.decode(_grpcResponse.message);
      return showDialog(
        barrierDismissible: false,
        context: context,
        builder: (context) => AlertDialog(
          title: Text(Language().getString(Constants.SUCCESS, selectedLang)),
          content: Container(
              child: RichText(
            text: TextSpan(
              children: <TextSpan>[
                TextSpan(
                    text: Language().getString(
                            Constants.SUCCESSFULLY_ADDED_TERMS_CONDITINS,
                            selectedLang) +
                        " : ",
                    style: TextStyle(
                        fontFamily: StyleView.FONT_TITLE,
                        color: Color(
                          Constants.APP_COLOR,
                        ))),
                TextSpan(
                    text: widget.connectionName,
                    style: TextStyle(
                      fontFamily: StyleView.FONT_TITLE,
                      color: Colors.blue,
                      fontSize: 16.0,
                    )),
              ],
            ),
          )),
          actions: [
            TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                  Navigator.pop(context);
                },
                child: Text(
                  Language().getString(Constants.OKAY_STR, selectedLang),
                  style: TextStyle(
                      fontSize: 15.0, color: Color(Constants.APP_COLOR)),
                ))
          ],
        ),
      );
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  Future<List<CurrencyNameDAO>> getCurrency() async {
    setState(() {
      isLoadingProgress = true;
    });

    http.Response response = await _service
        .getDropDownType("lookup/currency")
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<CurrencyNameDAO> list = [];
    setState(() {
      isLoadingProgress = false;
    });
    if (response.statusCode == 200) {
      var data = json.decode(response.body);
      for (var objects in data["data"])
        list.add(CurrencyNameDAO.fromJson(objects));
    }
    return list;
  }

  buildTextField(String _text) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 16.0),
      child: Row(
        children: <Widget>[
          Align(
              child: Text(Language().getString(_text, selectedLang),
                  style: TextStyle(
                      fontFamily: StyleView.FONT_TITLE,
                      fontWeight: FontWeight.bold,
                      fontSize: StyleView.FONT_SIZE_15)))
        ],
      ),
    );
  }

  buildCommentFieldView(TextEditingController _controller) {
    return Container(
        padding: EdgeInsets.only(left: 5),
        child: TextFormField(
          controller: _controller,
          maxLines: 7,
          textInputAction: TextInputAction.done,
          decoration: InputDecoration(
              border: OutlineInputBorder(),
              hintText: Language().getString(Constants.COMMENT, selectedLang)),
        ));
  }

  Future<List<BusinessUnitModel>> getBuData() async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = Constants.GETTING_DATA;
    });
    String body = json.encode({"id": AppController.instance.getMyBuId});

    var response = await _organizationService
        .getOrganizationDataById(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<BusinessUnitModel> _list = [];

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var object = json.decode(_grpcResponse.message!);
      _list.add(BusinessUnitModel.fromJson(object[0]));
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
      return _list;
  }

  Future<List<TermsAndConditionsDAO>> getConnectionDetails() async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = Constants.GETTING_DATA;
    });
    String body = json.encode(
        {"buId": AppController.instance.getMyBuId, "id": widget.connectionId});

    var response = await _invitationService.findConnectionDetailsById_grpc(
        body: body, token: AppController.instance.getAuthorizationKey);
    List<TermsAndConditionsDAO> list = [];
    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;

    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(resObj)) {
        for (var element in resObj) {
          list.add(TermsAndConditionsDAO.fromJson(element));
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
      return list;
  }

  appendPaymentTermsData(var termsData) {
    setState(() {
      if (_currencyList.length > 0) {
        for (int i = 0; i < _currencyList.length; i++) {
          if (termsData.invoicecurrencycode == _currencyList[i].code) {
            currencyDropdown = _currencyList[i];
          }
        }
      }
      if (termsData.invoicePaymentTerms != null) {
        for (int i = 0; i < paymentTermsList.length; i++) {
          if (termsData.invoicePaymentTerms ==
              paymentTermsList[i].paymentTerm) {
            paymentTermDropdown = paymentTermsList[i];
          }
        }
      }

      if (termsData.penaltyAmount != null) {
        for (int i = 0; i < penaltyAmountList.length; i++) {
          if (termsData.penaltyAmount.reason == penaltyAmountList[i].reason) {
            penaltyAmountDropdown = penaltyAmountList[i];
          }
        }

        if (termsData.penaltyAmount.value != null) {
          penaltyPercentage = "${termsData.penaltyAmount.value} %";
        }
      }
      if (termsData.advancePayment != null) {
        _radioValue = termsData.advancePayment.isActive
            ? Constants.YES_STRING
            : Constants.NO_STRING;
        if (_radioValue == Constants.YES_STRING &&
            termsData.advancePayment.value != null) {
          isPaymentVisible = true;
          advancePaymentPercentage = "${termsData.advancePayment.value} %";
        }
      }
      _commentController.text = termsData.comment;
    });
  }

  Future<List<PaymentTermsDAO>> getPaymentTerms() async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = Constants.GETTING_TERMS;
      AppController.instance.setCreateBuProgress = true;
    });

    http.Response response =
        await _service.getPaymentTerms().catchError((onError) {
      setState(() {
        isLoadingProgress = false;
        AppController.instance.setCreateBuProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    setState(() {
      isLoadingProgress = false;
      AppController.instance.setCreateBuProgress = false;
    });
    List<PaymentTermsDAO> _list = [];
    if (response.statusCode == 200) {
      var data = json.decode(response.body);
      for (var objects in data['data']) {
        _list.add(PaymentTermsDAO.fromJson(objects));
      }
    } else if (response.statusCode == 401) {
      return CommonMethods.handleUnauthorizedAccess(context);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          "${response.body}",
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }

    return _list;
  }

  Future<List<PenaltyAmountDAO>> getPenaltyAmountList() async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = Constants.GETTING_PENALTY_LIST;
      AppController.instance.setCreateBuProgress = true;
    });

    http.Response response =
        await _service.getPenaltyList().catchError((onError) {
      setState(() {
        isLoadingProgress = false;
        AppController.instance.setCreateBuProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    setState(() {
      isLoadingProgress = false;
      AppController.instance.setCreateBuProgress = false;
    });
    List<PenaltyAmountDAO> _list = [];
    if (response.statusCode == 200) {
      var data = json.decode(response.body);
      for (var objects in data['data']) {
        _list.add(PenaltyAmountDAO.fromJson(objects));
      }
    } else if (response.statusCode == 401) {
      return CommonMethods.handleUnauthorizedAccess(context);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          "${response.body}",
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }

    return _list;
  }
}
