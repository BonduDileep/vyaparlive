import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/TextView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/BusinessUnitModel.dart';
import 'package:vyaparlive/model/DirectorData.dart';
import 'package:vyaparlive/model/ExportsModel.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/Organization/PaymentDetailsPage.dart';
import 'package:vyaparlive/model/RegulationData.dart';
import 'package:vyaparlive/model/StockDetailsModel.dart';
import 'package:vyaparlive/model/TaxSchemeData.dart';
import 'dart:convert';

import 'package:vyaparlive/service/organization_service.dart';

class ConnectionsBuDetailsPage extends StatefulWidget {
  final String? buName;
  final String? buId;
  final String? connectionId;
  final bool isFromBuList;
  ConnectionsBuDetailsPage(
      {this.buName, this.buId, this.connectionId, this.isFromBuList = false});
  @override
  _ConnectionsBuDetailsPageState createState() =>
      _ConnectionsBuDetailsPageState();
}

class _ConnectionsBuDetailsPageState extends State<ConnectionsBuDetailsPage> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  List<BusinessUnitModel> _buDetailsList = [];
  bool isLoading = false;
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  late OrganizationService _organizationService;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  String advancePaymentValue = "";
  List<StockDetailsModel> _stockDiapatchLocations = [];
  List<StockDetailsModel> _stockReceiveLocations = [];
  List<DirectorsData> _directorsList = [];
  List<TaxSchemeData> _taxSchemeList = [];
  List<RegulationData> _regulationDataList = [];
  List<ExportsModel> _exportsData = [];
  List<ExportsModel> _importsData = [];
  List<BankDetails> _bankDetailsData = [];
  String? contactPerson = "";
  String? contactNumber = "";
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _organizationService = OrganizationService();

    this.loadConnectionDetails();
  }

  loadConnectionDetails() async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
      });
      getBuDetails().then((value) {
        if (value.length > 0) {
          setState(() {
            _buDetailsList.addAll(value);
            if (_buDetailsList[0].paymentTerms != null &&
                _buDetailsList[0].paymentTerms!.advancePayment != null &&
                _buDetailsList[0].paymentTerms!.advancePayment!.isActive!) {
              advancePaymentValue = _buDetailsList[0]
                          .paymentTerms!
                          .advancePayment!
                          .value !=
                      null
                  ? "${_buDetailsList[0].paymentTerms!.advancePayment!.value} %"
                  : "";
            } else {
              advancePaymentValue = _buDetailsList[0]
                          .paymentTerms!
                          .advancePayment !=
                      null
                  ? "${_buDetailsList[0].paymentTerms!.advancePayment!.value != null ? _buDetailsList[0].paymentTerms!.advancePayment!.value : ""}"
                  : '';
            }
            for (int i = 0; i < _buDetailsList[0].locationsList!.length; i++) {
              if (_buDetailsList[0].locationsList![i].locationType ==
                      Constants.KEY_MAIN_OFFICE ||
                  _buDetailsList[0].locationsList![i].locationName ==
                      "Main Office") {
                contactPerson =
                    _buDetailsList[0].locationsList![i].contactPerson;
                contactNumber =
                    _buDetailsList[0].locationsList![i].contactNumber;
              }
            }
            if (widget.isFromBuList) {
              this.updateStockDispatchLocationData();
              this.updateStockReceiveLocationData();
              this.updateDirectorsData();
              this.updateTaxSchemeData();
              this.updateRegulationData();
              this.updateExportsAndImportsData();
              this.updateBankDetails();
            }
          });
        }
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<BusinessUnitModel>> getBuDetails() async {
    _buDetailsList.clear();
    setState(() {
      isLoadingProgress = true;
    });
    String body = json.encode({"id": widget.buId});
    var response = await _organizationService
        .getOrganizationDataById(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    List<BusinessUnitModel> _list = [];

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(resObj)) {
        _list.add(BusinessUnitModel.fromJson(resObj[0]));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
      return _list;
  }

  buildCommentFieldView(String value) {
    return Container(
        width: MediaQuery.of(context).size.width,
        margin: EdgeInsets.symmetric(
          vertical: 5.0,
        ),
        decoration: BoxDecoration(
          border: Border.all(
            color: Colors.grey,
          ),
          borderRadius: BorderRadius.circular(5.0),
          color: Colors.white70,
        ),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(value),
        ));
  }

  buildTextField(String? _text) {
    return Container(
      margin: EdgeInsets.symmetric(
        vertical: 5.0,
      ),
      child: Row(
        children: <Widget>[
          Align(
              child: Text(Language().getString(_text, selectedLang),
                  style: TextStyle(
                      fontWeight: StyleView.fontSemiBold,
                      color: Color(Constants.APP_COLOR),
                      fontSize: StyleView.FONT_SIZE_15)))
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
        body: Stack(
      children: [
        SafeArea(
          child: Scaffold(
              key: _scaffoldkey,
              backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
              appBar: AppBar(
                elevation: 0,
                iconTheme: IconThemeData(color: theme.colorScheme.primary),
                backgroundColor: Colors.transparent,
                centerTitle: true,
                title: AppbarName(
                    title:
                        Language().getString(Constants.BU_DETAILS, selectedLang),
                    buName: "${widget.buName}"),
                actions: [
                  AppUtills.homeButton(context),
                ],
              ),
              body: (_buDetailsList.length == 0)
                  ? Center(
                      child: Text(Language()
                          .getString(Constants.NO_DATA_FOUND, selectedLang)),
                    )
                  : SingleChildScrollView(
                      child: Container(
                        margin: EdgeInsets.all(10.0),
                        child: Column(
                          children: <Widget>[
                            // this.buildTextField(Constants.BUSINESS_DETAILS),
                            this.showBusinessDetails(),
                            // this.buildTextField(Constants.CONTACT_DETAILS_STRING),
                            if (_buDetailsList[0].contactDetails != null &&
                                _buDetailsList[0].contactDetails!.address != null)
                              this.showContactDetails(),
                            if (_stockDiapatchLocations.length > 0 &&
                                widget.isFromBuList)
                              this.showStockLocations(
                                  Constants.STOCK_DISPATCH_LOCATIONS,
                                  _stockDiapatchLocations),
                            if (_stockReceiveLocations.length > 0 &&
                                widget.isFromBuList)
                              this.showStockLocations(
                                  Constants.STOCK_RECIVERS_LOCATIONS,
                                  _stockReceiveLocations),
                            if (_buDetailsList[0].registration != null &&
                                widget.isFromBuList)
                              this.showRegistrationDetails(),
                            if (_directorsList.length > 0 && widget.isFromBuList)
                              this.showDirectorsData(
                                  Constants.DIRECTORS_NAME_STRING,
                                  _directorsList),
                            if (_taxSchemeList.length > 0 && widget.isFromBuList)
                              this.showTaxSchemeData(
                                  Constants.TAX_SCHEME_STRING, _taxSchemeList),
                            if (_regulationDataList.length > 0 &&
                                widget.isFromBuList)
                              this.showRegulationData(
                                  Constants.REGULATION_ID, _regulationDataList),
                            if (_exportsData.length > 0 && widget.isFromBuList)
                              this.showExportsData(
                                  Constants.EXPORTS, _exportsData),
                            if (_importsData.length > 0 && widget.isFromBuList)
                              this.showExportsData(
                                  Constants.IMPORTS, _importsData),
                            if (_bankDetailsData.length > 0 &&
                                widget.isFromBuList)
                              this.showBankDetailsData(
                                  Constants.BANK_DETAILS, _bankDetailsData),
                            if (_buDetailsList[0].paymentTerms != null)
                              this.showPaymentDetails(),
                            if (_buDetailsList[0].paymentTerms != null)
                              Visibility(
                                  visible: _buDetailsList[0]
                                          .paymentTerms!
                                          .comment!
                                          .isNotEmpty
                                      ? true
                                      : false,
                                  child: Column(children: [
                                    buildTextField(Constants.CUSTOME_REMARKS),
                                    buildCommentFieldView(
                                        _buDetailsList[0].paymentTerms!.comment!),
                                  ]))
                          ],
                        ),
                      ),
                    )),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    ));
  }

  buildText(String title, String subTitle) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(title,
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_15,
                            fontFamily: StyleView.FONT_TITLE))),
              )),
        ),
        Expanded(
          flex: 2,
          child: Container(
              color: Colors.white70,
              height: 50,
              padding: EdgeInsets.only(left: 5),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  subTitle,
                  style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                ),
              )),
        )
      ],
    );
  }

  buildRichText(String text, String value) {
    return RichText(
      text: TextSpan(
        children: [
          TextSpan(
            text: text,
            style: TextStyle(
              fontSize: 17.0,
              color: Colors.black,
              fontFamily: StyleView.FONT_TITLE,
            ),
          ),
          TextSpan(
            text: " : " + value,
            style: TextStyle(
              color: Colors.black,
              fontSize: 16.0,
              fontFamily: StyleView.FONT_TITLE,
            ),
          )
        ],
      ),
    );
  }

  buildPenaltyPercentageDropdown(
      String title, String reason, String percentage) {
    return Container(
      child: Row(children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      title,
                      style: TextStyle(
                          fontSize: StyleView.FONT_SIZE_15,
                          fontFamily: StyleView.FONT_TITLE,
                          color: Colors.black),
                    )),
              )),
        ),
        Expanded(
            child: Container(
                height: 50,
                color: Colors.white,
                child: Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: Center(child: Text(reason)),
                ))),
        Expanded(
            child: Container(
                height: 50,
                color: Colors.white,
                child: Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: Center(child: Text(percentage)),
                ))),
      ]),
    );
  }

  showBusinessDetails() {
    return Container(
      decoration: BoxDecoration(
          border: Border.all(color: Colors.grey),
          borderRadius: BorderRadius.circular(5)),
      child: ExpansionTile(
        title: Text(
            Language().getString(Constants.BASIC_DETAILS_STRING, selectedLang),
            style: TextStyle(
                color: Color(Constants.APP_COLOR),
                fontSize: 14,
                fontWeight: StyleView.fontSemiBold)),
        children: [
          SizedBox(
            height: 1,
            child: new Container(color: Color(Constants.GREY_COLOR)),
          ),
          TextView(
            title: Language()
                .getString(Constants.BUSINESS_NAME_TITLE_STRING, selectedLang),
            value: _buDetailsList[0].businessName,
          ),
          SizedBox(
            height: 1,
            child: new Container(color: Color(Constants.GREY_COLOR)),
          ),
          TextView(
            title: Language().getString(Constants.CONTACT_NUMBER, selectedLang),
            value: _buDetailsList[0].dialCode! +
                " " +
                _buDetailsList[0].buContactNumber!,
          ),
          SizedBox(
            height: 1,
            child: new Container(color: Color(Constants.GREY_COLOR)),
          ),
          TextView(
              title: Language().getString(
                  Constants.STR_OWNER, selectedLang),
              value: _buDetailsList[0].businessHob),
          SizedBox(
            height: 1,
            child: new Container(color: Color(Constants.GREY_COLOR)),
          ),
          TextView(
              title:
                  Language().getString(Constants.WEBSITE_STRING, selectedLang),
              value: _buDetailsList[0].website),
          SizedBox(
            height: 1,
            child: new Container(color: Color(Constants.GREY_COLOR)),
          ),
          TextView(
              title:
                  Language().getString(Constants.BUSINESS_TYPE, selectedLang),
              value: _buDetailsList[0].type),
          SizedBox(
            height: 1,
            child: new Container(color: Color(Constants.GREY_COLOR)),
          ),
          TextView(
              title: Language()
                  .getString(Constants.COUNTRY_CODE_STRING, selectedLang),
              value: _buDetailsList[0].countryCode),
          SizedBox(
            height: 1,
            child: new Container(color: Color(Constants.GREY_COLOR)),
          ),
          TextView(
            title: Language()
                .getString(Constants.CURRENCY_CODE_STRING, selectedLang),
            value: _buDetailsList[0].currencyCode,
          ),
          SizedBox(
            height: 1,
            child: new Container(color: Color(Constants.GREY_COLOR)),
          ),
          TextView(
            title: Language().getString(Constants.GST_NO, selectedLang),
            value: _buDetailsList[0].orgGstNumber,
          ),
        ],
      ),
    );
  }

  showContactDetails() {
    return Container(
        decoration: BoxDecoration(
            border: Border.all(color: Colors.grey),
            borderRadius: BorderRadius.circular(5)),
        margin: EdgeInsets.only(top: 10.0),
        child: ExpansionTile(
            title: Text(
                Language()
                    .getString(Constants.CONTACT_DETAILS_STRING, selectedLang),
                style: TextStyle(color: Color(Constants.APP_COLOR))),
            children: <Widget>[
              SizedBox(
                height: 1,
                child: new Container(color: Color(Constants.GREY_COLOR)),
              ),
              TextView(
                title: Language()
                    .getString(Constants.CONTACT_PERSON, selectedLang),
                value: contactPerson,
              ),
              SizedBox(
                height: 1,
                child: new Container(color: Color(Constants.GREY_COLOR)),
              ),
              TextView(
                title: Language()
                    .getString(Constants.CONTACT_NUMBER, selectedLang),
                value: contactNumber,
              ),
              SizedBox(
                  height: 1,
                  child: new Container(color: Color(Constants.GREY_COLOR))),
              TextView(
                title: Language().getString(Constants.PLOT_NO, selectedLang),
                value: _buDetailsList[0].contactDetails!.address!.addressformat,
              ),
              SizedBox(
                height: 1,
                child: new Container(color: Color(Constants.GREY_COLOR)),
              ),
              TextView(
                title: Language().getString(
                    Constants.BUILDING_HOUSE_NUMBER_STRING, selectedLang),
                value: _buDetailsList[0]
                    .contactDetails!
                    .address!
                    .buildinghousenumber,
              ),
              SizedBox(
                height: 1,
                child: new Container(color: Color(Constants.GREY_COLOR)),
              ),
              TextView(
                title: Language().getString(Constants.BULIDING, selectedLang),
                value: _buDetailsList[0].contactDetails!.address!.buildingNo,
              ),
              SizedBox(
                height: 1,
                child: new Container(color: Color(Constants.GREY_COLOR)),
              ),
              TextView(
                title: Language().getString(
                    Constants.BUILDING_STREET_NAME_STRING, selectedLang),
                value: _buDetailsList[0]
                    .contactDetails!
                    .address!
                    .buildingstreetname,
              ),
              SizedBox(
                height: 1,
                child: new Container(color: Color(Constants.GREY_COLOR)),
              ),
              TextView(
                  title: Language().getString(
                      Constants.COLONY_SELECTOR_AREA_LOCALITY_STRING,
                      selectedLang),
                  value: _buDetailsList[0]
                      .contactDetails!
                      .address!
                      .colonysectorArealocality),
              SizedBox(
                height: 1,
                child: new Container(color: Color(Constants.GREY_COLOR)),
              ),
              TextView(
                title: Language()
                    .getString(Constants.LAND_MARK_STRING, selectedLang),
                value: _buDetailsList[0].contactDetails!.address!.landmark,
              ),
              SizedBox(
                height: 1,
                child: new Container(color: Color(Constants.GREY_COLOR)),
              ),
              TextView(
                title: Language()
                    .getString(Constants.COUNTRY_NAME_STRING, selectedLang),
                value:
                    _buDetailsList[0].contactDetails!.address!.country != null
                        ? _buDetailsList[0].contactDetails!.address!.country
                        : "",
              ),
              SizedBox(
                height: 1,
                child: new Container(color: Color(Constants.GREY_COLOR)),
              ),
              TextView(
                title: Language()
                    .getString(Constants.STATE_NAME_STRING, selectedLang),
                value: _buDetailsList[0].contactDetails!.address!.state != null
                    ? _buDetailsList[0].contactDetails!.address!.state
                    : "",
              ),
              SizedBox(
                height: 1,
                child: new Container(color: Color(Constants.GREY_COLOR)),
              ),
              TextView(
                title: Language()
                    .getString(Constants.DISTRICT_STRING, selectedLang),
                value:
                    _buDetailsList[0].contactDetails!.address!.district != null
                        ? _buDetailsList[0].contactDetails!.address!.district
                        : "",
              ),
              SizedBox(
                height: 1,
                child: new Container(color: Color(Constants.GREY_COLOR)),
              ),
              TextView(
                title: Language()
                    .getString(Constants.CITY_NAME_STRING, selectedLang),
                value: _buDetailsList[0]
                            .contactDetails!
                            .address!
                            .villagetowncity !=
                        null
                    ? _buDetailsList[0].contactDetails!.address!.villagetowncity
                    : "",
              ),
              SizedBox(
                height: 1,
                child: new Container(color: Color(Constants.GREY_COLOR)),
              ),
              TextView(
                title: Language().getString(Constants.PIN_CODE, selectedLang),
                value: _buDetailsList[0].contactDetails!.address!.postcode,
              ),
            ]));
  }

  showPaymentDetails() {
    return Column(
      children: [
        // this.buildTextField(Constants.PAYMENT_TERMS_STRING),
        Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(5.0),
            border: Border.all(
              color: Colors.grey,
            ),
          ),
          margin: EdgeInsets.only(top: 10.0),
          child: ExpansionTile(
            title: Text(
                Language()
                    .getString(Constants.PAYMENT_TERMS_STRING, selectedLang),
                style: TextStyle(color: Color(Constants.APP_COLOR))),
            children: [
              SizedBox(
                height: 1,
                child: new Container(color: Color(Constants.GREY_COLOR)),
              ),
              TextView(
                title: Language().getString(
                    Constants.INVOICE_CURRENCY_CODE_STRING, selectedLang),
                value: _buDetailsList[0].paymentTerms != null &&
                        _buDetailsList[0].paymentTerms!.invoicecurrencycode !=
                            null
                    ? _buDetailsList[0].paymentTerms!.invoicecurrencycode
                    : "",
              ),
              SizedBox(
                height: 1,
                child: new Container(color: Color(Constants.GREY_COLOR)),
              ),
              if (_buDetailsList[0].paymentTerms!.invoicePaymentTerms != null)
                TextView(
                    title: Language().getString(
                        Constants.INVOICE_PAYMENT_TERMS, selectedLang),
                    value:
                        "${_buDetailsList[0].paymentTerms!.invoicePaymentTerms}"),
              Visibility(
                  visible:
                      (_buDetailsList[0].paymentTerms!.penaltyAmount != null
                          ? true
                          : false),
                  child: Column(children: [
                    SizedBox(
                      height: 1,
                      child: new Container(color: Color(Constants.GREY_COLOR)),
                    ),
                    TextView(
                      title:
                          Language().getString("Payment Terms", selectedLang),
                      value:
                          "${_buDetailsList[0].paymentTerms!.penaltyAmount!.reason}",
                    ),
                  ])),
              Visibility(
                  visible:
                      (_buDetailsList[0].paymentTerms!.penaltyAmount != null
                          ? true
                          : false),
                  child: Column(children: [
                    SizedBox(
                      height: 1,
                      child: new Container(color: Color(Constants.GREY_COLOR)),
                    ),
                    TextView(
                      title: Language()
                          .getString(Constants.PENALTY_REASON, selectedLang),
                      value:
                          "${_buDetailsList[0].paymentTerms!.penaltyAmount!.value} %",
                    ),
                  ])),
              SizedBox(
                height: 1,
                child: new Container(color: Color(Constants.GREY_COLOR)),
              ),
              TextView(
                title: Language()
                    .getString(Constants.ADVANCE_PAYMENT, selectedLang),
                value: "$advancePaymentValue",
              )
            ],
          ),
        ),
      ],
    );
  }

  showStockLocations(String title, List<StockDetailsModel> stockList) {
    return Column(
      children: <Widget>[
        // buildTextField(Language().getString(title, selectedLang)),
        for (int i = 0; i < stockList.length; i++)
          Column(
            children: <Widget>[
              Container(
                  decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey),
                      borderRadius: BorderRadius.circular(5)),
                  margin: EdgeInsets.symmetric(vertical: 5.0),
                  child: ExpansionTile(
                    title: Text(
                        Language().getString(
                            stockList[i].stockLocationName, selectedLang),
                        style: TextStyle(color: Color(Constants.APP_COLOR))),
                    children: <Widget>[
                      Container(
                          child: Column(
                        children: <Widget>[
                          SizedBox(
                              height: 1,
                              child: new Container(
                                  color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language().getString(
                                  Constants.LOCATION_PHONE_NUMBER,
                                  selectedLang),
                              value: stockList[i].stockLocationNumber),
                          SizedBox(
                              height: 1,
                              child: Container(
                                  color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language().getString(
                                  Constants.LOCATION_NAME, selectedLang),
                              value: stockList[i].stockLocationName),
                          SizedBox(
                              height: 1,
                              child: Container(
                                  color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language()
                                  .getString(Constants.PLOT_NO, selectedLang),
                              value: stockList[i].plotNo),
                          SizedBox(
                              height: 1,
                              child: Container(
                                  color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language()
                                  .getString(Constants.BULIDING, selectedLang),
                              value: stockList[i].buildingNo),
                          SizedBox(
                              height: 1,
                              child: Container(
                                  color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language().getString(
                                  Constants.BUILDING_HOUSE_NUMBER_STRING,
                                  selectedLang),
                              value: stockList[i].houseNo),
                          SizedBox(
                              height: 1,
                              child: Container(
                                  color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language().getString(
                                  Constants.BUILDING_STREET_NAME_STRING,
                                  selectedLang),
                              value: stockList[i].streetName),
                          SizedBox(
                              height: 1,
                              child: Container(
                                  color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language().getString(
                                  Constants
                                      .COLONY_SELECTOR_AREA_LOCALITY_STRING,
                                  selectedLang),
                              value: stockList[i].locality),
                          SizedBox(
                              height: 1,
                              child: Container(
                                  color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language().getString(
                                  Constants.LAND_MARK_STRING, selectedLang),
                              value: stockList[i].landmark),
                          SizedBox(
                              height: 1,
                              child: Container(
                                  color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language().getString(
                                  Constants.COUNTRY_NAME_STRING, selectedLang),
                              value: "${stockList[i].country}"),
                          SizedBox(
                              height: 1,
                              child: Container(
                                  color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language().getString(
                                  Constants.STATE_NAME_STRING, selectedLang),
                              value: "${stockList[i].state}"),
                          SizedBox(
                              height: 1,
                              child: Container(
                                  color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language().getString(
                                  Constants.DISTRICT_STRING, selectedLang),
                              value: "${stockList[i].district}"),
                          SizedBox(
                              height: 1,
                              child: Container(
                                  color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language().getString(
                                  Constants.CITY_NAME_STRING, selectedLang),
                              value: stockList[i].city),
                          SizedBox(
                              height: 1,
                              child: Container(
                                  color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language()
                                  .getString(Constants.PIN_CODE, selectedLang),
                              value: stockList[i].postalCode),
                        ],
                      ))
                    ],
                  )),
            ],
          )
      ],
    );
  }

  updateStockDispatchLocationData() {
    for (int i = 0; i < _buDetailsList[0].locationsList!.length; i++) {
      if (_buDetailsList[0].locationsList![i].locationType ==
          Constants.KEY_STOCK_DISPATCH) {
        _stockDiapatchLocations.add(StockDetailsModel(
          stockLocationNumber:
              _buDetailsList[0].locationsList![i].contactNumber,
          stockLocationName: _buDetailsList[0].locationsList![i].locationName,
          buildingNo:
              _buDetailsList[0].locationsList![i].addressDetails!.buildingNo,
          houseNo: _buDetailsList[0]
              .locationsList![i]
              .addressDetails!
              .buildinghousenumber,
          streetName: _buDetailsList[0]
              .locationsList![i]
              .addressDetails!
              .buildingstreetname,
          locality: _buDetailsList[0]
              .locationsList![i]
              .addressDetails!
              .colonysectorArealocality,
          landmark:
              _buDetailsList[0].locationsList![i].addressDetails!.landmark,
          country: _buDetailsList[0].locationsList![i].addressDetails!.country,
          state: _buDetailsList[0].locationsList![i].addressDetails!.state,
          district:
              _buDetailsList[0].locationsList![i].addressDetails!.district,
          city: _buDetailsList[0]
              .locationsList![i]
              .addressDetails!
              .villagetowncity,
          plotNo: _buDetailsList[0].locationsList![i].addressDetails!.plotNo,
          postalCode:
              _buDetailsList[0].locationsList![i].addressDetails!.postcode,
          userName: _buDetailsList[0].locationsList![i].contactPerson,
        ));
      }
    }
  }

  updateStockReceiveLocationData() {
    for (int i = 0; i < _buDetailsList[0].locationsList!.length; i++) {
      if (_buDetailsList[0].locationsList![i].locationType ==
          Constants.KEY_STOCK_RECEIVE) {
        _stockReceiveLocations.add(StockDetailsModel(
          stockLocationNumber:
              _buDetailsList[0].locationsList![i].contactNumber,
          stockLocationName: _buDetailsList[0].locationsList![i].locationName,
          buildingNo:
              _buDetailsList[0].locationsList![i].addressDetails!.buildingNo,
          houseNo: _buDetailsList[0]
              .locationsList![i]
              .addressDetails!
              .buildinghousenumber,
          streetName: _buDetailsList[0]
              .locationsList![i]
              .addressDetails!
              .buildingstreetname,
          locality: _buDetailsList[0]
              .locationsList![i]
              .addressDetails!
              .colonysectorArealocality,
          landmark:
              _buDetailsList[0].locationsList![i].addressDetails!.landmark,
          country: _buDetailsList[0].locationsList![i].addressDetails!.country,
          state: _buDetailsList[0].locationsList![i].addressDetails!.state,
          district:
              _buDetailsList[0].locationsList![i].addressDetails!.district,
          city: _buDetailsList[0]
              .locationsList![i]
              .addressDetails!
              .villagetowncity,
          plotNo: _buDetailsList[0].locationsList![i].addressDetails!.plotNo,
          postalCode:
              _buDetailsList[0].locationsList![i].addressDetails!.postcode,
          userName: _buDetailsList[0].locationsList![i].contactPerson,
        ));
      }
    }
  }

  showRegistrationDetails() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(5.0),
        border: Border.all(
          color: Colors.grey,
        ),
      ),
      margin: EdgeInsets.only(top: 10.0),
      child: ExpansionTile(
        title: Text(
            Language()
                .getString(Constants.REGISTRATION_HEADER_STRING, selectedLang),
            style: TextStyle(color: Color(Constants.APP_COLOR))),
        children: [
          SizedBox(
            height: 1,
            child: new Container(color: Color(Constants.GREY_COLOR)),
          ),
          TextView(
            title: Language().getString(Constants.COMPANY_NAME, selectedLang),
            value: _buDetailsList[0].registration!.govtregisteredName,
          ),
          SizedBox(
            height: 1,
            child: new Container(color: Color(Constants.GREY_COLOR)),
          ),
          TextView(
              title: Language()
                  .getString(Constants.REGISTRATION_DATE_STRING, selectedLang),
              value: "${_buDetailsList[0].registration!.registrationDate}"),
          SizedBox(
            height: 1,
            child: new Container(color: Color(Constants.GREY_COLOR)),
          ),
          TextView(
            title: Language()
                .getString(Constants.REGISTRATION_COUNTRY_STRING, selectedLang),
            value: _buDetailsList[0].registration!.registrationCountry != null
                ? _buDetailsList[0].registration!.registrationCountry
                : "",
          ),
          SizedBox(
            height: 1,
            child: new Container(color: Color(Constants.GREY_COLOR)),
          ),
          TextView(
            title: Language()
                .getString(Constants.REGISTRATION_STATE_STRING, selectedLang),
            value: _buDetailsList[0].registration!.registrationState != null
                ? _buDetailsList[0].registration!.registrationState
                : "",
          ),
          SizedBox(
            height: 1,
            child: new Container(color: Color(Constants.GREY_COLOR)),
          ),
          TextView(
            title: Language()
                .getString(Constants.REGISTRATION_CITY_STRING, selectedLang),
            value: _buDetailsList[0].registration!.registrationCity != null
                ? _buDetailsList[0].registration!.registrationCity
                : "",
          ),
          SizedBox(
            height: 1,
            child: new Container(color: Color(Constants.GREY_COLOR)),
          ),
          TextView(
            title:
                Language().getString(Constants.LEGAL_ENTITY_TYPE, selectedLang),
            value:
                "${_buDetailsList[0].registration!.legalentityType != null ? _buDetailsList[0].registration!.legalentityType : ""}",
          )
        ],
      ),
    );
  }

  updateDirectorsData() {
    for (int i = 0; i < _buDetailsList[0].directors!.length; i++)
      _directorsList.add(DirectorsData(
          personName: _buDetailsList[0].directors![i].personName,
          personSchemeName:
              _buDetailsList[0].directors![i].personidentificationSchemename,
          personIdentificationNumber:
              _buDetailsList[0].directors![i].personidentificationNumber,
          digitalSignature: _buDetailsList[0].directors![i].digitalSignature));
  }

  showDirectorsData(String title, List<DirectorsData> directors) {
    return Column(
      children: <Widget>[
        buildTextField(Language().getString(title, selectedLang)),
        for (int i = 0; i < directors.length; i++)
          Column(
            children: <Widget>[
              Container(
                  decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey),
                      borderRadius: BorderRadius.circular(5)),
                  margin: EdgeInsets.symmetric(vertical: 5.0),
                  child: ExpansionTile(
                    title: Text(
                        Language()
                            .getString(directors[i].personName, selectedLang),
                        style: TextStyle(color: Color(Constants.APP_COLOR))),
                    children: <Widget>[
                      Container(
                          child: Column(
                        children: <Widget>[
                          SizedBox(
                              height: 1,
                              child: new Container(
                                  color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language().getString(
                                  Constants.IDENTIFICATION_SCHEME_STRING,
                                  selectedLang),
                              value: directors[i].personSchemeName),
                          SizedBox(
                              height: 1,
                              child: Container(
                                  color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language().getString(
                                  Constants.IDENTIFICATION_NUMBER_STRING,
                                  selectedLang),
                              value: directors[i].personIdentificationNumber),
                        ],
                      ))
                    ],
                  )),
            ],
          )
      ],
    );
  }

  showTaxSchemeData(String title, List<TaxSchemeData> taxSchemeList) {
    return Column(
      children: <Widget>[
        // buildTextField(Language().getString(title, selectedLang)),
        for (int i = 0; i < taxSchemeList.length; i++)
          Column(
            children: <Widget>[
              Container(
                  decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey),
                      borderRadius: BorderRadius.circular(5)),
                  margin: EdgeInsets.symmetric(vertical: 5.0),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      children: <Widget>[
                        this.buildRowTextView(Constants.TAX_ID,
                            taxSchemeList[i].govttaxscheme_name),
                        this.buildRowTextView(Constants.GOVT_TAX_NUMBER_STRING,
                            taxSchemeList[i].govttaxscheme_number)
                      ],
                    ),
                  )),
            ],
          )
      ],
    );
  }

  showRegulationData(String title, List<RegulationData> _regulationList) {
    return Column(
      children: <Widget>[
        // buildTextField(Language().getString(title, selectedLang)),
        for (int i = 0; i < _regulationList.length; i++)
          Column(
            children: <Widget>[
              Container(
                  decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey),
                      borderRadius: BorderRadius.circular(5)),
                  margin: EdgeInsets.symmetric(vertical: 5.0),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      children: <Widget>[
                        this.buildRowTextView(Constants.BUSINESS_SCHEME_NAME,
                            _regulationList[i].govtbusinessSchemeid),
                        this.buildRowTextView(Constants.REGULA_ID,
                            _regulationList[i].govtregistrationId)
                      ],
                    ),
                  )),
            ],
          )
      ],
    );
  }

  buildRowTextView(String title, String? value) {
    return Container(
        child: Padding(
      padding: const EdgeInsets.all(2.0),
      child: Row(
        children: [
          Expanded(
            child: Text(Language().getString(title, selectedLang),
                style: TextStyle(
                  color: Color(Constants.APP_COLOR),
                  fontWeight: FontWeight.bold,
                )),
          ),
          Text("  : "),
          Expanded(child: Text("$value", style: TextStyle(fontSize: 14.0)))
        ],
      ),
    ));
  }

  updateTaxSchemeData() {
    for (int i = 0; i < _buDetailsList[0].taxScheme!.length; i++)
      _taxSchemeList.add(TaxSchemeData(
          govttaxscheme_name: _buDetailsList[0].taxScheme![i].schemeName,
          govttaxscheme_number: _buDetailsList[0].taxScheme![i].schemeNumber,
          taxexemption_reason: _buDetailsList[0].taxScheme![i].reason));
  }

  updateRegulationData() {
    for (int i = 0; i < _buDetailsList[0].regulation!.length; i++)
      _regulationDataList.add(RegulationData(
          govtbusinessSchemeid:
              _buDetailsList[0].regulation![i].govtbusinessSchemeid,
          govtregistrationId:
              _buDetailsList[0].regulation![i].govtregistrationId));
  }

  updateExportsAndImportsData() {
    for (int i = 0; i < _buDetailsList[0].exports!.length; i++)
      _exportsData.add(ExportsModel(
          govtregistrationSchemeid:
              _buDetailsList[0].exports![i].govtregistrationSchemeid,
          govtregistrationSchemename:
              _buDetailsList[0].exports![i].govtregistrationSchemename));

    for (int i = 0; i < _buDetailsList[0].imports!.length; i++)
      _importsData.add(ExportsModel(
          govtregistrationSchemeid:
              _buDetailsList[0].imports![i].govtregistrationSchemeid,
          govtregistrationSchemename:
              _buDetailsList[0].imports![i].govtregistrationSchemename));
  }

  updateBankDetails() {
    for (int i = 0; i < _buDetailsList[0].bankDetailsReceives!.length; i++)
      _bankDetailsData.add(BankDetails(
          bankname: _buDetailsList[0].bankDetailsReceives![i].bankName,
          bankaccountname:
              _buDetailsList[0].bankDetailsReceives![i].bankAccountName,
          bankAccountNumber:
              _buDetailsList[0].bankDetailsReceives![i].bankAccountNumber,
          epayCode: _buDetailsList[0].bankDetailsReceives![i].ePayCode,
          swiftCode: _buDetailsList[0].bankDetailsReceives![i].swifTcode,
          micrCode: _buDetailsList[0].bankDetailsReceives![i].micrCode,
          ifscCode: _buDetailsList[0].bankDetailsReceives![i].ifscCode,
          isShowInvoiceView: _buDetailsList[0]
              .bankDetailsReceives![i]
              .isShowBankDataInInvoice));
  }

  showExportsData(String title, List<ExportsModel> exportsData) {
    return Column(
      children: <Widget>[
        // buildTextField(Language().getString(title, selectedLang)),
        for (int i = 0; i < exportsData.length; i++)
          Column(
            children: <Widget>[
              Container(
                  decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey),
                      borderRadius: BorderRadius.circular(5)),
                  margin: EdgeInsets.symmetric(vertical: 5.0),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      children: <Widget>[
                        this.buildRowTextView(Constants.REGISTRATION_NAME,
                            exportsData[i].govtregistrationSchemename),
                        this.buildRowTextView(Constants.REGISTRATION_ID,
                            exportsData[i].govtregistrationSchemeid)
                      ],
                    ),
                  )),
            ],
          )
      ],
    );
  }

  showBankDetailsData(String title, List<BankDetails> bankList) {
    return Column(
      children: <Widget>[
        buildTextField(Language().getString(title, selectedLang)),
        for (int i = 0; i < bankList.length; i++)
          Column(
            children: <Widget>[
              Container(
                  decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey),
                      borderRadius: BorderRadius.circular(5)),
                  margin: EdgeInsets.symmetric(vertical: 5.0),
                  child: ExpansionTile(
                    title: Text(
                        Language()
                            .getString(bankList[i].bankname, selectedLang),
                        style: TextStyle(color: Color(Constants.APP_COLOR))),
                    children: <Widget>[
                      Container(
                          child: Column(
                        children: <Widget>[
                          SizedBox(
                              height: 1,
                              child: new Container(
                                  color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language().getString(
                                  Constants.BANK_ACCOUNT_NAME, selectedLang),
                              value: bankList[i].bankaccountname),
                          SizedBox(
                              height: 1,
                              child: Container(
                                  color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language().getString(
                                  Constants.BANK_ACCOUNT_NUMBER, selectedLang),
                              value: bankList[i].bankAccountNumber),
                          SizedBox(
                              height: 1,
                              child: Container(
                                  color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language()
                                  .getString(Constants.EPAY, selectedLang),
                              value: bankList[i].epayCode),
                          SizedBox(
                              height: 1,
                              child: Container(
                                  color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language().getString(
                                  Constants.SWIFT_CODE, selectedLang),
                              value: bankList[i].swiftCode),
                          SizedBox(
                              height: 1,
                              child: Container(
                                  color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language()
                                  .getString(Constants.MICR_CODE, selectedLang),
                              value: bankList[i].micrCode),
                          SizedBox(
                              height: 1,
                              child: Container(
                                  color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language()
                                  .getString(Constants.IFSC_CODE, selectedLang),
                              value: bankList[i].ifscCode),
                          SizedBox(
                              height: 1,
                              child: Container(
                                  color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language().getString(
                                  Constants.SHOW_BANK_DETAILS_IN_INVOICE,
                                  selectedLang),
                              value: bankList[i].isShowInvoiceView!
                                  ? Constants.YES_STRING
                                  : Constants.NO_STRING),
                        ],
                      ))
                    ],
                  )),
            ],
          )
      ],
    );
  }
}
