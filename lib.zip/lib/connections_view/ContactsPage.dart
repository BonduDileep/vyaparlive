import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/MyDrawer.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/connections_view/ConnectionsPage.dart';
import 'package:vyaparlive/connections_view/InternalConnections.dart';

class ContactsView extends StatefulWidget {
  @override
  _ContactsViewState createState() => _ContactsViewState();
}

class _ContactsViewState extends State<ContactsView>
    with TickerProviderStateMixin {
  String? selectedLang = AppController.instance.getSelectedlanguage; // 'en';
  late SharedPreferences sharedPreferences;
  TabController? _tabController;
  bool isConnectionsview = true;
  bool isExternalConnectionsview = false;
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return AppBackgroundView(
      body: WillPopScope(
          child: SafeArea(
            child: Scaffold(
              backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
              appBar: AppBar(
                elevation: 0,
                iconTheme: IconThemeData(color: theme.colorScheme.primary),
                backgroundColor: Colors.transparent,
                title: AppbarName(
                  title: Language()
                      .getString(Constants.CONNECTIONS_STR, selectedLang),
                  buName: AppController.instance.getBuName,
                ),
                centerTitle: true,
                bottom: PreferredSize(
                  preferredSize: Size.fromHeight(screenSize.height * 0.09),
                  child: TabBar(
                      indicatorSize: TabBarIndicatorSize.tab,
                      controller: _tabController,
                      indicator: BoxDecoration(
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey,
                              blurRadius: 6.0,
                            ),
                            BoxShadow(color: Colors.white, offset: Offset(0, 9)),
                          ],
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(10),
                              topRight: Radius.circular(10)),
                          color: Colors.white),
                      onTap: (index) {
                        CommonMethods.hideKeyboard(context);
                      },
                      tabs: [
                        Tab(
                            child: Text(
                          Language()
                              .getString(Constants.STR_EXTERNAL, selectedLang),
                          style: TextStyle(color: theme.colorScheme.primary),
                        )),
                        Tab(
                            child: Text(
                                Language().getString(
                                    Constants.STR_INTERNAL, selectedLang),
                                style:
                                    TextStyle(color: theme.colorScheme.primary))),
                      ]),
                ),
                actions: [
                  AppUtills.homeButton(context),
                ],
              ),
              drawer: MyDrawer(),
              body: TabBarView(
                controller: _tabController,
                physics: NeverScrollableScrollPhysics(),
                children: [
                  // if(CommonMethods.isPrivillegeExist(context, PrivillegesActions.KEY_ONLINE_CONNECTIONS_EXTERNAL))
                  Container(child: ListOfContactsView()),
                  // if(CommonMethods.isPrivillegeExist(context, PrivillegesActions.KEY_ONLINE_CONNECTIONS_INTERNAL))
                  Container(child: InternalConnectionsPage()),
                ],
              ),
            ),
          ),
          onWillPop: () {
            return CommonMethods.onBackPress(context).then((value) => value);
          }),
    );
  }
}
