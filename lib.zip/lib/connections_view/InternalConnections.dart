import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/service/organization_service.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/animation/list_loader/ListLoader.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/config/Language.dart';

import 'package:vyaparlive/connections_view/PlaceConnectionOrder.dart';
import 'package:vyaparlive/Transaction/buyer/DiscussionView.dart';
import 'package:vyaparlive/Transaction/TransactionsPage.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';

import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';

import 'package:vyaparlive/connections_view/ConnectionsBuDetails.dart';
import 'package:vyaparlive/connections_view/connection_widgets/connection_card.dart';
import 'package:vyaparlive/model/BuBasicDataModel.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/service/Service.dart';
import 'package:vyaparlive/service/bu_list_grpc_service.dart';
import 'package:vyaparlive/utills/SharePref.dart';
import 'dart:convert';

class InternalConnectionsPage extends StatefulWidget {
  @override
  _InternalConnectionsPageState createState() =>
      _InternalConnectionsPageState();
}

class _InternalConnectionsPageState extends State<InternalConnectionsPage> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? userId = "";
  String? myBuId = "";
  String? myBuName = "";
  Service? _service;
  // ProgressDialog progressDialog;
  List<BuBasicDataModel> _buList = [];
  final _searchController = TextEditingController();
  BuBasicDataModel _buData = BuBasicDataModel();
  bool isLoading = false;
  bool isLoadingProgress = true;
  String progressMessage = Constants.GETTING_DATA;
  static String showLoaderText = Constants.NO_DATA_FOUND;
  late BuListGrpcService _transactionService;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  List<Map> _namesMapData = [];
  late OrganizationService _organizationService;
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    this.getLoadLanguage();
    theme = AppTheme.vyaparTheme;
    _transactionService = BuListGrpcService();
    _service = Service();
    _organizationService = new OrganizationService();
    myBuId = AppController.instance.getMyBuId;
    myBuName = AppController.instance.getBuName;
    SharePref().getUserId().then((value) {
      userId = value;
      loadBuData();
    });
  }

  getLoadLanguage() {
    _namesMapData = [
      {"name": Language().getString(Constants.OUR_SALES_TEAM, selectedLang)},
      {"name": Language().getString(Constants.PRODUCTS_STR, selectedLang)},
      {
        "name":
            Language().getString(Constants.START_ORDER_DISCUSSION, selectedLang)
      },
      {
        "name":
            Language().getString(Constants.TRANSACTION_HISTORY, selectedLang)
      },
      {"name": Language().getString(Constants.BU_DETAILS, selectedLang)},
      {"name": Language().getString(Constants.DIRECT_ORDER, selectedLang)},
      {"name": Language().getString(Constants.ASSIGN_TO_USER, selectedLang)},
    ];
  }

  loadBuData() async {
    // Future.delayed(Duration.zero).then((value) async {
    if (await NetworkStatus.getInternetStatus()) {
      getAllBuBusinessData(userId).then((value) {
        setState(() {
          if (value.length > 0) {
            _buList.clear();
            _buList.addAll(value);
          } else {
            showLoaderText = Constants.NO_DATA_FOUND;
          }
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
    // });
  }

  Widget _listViewData() {
    if (isLoadingProgress) {
      return Expanded(child: ListLoader());
    } else if (!isLoadingProgress && _buList.length == 0) {
      return Expanded(
          child: Center(
              child: Text(Language().getString(showLoaderText, selectedLang))));
    } else {
      return Expanded(
        child: AnimationLimiter(
          child: ListView.separated(
            physics: const BouncingScrollPhysics(
                parent: AlwaysScrollableScrollPhysics()),
            shrinkWrap: true,
            separatorBuilder: (context, index) => Divider(
              height: 0.0,
              color: Colors.transparent,
            ),
            itemBuilder: (BuildContext ctxt, int index) {
              return AnimationConfiguration.staggeredList(
                position: index,
                duration: Duration(milliseconds: 1200),
                child: SlideAnimation(
                  verticalOffset: 50.0,
                  child: FadeInAnimation(
                    child: new ConnectionCard(
                      true,
                      buBasicDataModel: _buList[index],
                      onProductsClick: () => {
                        CommonMethods.hideKeyboard(context),
                        Navigator.push(
                            context,
                            new MaterialPageRoute(
                                builder: (context) => PlaceConnectionOrderPage(
                                      buName: _buList[index].businessName,
                                      buId: _buList[index].id,
                                      isInternalConnection: true,
                                    ))).then((value) => {
                              // loadBuData()
                            })
                      },
                      onActivityClick: () {
                        CommonMethods.hideKeyboard(context);
                        AppController.instance.setBuData = _buList[index];
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => TransactionsView(
                                      isFromInternalConnection: true,
                                      isFromBuList: true,
                                      buId: _buList[index].id,
                                      buName: _buList[index].businessName,
                                    ))).then((value) => {
                              // loadBuData()
                            });
                      },
                      onStartDiscussionClick: () {
                        CommonMethods.hideKeyboard(context);
                        _buData = _buList[index];
                        showDiscussionChoiceDialog();
                      },
                      onBuDetailsClick: () {
                        CommonMethods.hideKeyboard(context);
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => ConnectionsBuDetailsPage(
                                    buName: _buList[index].businessName,
                                    buId: _buList[index].id))).then((value) => {
                              // loadBuData()
                            });
                      },
                      namesMapData: _namesMapData,
                    ),
                  ),
                ),
              );
            },
            itemCount: _buList.length,
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        SafeArea(
          child: Scaffold(
            key: _scaffoldkey,
            body: Container(
                color: Color(Constants.APP_BACKGROUND_COLOR),
                margin: EdgeInsets.only(left: 5),
                child: Card(
                  elevation: 20,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(10.0),
                          bottomLeft: Radius.circular(10.0))),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      children: <Widget>[
                        Container(
                          height: 60.0,
                          child: buildSearchBarView(),
                        ),
                        SizedBox(height: 5.0),
                        _listViewData()
                      ],
                    ),
                  ),
                )),
          ),
        ),
        // AppUtills.showLoadingView(
        //     context: context,
        //     message: Language().getString(progressMessage, selectedLang),
        //     isLoading: isLoadingProgress),
      ],
    );
  }

  showDiscussionChoiceDialog() {
    return showDialog(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(15.0)),
            ),
            title: Column(
              children: <Widget>[
                Align(
                  alignment: Alignment.topRight,
                  child: GestureDetector(
                    onTap: () {
                      Navigator.of(context).pop();
                    },
                    child: Icon(
                      Icons.close,
                      color: Colors.red,
                    ),
                  ),
                ),
                SizedBox(
                  height: 2.5,
                ),
              ],
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                GestureDetector(
                  onTap: () {},
                  child: ButtonTheme(
                    minWidth: MediaQuery.of(context).size.width,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: new BorderRadius.circular(30.0),
                        ),
                        backgroundColor: Color(0xFF083e64),
                        textStyle: TextStyle(color: Colors.white),
                        elevation: 3.0,
                      ),
                      onPressed: () => {
                        Navigator.of(context).pop(),
                        postBodyForProductsBuy(),
                      },
                      child: Padding(
                        padding: EdgeInsets.symmetric(vertical: 15),
                        child: Text(Language()
                            .getString(Constants.BUY_PRODUCTS, selectedLang)),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                GestureDetector(
                  onTap: () {},
                  child: ButtonTheme(
                    minWidth: MediaQuery.of(context).size.width,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Color(0xFF083e64),
                          textStyle: TextStyle(color: Colors.white),
                          elevation: 3.0,
                          shape: RoundedRectangleBorder(
                            borderRadius: new BorderRadius.circular(30.0),
                          )),
                      onPressed: () => {
                        Navigator.of(context).pop(),
                        postBodyForProductsSell(),
                      },
                      child: Padding(
                        padding: EdgeInsets.symmetric(vertical: 15),
                        child: Text(Language()
                            .getString(Constants.SELL_PRODUCTS, selectedLang)),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        });
  }

  buildSearchBarView() {
    return Card(
      elevation: 5,
      shadowColor: theme.colorScheme.primary,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0),
          side:
              BorderSide(color: theme.colorScheme.primary, strokeAlign: 0.01)),
      child: Row(
        children: <Widget>[
          Expanded(
              child: Container(
            padding: EdgeInsets.only(left: 10),
            child: TextFormField(
              controller: _searchController,
              onChanged: onSearchTextChanged,
              style: TextStyle(fontWeight: StyleView.fontSemiBold),
              decoration: InputDecoration(
                  contentPadding: EdgeInsets.only(bottom: 10),
                  border: InputBorder.none,
                  hintText:
                      Language().getString(Constants.SEARCH, selectedLang),
                  hintStyle: TextStyle(
                      fontWeight: StyleView.fontSemiBold, fontSize: 13.0)),
            ),
          )),
        ],
      ),
    );
  }

  onSearchTextChanged(String text) {
    showLoaderText = Constants.LOADING;
  }

  Future<List<BuBasicDataModel>> getAllBuBusinessData(String? userId) async {
    String body = json.encode({"id": userId});
    var response = await _organizationService
        .getBulistByUserId(body: body, token: "")
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<BuBasicDataModel> _model = [];
    List<BuBasicDataModel> buList = [];
    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var responseBody = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(responseBody)) {
        for (var noteJson in responseBody) {
          _model.add(BuBasicDataModel.fromJson(noteJson));
        }
        if (_model.length > 0) {
          for (int i = 0; i < _model.length; i++) {
            if (myBuId != _model[i].id) {
              buList.add(_model[i]);
            }
          }
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }

    return buList;
  }

  postBodyForProductsSell() async {
    setState(() {
      isLoadingProgress = true;
    });
    Map data = {
      "id": "",
      "order_type":"online_discussion_sell",
      "buyer": {
        "id": _buData.id,
        "name": _buData.businessName,
      },
      "seller": {
        "id": myBuId,
        "name": myBuName,
      },
      "sender": {
        "id": myBuId,
      },
      "ctr": {"type": "", "Agent": "", "transaction_ref": ""},
      "discussion": {
        "initiator": _buData.id,
        "initiator_user": _buData.businessName,
        "message_start_date": "",
        "confirmation_message": [],
        "confirmation_status": ""
      }
    };
    String body = json.encode(data);
    var response = await _transactionService
        .beginTransaction(body, AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);
      Navigator.of(context).pop();
      naviToDiscussionPage(data);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  naviToDiscussionPage(String? transactionId) {
    Navigator.push(
        context,
        new MaterialPageRoute(
            builder: (context) => DiscussionView(
                  transactionId: transactionId,
                  transactionName: _buData.businessName,
                )));
  }

  postBodyForProductsBuy() async {
    setState(() {
      isLoadingProgress = true;
    });
    Map data = {
      "id": "",
      "order_type":"online_discussion_buy",
      "buyer": {
        "id": myBuId,
        "name": myBuName,
      },
      "seller": {
        "id": _buData.id,
        "name": _buData.businessName,
      },
      "sender": {
        "id": myBuId,
      },
      "ctr": {"type": "", "Agent": "", "transaction_ref": ""},
      "discussion": {
        "initiator": _buData.id,
        "initiator_user": _buData.businessName,
        "message_start_date": "",
        "confirmation_message": [],
        "confirmation_status": ""
      }
    };
    String body = json.encode(data);
    var response = await _transactionService
        .beginTransaction(body, AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);
      Navigator.of(context).pop();
      naviToDiscussionPage(data);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }
}
