import 'package:flutter/material.dart';
import 'package:flutx/flutx.dart';

import '../../Transaction/TransactionsPage.dart';
import '../../Transaction/direcr_order_view/DirectOrderPage.dart';
import '../ConnectionsBuDetails.dart';
import '../PlaceConnectionOrder.dart';
import '../TermsAndConditionsPage.dart';

class ConnectionController extends FxController {
  void navigationTermsAndConditionsPage(
      {required BuildContext context,
      required String connectionId,
      required String connectionBuName,
      required String connectionBuId}) {
    Navigator.push(
        context,
        new MaterialPageRoute(
            builder: (context) => TermsAndConditionsPage(
                connectionId: connectionId,
                connectionName: connectionBuName,
                connectionBuId: connectionBuId)));
  }

  void navigationProductsPage(
      {required BuildContext context,
      required String connectionBuName,
      required String connectionBuId}) {
    Navigator.push(
        context,
        new MaterialPageRoute(
            builder: (context) => PlaceConnectionOrderPage(
                buName: connectionBuName, buId: connectionBuId)));
  }

  void navigationTransactionPage(
      {required BuildContext context,
      required bool isFromConnections,
      required bool isFromBuList}) {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) =>
                TransactionsView(isFromConnections: true, isFromBuList: true)));
  }

  void navigationOrganizationDetailsPage(
      {required BuildContext context,
      required String connectionId,
      required String connectionBuName,
      required String connectionBuId}) {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => ConnectionsBuDetailsPage(
                connectionId: connectionId,
                buName: connectionBuName,
                buId: connectionBuId)));
  }

  void navigationDirectOrderPage(
      {required BuildContext context,
      required String connectionBuId,
      required String connectionBuName}) {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => DirectOrderPage(
                connectionId: connectionBuId,
                isOnline: true,
                connectionName: connectionBuName)));
  }

  void navigationDirectSellOrderPage(
      {required BuildContext context,
      required String connectionBuId,
      required String connectionBuName}) {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => DirectOrderPage(
                isForSell: true,
                isOnline: true,
                connectionId: connectionBuId,
                connectionName: connectionBuName)));
  }

  @override
  String getTag() {
    return "connection_controller";
  }
}
