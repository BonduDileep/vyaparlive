import 'package:vyaparlive/service/api_service/TransactionApiService.dart';
import 'package:vyaparlive/service/api_service/UserApiService.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/animation/list_loader/ListLoader.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:flutx/flutx.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/Transaction/buyer/DiscussionView.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/connections_view/connection_widgets/connection_card.dart';
import 'package:vyaparlive/model/Contacts.dart';
import 'package:vyaparlive/model/UserModel.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:vyaparlive/stock_returns_view/ReturnProductsDiscussionPage.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:vyaparlive/utills/SharePref.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:checkbox_grouped/checkbox_grouped.dart';
import '../service/api_service/InvitationApiService.dart';
import 'controller/ConnectionController.dart';

class ListOfContactsView extends StatefulWidget {
  @override
  _ListOfContactsViewState createState() => _ListOfContactsViewState();
}

class _ListOfContactsViewState extends State<ListOfContactsView>
    with TickerProviderStateMixin {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? selectedLang = AppController.instance.getSelectedlanguage;
  late SharedPreferences sharedPreferences;
  List<Contacts> _contactsModel = [];
  TextEditingController _searchController = TextEditingController();
  Contacts _indexContacts = Contacts();
  String? userId = "";
  bool isLoading = false;
  String? buId = "";
  String? buName = "";
  List<UserModel> _usersList = [];
  bool isLoadingProgress = true;
  String progressMessage = Constants.GETTING_DATA;
  static String showLoaderText = Constants.NO_DATA_FOUND;
  UserModel? usersDropdownValue;
  String? rawMaterialTransactionRadioValue;
  String? actualTransactionRadioValue;
  bool isBuyProductsSelected = false;
  List<Map> _namesMapData = [];
  List<String> filterOptions = [];
  List<String> _checked = [];
  bool isShowFloatButton = false;
  bool isForSearchFilters = false;
  List<Contacts> _connectionUsers = [];
  String? stockReturnsType;
  late ThemeData theme;
  late AnimationController _animationController;
  late ConnectionController _connectionController;
  @override
  void initState() {
    super.initState();
    _connectionController = FxControllerStore.putOrFind(ConnectionController());
    this.getLoadLanguage();
    theme = AppTheme.vyaparTheme;

    filterOptions = [
      Language().getString(Constants.DISTRIBUTORS_LIST, selectedLang)
    ];
    initBottomSheetAnimation();
    buId = AppController.instance.getMyBuId;
    buName = AppController.instance.getBuName;
    SharePref().getUserId().then((onValue) {
      setState(() => userId = onValue);
    });
    loadServiceCalls();
  }

  initBottomSheetAnimation() {
    _animationController = BottomSheet.createAnimationController(this);
    _animationController.duration =
        const Duration(milliseconds: Constants.bottomSheet_duration);
    _animationController.reverseDuration =
        const Duration(milliseconds: Constants.bottomSheet_reverse_duration);
    _animationController.drive(CurveTween(curve: Curves.easeIn));
  }

  Future<void> loadServiceCalls() async {
    await loadConnectionsData();
    await loadUsersData();
  }

  getLoadLanguage() {
    _namesMapData = [
      {"name": Language().getString(Constants.OUR_SALES_TEAM, selectedLang)},
      {"name": Language().getString(Constants.PRODUCTS_STR, selectedLang)},
      {
        "name":
            Language().getString(Constants.START_ORDER_DISCUSSION, selectedLang)
      },
      {
        "name":
            Language().getString(Constants.TRANSACTION_HISTORY, selectedLang)
      },
      {"name": Language().getString(Constants.BU_DETAILS, selectedLang)},
      {"name": Language().getString(Constants.DIRECT_BUY_ORDER, selectedLang)},
      {"name": Language().getString(Constants.ASSIGN_TO_USER, selectedLang)},
      {
        "name": Language().getString(Constants.ADD_TO_DISTRIBUTOR, selectedLang)
      },
      {
        "name": Language()
            .getString(Constants.REMOVE_FROM_DISTRIBUTOR, selectedLang)
      },
      {
        "name": Language()
            .getString(Constants.THIS_CONNECTION_IS_DISTRIBUTOR, selectedLang)
      },
      {
        "name":
            Language().getString(Constants.FIELD_OFFICERS_LIST, selectedLang)
      },
      {"name": Language().getString(Constants.RETURN_PRODUCTS, selectedLang)},
      {"name": Language().getString(Constants.RE_CALL_PRODUCTS, selectedLang)},
      {
        "name": Language().getString(Constants.DIRECT_SELL_ORDERS, selectedLang)
      },
    ];
  }

  Card buildSearchBarView() {
    return Card(
      elevation: 5,
      shadowColor: theme.colorScheme.primary,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0),
          side:
              BorderSide(color: theme.colorScheme.primary, strokeAlign: 0.02)),
      child: Row(
        children: <Widget>[
          Expanded(
              child: Container(
            padding: EdgeInsets.only(left: 15),
            child: TextFormField(
              controller: _searchController,
              onChanged: onSearchTextChanged,
              style: TextStyle(fontWeight: StyleView.fontSemiBold),
              decoration: InputDecoration(
                  contentPadding: EdgeInsets.only(bottom: 10),
                  border: InputBorder.none,
                  hintText:
                      Language().getString(Constants.SEARCH, selectedLang),
                  hintStyle: TextStyle(
                      fontSize: 13.0, fontWeight: StyleView.fontSemiBold)),
            ),
          )),
          if (_searchController.text.isNotEmpty)
            Container(
                color: Colors.white,
                child: IconButton(
                    icon: Icon(
                      Icons.close,
                      color: Colors.red,
                      size: 20.0,
                    ),
                    onPressed: () {
                      setState(() {
                        CommonMethods.hideKeyboard(context);
                        _searchController.clear();
                        onSearchTextChanged(_searchController.text);
                      });
                    })),
          Container(
              child: IconButton(
                  onPressed: () {
                    bottomSheetFilterView();
                    //this.buildFilterDialog();
                  },
                  icon: Icon(
                    Icons.filter_list,
                    color: theme.colorScheme.primary,
                  )))
        ],
      ),
    );
  }

  bottomSheetFilterView() {
    showModalBottomSheet(
        transitionAnimationController: _animationController,
        isScrollControlled: true,
        enableDrag: true,
        showDragHandle: true,
        backgroundColor: Colors.white,
        barrierColor: Colors.black54,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20.0),
                topRight: Radius.circular(20.0))),
        context: context,
        builder: (BuildContext buildContext) {
          return StatefulBuilder(
            builder: (BuildContext context,
                void Function(void Function()) setState) {
              return Padding(
                padding: const EdgeInsets.all(8.0),
                child: ListView(
                  shrinkWrap: true,
                  children: [
                    SimpleGroupedCheckbox<String>(
                      controller: GroupController(),
                      onItemSelected: (selected) {
                        // if (selected.length > 1) {
                        //   selected.removeAt(0);
                        // }
                        // setState(() {
                        //   _checked = selected;
                        // });
                      },
                      itemsTitle: filterOptions,
                      values: filterOptions,
                      groupStyle: GroupStyle(
                          activeColor: Colors.black,
                          itemTitleStyle: TextStyle(
                              fontSize: 15,
                              fontWeight: StyleView.fontSemiBold)),
                      // checkFirstElement: false,
                    ),
                    FxSpacing.height(10.0),
                    Container(
                      child: CommonButtonsView(
                          context: context,
                          b1Text: Language()
                              .getString(Constants.STR_CANCEL, selectedLang),
                          b2Text: Language()
                              .getString(Constants.APPLY_FILTER, selectedLang),
                          onb1Action: () => Navigator.of(context).pop(),
                          onb2Action: () {
                            Navigator.of(context).pop();
                            // if (_checked.length > 0) {
                            setState(() {
                              isShowFloatButton = true;
                            });

                            loadConnectionsData(isDistributor: true);
                          }
                          // },
                          ),
                    )
                  ],
                ),
              );
            },
          );
        });
  }

  void onSearchTextChanged(String text) {
    showLoaderText = Constants.LOADING;
    if (text.isEmpty) {
      isForSearchFilters = false;
      loadConnectionsData();
    } else {
      isForSearchFilters = true;
      if (CommonMethods.isNumeric(text)) {
        loadConnectionsData(contactNumber: text);
      } else {
        loadConnectionsData(buName: text);
      }
    }
  }

  showDiscussionChoiceDialog() {
    return showDialog(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(15.0)),
              ),
              title: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Container(
                    child: Text(
                      Language().getString(
                          Constants.STR_DISCUSSION_FOR, selectedLang),
                      style: TextStyle(
                          color: theme.colorScheme.primary,
                          fontWeight: StyleView.fontMedium,
                          fontSize: 15.0),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      rawMaterialTransactionRadioValue = null;
                      actualTransactionRadioValue = null;
                      isBuyProductsSelected = false;
                      Navigator.of(context).pop();
                    },
                    child: Icon(
                      Icons.close,
                      color: Colors.red,
                    ),
                  ),
                ],
              ),
              content:
                  StatefulBuilder(builder: (context, StateSetter setState) {
                return Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Container(
                      width: MediaQuery.of(context).size.width,
                      height: 50,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                            borderRadius: new BorderRadius.circular(30.0),
                          ),
                          backgroundColor: theme.colorScheme.primary,
                          elevation: 3.0,
                        ),
                        onPressed: () => {
                          serviceCallBuyProducts(),
                          Navigator.of(context).pop(),
                        },
                        child: Padding(
                          padding: EdgeInsets.symmetric(vertical: 15),
                          child: Text(
                            Language().getString(
                                Constants.BUY_PRODUCTS, selectedLang),
                            style: TextStyle(fontWeight: StyleView.fontRegular),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 10),
                    Container(
                      width: MediaQuery.of(context).size.width,
                      height: 50,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                            borderRadius: new BorderRadius.circular(30.0),
                          ),
                          backgroundColor: theme.colorScheme.primary,
                          elevation: 3.0,
                        ),
                        onPressed: () async {
                          setState(() => isBuyProductsSelected = false);
                          serviceCallSellProducts();
                          Navigator.of(context).pop();
                        },
                        child: Padding(
                          padding: EdgeInsets.symmetric(vertical: 15),
                          child: Text(
                            Language().getString(
                                Constants.SELL_PRODUCTS, selectedLang),
                            style: TextStyle(fontWeight: StyleView.fontRegular),
                          ),
                        ),
                      ),
                    )
                  ],
                );
              }));
        });
  }

  Widget _listViewData() {
    if (isLoadingProgress) {
      return Expanded(child: ListLoader());
    } else if (!isLoadingProgress && _contactsModel.length == 0) {
      return Expanded(
          child: Center(
              child: Text(Language().getString(showLoaderText, selectedLang))));
    } else {
      return Expanded(
        child: AnimationLimiter(
          child: ListView.separated(
            physics: const BouncingScrollPhysics(
                parent: AlwaysScrollableScrollPhysics()),
            shrinkWrap: true,
            separatorBuilder: (context, index) => Divider(
              height: 10.0,
              color: Colors.transparent,
            ),
            itemBuilder: (BuildContext ctxt, int index) {
              return AnimationConfiguration.staggeredList(
                position: index,
                duration: Duration(milliseconds: 900),
                child: SlideAnimation(
                  verticalOffset: 50.0,
                  child: FadeInAnimation(
                    child: new ConnectionCard(
                      false,
                      contacts: _contactsModel[index],
                      onTermsClick: () {
                        CommonMethods.hideKeyboard(context);
                        _indexContacts = _contactsModel[index];
                        _connectionController.navigationTermsAndConditionsPage(
                            context: context,
                            connectionId: _contactsModel[index].id!,
                            connectionBuName: _contactsModel[index].buName!,
                            connectionBuId: _contactsModel[index].buId!);
                      },
                      onProductsClick: () {
                        CommonMethods.hideKeyboard(context);
                        _indexContacts = _contactsModel[index];
                        _connectionController.navigationProductsPage(
                            context: context,
                            connectionBuName: _contactsModel[index].buName!,
                            connectionBuId: _contactsModel[index].buId!);
                      },
                      onActivityClick: () {
                        CommonMethods.hideKeyboard(context);
                        AppController.instance.setConnectionsData =
                            _contactsModel[index];
                        _connectionController.navigationTransactionPage(
                            context: context,
                            isFromConnections: true,
                            isFromBuList: true);
                      },
                      onStartDiscussionClick: () {
                        CommonMethods.hideKeyboard(context);
                        _indexContacts = _contactsModel[index];
                        showDiscussionChoiceDialog();
                      },
                      onBuDetailsClick: () {
                        CommonMethods.hideKeyboard(context);
                        _indexContacts = _contactsModel[index];
                        _connectionController.navigationOrganizationDetailsPage(
                            context: context,
                            connectionId: _contactsModel[index].id!,
                            connectionBuName: _contactsModel[index].buName!,
                            connectionBuId: _contactsModel[index].buId!);
                      },
                      onDirectOrder: () {
                        CommonMethods.hideKeyboard(context);
                        _connectionController.navigationDirectOrderPage(
                            context: context,
                            connectionBuId: _contactsModel[index].buId!,
                            connectionBuName: _contactsModel[index].buName!);
                      },
                      onAssignToUser: () {
                        if (_usersList.length > 0) {
                          setState(() => usersDropdownValue = null);
                          showUsersList(_contactsModel[index].id,
                              _contactsModel[index].buName);
                        }
                      },
                      namesMapData: _namesMapData,
                      addToDistributor: () => updateAddToDistributor(index),
                      onUsersList: () => serviceCallConnectionsUsers(index),
                      onReturnsOfProducts: () => returnsOfProductsView(index),
                      onRecallOfProducts: () => print("Clicked"),
                      onDirectSellOrder: () {
                        CommonMethods.hideKeyboard(context);
                        _connectionController.navigationDirectSellOrderPage(
                            context: context,
                            connectionBuId: _contactsModel[index].buId!,
                            connectionBuName: _contactsModel[index].buName!);
                      },
                      // onChatClick: () {
                      //   Navigator.push(
                      //       context,
                      //       new MaterialPageRoute(
                      //           builder: (context) => ChatScreenView(
                      //                 chatId: userId! +
                      //                     "_" +
                      //                     _contactsModel[index].buId!,
                      //                 transactionName:
                      //                     _contactsModel[index].buName,
                      //               )));
                      // },
                    ),
                  ),
                ),
              );
            },
            itemCount: _contactsModel.length,
          ),
        ),
      );
    }
  }

  Future<void> updateAddToDistributor(int index) async {
    String message = "";
    bool isExist = false;
    if (_contactsModel[index].isDistributor!) {
      message =
          Language().getString(Constants.REMOVE_DISTRIBUTOR, selectedLang);
      isExist = true;
    } else {
      message = Language()
              .getString(Constants.ARE_YOU_SURE_DO_YOU_WANT_TO, selectedLang) +
          " ${_contactsModel[index].buName} " +
          Language().getString(Constants.AS_DISTRIBUTOR, selectedLang);
      isExist = false;
    }
    final action = await Dialogs.yesCancelDialog(
        context,
        Language().getString(Constants.MESSAGE, selectedLang),
        message,
        Language().getString(Constants.YES_STRING, selectedLang),
        Language().getString(Constants.NO_STRING, selectedLang),
        true);
    if (action == DialogAction.yes) {
      addToDistributorServiceCall(index, isExist);
    }
  }

  returnsOfProductsView(int index) {
    return showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: Text(
          Language().getString(Constants.SELECT_ONE_OPTION, selectedLang),
          style: TextStyle(
              color: Color(Constants.APP_COLOR),
              fontSize: 16.0,
              fontWeight: FontWeight.w500),
        ),
        actions: [
          CommonButtonsView(
              context: context,
              b1Text: Language().getString(Constants.CLOSE, selectedLang),
              b2Text: Language().getString(Constants.CONTINUE, selectedLang),
              onb2Action: () => {
                    Navigator.of(context).pop(),
                    if (stockReturnsType == Constants.RETURN_PRODUCTS)
                      {
                        Navigator.push(
                          context,
                          PageTransition(
                            context: context,
                            page: ReturnProductsDiscussionPage(),
                          ),
                        ),
                      }
                  },
              onb1Action: () => {
                    setState(() {
                      stockReturnsType = null;
                    }),
                    Navigator.of(context).pop(),
                  })
        ],
        content: StatefulBuilder(
          builder: (BuildContext context, StateSetter setState) => Container(
            height: 80,
            child: Column(children: [
              Container(
                child: Row(
                  children: [
                    Radio(
                        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        value: Constants.RETURN_PRODUCTS,
                        activeColor: Color(Constants.APP_COLOR),
                        groupValue: stockReturnsType,
                        onChanged: (dynamic selectedValue) {
                          setState(() {
                            stockReturnsType = selectedValue;
                          });
                        }),
                    Text(Language()
                        .getString(Constants.RETURN_PRODUCTS, selectedLang))
                  ],
                ),
              ),
              Container(
                child: Row(
                  children: [
                    Radio(
                        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        value: Constants.RE_CALL_PRODUCTS,
                        groupValue: stockReturnsType,
                        activeColor: Color(Constants.APP_COLOR),
                        onChanged: (dynamic selectedValue) {
                          setState(() {
                            stockReturnsType = selectedValue;
                          });
                        }),
                    Text(Language()
                        .getString(Constants.RE_CALL_PRODUCTS, selectedLang))
                  ],
                ),
              ),
            ]),
          ),
        ),
      ),
    );
  }

  showUsersList(String? connectionId, String? connectionName) {
    return showDialog(
        barrierDismissible: false,
        barrierColor: Colors.black54,
        context: context,
        builder: (context) {
          return AlertDialog(
              elevation: 100.0,
              contentPadding: EdgeInsets.fromLTRB(15.0, 0, 15.0, 0),
              backgroundColor: Colors.white, //(0XFFE0E0E0),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(
                  Radius.circular(
                    7.0,
                  ),
                ),
              ),
              title: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Text(
                    Language().getString(Constants.SELECT_USER, selectedLang),
                    style: TextStyle(color: theme.colorScheme.primary),
                  ),
                  GestureDetector(
                    onTap: () {
                      usersDropdownValue = null;
                      Navigator.of(context).pop();
                    },
                    child: Icon(
                      Icons.close,
                      color: Colors.red,
                    ),
                  ),
                ],
              ),
              content: StatefulBuilder(
                  builder: (BuildContext context, StateSetter setState) {
                return usersDropdownView(
                    setState, connectionId, connectionName);
              }));
        });
  }

  Widget usersDropdownView(
      StateSetter setState, String? connectionId, String? connectionName) {
    return Container(
        height: 150.0,
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                  margin: EdgeInsets.symmetric(horizontal: 5.0, vertical: 10.0),
                  decoration: AppUtills.boxDecoration(),
                  // height: 50,
                  child: DropdownButton<UserModel>(
                      onTap: () {
                        FocusScope.of(context).unfocus();
                      },
                      value: usersDropdownValue,
                      hint: Container(
                          padding: EdgeInsets.symmetric(horizontal: 8),
                          child: new Text(
                            Language().getString(
                                Constants.SELECT_A_USER, selectedLang),
                          )),
                      isExpanded: true,
                      underline: SizedBox(),
                      onChanged: (UserModel? data) {
                        setState(() {
                          usersDropdownValue = data;
                        });
                      },
                      items: _usersList.map((UserModel model) {
                        return new DropdownMenuItem<UserModel>(
                          child: Container(
                              padding: EdgeInsets.symmetric(horizontal: 8),
                              child: new Text(model.name!)),
                          value: model,
                        );
                      }).toList())),
              SizedBox(height: 10.0),
              Container(
                  width: MediaQuery.of(context).size.width,
                  child: CommonButtonsView(
                    context: context,
                    b1Text: "",
                    b2Text: Language().getString(Constants.DONE, selectedLang),
                    onb2Action: () async {
                      Navigator.of(context).pop();
                      if (usersDropdownValue == null) {
                        return;
                      }
                      updateAssignUser(connectionId!, connectionName!);
                    },
                  )),
            ]));
  }

  buildFilterDialog() {
    return showDialog(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) {
          return StatefulBuilder(builder: (context, StateSetter setState) {
            return Scaffold(
                backgroundColor: Colors.transparent,
                body: Container(
                  margin:
                      EdgeInsets.symmetric(horizontal: 20.0, vertical: 200.0),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(15.0)),
                  ),
                  child: Column(
                    children: <Widget>[
                      Container(
                        margin: EdgeInsets.symmetric(
                            vertical: 5.0, horizontal: 5.0),
                        alignment: Alignment.centerRight,
                        child: GestureDetector(
                            onTap: () {
                              _checked.clear();
                              Navigator.of(context).pop();
                            },
                            child: Padding(
                                padding: EdgeInsets.all(5.0),
                                child: Icon(Icons.close, color: Colors.red))),
                      ),
                      SizedBox(height: 2.5),
                      Text(
                        Language()
                            .getString(Constants.SORT_BY_STR, selectedLang),
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_18,
                            fontFamily: StyleView.FONT_TITLE),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(height: 2.5),
                      Container(
                          width: MediaQuery.of(context).size.width,
                          height: 2,
                          color: Colors.grey),
                      SizedBox(height: 5),
                      // CheckboxGroup(
                      //   labels: filterOptions,
                      //   checked: _checked,
                      //   onSelected: (List selected) {
                      //     if (selected.length > 1) {
                      //       selected.removeAt(0);
                      //     }
                      //     setState(() {
                      //       _checked = selected;
                      //     });
                      //   },
                      // ),
                      Container(
                        margin: EdgeInsets.symmetric(vertical: 10.0),
                        child: ElevatedButton(
                          style: CommonMethods.elevatedButtonStyle(),
                          onPressed: () {
                            Navigator.of(context).pop();
                            // if (_checked.length > 0) {
                            setState(() {
                              isShowFloatButton = true;
                            });
                            loadConnectionsData(isDistributor: true);
                            // }
                          },
                          child: Text(Language()
                              .getString(Constants.APPLY_FILTER, selectedLang)),
                        ),
                      ),
                      SizedBox(height: 10.0)
                    ],
                  ),
                ));
          });
        });
  }

  @override
  void dispose() {
    _connectionController.dispose();
    super.dispose();
  }

  @override
  void setState(VoidCallback fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        SafeArea(
          child: Scaffold(
            key: _scaffoldkey,
            floatingActionButton: (isShowFloatButton)
                ? FloatingActionButton(
                    backgroundColor: theme.colorScheme.primary,
                    onPressed: () {
                      setState(() {
                        isShowFloatButton = false;
                        isLoadingProgress = true;
                        _searchController.clear();
                        CommonMethods.hideKeyboard(context);
                        _checked.clear();
                      });
                      this.loadConnectionsData();
                    },
                    child: Text(
                      Language().getString(Constants.CLEAR_FILTERS, selectedLang),
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 10.0, color: Colors.white),
                    ),
                  )
                : null,
            body: Container(
                color: Color(Constants.APP_BACKGROUND_COLOR),
                margin: EdgeInsets.only(right: 5),
                child: Card(
                  elevation: 20,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.only(
                          topRight: Radius.circular(10.0),
                          bottomRight: Radius.circular(10.0))),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      children: <Widget>[
                        Container(
                          height: 50.0,
                          margin: EdgeInsets.only(top: 10),
                          child: buildSearchBarView(),
                        ),
                        SizedBox(height: 10.0),
                        _listViewData()
                      ],
                    ),
                  ),
                )),
          ),
        ),
      ],
    );
  }

  Future<void> updateAssignUser(
      String connectionId, String connectionName) async {
    setState(() => isLoadingProgress = true);
    bool value = await InvitationApiService.instance.assignConnectionToUser(
        connectionId: connectionId,
        userId: usersDropdownValue!.id!,
        buId: buId!,
        langError: Language().getString(Constants.ERROR, selectedLang),
        langOk: Language().getString(Constants.OKAY_STR, selectedLang));
    setState(() => isLoadingProgress = false);
    String message = "";
    if (value) {
      message = '$connectionName ' +
          Language().getString(Constants.IS_ASSIGNED_TO, selectedLang) +
          ' ${usersDropdownValue!.name}.';
    } else {
      message =
          Language().getString(Constants.FAILED_TO_ASSIGN_USER, selectedLang);
    }
    await Dialogs.yesCancelDialog(
        context,
        Language().getString(Constants.SUCCESS, selectedLang),
        message,
        Language().getString(Constants.OKAY_STR, selectedLang),
        "",
        false);
  }

  serviceCallConnectionsUsers(int index) async {
    if (await NetworkStatus.getInternetStatus()) {
      List<Contacts> fetchUsersList = await InvitationApiService.instance
          .getConnectionUsers(
              context: context,
              connectionId: _contactsModel[index].id!,
              buId: buId!,
              langError: Language().getString(Constants.ERROR, selectedLang),
              langOk: Language().getString(Constants.OKAY_STR, selectedLang));
      if (fetchUsersList.length == 0) {
        Dialogs.yesCancelDialog(
            context,
            Language().getString(Constants.INFO, selectedLang),
            Language().getString(
                Constants.CONNECTION_HAS_NO_FIELD_OFFICERS, selectedLang),
            Language().getString(Constants.OKAY_STR, selectedLang),
            "",
            false);
        return;
      }
      if (fetchUsersList[0].usersList!.length > 0) {
        setState(() => _connectionUsers.addAll(fetchUsersList));
        showUsersCardView(_connectionUsers[0].usersList);
      }
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  showUsersCardView(List<UserModel>? usersInfo) {
    return showDialog(
        context: context,
        builder: (context) => Container(
              margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5.0),
                  color: Color(Constants.APP_BACKGROUND_COLOR)),
              child: Scaffold(
                  backgroundColor: Colors.transparent,
                  bottomNavigationBar: Container(
                      child: ElevatedButton(
                          style: CommonMethods.elevatedButtonStyle(),
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                          child: Text(Language()
                              .getString(Constants.CLOSE, selectedLang)))),
                  body: Container(
                    child: Padding(
                      padding: const EdgeInsets.all(5.0),
                      child: Column(
                        children: [
                          Container(
                            margin: EdgeInsets.symmetric(vertical: 10.0),
                            child: Center(
                              child: Text(
                                "Assigned Field Officers",
                                style: TextStyle(
                                    color: Color(Constants.APP_COLOR),
                                    fontWeight: FontWeight.bold,
                                    fontSize: 15.0),
                              ),
                            ),
                          ),
                          Expanded(
                            child: ListView.builder(
                              itemBuilder: (context, index) => Container(
                                  child: Card(
                                      elevation: 2.5,
                                      child: Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Column(children: [
                                          Container(
                                              child: Row(children: [
                                            Expanded(
                                              child: Text(
                                                  Language().getString(
                                                      Constants.NAME_STRING,
                                                      selectedLang),
                                                  style: TextStyle(
                                                      color: Color(
                                                          Constants.APP_COLOR),
                                                      fontWeight:
                                                          FontWeight.bold)),
                                            ),
                                            Text("  : "),
                                            Expanded(
                                                flex: 2,
                                                child: Text(
                                                    usersInfo[index].name!))
                                          ])),
                                          Container(
                                              child: Row(children: [
                                            Expanded(
                                                child: Text(
                                                    Constants.MOBILE_NUMBER,
                                                    style: TextStyle(
                                                        color: Color(Constants
                                                            .APP_COLOR),
                                                        fontWeight:
                                                            FontWeight.bold))),
                                            Text("  : "),
                                            Expanded(
                                                flex: 2,
                                                child: Text(
                                                    usersInfo[index].contact!))
                                          ]))
                                        ]),
                                      ))),
                              itemCount: usersInfo!.length,
                            ),
                          ),
                        ],
                      ),
                    ),
                  )),
            ));
  }

  Future<void> serviceCallBuyProducts() async {
    if (await NetworkStatus.getInternetStatus()) {
      Map<String, dynamic> mapData = {
        "id": "",
        "is_offline": false,
        "order_type":"online_discussion_buy",
        "buyer": {
          "id": buId,
          "name": buName,
        },
        "seller": {
          "id": _indexContacts.buId,
          "name": _indexContacts.buName,
        },
        "sender": {
          "id": buId,
        },
        "ctr": {"type": "", "Agent": "", "transaction_ref": ""},
        "discussion": {
          "initiator": _indexContacts.buId,
          "initiator_user": _indexContacts.buName,
          "message_start_date": "",
          "confirmation_message": [],
          "confirmation_status": ""
        }
      };

      if (isBuyProductsSelected && rawMaterialTransactionRadioValue != null) {
        mapData['transaction_type'] = Constants.KEY_RAW_MATERIAL;
      }
      setState(() => isLoadingProgress = true);
      String transactionId = await TransactionApiService.instance.buyProducts(
          context: context,
          mapData: mapData,
          langError: Language().getString(Constants.ERROR, selectedLang),
          langOk: Language().getString(Constants.OKAY_STR, selectedLang));
      setState(() => isLoadingProgress = false);
      if (transactionId.isNotEmpty) {
        Navigator.push(
            context,
            new MaterialPageRoute(
                builder: (context) => DiscussionView(
                      transactionId: transactionId,
                      transactionName: _indexContacts.buName,
                    )));
      }
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<void> serviceCallSellProducts() async {
    if (await NetworkStatus.getInternetStatus()) {
      Map<String, dynamic> mapData = {
        "id": "",
        "is_offline": false,
        "order_type":"online_discussion_sell",
        "buyer": {
          "id": _indexContacts.buId,
          "name": _indexContacts.buName,
        },
        "seller": {
          "id": buId,
          "name": buName,
        },
        "sender": {
          "id": buId,
        },
        "ctr": {"type": "", "Agent": "", "transaction_ref": ""},
        "discussion": {
          "initiator": _indexContacts.buId,
          "initiator_user": _indexContacts.buName,
          "message_start_date": "",
          "confirmation_message": [],
          "confirmation_status": ""
        }
      };
      setState(() => isLoadingProgress = true);
      String transactionId = await TransactionApiService.instance.sellProducts(
          context: context,
          mapData: mapData,
          langError: Language().getString(Constants.ERROR, selectedLang),
          langOk: Language().getString(Constants.OKAY_STR, selectedLang));
      setState(() => isLoadingProgress = false);
      if (transactionId.isNotEmpty) {
        Navigator.push(
          context,
          new MaterialPageRoute(
            builder: (context) => DiscussionView(
              transactionId: transactionId,
              transactionName: _indexContacts.buName,
            ),
          ),
        );
      }
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<void> loadConnectionsData(
      {String buName = "",
      String contactNumber = "",
      bool isDistributor = false}) async {
    if (await NetworkStatus.getInternetStatus()) {
      if (!isForSearchFilters) {
        setState(() => isLoadingProgress = true);
      }
      Map<String, dynamic> filtersData = {
        "bu_name": buName,
        "contactNumber": contactNumber
      };
      if (isDistributor) {
        filtersData['is_distributor'] = isDistributor;
      }
      List<Contacts> fetchConnectionList = await InvitationApiService.instance
          .getContacts(
              context: context,
              buId: buId!,
              filtersData: filtersData,
              langError: Language().getString(Constants.ERROR, selectedLang),
              langOk: Language().getString(Constants.OKAY_STR, selectedLang));
      setState(() {
        isLoadingProgress = false;
        _contactsModel.clear();
      });
      if (fetchConnectionList.length > 0) {
        fetchConnectionList.sort((a, b) => a.buName!
            .toLowerCase()
            .toString()
            .compareTo(b.buName!.toLowerCase().toString()));
        setState(() => _contactsModel.addAll(fetchConnectionList));
      } else {
        setState(() => showLoaderText = Constants.NO_DATA_FOUND);
      }
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<void> addToDistributorServiceCall(int index, bool isExist) async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() => isLoadingProgress = true);
      final value = await InvitationApiService.instance.addDistributor(
          connectionId: _contactsModel[index].id!,
          isDistributor: isExist ? false : true,
          buId: buId!);
      setState(() => isLoadingProgress = false);
      if (value) {
        String message = "";
        if (isExist) {
          message = '${_contactsModel[index].buName} ' +
              Language().getString(
                  Constants.IS_SUCCESSFULLY_REMOVE_DIS, selectedLang);
        } else {
          message = '${_contactsModel[index].buName}' +
              Language().getString(
                  Constants.IS_SUCCESSFULLY_ADDED_AS_DIS, selectedLang);
        }
        final action = await Dialogs.yesCancelDialog(
            context,
            Language().getString(Constants.SUCCESS, selectedLang),
            message,
            Language().getString(Constants.OKAY_STR, selectedLang),
            "",
            false);
        if (action == DialogAction.yes) {
          loadConnectionsData();
        }
      }
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<void> loadUsersData() async {
    if (await NetworkStatus.getInternetStatus()) {
      List<UserModel> fetchUsersList = await UserApiService.instance
          .getUsersByBuId(context, buId!,
              langError: Language().getString(Constants.ERROR, selectedLang),
              langOk: Language().getString(Constants.OKAY_STR, selectedLang));
      setState(() => isLoadingProgress = false);
      if (fetchUsersList.length > 0) {
        fetchUsersList.sort(
            (a, b) => a.firstName.toString().compareTo(b.firstName.toString()));
        setState(() => _usersList.addAll(fetchUsersList));
      }
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }
}
