import 'dart:convert';

import 'package:intl/intl.dart';
import 'package:vyaparlive/components/DateFilterUtil.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/core/enums/privilleges_enum.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/TransactionsModel.dart';
import 'package:vyaparlive/offline_connections/controller/controller.dart';
import 'package:vyaparlive/order_form/OrderFormDetails.dart';
import 'package:vyaparlive/service/api_service/InvitationApiService.dart';
import 'package:vyaparlive/service/api_service/UserApiService.dart';
import 'package:vyaparlive/service/bu_list_grpc_service.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:flutx/flutx.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/offline_connections/CreateOfflineCustomerPage.dart';
import 'package:vyaparlive/offline_connections/business_view/BuListCardView.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/MyDrawer.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/BuBasicDataModel.dart';
import 'package:vyaparlive/model/BuListModel.dart';
import 'package:vyaparlive/model/CountryDAO.dart';
import 'package:vyaparlive/model/DepartmentDAO.dart';
import 'package:vyaparlive/model/StatesDAO.dart';
import 'package:vyaparlive/model/UserModel.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:vyaparlive/utills/animation/list_loader/ListLoader.dart';

import '../Transaction/TransactionsPage.dart';
import '../Transaction/buyer/DiscussionView.dart';
import '../service/api_service/TransactionApiService.dart';
import '../utills/SharePref.dart';

class OrderFormOrdersView extends StatefulWidget {
  @override
  _OrderFormOrdersViewState createState() => _OrderFormOrdersViewState();
}

class _OrderFormOrdersViewState extends State<OrderFormOrdersView>
    with TickerProviderStateMixin {
  String? buId = "";
  String? buName = "";
  bool isSearchForParams = false;
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? userId = "";
  BuBasicDataModel? dropdownValue;
  DepartmentDAO? departmentDropdownValue;
  TextEditingController _searchController = TextEditingController();
  String showLoaderText = Constants.NO_DATA_FOUND;
  StatesDAO? statesDropdownValue;
  String? districtDropdownValue;
  CountryDAO? countryDropdownValue;
  String? citiesDropDownValue;
  String buContactId = '';
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  UserModel? usersDropdownValue;
  late ThemeData theme;
  late BuListGrpcService _transactionService;
  List<TransactionsModel> _transactionsList = [];
  ScrollController? _scrollController;

  String? transactionName = "";
  String? transactionStatus = "";
  String transactionDate = "";
  String status = "";
  num? totalOrders = 0;

  String startDate = "";
  String endDate = "";

  bool isShowFloatButton = false;

  DateFormat formatter = DateFormat("yyyy-MM-dd");

  late TextEditingController _fromDateController = new TextEditingController();
  late TextEditingController _toDateController = new TextEditingController();

  late AnimationController _animationController;

  String? radioButtonValue = "";
  String? selectedStatusFilter = "";
  String? selectedTypeFilter = "";

  @override
  void dispose() {
    _scrollController!.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _transactionService = BuListGrpcService();
    theme = AppTheme.vyaparTheme;
    buId = AppController.instance.getMyBuId;
    buName = AppController.instance.getBuName;
    initBottomSheetAnimation();
    startDate = formatter.format(DateTime.now()); //mnthStartDate);
    endDate = formatter.format(DateTime.now());
    _fromDateController.text = startDate;
    _toDateController.text = endDate;
    SharePref().getUserId().then((value) {
      userId = value;
    });
    _scrollController = new ScrollController();
    loadOrders("");
  }

  initBottomSheetAnimation() {
    _animationController = BottomSheet.createAnimationController(this);
    _animationController.duration =
        const Duration(milliseconds: Constants.bottomSheet_duration);
    _animationController.reverseDuration =
        const Duration(milliseconds: Constants.bottomSheet_reverse_duration);
    _animationController.drive(CurveTween(curve: Curves.easeIn));
  }

  loadOrders(String name) async {
    if (!await NetworkStatus.getInternetStatus()) {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
      return;
    }

    setState(() => isLoadingProgress = true);

    String body = json.encode({
      "buId": buId,
      "filters": {
        "name": name,
        "DateFrom": _fromDateController.text,
        "dateTo": _toDateController.text,
        "type": selectedTypeFilter
      }
    });
    GRPCResponse _grpcResponse = await _transactionService.getAllOrders(
        body: body, token: AppController.instance.getAuthorizationKey);
    List<TransactionsModel> _list = [];
    setState(() {
      radioButtonValue = "Status";
      isLoadingProgress = false;
    });
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      print(resObj);

      if (!CommonMethods.checkResponseType(resObj)) {
        var resultArray = resObj["result"];
        num count = resObj["total"];
        for (var i in resultArray) {
          _list.add(TransactionsModel.fromJson(i));
        }

        setState(() {
          _transactionsList = _list;
          totalOrders = count;
        });
      }
      // Process resObj as needed
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  Widget searchFilterView() {
    return Container(
      height: 50.0,
      child: Card(
        elevation: 5,
        shadowColor: theme.colorScheme.primary,
        shape: new RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
            side: new BorderSide(
                color: theme.colorScheme.primary, strokeAlign: 0.02)),
        child: Row(
          children: <Widget>[
            Expanded(
              flex: 5,
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: TextFormField(
                  controller: _searchController,
                  onChanged: onSearchTextChanged,
                  style: TextStyle(fontWeight: StyleView.fontSemiBold),
                  decoration: InputDecoration(
                      contentPadding: EdgeInsets.only(bottom: 10),
                      border: InputBorder.none,
                      hintText: Language()
                          .getString(Constants.SEARCH_BY_NAME, selectedLang),
                      hintStyle: TextStyle(
                          fontSize: 13.0, fontWeight: StyleView.fontSemiBold)),
                ),
              ),
            ),
            Container(color: Colors.grey),
            Expanded(
              child: Container(
                margin: EdgeInsets.only(left: 2),
                padding: EdgeInsets.only(left: 5),
                child: IconButton(
                    icon: Icon(Icons.filter_alt),
                    onPressed: () async {
                      filterBottomView(context);
                    }),
              ),
            ),
          ],
        ),
      ),
    );
  }

  onSearchTextChanged(String text) async {
    showLoaderText = Constants.LOADING;
    if (text.isEmpty) {
      isSearchForParams = false;
      loadOrders("");
    } else {
      isSearchForParams = true;

      loadOrders(text);
    }
  }

  listRow(int index) {
    if (_transactionsList[index].seller!.id == buId) {
      transactionName = _transactionsList[index].buyer!.name;
    }

    if (_transactionsList[index].ctrDetails != null &&
        _transactionsList[index].ctrDetails!.type == Constants.CTR1) {
      transactionStatus = _transactionsList[index].status;
    } else {
      transactionStatus = _transactionsList[index].status;
    }

    return Card(
      elevation: 2.5,
      color: Colors.white,
      shadowColor: AppTheme.theme.colorScheme.primary, //Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(5),
        // side: BorderSide(color: AppTheme.theme.colorScheme.primary)
      ),
      child: Container(
        padding: EdgeInsets.only(left: 10.0, top: 8.0, bottom: 8.0),
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                "$transactionName",
                style: TextStyle(
                    color: AppTheme.theme.colorScheme
                        .primary, //Color(Constants.APP_COLOR),
                    fontSize: 15.0,
                    fontWeight: StyleView.fontSemiBold),
              ),
              FxSpacing.height(3.0),
              FxSpacing.height(3.0),
              Text(
                "${_transactionsList[index].offerDetails!.productDetails!.length} items",
                style: TextStyle(
                    color: Color(0xFF282828), //Color(Constants.APP_COLOR),
                    fontSize: 12.5,
                    fontWeight: StyleView.fontMedium),
              ),
              FxSpacing.height(5.0),
              Row(
                children: [
                  Icon(Icons.date_range_sharp,
                      size: 15.0,
                      color: CommonMethods.transactionStatusColorHandling(
                          status) //Color(0xFF282828),
                      ),
                  FxSpacing.width(3.0),
                  Text(
                    AppUtills.getISTTime(
                        _transactionsList[index].modifiedDate.toString()),
                    style: TextStyle(
                        color: Color(0xFF282828), //Color(Constants.APP_COLOR),
                        fontSize: 12.5,
                        fontWeight: StyleView.fontMedium),
                  ),
                ],
              ),
              this.showTransactionType(
                  _transactionsList[index].transactionType),
            ]),
      ),
    );
  }

  Widget transactionTypeView(String? text) {
    return Container(
      margin: EdgeInsets.only(top: 5.0),
      child: Text(text!,
          style: TextStyle(
            color: Colors.orange,
            fontSize: StyleView.FONT_SIZE_13,
          )),
    );
  }

  showTransactionType(String? transactionType) {
    if (transactionType == "retail") {
      return this.transactionTypeView("Retail Transaction");
    } else if (transactionType == "transaction" ||
        transactionType == "wholesale_invoice" ||
        transactionType == "wholesale_quotation") {
      return this.transactionTypeView("B2B customer transaction");
    } else {
      return this.transactionTypeView("Pending");
    }
  }

  Widget _listViewData() {
    if (isLoadingProgress) {
      return Expanded(child: ListLoader());
    } else if (!isLoadingProgress && _transactionsList.length == 0) {
      return Expanded(
          child: Center(
        child: new Text(Language().getString(showLoaderText, selectedLang)),
      ));
    } else {
      return Expanded(
        child: Container(
            child: AnimationLimiter(
          child: ListView.separated(
            controller: _scrollController,
            physics: const BouncingScrollPhysics(
                parent: AlwaysScrollableScrollPhysics()),
            shrinkWrap: true,
            separatorBuilder: (context, index) => Divider(
              height: 5.0,
              color: Colors.transparent,
            ),
            itemBuilder: (BuildContext ctxt, int index) {
              return AnimationConfiguration.staggeredList(
                position: index,
                // duration: Duration(milliseconds: 500),
                child: SlideAnimation(
                  verticalOffset: 50.0,
                  child: FadeInAnimation(
                    child: Stack(
                      children: [
                        InkWell(
                            onTap: () {
                              CommonMethods.hideKeyboard(context);
                              Navigator.push(
                                  context,
                                  PageTransition(
                                      context: context,
                                      page: OrderFormDetailsPage(
                                        orderFormId:
                                            _transactionsList[index].id_new,
                                        transactionName: transactionName,
                                      ))).then((value) => {});
                            },
                            child: Container(child: listRow(index))),
                        if (_transactionsList[index].status ==
                            Constants.PAYMENT_RESOLVED)
                          Positioned(
                              right: 10,
                              top: MediaQuery.of(context).size.height * 0.02,
                              child: Icon(
                                Icons.check_circle,
                                color: Colors.green,
                                size: 19.0,
                              ))
                      ],
                    ),
                  ),
                ),
              );
            },
            itemCount: _transactionsList.length,
          ),
        )),
      );
    }
  }

  renderTotalOrdersCount() {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 5),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(5.0),
      ),
      child: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: Container(
                    margin: EdgeInsets.symmetric(vertical: 5.0),
                    child: Text(
                      Language().getString("Total Orders", selectedLang),
                      style: TextStyle(
                          color: Color(Constants.APP_COLOR),
                          fontSize: 15.0,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                Expanded(
                  // flex: 2,
                  child: Container(
                    margin: EdgeInsets.symmetric(horizontal: 5.0),
                    child: Text(
                      " : ${totalOrders}",
                      style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                        fontSize: 15.0,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget renderStatusFilterView(StateSetter setState) {
    return Column(
      children: [
        Container(
          child: Row(
            children: [
              Radio(
                  materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  value: Constants.PENDING_C,
                  groupValue: selectedStatusFilter,
                  activeColor: Color(Constants.APP_COLOR),
                  onChanged: (dynamic selectedValue) {
                    setState(() {
                      selectedStatusFilter = selectedValue;
                    });
                  }),
              Text(
                Language().getString(Constants.PENDING, selectedLang),
              )
            ],
          ),
        ),
        Container(
          child: Row(
            children: [
              Radio(
                  materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  value: Constants.COMPLETED_C,
                  groupValue: selectedStatusFilter,
                  activeColor: Color(Constants.APP_COLOR),
                  onChanged: (dynamic selectedValue) {
                    setState(() {
                      selectedStatusFilter = selectedValue;
                    });
                  }),
              Text(
                Language().getString(Constants.COMPLETED, selectedLang),
              )
            ],
          ),
        ),
      ],
    );
  }

  Widget renderTypeFilterView(StateSetter setState) {
    return Column(
      children: [
        Container(
          child: Row(
            children: [
              Radio(
                  materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  value: "retail",
                  groupValue: selectedTypeFilter,
                  activeColor: Color(Constants.APP_COLOR),
                  onChanged: (dynamic selectedValue) {
                    setState(() {
                      selectedTypeFilter = selectedValue;
                    });
                  }),
              Text(
                Language().getString("Retail", selectedLang),
              )
            ],
          ),
        ),
        Container(
          child: Row(
            children: [
              Radio(
                  materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  value: "wholesale_invoice",
                  groupValue: selectedTypeFilter,
                  activeColor: Color(Constants.APP_COLOR),
                  onChanged: (dynamic selectedValue) {
                    setState(() {
                      selectedTypeFilter = selectedValue;
                    });
                  }),
              Text(
                Language().getString(Constants.TRANSACTIONS_STR, selectedLang),
              )
            ],
          ),
        ),
        Container(
          child: Row(
            children: [
              Radio(
                  materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  value: "wholesale_quotation",
                  groupValue: selectedTypeFilter,
                  activeColor: Color(Constants.APP_COLOR),
                  onChanged: (dynamic selectedValue) {
                    setState(() {
                      selectedTypeFilter = selectedValue;
                    });
                  }),
              Text(
                Language().getString(Constants.QUOTATION, selectedLang),
              )
            ],
          ),
        ),
      ],
    );
  }

  Widget showRadiobuttonsView(StateSetter setState) {
    return Row(children: [
      Container(
        child: Row(
          children: [
            Radio(
                value: "Status",
                activeColor: Color(Constants.APP_COLOR),
                groupValue: radioButtonValue,
                onChanged: (dynamic value) {
                  setState(() {
                    radioButtonValue = value;
                  });
                }),
            Text(
              "Status",
              style: TextStyle(fontWeight: StyleView.fontSemiBold),
            ),
          ],
        ),
      ),
      Container(
        child: Row(
          children: [
            Radio(
              value: "Type",
              activeColor: Color(Constants.APP_COLOR),
              groupValue: radioButtonValue,
              onChanged: (dynamic value) {
                setState(() {
                  radioButtonValue = value;
                });
              },
            ),
            Text(
              "Type",
              style: TextStyle(fontWeight: StyleView.fontSemiBold),
            ),
          ],
        ),
      ),
    ]);
  }

  void filterBottomView(context) {
    showModalBottomSheet(
        transitionAnimationController: _animationController,
        isScrollControlled: true,
        backgroundColor: Colors.white,
        barrierColor: Colors.black54,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20.0),
                topRight: Radius.circular(20.0))),
        context: context,
        builder: (BuildContext buildContext) {
          return StatefulBuilder(
            builder: (BuildContext context,
                void Function(void Function()) setState) {
              return Padding(
                padding: const EdgeInsets.all(8.0),
                child: ListView(
                  shrinkWrap: true,
                  children: [
                    Column(children: [
                      Container(
                        width: MediaQuery.of(context).size.width * 0.25,
                        height: 3,
                        color: Colors.grey,
                      ),
                      showRadiobuttonsView(setState),
                      // dateFilterView(),
                      FxSpacing.height(5.0),
                      (radioButtonValue == "Status")
                          ? this.renderStatusFilterView(setState)
                          : this.renderTypeFilterView(setState),
                      // FxSpacing.height(10.0),
                      // this.showTransactionStatus(),
                      // FxSpacing.height(10.0),
                      // this.showTransactionTypeView(setState)
                    ]),
                    FxSpacing.height(10.0),
                    Container(
                      padding: EdgeInsets.only(bottom: 10),
                      child: CommonButtonsView(
                          context: context,
                          b1Text: Language()
                              .getString(Constants.STR_CANCEL, selectedLang),
                          b2Text: Language()
                              .getString(Constants.APPLY_FILTER, selectedLang),
                          onb1Action: () => {Navigator.of(context).pop()},
                          onb2Action: () {
                            setState(() {
                              isShowFloatButton = true;
                            });
                            loadOrders("");
                            Navigator.of(context).pop();
                          }),
                    )
                  ],
                ),
              );
            },
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
      body: Stack(
        children: [
          WillPopScope(
            child: SafeArea(
              child: Scaffold(
                  key: _scaffoldkey,
                  backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                  appBar: AppBar(
                    backgroundColor:
                        Colors.transparent, //(Constants.APP_COLOR),
                    centerTitle: true,
                    elevation: 0,
                    iconTheme: IconThemeData(color: theme.colorScheme.primary),
                    title: AppbarName(
                        title: Language()
                            .getString(Constants.ORDERS, selectedLang),
                        buName: "$buName"),
                    actions: [],
                  ),
                  floatingActionButton: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        if (isShowFloatButton)
                          SizedBox(
                            width: 5,
                          ),
                        if (isShowFloatButton)
                          FloatingActionButton(
                              backgroundColor: theme.colorScheme.primary,
                              onPressed: () {
                                setState(() {
                                  isShowFloatButton = false;
                                  isLoadingProgress = true;
                                  _searchController.clear();
                                  _fromDateController.text = startDate;
                                  _toDateController.text = endDate;
                                  selectedStatusFilter = "";
                                  selectedTypeFilter = "";
                                  radioButtonValue = "";
                                });
                                loadOrders("");
                              },
                              child: Text(
                                Language().getString(
                                    Constants.CLEAR_FILTERS, selectedLang),
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 11.0,
                                    fontWeight: StyleView.fontSemiBold),
                              ))
                      ],
                    ),
                  ),
                  drawer: MyDrawer(),
                  body: Container(
                      margin: EdgeInsets.only(left: 5, right: 5, top: 20),
                      child: Column(
                        children: [
                          searchFilterView(),
                          Container(
                            padding: EdgeInsets.symmetric(
                                vertical: 10, horizontal: 5),
                            child: DateFilterUtill(
                              isShowSearchButton: true,
                              fromDate: "",
                              toDate: "",
                              fromDateController: _fromDateController,
                              toDateController: _toDateController,
                              onFromDateSelected: (value) {
                                setState(
                                    () => _fromDateController.text = value);
                              },
                              onToDateSelected: (value) {
                                setState(() => _toDateController.text = value);
                              },
                              onSearchParms: () {
                                setState(() {
                                  isShowFloatButton = true;
                                  isLoadingProgress = true;
                                });

                                loadOrders("");
                              },
                            ),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          renderTotalOrdersCount(),
                          _listViewData(),
                        ],
                      ))),
            ),
            onWillPop: () {
              return CommonMethods.onBackPress(context).then((value) => value);
            },
          ),
          AppUtills.showLoadingView(
              context: context,
              message: Language().getString(progressMessage, selectedLang),
              isLoading: isLoadingProgress),
        ],
      ),
    );
  }

  @override
  void setState(VoidCallback fn) {
    if (mounted) {
      super.setState(fn);
    }
  }
}
