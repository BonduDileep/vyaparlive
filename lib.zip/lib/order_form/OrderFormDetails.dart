import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:vyaparlive/Transaction/ListOfTransactions.dart';
import 'package:vyaparlive/components/TransactionDetailsView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/offline_connections/FillOrderForm.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:vyaparlive/retailer_view/RetailProductsSelection.dart';
import 'package:vyaparlive/retailer_view/component/RetailCustomerInvoicePrintView.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Transaction/card_view/ProductCardDesign.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/ModelProduct.dart';
import 'package:vyaparlive/model/TransactionsModel.dart';
import 'package:vyaparlive/model/transaction/ProductDetailsModel.dart';
import 'package:vyaparlive/model/transaction/TransactionPendingProducts.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/service/bu_list_grpc_service.dart';

class OrderFormDetailsPage extends StatefulWidget {
  final String? orderFormId;
  final String? transactionName;

  OrderFormDetailsPage({this.orderFormId, this.transactionName});
  @override
  _OrderFormDetailsPageState createState() => _OrderFormDetailsPageState();
}

class _OrderFormDetailsPageState extends State<OrderFormDetailsPage> {
  String? buName = "";
  String? buId = "";
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();

  List<TransactionsModel> _transactionsList = [];
  bool checkBoxValue = false;
  List<ModelProduct> selectedList = [];
  List<ProductDetails> _responsePrducts = [];
  List<ProductDetails> _productsList = [];
  List<Product> _invoiceProducts = [];
  List<ModelProduct> qntyFilterProducts = [];

  int productQunatiy = 0;
  bool isInvoiceButtionEnable = true;
  String? choice;
  String termType = "connection";
  bool isYourTransactionbuyer = false;
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  late BuListGrpcService _transactionService;
  List<TransactionPendingProducts> pendingProductsList = [];
  String? selectedLang = AppController.instance.getSelectedlanguage; // 'en';
  late SharedPreferences sharedPreferences;
  late ThemeData theme;
  String? imageRelativePath = '';

  String transactionName = "";
  String transactionDate = "";
  DateFormat formatter = DateFormat("yyyy-MM-dd");
  List<Map> _namesData = [];

  @override
  void initState() {
    super.initState();
    getLoadLanguage();
    theme = AppTheme.vyaparTheme;
    _transactionService = BuListGrpcService();
    buName = AppController.instance.getBuName;
    buId = AppController.instance.getMyBuId;
    loadOrderFormDataData();
  }

  getLoadLanguage() async {
    setState(() {
      _namesData = [
        {"name": Language().getString(Constants.NAME_STRING, selectedLang)},
        {"name": Language().getString(Constants.ORDER_ID_STR, selectedLang)},
        {"name": Language().getString(Constants.ORDER_DATE_STR, selectedLang)}
      ];
    });
  }

  loadOrderFormDataData() async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
      });

      await this.getAllDiscussionData().then((value) {
        setState(() {
          _transactionsList.addAll(value);
          if (_transactionsList.isEmpty) {
            return;
          }
          if (_transactionsList[0].isOffline!) {
            isYourTransactionbuyer = false;
          } else {
            if (_transactionsList[0].buyer!.id == buId) {
              isYourTransactionbuyer = true;
            }
          }

          if (_transactionsList[0].buyer!.id == buId) {
            transactionName =
                _transactionsList[0].seller!.name! + " ( Seller )";
          } else {
            transactionName = _transactionsList[0].buyer!.name! + " ( Buyer )";
          }
          transactionDate =
              formatter.format(_transactionsList[0].transactionDate!);

          if (_transactionsList[0].offerDetails != null) {
            ///  Buyer Ordered products
            _responsePrducts
                .addAll(_transactionsList[0].offerDetails!.productDetails!);
          }

          selectedList.addAll(
              _transactionsList[0].offerDetails!.productDetails!.map((e) {
            return ModelProduct(
                id: e.productId,
                name: e.productName,
                quantity: e.quantity,
                counter: e.quantity?.toInt(),
                counterNew: e.quantity,
                price: e.priceUnit,
                quantityIn: e.quantityIn,
                isItemSelected: true,
                batchPriceList: e.batchPricingList);
          }).toList());
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  serviceCallUpdateOrderFormStatus(String type) async {
    setState(() {
      isLoadingProgress = true;
    });

    String body =
        json.encode({"buId": buId, "id": widget.orderFormId, "type": type});

    var response = await _transactionService
        .updateOrderForm(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var action = Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          "Assigned successfully",
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
      action.then((value) {
        loadOrderFormDataData();
      });
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  Future<String?> showChoiceDialog(BuildContext context) {
    String? selectedOption;
    String? selectedWholesaleOption;

    return showDialog<String>(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(8)),
              ),
              title: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Align(
                    alignment: Alignment.topRight,
                    child: GestureDetector(
                      onTap: () => Navigator.of(context).pop(),
                      child: const Icon(Icons.close, color: Colors.red),
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      Constants.GENERATE_INVOICE_FOR,
                      style:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                  ),
                ],
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // RETAIL
                  RadioListTile<String>(
                    title: const Text("Retail"),
                    value: "retail",
                    groupValue: selectedOption,
                    onChanged: (value) {
                      setState(() {
                        selectedOption = value;
                        selectedWholesaleOption =
                            null; // reset wholesale options
                      });
                    },
                  ),

                  // WHOLESALE
                  RadioListTile<String>(
                    title: const Text("Wholesale"),
                    value: "wholesale",
                    groupValue: selectedOption,
                    onChanged: (value) {
                      setState(() {
                        selectedOption = value;
                      });
                    },
                  ),

                  // SHOW NESTED OPTIONS WHEN WHOLESALE SELECTED
                  if (selectedOption == "wholesale") ...[
                    Padding(
                      padding: const EdgeInsets.only(left: 40.0),
                      child: Column(
                        children: [
                          RadioListTile<String>(
                            title: const Text(Constants.GENERATE_INVOICE),
                            value: "wholesale_invoice",
                            groupValue: selectedWholesaleOption,
                            onChanged: (value) {
                              setState(() {
                                selectedWholesaleOption = value;
                              });
                            },
                          ),
                          RadioListTile<String>(
                            title: const Text(Constants.GENERATE_QUOTATION),
                            value: "wholesale_quotation",
                            groupValue: selectedWholesaleOption,
                            onChanged: (value) {
                              setState(() {
                                selectedWholesaleOption = value;
                              });
                            },
                          ),
                        ],
                      ),
                    )
                  ],

                  const SizedBox(height: 10),

                  CommonButtonsView(
                    context: context,
                    b1Text: "",
                    b2Text:
                        Language().getString(Constants.CONTINUE, selectedLang),
                    onb2Action: () {
                      if (selectedOption == null) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                              content: Text("Please select an option")),
                        );
                        return;
                      }

                      // Retail case
                      if (selectedOption == "retail") {
                        // Navigator.of(context).pop("retail");

                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => RetailProductsSelection(
                                      selectedProducts: selectedList,
                                      retailerData: _transactionsList[0].buyer,
                                      isFromOrderForm: true,
                                      orderFormId: widget.orderFormId,
                                    ))).then((value) {
                          loadOrderFormDataData();
                        });
                        return;
                      }

                      // Wholesale case: must pick sub-option
                      if (selectedOption == "wholesale" &&
                          selectedWholesaleOption == null) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                              content:
                                  Text("Please select a wholesale option")),
                        );
                        return;
                      }

                      // Return wholesale sub-option
                      Navigator.of(context).pop(selectedWholesaleOption);
                    },
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  handleBottomButtons() {
    return Container(
      padding: EdgeInsets.only(left: 10.0, right: 10, bottom: 30),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          _transactionsList.isNotEmpty
              ? this.showOrderStatusBottom()
              : Container(),
          (_transactionsList.isNotEmpty &&
                  _transactionsList[0].assignedOrderType!.isEmpty)
              ? this.generateOfflineInvoiceView()
              : InkWell(
                  onTap: () {
                    if (_transactionsList[0]
                        .assignedOrderType!
                        .contains("wholesale")) {
                      Navigator.push(
                        context,
                        PageTransition(
                            context: context,
                            page: ListOfTransactionsPage(
                              transactionId: _transactionsList[0].transactionId,
                            )),
                      );
                    } else if (_transactionsList[0].assignedOrderType ==
                        'retail') {
                      Navigator.push(
                          context,
                          PageTransition(
                              context: context,
                              page: RetailCustomerInvoicePrintView(
                                invoiceNo: null,
                                buyerName: _transactionsList[0].buyer!.name,
                                invoiceId: _transactionsList[0].retailId,
                              )));
                    }
                  },
                  child: Container(
                    child: Text(
                      "View Details",
                      style: TextStyle(
                              color: theme.colorScheme.primary,
                              fontSize: 16.0,
                              fontWeight: StyleView.fontSemiBold)
                          .copyWith(decoration: TextDecoration.underline),
                    ),
                  ),
                )
        ],
      ),
    );
  }

  generateOfflineInvoiceView() {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
          backgroundColor: theme.colorScheme.primary,
          elevation: 0),
      onPressed: () {
        showChoiceDialog(context).then((selectedOption) {
          if (selectedOption == null || selectedOption.isEmpty) {
            return;
          }
          if (selectedOption == 'wholesale_invoice') {
            // serviceCallUpdateOrderFormStatus(selectedOption);\
            Navigator.push(
              context,
              PageTransition(
                context: context,
                page: FillOrderForm(
                  contactName: _transactionsList[0].buyer!.name,
                  recordId: _transactionsList[0].buyer!.id,
                  selectedProducts: selectedList,
                  orderFormId: widget.orderFormId,
                ),
              ),
            ).then((onValue) {
              loadOrderFormDataData();
            });
          } else if (selectedOption == 'wholesale_quotation') {
            Navigator.push(
              context,
              PageTransition(
                context: context,
                page: FillOrderForm(
                  contactName: _transactionsList[0].buyer!.name,
                  recordId: _transactionsList[0].buyer!.id,
                  selectedProducts: selectedList,
                  orderFormId: widget.orderFormId,
                  isQuotation: true,
                  fromCreateTransaction: true,
                ),
              ),
            ).then((onValue) {
              loadOrderFormDataData();
            });
            ;
          }
        });
      },
      child: Text(
        Language().getString(Constants.ACCEPT_STRING, selectedLang),
        style: TextStyle(
          color: Colors.white,
        ),
      ),
    );
  }

  getOrderStatusText() {
    if (_transactionsList.isEmpty ||
        _transactionsList[0].assignedOrderType!.isEmpty) {
      return "Pending";
    } else if (_transactionsList[0].assignedOrderType == "wholesale_invoice") {
      return "Transaction Invoice Generated";
    } else if (_transactionsList[0].assignedOrderType ==
        "wholesale_quotation") {
      return "Quotation Generated";
    } else if (_transactionsList[0].assignedOrderType == "retail") {
      return "Retail Invoice Generated";
    } else {
      return _transactionsList[0].assignedOrderType!;
    }
  }

  showOrderStatusBottom() {
    if (_transactionsList.isEmpty) {
      return Container();
    } else {
      return Container(
        child: Row(
          children: <Widget>[
            Text(
              Language().getString(Constants.STATUS_STRING, selectedLang) +
                  " : ",
              style:
                  TextStyle(fontSize: 15.0, fontWeight: StyleView.fontSemiBold),
            ),
            Text(
              getOrderStatusText(),
              style: TextStyle(
                  fontSize: 14.0,
                  color: Colors.green,
                  fontWeight: StyleView.fontMedium),
            )
          ],
        ),
      );
    }
  }

  orderAcceptDialog(String status, String message) {
    return showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) {
          return AlertDialog(
            title: Text(Language().getString(Constants.MESSAGE, selectedLang)),
            content: Text(status == Constants.ORDER_ACCEPTED
                ? Language().getString(Constants.ORDER_ACCEPTED, selectedLang) +
                    ".\n" +
                    Language().getString(
                        Constants.PLEASE_GENERATE_INVOICE, selectedLang)
                : Language().getString(Constants.ORDER_REJECTED, selectedLang)),
            actions: <Widget>[
              TextButton(
                onPressed: () {},
                child:
                    Text(Language().getString(Constants.OKAY_STR, selectedLang),
                        style: TextStyle(
                          color: Color(Constants.APP_COLOR),
                          fontSize: 18.0,
                        )),
              )
            ],
          );
        });
  }

  @override
  void setState(VoidCallback fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
      body: Stack(
        children: [
          SafeArea(
            child: Scaffold(
              key: _scaffoldkey,
              backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
              appBar: AppBar(
                backgroundColor: Colors.transparent, //(Constants.APP_COLOR),
                centerTitle: true,
                elevation: 0,
                iconTheme: IconThemeData(color: theme.colorScheme.primary),
                title: AppbarName(
                    title: Language()
                        .getString(Constants.ORDER_DETAILS, selectedLang),
                    buName: "$buName"),
                actions: [
                  // AppUtills.homeButton(context),
                ],
              ),
              bottomNavigationBar: (_transactionsList.length == 0) ||
                      (_transactionsList[0].offerDetails != null)
                  ? handleBottomButtons()
                  : null,
              body: Container(
                padding: EdgeInsets.all(10.0),
                child: Column(
                  children: [
                    if (_transactionsList.length > 0)
                      TransactionDetailsViewPage(
                        transactionName: transactionName,
                        transactionId: _transactionsList[0].id_new,
                        transactionDate:
                            _transactionsList[0].transactionDate.toString(),
                        namesData: _namesData,
                      ),
                    SizedBox(height: 5.0),
                    _responsePrducts.length > 0
                        ? this.showBuyerView()
                        : Center(
                            child: Text(Language().getString(
                                Constants.NO_DATA_FOUND, selectedLang)),
                          ),
                  ],
                ),
              ),
            ),
          ),
          AppUtills.showLoadingView(
              context: context,
              message: Language().getString(progressMessage, selectedLang),
              isLoading: isLoadingProgress),
        ],
      ),
    );
  }

  showBuyerView() {
    return Container(
      child: ListView.separated(
          shrinkWrap: true,
          itemBuilder: (context, index) {
            return ProductCardDesignView(
              strTotalAmount:
                  Language().getString(Constants.TOTAL_AMOUNT, selectedLang),
              strUnitPrice:
                  Language().getString(Constants.PRICE_UNIT, selectedLang),
              strQuantity:
                  Language().getString(Constants.QUANTITY, selectedLang),
              strOfferApplied:
                  Language().getString(Constants.OFFER_APPLIED, selectedLang),
              productImage: _responsePrducts[index].productImage,
              productName: _responsePrducts[index].productName,
              productPrice: _responsePrducts[index].totalPrice,
              productQnty: _responsePrducts[index].quantity,
              isFromPO: true,
              quantityIn: _responsePrducts[index].quantityIn,
              isShowOffer: _responsePrducts[index].offerSelected,
            );
          },
          separatorBuilder: (context, index) => new Divider(height: 0.0),
          itemCount: _responsePrducts.length),
    );
  }

  Future<List<TransactionsModel>> getAllDiscussionData() async {
    _transactionsList.clear();
    qntyFilterProducts.clear();
    selectedList.clear();
    _productsList.clear();
    _invoiceProducts.clear();
    _responsePrducts.clear();
    // String body = json.encode({"id": widget.orderFormId});

    String body = json.encode({
      "buId": buId,
      "filters": {"id": widget.orderFormId}
    });

    var response = await _transactionService
        .getAllOrders(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<TransactionsModel> _discussionsData = [];

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(resObj)) {
        var resultArray = [];
        resultArray = resObj["result"];
        if (resultArray.isNotEmpty)
          _discussionsData.add(TransactionsModel.fromJson(resultArray[0]));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }

    return _discussionsData;
  }
}
