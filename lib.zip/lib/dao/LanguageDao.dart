class LanguageDao {
  String? english;
  String? hindi;
  String? telugu;

  // Map<String, dynamic> get map {
  //   return {'en': english ?? '', 'hi': hindi ?? '', 'ti': telugu ?? ''};
  // }

  LanguageDao({this.english, this.hindi, this.telugu});
}
