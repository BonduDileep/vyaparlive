import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/login_view/controller/forgotPassword_controller.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:flutter/material.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'package:flutter_otp_text_field/flutter_otp_text_field.dart';
import 'package:flutx/flutx.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/login_view/LoginPage.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/service/user_services.dart';
import 'package:vyaparlive/utills/SharePref.dart';

import '../service/Service.dart';

class UpdatePasswordPage extends StatefulWidget {
  final String? validationText;
  UpdatePasswordPage({this.validationText});
  @override
  _UpdatePasswordPageState createState() => _UpdatePasswordPageState();
}

class _UpdatePasswordPageState extends State<UpdatePasswordPage>
    with TickerProviderStateMixin {
  String? buName = "";
  String? regMobileNumber = "";
  final currentPasswordController = TextEditingController();
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  bool mobileNumberError = false;
  bool newPasswordError = false;
  bool currentPasswordError = false;
  bool confirmPasswordError = false;
  bool otpErrorMessage = false;
  bool confirmPasswordMismatchError = false;
  bool hideCurrentPassword = true;
  bool hideOTPVisible = true;
  bool hideNewPassword = true;
  bool hideConfirmPassword = true;
  bool isLoadingProgress = false;
  String progressMessage = Constants.UPDATING;
  late UserService _userService;
  late ForgotPasswordController _controller;
  late ThemeData theme;
  late FocusNode _mobileFocusNode;
  late FocusNode _passwordFocusNode;
  late FocusNode _confirmFocusNode;
  late FocusNode _otpFocusNode;
  late AnimationController _animationController;
  late Service _service;
  String verificationCode = "";
  @override
  void initState() {
    super.initState();
    initBottomSheetAnimation();
    _service = new Service();
    _mobileFocusNode = FocusNode();
    _passwordFocusNode = FocusNode();
    _confirmFocusNode = FocusNode();
    _otpFocusNode = FocusNode();
    theme = AppTheme.vyaparTheme;

    _controller = FxControllerStore.putOrFind(ForgotPasswordController());
    _userService = UserService();
    buName = AppController.instance.getBuName;
    if (widget.validationText == Constants.UPDATE_PASSWORD) {
      SharePref().getPhoneNumber().then((value) {
        regMobileNumber = value;
        _controller.mobileNumber.text = regMobileNumber!;
      });
    }
  }

  initBottomSheetAnimation() {
    _animationController = BottomSheet.createAnimationController(this);
    _animationController.duration =
        const Duration(milliseconds: Constants.bottomSheet_duration);
    _animationController.reverseDuration =
        const Duration(milliseconds: Constants.bottomSheet_reverse_duration);
    _animationController.drive(CurveTween(curve: Curves.easeIn));
  }

  currentPasswordView() {
    if (widget.validationText == Constants.UPDATE_PASSWORD) {
      return Container(
          margin: EdgeInsets.only(top: 20),
          child: currentPasswordTextField(
              Language().getString("Current Password", selectedLang)));
    } else {
      return SizedBox();
    }
  }

  Widget _buildBody() {
    return AppBackgroundView(
        body: Stack(children: [
      SafeArea(
        child: Scaffold(
          backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
          appBar: AppBar(
              backgroundColor: Colors.transparent,
              elevation: 0.0,
              centerTitle: true,
              iconTheme: IconThemeData(color: theme.colorScheme.primary),
              title: AppbarName(
                  title:
                      Language().getString(widget.validationText!, selectedLang),
                  buName: buName)),
          body: SingleChildScrollView(
            child: Container(
              margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 20.0),
              child: Column(
                children: [
                  FxSpacing.height(20),
                  mobileNumberField(Constants.ENTER_REGISTERED_MOBILE_NUMBER),
                  // otpTextField(Constants.ENTER_OTP),
                  currentPasswordView(),
                  if (widget.validationText == Constants.UPDATE_PASSWORD)
                    Container(
                        child: Column(children: [
                      FxSpacing.height(20),
                      passwordTextField(Language()
                          .getString(Constants.ENTER_PASSWORD, selectedLang)),
                      FxSpacing.height(20),
                      confirmPasswordTextField(Language().getString(
                          Constants.ENTER_CONFIRM_PASSWORD, selectedLang)),
                      FxSpacing.height(20.0),
                    ])),
                  bottomView(),
                ],
              ),
            ),
          ),
        ),
      ),
      AppUtills.showLoadingView(
          context: context,
          message: Language().getString(progressMessage, selectedLang),
          isLoading: isLoadingProgress),
    ]));
  }

  TextFormField mobileNumberField(String text) {
    return TextFormField(
      style: TextStyle(fontWeight: StyleView.fontMedium, fontSize: 15.0),
      controller: _controller.mobileNumber,
      focusNode: _mobileFocusNode,
      textInputAction: TextInputAction.next,
      keyboardType: TextInputType.number,
      decoration: CommonMethods.textFieldDecorationTheme(text,
          prefixIcon: FeatherIcons.phone),
      onEditingComplete: () {
        _mobileFocusNode.unfocus();
        if (widget.validationText == Constants.FORGOT_PASSWORD_STRING) {
          FocusScope.of(context).requestFocus(_otpFocusNode);
        } else {
          FocusScope.of(context).requestFocus(_passwordFocusNode);
        }
      },
      maxLength: 10,
      onChanged: (value) => onChangedText(value, text),
    );
  }

  Widget otpTextField(String text) {
    return Container(
      margin: EdgeInsets.only(top: 20),
      child: TextFormField(
        style: TextStyle(fontWeight: StyleView.fontMedium, fontSize: 15.0),
        controller: _controller.otp,
        focusNode: _otpFocusNode,
        textInputAction: TextInputAction.next,
        keyboardType: TextInputType.number,
        maxLength: 4,
        decoration: CommonMethods.textFieldDecorationTheme(text,
            prefixIcon: FeatherIcons.link),
        onEditingComplete: () {
          // c.unfocus();
          _otpFocusNode.unfocus();
          // FocusScope.of(context).requestFocus(_passwordFocusNode);
        },
        onChanged: (value) => onChangedText(value, text),
      ),
    );
  }

  TextFormField currentPasswordTextField(String text) {
    return TextFormField(
      style: TextStyle(fontWeight: StyleView.fontMedium, fontSize: 15.0),
      controller: _controller.currentPassword,
      // focusNode: _confirmFocusNode,
      obscureText: hideCurrentPassword,
      textInputAction: TextInputAction.next,
      keyboardType: TextInputType.visiblePassword,
      decoration: CommonMethods.textFieldDecorationTheme(text,
          prefixIcon: FeatherIcons.lock,
          sufixIcon: IconButton(
              onPressed: () {
                setState(() {
                  hideCurrentPassword = !hideCurrentPassword;
                });
              },
              icon: (hideCurrentPassword)
                  ? Icon(Icons.visibility_off)
                  : Icon(Icons.visibility))),
      onEditingComplete: () {
        // c.unfocus();
        FocusScope.of(context).requestFocus(_passwordFocusNode);
      },
      onChanged: (value) => onChangedText(value, text),
    );
  }

  TextFormField passwordTextField(String text) {
    return TextFormField(
      style: TextStyle(fontWeight: StyleView.fontMedium, fontSize: 15.0),
      controller: _controller.password,
      focusNode: _passwordFocusNode,
      obscureText: hideNewPassword,
      textInputAction: TextInputAction.next,
      keyboardType: TextInputType.visiblePassword,
      decoration: CommonMethods.textFieldDecorationTheme(text,
          prefixIcon: FeatherIcons.lock,
          sufixIcon: IconButton(
              onPressed: () {
                setState(() {
                  hideNewPassword = !hideNewPassword;
                });
              },
              icon: (hideNewPassword)
                  ? Icon(Icons.visibility_off)
                  : Icon(Icons.visibility))),
      onEditingComplete: () {
        _passwordFocusNode.unfocus();
        // FocusScope.of(context).requestFocus(_confirmFocusNode);
      },
      onChanged: (value) => onChangedText(value, text),
    );
  }

  TextFormField confirmPasswordTextField(String text) {
    return TextFormField(
      style: TextStyle(fontWeight: StyleView.fontMedium, fontSize: 15.0),
      controller: _controller.confirmPassword,
      focusNode: _confirmFocusNode,
      obscureText: hideConfirmPassword,
      textInputAction: TextInputAction.done,
      keyboardType: TextInputType.visiblePassword,
      decoration: CommonMethods.textFieldDecorationTheme(text,
          prefixIcon: FeatherIcons.lock,
          sufixIcon: IconButton(
              onPressed: () {
                setState(() {
                  hideConfirmPassword = !hideConfirmPassword;
                });
              },
              icon: (hideConfirmPassword)
                  ? Icon(Icons.visibility_off)
                  : Icon(Icons.visibility))),
      onEditingComplete: () {
        _confirmFocusNode.unfocus();
        FocusScope.of(context).unfocus();
      },
      onChanged: (value) => onChangedText(value, text),
    );
  }

  @override
  void dispose() {
    _controller.password.clear();
    _controller.mobileNumber.clear();
    _controller.confirmPassword.clear();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FxBuilder<ForgotPasswordController>(
        controller: _controller, builder: (_controller) => _buildBody());
  }

  Widget bottomView() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 15.0, vertical: 10.0),
      child: CommonButtonsView(
        context: context,
        b1Text: widget.validationText == Constants.UPDATE_PASSWORD
            ? Language().getString(widget.validationText, selectedLang)
            : Language().getString(
                Constants.SEND_OTP, selectedLang), //Constants.CONFIRM_PASSWORD,
        b2Text: "",
        onb1Action: () {
          String value = this.validatingFields();
          if (value.isEmpty) {
            if (widget.validationText == Constants.UPDATE_PASSWORD) {
              this.serviceCallUpdatePassword();
            } else {
              sendOTPServiceCall();
            }
          } else {
            Dialogs.yesCancelDialog(
                context,
                Language().getString(Constants.ERROR, selectedLang),
                value,
                Language().getString(Constants.OKAY_STR, selectedLang),
                "",
                false);
          }
        },
      ),
    );
  }

  Future<void> sendOTPServiceCall() async {
    var mapData = {
      "contact": "+91 " + _controller.mobileNumber.text,
      "reference": "forgotpwd-otp"
    };

    String body = json.encode(mapData);

    http.Response response = await _service.sendOTP(body);

    if (response.statusCode == 200) {
      bottomSheetOTPCode();
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          "${response.body}",
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  onChangedText(String value, String textFieldName) {
    if (textFieldName == Constants.ENTER_REGISTERED_MOBILE_NUMBER &&
        _controller.mobileNumber.text.isNotEmpty) {
      setState(() {
        mobileNumberError = false;
      });
    } else if (textFieldName == Constants.ENTER_CURRENT_PASSWORD &&
        _controller.currentPassword.text.isNotEmpty) {
      setState(() {
        currentPasswordError = false;
      });
    } else if (textFieldName == Constants.ENTER_NEW_PASSWORD &&
        _controller.password.text.isNotEmpty) {
      setState(() {
        newPasswordError = false;
      });
    } else if (textFieldName == Constants.ENTER_CONFIRM_PASSWORD &&
        _controller.confirmPassword.text.isNotEmpty) {
      if (_controller.password.text == _controller.confirmPassword.text) {
        setState(() {
          confirmPasswordMismatchError = false;
          confirmPasswordError = false;
        });
      } else if (_controller.password.text !=
          _controller.confirmPassword.text) {
        setState(() {
          confirmPasswordMismatchError = true;
          confirmPasswordError = true;
        });
      } else {
        setState(() {
          confirmPasswordError = false;
        });
      }
    } else if (textFieldName == Constants.ENTER_CONFIRM_PASSWORD &&
        _controller.confirmPassword.text.isEmpty) {
      setState(() {
        confirmPasswordMismatchError = false;
        confirmPasswordError = false;
      });
    } else if (textFieldName == Constants.ENTER_OTP &&
        _controller.otp.text.isNotEmpty) {
      setState(() {
        otpErrorMessage = false;
      });
    } else {
      return null;
    }
  }

  String? errorText(String textFieldName) {
    if (textFieldName == Constants.ENTER_REGISTERED_MOBILE_NUMBER &&
        mobileNumberError) {
      return Constants.PLEASE_ENTER_REGISTERED_MOBILE_NUMBER;
    } else if (textFieldName == Constants.ENTER_CURRENT_PASSWORD &&
        currentPasswordError) {
      return Constants.PLEASE_ENTER_CURRENT_PASSWORD;
    } else if (textFieldName == Constants.ENTER_NEW_PASSWORD &&
        newPasswordError) {
      return Constants.PLEASE_ENTER_NEW_PASSWORD;
    } else if (textFieldName == Constants.ENTER_CONFIRM_PASSWORD &&
        confirmPasswordError) {
      if (confirmPasswordError && confirmPasswordMismatchError) {
        return Constants.CONFIRM_PASSWORD_MIS_MATCHED;
      } else {
        return Constants.PLEASE_ENTER_CONFIRM_PASSWORD;
      }
    } else if (textFieldName == Constants.ENTER_OTP && otpErrorMessage) {
      return Constants.PLEASE_ENTER_OTP;
    } else {
      return null;
    }
  }

  validatingFields() {
    String errorText = '';
    if (widget.validationText == Constants.FORGOT_PASSWORD_STRING) {
      if (_controller.mobileNumber.text.isEmpty ||
          _controller.mobileNumber.text.length < 9) {
        return errorText = Constants.ENTER_REGISTERED_MOBILE_NUMBER;
      }

      return errorText;
    }

    if (_controller.mobileNumber.text.isEmpty ||
        _controller.mobileNumber.text.length < 9) {
      return errorText = Constants.ENTER_REGISTERED_MOBILE_NUMBER;
    }

    if (widget.validationText == Constants.UPDATE_PASSWORD &&
        _controller.currentPassword.text.isEmpty) {
      return errorText = Constants.PLEASE_ENTER_CURRENT_PASSWORD;
    }

    if (_controller.password.text.isEmpty) {
      return Constants.PLEASE_ENTER_NEW_PASSWORD;
    }
    if (_controller.password.text.length < 4) {
      return "New passowrd must be greater than 3 letters.";
    }

    if (_controller.confirmPassword.text.isEmpty) {
      return Constants.PLEASE_ENTER_CONFIRM_PASSWORD;
    }

    if (_controller.confirmPassword.text.length < 4) {
      return "Confirm passowrd must be greater than 3 letters.";
    }

    if (_controller.confirmPassword.text != _controller.password.text) {
      return errorText = Constants.CONFIRM_PASSWORD_MIS_MATCHED;
    }

    return errorText;
  }

  passwordVisibility(String textFormText) {
    if (textFormText == Constants.ENTER_CURRENT_PASSWORD) {
      setState(() {
        hideCurrentPassword = !hideCurrentPassword;
      });
    } else if (textFormText == Constants.ENTER_NEW_PASSWORD) {
      setState(() {
        hideNewPassword = !hideNewPassword;
      });
    } else if (textFormText == Constants.ENTER_CONFIRM_PASSWORD) {
      setState(() {
        hideConfirmPassword = !hideConfirmPassword;
      });
    } else {
      return false;
    }
  }

  bottomsheetForgotPasswordTextFields() {
    showModalBottomSheet(
        transitionAnimationController: _animationController,
        isScrollControlled: true,
        enableDrag: true,
        showDragHandle: true,
        backgroundColor: theme.colorScheme.primaryContainer,
        barrierColor: Colors.black54,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20.0),
                topRight: Radius.circular(20.0))),
        context: context,
        builder: (BuildContext buildContext) {
          return Padding(
            padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom),
            child: ListView(
              shrinkWrap: true,
              children: [
                Container(
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Reset Password",
                          style: TextStyle(
                              color: Colors.black,
                              fontWeight: StyleView.fontSemiBold,
                              fontSize: 15),
                        ),
                      ],
                    ),
                  ),
                ),
                Container(
                    child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(children: [
                    FxSpacing.height(20),
                    passwordTextField("Please enter new password"),
                    FxSpacing.height(20),
                    confirmPasswordTextField("Confirm new password"),
                    FxSpacing.height(20.0),
                    Container(
                      padding: EdgeInsets.only(bottom: 30),
                      child: CommonButtonsView(
                          context: context,
                          b1Text: Language()
                              .getString(Constants.STR_CANCEL, selectedLang),
                          b2Text: Language()
                              .getString(Constants.CONFIRM, selectedLang),
                          onb1Action: () {
                            _controller.password.clear();
                            _controller.confirmPassword.clear();
                            Navigator.of(context).pop();
                          },
                          onb2Action: () {
                            Navigator.of(context).pop();
                            serviceCallForgotPassword();
                          }),
                    )
                  ]),
                )),
              ],
            ),
          );
        });
  }

  bottomSheetOTPCode() {
    showModalBottomSheet(
        transitionAnimationController: _animationController,
        isScrollControlled: true,
        enableDrag: true,
        showDragHandle: true,
        backgroundColor: theme.colorScheme.primaryContainer,
        barrierColor: Colors.black54,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20.0),
                topRight: Radius.circular(20.0))),
        context: context,
        builder: (BuildContext buildContext) {
          return Padding(
            padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom),
            child: ListView(
              shrinkWrap: true,
              children: [
                Container(
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Verification Code",
                          style: TextStyle(
                              color: Colors.black,
                              fontWeight: StyleView.fontSemiBold,
                              fontSize: 15),
                        ),
                        Padding(
                          padding: EdgeInsets.only(top: 10),
                          child: Text(
                            "Enter the 4 digit number that we send to ${_controller.mobileNumber.text}",
                            style: TextStyle(
                                color: Colors.black,
                                fontWeight: StyleView.fontRegular,
                                fontSize: 15),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
                OtpTextField(
                  numberOfFields: 4,
                  borderWidth: 1,
                  borderColor: theme.colorScheme.primaryContainer,
                  enabledBorderColor: Colors.black,
                  showFieldAsBox: true,
                  onCodeChanged: (String code) {
                    print("otp code: ${code}");
                    if (code.isEmpty) {
                      _controller.otp.text = _controller.otp.text
                          .substring(0, _controller.otp.text.length - 1);
                    } else {
                      _controller.otp.text = _controller.otp.text + code;
                    }
                  },
                  onSubmit: (String code) {
                    setState(() {
                      verificationCode = code;
                    });
                    print(code);
                  },
                ),
                // FxSpacing.height(50.0),
                Container(
                    child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(children: [
                    FxSpacing.height(20.0),
                    Container(
                      padding: EdgeInsets.only(bottom: 30),
                      child: CommonButtonsView(
                          context: context,
                          b1Text: Language()
                              .getString(Constants.STR_CANCEL, selectedLang),
                          b2Text: Language()
                              .getString(Constants.SEND, selectedLang),
                          onb1Action: () {
                            _controller.otp.clear();
                            Navigator.of(context).pop();
                          },
                          onb2Action: () {
                            verifyOtp();
                          }),
                    )
                  ]),
                )),
              ],
            ),
          );
        });
  }

  Future<void> verifyOtp() async {
    Map<String, dynamic> mapData = {
      "contact": "+91 " + _controller.mobileNumber.text,
      "reference": "forgotpwd-otp",
      "otp": verificationCode
    };
    String body = json.encode(mapData);
    http.Response response = await _service.verifyOTP(body);
    if (response.statusCode == 200) {
      Navigator.of(context).pop();
      bottomsheetForgotPasswordTextFields();
    } else {
      if (response.body == "false") {
        await Dialogs.yesCancelDialog(
            context,
            Language().getString(Constants.ERROR, selectedLang),
            Language().getString(Constants.INCORRECT_OTP, selectedLang),
            Language().getString(Constants.OKAY_STR, selectedLang),
            "",
            false);
      }
    }
  }

  Icon iconVisibility(String textFormText) {
    if (textFormText == Constants.ENTER_CURRENT_PASSWORD &&
        hideCurrentPassword) {
      return Icon(Icons.visibility_off);
    } else if (textFormText == Constants.ENTER_NEW_PASSWORD &&
        hideNewPassword) {
      return Icon(Icons.visibility_off);
    } else if (textFormText == Constants.ENTER_CONFIRM_PASSWORD &&
        hideConfirmPassword) {
      return Icon(Icons.visibility_off);
    } else {
      return Icon(Icons.visibility);
    }
  }

  serviceCallUpdatePassword() async {
    setState(() {
      isLoadingProgress = true;
    });
    Map data = {
      "contact": _controller.mobileNumber.text,
      "current_password": _controller.currentPassword.text,
      "new_password": _controller.password.text,
      "confirm_password": _controller.confirmPassword.text
    };
    String body = json.encode(data);
    var response = await _userService
        .updatePassword(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;

    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          Language().getString(
              Constants.PASSOWRD_UPDATED_LOGIN_AGAIN, selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);

      if (action == DialogAction.yes) {
        AppController.instance.setMyBuId = "";
        AppController.instance.setBuName = "";
        AppController.instance.setAuthorizationKey = "";
        SharePref().savePhoneNumber('');
        SharePref().savePassword('');
        SharePref().saveFirebaseToken("");
        SharePref().saveHomePageSelectedBuId('');
        return Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(builder: (context) => LoginPage()),
            (Route<dynamic> route) => false);
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  serviceCallForgotPassword() async {
    setState(() {
      isLoadingProgress = true;
    });
    Map data = {
      "contact": _controller.mobileNumber.text,
      "otp": _controller.otp.text,
      "new_password": _controller.password.text,
      "confirm_password": _controller.confirmPassword.text
    };
    String body = json.encode(data);
    var response = await _userService
        .forgotPassword(body: body, token: "")
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          Language().getString(
              Constants.PASSOWRD_UPDATED_LOGIN_AGAIN, selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);

      if (action == DialogAction.yes) {
        return Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(builder: (context) => LoginPage()),
            (Route<dynamic> route) => false);
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }
}
