import 'dart:convert';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/login_view/controller/forgotPassword_controller.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:flutter/material.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'package:flutter_otp_text_field/flutter_otp_text_field.dart';
import 'package:flutx/flutx.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/login_view/LoginPage.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/service/user_services.dart';
import 'package:vyaparlive/utills/SharePref.dart';

import '../redux/actions/reset_data.dart';
import '../redux/state/app_state.dart';
import '../service/Service.dart';

class DeleteAccountPage extends StatefulWidget {
  final String? validationText;
  DeleteAccountPage({this.validationText});
  @override
  _DeleteAccountPageState createState() => _DeleteAccountPageState();
}

class _DeleteAccountPageState extends State<DeleteAccountPage>
    with TickerProviderStateMixin {
  String? buName = "";
  String? regMobileNumber = "";
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  bool mobileNumberError = false;
  bool otpErrorMessage = false;
  bool hideOTPVisible = true;
  bool isLoadingProgress = false;
  String progressMessage = Constants.UPDATING;
  late UserService _userService;
  late ForgotPasswordController _controller;
  late ThemeData theme;
  late FocusNode _mobileFocusNode;
  late FocusNode _otpFocusNode;
  late AnimationController _animationController;
  late Service _service;
  String verificationCode = "";
  @override
  void initState() {
    super.initState();
    initBottomSheetAnimation();
    _service = new Service();
    _mobileFocusNode = FocusNode();
    _otpFocusNode = FocusNode();
    theme = AppTheme.vyaparTheme;

    _controller = FxControllerStore.putOrFind(ForgotPasswordController());
    _userService = UserService();
    buName = AppController.instance.getBuName;
    SharePref().getPhoneNumber().then((value) {
      regMobileNumber = value;
      _controller.mobileNumber.text = regMobileNumber!;
    });
  }

  initBottomSheetAnimation() {
    _animationController = BottomSheet.createAnimationController(this);
    _animationController.duration =
        const Duration(milliseconds: Constants.bottomSheet_duration);
    _animationController.reverseDuration =
        const Duration(milliseconds: Constants.bottomSheet_reverse_duration);
    _animationController.drive(CurveTween(curve: Curves.easeIn));
  }

  Widget _buildBody() {
    return AppBackgroundView(
        body: Stack(children: [
      SafeArea(
        child: Scaffold(
          backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
          appBar: AppBar(
              backgroundColor: Colors.transparent,
              elevation: 0.0,
              centerTitle: true,
              iconTheme: IconThemeData(color: theme.colorScheme.primary),
              title: AppbarName(
                  title:
                      Language().getString(Constants.DELETE_ACCOUNT, selectedLang),
                  buName: buName)),
          body: SingleChildScrollView(
            child: Container(
              margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 20.0),
              child: Column(
                children: [
                  FxSpacing.height(20),
                  mobileNumberField(Constants.ENTER_REGISTERED_MOBILE_NUMBER),
                  // otpTextField(Constants.ENTER_OTP),
                  bottomView(),
                ],
              ),
            ),
          ),
        ),
      ),
      AppUtills.showLoadingView(
          context: context,
          message: Language().getString(progressMessage, selectedLang),
          isLoading: isLoadingProgress),
    ]));
  }

  TextFormField mobileNumberField(String text) {
    return TextFormField(
      style: TextStyle(fontWeight: StyleView.fontMedium, fontSize: 15.0),
      controller: _controller.mobileNumber,
      focusNode: _mobileFocusNode,
      textInputAction: TextInputAction.next,
      keyboardType: TextInputType.number,
      decoration: CommonMethods.textFieldDecorationTheme(text,
          prefixIcon: FeatherIcons.phone),
      onEditingComplete: () {
        _mobileFocusNode.unfocus();
        FocusScope.of(context).requestFocus(_otpFocusNode);
      },
      maxLength: 10,
      onChanged: (value) => onChangedText(value, text),
    );
  }

  Widget otpTextField(String text) {
    return Container(
      margin: EdgeInsets.only(top: 20),
      child: TextFormField(
        style: TextStyle(fontWeight: StyleView.fontMedium, fontSize: 15.0),
        controller: _controller.otp,
        focusNode: _otpFocusNode,
        textInputAction: TextInputAction.next,
        keyboardType: TextInputType.number,
        maxLength: 4,
        decoration: CommonMethods.textFieldDecorationTheme(text,
            prefixIcon: FeatherIcons.link),
        onEditingComplete: () {
          // c.unfocus();
          _otpFocusNode.unfocus();
          // FocusScope.of(context).requestFocus(_passwordFocusNode);
        },
        onChanged: (value) => onChangedText(value, text),
      ),
    );
  }

  @override
  void dispose() {
    _controller.password.clear();
    _controller.mobileNumber.clear();
    _controller.confirmPassword.clear();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FxBuilder<ForgotPasswordController>(
        controller: _controller, builder: (_controller) => _buildBody());
  }

  Widget bottomView() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 15.0, vertical: 10.0),
      child: CommonButtonsView(
        context: context,
        b1Text: Language().getString(Constants.SEND_OTP, selectedLang),
        b2Text: "",
        onb1Action: () {
          String value = this.validatingFields();
          if (value.isEmpty) {
            sendUserOTP();
          } else {
            Dialogs.yesCancelDialog(
                context,
                Language().getString(Constants.ERROR, selectedLang),
                value,
                Language().getString(Constants.OKAY_STR, selectedLang),
                "",
                false);
          }
        },
      ),
    );
  }

  Future<void> sendUserOTP() async {
    var mapData = {
      "contact": _controller.mobileNumber.text,
      "type": "account-delete"
    };

    String body = json.encode(mapData);

    var response = await _userService
        .sendUserOTP(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((error) {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          error.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      bottomSheetOTPCode();
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message!,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  onChangedText(String value, String textFieldName) {
    if (textFieldName == Constants.ENTER_REGISTERED_MOBILE_NUMBER &&
        _controller.mobileNumber.text.isNotEmpty) {
      setState(() {
        mobileNumberError = false;
      });
    } else if (textFieldName == Constants.ENTER_OTP &&
        _controller.otp.text.isNotEmpty) {
      setState(() {
        otpErrorMessage = false;
      });
    } else {
      return null;
    }
  }

  String? errorText(String textFieldName) {
    if (textFieldName == Constants.ENTER_REGISTERED_MOBILE_NUMBER &&
        mobileNumberError) {
      return Constants.PLEASE_ENTER_REGISTERED_MOBILE_NUMBER;
    } else if (textFieldName == Constants.ENTER_OTP && otpErrorMessage) {
      return Constants.PLEASE_ENTER_OTP;
    } else {
      return null;
    }
  }

  validatingFields() {
    String errorText = '';
    if (_controller.mobileNumber.text.isEmpty ||
        _controller.mobileNumber.text.length < 9) {
      return errorText = Constants.ENTER_REGISTERED_MOBILE_NUMBER;
    }

    return errorText;
  }


  bottomSheetOTPCode() {
    showModalBottomSheet(
        transitionAnimationController: _animationController,
        isScrollControlled: true,
        enableDrag: true,
        showDragHandle: true,
        backgroundColor: theme.colorScheme.primaryContainer,
        barrierColor: Colors.black54,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20.0),
                topRight: Radius.circular(20.0))),
        context: context,
        builder: (BuildContext buildContext) {
          return Padding(
            padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom),
            child: ListView(
              shrinkWrap: true,
              children: [
                Container(
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Verification Code",
                          style: TextStyle(
                              color: Colors.black,
                              fontWeight: StyleView.fontSemiBold,
                              fontSize: 15),
                        ),
                        Padding(
                          padding: EdgeInsets.only(top: 10),
                          child: Text(
                            "Enter the 4 digit number that we send to ${_controller.mobileNumber.text}",
                            style: TextStyle(
                                color: Colors.black,
                                fontWeight: StyleView.fontRegular,
                                fontSize: 15),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
                OtpTextField(
                  numberOfFields: 4,
                  borderWidth: 1,
                  borderColor: theme.colorScheme.primaryContainer,
                  enabledBorderColor: Colors.black,
                  showFieldAsBox: true,
                  onCodeChanged: (String code) {
                    print("otp code: ${code}");
                    if (code.isEmpty) {
                      _controller.otp.text = _controller.otp.text
                          .substring(0, _controller.otp.text.length - 1);
                    } else {
                      _controller.otp.text = _controller.otp.text + code;
                    }
                  },
                  onSubmit: (String code) {
                    setState(() {
                      verificationCode = code;
                    });
                    print(code);
                  },
                ),
                // FxSpacing.height(50.0),
                Container(
                    child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(children: [
                    FxSpacing.height(20.0),
                    Container(
                      padding: EdgeInsets.only(bottom: 30),
                      child: CommonButtonsView(
                          context: context,
                          b1Text: Language()
                              .getString(Constants.STR_CANCEL, selectedLang),
                          b2Text: Language()
                              .getString(Constants.DELETE_ACCOUNT, selectedLang),
                          onb1Action: () {
                            _controller.otp.clear();
                            Navigator.of(context).pop();
                          },
                          onb2Action: () {
                            verifyOtp();
                          }),
                    )
                  ]),
                )),
              ],
            ),
          );
        });
  }

  Future<void> verifyOtp() async {
    Map<String, dynamic> mapData = {
      "contact": _controller.mobileNumber.text,
      "otp": verificationCode
    };
    String body = json.encode(mapData);
    var response = await _userService
        .confirmUserDeleteWithOTP(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((error) {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          error.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      Navigator.of(context).pop();
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          "Account deleted successfully.",
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);

      if (action == DialogAction.yes) {
        StoreProvider.of<AppState>(context).dispatch(ResetData());
        AppController.instance.setBuList = [];
        AppController.instance.setMyBuId = null;
        SharePref().insertUserId('');
        SharePref().savePhoneNumber('');
        SharePref().savePassword('');
        SharePref().saveUserName('');
        SharePref().saveProfilePic('');
        await CommonMethods.clearAppData(context);
        Future.delayed(Duration(seconds: 3));
      
        Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(builder: (context) => LoginPage()),
            (Route<dynamic> route) => false);
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message!,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }
}
