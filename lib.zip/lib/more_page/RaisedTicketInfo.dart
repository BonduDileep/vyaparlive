import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/model/RaisedTicketDAO.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:custom_searchable_dropdown/custom_searchable_dropdown.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/DateFilterUtil.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/Contacts.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'package:vyaparlive/service/Service.dart';
import 'package:vyaparlive/service/invitation_services.dart';

class RaisedTicketInfoView extends StatefulWidget {
  @override
  _RaisedTicketInfoViewState createState() => _RaisedTicketInfoViewState();
}

class _RaisedTicketInfoViewState extends State<RaisedTicketInfoView>
    with TickerProviderStateMixin {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? buName = "";
  String? buId = "";
  // ProgressDialog progressDialog;
  List<RaisedTicketDAO> notificationsList = [];
  bool isLoading = false;
  late Service _service;
  var startDate;
  var endDate;
  DateFormat formatter = DateFormat("yyyy-MM-dd");
  DateTime selectedDate = DateTime.now();
  final double calendarHeight = 40.0;
  List<Contacts> _contactsModel = [];
  Contacts? connectionName;
  final List<DropdownMenuItem> searchItems = [];
  String params = "";
  String todayDate = "";
  String? convertedDate = "";
  bool isLoadingProgress = true;
  String progressMessage = Constants.GETTING_DATA;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  late InvitationService _invitationService;
  DateTime mnthStartDate =
      DateTime.utc(DateTime.now().year, DateTime.now().month, 1);
  late ThemeData theme;
  late TextEditingController _fromDateController;
  late TextEditingController _toDateController;
  late AnimationController _animationController;

  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    initBottomSheetAnimation();
    _invitationService = InvitationService();
    startDate = formatter.format(DateTime.now().subtract(Duration(days: 7)));
    endDate = formatter.format(DateTime.now());
    todayDate = formatter.format(DateTime.now());
    _service = Service();
    _fromDateController = new TextEditingController(
        text: formatter.format(DateTime.now().subtract(Duration(days: 7))));
    _toDateController =
        new TextEditingController(text: formatter.format(DateTime.now()));
    buName = AppController.instance.getBuName;
    buId = AppController.instance.getMyBuId;

    convertedDate = AppUtills.getOneDayAddedDate(endDate);
    params =
        "?${Constants.DATE_FROM}$startDate&${Constants.DATE_TO}$convertedDate";
    Future.delayed(Duration(seconds: 1)).then((value) {
      serviceCallNotifications(params);
      // isLoadingProgress = true;
      // loadConnectionsData();
    });
  }

  initBottomSheetAnimation() {
    _animationController = BottomSheet.createAnimationController(this);
    _animationController.duration =
        const Duration(milliseconds: Constants.bottomSheet_duration);
    _animationController.reverseDuration =
        const Duration(milliseconds: Constants.bottomSheet_reverse_duration);
    _animationController.drive(CurveTween(curve: Curves.easeIn));
  }

  serviceCallNotifications(String params) async {
    if (await NetworkStatus.getInternetStatus()) {
      getNotifications(buId!, params).then((value) {
        setState(() {
          notificationsList.addAll(value);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Widget buildSearchView() {
    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: ListView(
        shrinkWrap: true,
        children: [
          DateFilterUtill(
            isShowSearchButton: true,
            fromDate: "",
            toDate: "",
            fromDateController: _fromDateController,
            toDateController: _toDateController,
            onFromDateSelected: (value) {
              setState(() {
                // startDate = value;
                _fromDateController.text = value;
              });
            },
            onToDateSelected: (value) {
              setState(() {
                // endDate = value;
                _toDateController.text = value;
              });
            },
            onSearchParms: () {
              // setState(() {
              //   isLoadingProgress = true;
              // });
              // if (endDate == todayDate) {
              //   convertedDate = AppUtills.getOneDayAddedDate(endDate);
              // } else {
              //   convertedDate = endDate;
              // }
              // params =
              //     "?${Constants.DATE_FROM}${_fromDateController.text}&${Constants.DATE_TO}${_toDateController.text}" +
              //         "&name=${connectionName != null ? connectionName!.buName : ""}";
              // print(params);
              serviceCallNotifications(params);
            },
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
      body: Stack(
        children: [
          WillPopScope(
            onWillPop: () async {
              return true;
            },
            child: SafeArea(
              child: Scaffold(
                key: _scaffoldkey,
                backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                appBar: AppBar(
                  iconTheme: IconThemeData(color: theme.colorScheme.primary),
                  backgroundColor: Colors.transparent, //(Constants.APP_COLOR),
                  centerTitle: true,
                  elevation: 0,
                  title: AppbarName(
                      title: Language()
                          .getString("My Conversations", selectedLang),
                      buName: "$buName"),
                ),
                // drawer: MyDrawer(),
                body: Container(
                  margin: EdgeInsets.all(5.0),
                  child: RefreshIndicator(
                    onRefresh: () {
                      serviceCallNotifications("");
                      return Future.delayed(Duration(seconds: 3));
                    },
                    child: Column(
                      children: [
                        buildSearchView(),
                        Expanded(
                          child: (notificationsList.length > 0)
                              ? Container(
                                  margin: EdgeInsets.only(top: 20.0),
                                  child: AnimationLimiter(
                                    child: ListView.builder(
                                      shrinkWrap: true,
                                      itemBuilder: (context, index) =>
                                          AnimationConfiguration.staggeredList(
                                              position: index,
                                              child: SlideAnimation(
                                                  verticalOffset: 50.0,
                                                  child: FadeInAnimation(
                                                      child: notificationCard(
                                                          notificationsList[
                                                              index])))),
                                      itemCount: notificationsList.length,
                                    ),
                                  ),
                                )
                              : Center(
                                  child: Text(
                                  Language().getString(
                                      Constants.NO_DATA_FOUND, selectedLang),
                                )),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
          AppUtills.showLoadingView(
              context: context,
              message: Language().getString(progressMessage, selectedLang),
              isLoading: isLoadingProgress),
        ],
      ),
    );
  }

  notificationCard(RaisedTicketDAO ticketData) {
    return InkWell(
      onTap: () {},
      child: Card(
        shadowColor: AppTheme.vyaparTheme.colorScheme.primary,
        elevation: 8.0,
        child: ExpansionTile(
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                for (int i = 0; i < ticketData.messages!.length; i++)
                  Card(
                    shadowColor: AppTheme.vyaparTheme.colorScheme.primary,
                    elevation: 8.0,
                    child: Container(
                      alignment: Alignment.centerLeft,
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.all(Radius.circular(10.0)),
                          border: Border.all(color: Colors.white60)),
                      margin: EdgeInsets.symmetric(horizontal: 10),
                      child: Column(
                        children: [
                          Container(
                            alignment: Alignment.centerLeft,
                            child: Text(
                              "${ticketData.messages![i].message}",
                              style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: StyleView.fontMedium),
                            ),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Container(
                            alignment: Alignment.centerLeft,
                            child: Text(
                              AppUtills.getDateFormate(ticketData
                                  .messages![i].createdDate
                                  .toString()),
                              style: TextStyle(
                                  fontSize: 13.0,
                                  fontWeight: StyleView.fontRegular),
                            ),
                          ),
                        ],
                      ),
                    ),
                  )
              ],
            )
          ],
          title: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Container(
                        child: Text(
                          "Ticket ID",
                          style: TextStyle(
                              color: Colors
                                  .black, //AppTheme.vyaparTheme.colorScheme.primary,
                              fontWeight: StyleView.fontBold),
                        ),
                      ),
                    ),
                    Expanded(
                      child: Container(
                        child: Text(
                          ": ${ticketData.id}",
                          style: TextStyle(
                              color: Colors
                                  .black, //AppTheme.vyaparTheme.colorScheme.primary,
                              fontWeight: StyleView.fontRegular),
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 8,
                ),
                Row(
                  children: [
                    Expanded(
                      child: Container(
                        child: Text(
                          "Subject",
                          style: TextStyle(
                              color: Colors
                                  .black, //AppTheme.vyaparTheme.colorScheme.primary,
                              fontWeight: StyleView.fontBold),
                        ),
                      ),
                    ),
                    Expanded(
                      child: Container(
                        child: Text(
                          ": ${ticketData.subject}",
                          style: TextStyle(
                              color: Colors
                                  .black, //AppTheme.vyaparTheme.colorScheme.primary,
                              fontWeight: StyleView.fontRegular),
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 8,
                ),
                Container(
                  margin: EdgeInsets.symmetric(vertical: 5.0),
                  child: Text(
                    AppUtills.getDateFormate(ticketData.createdDate.toString()),
                    style: TextStyle(
                        fontSize: 13.0, fontWeight: StyleView.fontRegular),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );

    // NotificationCard(
    //   message: ticketData.message,
    //   notificationDate: ticketData.createdDate,
    //   onNotificationClick: () {},
    // );
  }

  showConnectionsList() {
    return Container(
        decoration: AppUtills.boxDecoration(),
        child: CustomSearchableDropDown(
          items: _contactsModel.toList(),
          label:
              Language().getString(Constants.SEARCH_BY_BUSINESS, selectedLang),
          labelStyle:
              TextStyle(fontWeight: StyleView.fontSemiBold, fontSize: 14.0),
          suffixIcon: Padding(
            padding: const EdgeInsets.all(0.0),
            child: Icon(Icons.search),
          ),
          dropDownMenuItems: _contactsModel.map((item) {
            return item.buName;
          }).toList(),
          onChanged: (value) {
            if (value != null) {
              setState(() {
                connectionName = value;
                isLoadingProgress = true;
                params = "?name=${connectionName!.buName!}" +
                    "&${Constants.DATE_FROM}${_fromDateController.text}&${Constants.DATE_TO}${_toDateController.text}";
                serviceCallNotifications(params);
              });
            }
            // else {
            //   setState(() {
            //     isLoadingProgress = true;
            //     params =
            //         "?${Constants.DATE_FROM}$startDate&${Constants.DATE_TO}$convertedDate";
            //     serviceCallNotifications(params);
            //   });
            // }
          },
        ));
  }

  Future<List<RaisedTicketDAO>> getNotifications(
      String buId, String params) async {
    notificationsList.clear();
    http.Response response =
        await _service.getPreviousTickets(buId, dateFrom: _fromDateController.text, dateTo: _toDateController.text).catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<RaisedTicketDAO> _model = [];
    isLoading = true;

    setState(() {
      isLoadingProgress = false;
    });

    if (response.statusCode == 200) {
      var data = json.decode(response.body);

      var resultArray = data['results'];
      for (var dataObject in resultArray) {
        _model.add(RaisedTicketDAO.fromJson(dataObject));
        // for (var value in dataObject['messages']) {
          
        // }
      }
    } else if (response.statusCode == 401) {
      CommonMethods.handleUnauthorizedAccess(context);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          response.body,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    return _model;
  }
}
