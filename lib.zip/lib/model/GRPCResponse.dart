class GRPCResponse {
  String? message;
  bool? isError;
  bool? isException;

  GRPCResponse({this.message, this.isError, this.isException});

  String? get getMessage => message;

  set setMessage(String message) => this.message = message;

  bool? get getIsError => isError;

  set setIsError(bool isError) => this.isError = isError;

  bool? get getIsException => isException;

  set setIsException(bool isException) => this.isException = isException;
}
