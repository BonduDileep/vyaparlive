import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/model/RawRequestFormDAO.dart';
import 'package:vyaparlive/model/TransactionsModel.dart';

class RawProductsIssueDAO {
  String? buId;
  String? issuedPurpose;
  IssuedTo? issuedTo;
  DateTime? createdDate;
  List<Product>? productist;
  String? id;
  FinalProduct? finalProduct;
  String? requestedId;
  IssuedTo? approvedBy;
  IssuedTo? requestedBy;
  String? issueId;
  num? requestNumber;
  num? issueNumber;
  List<FinalProduct>? finalProductsList;
  String? department;
  String? issueBatchNumber;

  RawProductsIssueDAO(
      {this.buId,
      this.createdDate,
      this.issuedPurpose,
      this.issuedTo,
      this.productist,
      this.id,
      this.finalProduct,
      this.requestedId,
      this.approvedBy,
      this.requestedBy,
      this.issueId,
      this.requestNumber,
      this.issueNumber,
      this.finalProductsList,
      this.department,
      this.issueBatchNumber});

  factory RawProductsIssueDAO.fromJson(Map<String, dynamic> json) =>
      RawProductsIssueDAO(
        buId: json.containsKey("bu_id") && json["bu_id"] != null
            ? json["bu_id"]
            : "",
        issuedPurpose:
            json.containsKey("issued_purpose") && json["issued_purpose"] != null
                ? json["issued_purpose"]
                : "",
        issuedTo: json.containsKey("issued_to") && json["issued_to"] != null
            ? IssuedTo.fromJson(json["issued_to"])
            : null,
        createdDate: (CommonMethods.getRawIssueCretaedDateFromRes(json)!
                .isNotEmpty)
            ? DateTime.parse(CommonMethods.getRawIssueCretaedDateFromRes(json)!)
            : null,
        // json.containsKey("created_date") &&
        //         json["created_date"] != null
        //     ? DateTime.parse(json["created_date"])
        //     : null,
        productist: json.containsKey("products") && json["products"] != null
            ? List<Product>.from(
                json["products"].map((x) => Product.fromJson(x)))
            : [],
        id: json.containsKey("_id") && json["_id"] != null ? json["_id"] : "",
        finalProduct:
            json.containsKey("final_product") && json["final_product"] != null
                ? FinalProduct.fromJson(json["final_product"])
                : null,
        requestedId:
            json.containsKey("request_id") && json["request_id"] != null
                ? json["request_id"]
                : "",
        approvedBy:
            json.containsKey("approved_by") && json["approved_by"] != null
                ? IssuedTo.fromJson(json["approved_by"])
                : null,
        requestedBy:
            json.containsKey("requested_by") && json["requested_by"] != null
                ? IssuedTo.fromJson(json["requested_by"])
                : null,
        issueId: json.containsKey("issue_id") && json["issue_id"] != null
            ? json["issue_id"]
            : "",
        requestNumber:
            json.containsKey("req_number") && json["req_number"] != null
                ? json["req_number"]
                : 0,
        issueNumber:
            json.containsKey("issue_number") && json["issue_number"] != null
                ? json["issue_number"]
                : 0,
        finalProductsList:
            json.containsKey("final_products") && json["final_products"] != null
                ? List<FinalProduct>.from(
                    json["final_products"].map((x) => FinalProduct.fromJson(x)))
                : [],
        department: json.containsKey("department") && json["department"] != null
            ? json["department"]
            : "",
        issueBatchNumber: json.containsKey("issue_batch_number") &&
                json["issue_batch_number"] != null
            ? json["issue_batch_number"]
            : "",
      );

  Map<String, dynamic> toJson() => {
        "bu_id": buId,
        "issued_purpose": issuedPurpose,
        "issued_to": issuedTo,
        "created_date": createdDate!.toIso8601String(),
        "products": List<dynamic>.from(productist!.map((e) => e.toJson())),
        "_id": id,
        "request_id": requestedId,
        "requested_by": requestedBy!.toJson(),
        "approved_by": approvedBy!.toJson(),
        "issue_id": issueId,
        "issue_number": issueNumber,
        "req_number": requestNumber,
        "final_products":
            List<dynamic>.from(finalProductsList!.map((e) => e.toJson())),
        "issue_batch_number": issueBatchNumber,
        "department": department,
      };
}

class FinalProduct {
  String? addedBy;
  num? quantity;
  DateTime? createdDate;
  String? productName;
  String? quantityIn;
  String? batchNumber;
  String? addedByUser;
  FinalProduct(
      {this.addedBy,
      this.createdDate,
      this.quantity,
      this.productName,
      this.quantityIn,
      this.batchNumber,
      this.addedByUser});

  factory FinalProduct.fromJson(Map<String, dynamic> json) => FinalProduct(
      addedBy: json.containsKey("added_by") && json["added_by"] != null
          ? json["added_by"]
          : "",
      quantity: json.containsKey("quantity") && json["quantity"] != null
          ? json["quantity"]
          : 0,
      createdDate: CommonMethods.getRawIssueCretaedDateFromRes(json)!.isNotEmpty
          ? DateTime.parse(CommonMethods.getRawIssueCretaedDateFromRes(json)!)
          : null,
      productName:
          json.containsKey("product_name") && json["product_name"] != null
              ? json["product_name"]
              : "",
      quantityIn: json.containsKey("quantity_in") && json["quantity_in"] != null
          ? json["quantity_in"]
          : "",
      batchNumber:
          json.containsKey("batch_number") && json["batch_number"] != null
              ? json["batch_number"]
              : "",
      addedByUser:
          json.containsKey("added_by_user") && json["added_by_user"] != null
              ? json["added_by_user"]
              : "");

  Map<String, dynamic> toJson() => {
        "created_date": createdDate!.toIso8601String(),
        "quantity": quantity,
        "added_by": addedBy,
        "product_name": productName,
        "quantity_in": quantityIn,
        "batch_number": batchNumber,
        "added_by_user": addedByUser
      };
}
