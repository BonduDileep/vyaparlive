import 'dart:convert';
import 'package:vyaparlive/model/product_model/BatchPriceDAO.dart';
import 'package:vyaparlive/model/product_model/ImageUrl.dart';
import 'package:vyaparlive/model/product_model/OffersDAO.dart';
import 'package:vyaparlive/model/bu_model/ContactDetailsModel.dart';
import 'package:vyaparlive/model/bu_model/PaymentTermsModel.dart';
import 'package:vyaparlive/model/transaction/DeliveryDetailsModel.dart';
import 'package:vyaparlive/model/transaction/InvoiceDetailsModel.dart';
import 'package:vyaparlive/model/transaction/PackingDetailsModel.dart';
import 'package:vyaparlive/model/transaction/StockDetailsModel.dart';

InvoiceDAO invoiceDaoFromJson(String str) =>
    InvoiceDAO.fromJson(json.decode(str));

String invoiceDaoToJson(InvoiceDAO data) => json.encode(data.toJson());

class InvoiceDAO {
  DateTime? invoiceDate;
  dynamic billNo;
  TaxReferences? taxReferences;
  String? address;
  String? authority;
  List<Product>? products;
  PackageDetails? packageDetails;
  OrderTrack? orderTrack;
  StockReconciliation? stockReconciliation;
  StockReconciliation? paymentReconciliation;
  ContactDetails? sellerContactDetails;
  ContactDetails? buyerContactDetails;
  PaymentTerms? paymentTerms;
  num? subTotal;
  num? total;
  var amountPaid;
  num? gstTotal;
  var balanceDue;
  num? cgstTotal;
  num? sgstTotal;
  num? taxTotal;
  num? finalTotal;
  num? productToatalCost;
  num? totalOffer;
  num? totalPrice;
  num? additionalDiscount;
  String? actualDeliveryDate;
  String? actualDeliveryTime;
  String? receivedBy;
  String? stockReceiveStatus;
  num? igstTotal;
  List<Product>? replacedProducts;
  InvoiceDetails? invoiceDetails;
  String? invoiceId;
  String? discountType;
  List<AdditionalCharges>? additionalCharges;
  num? pendingAmount;
  num? paid_amount;
  num? additionalDiscountTotal;

  InvoiceDAO(
      {this.invoiceDate,
      this.billNo,
      this.taxReferences,
      this.address,
      this.authority,
      this.products,
      this.packageDetails,
      this.orderTrack,
      this.stockReconciliation,
      this.paymentReconciliation,
      this.sellerContactDetails,
      this.buyerContactDetails,
      this.paymentTerms,
      this.amountPaid,
      this.balanceDue,
      this.gstTotal,
      this.subTotal,
      this.cgstTotal,
      this.finalTotal,
      this.sgstTotal,
      this.taxTotal,
      this.total,
      this.additionalDiscount,
      this.productToatalCost,
      this.totalOffer,
      this.totalPrice,
      this.actualDeliveryDate,
      this.actualDeliveryTime,
      this.receivedBy,
      this.stockReceiveStatus,
      this.igstTotal,
      this.replacedProducts,
      this.invoiceDetails,
      this.invoiceId,
      this.discountType,
      this.additionalCharges,
      this.pendingAmount,
      this.paid_amount,
      this.additionalDiscountTotal});

  factory InvoiceDAO.fromJson(Map<String, dynamic> json) => InvoiceDAO(
      actualDeliveryDate: json.containsKey("actual_delivery_date") &&
              json["actual_delivery_date"] != null
          ? json["actual_delivery_date"]
          : "",
      actualDeliveryTime: json.containsKey("actual_delivxery_time") &&
              json['actual_delivery_time'] != null
          ? json['actual_delivery_time']
          : "",
      receivedBy: json.containsKey("stock_received_by") && json['stock_received_by'] != null
          ? json['stock_received_by']
          : "",
      stockReceiveStatus: json.containsKey("stock_received_status") &&
              json['stock_received_status'] != null
          ? json['stock_received_status']
          : "",
      cgstTotal: json.containsKey("cgst_total") && json["cgst_total"] != null
          ? json["cgst_total"]
          : 0,
      sgstTotal: json.containsKey("sgst_total") && json["sgst_total"] != null
          ? json["sgst_total"]
          : 0,
      taxTotal: json.containsKey("tax_total") && json["tax_total"] != null
          ? json["tax_total"]
          : 0,
      finalTotal: json.containsKey("invoice_amount") && json["invoice_amount"] != null
          ? json["invoice_amount"]
          : 0,
      productToatalCost: json.containsKey("products_cost") && json["products_cost"] != null ? json["products_cost"] : 0,
      totalOffer: json.containsKey("total_offer") && json["total_offer"] != null ? json["total_offer"] : 0,
      totalPrice: json.containsKey("total_price") && json["total_price"] != null && json["total_price"] is num ? json["total_price"] : 0,
      additionalDiscount: json.containsKey("additional_discount") && json["additional_discount"] != null ? json["additional_discount"] : 0,
      // invoiceDate: json.containsKey("invoice_date") && json["invoice_date"] != null ? DateTime.parse(json["invoice_date"]) : DateTime.now().toUtc().toString(),
      billNo: json.containsKey("bill_no") && json["bill_no"] != null ? json["bill_no"] ?? 0 : 0,
      taxReferences: json.containsKey("tax_references") && json["tax_references"] != null ? TaxReferences.fromJson(json["tax_references"]) : null,
      address: json.containsKey("address") && json["address"] != null ? json["address"] : "",
      authority: json.containsKey("authority") && json["authority"] != null ? json["authority"] : "",
      products: json.containsKey("products") && json["products"] != null ? List<Product>.from(json["products"].map((x) => Product.fromJson(x))) : [],
      packageDetails: json.containsKey("package_details") && json["package_details"] != null ? PackageDetails.fromJson(json["package_details"]) : null,
      orderTrack: json.containsKey("order_track") && json["order_track"] != null ? OrderTrack.fromJson(json["order_track"]) : null,
      stockReconciliation: json.containsKey("stock_reconciliation") && json["stock_reconciliation"] != null ? StockReconciliation.fromJson(json["stock_reconciliation"]) : null,
      paymentReconciliation: json.containsKey("payment_reconciliation") && json["payment_reconciliation"] != null ? StockReconciliation.fromJson(json["payment_reconciliation"]) : null,
      sellerContactDetails: json.containsKey("seller") && json["seller"] != null ? ContactDetails.fromJson(json["seller"]) : null,
      buyerContactDetails: json.containsKey("buyer") && json["buyer"] != null ? ContactDetails.fromJson(json["buyer"]) : null,
      subTotal: json.containsKey("sub_total") && json["sub_total"] != null ? json["sub_total"] : 0,
      gstTotal: json.containsKey("gst_total") && json["gst_total"] != null ? json["gst_total"] : 0,
      total: json.containsKey("total") && json["total"] != null ? json["total"] : 0,
      amountPaid: json.containsKey("amount_paid") && json["amount_paid"] != null ? json["amount_paid"] : 0,
      balanceDue: json.containsKey("balance_due") && json["balance_due"] != null ? json["balance_due"] : 0,
      igstTotal: json.containsKey("igst_total") && json["igst_total"] != null ? json["igst_total"] : 0,
      replacedProducts: json.containsKey("replaced_products") && json["replaced_products"] != null ? List<Product>.from(json["replaced_products"].map((x) => Product.fromJson(x))) : [],
      invoiceDetails: json.containsKey("invoice_details") && json["invoice_details"] != null ? InvoiceDetails.fromJson(json["invoice_details"]) : null,
      invoiceId: json.containsKey("id") && json["id"] != null ? json["id"] : "",
      discountType: json.containsKey("additional_discount_type") && json["additional_discount_type"] != null ? json["additional_discount_type"] : "",
      additionalCharges: json.containsKey("additional_charges") && json["additional_charges"] != null ? List<AdditionalCharges>.from(json["additional_charges"].map((x) => AdditionalCharges.fromJson(x))) : [],
      pendingAmount: json.containsKey("pending_amount") && json["pending_amount"] != null ? json["pending_amount"] : 0,
      paid_amount: json.containsKey("paid_amount") && json["paid_amount"] != null ? json["paid_amount"] : 0,
      additionalDiscountTotal: json.containsKey("additional_discount_total") && json["additional_discount_total"] != null ? json["additional_discount_total"] : 0);

  Map<String, dynamic> toJson() => {
        // "invoice_date": invoiceDate.toIso8601String(),
        "bill_no": billNo,
        "tax_references": taxReferences!.toJson(),
        "address": address,
        "authority": authority,
        "products": List<dynamic>.from(products!.map((x) => x.toJson())),
        "package_details": packageDetails!.toJson(),
        "order_track": orderTrack!.toJson(),
        "stock_reconciliation": stockReconciliation!.toJson(),
        "payment_reconciliation": paymentReconciliation!.toJson(),
        "seller": sellerContactDetails!.toJson(),
        "buyer": buyerContactDetails!.toJson(),
        "terms": paymentTerms!.toJson(),
        "balance_due": balanceDue,
        "amount_paid": amountPaid,
        "total": total,
        "gst_total": gstTotal,
        "sub_total": subTotal,
        "cgst_total": cgstTotal,
        "sgst_total": sgstTotal,
        "tax_total": taxTotal,
        "final_price": finalTotal,
        "actual_delivery_date": actualDeliveryDate,
        "actual_delivery_time": actualDeliveryTime,
        "stock_received_by": receivedBy,
        "stock_received_status": stockReceiveStatus,
        "igst_total": igstTotal,
        "replaced_products":
            List<dynamic>.from(replacedProducts!.map((x) => x.toJson())),
        "invoice_details": invoiceDetails!.toJson(),
        "id": invoiceId,
        "additional_discount_type": discountType,
        "pending_amount": pendingAmount,
        "additional_discount_total":additionalDiscountTotal
      };
}

class Product {
  Product(
      {this.id,
      this.quantity,
      this.unitPrice,
      this.total,
      this.productName,
      this.gst,
      this.gstValue,
      this.offerData,
      this.subTotal,
      this.unitPriceWithOffer,
      this.taxType,
      this.totalPrice,
      this.totalTax,
      this.cgst,
      this.cgstValue,
      this.sgst,
      this.subTotalWithoutOffer,
      this.sgstValue,
      this.productImage,
      this.gstTotal,
      this.offerAmount,
      this.productAmountTotal,
      this.productCost,
      this.productTotalOffer,
      this.offerSelected,
      this.batchPricingList,
      this.batchNumber,
      this.quantityIn,
      this.cgstPercentage,
      this.igstPercentage,
      this.sgstPercentage,
      this.imageUrl,
      this.uid,
      this.hsnCode});

  String? id;
  num? quantity;
  num? total;
  num? unitPrice;
  String? productName;
  String? productImage;
  String? taxType;
  OffersDAO? offerData;
  num? unitPriceWithOffer;
  num? totalTax;
  num? subTotal;
  num? subTotalWithoutOffer;
  num? totalPrice;
  num? gstValue;
  dynamic gst;
  num? cgst;
  num? sgst;
  num? cgstValue;
  num? sgstValue;
  num? gstTotal;
  num? productCost;
  num? offerAmount;
  num? productTotalOffer;
  num? productAmountTotal;
  bool? offerSelected;
  List<BatchPriceDAO>? batchPricingList;
  String? batchNumber;
  String? quantityIn;
  num? igstPercentage;
  num? cgstPercentage;
  num? sgstPercentage;
  List<ImageUrl>? imageUrl;
  String? uid;
  String? hsnCode;

  factory Product.fromJson(Map<String, dynamic> json) => Product(
      id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
      quantity: json.containsKey("quantity") && json["quantity"] != null
          ? json["quantity"]
          : 0,
      unitPrice: json.containsKey("unit_price") && json["unit_price"] != null
          ? json["unit_price"]
          : 0,
      total: json.containsKey("total") && json["total"] != null
          ? json["total"]
          : 0,
      subTotalWithoutOffer: json.containsKey("sub_total_without_offer") &&
              json["sub_total_without_offer"] != null
          ? json["sub_total_without_offer"]
          : 0,
      productName: json.containsKey("product_name") && json["product_name"] != null
          ? json["product_name"]
          : "",
      gst: json.containsKey("igst") && json["igst"] != null ? json["igst"] : 0,
      offerData: json.containsKey("offer") && json["offer"] != null
          ? OffersDAO.fromJson(json["offer"])
          : null,
      taxType: json.containsKey("tax_type") && json["tax_type"] != null
          ? json["tax_type"]
          : "",
      unitPriceWithOffer: json.containsKey("unit_price_with_offer") &&
              json["unit_price_with_offer"] != null
          ? json["unit_price_with_offer"]
          : null,
      offerSelected: json.containsKey("offer_selected") && json["offer_selected"] != null
          ? json["offer_selected"]
          : false,
      totalTax: json.containsKey("total_tax") && json["total_tax"] != null
          ? json["total_tax"]
          : 0,
      subTotal: json.containsKey("sub_total") && json["sub_total"] != null
          ? json["sub_total"]
          : 0,
      totalPrice: json.containsKey("total_price") && json["total_price"] != null
          ? json["total_price"]
          : 0,
      gstValue: json.containsKey("gst_value") && json["gst_value"] != null
          ? json["gst_value"]
          : 0,
      cgst: json.containsKey("cgst") && json["cgst"] != null ? json["cgst"] : 0,
      sgst: json.containsKey("sgst") && json["sgst"] != null ? json["sgst"] : 0,
      cgstValue: json.containsKey("cgst_value") && json["cgst_value"] != null ? json["cgst_value"] : 0,
      sgstValue: json.containsKey("sgst_value") && json["sgst_value"] != null ? json["sgst_value"] : 0,
      productImage: json.containsKey("product_image") && json["product_image"] != null ? json["product_image"] : "",
      productCost: json.containsKey("product_cost") && json["product_cost"] != null ? json["product_cost"] : 0,
      gstTotal: json.containsKey("gst_total") && json["gst_total"] != null ? json["gst_total"] : 0,
      offerAmount: json.containsKey("offer_amount") && json["offer_amount"] != null ? json["offer_amount"] : 0,
      productAmountTotal: json.containsKey("product_amount_total") && json["product_amount_total"] != null ? json["product_amount_total"] : 0,
      productTotalOffer: json.containsKey("product_total_offer") && json["product_total_offer"] != null ? json["product_total_offer"] : 0,
      batchPricingList: [],
      // json.containsKey("batch_pricing") && json["batch_pricing"] != null ? List<BatchPriceDAO>.from(json["batch_pricing"].map((e) => BatchPriceDAO.fromJson(e))) : [],
      batchNumber: json.containsKey("batch_number") && json["batch_number"] != null ? json["batch_number"] : "",
      quantityIn: json.containsKey("quantity_in") && json["quantity_in"] != null ? json["quantity_in"] : "",
      igstPercentage: json.containsKey("igst_unit") && json["igst_unit"] != null ? json["igst_unit"] : 0,
      cgstPercentage: json.containsKey("cgst_unit") && json["cgst_unit"] != null ? json["cgst_unit"] : 0,
      sgstPercentage: json.containsKey("sgst_unit") && json["sgst_unit"] != null ? json["sgst_unit"] : 0,
      imageUrl: json.containsKey("image_dps") && json["image_dps"] != null ? List<ImageUrl>.from(json["image_dps"].map((e) => ImageUrl.fromJson(e))) : [],
      uid: json.containsKey("u_id") && json["u_id"] != null ? json["u_id"] : "",
      hsnCode: json.containsKey("hsn_code") && json["hsn_code"] != null ? json["hsn_code"] : "");

  Map<String, dynamic> toJson() => {
        "id": id,
        "quantity": quantity,
        "unit_price": unitPrice,
        "total": total,
        "product_name": productName,
        "product_image": productImage,
        "gst": gst,
        "offer": offerData,
        "tax_type": taxType,
        "unit_price_with_offer": unitPriceWithOffer,
        "total_tax": totalTax,
        "sub_total": subTotal,
        "total_price": totalPrice,
        "gst_value": gstValue,
        "offer_selected": offerSelected,
        "cgst": cgst,
        "sgst": sgst,
        "cgst_value": cgstValue,
        "sgst_value": sgstValue,
        "product_total_offer": productTotalOffer,
        "product_amount_total": productAmountTotal,
        "offer_amount": offerAmount,
        "gst_total": gstTotal,
        "product_cost": productCost,
        "batch_pricing":
            List<dynamic>.from(batchPricingList!.map((e) => e.toJson())),
        "batch_number": batchNumber,
        "quantity_in": quantityIn,
        "sgst_unit": sgstPercentage,
        "cgst_unit": cgstPercentage,
        "igst_unit": igstPercentage,
        "uid": uid,
        "hsn_code": hsnCode
      };
}

class TaxReferences {
  TaxReferences({
    this.gstNo,
  });

  String? gstNo;

  factory TaxReferences.fromJson(Map<String, dynamic> json) => TaxReferences(
        gstNo: json.containsKey("gst_no") && json["gst_no"] != null
            ? json["gst_no"]
            : "",
      );

  Map<String, dynamic> toJson() => {
        "gst_no": gstNo,
      };
}

class AdditionalCharges {
  AdditionalCharges({this.label, this.value});

  String? label;
  num? value;

  factory AdditionalCharges.fromJson(Map<String, dynamic> json) =>
      AdditionalCharges(
          label: json.containsKey("label") && json["label"] != null
              ? json["label"]
              : "",
          value: json.containsKey("value") && json["value"] != null
              ? (json["value"] is String
                  ? num.parse(json["value"])
                  : json["value"])
              : 0);

  Map<String, dynamic> toJson() => {"label": this.label, "value": this.value};
}
