class DirectorsData {
  String? personName;
  String? personSchemeName;
  String? personIdentificationNumber;
  String? personDigitalSign;
  String? digitalSignature;

  DirectorsData(
      {this.personName,
      this.personSchemeName,
      this.personIdentificationNumber,
      this.personDigitalSign,
      this.digitalSignature});
}
