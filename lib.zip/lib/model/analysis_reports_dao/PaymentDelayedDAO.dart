import 'package:vyaparlive/model/bu_model/ContactDetailsModel.dart';
import 'package:vyaparlive/model/transaction/ReceivedPaymnetDAO.dart';

class DelayPaymentsDAO {
  String? transactionId;
  String? invoiceId;
  DateTime? paymentDueDate;
  DateTime? invoiceDate;
  num? billNo;
  ContactDetails? buyer;
  List<ReceivedPaymentDAO>? receivedPayments;

  DelayPaymentsDAO(
      {this.billNo,
      this.buyer,
      this.invoiceDate,
      this.invoiceId,
      this.paymentDueDate,
      this.receivedPayments,
      this.transactionId});

  factory DelayPaymentsDAO.fromJson(Map<String, dynamic> json) => DelayPaymentsDAO(
      invoiceDate:
          json.containsKey("invoice_date") && json["invoice_date"] != null
              ? DateTime.parse(json["invoice_date"])
              : null,
      transactionId:
          json.containsKey("transactionId") && json["transactionId"] != null
              ? json["transactionId"]
              : "",
      invoiceId:
          json.containsKey("_id") && json["_id"] != null ? json["_id"] : "",
      paymentDueDate: json.containsKey("payment_due_date") &&
              json["payment_due_date"] != null
          ? DateTime.parse(json["payment_due_date"])
          : null,
      billNo:
          json.containsKey("invoice_number") && json["invoice_number"] != null
              ? json["invoice_number"]
              : 0,
      buyer: json.containsKey("buyer") && json["buyer"] != null
          ? ContactDetails.fromJson(json["buyer"])
          : null,
      receivedPayments: json.containsKey("payment_received") &&
              json["payment_received"] != null
          ? List<ReceivedPaymentDAO>.from(
              json["payment_received"].map((x) => ReceivedPaymentDAO.fromJson(x)))
          : []);
}
