import 'package:vyaparlive/components/common_methods.dart';

class ProductAnalysisDAO {
  String? productId;
  String? productName;
  DateTime? invoiceDate;
  num? count;
  num? quantity;

  ProductAnalysisDAO(
      {this.count,
      this.invoiceDate,
      this.productId,
      this.productName,
      this.quantity});

  factory ProductAnalysisDAO.fromJson(Map<String, dynamic> json) =>
      ProductAnalysisDAO(
          productId: CommonMethods.getProductId(json),
          productName:
              json.containsKey("product_name") && json["product_name"] != null
                  ? json["product_name"]
                  : "",
          invoiceDate:
              json.containsKey("invoice_date") && json["invoice_date"] != null
                  ? DateTime.parse(json["invoice_date"])
                  : null,
          count: json.containsKey("count") && json["count"] != null
              ? json["count"]
              : 0,
          quantity: json.containsKey("quantity") && json["quantity"] != null
              ? json["quantity"]
              : 0);

  Map<String, dynamic> tojson() => {
        "invoice_date": invoiceDate!.toIso8601String(),
        "product_name": productName,
        "count": count,
        "quantity": quantity
      };
}
