import 'package:vyaparlive/model/TransactionsModel.dart';

class StockReceiptItemsDAO {
  String? discrepancyCode;
  String? id;
  String? transactionId;
  num? billNo;
  Buyer? seller;
  Buyer? buyer;

  StockReceiptItemsDAO(
      {this.discrepancyCode,
      this.buyer,
      this.billNo,
      this.id,
      this.seller,
      this.transactionId});

  factory StockReceiptItemsDAO.fromJson(Map<String, dynamic> json) =>
      StockReceiptItemsDAO(
          discrepancyCode: json.containsKey("discrepancy_code") &&
                  json["discrepancy_code"] != null
              ? json["discrepancy_code"]
              : "",
          id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
          transactionId:
              json.containsKey("transactionId") && json["transactionId"] != null
                  ? json["transactionId"]
                  : "",
          billNo: json.containsKey("invoice_number") &&
                  json["invoice_number"] != null
              ? json["invoice_number"]
              : 0,
          buyer: json.containsKey("buyer") && json["buyer"] != null
              ? Buyer.fromJson(json["buyer"])
              : null,
          seller: json.containsKey("seller") && json["seller"] != null
              ? Buyer.fromJson(json["seller"])
              : null);

  Map<String, dynamic> toJson() => {
        "discrepancy_code": discrepancyCode,
        "transactionId": transactionId,
        "id": id,
        "bill_no": billNo,
        "buyer": buyer!.toJson(),
        "seller": seller!.toJson()
      };
}
