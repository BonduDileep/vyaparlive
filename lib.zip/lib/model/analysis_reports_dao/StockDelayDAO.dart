import 'package:vyaparlive/model/bu_model/ContactDetailsModel.dart';
import 'package:vyaparlive/model/transaction/DeliveryDetailsModel.dart';

class StockDelayDAO {
  DateTime? stockReceivedDate;
  OrderTrack? orderTrack;
  ContactDetails? buyer;
  dynamic billNo;
  String? transactionId;
  String? invoiceId;

  StockDelayDAO(
      {this.buyer,
      this.orderTrack,
      this.stockReceivedDate,
      this.billNo,
      this.transactionId,
      this.invoiceId});
  factory StockDelayDAO.fromJson(Map<String, dynamic> json) => StockDelayDAO(
      stockReceivedDate: json.containsKey("actual_delivery_date_time") &&
              json["actual_delivery_date_time"] != null
          ? DateTime.parse(json["actual_delivery_date_time"])
          : null,
      orderTrack: json.containsKey("order_track") && json["order_track"] != null
          ? OrderTrack.fromJson(json["order_track"])
          : null,
      buyer: json.containsKey("buyer") && json["buyer"] != null
          ? ContactDetails.fromJson(json["buyer"])
          : null,
      billNo: json.containsKey("bill_no") && json["bill_no"] != null
          ? json["bill_no"]??0
          : 0,
      transactionId:
          json.containsKey("transactionId") && json["transactionId"] != null
              ? json["transactionId"]
              : "",
      invoiceId:
          json.containsKey("_id") && json["_id"] != null ? json["_id"] : "");

  Map<String, dynamic> toJson() => {
        "buyer": buyer!.toJson(),
        "order_track": orderTrack!.toJson(),
        "actual_delivery_date_time": stockReceivedDate!.toIso8601String(),
        "transactionId": transactionId,
        "bill_no": billNo,
        "_id": invoiceId
      };
}
