import 'package:vyaparlive/model/analysis_reports_dao/StockReceiptItemsDAO.dart';

class StockReceiptDAO {
  String? transasctionId,
      buyerId,
      sellerId,
      buyerName,
      sellerName,
      invoiceStatus,
      id;
  num? invoiceNumber;
  String? discrepancyCode;
  num? count;
  List<StockReceiptItemsDAO>? discrepancyList;
  StockReceiptDAO(
      {this.buyerId,
      this.buyerName,
      this.id,
      this.invoiceStatus,
      this.sellerId,
      this.sellerName,
      this.transasctionId,
      this.invoiceNumber,
      this.count,
      this.discrepancyCode,
      this.discrepancyList});

  factory StockReceiptDAO.fromJson(Map<String, dynamic> json) => StockReceiptDAO(
      transasctionId:
          json.containsKey("transactionId") && json["transactionId"] != null
              ? json["transactionId"]
              : "",
      buyerId: json.containsKey("buyer_id") && json["buyer_id"] != null
          ? json["buyer_id"]
          : "",
      sellerId: json.containsKey("seller_id") && json["seller_id"] != null
          ? json["seller_id"]
          : "",
      buyerName: json.containsKey("buyer_name") && json["buyer_name"] != null
          ? json["buyer_name"]
          : "",
      sellerName: json.containsKey("seller_name") && json["seller_name"] != null
          ? json["seller_name"]
          : "",
      invoiceStatus:
          json.containsKey("invoice_status") && json["invoice_status"] != null
              ? json["invoice_status"]
              : "",
      id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
      invoiceNumber:
          json.containsKey("invoice_number") && json["invoice_number"] != null
              ? json["invoice_number"]
              : 0,
      count: json.containsKey("count") && json["count"] != null
          ? json["count"]
          : 0,
      discrepancyCode: json.containsKey("discrepancy_code") &&
              json["discrepancy_code"] != null
          ? json["discrepancy_code"]
          : "",
      discrepancyList: json.containsKey("items") && json["items"] != null
          ? List<StockReceiptItemsDAO>.from(json["items"].map((i) => StockReceiptItemsDAO.fromJson(i)))
          : []);

  Map<String, dynamic> toJson() => {
        "transactionId": transasctionId,
        "buyer_id": buyerId,
        "seller_id": sellerId,
        "buyer_name": buyerName,
        "invoice_status": invoiceStatus,
        "id": id,
        "invoice_number": invoiceNumber,
        "seller_name": sellerName,
        "count": count,
        "discrepancy_code": discrepancyCode,
        "items": List<dynamic>.from(discrepancyList!.map((e) => e.toJson()))
      };
}
