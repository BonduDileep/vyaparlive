import 'package:vyaparlive/model/UserModel.dart';

import 'bu_model/AddressDetailsModel.dart';

class Contacts {
  String? buId;
  String? buName;
  String? id;
  String? contactNumber;
  String? city;
  String? landmark;
  bool isOnline;
  bool? isDistributor;
  List<UserModel>? usersList;
  Address? address;

  Contacts(
      {this.buId,
      this.buName,
      this.id,
      this.contactNumber,
      this.city,
      this.landmark,
      this.isOnline = true,
      this.isDistributor = false,
      this.usersList,
      this.address});

  factory Contacts.fromJson(Map<String, dynamic> json) => Contacts(
      buId: json.containsKey("bu_id") && json["bu_id"] != null
          ? json["bu_id"]
          : "",
      buName: json.containsKey("bu_name") && json["bu_name"] != null
          ? json["bu_name"]
          : "",
      id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
      contactNumber:
          json.containsKey("contact_number") && json["contact_number"] != null
              ? json["contact_number"]
              : "",
      city:
          json.containsKey("city") && json["city"] != null ? json["city"] : "",
      landmark: json.containsKey("landmark") && json["landmark"] != null
          ? json["landmark"]
          : "",
      isDistributor:
          json.containsKey("is_distributor") && json["is_distributor"] != null
              ? json["is_distributor"]
              : false,
      usersList: json.containsKey("users_info") && json["users_info"] != null
          ? List<UserModel>.from(
              json["users_info"].map((x) => UserModel.fromJson(x)))
          : []);

  Map<String, dynamic> toJson() => {
        "bu_id": buId,
        "bu_name": buName,
        "id": id,
        "contact_number": contactNumber,
        "is_distributor": isDistributor,
        "users_info": List<dynamic>.from(usersList!.map((e) => e.toString()))
      };

  /// Using for search with buName
  @override
  String toString() {
    return '$buName'.toLowerCase() + '$buName'.toUpperCase();
  }
}
