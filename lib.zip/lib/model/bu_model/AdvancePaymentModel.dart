class AdvancePayment {
  bool? isActive;
  num? value;
  String? type;
  AdvancePayment({this.isActive = false, this.value, this.type});

  factory AdvancePayment.fromJson(Map<String, dynamic> json) => AdvancePayment(
      isActive: json.containsKey("active") && json["active"] != null
          ? json["active"]
          : false,
      value: json.containsKey("value") && json["value"] != null
          ? json["value"]
          : null,
      type:
          json.containsKey("type") && json["type"] != null ? json["type"] : "");

  Map<String, dynamic> toJson() =>
      {"active": isActive, "value": value, "type": type};
}
