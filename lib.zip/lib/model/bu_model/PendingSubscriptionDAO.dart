import 'package:vyaparlive/model/bu_model/YrSubscriptionModel.dart';

class PendingSubscriptionDAO {
  num? amountTotal;
  num? cgstTotal;
  num? sgstTotal;
  num? payableAmount;
  List<YrSubscriptions>? subscriptionList;

  PendingSubscriptionDAO(
      {this.amountTotal,
      this.cgstTotal,
      this.payableAmount,
      this.sgstTotal,
      this.subscriptionList});

  factory PendingSubscriptionDAO.fromJson(Map<String, dynamic> json) =>
      PendingSubscriptionDAO(
          amountTotal:
              json.containsKey("amount_total") && json["amount_total"] != null
                  ? json["amount_total"]
                  : 0,
          cgstTotal:
              json.containsKey("cgst_total") && json["cgst_total"] != null
                  ? json["cgst_total"]
                  : 0,
          sgstTotal:
              json.containsKey("sgst_total") && json["sgst_total"] != null
                  ? json["sgst_total"]
                  : 0,
          payableAmount: json.containsKey("payable_amount") &&
                  json["payable_amount"] != null
              ? json["payable_amount"]
              : 0,
          subscriptionList: json.containsKey("summary") &&
                  json["summary"] != null
              ? List<YrSubscriptions>.from(
                  json["summary"].map((e) => YrSubscriptions.fromJson(e)))
              : []);

  Map<String, dynamic> toJson() => {
        "amount_total": amountTotal,
        "cgst_total": cgstTotal,
        "sgst_total": sgstTotal,
        "payable_amount": payableAmount,
        "summary": List<dynamic>.from(subscriptionList!.map((e) => e.toJson()))
      };
}
