class Regulation {
  Regulation({
    this.govtbusinessSchemeid,
    this.govtregistrationId,
  });

  String? govtbusinessSchemeid;
  String? govtregistrationId;

  factory Regulation.fromJson(Map<String, dynamic> json) => Regulation(
        govtbusinessSchemeid: json.containsKey("govtbusiness_schemeid") &&
                json["govtbusiness_schemeid"] != null
            ? json["govtbusiness_schemeid"]
            : "",
        govtregistrationId: json.containsKey("govtregistration_id") &&
                json["govtregistration_id"] != null
            ? json["govtregistration_id"]
            : "",
      );

  Map<String, dynamic> toJson() => {
        "govtbusiness_schemeid": govtbusinessSchemeid,
        "govtregistration_id": govtregistrationId,
      };
}
