class PenaltyAmount {
  String? code;
  String? reason;
  String? type;
  num? value;
  PenaltyAmount({this.code, this.reason, this.type, this.value});

  factory PenaltyAmount.fromJson(Map<String, dynamic> json) => PenaltyAmount(
      code:
          json.containsKey("code") && json["code"] != null ? json["code"] : "",
      reason: json.containsKey("reason") && json["reason"] != null
          ? json["reason"]
          : "",
      value: json.containsKey("value") && json["value"] != null
          ? json["value"]
          : null,
      type:
          json.containsKey("type") && json["type"] != null ? json["type"] : "");

  Map<String, dynamic> toJson() =>
      {"code": code, "reason": reason, "type": type, "value": value};
}
