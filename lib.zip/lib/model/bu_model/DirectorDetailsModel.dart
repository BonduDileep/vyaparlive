class Directors {
  Directors({
    this.id,
    this.personName,
    this.personidentificationSchemename,
    this.personidentificationNumber,
    this.digitalSignature,
  });

  String? id;
  String? personName;
  String? personidentificationSchemename;
  String? personidentificationNumber;
  String? digitalSignature;

  factory Directors.fromJson(Map<String, dynamic> json) => Directors(
        id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
        personName:
            json.containsKey("person_name") && json["person_name"] != null
                ? json["person_name"]
                : "",
        personidentificationSchemename:
            json.containsKey("personidentification_schemename") &&
                    json["personidentification_schemename"] != null
                ? json["personidentification_schemename"]
                : "",
        personidentificationNumber:
            json.containsKey("personidentification_number") &&
                    json["personidentification_number"] != null
                ? json["personidentification_number"]
                : "",
        digitalSignature: json.containsKey("digital_signature") &&
                json["digital_signature"] != null
            ? json["digital_signature"]
            : "",
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "person_name": personName,
        "personidentification_schemename": personidentificationSchemename,
        "personidentification_number": personidentificationNumber,
        "digital_signature": digitalSignature,
      };
}
