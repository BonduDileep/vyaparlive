class TermsDAO {
  String? termType;
  String? termDescription;
  String? file;
  TermsDAO({this.termType, this.termDescription, this.file});
  factory TermsDAO.fromJson(Map<String, dynamic> json) => TermsDAO(
      termType: json.containsKey("term_type") && json["term_type"] != null
          ? json["term_type"]
          : "",
      termDescription: json.containsKey("term_descrition") &&
              json["term_description"] != null
          ? json["term_description"]
          : "",
      file:
          json.containsKey("file") && json['file'] != null ? json['file'] : "");

  Map<String, dynamic> toJson() => {
        "term_type": termType,
        "term_description": termDescription,
        'file': file
      };
}
