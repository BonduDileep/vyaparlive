class PenaltyAmountDAO {
  String? code;
  String? reason;
  String? id;

  PenaltyAmountDAO({this.code, this.id, this.reason});

  factory PenaltyAmountDAO.fromJson(Map<String, dynamic> json) =>
      PenaltyAmountDAO(
          code: json.containsKey("code") && json["code"] != null
              ? json["code"]
              : "",
          reason: json.containsKey("reason") && json["reason"] != null
              ? json["reason"]
              : "",
          id: json.containsKey("id") && json["id"] != null ? json["id"] : "");

  Map<String, dynamic> tojson() => {"code": code, "reason": reason, "id": id};
}
