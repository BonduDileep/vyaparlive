import 'package:vyaparlive/model/bu_model/StockDispatchModel.dart';

class StockReceiveLocations {
  StockReceiveLocations({
    this.id,
    this.receivelocationNumber,
    this.receivebusinessName,
    this.taxinfo,
    this.addressofreceiver,
  });

  String? id;
  String? receivelocationNumber;
  String? receivebusinessName;
  Taxinfo? taxinfo;
  Addressof? addressofreceiver;

  factory StockReceiveLocations.fromJson(Map<String, dynamic> json) =>
      StockReceiveLocations(
        id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
        receivelocationNumber: json.containsKey("receivelocation_number") &&
                json["receivelocation_number"] != null
            ? json["receivelocation_number"]
            : "",
        receivebusinessName: json.containsKey("receivebusiness_name") &&
                json["receivebusiness_name"] != null
            ? json["receivebusiness_name"]
            : "",
        taxinfo: json.containsKey("taxinfo") && json["taxinfo"] != null
            ? Taxinfo.fromJson(json["taxinfo"])
            : "" as Taxinfo?,
        addressofreceiver: json.containsKey("addressofreceiver") &&
                json["addressofreceiver"] != null
            ? Addressof.fromJson(json["addressofreceiver"])
            : "" as Addressof?,
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "receivelocation_number": receivelocationNumber,
        "receivebusiness_name": receivebusinessName,
        "taxinfo": taxinfo!.toJson(),
        "addressofreceiver": addressofreceiver!.toJson(),
      };
}
