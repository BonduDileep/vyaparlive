class BankDetail {
  BankDetail(
      {this.id,
      this.bankName,
      this.bankAccountName,
      this.bankAccountNumber,
      this.ePayCode,
      this.swifTcode,
      this.micrCode,
      this.ifscCode,
      this.isShowBankDataInInvoice});

  String? id;
  String? bankName;
  String? bankAccountName;
  String? bankAccountNumber;
  String? ePayCode;
  String? swifTcode;
  String? micrCode;
  String? ifscCode;
  bool? isShowBankDataInInvoice;

  factory BankDetail.fromJson(Map<String, dynamic> json) => BankDetail(
      id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
      bankName: json.containsKey("BankName") && json["BankName"] != null
          ? json["BankName"]
          : "",
      bankAccountName:
          json.containsKey("BankAccountName") && json["BankAccountName"] != null
              ? json["BankAccountName"]
              : "",
      bankAccountNumber: json.containsKey("BankAccountNumber") &&
              json["BankAccountNumber"] != null
          ? json["BankAccountNumber"]
          : "",
      ePayCode: json.containsKey("EPayCode") && json["EPayCode"] != null
          ? json["EPayCode"]
          : "",
      swifTcode: json.containsKey("SWIFTcode") && json["SWIFTcode"] != null
          ? json["SWIFTcode"]
          : "",
      micrCode: json.containsKey("MICRCode") && json["MICRCode"] != null
          ? json["MICRCode"]
          : "",
      ifscCode: json.containsKey("IFSC Code") && json["IFSC Code"] != null
          ? json["IFSC Code"]
          : "",
      isShowBankDataInInvoice: json.containsKey("show_bank_details") &&
              json["show_bank_details"] != null
          ? json["show_bank_details"]
          : false);

  Map<String, dynamic> toJson() => {
        "id": id,
        "BankName": bankName,
        "BankAccountName": bankAccountName,
        "BankAccountNumber": bankAccountNumber,
        "EPayCode": ePayCode,
        "SWIFTcode": swifTcode,
        "MICRCode": micrCode,
        "IFSC Code": ifscCode,
        "show_bank_details": isShowBankDataInInvoice
      };
}
