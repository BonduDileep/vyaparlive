class PaymentTermsDAO {
  String? id;
  String? paymentTerm;
  String? termCode;
  num? days;

  PaymentTermsDAO({this.id, this.paymentTerm, this.termCode, this.days});

  factory PaymentTermsDAO.fromJson(Map<String, dynamic> json) =>
      PaymentTermsDAO(
          id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
          paymentTerm: json.containsKey("invoice_payment_terms") &&
                  json["invoice_payment_terms"] != null
              ? json["invoice_payment_terms"]
              : "",
          termCode: json.containsKey("term_code") && json["term_code"] != null
              ? json["term_code"]
              : "",
          days: json.containsKey("days") && json["days"] != null
              ? json["days"]
              : 0);

  Map<String, dynamic> toJson() => {
        "id": id,
        "invoice_payment_terms": paymentTerm,
        "term_code": termCode,
        "days": days
      };
}
