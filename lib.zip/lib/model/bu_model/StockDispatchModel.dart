class StockDispatchLocations {
  StockDispatchLocations({
    this.id,
    this.dispatchlocationNumber,
    this.dispatchbusinessName,
    this.taxinfo,
    this.addressofsender,
  });

  String? id;
  String? dispatchlocationNumber;
  String? dispatchbusinessName;
  Taxinfo? taxinfo;
  Addressof? addressofsender;

  factory StockDispatchLocations.fromJson(Map<String, dynamic> json) =>
      StockDispatchLocations(
        id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
        dispatchlocationNumber: json.containsKey("dispatchlocation_number") &&
                json["dispatchlocation_number"] != null
            ? json["dispatchlocation_number"]
            : "",
        dispatchbusinessName: json.containsKey("dispatchbusiness_name") &&
                json["dispatchbusiness_name"] != null
            ? json["dispatchbusiness_name"]
            : "",
        taxinfo: json.containsKey("taxinfo") && json["taxinfo"] != null
            ? Taxinfo.fromJson(json["taxinfo"])
            : "" as Taxinfo?,
        addressofsender: json.containsKey("addressofsender") &&
                json["addressofsender"] != null
            ? Addressof.fromJson(json["addressofsender"])
            : "" as Addressof?,
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "dispatchlocation_number": dispatchlocationNumber,
        "dispatchbusiness_name": dispatchbusinessName,
        "taxinfo": taxinfo!.toJson(),
        "addressofsender": addressofsender!.toJson(),
      };
}

class Addressof {
  Addressof(
      {this.id,
      this.name,
      this.address,
      this.contactNo,
      this.houseNo,
      this.streetName,
      this.city,
      this.country,
      this.district,
      this.landMark,
      this.locality,
      this.postalCode,
      this.state,
      this.buildingNo,
      this.plotNo,
      this.user,
      this.taluka});

  String? id;
  String? name;
  String? address;
  String? contactNo;
  String? houseNo;
  String? buildingNo;
  String? streetName;
  String? locality;
  String? landMark;
  String? country;
  String? state;
  String? district;
  String? city;
  String? taluka;
  String? postalCode;
  String? plotNo;
  String? user;

  factory Addressof.fromJson(Map<String, dynamic> json) => Addressof(
      id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
      user: json.containsKey("user") && json["user"] != null
          ? json["user"]
          : null,
      name:
          json.containsKey("name") && json["name"] != null ? json["name"] : "",
      address: json.containsKey("address") && json["address"] != null
          ? json["address"]
          : "",
      contactNo: json.containsKey("contact_no") && json["contact_no"] != null
          ? json["contact_no"]
          : "",
      houseNo: json.containsKey("buildinghousenumber") &&
              json['buildinghousenumber'] != null
          ? json['buildinghousenumber']
          : "",
      buildingNo: json.containsKey("building_no") && json["building_no"] != null
          ? json["building_no"]
          : "",
      streetName: json.containsKey("buildingstreetname") &&
              json['buildingstreetname'] != null
          ? json['buildingstreetname']
          : "",
      locality: json.containsKey("colonysector_arealocality") &&
              json['colonysector_arealocality'] != null
          ? json['colonysector_arealocality']
          : "",
      landMark: json.containsKey("landmark") && json['landmark'] != null
          ? json['landmark']
          : "",
      plotNo: json.containsKey("plot_no") && json["plot_no"] != null
          ? json["plot_no"]
          : "",
      country: json.containsKey("country") && json['country'] != null ? json['country'] : "",
      state: json.containsKey("state") && json['state'] != null ? json['state'] : "",
      district: json.containsKey("district") && json['district'] != null ? json['district'] : "",
      city: json.containsKey("villagetowncity") && json['villagetowncity'] != null ? json['villagetowncity'] : "",
      taluka: json.containsKey("taluka") && json['taluka'] != null ? json['taluka'] : "",
      postalCode: json.containsKey("postcode") && json['postcode'] != null ? json['postcode'] : "");

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "user": user,
        "address": address,
        "contact_no": contactNo,
        "buildinghousenumber": houseNo,
        "building_no": buildingNo,
        "buildingstreetname": streetName,
        "colonysector_arealocality": locality,
        "landmark": landMark,
        "country": country,
        "state": state,
        "ditrict": district,
        "villagetowncity": city,
        "taluka": taluka,
        "plot_no": plotNo,
        "postcode": postalCode
      };
}

class Taxinfo {
  Taxinfo({
    this.id,
    this.taxname,
    this.taxid,
    this.exemptionReason,
  });

  String? id;
  String? taxname;
  String? taxid;
  String? exemptionReason;

  factory Taxinfo.fromJson(Map<String, dynamic> json) => Taxinfo(
        id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
        taxname: json.containsKey("taxname") && json["taxname"] != null
            ? json["taxname"]
            : "",
        taxid: json.containsKey("taxid") && json["taxid"] != null
            ? json["taxid"]
            : "",
        exemptionReason: json.containsKey("exemption_reason") &&
                json["exemption_reason"] != null
            ? json["exemption_reason"]
            : "",
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "taxname": taxname,
        "taxid": taxid,
        "exemption_reason": exemptionReason,
      };
}
