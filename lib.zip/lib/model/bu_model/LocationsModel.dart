import 'package:vyaparlive/model/bu_model/AddressDetailsModel.dart';

class Locations {
  Locations({
    this.contactNumber,
    this.contactPerson,
    this.locationId,
    this.locationName,
    this.addressDetails,
    this.locationType,
    this.isSelected = false,
  });
  String? locationId;
  String? locationName;
  String? contactPerson;
  String? contactNumber;
  Address? addressDetails;
  String? locationType;
  bool isSelected;

  factory Locations.fromJson(Map<String, dynamic> json) => Locations(
        locationId:
            json.containsKey("location_id") && json["location_id"] != null
                ? json["location_id"]
                : "",
        locationName:
            json.containsKey("location_name") && json["location_name"] != null
                ? json["location_name"]
                : "",
        contactPerson:
            json.containsKey("contact_person") && json["contact_person"] != null
                ? json["contact_person"]
                : "",
        contactNumber:
            json.containsKey("contact_number") && json["contact_number"] != null
                ? json["contact_number"]
                : "",
        addressDetails: json.containsKey("address") && json["address"] != null
            ? Address.fromJson(json["address"])
            : null,
        locationType:
            json.containsKey("location_type") && json["location_type"] != null
                ? json["location_type"]
                : "",
      );

  Map<String, dynamic> toJson() => {
        "location_id": locationId,
        "location_name": locationName,
        "contact_person": contactPerson,
        "contact_number": contactNumber,
        "address": addressDetails,
        "location_type": locationType
      };
}
