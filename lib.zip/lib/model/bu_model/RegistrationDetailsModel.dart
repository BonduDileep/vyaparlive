class Registration {
  Registration(
      {this.govtregisteredName,
      this.legalentityType,
      this.govtregistrationScheme,
      this.govtregisteredSchemeid,
      this.registrationDate,
      this.registrationCity,
      this.registrationState,
      this.govtclassifiedLineofbusiness,
      this.registrationCountry,
      this.cinNumber,
      this.panNumber});

  String? govtregisteredName;
  String? legalentityType;
  String? govtregistrationScheme;
  String? govtregisteredSchemeid;
  String? registrationDate;
  String? registrationCity;
  String? registrationState;
  String? govtclassifiedLineofbusiness;
  String? registrationCountry;
  String? panNumber;
  String? cinNumber;

  factory Registration.fromJson(Map<String, dynamic> json) => Registration(
      govtregisteredName:
          json.containsKey("govtregistered_name") && json["govtregistered_name"] != null
              ? json["govtregistered_name"]
              : "",
      legalentityType: json.containsKey("legalentity_type") && json["legalentity_type"] != null
          ? json["legalentity_type"]
          : null,
      govtregistrationScheme: json.containsKey("govtregistration_scheme") &&
              json["govtregistration_scheme"] != null
          ? json["govtregistration_scheme"]
          : "",
      govtregisteredSchemeid: json.containsKey("govtregistered_schemeid") &&
              json["govtregistered_schemeid"] != null
          ? json["govtregistered_schemeid"]
          : "",
      registrationDate:
          json.containsKey("registration_date") && json["registration_date"] != null
              ? json["registration_date"]
              : "",
      registrationCity:
          json.containsKey("registration_city") && json["registration_city"] != null
              ? json["registration_city"]
              : null,
      registrationState: json.containsKey("registration_state") && json["registration_state"] != null ? json["registration_state"] : null,
      registrationCountry: json.containsKey("registration_country") && json["registration_country"] != null ? json["registration_country"] : null,
      govtclassifiedLineofbusiness: json.containsKey("govtclassified_lineofbusiness") && json["govtclassified_lineofbusiness"] != null ? json["govtclassified_lineofbusiness"] : "",
      panNumber: json.containsKey("pan_number") && json["pan_number"] != null ? json["pan_number"] : "",
      cinNumber: json.containsKey("cin_number") && json["cin_number"] != null ? json["cin_number"] : "");

  Map<String, dynamic> toJson() => {
        "govtregistered_name": govtregisteredName,
        "legalentity_type": legalentityType,
        "govtregistration_scheme": govtregistrationScheme,
        "govtregistered_schemeid": govtregisteredSchemeid,
        "registration_date": registrationDate,
        "registration_city": registrationCity,
        "registration_state": registrationState,
        "registration_country": registrationCountry,
        "govtclassified_lineofbusiness": govtclassifiedLineofbusiness,
        "pan_number": panNumber,
        "cin_number": cinNumber
      };
}
