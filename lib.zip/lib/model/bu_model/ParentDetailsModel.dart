class ParentDetails {
  ParentDetails({this.id});
  String? id;

  factory ParentDetails.fromJson(Map<String, dynamic> json) => ParentDetails(
        id: json.containsKey("OrgId") && json["OrgId"] != null
            ? json["OrgId"]
            : "",
      );

  Map<String, dynamic> toJson() => {
        "id": id,
      };
}
