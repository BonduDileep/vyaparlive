import 'package:vyaparlive/model/bu_model/AddressDetailsModel.dart';
import 'package:vyaparlive/model/bu_model/TaxSchemeModel.dart';

class ContactDetails {
  ContactDetails(
      {this.primarycontactname,
      this.address,
      this.gstNumber,
      this.shipToAddress,
      this.contactNumber,
      this.countryCode,
      this.currencySymbol,
      this.contactName,
      this.taxList,
      this.isOffline,
      this.contact});

  String? primarycontactname;
  Address? address;
  String? gstNumber;
  Address? shipToAddress;
  String? countryCode;
  String? contactNumber;
  String? currencySymbol;
  String? contactName;
  List<TaxScheme>? taxList;
  bool? isOffline;
  String? contact;

  factory ContactDetails.fromJson(Map<String, dynamic> json) => ContactDetails(
        primarycontactname: json.containsKey("primarycontactname") &&
                json["primarycontactname"] != null
            ? json["primarycontactname"]
            : "",
        address: json.containsKey("address") && json["address"] != null
            ? Address.fromJson(json["address"])
            : null,
        gstNumber: json.containsKey("GST_No") && json["GST_No"] != null
            ? json["GST_No"]
            : "",
        shipToAddress: json.containsKey("ship_to_address") &&
                json["ship_to_address"] != null
            ? Address.fromJson(json["ship_to_address"])
            : null,
        countryCode:
            json.containsKey("country_code") && json["country_code"] != null
                ? json["country_code"]
                : "",
        contactNumber:
            json.containsKey("contact_number") && json["contact_number"] != null
                ? json["contact_number"]
                : "",
        currencySymbol: json.containsKey("currency_symbol") &&
                json["currency_symbol"] != null
            ? json["currency_symbol"]
            : "",
        contactName: json.containsKey("name") && json["name"] != null
            ? json["name"]
            : "",
        taxList: json.containsKey("tax_scheme") && json["tax_scheme"] != null
            ? List<TaxScheme>.from(
                json['tax_scheme'].map((x) => TaxScheme.fromJson(x)))
            : [],
        isOffline: json.containsKey("is_offline") && json['is_offline'] != null
            ? json['is_offline']
            : false,
        contact: json.containsKey("contact") && json["contact"] != null
            ? json["contact"]
            : "",
      );

  Map<String, dynamic> toJson() => {
        "primarycontactname": primarycontactname,
        "address": address!.toJson(),
        "GST_No": gstNumber,
        "ship_to_address": shipToAddress!.toJson(),
        "contact_number": contactNumber,
        "country_code": countryCode,
        "currency_symbol": currencySymbol,
        "name": contactName,
        "tax_scheme": List.from(taxList!.map((e) => e.toJson())),
        'is_offline': isOffline,
        'contact': contact,
      };
}
