class Address {
  Address(
      {this.addressformat,
      this.businesslocationnumber,
      this.buildinghousenumber,
      this.buildingstreetname,
      this.colonysectorArealocality,
      this.villagetowncity,
      this.taluk,
      this.landmark,
      this.state,
      this.district,
      this.postcode,
      this.country,
      this.plotNo,
      this.buildingNo,
      this.contactNumber,
      this.contactPerson,
      this.phoneNumberOnInvoice,
      this.emailOnInvoice,
      this.locationName,
      this.locationId,
      this.gpsData,
      this.city});

  String? addressformat;
  String? businesslocationnumber;
  String? buildingNo;
  String? buildinghousenumber;
  String? buildingstreetname;
  String? colonysectorArealocality;
  String? villagetowncity;
  String? taluk;
  String? landmark;
  String? state;
  String? district;
  String? postcode;
  String? country;
  String? plotNo;
  String? contactPerson;
  String? contactNumber;
  String? phoneNumberOnInvoice;
  String? emailOnInvoice;
  String? locationName;
  String? locationId;
  String? city;
  Gps? gpsData;

  factory Address.fromJson(Map<String, dynamic> json) => Address(
      addressformat: json.containsKey("addressformat") && json["addressformat"] != null
          ? json["addressformat"]
          : "",
      plotNo: json.containsKey("plot_no") && json["plot_no"] != null
          ? json["plot_no"]
          : "",
      businesslocationnumber: json.containsKey("businesslocationnumber") &&
              json["businesslocationnumber"] != null
          ? json["businesslocationnumber"]
          : "",
      buildinghousenumber:
          json.containsKey("buildinghousenumber") && json["buildinghousenumber"] != null
              ? json["buildinghousenumber"]
              : "",
      buildingNo: json.containsKey("building_no") && json["building_no"] != null
          ? json["building_no"]
          : "",
      buildingstreetname:
          json.containsKey("buildingstreetname") && json["buildingstreetname"] != null
              ? json["buildingstreetname"]
              : "",
      colonysectorArealocality: json.containsKey("colonysector_arealocality") &&
              json["colonysector_arealocality"] != null
          ? json["colonysector_arealocality"]
          : "",
      villagetowncity: json.containsKey("villagetowncity") && json["villagetowncity"] != null ? json["villagetowncity"] : null,
      taluk: json.containsKey("taluk") && json["taluk"] != null ? json["taluk"] : "",
      landmark: json.containsKey("landmark") && json["landmark"] != null ? json["landmark"] : "",
      state: json.containsKey("state") && json["state"] != null ? json["state"] : null,
      district: json.containsKey("district") && json["district"] != null ? json["district"] : null,
      postcode: json.containsKey("postcode") && json["postcode"] != null ? json["postcode"] : "",
      country: json.containsKey("country") && json["country"] != null ? json["country"] : null,
      contactNumber: json.containsKey("contact_number") && json["contact_number"] != null ? json["contact_number"] : "",
      contactPerson: json.containsKey("contact_person") && json["contact_person"] != null ? json["contact_person"] : "",
      phoneNumberOnInvoice: json.containsKey("phone_number_on_invoice") && json["phone_number_on_invoice"] != null ? json["phone_number_on_invoice"] : "",
      emailOnInvoice: json.containsKey("email_on_invoice") && json["email_on_invoice"] != null ? json["email_on_invoice"] : "",
      locationName: json.containsKey("location_name") && json['location_name'] != null ? json['location_name'] : '',
      locationId: json.containsKey('location_id') && json['location_id'] != null ? json['location_id'] : "",
      city:json.containsKey("city") && json["city"] != null ? json["city"] : "",
      gpsData: json.containsKey("gps") && json["gps"] != null ? Gps.fromJson(json['gps']) : null);

  Map<String, dynamic> toJson() => {
        "addressformat": addressformat,
        "businesslocationnumber": businesslocationnumber,
        "buildinghousenumber": buildinghousenumber,
        "building_no": buildingNo,
        "buildingstreetname": buildingstreetname,
        "colonysector_arealocality": colonysectorArealocality,
        "villagetowncity": villagetowncity,
        "taluk": taluk,
        "landmark": landmark,
        "state": state,
        "district": district,
        "postcode": postcode,
        "country": country,
        "plot_no": plotNo,
        "contact_person": contactPerson,
        "contact_number": contactNumber,
        "email_on_invoice": emailOnInvoice,
        "phone_number_on_invoice": phoneNumberOnInvoice,
        "location_name": locationName,
        "location_id": locationId,
        "gps": gpsData,
        "city": city
      };
}

class Gps {
  double? latitude;
  double? langitude;

  Gps({this.langitude, this.latitude});

  factory Gps.fromJson(Map<String, dynamic> json) => Gps(
      langitude: json.containsKey("lang") &&
              json["lang"] != null &&
              json["lang"] is double
          ? json["lang"]
          : 0.0,
      latitude: json.containsKey("lat") &&
              json["lat"] != null &&
              json["lang"] is double
          ? json["lat"]
          : 0.0);

  Map<String, dynamic> toJson() => {"lang": langitude, "lat": latitude};
}
