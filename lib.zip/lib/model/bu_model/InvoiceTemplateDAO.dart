class InvoiceTemplateDAO {
  String? tempLogo;
  int? tempId;

  InvoiceTemplateDAO({this.tempId, this.tempLogo});

  factory InvoiceTemplateDAO.fromJson(Map<String, dynamic> json) =>
      InvoiceTemplateDAO(
          tempId: json.containsKey("template_id") && json["template_id"] != null
              ? json["template_id"]
              : 0,
          tempLogo: json.containsKey("logo") && json["logo"] != null
              ? json["logo"]
              : "");

  Map<String, dynamic> toJson() => {"logo": tempLogo, "template_id": tempId};
}
