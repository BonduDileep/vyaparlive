class Ports {
  Ports({
    this.country,
    this.govtregistrationSchemename,
    this.govtregistrationSchemeid,
  });

  String? country;
  String? govtregistrationSchemename;
  String? govtregistrationSchemeid;

  factory Ports.fromJson(Map<String, dynamic> json) => Ports(
        country: json.containsKey("country") && json["country"] != null
            ? json["country"]
            : null,
        govtregistrationSchemename:
            json.containsKey("govtregistration_schemename") &&
                    json["govtregistration_schemename"] != null
                ? json["govtregistration_schemename"]
                : "",
        govtregistrationSchemeid:
            json.containsKey("govtregistration_schemeid") &&
                    json["govtregistration_schemeid"] != null
                ? json["govtregistration_schemeid"]
                : "",
      );

  Map<String, dynamic> toJson() => {
        "country": country,
        "govtregistration_schemename": govtregistrationSchemename,
        "govtregistration_schemeid": govtregistrationSchemeid,
      };
}
