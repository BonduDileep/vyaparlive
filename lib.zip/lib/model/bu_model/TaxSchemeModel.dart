class TaxScheme {
  String? id;
  String? schemeName;
  String? schemeNumber;
  String? reason;

  TaxScheme({this.id, this.schemeName, this.schemeNumber, this.reason});

  factory TaxScheme.fromJson(Map<String, dynamic> json) => TaxScheme(
        id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
        schemeName: json.containsKey("govttaxscheme_name") &&
                json["govttaxscheme_name"] != null
            ? json["govttaxscheme_name"]
            : "",
        schemeNumber: json.containsKey("govttaxscheme_number") &&
                json["govttaxscheme_number"] != null
            ? json["govttaxscheme_number"]
            : "",
        reason: json.containsKey("taxexemption_reason") &&
                json["taxexemption_reason"] != null
            ? json["taxexemption_reason"]
            : "",
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "govttaxscheme_name": schemeName,
        "govttaxscheme_number": schemeNumber,
        "taxexemption_reason": reason,
      };
}
