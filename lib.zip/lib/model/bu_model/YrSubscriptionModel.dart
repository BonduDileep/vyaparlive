class YrSubscriptions {
  YrSubscriptions(
      {this.noOfAllowedUsers,
      this.endDate,
      this.basic,
      this.extraSubscription,
      this.isShowPaynowButton,this.invoiceId});

  int? noOfAllowedUsers;
  DateTime? endDate;
  BasicSubscription? basic;
  List<ExtraSubscription>? extraSubscription;
  bool? isShowPaynowButton;
  String? invoiceId;

  factory YrSubscriptions.fromJson(Map<String, dynamic> json) =>
      YrSubscriptions(
          noOfAllowedUsers: json.containsKey("no_of_allowed_users") &&
                  json["no_of_allowed_users"] != null
              ? json["no_of_allowed_users"]
              : 0,
          endDate: json.containsKey("end_date") && json["end_date"] != null
              ? DateTime.parse(json["end_date"])
              : null,
          basic: json.containsKey("basic") && json["basic"] != null
              ? BasicSubscription.fronJson(json["basic"])
              : null,
          extraSubscription: json.containsKey("extra") && json["extra"] != null
              ? List<ExtraSubscription>.from(
                  json["extra"].map((x) => ExtraSubscription.fromJson(x)))
              : [],
          isShowPaynowButton: json.containsKey("canShowPaymentBtn") &&
                  json["canShowPaymentBtn"] != null
              ? json["canShowPaymentBtn"]
              : false,
              invoiceId:json.containsKey("invoice_id")&&json["invoice_id"]!=null?json["invoice_id"]:""
              );

  Map<String, dynamic> toJson() => {
        "no_of_allowed_users": noOfAllowedUsers,
        "end_date": endDate!.toIso8601String(),
        "basic": basic!.toJson(),
        "extra": List<dynamic>.from(extraSubscription!.map((x) => x.toString())),
        "canShowPaymentBtn": isShowPaynowButton,
        "invoice_id":invoiceId
      };
}

class BasicSubscription {
  DateTime? startDate;
  int? amount;
  String? checksum;
  int? paymentOrderId;
  String? paymentRefId;
  String? paymentStatus;
  String? paymentTxnId;
  num? cgst;
  num? sgst;
  num? igst;
  num? payableAmount;

  BasicSubscription(
      {this.startDate,
      this.amount,
      this.checksum,
      this.paymentOrderId,
      this.paymentRefId,
      this.paymentStatus,
      this.paymentTxnId,
      this.cgst,
      this.igst,
      this.sgst,
      this.payableAmount});

  factory BasicSubscription.fronJson(Map<String, dynamic> json) => BasicSubscription(
      startDate: json.containsKey("start_date") && json["start_date"] != null
          ? DateTime.parse(json["start_date"])
          : DateTime.now(),
      amount: json.containsKey("amount") && json["amount"] != null
          ? json["amount"]
          : 0,
      checksum: json.containsKey("checksum") && json["checksum"] != null
          ? json["checksum"]
          : "",
      paymentTxnId:
          json.containsKey("payment_txn_id") && json["payment_txn_id"] != null
              ? json["payment_txn_id"]
              : "",
      paymentOrderId: json.containsKey("payment_order_id") &&
              json['payment_order_id'] != null
          ? json['payment_order_id']
          : 0,
      paymentRefId:
          json.containsKey("payment_ref_id") && json['payment_ref_id'] != null
              ? json['payment_ref_id']
              : "",
      paymentStatus:
          json.containsKey("payment_status") && json["payment_status"] != null
              ? json["payment_status"]
              : "",
      igst: json.containsKey("igst") && json["igst"] != null ? json["igst"] : 0,
      cgst: json.containsKey("cgst") && json["cgst"] != null ? json["cgst"] : 0,
      sgst: json.containsKey("sgst") && json["sgst"] != null ? json["sgst"] : 0,
      payableAmount:
          json.containsKey("payable_amount") && json["payable_amount"] != null
              ? json["payable_amount"]
              : 0);

  Map<String, dynamic> toJson() => {
        "checksum": checksum,
        "amount": amount,
        "start_date": startDate!.toIso8601String(),
        "payment_status": paymentStatus,
        "payment_ref_id": paymentRefId,
        "payment_order_id": paymentOrderId,
        "payment_txn_id": paymentTxnId,
        "igst": igst,
        "cgst": cgst,
        "sgst": sgst,
        "payable_amount": payableAmount
      };
}

class ExtraSubscription {
  DateTime? startDate;
  DateTime? endDate;
  String? checksum;
  int? amount;

  ExtraSubscription({this.amount, this.checksum, this.endDate, this.startDate});

  factory ExtraSubscription.fromJson(Map<String, dynamic> json) =>
      ExtraSubscription(
          startDate:
              json.containsKey("start_date") && json["start_date"] != null
                  ? DateTime.parse(json["start_date"])
                  : DateTime.now(),
          endDate: json.containsKey("endDate") && json["endDate"] != null
              ? DateTime.parse(json["endDate"])
              : DateTime.now(),
          amount: json.containsKey("amount") && json["amount"] != null
              ? json["amount"]
              : 0,
          checksum: json.containsKey("checksum") && json["checksum"] != null
              ? json["checksum"]
              : "");

  Map<String, dynamic> toJson() => {
        "checksum": checksum,
        "amount": amount,
        "endDate": endDate!.toIso8601String(),
        "start_date": startDate!.toIso8601String()
      };
}
