class YrDetails {
  YrDetails({
    this.businessunitId,
    this.legalentityId,
    this.groupheadId,
    this.bulegalentity,
    this.bugrouphead,
  });

  String? businessunitId;
  String? legalentityId;
  String? groupheadId;
  String? bulegalentity;
  String? bugrouphead;

  factory YrDetails.fromJson(Map<String, dynamic> json) => YrDetails(
        businessunitId: json.containsKey("businessunit_id") &&
                json["businessunit_id"] != null
            ? json["businessunit_id"]
            : "",
        legalentityId:
            json.containsKey("legalentity_id") && json["legalentity_id"] != null
                ? json["legalentity_id"]
                : "",
        groupheadId:
            json.containsKey("grouphead_id") && json["grouphead_id"] != null
                ? json["grouphead_id"]
                : "",
        bulegalentity:
            json.containsKey("bulegalentity") && json["bulegalentity"] != null
                ? json["bulegalentity"]
                : "",
        bugrouphead:
            json.containsKey("bugrouphead") && json["bugrouphead"] != null
                ? json["bugrouphead"]
                : "",
      );

  Map<String, dynamic> toJson() => {
        "businessunit_id": businessunitId,
        "legalentity_id": legalentityId,
        "grouphead_id": groupheadId,
        "bulegalentity": bulegalentity,
        "bugrouphead": bugrouphead,
      };
}
