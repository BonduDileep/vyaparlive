import 'package:vyaparlive/model/bu_model/AdvancePaymentModel.dart';
import 'package:vyaparlive/model/bu_model/PenaltyDetailsModel.dart';
import 'package:vyaparlive/model/bu_model/TermsModel.dart';

class PaymentTerms {
  PaymentTerms(
      {this.id,
      this.invoicecurrencycode,
      this.penaltyAmount,
      this.advancePayment,
      this.comment,
      this.invoicePaymentTerms,
      this.termsList,
      this.paymentperiodcode,
      this.numberofdays,
      this.invoiceDescription,
      this.partialpaymentpercent,
      this.penaltyamount,
      this.penaltypercentrate,
      this.description,
      this.penaltybasisamount,
      this.termCode,
      this.paymentTermsDays});

  String? id;
  String? invoicecurrencycode;
  String? invoicePaymentTerms;
  String? comment;
  PenaltyAmount? penaltyAmount;
  AdvancePayment? advancePayment;
  List<TermsDAO>? termsList;
  String? paymentperiodcode;
  String? numberofdays;
  String? invoiceDescription;
  String? partialpaymentpercent;
  String? penaltyamount;
  String? penaltypercentrate;
  String? description;
  String? penaltybasisamount;
  String? termCode;
  num? paymentTermsDays;

  factory PaymentTerms.fromJson(Map<String, dynamic> json) => PaymentTerms(
      id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
      invoicecurrencycode: json.containsKey("invoice_currency_code") &&
              json["invoice_currency_code"] != null
          ? json["invoice_currency_code"]
          : "",
      invoicePaymentTerms: json.containsKey("invoice_payment_terms") &&
              json["invoice_payment_terms"] != null
          ? json["invoice_payment_terms"]
          : "",
      comment: json.containsKey("comments") && json["comments"] != null
          ? json["comments"]
          : "",
      penaltyAmount:
          json.containsKey("penalty_amount") && json["penalty_amount"] != null
              ? PenaltyAmount.fromJson(json["penalty_amount"])
              : null,
      advancePayment:
          json.containsKey("advance_payment") && json["advance_payment"] != null
              ? AdvancePayment.fromJson(json["advance_payment"])
              : null,
      termsList: json.containsKey("terms") && json["terms"] != null
          ? List<TermsDAO>.from(json["terms"].map((x) => TermsDAO.fromJson(x)))
          : [],
      paymentperiodcode: json.containsKey("paymentperiodcode") &&
              json["paymentperiodcode"] != null
          ? json["paymentperiodcode"]
          : "",
      numberofdays: json.containsKey("numberofdays") ? json["numberofdays"] : null,
      invoiceDescription: json.containsKey("invoice_description") ? json["invoice_description"] : "",
      partialpaymentpercent: json.containsKey("partialpaymentpercent") && json["partialpaymentpercent"] != null ? json["partialpaymentpercent"] : "",
      penaltyamount: json.containsKey("penaltyamount") && json["penaltyamount"] != null ? json["penaltyamount"] : "",
      penaltypercentrate: json.containsKey("penaltypercentrate") && json["penaltypercentrate"] != null ? json["penaltypercentrate"] : "",
      description: json.containsKey("description") && json["description"] != null ? json["description"] : "",
      penaltybasisamount: json.containsKey("penaltybasisamount") && json["penaltybasisamount"] != null ? json["penaltybasisamount"] : "",
      termCode: json.containsKey("term_code") && json["term_code"] != null ? json["term_code"] : "",
      paymentTermsDays: json.containsKey("days") && json["days"] != null ? json["days"] : 0);

  Map<String, dynamic> toJson() => {
        "id": id,
        "invoice_currency_code": invoicecurrencycode,
        "invoice_payment_terms": invoicePaymentTerms,
        "penalty_amount": penaltyAmount!.toJson(),
        "comments": comment,
        "advance_payment_value": advancePayment!.toJson(),
        "terms": List<dynamic>.from(termsList!.map((x) => x.toJson())),
        "paymentperiodcode": paymentperiodcode,
        "numberofdays": numberofdays,
        "invoice_description": invoiceDescription,
        "partialpaymentpercent": partialpaymentpercent,
        "penaltyamount": penaltyamount,
        "penaltypercentrate": penaltypercentrate,
        "description": description,
        "penaltybasisamount": penaltybasisamount,
        "days": paymentTermsDays
      };
}
