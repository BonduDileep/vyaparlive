class StockDetailsModel {
  String? stockLocationNumber;
  String? stockLocationName;
  String? houseNo;
  String? buildingNo;
  String? streetName;
  String? locality;
  String? landmark;
  String? city;
  String? taluka;
  String? postalCode;
  String? country;
  String? state;
  String? district;
  String? userName;
  String? plotNo;
  String? locationType;
  String? locationId;
  StockDetailsModel(
      {this.stockLocationNumber,
      this.stockLocationName,
      this.city,
      this.country,
      this.district,
      this.houseNo,
      this.buildingNo,
      this.landmark,
      this.locality,
      this.postalCode,
      this.state,
      this.streetName,
      this.taluka,
      this.plotNo,
      this.userName,
      this.locationType,
      this.locationId});
}
