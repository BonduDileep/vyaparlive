import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/model/PendingProductsDAO.dart';

class PaymentRemainderDAO {
  String? transactionId;
  num? invoiceNo;
  DateTime? createdDate;
  String? status;
  DateTime? paymentDueDate;
  BuyerDetails? buyer;
  BuyerDetails? seller;
  num? invoiceAmount;
  String? invoiceId;

  PaymentRemainderDAO(
      {this.buyer,
      this.createdDate,
      this.invoiceNo,
      this.paymentDueDate,
      this.seller,
      this.status,
      this.transactionId,
      this.invoiceAmount,
      this.invoiceId});

  factory PaymentRemainderDAO.fromJson(Map<String, dynamic> json) =>
      PaymentRemainderDAO(
          buyer: json.containsKey("buyer") &&
                  json['buyer'] != null
              ? BuyerDetails.fromJson(json['buyer'])
              : null,
          seller: json.containsKey(
                      "seller") &&
                  json['seller'] != null
              ? BuyerDetails.fromJson(json['seller'])
              : null,
          transactionId: CommonMethods.getTransactionIdFromRes(json),
          invoiceNo:
              json.containsKey(
                          "bill_no") &&
                      json['bill_no'] != null
                  ? json['bill_no']
                  : 0,
          createdDate:
              json.containsKey(
                          "created_date") &&
                      json['created_date'] != null
                  ? DateTime.parse(json['created_date'])
                  : null,
          invoiceAmount:
              json
                          .containsKey("invoice_amount") &&
                      json['invoice_amount'] != null
                  ? json['invoice_amount']
                  : 0,
          status: json.containsKey("status") && json['status'] != null
              ? json['status']
              : "",
          paymentDueDate: json.containsKey("payment_due_date") &&
                  json['payment_due_date'] != null
              ? DateTime.parse(json['payment_due_date'])
              : null,
          invoiceId:
              json.containsKey("id") && json["id"] != null ? json["id"] : "");

  Map<String, dynamic> toJson() => {
        "buyer": buyer,
        "seller": seller,
        "txnId": transactionId,
        "bill_no": invoiceNo,
        "created_date": createdDate!.toIso8601String(),
        "invoice_amount": invoiceAmount,
        "status": status,
        "payment_due_date": paymentDueDate!.toIso8601String(),
        "id": invoiceId
      };
}
