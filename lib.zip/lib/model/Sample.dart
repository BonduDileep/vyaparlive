class SampleProduct {
  int? id;
  int? counter;
  int? isButton;
  String? productname;
  String? productImage;
  int? price;
  int? quantity;
  String? category;
  String? date;
  String? orderfrom;
  String? batchOneQuantity;
  String? batchTwoQuantity;
  String? batchThreeQuantity;
  String? batchOnePrice;
  String? batchTwoPrice;
  String? batchThreePrice;
  String? productQuality;

  SampleProduct(
      this.id,
      this.productname,
      this.counter,
      this.isButton,
      this.productImage,
      this.price,
      this.quantity,
      this.category,
      this.date,
      this.orderfrom,
      this.batchOneQuantity,
      this.batchTwoQuantity,
      this.batchThreeQuantity,
      this.batchOnePrice,
      this.batchTwoPrice,
      this.batchThreePrice,
      this.productQuality);

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      'id': id,
      'productname': productname,
      'counter': counter,
      'product_image': productImage,
      'quantity': quantity,
      'price': price,
      'category': category,
      'date': date,
      'orderfrom': orderfrom,
      'batch_one_quantity': batchOneQuantity,
      'batch_two_quantity': batchTwoQuantity,
      'batch_three_quantity': batchThreeQuantity,
      'batch_one_price': batchOnePrice,
      'batch_two_price': batchTwoPrice,
      'batch_three_price': batchThreePrice,
      'product_quality': productQuality
    };
    return map;
  }

  SampleProduct.fromMap(Map<String, dynamic> map) {
    id = map['id'];
    productname = map['productname'];
    counter = map['counter'];
    productImage = map['product_image'];
    quantity = map['quantity'];
    category = map['category'];
    date = map['date'];
    orderfrom = map['orderfrom'];
    batchOneQuantity = map['batch_one_quantity'];
    batchTwoQuantity = map['batch_two_quantity'];
    batchThreeQuantity = map['batch_three_quantity'];
    batchOnePrice = map['batch_one_price'];
    batchTwoPrice = map['batch_two_price'];
    batchThreePrice = map['batch_three_price'];
    productQuality = map['product_quality'];
  }
}
