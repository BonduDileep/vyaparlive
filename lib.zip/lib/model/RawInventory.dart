class RawInventory {
  String? issuedTo;
  num? quantity;
  String? batchNumber;

  RawInventory({this.issuedTo, this.quantity,this.batchNumber});

  factory RawInventory.fromJson(Map<String, dynamic> json) => RawInventory(
        issuedTo: json.containsKey("issued_to") && json["issued_to"] != null
            ? json["issued_to"]
            : "",
        quantity: json.containsKey("quantity") && json["quantity"] != null
            ? json["quantity"]
            : 0,
            batchNumber:  json.containsKey("batch_no") && json["batch_no"] != null
            ? json["batch_no"]
            : "",
      );

  Map<String, dynamic> toJson() =>
      {"quantity": quantity, "issued_to": issuedTo,"batch_no":batchNumber};
}
