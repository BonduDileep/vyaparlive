class InvitationFieldsData {
  String inviteeName = "";
  String inviteeContactNumber = "";
  String inviteeEmail = "";
  String businessRelation = "";
  String businessName = "";

  String businessRole = "";
  String ableToInvite = "";
  String businessUnitId = "";
  String city = "";
  String state = "";
  String country = "";
  String currency = "";
  String countryCode = "";
  String parentId = "";

  String? get getInviteeName => inviteeName;

  set setInviteeName(String inviteeName) => this.inviteeName = inviteeName;

  String? get getInviteeContactNumber => inviteeContactNumber;

  set setInviteeContactNumber(String inviteeContactNumber) =>
      this.inviteeContactNumber = inviteeContactNumber;

  String? get getInviteeEmail => inviteeEmail;

  set setInviteeEmail(String inviteeEmail) => this.inviteeEmail = inviteeEmail;

  String? get getBusinessRelation => businessRelation;

  set setBusinessRelation(String businessRelation) =>
      this.businessRelation = businessRelation;

  String? get getBusinessName => businessName;

  set setBusinessName(String businessName) => this.businessName = businessName;

  String? get getBusinessRole => businessRole;

  set setBusinessRole(String businessRole) => this.businessRole = businessRole;

  String? get getAbleToInvite => ableToInvite;

  set setAbleToInvite(String ableToInvite) => this.ableToInvite = ableToInvite;

  String? get getBusinessUnitId => businessUnitId;

  set setBusinessUnitId(String businessUnitId) =>
      this.businessUnitId = businessUnitId;

  String? get getCity => city;

  set setCity(String city) => this.city = city;

  String? get getState => state;

  set setState(String state) => this.state = state;

  String? get getCountry => country;

  set setCountry(String country) => this.country = country;

  String? get getCurrency => currency;

  set setCurrency(String currency) => this.currency = currency;

  String? get getCountryCode => countryCode;

  set setCountryCode(String countryCode) => this.countryCode = countryCode;

  set setParentId(String selectedBuId) => this.parentId = selectedBuId;

  String? get getParentId => parentId;
}
