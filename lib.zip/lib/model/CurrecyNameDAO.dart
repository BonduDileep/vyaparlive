class CurrencyNameDAO implements Comparable<CurrencyNameDAO> {
  String? lookupName;
  String? id;
  String? name;
  String? code;
  String? htmlSymbol;

  CurrencyNameDAO(
      {this.lookupName, this.id, this.name, this.code, this.htmlSymbol});

  factory CurrencyNameDAO.fromJson(Map<String, dynamic> json) =>
      CurrencyNameDAO(
          lookupName:
              json.containsKey("lookup_name") && json["lookup_name"] != null
                  ? json["lookup_name"]
                  : "",
          id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
          name: json.containsKey("name") && json["name"] != null
              ? json["name"]
              : "",
          code: json.containsKey("code") && json["code"] != null
              ? json["code"]
              : "",
          htmlSymbol:
              json.containsKey("html_symbol") && json["html_symbol"] != null
                  ? json["html_symbol"]
                  : "");

  Map<String, dynamic> toJson() => {
        "lookup_name": lookupName,
        "id": id,
        "name": name,
        "code": code,
        "html_symbol": htmlSymbol
      };

  @override
  int compareTo(CurrencyNameDAO other) {
    // TODO: implement compareTo
    return name!.compareTo(other.name!);
  }
}
