class ProductDataModal {
  String productname;
  int id;
  int counter;
  int isButton;
  String productImage;
  int price;
  String quantity;
  String category;
  String date;
  String orderfrom;
//  String orderfrom;
  String batchOneQuantity;
  String batchTwoQuantity;
  String batchThreeQuantity;
  String batchOnePrice;
  String batchTwoPrice;
  String batchThreePrice;
  String productQuality;
  ProductDataModal(
      this.id,
      this.productname,
      this.counter,
      this.isButton,
      this.productImage,
      this.price,
      this.quantity,
      this.category,
      this.date,
      this.orderfrom,
      this.batchOneQuantity,
      this.batchTwoQuantity,
      this.batchThreeQuantity,
      this.batchOnePrice,
      this.batchTwoPrice,
      this.batchThreePrice,
      this.productQuality);
}
