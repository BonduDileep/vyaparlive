class TaxSchemeData {
  // ignore: non_constant_identifier_names
  String? govttaxscheme_name;
  // ignore: non_constant_identifier_names
  String? govttaxscheme_number;
  // ignore: non_constant_identifier_names
  String? taxexemption_reason;

  TaxSchemeData(
      // ignore: non_constant_identifier_names
      {this.govttaxscheme_name,
      // ignore: non_constant_identifier_names
      this.govttaxscheme_number,
      // ignore: non_constant_identifier_names
      this.taxexemption_reason});
}
