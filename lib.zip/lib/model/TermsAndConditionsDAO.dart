import 'package:vyaparlive/model/bu_model/PaymentTermsModel.dart';

class TermsAndConditionsDAO {
  TermsAndConditionsDAO({
    this.buId,
    this.buName,
    this.status,
    this.paymentTerms,
    this.id,
  });

  String? buId;
  String? buName;
  String? status;

  PaymentTerms? paymentTerms;
  String? id;

  factory TermsAndConditionsDAO.fromJson(Map<String, dynamic> json) =>
      TermsAndConditionsDAO(
        buId:
            json.containsKey("") && json["bu_id"] != null ? json["bu_id"] : "",
        buName: json.containsKey("") && json["bu_name"] != null
            ? json["bu_name"]
            : "",
        status: json.containsKey("") && json["status"] != null
            ? json["status"]
            : "",
        paymentTerms:
            json.containsKey("payment_terms") && json["payment_terms"] != null
                ? PaymentTerms.fromJson(json["payment_terms"])
                : null,
        id: json["id"],
      );

  Map<String, dynamic> toJson() => {
        "bu_id": buId,
        "bu_name": buName,
        "status": status,
        "payment_terms": paymentTerms!.toJson(),
        "id": id,
      };
}
