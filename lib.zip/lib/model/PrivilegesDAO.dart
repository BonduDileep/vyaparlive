class PrivilegesDAO {
  String? id;
  String? name;
  String? code;
  String? description;
  String? featureGroup;
  String? label;
  bool? isEnabled;
  String? key;
  List<HierarchyChildrenDAO>? childrenList;
  PrivilegesDAO(
      {this.id,
      this.name,
      this.code,
      this.description,
      this.featureGroup,
      this.childrenList,
      this.label,
      this.isEnabled = false,
      this.key});

  factory PrivilegesDAO.fromJson(Map<String, dynamic> json) => PrivilegesDAO(
      id: json.containsKey("_id") && json["_id"] != null ? json["_id"] : "",
      name:
          json.containsKey("name") && json["name"] != null ? json["name"] : "",
      code:
          json.containsKey("code") && json["code"] != null ? json["code"] : "",
      featureGroup:
          json.containsKey("feature_group") && json["feature_group"] != null
              ? json["feature_group"]
              : "",
      description:
          json.containsKey("description") && json["description"] != null
              ? json["description"]
              : "",
      label: json.containsKey("label") && json["label"] != null
          ? json["label"]
          : "",
      childrenList: json.containsKey('children') && json["children"] != null
          ? List<HierarchyChildrenDAO>.from(
              json["children"].map((x) => HierarchyChildrenDAO.fromJson(x)))
          : [],
      key: json.containsKey("key") && json["key"] != null ? json["key"] : "");

  Map<String, dynamic> toJson() => {
        "_id": id,
        "name": name,
        "code": code,
        "description": description,
        "feature_group": featureGroup,
        "label": label.toString(),
        "children": List<dynamic>.from(childrenList!.map((e) => e.toJson())),
        "key": key.toString()
      };
}

class HierarchyChildrenDAO {
  String? label;
  String? code;
  String? type;
  bool? isEnabled;
  HierarchyChildrenDAO(
      {this.code, this.label, this.type, this.isEnabled = false});

  factory HierarchyChildrenDAO.fromJson(Map<String, dynamic> json) =>
      HierarchyChildrenDAO(
          label: json.containsKey("label") && json["label"] != null
              ? json["label"]
              : "",
          code: json.containsKey("code") && json["code"] != null
              ? json["code"]
              : "",
          type: json.containsKey("type") && json["type"] != null
              ? json["type"]
              : "");

  Map<String, dynamic> toJson() => {
        "label": label.toString(),
        "code": code.toString(),
        "type": type.toString()
      };
}
