import 'package:vyaparlive/model/bu_model/AddressDetailsModel.dart';

class RetailGrpcDAO {
  String? id;
  String? name;
  String? mobileNummber;
  Address? address;
  String? buId;
  String? discountType;
  num? discount;
  String? retailId;
  List<String>? terms;
  bool? ssf_crm;
  RetailGrpcDAO(
      {this.address,
      this.buId,
      this.discount,
      this.discountType,
      this.mobileNummber,
      this.name,
      this.terms,
      this.retailId,
      this.id,
      this.ssf_crm = false});

  factory RetailGrpcDAO.fromJson(Map<String, dynamic> json) => RetailGrpcDAO(
      retailId: json.containsKey("id") && json["id"] != null ? json["id"] : "",
      id: json.containsKey("_id") && json["_id"] != null ? json["_id"] : "",
      name:
          json.containsKey("name") && json["name"] != null ? json["name"] : "",
      mobileNummber:
          json.containsKey("mobile_number") && json["mobile_number"] != null
              ? json["mobile_number"]
              : "",
      address: json.containsKey("address") && json["address"] != null
          ? Address.fromJson(json["address"])
          : null,
      buId: json.containsKey("bu_id") && json["bu_id"] != null
          ? json["bu_id"]
          : "",
      discountType:
          json.containsKey("discount_type") && json["discount_type"] != null
              ? json["discount_type"]
              : "",
      discount: json.containsKey("discount") && json["discount"] != null
          ? json["discount"]
          : 0,
      ssf_crm:
          json.containsKey("ssf_crm") && json["ssf_crm"] != null
              ? json["ssf_crm"]
              : false,
      terms: json.containsKey("terms") && json["terms"] != null
          ? List<String>.from(json["terms"].map((e) => e))
          : []);

  Map<String, dynamic> toJson() => {
        "_id": id,
        "id": retailId,
        "name": name,
        "mobile_number": mobileNummber,
        "address": address!.toJson(),
        "bu_id": buId,
        "discount_type": discountType,
        "discount": discount,
        "terms": List<String>.from(terms!.map((e) => e)),
        "ssf_crm_user": ssf_crm
      };
}
