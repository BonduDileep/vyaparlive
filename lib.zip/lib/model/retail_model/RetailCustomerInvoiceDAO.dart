import 'package:vyaparlive/model/InvoiceDAO.dart';
import 'package:vyaparlive/model/TransactionsModel.dart';
import 'package:vyaparlive/model/bu_model/AddressDetailsModel.dart';

class RetailCustomerInvoiceDAO {
  Buyer? seller;
  RetailBuyer? retailBuyer;
  dynamic invoiceNum;
  num? discount;
  String? discountType;
  InvoiceDAO? invoiceDetails;
  DateTime? createdDate;
  String? invoiceId;
  num? paid_amount;
  num? pending_amount;
  String? id;
  String? status;

  RetailCustomerInvoiceDAO(
      {this.createdDate,
      this.discount,
      this.discountType,
      this.invoiceDetails,
      this.invoiceNum,
      this.retailBuyer,
      this.seller,
      this.invoiceId,
      this.paid_amount,
      this.pending_amount,
      this.id,
      this.status}); // add paid_amount, pending_amount out side invoice_details

  // and one more paid_amount come in invoice_details as array of objects or null

  factory RetailCustomerInvoiceDAO.fromJson(Map<String, dynamic> json) =>
      RetailCustomerInvoiceDAO(
        seller: json.containsKey("seller") && json["seller"] != null
            ? Buyer.fromJson(json["seller"])
            : null,
        retailBuyer: json.containsKey("buyer") && json["buyer"] != null
            ? RetailBuyer.fromJson(json["buyer"])
            : null,
        invoiceDetails: json.containsKey("invoice_details") &&
                json["invoice_details"] != null
            ? InvoiceDAO.fromJson(json["invoice_details"])
            : null,
        discount: json.containsKey("discount") && json["discount"] != null
            ? json["discount"]
            : 0,
        discountType:
            json.containsKey("discount_type") && json["discount_type"] != null
                ? json["discount_type"]
                : "",
        invoiceNum:
            json.containsKey("invoice_number") && json["invoice_number"] != null
                ? json["invoice_number"]??0
                : 0,
        createdDate:
            json.containsKey("created_date") && json["created_date"] != null
                ? DateTime.parse(json["created_date"])
                : DateTime.now().toUtc().toString() as DateTime?,
        invoiceId:
            json.containsKey("id") && json["id"] != null ? json["id"] : "",
        paid_amount:
            json.containsKey("paid_amount") && json["paid_amount"] != null
                ? json["paid_amount"]
                : 0,
        pending_amount:
            json.containsKey("pending_amount") && json["pending_amount"] != null
                ? json["pending_amount"]
                : 0,
        id: json.containsKey("_id") && json["_id"] != null ? json["_id"] : "",
        status: json.containsKey("status") && json["status"] != null
            ? json["status"]
            : "",
      );

  Map<String, dynamic> toJson() => {
        "seller": seller!.toJson(),
        "buyer": retailBuyer!.toJson(),
        "invoice_details": invoiceDetails!.toJson(),
        "discount": discount,
        "discount_type": discountType,
        "invoice_number": invoiceNum,
        "created_date": createdDate!.toIso8601String(),
        "id": invoiceId,
        "paid_amount": paid_amount,
        "pending_amount": pending_amount,
        "_id": id
      };
}

class RetailBuyer {
  String? retailId;
  String? name;
  String? mobile;
  Address? address;

  RetailBuyer({this.address, this.name, this.retailId, this.mobile});

  factory RetailBuyer.fromJson(Map<String, dynamic> json) => RetailBuyer(
      retailId: json.containsKey("id") && json["id"] != null ? json["id"] : "",
      name:
          json.containsKey("name") && json["name"] != null ? json["name"] : "",
      address: json.containsKey("address") && json["address"] != null
          ? Address.fromJson(json["address"])
          : "" as Address?,
      mobile: json.containsKey("mobile_number") && json["mobile_number"] != null
          ? json["mobile_number"]
          : "");

  Map<String, dynamic> toJson() => {
        "id": retailId,
        "name": name,
        "address": address,
        "mobile_number": mobile
      };
}
