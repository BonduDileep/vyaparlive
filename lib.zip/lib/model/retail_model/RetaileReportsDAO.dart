import 'package:vyaparlive/model/InvoiceDAO.dart';
import 'package:vyaparlive/model/retail_model/RetailCustomerInvoiceDAO.dart';
import 'package:vyaparlive/model/bu_model/ContactDetailsModel.dart';

class RetailReportsDAO {
  ContactDetails? seller;
  RetailBuyer? buyer;
  List<Product>? productList;
  dynamic billNo;
  DateTime? invoiceDate;
  num? invoiceAmount;
  num? paidAmount;
  String? id;
  num? pendingAmount;
  String? paymentStatus;
  String? status;
  num? saleProfit;

  RetailReportsDAO(
      {this.billNo,
      this.buyer,
      this.id,
      this.invoiceAmount,
      this.invoiceDate,
      this.paidAmount,
      this.productList,
      this.seller,
      this.pendingAmount,
      this.paymentStatus,
      this.status,
      this.saleProfit});

  factory RetailReportsDAO.fromJson(Map<String, dynamic> json) =>
      RetailReportsDAO(
        seller: json.containsKey("seller") && json["seller"] != null
            ? ContactDetails.fromJson(json["seller"])
            : null,
        buyer: json.containsKey("buyer") && json["buyer"] != null
            ? RetailBuyer.fromJson(json["buyer"])
            : null,
        billNo: json.containsKey("bill_no") && json["bill_no"] != null
            ? json["bill_no"]??0
            : 0,
        invoiceAmount:
            json.containsKey("invoice_amount") && json["invoice_amount"] != null
                ? json["invoice_amount"]
                : 0,
        invoiceDate:
            json.containsKey("invoice_date") && json["invoice_date"] != null
                ? DateTime.parse(json["invoice_date"])
                : DateTime.now().toUtc(),
        paidAmount:
            json.containsKey("paid_amount") && json["paid_amount"] != null
                ? json["paid_amount"]
                : 0,
        id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
        productList: json.containsKey("products") && json["products"] != null
            ? List<Product>.from(
                json["products"].map((e) => Product.fromJson(e)))
            : [],
        pendingAmount:
            json.containsKey("pending_amount") && json["pending_amount"] != null
                ? json["pending_amount"]
                : 0,
        paymentStatus:
            json.containsKey("payment_status") && json["payment_status"] != null
                ? json["payment_status"]
                : "",
        status: json.containsKey("status") && json["status"] != null
            ? json["status"]
            : "",
        saleProfit: json.containsKey("sale_profit") && json["sale_profit"] != null
            ? json["sale_profit"]
            : 0,
      );

  Map<String, dynamic> toJson() => {
        "seller": seller!.toJson(),
        "buyer": buyer!.toJson(),
        "id": id,
        "bill_no": billNo,
        "invoice_amount": invoiceAmount,
        "invoice_date": invoiceDate!.toIso8601String(),
        "paid_amount": paidAmount,
        "products": List<dynamic>.from(productList!.map((e) => e.toJson())),
        "pending_amount": pendingAmount,
        "payment_status": paymentStatus,
        "status": status,
        "sale_profit":saleProfit
      };
}
