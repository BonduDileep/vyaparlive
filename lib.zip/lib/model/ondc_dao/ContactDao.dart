class ContactDao {
  String? phone;
  ContactDao({this.phone});

  factory ContactDao.fromJson(Map<String, dynamic> json) => ContactDao(
      phone: json.containsKey("phone") && json["phone"] != null
          ? json["phone"]
          : "");

  Map<String, dynamic> toJson() => {"phone": phone.toString()};
}
