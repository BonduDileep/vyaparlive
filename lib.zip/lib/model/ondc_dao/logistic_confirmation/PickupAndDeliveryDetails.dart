import 'package:vyaparlive/model/ondc_dao/Categories.dart';
import 'package:vyaparlive/model/ondc_dao/ContactDao.dart';

import '../LocationsDao.dart';
import '../PersonDao.dart';

class PickupAndDeliveryDetails {
  CategorieTime? time;
  LocationDao? locationData;
  ContactDao? contactDao;
  PersonDao? personDao;

  PickupAndDeliveryDetails(
      {this.contactDao, this.locationData, this.personDao, this.time});

  factory PickupAndDeliveryDetails.fromJson(Map<String, dynamic> json) =>
      PickupAndDeliveryDetails(
        time: json.containsKey("time") && json["time"] != null
            ? CategorieTime.fromJson(json["time"])
            : null,
        locationData: json.containsKey("location") && json["location"] != null
            ? LocationDao.fromJson(json["location"])
            : null,
        contactDao: json.containsKey("contact") && json["contact"] != null
            ? ContactDao.fromJson(json["contact"])
            : null,
        personDao: json.containsKey("person") && json["person"] != null
            ? PersonDao.fromJson(json["person"])
            : null,
      );

  Map<String, dynamic> toJson() => {
        "person": personDao!.toJson(),
        "contact": contactDao!.toJson(),
        "location": locationData!.toJson(),
        "time": time!.toJson()
      };
}
