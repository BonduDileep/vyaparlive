class AgentDao {
  String? name;
  String? phone;

  AgentDao({this.name, this.phone});

  factory AgentDao.fromJson(Map<String, dynamic> json) => AgentDao(
      name:
          json.containsKey("name") && json["name"] != null ? json["name"] : "",
      phone: json.containsKey("phone") && json["phone"] != null
          ? json["phone"]
          : "");

  Map<String, dynamic> toJson() =>
      {"name": name.toString(), "phone": phone.toString()};
}
