import '../OndcOrderedProducts.dart';

class QuoteDao {
  PriceDao? priceDao;
  QuoteDao({this.priceDao});

  factory QuoteDao.fromJson(Map<String, dynamic> json) => QuoteDao(
      priceDao: json.containsKey("price") && json["price"] != null
          ? PriceDao.fromJson(json["price"])
          : null);

  Map<String, dynamic> toJson() => {"price": priceDao!.toJson()};
}
