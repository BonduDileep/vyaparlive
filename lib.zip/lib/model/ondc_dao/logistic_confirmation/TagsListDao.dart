class TagsListDao {
  String? code;
  List<TrackingList>? list;

  TagsListDao({this.code, this.list});

  factory TagsListDao.fromJson(Map<String, dynamic> json) => TagsListDao(
      code:
          json.containsKey("code") && json["code"] != null ? json["code"] : "",
      list: json.containsKey("list") && json["list"] != null
          ? List<TrackingList>.from(
              json["list"].map((e) => TrackingList.fromJson(e)))
          : []);

  Map<String, dynamic> toJson() => {
        "code": code.toString(),
        "list": List<dynamic>.from(list!.map((e) => e))
      };
}

class TrackingList {
  String? code;
  String? value;

  TrackingList({this.code, this.value});

  factory TrackingList.fromJson(Map<String, dynamic> json) => TrackingList(
      code:
          json.containsKey("code") && json["code"] != null ? json["code"] : "",
      value: json.containsKey("value") && json["value"] != null
          ? json["value"]
          : "");

  Map<String, dynamic> toJson() =>
      {"code": code.toString(), "value": value.toString()};
}
