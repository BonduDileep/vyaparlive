import 'package:vyaparlive/model/ondc_dao/logistic_confirmation/LogisticMessagesDao.dart';

class LogisticConfirmationDao {
  LogisticMessagesDao? messagesDao;

  LogisticConfirmationDao({this.messagesDao});

  factory LogisticConfirmationDao.fromJson(Map<String, dynamic> json) =>
      LogisticConfirmationDao(
          messagesDao: json.containsKey("message") && json["message"] != null
              ? LogisticMessagesDao.fromJson(json["message"])
              : null);

  Map<String, dynamic> toJson() => {"message": messagesDao!.toJson()};
}
