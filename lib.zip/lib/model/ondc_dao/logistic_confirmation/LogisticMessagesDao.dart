import 'package:vyaparlive/model/ondc_dao/logistic_confirmation/LogisticOrdersDao.dart';

class LogisticMessagesDao {
  LogisticOrdersDao? ordersDao;

  LogisticMessagesDao({this.ordersDao});

  factory LogisticMessagesDao.fromJson(Map<String, dynamic> json) =>
      LogisticMessagesDao(
          ordersDao: json.containsKey("order") && json["order"] != null
              ? LogisticOrdersDao.fromJson(json["order"])
              : null);

  Map<String, dynamic> toJson() => {"order": ordersDao!.toJson()};
}
