class VehicleDetailsDao {
  String? registrationNumber;

  VehicleDetailsDao({this.registrationNumber});

  factory VehicleDetailsDao.fromJson(Map<String, dynamic> json) =>
      VehicleDetailsDao(
          registrationNumber:
              json.containsKey("registration") && json["registration"] != null
                  ? json["registration"]
                  : "");

  Map<String, dynamic> toJson() =>
      {"registration": registrationNumber.toString()};
}
