import 'package:vyaparlive/model/ondc_dao/FulfillmentDao.dart';
import 'package:vyaparlive/model/ondc_dao/logistic_confirmation/QuoteDao.dart';

class LogisticOrdersDao {
  String? id;
  String? state;
  QuoteDao? quoteDao;
  List<FullfillmentDao>? fullfillmentDao;

  LogisticOrdersDao({this.fullfillmentDao, this.id, this.quoteDao, this.state});

  factory LogisticOrdersDao.fromJson(Map<String, dynamic> json) =>
      LogisticOrdersDao(
          id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
          state: json.containsKey("state") && json["state"] != null
              ? json["state"]
              : "",
          quoteDao: json.containsKey("quote") && json["quote"] != null
              ? QuoteDao.fromJson(json["quote"])
              : null,
          fullfillmentDao: json.containsKey("fulfillments") &&
                  json["fulfillments"] != null
              ? List<FullfillmentDao>.from(
                  json["fulfillments"].map((e) => FullfillmentDao.fromJson(e)))
              : []);

  Map<String, dynamic> toJson() => {
        "fulfillments": List<dynamic>.from(fullfillmentDao!.map((e) => e)),
        "quote": quoteDao!.toJson(),
        "state": state.toString(),
        "id": id.toString()
      };
}
