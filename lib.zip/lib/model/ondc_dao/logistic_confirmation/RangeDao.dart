class RangeDao {
  DateTime? startTime;
  DateTime? endTime;

  RangeDao({this.endTime, this.startTime});

  factory RangeDao.fromJson(Map<String, dynamic> json) => RangeDao(
      startTime: json.containsKey("start") && json["start"] != null
          ? DateTime.parse(json["start"])
          : null,
      endTime: json.containsKey("end") && json["end"] != null
          ? DateTime.parse(json["end"])
          : null);

  Map<String, dynamic> toJson() => {
        "start": startTime!.toIso8601String(),
        "end": endTime!.toIso8601String()
      };
}
