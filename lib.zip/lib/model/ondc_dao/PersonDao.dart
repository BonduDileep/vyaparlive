class PersonDao {
  String? name;
  PersonDao({this.name});

  factory PersonDao.fromJson(Map<String, dynamic> json) => PersonDao(
      name:
          json.containsKey("name") && json["name"] != null ? json["name"] : "");

  Map<String, dynamic> toJson() => {"name": name.toString()};
}
