class Descriptor {
  String? name;
  String? shortDesc;
  String? longDesc;
  String? code;

  Descriptor({this.code, this.longDesc, this.name, this.shortDesc});

  factory Descriptor.fromJson(Map<String, dynamic> json) => Descriptor(
      code:
          json.containsKey("code") && json['code'] != null ? json['code'] : "",
      shortDesc: json.containsKey("short_desc") && json['short_desc'] != null
          ? json['short_desc']
          : "",
      longDesc: json.containsKey("long_desc") && json['long_desc'] != null
          ? json['long_desc']
          : "",
      name:
          json.containsKey("name") && json['name'] != null ? json['name'] : "");

  Map<String, dynamic> toJson() => {
        "long_desc": longDesc.toString(),
        "name": name.toString(),
        "code": code.toString(),
        "short_desc": shortDesc.toString()
      };
}
