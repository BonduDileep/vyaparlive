import 'package:vyaparlive/model/ondc_dao/Categories.dart';
import 'package:vyaparlive/model/ondc_dao/Descriptor.dart';
import 'package:vyaparlive/model/ondc_dao/FulfillmentDao.dart';
import 'package:vyaparlive/model/ondc_dao/LocationsDao.dart';
import 'package:vyaparlive/model/ondc_dao/OndcOrderedProducts.dart';

class LogisticProvider {
  String? id;
  Descriptor? descriptor;
  List<Categories>? categories;
  List<OndcOrderedProducts>? products;
  List<LocationDao>? location;
  List<FullfillmentDao>? fullfillmentDao;
  bool isChecked;
  String? lspId;

  LogisticProvider(
      {this.categories,
      this.descriptor,
      this.id,
      this.products,
      this.location,
      this.fullfillmentDao,
      this.isChecked = false,
      this.lspId});

  factory LogisticProvider.fromJson(Map<String, dynamic> json) =>
      LogisticProvider(
          id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
          descriptor:
              json.containsKey("descriptor") && json["descriptor"] != null
                  ? Descriptor.fromJson(json["descriptor"])
                  : null,
          categories:
              json.containsKey("categories") && json["categories"] != null
                  ? List<Categories>.from(
                      json["categories"].map((e) => Categories.fromJson(e)))
                  : [],
          products: json.containsKey("items") && json["items"] != null
              ? List<OndcOrderedProducts>.from(
                  json["items"].map((e) => OndcOrderedProducts.fromJson(e)))
              : [],
          location: json.containsKey("locations") && json["locations"] != null
              ? List<LocationDao>.from(
                  json["locations"].map((e) => LocationDao.fromJson(e)))
              : [],
          fullfillmentDao: json.containsKey("fulfillments") &&
                  json["fulfillments"] != null
              ? List<FullfillmentDao>.from(
                  json["fulfillments"].map((e) => FullfillmentDao.fromJson(e)))
              : []);

  Map<String, dynamic> toJson() => {
        "id": id.toString(),
        "descriptor": descriptor!.toJson(),
        "categories": List<dynamic>.from(categories!.map((e) => e)),
        "items": List<dynamic>.from(products!.map((e) => e)),
        "locations": List<dynamic>.from(location!.map((e) => e)),
        "fulfillments": List<dynamic>.from(fullfillmentDao!.map((e) => e)),
      };
}
