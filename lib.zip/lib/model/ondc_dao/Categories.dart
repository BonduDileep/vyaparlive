import 'logistic_confirmation/RangeDao.dart';

class Categories {
  String? id;
  CategorieTime? time;

  Categories({this.id, this.time});

  factory Categories.fromJson(Map<String, dynamic> json) => Categories(
      id: json.containsKey("id") && json['id'] != null ? json['id'] : "",
      time: json.containsKey("time") && json['time'] != null
          ? CategorieTime.fromJson(json['time'])
          : null);

  Map<String, dynamic> toJson() =>
      {"id": id.toString(), "time": time!.toJson()};
}

class CategorieTime {
  String? label;
  String? duration;
  DateTime? timeStamp;
  RangeDao? rangeDao;
  CategorieTime({this.duration, this.label, this.timeStamp, this.rangeDao});

  factory CategorieTime.fromJson(Map<String, dynamic> json) => CategorieTime(
      label: json.containsKey("label") && json['label'] != null
          ? json['label']
          : "",
      duration: json.containsKey("duration") && json['duration'] != null
          ? json['duration']
          : "",
      timeStamp: json.containsKey("timestamp") && json["timestamp"] != null
          ? DateTime.parse(json["timestamp"])
          : DateTime.now(),
      rangeDao: json.containsKey("range") && json["range"] != null
          ? RangeDao.fromJson(json["range"])
          : null);

  Map<String, dynamic> toJson() => {
        "timestamp": timeStamp!.toIso8601String(),
        "duration": duration.toString(),
        "label": label.toString(),
        "range": rangeDao!.toJson()
      };
}
