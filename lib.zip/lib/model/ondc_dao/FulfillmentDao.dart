import 'package:vyaparlive/model/ondc_dao/logistic_confirmation/AgentDao.dart';
import 'package:vyaparlive/model/ondc_dao/logistic_confirmation/PickupAndDeliveryDetails.dart';
import 'package:vyaparlive/model/ondc_dao/logistic_confirmation/VehicleDetailsDao.dart';

import 'logistic_confirmation/TagsListDao.dart';

class FullfillmentDao {
  String? id;
  String? type;
  bool? tracking;
  PickupAndDeliveryDetails? pickupDetails;
  PickupAndDeliveryDetails? deliveryDetails;
  AgentDao? agentDao;
  VehicleDetailsDao? vehicleDetailsDao;
  List<TagsListDao>? tagsListDao;

  FullfillmentDao(
      {this.agentDao,
      this.deliveryDetails,
      this.id,
      this.pickupDetails,
      this.tagsListDao,
      this.tracking,
      this.type,
      this.vehicleDetailsDao});

  factory FullfillmentDao.fromJson(Map<String, dynamic> json) =>
      FullfillmentDao(
          id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
          type: json.containsKey("type") && json["type"] != null
              ? json["type"]
              : "",
          tracking: json.containsKey("tracking") && json["tracking"] != null
              ? json["tracking"]
              : false,
          pickupDetails: json.containsKey("start") && json["start"] != null
              ? PickupAndDeliveryDetails.fromJson(json["start"])
              : null,
          deliveryDetails: json.containsKey("end") && json["end"] != null
              ? PickupAndDeliveryDetails.fromJson(json["end"])
              : null,
          agentDao: json.containsKey("agent") && json["agent"] != null
              ? AgentDao.fromJson(json["agent"])
              : null,
          vehicleDetailsDao:
              json.containsKey("vehicle") && json["vehicle"] != null
                  ? VehicleDetailsDao.fromJson(json["vehicle"])
                  : null,
          tagsListDao: json.containsKey("tags") && json["tags"] != null
              ? List<TagsListDao>.from(
                  json["tags"].map((e) => TagsListDao.fromJson(e)))
              : []);

  Map<String, dynamic> toJson() => {
        "id": id.toString(),
        "type": type.toString(),
        "tracking": tracking,
        "start": pickupDetails!.toJson(),
        "end": deliveryDetails!.toJson(),
        "agent": agentDao!.toJson(),
        "vehicle": vehicleDetailsDao!.toJson(),
        "tags": List<dynamic>.from(tagsListDao!.map((e) => e))
      };
}
