import 'package:vyaparlive/model/ondc_dao/LogisticProvider.dart';

class ListOfInvoiceProvidersDAO {
  String? id;
  List<LogisticProvider>? providers;

  ListOfInvoiceProvidersDAO({this.id, this.providers});

  factory ListOfInvoiceProvidersDAO.fromJson(Map<String, dynamic> json) =>
      ListOfInvoiceProvidersDAO(
          id: json.containsKey("_id") && json["_id"] != null ? json["_id"] : "",
          providers: json.containsKey("providers") && json["providers"] != null
              ? List<LogisticProvider>.from(
                  json["providers"].map((e) => LogisticProvider.fromJson(e)))
              : []);

  Map<String, dynamic> toJson() => {
        "_id": id.toString(),
        "providers": List<dynamic>.from(providers!.map((e) => e))
      };
}
