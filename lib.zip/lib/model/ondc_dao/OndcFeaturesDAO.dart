class OndcFeaturesDAO {
  String? key;
  dynamic value;

  OndcFeaturesDAO({this.key, this.value});

  factory OndcFeaturesDAO.fromJson(Map<String, dynamic> json) =>
      OndcFeaturesDAO(
          key: json.containsKey("code") && json["code"] != null
              ? json["code"]
              : "",
          value: json.containsKey("value") && json["value"] != null
              ? json["value"]
              : null);

  Map<String, dynamic> toJson() => {"code": key, "value": value};
}
