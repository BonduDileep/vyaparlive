import 'package:vyaparlive/model/ondc_dao/Categories.dart';
import 'package:vyaparlive/model/ondc_dao/Descriptor.dart';

class OndcOrderedProducts {
  String? id;
  String? parentItemId;
  String? categoryId;
  String? fulfillmentId;
  Descriptor? descriptor;
  CategorieTime? categorieTime;
  PriceDao? price;

  OndcOrderedProducts(
      {this.categorieTime,
      this.categoryId,
      this.descriptor,
      this.fulfillmentId,
      this.id,
      this.parentItemId,
      this.price});

  factory OndcOrderedProducts.fromJson(Map<String, dynamic> json) =>
      OndcOrderedProducts(
          id: json.containsKey("id") && json['id'] != null ? json['id'] : "",
          parentItemId: json.containsKey("parent_item_id") &&
                  json['parent_item_id'] != null
              ? json['parent_item_id']
              : "",
          categoryId:
              json.containsKey("category_id") && json['category_id'] != null
                  ? json['category_id']
                  : "",
          fulfillmentId: json.containsKey("fulfillment_id") &&
                  json['fulfillment_id'] != null
              ? json['fulfillment_id']
              : "",
          descriptor:
              json.containsKey("descriptor") && json["descriptor"] != null
                  ? Descriptor.fromJson(json["descriptor"])
                  : null,
          categorieTime: json.containsKey("time") && json['time'] != null
              ? CategorieTime.fromJson(json['time'])
              : null,
          price: json.containsKey("price") && json['price'] != null
              ? PriceDao.fromJson(json['price'])
              : null);
}

class PriceDao {
  String? currency;
  String? value;

  PriceDao({this.currency, this.value});

  factory PriceDao.fromJson(Map<String, dynamic> json) => PriceDao(
      currency: json.containsKey("currency") && json['currency'] != null
          ? json['currency']
          : "",
      value: json.containsKey("value") && json['value'] != null
          ? json['value']
          : "0");

  Map<String, dynamic> toJson() =>
      {"value": value.toString(), "currency": currency.toString()};
}
