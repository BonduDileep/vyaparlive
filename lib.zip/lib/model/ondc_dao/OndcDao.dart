import 'IgmDao.dart';

class OndcDao {
  String? buyerApp;
  String? transactionId;
  bool? hasIgm;
  IgmDao? igmDao;
  ONDCOrder? ondcOrder;
  OndcDao(
      {this.buyerApp,
      this.transactionId,
      this.hasIgm,
      this.igmDao,
      this.ondcOrder});

  factory OndcDao.from(Map<String, dynamic> json) => OndcDao(
        buyerApp: json.containsKey("buyer_app") && json['buyer_app'] != null
            ? json["buyer_app"]
            : "",
        transactionId:
            json.containsKey("transaction_id") && json["transaction_id"] != null
                ? json['transaction_id']
                : "",
        hasIgm: json.containsKey("has_igm") && json['has_igm'] != null
            ? json["has_igm"]
            : false,
        igmDao:
            json.containsKey("igm") && json['igm'] != null ? IgmDao.from(json["igm"]) : null,
        ondcOrder: json.containsKey("order") && json['order'] != null
            ? ONDCOrder.from(json["order"])
            : null,
      );

  Map<String, dynamic> toJson() => {
        "buyer_app": buyerApp.toString(),
        "transaction_id": transactionId,
        "order": ondcOrder,
        "igm": igmDao,
        "has_igm": hasIgm
      };
}

class ONDCOrder {
  String? id;
  ONDCOrder({this.id});

  factory ONDCOrder.from(Map<String, dynamic> json) => ONDCOrder(
      id: json.containsKey("id") && json['id'] != null ? json["id"] : "");

  Map<String, dynamic> toJson() => {"id": id};
}
