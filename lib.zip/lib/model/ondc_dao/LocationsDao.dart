class LocationDao {
  String? id;
  String? gps;
  LocationAddressDao? addressDao;
  LocationDao({this.addressDao, this.gps, this.id});

  factory LocationDao.fromJson(Map<String, dynamic> json) => LocationDao(
      id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
      gps: json.containsKey("gps") && json["gps"] != null ? json["gps"] : "",
      addressDao: json.containsKey("address") && json["address"] != null
          ? LocationAddressDao.fromJson(json["address"])
          : null);

  Map<String, dynamic> toJson() => {
        "id": id.toString(),
        "gps": gps.toString(),
        "address": addressDao!.toJson()
      };
}

class LocationAddressDao {
  String? street;
  String? locality;
  String? city;
  String? state;
  String? areaCode;

  LocationAddressDao(
      {this.areaCode, this.city, this.locality, this.state, this.street});

  factory LocationAddressDao.fromJson(Map<String, dynamic> json) =>
      LocationAddressDao(
          state: json.containsKey("state") && json["state"] != null
              ? json["state"]
              : "",
          locality: json.containsKey("locality") && json["locality"] != null
              ? json["locality"]
              : "",
          areaCode: json.containsKey("area_code") && json["area_code"] != null
              ? json["area_code"]
              : "",
          city: json.containsKey("city") && json["city"] != null
              ? json["city"]
              : "",
          street: json.containsKey("street") && json["street"] != null
              ? json["street"]
              : "");

  Map<String, dynamic> toJson() => {
        "area_code": areaCode.toString(),
        "street": street.toString(),
        "city": city.toString(),
        "locality": locality.toString(),
        "state": state.toString()
      };
}
