class IgmDao {
  String? id;
  MessageWrapper? message;
  String? createdDt;
  Processing? processing;
  List<OnIssue>? onIssue;
  List<AdditionalReqs>? additionalReqs;

  IgmDao({
    this.id,
    this.message,
    this.createdDt,
    this.processing,
    this.onIssue,
    this.additionalReqs
  });

  factory IgmDao.from(Map<String, dynamic> json) => IgmDao(
        id: json.containsKey("_id") && json["_id"]!=null ? json["_id"]:"",
        message: json.containsKey("message") && json["message"] != null
            ? MessageWrapper.from(json["message"])
            : null,
        createdDt: json.containsKey("created_dt") && json["created_dt"]!=null ? json["created_dt"]:"",
        processing: json.containsKey("processing") && json["processing"] != null
            ? Processing.from(json["processing"])
            : null,
        onIssue: json.containsKey("on_issue") && json["on_issue"] != null
            ? List<OnIssue>.from(json["on_issue"].map((x) => OnIssue.from(x)))
            : null,
        additionalReqs: json.containsKey("additional_reqs") && json["additional_reqs"] != null
            ? List<AdditionalReqs>.from(json["additional_reqs"].map((x) => AdditionalReqs.from(x)))
            : null,
      );
}

class MessageWrapper {
  Issue? issue;
  List<UpdateTarget>? updateTarget;

  MessageWrapper({this.issue, this.updateTarget});

  factory MessageWrapper.from(Map<String, dynamic> json) => MessageWrapper(
        issue: json.containsKey("issue") && json["issue"] != null ? Issue.from(json["issue"]) : null,
        updateTarget: json.containsKey("update_target") && json["update_target"] != null
            ? List<UpdateTarget>.from(
                json["update_target"].map((x) => UpdateTarget.from(x)))
            : [],
      );
}

class Issue {
  String? id;
  String? category;
  String? subCategory;
  ComplainantInfo? complainantInfo;
  OrderDetails? orderDetails;
  Description? description;
  Source? source;
  DurationWrapper? expectedResponseTime;
  DurationWrapper? expectedResolutionTime;
  String? status;
  String? issueType;
  IssueActions? issueActions;
  String? createdAt;
  String? updatedAt;
  String? level;
  List<String>? respondentIds;
  List<ActionItem>? actions;
  String? lastActionId;

  Issue({
    this.id,
    this.category,
    this.subCategory,
    this.complainantInfo,
    this.orderDetails,
    this.description,
    this.source,
    this.expectedResponseTime,
    this.expectedResolutionTime,
    this.status,
    this.issueType,
    this.issueActions,
    this.createdAt,
    this.updatedAt,
    this.level,
    this.respondentIds,
    this.actions,
    this.lastActionId,
  });

  factory Issue.from(Map<String, dynamic> json) => Issue(
        id: json.containsKey("id") && json["id"]!=null ?  json["id"] : "",
        category: json.containsKey("category") && json["category"] != null
            ? json["category"]
            : "",
        subCategory:
            json.containsKey("sub_category") && json["sub_category"] != null
                ? json["sub_category"]
                : "",
        complainantInfo: json.containsKey("complainant_info") &&
                json["complainant_info"] != null
            ? ComplainantInfo.from(json["complainant_info"])
            : null,
        orderDetails:
            json.containsKey("order_details") && json["order_details"] != null
                ? OrderDetails.from(json["order_details"])
                : null,
        description:
            json.containsKey("descriptor") && json["descriptor"] != null
                ? Description.from(json["descriptor"])
                : null,
        source: json.containsKey("source") && json["source"] != null
            ? Source.from(json["source"])
            : null,
        expectedResponseTime: json.containsKey("expected_response_time") &&
                json["expected_response_time"] != null
            ? DurationWrapper.from(json["expected_response_time"])
            : null,
        expectedResolutionTime: json.containsKey("expected_resolution_time") &&
                json["expected_resolution_time"] != null
            ? DurationWrapper.from(json["expected_resolution_time"])
            : null,
        status: json.containsKey("status") && json["status"] != null
            ? json["status"]
            : "",
        issueType: json.containsKey("issue_type") && json["issue_type"] != null
            ? json["issue_type"]
            : "",
        issueActions: json.containsKey("issue_actions") && json["issue_actions"] != null
            ? IssueActions.from(json["issue_actions"])
            : null,
        createdAt: json.containsKey("created_at") && json["created_at"]!=null ? json["created_at"]:"",
        updatedAt: json.containsKey("updated_at") && json["updated_at"] != null ? json["updated_at"]:"",
        level: json.containsKey("level") && json["level"]!=null ? json["level"]:"",
        lastActionId: json.containsKey("last_action_id") &&  json["last_action_id"]!=null ? json["last_action_id"]:"",
        respondentIds: json.containsKey("respondent_ids") && json["respondent_ids"] != null
            ? List<String>.from(json["respondent_ids"])
            : null,
        actions: json.containsKey("actions") && json["actions"] != null
            ? List<ActionItem>.from(
                json["actions"].map((x) => ActionItem.from(x)))
            : null,
      );
}

class ComplainantInfo {
  Contact? contact;
  Person? person;

  ComplainantInfo({this.contact, this.person});

  factory ComplainantInfo.from(Map<String, dynamic> json) => ComplainantInfo(
        contact: json.containsKey("contact") && json["contact"] != null ? Contact.from(json["contact"]) : null,
        person:  json.containsKey("person") && json["person"] != null ? Person.from(json["person"]) : null,
      );
}

class Contact {
  String? email;
  String? phone;

  Contact({this.email, this.phone});

  factory Contact.from(Map<String, dynamic> json) => Contact(
        email: json.containsKey("email") && json["email"]!=null? json["email"]:"",
        phone: json.containsKey("phone") &&  json["phone"]!=null ? json["phone"]:"",
      );
}

class Person {
  String? name;

  Person({this.name});

  factory Person.from(Map<String, dynamic> json) => Person(
        name: json.containsKey("name") && json["name"]!=null? json["name"]:"",
      );
}

class OrderDetails {
  String? id;
  String? state;
  String? providerId;
  List<Fulfillment>? fulfillments;
  List<Item>? items;

  OrderDetails(
      {this.id, this.state, this.providerId, this.fulfillments, this.items});

  factory OrderDetails.from(Map<String, dynamic> json) => OrderDetails(
        id: json.containsKey("id") && json["id"]!=null ?  json["id"] : "",
        state: json.containsKey("id") && json["state"]!=null ? json["state"]:"",
        providerId: json.containsKey("provider_id") && json["provider_id"]!=null ? json["provider_id"]:"",
        fulfillments: json.containsKey("fulfillments") && json["fulfillments"] != null
            ? List<Fulfillment>.from(
                json["fulfillments"].map((x) => Fulfillment.from(x)))
            : null,
        items: json.containsKey("items") && json["items"] != null
            ? List<Item>.from(json["items"].map((x) => Item.from(x)))
            : null,
      );
}

class Fulfillment {
  String? id;
  String? state;

  Fulfillment({this.id, this.state});

  factory Fulfillment.from(Map<String, dynamic> json) => Fulfillment(
        id: json["id"],
        state: json["state"],
      );
}

class Item {
  String? id;
  int? quantity;

  Item({this.id, this.quantity});

  factory Item.from(Map<String, dynamic> json) => Item(
        id: json["id"],
        quantity: json["quantity"],
      );
}

class Description {
  String? shortDesc;
  String? longDesc;
  AdditionalDesc? additionalDesc;
  List<Images>? images;

  Description(
      {this.shortDesc, this.longDesc, this.additionalDesc, this.images});

  factory Description.from(Map<String, dynamic> json) => Description(
        shortDesc: json.containsKey("short_desc") && json["short_desc"]!=null ?  json["short_desc"] : "",
        longDesc: json.containsKey("long_desc") && json["long_desc"]!=null ? json["long_desc"]:"",
        additionalDesc: json.containsKey("additional_desc") && json["additional_desc"] != null
            ? AdditionalDesc.from(json["additional_desc"])
            : null,
        images:
            json.containsKey("images") && json["images"] != null ? List<Images>.from(json["images"].map((x) => Images.from(x))) : null,
      );
}

class Images {
  String? url;
  String? sizeType;

  Images(
      {this.url, this.sizeType});

  factory Images.from(Map<String, dynamic> json) => Images(
        url: json.containsKey("url") && json["url"]!=null ?  json["url"] : "",
        sizeType: json.containsKey("size_type") && json["size_type"]!=null ? json["size_type"]:"");
}

class AdditionalDesc {
  String? url;
  String? contentType;

  AdditionalDesc({this.url, this.contentType});

  factory AdditionalDesc.from(Map<String, dynamic> json) => AdditionalDesc(
        url: json["url"],
        contentType: json["content_type"],
      );
}

class Source {
  String? networkParticipantId;
  String? type;

  Source({this.networkParticipantId, this.type});

  factory Source.from(Map<String, dynamic> json) => Source(
        networkParticipantId: json["network_participant_id"],
        type: json["type"],
      );
}

class DurationWrapper {
  String? duration;

  DurationWrapper({this.duration});

  factory DurationWrapper.from(Map<String, dynamic> json) => DurationWrapper(
        duration: json["duration"],
      );
}

class IssueActions {
  List<ComplainantAction>? complainantActions;

  IssueActions({this.complainantActions});

  factory IssueActions.from(Map<String, dynamic> json) => IssueActions(
        complainantActions: json["complainant_actions"] != null
            ? List<ComplainantAction>.from(json["complainant_actions"]
                .map((x) => ComplainantAction.from(x)))
            : null,
      );
}

class ComplainantAction {
  String? complainantAction;
  String? shortDesc;
  String? updatedAt;
  UpdatedBy? updatedBy;

  ComplainantAction({
    this.complainantAction,
    this.shortDesc,
    this.updatedAt,
    this.updatedBy,
  });

  factory ComplainantAction.from(Map<String, dynamic> json) =>
      ComplainantAction(
        complainantAction: json["complainant_action"],
        shortDesc: json["short_desc"],
        updatedAt: json["updated_at"],
        updatedBy: json["updated_by"] != null
            ? UpdatedBy.from(json["updated_by"])
            : null,
      );
}

class UpdatedBy {
  Org? org;
  Contact? contact;
  Person? person;

  UpdatedBy({this.org, this.contact, this.person});

  factory UpdatedBy.from(Map<String, dynamic> json) => UpdatedBy(
        org: json["org"] != null ? Org.from(json["org"]) : null,
        contact: json["contact"] != null ? Contact.from(json["contact"]) : null,
        person: json["person"] != null ? Person.from(json["person"]) : null,
      );
}

class Org {
  String? name;

  Org({this.name});

  factory Org.from(Map<String, dynamic> json) => Org(name: json["name"]);
}

class Processing {
  Context? context;
  MessageWrapper? message;

  Processing({this.context, this.message});

  factory Processing.from(Map<String, dynamic> json) => Processing(
        context: json["context"] != null ? Context.from(json["context"]) : null,
        message: json["message"] != null
            ? MessageWrapper.from(json["message"])
            : null,
      );
}

class Context {
  String? domain;
  String? city;
  String? country;
  String? coreVersion;
  String? action;
  String? bapUri;
  String? bapId;
  String? bppUri;
  String? bppId;
  String? transactionId;
  String? ttl;
  String? messageId;
  String? timestamp;

  Context({
    this.domain,
    this.city,
    this.country,
    this.coreVersion,
    this.action,
    this.bapUri,
    this.bapId,
    this.bppUri,
    this.bppId,
    this.transactionId,
    this.ttl,
    this.messageId,
    this.timestamp,
  });

  factory Context.from(Map<String, dynamic> json) => Context(
        domain: json.containsKey("domain") && json["domain"]!=null? json["domain"]:"",
        city: json.containsKey("city") && json["city"]!=null?json["city"]:"",
        country: json.containsKey("country") && json["country"]!=null?json["country"]:"",
        coreVersion: json.containsKey("core_version") && json["core_version"]!=null?json["core_version"]:"",
        action: json.containsKey("action") && json["action"]!=null?json["action"]:"",
        bapUri: json.containsKey("bap_uri") && json["bap_uri"]!=null?json["bap_uri"]:"",
        bapId: json.containsKey("bap_id") && json["bap_id"]!=null?json["bap_id"]:"",
        bppUri: json.containsKey("bpp_uri") && json["bpp_uri"]!=null?json["bpp_uri"]:"",
        bppId: json.containsKey("bpp_id") && json["bpp_id"]!=null?json["bpp_id"]:"",
        transactionId: json.containsKey("transaction_id") && json["transaction_id"]!=null?json["transaction_id"]:"",
        ttl: json.containsKey("ttl") && json["ttl"]!=null?json["ttl"]:"",
        messageId: json.containsKey("message_id") && json["message_id"]!=null?json["message_id"]:"",
        timestamp: json.containsKey("timestamp") && json["timestamp"]!=null?json["timestamp"]:"",
      );
}

class OnIssue {
  Context? context;
  MessageWrapper? message;

  OnIssue({this.context, this.message});

  factory OnIssue.from(Map<String, dynamic> json) => OnIssue(
        context: json["context"] != null ? Context.from(json["context"]) : null,
        message: json["message"] != null
            ? MessageWrapper.from(json["message"])
            : null,
      );
}

class AdditionalReqs {
  String? additionalReqId;
  Context? context;
  MessageWrapper? message;

  AdditionalReqs({this.additionalReqId,this.context, this.message});

  factory AdditionalReqs.from(Map<String, dynamic> json) => AdditionalReqs(
        additionalReqId:json.containsKey("id") && json["id"] != null ? json["id"]:"",
        context: json.containsKey("context") && json["context"] != null ? Context.from(json["context"]) : null,
        message: json.containsKey("message") && json["message"] != null
            ? MessageWrapper.from(json["message"])
            : null,
      );
}

class ActionItem {
  String? id;
  Descriptor? descriptor;
  String? updatedAt;
  String? actionBy;
  ActorDetails? actorDetails;

  ActionItem(
      {this.id,
      this.descriptor,
      this.updatedAt,
      this.actionBy,
      this.actorDetails});

  factory ActionItem.from(Map<String, dynamic> json) => ActionItem(
        id: json["id"],
        descriptor: json["descriptor"] != null
            ? Descriptor.from(json["descriptor"])
            : null,
        updatedAt: json["updated_at"],
        actionBy: json["action_by"],
        actorDetails: json["actor_details"] != null
            ? ActorDetails.from(json["actor_details"])
            : null,
      );
}

class Descriptor {
  String? code;
  String? shortDesc;

  Descriptor({this.code, this.shortDesc});

  factory Descriptor.from(Map<String, dynamic> json) => Descriptor(
        code: json["code"],
        shortDesc: json["short_desc"],
      );
}

class ActorDetails {
  String? name;

  ActorDetails({this.name});

  factory ActorDetails.from(Map<String, dynamic> json) =>
      ActorDetails(name: json["name"]);
}

class UpdateTarget {
  String? path;
  String? action;

  UpdateTarget({this.path, this.action});

  factory UpdateTarget.from(Map<String, dynamic> json) => UpdateTarget(
        path: json.containsKey("path") && json["path"]!=null?json["path"]:"",
        action: json.containsKey("action") && json["action"]!=null?json["action"]:"",
      );

  Map<String, dynamic> toJson() => {
        "path": path,
        "action": action,
      };
}
