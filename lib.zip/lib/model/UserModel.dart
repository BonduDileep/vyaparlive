// To parse this JSON data, do
//
//     final userModel = userModelFromJson(jsonString);

import 'dart:convert';
import 'package:vyaparlive/model/PrivilegesDAO.dart';

UserModel userModelFromJson(String str) => UserModel.fromJson(json.decode(str));

String userModelToJson(UserModel data) => json.encode(data.toJson());

class UserModel {
  UserModel(
      {this.name,
      this.contact,
      this.password,
      this.invitationId,
      this.status,
      this.firstName,
      this.middleName,
      this.lastName,
      this.designation,
      this.personalAddress,
      this.workLocation,
      this.hiredAt,
      this.birthday,
      this.homePhone,
      this.personalEmailId,
      this.personalPhoneNo,
      this.alternativeContactNo,
      this.extensions,
      this.reportsTo,
      this.documents,
      this.businessUnits,
      this.metadataAttachments,
      this.id,
      this.firebaseTocken,
      this.dialerCode});

  String? name;
  String? contact;
  String? password;
  String? invitationId;
  num? status;
  String? firstName;
  String? middleName;
  String? lastName;
  String? designation;
  PersonalAddress? personalAddress;
  WorkLocation? workLocation;
  DateTime? hiredAt;
  DateTime? birthday;
  String? homePhone;
  String? personalEmailId;
  String? personalPhoneNo;
  String? alternativeContactNo;
  String? extensions;
  String? reportsTo;
  List<dynamic>? documents;
  List<BusinessUnit>? businessUnits;
  dynamic metadataAttachments;
  String? id;
  String? firebaseTocken;
  String? dialerCode;

  factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
      name:
          json.containsKey("name") && json["name"] != null ? json["name"] : "",
      contact: json.containsKey("contact") && json["contact"] != null
          ? json["contact"]
          : "",
      password: json.containsKey("password") && json["password"] != null
          ? json["password"]
          : "",
      invitationId:
          json.containsKey("invitation_id") && json["invitation_id"] != null
              ? json["invitation_id"]
              : "",
      status: json.containsKey("status") && json["status"] != null
          ? json["status"]
          : 0,
      firstName: json.containsKey("first_name") && json["first_name"] != null
          ? json["first_name"]
          : "",
      middleName: json.containsKey("middle_name") && json["middle_name"] != null
          ? json["middle_name"]
          : "",
      lastName: json.containsKey("last_name") && json["last_name"] != null
          ? json["last_name"]
          : "",
      designation: json.containsKey("designation") && json["designation"] != null
          ? json["designation"]
          : "",
      personalAddress:
          json.containsKey("personal_address") && json["personal_address"] != null
              ? PersonalAddress.fromJson(json["personal_address"])
              : null,
      workLocation:
          json.containsKey("work_location") && json["work_location"] != null
              ? WorkLocation.fromJson(json["work_location"])
              : null,
      hiredAt: json.containsKey("hired_at") && json["hired_at"] != null
          ? DateTime.tryParse(json["hired_at"])
          : null,
      birthday: json.containsKey("birthday") && json["birthday"] != null
          ? DateTime.tryParse(json["birthday"])
          : null,
      homePhone: json.containsKey("home_phone") && json["home_phone"] != null ? json["home_phone"] : "",
      personalEmailId: json.containsKey("personal_email_id") && json["personal_email_id"] != null ? json["personal_email_id"] : "",
      personalPhoneNo: json.containsKey("personal_phone_no") && json["personal_phone_no"] != null ? json["personal_phone_no"] : "",
      alternativeContactNo: json.containsKey("alternative_contact_no") && json["alternative_contact_no"] != null ? json["alternative_contact_no"] : "",
      extensions: json.containsKey("extension") && json["extension"] != null ? json["extension"] : "",
      reportsTo: json.containsKey("reports_to") && json["reports_to"] != null ? json["reports_to"] : "",
      documents: json.containsKey("documents") && json["documents"] != null ? List<dynamic>.from(json["documents"].map((x) => x)) : [],
      businessUnits: json.containsKey("business_units") && json["business_units"] != null ? List<BusinessUnit>.from(json["business_units"].map((x) => BusinessUnit.fromJson(x))) : [],
      metadataAttachments: json.containsKey("@metadata.@attachments") && json["@metadata.@attachments"] != null ? json["@metadata.@attachments"] : "",
      id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
      firebaseTocken: json.containsKey("firebase_token") && json["firebase_token"] != null ? json["firebase_token"] : "",
      dialerCode: json.containsKey("dial_code") && json["dial_code"] != null ? json["dial_code"] : "");

  Map<String, dynamic> toJson() => {
        "name": name,
        "contact": contact,
        "password": password,
        "invitation_id": invitationId,
        "status": status,
        "first_name": firstName,
        "middle_name": middleName,
        "last_name": lastName,
        "designation": designation,
        "personal_address": personalAddress!.toJson(),
        "work_location": workLocation!.toJson(),
        "hired_at": hiredAt!.toIso8601String(),
        "birthday": birthday!.toIso8601String(),
        "home_phone": homePhone,
        "personal_email_id": personalEmailId,
        "personal_phone_no": personalPhoneNo,
        "alternative_contact_no": alternativeContactNo,
        "extension": extensions,
        "reports_to": reportsTo,
        "documents": List<dynamic>.from(documents!.map((x) => x)),
        "business_units":
            List<dynamic>.from(businessUnits!.map((x) => x.toJson())),
        "@metadata.@attachments": metadataAttachments,
        "id": id,
        "firebase_token": firebaseTocken,
        "dial_code": dialerCode
      };
}

class BusinessUnit {
  BusinessUnit({
    this.businessId,
    this.businessName,
    this.departmentName,
    this.bussinessMailId,
    this.role,
  });

  String? businessId;
  String? businessName;
  String? departmentName;
  String? bussinessMailId;
  List<String>? role; //List<RolesDAO>? role;

  factory BusinessUnit.fromJson(Map<String, dynamic> json) => BusinessUnit(
        businessId:
            json.containsKey("business_id") && json["business_id"] != null
                ? json["business_id"]
                : "",
        businessName:
            json.containsKey("business_name") && json["business_name"] != null
                ? json["business_name"]
                : "",
        departmentName: json.containsKey("department_name") &&
                json["department_name"] != null
            ? json["department_name"]
            : "",
        bussinessMailId: json.containsKey("bussiness_mail_id") &&
                json["bussiness_mail_id"] != null
            ? json["bussiness_mail_id"]
            : "",
        role: json.containsKey("roles") && json["roles"] != null
            ? (json["roles"] is List
                ? (json["roles"].isNotEmpty &&
                        json["roles"].every((e) => e is String))
                    ? List<String>.from(json[
                        "roles"]) 
                    : []
                : [])

            // ? List<String>.from(json["roles"].map((x) => x))
            : [],
      );

  Map<String, dynamic> toJson() => {
        "business_id": businessId,
        "business_name": businessName,
        "department_name": departmentName,
        "bussiness_mail_id": bussinessMailId,
        "roles": List<dynamic>.from(role!.map((x) => x)),
      };
}

class Role {
  Role({
    this.roleId,
    this.roleName,
    this.roleCode,
    this.permissions,
  });

  String? roleId;
  String? roleName;
  String? roleCode;
  List<PrivilegesDAO>? permissions;

  factory Role.fromJson(Map<String, dynamic> json) => Role(
        roleId: json.containsKey("role_id") && json["role_id"] != null
            ? json["role_id"]
            : "",
        roleName: json.containsKey("name") && json["name"] != null
            ? json["name"]
            : "",
        roleCode: json.containsKey("code") && json["code"] != null
            ? json["code"]
            : "",
        permissions:
            json.containsKey("permissions") && json["permissions"] != null
                ? List<PrivilegesDAO>.from(
                    json["permissions"].map((x) => PrivilegesDAO.fromJson(x)))
                : [],
      );

  Map<String, dynamic> toJson() => {
        "role_id": roleId,
        "permissions": List<dynamic>.from(permissions!.map((x) => x.toJson())),
      };
}

class Permissions {
  String? id;
  String? name;
  String? code;
  String? description;
  Permissions({this.id, this.name, this.code, this.description});

  factory Permissions.fromJson(Map<String, dynamic> json) => Permissions(
      id: json.containsKey("") && json["id"] != null ? json["id"] : "",
      name:
          json.containsKey("name") && json["name"] != null ? json["name"] : "",
      code:
          json.containsKey("code") && json["code"] != null ? json["code"] : "",
      description:
          json.containsKey("description") && json["description"] != null
              ? json["description"]
              : ",");

  Map<String, dynamic> toJson() =>
      {"id": id, "code": code, "name": name, "description": description};
}

class PersonalAddress {
  PersonalAddress(
      {this.addressType,
      this.businessLocationNumber,
      this.buildingHouseNumber,
      this.buildingStreetName,
      this.colonySectorAreaLocality,
      this.villageTownCity,
      this.taluk,
      this.landmark,
      this.state,
      this.district,
      this.postCode,
      this.country,
      this.location,
      this.phone,
      this.fax,
      this.plotNo,
      this.buildingNo,
      this.officeCountryCode});

  String? addressType;
  String? businessLocationNumber;
  String? buildingHouseNumber;
  String? buildingNo;
  String? buildingStreetName;
  String? colonySectorAreaLocality;
  String? villageTownCity;
  String? taluk;
  String? landmark;
  String? state;
  String? district;
  String? postCode;
  String? country;
  Location? location;
  String? phone;
  String? fax;
  String? plotNo;
  String? officeCountryCode;

  factory PersonalAddress.fromJson(Map<String, dynamic> json) => PersonalAddress(
      addressType: json.containsKey("address_type") && json["address_type"] != null
          ? json["address_type"]
          : "",
      businessLocationNumber: json.containsKey("business_location_number") &&
              json["business_location_number"] != null
          ? json["business_location_number"]
          : "",
      buildingHouseNumber:
          json.containsKey("building_house_number") && json["building_house_number"] != null
              ? json["building_house_number"]
              : "",
      buildingNo: json.containsKey("buliding_no") && json["buliding_no"] != null
          ? json["buliding_no"]
          : "",
      plotNo: json.containsKey("plot_no") && json["plot_no"] != null
          ? json["plot_no"]
          : "",
      buildingStreetName: json.containsKey("building_street_name") && json["building_street_name"] != null
          ? json["building_street_name"]
          : "",
      colonySectorAreaLocality: json.containsKey("colony_sector_area_locality") &&
              json["colony_sector_area_locality"] != null
          ? json["colony_sector_area_locality"]
          : "",
      villageTownCity: json.containsKey("village_town_city") && json["village_town_city"] != null ? json["village_town_city"] : "",
      taluk: json.containsKey("taluk") && json["taluk"] != null ? json["taluk"] : "",
      landmark: (json.containsKey("landmark") && json["landmark"] != null) ? json["landmark"] : "",
      state: json.containsKey("state") && json["state"] != null ? json["state"] : "",
      district: json.containsKey("district") && json["district"] != null ? json["district"] : "",
      postCode: json.containsKey("post_code") && json["post_code"] != null ? json["post_code"] : "",
      country: json.containsKey("country") && json["country"] != null ? json["country"] : "",
      location: json.containsKey("location") && json["location"] != null ? Location.fromJson(json["location"]) : null,
      phone: json.containsKey("phone") && json["phone"] != null ? json["phone"] : "",
      fax: json.containsKey("fax") && json["fax"] != null ? json["fax"] : "",
      officeCountryCode: json.containsKey("office_country_code") && json["office_country_code"] != null ? json["office_country_code"] : "");

  Map<String, dynamic> toJson() => {
        "address_type": addressType,
        "business_location_number": businessLocationNumber,
        "building_house_number": buildingHouseNumber,
        "buliding_no": buildingNo,
        "building_street_name": buildingStreetName,
        "colony_sector_area_locality": colonySectorAreaLocality,
        "village_town_city": villageTownCity,
        "taluk": taluk,
        "landmark": landmark,
        "state": state,
        "district": district,
        "post_code": postCode,
        "country": country,
        "location": location!.toJson(),
        "phone": phone,
        "fax": fax,
        "plot_no": plotNo,
        "office_country_code": officeCountryCode
      };
}

class Location {
  Location({
    this.latitude,
    this.longitude,
  });

  String? latitude;
  String? longitude;

  factory Location.fromJson(Map<String, dynamic> json) => Location(
        latitude: json.containsKey("latitude") && json["latitude"] != null
            ? json["latitude"]
            : "",
        longitude: json.containsKey("longitude") && json["longitude"] != null
            ? json["longitude"]
            : "",
      );

  Map<String, dynamic> toJson() => {
        "latitude": latitude,
        "longitude": longitude,
      };
}

class WorkLocation {
  WorkLocation({
    this.locationName,
  });

  String? locationName;

  factory WorkLocation.fromJson(Map<String, dynamic> json) => WorkLocation(
        locationName:
            json.containsKey("location_name") && json["location_name"] != null
                ? json["location_name"]
                : "",
      );

  Map<String, dynamic> toJson() => {
        "location_name": locationName,
      };
}
