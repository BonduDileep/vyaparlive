import 'package:vyaparlive/model/product_model/InventoryDetailsDAO.dart';

class InventoryManagementModel {
  String? locationName;
  num? quantity;
  String? batchNumber;
  String? quantityIn;
  List<InventoryDetailsDAO>? locationBatchList;
  String? locationId;
  String? updatedby;
  String? updatedDate;
  InventoryManagementModel(
      {this.locationName,
      this.quantity,
      this.batchNumber,
      this.quantityIn,
      this.locationBatchList,
      this.locationId,
      this.updatedby,
      this.updatedDate});
}
