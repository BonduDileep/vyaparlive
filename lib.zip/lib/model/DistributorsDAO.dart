class DistributorsDAO {
  String? buName;
  String? buId;
  String? shortName;

  DistributorsDAO({this.buId, this.buName, this.shortName});

  factory DistributorsDAO.fromJson(Map<String, dynamic> json) =>
      DistributorsDAO(
          buId:
              json.containsKey("_id") && json["_id"] != null ? json["_id"] : "",
          buName:
              json.containsKey("business_name") && json["business_name"] != null
                  ? json["business_name"]
                  : "",
          shortName:
              json.containsKey("short_name") && json["short_name"] != null
                  ? json["short_name"]
                  : "");

  Map<String, dynamic> toJson() =>
      {"_id": buId, "business_name": buName, "short_name": shortName};

  @override
  String toString() {
    return "$buName".toLowerCase() + "$buName".toUpperCase();
  }
}
