import 'package:vyaparlive/model/ProductSubCategoryDAO.dart';

class ProductCategoryDAO implements Comparable<ProductCategoryDAO> {
  String? id;
  String? type;
  int? code;
  int? parentCode;
  String? name;
  String? strCode;
  List<ProductSubCategoryDAO>? subCategoryList;

  ProductCategoryDAO(
      {this.id,
      this.type,
      this.code,
      this.parentCode,
      this.subCategoryList,
      this.name,
      this.strCode});

  factory ProductCategoryDAO.fromJson(Map<String, dynamic> json) =>
      ProductCategoryDAO(
          id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
          type: json.containsKey("product_category") &&
                  json["product_category"] != null
              ? json["product_category"]
              : "",
          code: json.containsKey("UNSPSC_code") && json["UNSPSC_code"] != null
              ? json["UNSPSC_code"]
              : 0,
          parentCode: json.containsKey("parent_UNSPSC_code") &&
                  json["parent_UNSPSC_code"] != null
              ? json["parent_UNSPSC_code"]
              : 0,
          subCategoryList: json.containsKey("sub_categories") &&
                  json["sub_categories"] != null
              ? List<ProductSubCategoryDAO>.from(json["sub_categories"]
                  .map((x) => ProductSubCategoryDAO.fromJson(x)))
              : [],
          name: json.containsKey("name") && json["name"] != null
              ? json["name"]
              : "",
          strCode: json.containsKey("code") && json["code"] != null
              ? json["code"]
              : "");

  Map<String, dynamic> toJson() => {
        "id": id,
        "product_category": type,
        "UNSPSC_code": code,
        "parent_UNSPSC_code": parentCode,
        "sub_categories":
            List<dynamic>.from(subCategoryList!.map((e) => e.toJson())),
        "name": name,
        "code": strCode
      };

  /// Using for search by type in CategorySearchPage.dart and EditMyProduct.dart
  @override
  String toString() {
    return '$type'.toLowerCase() + '$type'.toUpperCase();
  }

  @override
  int compareTo(ProductCategoryDAO other) {
    // Compare based on the 'name' field
    return name!.compareTo(other.name!);
  }
}
