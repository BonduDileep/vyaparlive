class RolePermissions {
  String? objectName;
  String? objectWrite;
  String? objectRead;

  RolePermissions({this.objectName, this.objectRead, this.objectWrite});
}
