import 'package:vyaparlive/model/ProductConsumptionDAO.dart';

class ConsumableProductReportsDAO {
  String? id;
  String? productName;
  List<IssueDetails>? issuedDetails;

  ConsumableProductReportsDAO({this.id, this.issuedDetails, this.productName});

  factory ConsumableProductReportsDAO.fromJson(Map<String, dynamic> json) =>
      ConsumableProductReportsDAO(
          id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
          productName: json.containsKey("name") && json["name"] != null
              ? json["name"]
              : "",
          issuedDetails: json.containsKey("issues") && json["issues"] != null
              ? List<IssueDetails>.from(
                  json["issues"].map((e) => IssueDetails.fromJson(e)))
              : []);

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": productName,
        "issues": List<dynamic>.from(issuedDetails!.map((e) => e.toJson()))
      };
}
