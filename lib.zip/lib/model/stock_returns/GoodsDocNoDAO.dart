class GoodsDocNoDAO {
  String? buyerName;
  String? sellerName;
  String? docId;
  num? docNumber;

  GoodsDocNoDAO({
    this.buyerName,
    this.docId,
    this.docNumber,
    this.sellerName,
  });

  factory GoodsDocNoDAO.fromJson(Map<String, dynamic> json) => GoodsDocNoDAO(
        buyerName: json.containsKey("buyer_name") && json["buyer_name"] != null
            ? json["buyer_name"]
            : "",
        sellerName:
            json.containsKey("seller_name") && json["seller_name"] != null
                ? json["seller_name"]
                : "",
        docId: json.containsKey("id") && json["id"] != null ? json["id"] : "",
        docNumber: json.containsKey("doc_number") && json["doc_number"] != null
            ? json["doc_number"]
            : 0,
      );

  Map<String, dynamic> toJson() => {
        "doc_number": docNumber,
        "id": docId,
        "buyer_name": buyerName,
        "seller_name": sellerName,
      };
}
