import 'package:flutter/cupertino.dart';

class StockGoodsProducts {
  String? id;
  String? productName;
  List<Batches>? batchesList;
  String? uId;

  StockGoodsProducts({
    this.batchesList,
    this.id,
    this.productName,
    this.uId,
  });

  factory StockGoodsProducts.fromJson(Map<String, dynamic> json) =>
      StockGoodsProducts(
          id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
          productName:
              json.containsKey("product_name") && json["product_name"] != null
                  ? json["product_name"]
                  : "",
          batchesList:
              json.containsKey("batches") && json["batches"] != null
                  ? List<Batches>.from(
                      json["batches"].map((e) => Batches.fromJson(e)))
                  : [],
          uId: json.containsKey("u_id") && json["u_id"] != null
              ? json["u_id"]
              : "");

  Map<String, dynamic> toJson() => {
        "id": id,
        "product_name": productName,
        "batches": List<dynamic>.from(batchesList!.map((e) => e.toJson())),
        "u_id": uId,
      };
}

class Batches {
  String? batchNumber;
  num? cgst;
  num? cgstUnit;
  num? sgst;
  num? sgstUnit;
  num? tax;
  String? taxType;
  num? unitPrice;
  num? gstTotal;
  String? id;
  String? invoiceId;
  num? offerAmount;
  num? productAmountTotal;
  num? productCost;
  num? productTotalOffer;
  num? quantity;
  String? quantityIn;
  num? reducedQuantity;
  String? returnReason;
  String? uId;
  num? invoiceNo;
  TextEditingController? sellerAcceptedQunatityController;
  TextEditingController? sellerReceivedQuantityController;
  num? igstTotal;
  num? sellerReceivedQuantity;
  num? sellerAcceptedQuantity;
  DateTime? invoiceDate;
  Batches({
    this.batchNumber,
    this.cgst,
    this.cgstUnit,
    this.gstTotal,
    this.id,
    this.invoiceId,
    this.offerAmount,
    this.productAmountTotal,
    this.productCost,
    this.productTotalOffer,
    this.quantity,
    this.quantityIn,
    this.reducedQuantity,
    this.returnReason,
    this.sgst,
    this.sgstUnit,
    this.tax,
    this.taxType,
    this.uId,
    this.unitPrice,
    this.invoiceNo,
    this.sellerAcceptedQunatityController,
    this.sellerReceivedQuantityController,
    this.igstTotal,
    this.sellerAcceptedQuantity,
    this.sellerReceivedQuantity,
    this.invoiceDate,
  });
  factory Batches.fromJson(Map<String, dynamic> json) => Batches(
      batchNumber: json.containsKey("batch_number") && json["batch_number"] != null
          ? json["batch_number"]
          : "",
      cgst: json.containsKey("cgst") && json["cgst"] != null ? json["cgst"] : 0,
      cgstUnit: json.containsKey("cgst_unit") && json["cgst_unit"] != null
          ? json["cgst_unit"]
          : 0,
      sgst: json.containsKey("sgst") && json["sgst"] != null ? json["sgst"] : 0,
      sgstUnit: json.containsKey("sgst_unit") && json["sgst_unit"] != null
          ? json["sgst_unit"]
          : 0,
      tax: json.containsKey("tax") && json["tax"] != null ? json["tax"] : 0,
      taxType: json.containsKey("tax_type") && json["tax_type"] != null
          ? json["tax_type"]
          : "",
      unitPrice: json.containsKey("unit_price") && json["unit_price"] != null
          ? json["unit_price"]
          : 0,
      gstTotal: json.containsKey("gst_total") && json["gst_total"] != null
          ? json["gst_total"]
          : 0,
      invoiceId: json.containsKey("invoice_id") && json["invoice_id"] != null
          ? json["invoice_id"]
          : "",
      offerAmount: json.containsKey("offer_amount") && json["offer_amount"] != null
          ? json["offer_amount"]
          : 0,
      productAmountTotal: json.containsKey("product_amount_total") &&
              json["product_amount_total"] != null
          ? json["product_amount_total"]
          : 0,
      productCost: json.containsKey("product_cost") && json["product_cost"] != null
          ? json["product_cost"]
          : 0,
      productTotalOffer: json.containsKey("product_total_offer") &&
              json["product_total_offer"] != null
          ? json["product_total_offer"]
          : 0,
      quantity: json.containsKey("quantity") && json["quantity"] != null
          ? json["quantity"]
          : 0,
      quantityIn: json.containsKey("quantity_in") && json["quantity_in"] != null
          ? json["quantity_in"]
          : "",
      reducedQuantity: json.containsKey("reduced_quantity") && json["reduced_quantity"] != null ? json["reduced_quantity"] : 0,
      returnReason: json.containsKey("return_reason") && json["return_reason"] != null ? json["return_reason"] : "",
      uId: json.containsKey("u_id") && json["u_id"] != null ? json["u_id"] : "",
      invoiceNo: json.containsKey("invoice_number") && json["invoice_number"] != null ? json["invoice_number"] : 0,
      sellerAcceptedQuantity: json.containsKey("count_accepted_by_seller") && json["count_accepted_by_seller"] != null ? json["count_accepted_by_seller"] : 0,
      sellerReceivedQuantity: json.containsKey("count_recieved_by_seller") && json["count_recieved_by_seller"] != null ? json["count_recieved_by_seller"] : 0,
      invoiceDate: json.containsKey("invoice_date") && json["invoice_date"] != null ? DateTime.parse(json["invoice_date"]) : null);

  Map<String, dynamic> toJson() => {
        "batch_number": batchNumber,
        "cgst": cgst,
        "cgst_unit": cgstUnit,
        "sgst": sgst,
        "sgst_unit": sgstUnit,
        "tax": tax,
        "tax_type": taxType,
        "unit_price": unitPrice,
        "gst_total": gstTotal,
        "invoice_id": invoiceId,
        "offer_amount": offerAmount,
        "product_amount_total": productAmountTotal,
        "product_cost": productCost,
        "product_total_offer": productTotalOffer,
        "quantity": quantity,
        "quantity_in": quantityIn,
        "reduced_quantity": reducedQuantity,
        "return_reason": returnReason,
        "u_id": uId,
        "invoice_number": invoiceNo,
        "count_recieved_by_seller": sellerReceivedQuantity,
        "count_accepted_by_seller": sellerAcceptedQuantity,
        "invoice_date": invoiceDate!.toIso8601String(),
      };
}
