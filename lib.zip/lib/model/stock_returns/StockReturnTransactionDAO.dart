import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/model/TransactionsModel.dart';
import 'package:vyaparlive/model/stock_returns/StockGoodsProductsDAO.dart';
import 'package:vyaparlive/model/transaction/DeliveryDetailsModel.dart';
import 'package:vyaparlive/model/transaction/DiscussionModel.dart';
import 'package:vyaparlive/model/transaction/PackingDetailsModel.dart';

class StockReturnTransactionDAO {
  String? transactionId;
  String? buyerName;
  String? sellerName;
  Buyer? buyerData;
  Buyer? sellerData;
  String? buyerId;
  Discussion? discussionData;
  DateTime? createdDate;
  String? goodsType;
  String? status;
  num? billNo;
  String? invoiceId;
  // String transactionId;
  DateTime? invoiceDate;
  List<StockGoodsProducts>? returnProductList;
  num? docNumber;
  PackageDetails? packingData;
  List<Product>? productsList;
  OrderTrack? deliveryDetails;
  String? sellerId;
  String? grStatus;
  bool? isDocCreated;
  bool? isDeliveryDetailsUpdated;
  bool? isPackingDetailsUpdated;
  bool? isStockReceived;
  bool? isStockResolved;
  bool? isDraftCreditNoteCreated;
  bool? isFinalCreditNoteCreated;

  StockReturnTransactionDAO({
    this.buyerName,
    this.sellerName,
    this.transactionId,
    this.buyerData,
    this.sellerData,
    this.discussionData,
    this.buyerId,
    this.createdDate,
    this.goodsType,
    this.status,
    this.productsList,
    this.billNo,
    this.invoiceDate,
    this.invoiceId,
    this.docNumber,
    this.packingData,
    this.returnProductList,
    this.deliveryDetails,
    this.sellerId,
    this.grStatus,
    this.isDeliveryDetailsUpdated,
    this.isDocCreated,
    this.isDraftCreditNoteCreated,
    this.isFinalCreditNoteCreated,
    this.isPackingDetailsUpdated,
    this.isStockReceived,
    this.isStockResolved,
  });

  factory StockReturnTransactionDAO.fromJson(Map<String, dynamic> json) =>
      StockReturnTransactionDAO(
        buyerName: json.containsKey("buyer_name") && json["buyer_name"] != null
            ? json["buyer_name"]
            : "",
        sellerName:
            json.containsKey("seller_name") && json["seller_name"] != null
                ? json["seller_name"]
                : "",
        transactionId: CommonMethods.getTransactionIdFromRes(json),
        // json.containsKey("id") && json["id"] != null ? json["id"] : "",
        buyerData: json.containsKey("buyer") && json["buyer"] != null
            ? Buyer.fromJson(json["buyer"])
            : null,
        sellerData: json.containsKey("seller") && json["seller"] != null
            ? Buyer.fromJson(json['seller'])
            : null,
        discussionData:
            json.containsKey("discussion") && json["discussion"] != null
                ? Discussion.fromJson(json["discussion"])
                : null,
        buyerId: json.containsKey("buyer_id") && json["buyer_id"] != null
            ? json["buyer_id"]
            : "",
        createdDate:
            json.containsKey("created_dt") && json["created_dt"] != null
                ? DateTime.parse(json["created_dt"])
                : null,
        goodsType: json.containsKey("type") && json["type"] != null
            ? json["type"]
            : "",
        status: json.containsKey("status") && json["status"] != null
            ? json["status"]
            : "",
        invoiceDate:
            json.containsKey("invoice_date") && json["invoice_date"] != null
                ? DateTime.parse(json["invoice_date"])
                : null,
        invoiceId: json.containsKey("invoice_id") && json["invoice_id"] != null
            ? json["invoice_id"]
            : "",
        billNo:
            json.containsKey('invoice_number') && json["invoice_number"] != null
                ? json["invoice_number"]
                : 0,
        returnProductList: json.containsKey("preparedProducts") &&
                json["preparedProducts"] != null
            ? List<StockGoodsProducts>.from(json["preparedProducts"]
                .map((e) => StockGoodsProducts.fromJson(e)))
            : [],
        docNumber: json.containsKey("doc_number") && json["doc_number"] != null
            ? json["doc_number"]
            : 0,
        packingData: json.containsKey("packing_details") &&
                json["packing_details"] != null
            ? PackageDetails.fromJson(json["packing_details"])
            : null,
        productsList: json.containsKey("products") && json["products"] != null
            ? List<Product>.from(
                json["products"].map((e) => Product.fromJson(e)))
            : [],
        deliveryDetails:
            json.containsKey("order_track") && json["order_track"] != null
                ? OrderTrack.fromJson(json["order_track"])
                : null,
        sellerId: json.containsKey("seller_id") && json["seller_id"] != null
            ? json["seller_id"]
            : "",
        grStatus: json.containsKey("status") && json["status"] != null
            ? json["status"]
            : "",
        isDeliveryDetailsUpdated:
            json.containsKey("is_delivery_details_updated") &&
                    json["is_delivery_details_updated"] != null
                ? json["is_delivery_details_updated"]
                : false,

        isDocCreated: json.containsKey("is_document_created") &&
                json["is_document_created"] != null
            ? json["is_document_created"]
            : false,
        isDraftCreditNoteCreated:
            json.containsKey("is_draft_credit_note_generated") &&
                    json["is_draft_credit_note_generated"] != null
                ? json["is_draft_credit_note_generated"]
                : false,

        isFinalCreditNoteCreated:
            json.containsKey("is_final_credit_note_generated") &&
                    json["is_final_credit_note_generated"] != null
                ? json["is_final_credit_note_generated"]
                : false,

        isPackingDetailsUpdated:
            json.containsKey("is_packing_details_updated") &&
                    json["is_packing_details_updated"] != null
                ? json["is_packing_details_updated"]
                : false,
        isStockReceived: json.containsKey("is_stock_received") &&
                json["is_stock_received"] != null
            ? json["is_stock_received"]
            : false,
        isStockResolved: json.containsKey("is_stock_resolved") &&
                json["is_stock_resolved"] != null
            ? json["is_stock_resolved"]
            : false,
      );

  Map<String, dynamic> toJson() => {
        "id": transactionId,
        "buyer_name": buyerName,
        "seller_name": sellerName,
        "buyer": buyerData!.toJson(),
        "seller": sellerData!.toJson(),
        "discussion": discussionData!.toJson(),
        "buyer_id": buyerId,
        "created_dt": createdDate,
        "type": goodsType,
        "status": status,
        "preparedProducts":
            List<dynamic>.from(returnProductList!.map((e) => e.toJson())),
        "invoice_id": invoiceId,
        "invoice_date": invoiceDate!.toIso8601String(),
        "invoice_number": billNo,
        "doc_number": docNumber,
        "packing_details": packingData,
        "products": List<dynamic>.from(productsList!.map((e) => e.toJson())),
        "order_track": deliveryDetails!.toJson(),
        "seller_id": sellerId,
        "is_stock_resolved": isStockResolved,
        "is_stock_received": isStockReceived,
        "is_packing_details_updated": isPackingDetailsUpdated,
        "is_final_credit_note_generated": isFinalCreditNoteCreated,
        "is_draft_credit_note_generated": isDraftCreditNoteCreated,
        "is_document_created": isDocCreated,
        "is_delivery_details_updated": isDeliveryDetailsUpdated,
      };
}
