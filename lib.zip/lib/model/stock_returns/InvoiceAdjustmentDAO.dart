class InvoiceAdjustmentDAO {
  num? amount;
  num? billNo;
  String? invoiceId;

  InvoiceAdjustmentDAO({
    this.amount,
    this.billNo,
    this.invoiceId,
  });

  factory InvoiceAdjustmentDAO.fromJson(Map<String, dynamic> json) =>
      InvoiceAdjustmentDAO(
        amount: json.containsKey("amount") && json["amount"] != null
            ? json["amount"]
            : 0,
        billNo:
            json.containsKey("invoice_number") && json["invoice_number"] != null
                ? json["invoice_number"]
                : 0,
        invoiceId: json.containsKey("invoice_id") && json["invoice_id"] != null
            ? json["invoice_id"]
            : "",
      );

  Map<String, dynamic> toJson() => {
        "invoice_id": invoiceId,
        "invoice_number": billNo,
        "amount": amount,
      };
}
