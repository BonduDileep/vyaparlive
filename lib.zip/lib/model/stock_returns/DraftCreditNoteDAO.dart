import 'package:vyaparlive/model/stock_returns/StockGoodsProductsDAO.dart';

class DraftCreditNoteDAO {
  List<StockGoodsProducts>? productList;

  DraftCreditNoteDAO({
    this.productList,
  });

  factory DraftCreditNoteDAO.fromJson(Map<String, dynamic> json) =>
      DraftCreditNoteDAO(
        productList: json.containsKey("products") && json["products"] != null
            ? List<StockGoodsProducts>.from(
                json["products"].map((e) => StockGoodsProducts.fromJson(e)))
            : [],
      );

  Map<String, dynamic> toJson() =>
      {"products": List<dynamic>.from(productList!.map((e) => e.toJson()))};
}
