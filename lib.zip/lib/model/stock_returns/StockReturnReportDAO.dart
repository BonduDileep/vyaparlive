class StockReturnReportDAO {
  String? id;
  String? buyerName;
  String? buyerId;
  String? sellerName;
  String? sellerId;
  DateTime? createdDate;
  num? finalAmount;
  num? pendingAmount;
  num? count;

  StockReturnReportDAO({
    this.buyerId,
    this.buyerName,
    this.count,
    this.createdDate,
    this.finalAmount,
    this.id,
    this.pendingAmount,
    this.sellerId,
    this.sellerName,
  });

  factory StockReturnReportDAO.fromJson(Map<String, dynamic> json) =>
      StockReturnReportDAO(
        buyerId: json.containsKey("buyer_id") && json["buyer_id"] != null
            ? json["buyer_id"]
            : "",
        buyerName: json.containsKey("buyer_name") && json["buyer_name"] != null
            ? json["buyer_name"]
            : "",
        sellerId: json.containsKey("seller_id") && json["seller_id"] != null
            ? json["seller_id"]
            : "",
        sellerName:
            json.containsKey("seller_name") && json["seller_name"] != null
                ? json["seller_name"]
                : "",
        id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
        createdDate:
            json.containsKey("created_dt") && json["created_dt"] != null
                ? DateTime.parse(json["created_dt"])
                : null,
        finalAmount: json.containsKey("final_credit_amount") &&
                json["final_credit_amount"] != null
            ? json["final_credit_amount"]
            : 0,
        pendingAmount: json.containsKey("pending_credit_amount") &&
                json["pending_credit_amount"] != null
            ? json["pending_credit_amount"]
            : 0,
      );

  Map<String, dynamic> toJson() => {
        "pending_credit_amount": pendingAmount,
        "final_credit_amount": finalAmount,
        "created_dt": createdDate!.toIso8601String(),
        "id": id,
        "seller_name": sellerName,
        "seller_id": sellerId,
        "buyer_name": buyerName,
        "buyer_id": buyerId,
        "count": count,
      };
}
