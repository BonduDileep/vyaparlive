import 'package:vyaparlive/model/stock_returns/InvoiceAdjustmentDAO.dart';
import 'package:vyaparlive/model/stock_returns/StockGoodsProductsDAO.dart';

class FinalCreditNoteDAO {
  String? grId;
  String? grdId;
  String? noteId;
  DateTime? createdDate;
  num? crnNo;
  // num invoiceAdjustAmount;
  num? finalCreditAmout;
  num? pendingCreditAmount;
  List<StockGoodsProducts>? finalProductsList;
  List<InvoiceAdjustmentDAO>? invoiceAdjustAmountList;

  FinalCreditNoteDAO({
    this.createdDate,
    this.finalCreditAmout,
    this.grId,
    this.grdId,
    // this.invoiceAdjustAmount,
    this.noteId,
    this.crnNo,
    this.pendingCreditAmount,
    this.finalProductsList,
    this.invoiceAdjustAmountList,
  });

  factory FinalCreditNoteDAO.fromJson(Map<String, dynamic> json) =>
      FinalCreditNoteDAO(
        grId: json.containsKey("gr_id") && json["gr_id"] != null
            ? json["gr_id"]
            : "",
        grdId: json.containsKey("grd_id") && json["grd_id"] != null
            ? json["grd_id"]
            : "",
        noteId: json.containsKey("id") && json["id"] != null ? json["id"] : "",
        createdDate:
            json.containsKey("created_dt") && json["created_dt"] != null
                ? DateTime.parse(json["created_dt"])
                : null,
        // invoiceAdjustAmount: json.containsKey("invoice_adjustment") &&
        //         json["invoice_adjustment"] != null
        //     ? json["invoice_adjustment"]
        //     : 0,
        finalCreditAmout: json.containsKey("final_credit_amount") &&
                json["final_credit_amount"] != null
            ? json["final_credit_amount"]
            : 0,
        pendingCreditAmount: json.containsKey("pending_credit_amount") &&
                json["pending_credit_amount"] != null
            ? json["pending_credit_amount"]
            : 0,
        finalProductsList: json.containsKey("preparedProducts") &&
                json["preparedProducts"] != null
            ? List<StockGoodsProducts>.from(json["preparedProducts"]
                .map((e) => StockGoodsProducts.fromJson(e)))
            : [],
        crnNo: json.containsKey("crn_number") && json["crn_number"] != null
            ? json["crn_number"]
            : 0,
        invoiceAdjustAmountList: json.containsKey("invoice_adjustment") &&
                json["invoice_adjustment"] != null
            ? List<InvoiceAdjustmentDAO>.from(json["invoice_adjustment"]
                .map((e) => InvoiceAdjustmentDAO.fromJson(e)))
            : [],
      );

  Map<String, dynamic> toJson() => {
        "pending_credit_amount": pendingCreditAmount,
        "final_credit_amount": finalCreditAmout,
        "invoice_adjustment": List<dynamic>.from(invoiceAdjustAmountList!
            .map((i) => i.toJson())), //invoiceAdjustAmount,
        "created_dt": createdDate!.toIso8601String(),
        "id": noteId,
        "gr_id": grId,
        "grd_id": grdId,
        "preparedProducts":
            List<dynamic>.from(finalProductsList!.map((i) => i.toJson())),
        "crn_number": crnNo,
      };
}
