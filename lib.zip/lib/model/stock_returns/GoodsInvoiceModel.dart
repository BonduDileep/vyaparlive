import 'package:flutter/cupertino.dart';

class GoodsInvoiceModel {
  num? billNo;
  bool? isChecked;
  DateTime? invoiceDate;
  String? invoiceId;
  String? transactionId;
  num? invoiceQuantity;
  String? quantityIn;
  List<TextEditingController> returnProductsController;
  List<String?> returnProductsReason;
  List<num> totalProductsCount;
  String? product_uId;

  GoodsInvoiceModel({
    this.billNo,
    this.isChecked,
    this.invoiceDate,
    this.invoiceId,
    this.transactionId,
    this.invoiceQuantity,
    this.quantityIn,
    this.product_uId,
  })  : this.returnProductsController = [],
        this.returnProductsReason = [],
        this.totalProductsCount = [];
}
