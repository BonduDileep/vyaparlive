import 'package:vyaparlive/model/stock_returns/DraftCreditNoteDAO.dart';
import 'package:vyaparlive/model/stock_returns/StockGoodsProductsDAO.dart';
import 'package:vyaparlive/model/transaction/DeliveryDetailsModel.dart';
import 'package:vyaparlive/model/transaction/PackingDetailsModel.dart';
import 'package:vyaparlive/model/transaction/StockDetailsModel.dart';

class GRDocList {
  String? buyerName;
  String? sellerName;
  String? buyerId;
  String? sellerId;
  DateTime? docCreatedDate;
  String? docId;
  num? docNumber;
  PackageDetails? packingData;
  List<StockGoodsProducts>? returnProductList;
  String? status;
  OrderTrack? deliveryDetails;
  StockReconciliation? grdReconciliation;
  String? actualDeliveryDate;
  String? actualDeliveryTime;
  String? stockReceivedBy;
  String? stockReceivedStatus;
  DateTime? actualDeliveryTimeStamp;
  DraftCreditNoteDAO? draftCreditNote;
  bool? isBuyerDraftNoteAccepted;
  GRDocList({
    this.buyerId,
    this.buyerName,
    this.docCreatedDate,
    this.docId,
    this.docNumber,
    this.sellerId,
    this.sellerName,
    this.packingData,
    this.returnProductList,
    this.status,
    this.deliveryDetails,
    this.grdReconciliation,
    this.actualDeliveryDate,
    this.actualDeliveryTime,
    this.stockReceivedBy,
    this.stockReceivedStatus,
    this.actualDeliveryTimeStamp,
    this.draftCreditNote,
    this.isBuyerDraftNoteAccepted,
  });

  factory GRDocList.fromJson(Map<String, dynamic> json) => GRDocList(
        buyerId: json.containsKey("buyer_id") && json["buyer_id"] != null
            ? json["buyer_id"]
            : "",
        buyerName: json.containsKey("buyer_name") && json["buyer_name"] != null
            ? json["buyer_name"]
            : "",
        sellerId: json.containsKey("seller_id") && json["seller_id"] != null
            ? json["seller_id"]
            : "",
        sellerName:
            json.containsKey("seller_name") && json["seller_name"] != null
                ? json["seller_name"]
                : "",
        docId: json.containsKey("id") && json["id"] != null ? json["id"] : "",
        docNumber: json.containsKey("doc_number") && json["doc_number"] != null
            ? json["doc_number"]
            : 0,
        docCreatedDate:
            json.containsKey("created_dt") && json["created_dt"] != null
                ? DateTime.parse(json["created_dt"])
                : null,
        packingData: json.containsKey("packing_details") &&
                json["packing_details"] != null
            ? PackageDetails.fromJson(json["packing_details"])
            : null,
        returnProductList: json.containsKey("preparedProducts") &&
                json["preparedProducts"] != null
            ? List<StockGoodsProducts>.from(json["preparedProducts"]
                .map((e) => StockGoodsProducts.fromJson(e)))
            : [],
        status: json.containsKey("status") && json["status"] != null
            ? json["status"]
            : "",
        deliveryDetails:
            json.containsKey("order_track") && json["order_track"] != null
                ? OrderTrack.fromJson(json['order_track'])
                : null,
        grdReconciliation: json.containsKey("stock_reconciliation") &&
                json["stock_reconciliation"] != null
            ? StockReconciliation.fromJson(json["stock_reconciliation"])
            : null,
        actualDeliveryDate: json.containsKey("actual_delivery_date") &&
                json["actual_delivery_date"] != null
            ? json["actual_delivery_date"]
            : "",
        actualDeliveryTime: json.containsKey("actual_delivery_time") &&
                json["actual_delivery_time"] != null
            ? json["actual_delivery_time"]
            : "",
        stockReceivedBy: json.containsKey("stock_received_by") &&
                json["stock_received_by"] != null
            ? json["stock_received_by"]
            : "",
        stockReceivedStatus: json.containsKey("stock_received_status") &&
                json["stock_received_status"] != null
            ? json["stock_received_status"]
            : "",
        actualDeliveryTimeStamp:
            json.containsKey("actual_delivery_date_time") &&
                    json["actual_delivery_date_time"] != null
                ? DateTime.parse(json["actual_delivery_date_time"])
                : null,
        isBuyerDraftNoteAccepted: json.containsKey("is_buyer_accepted") &&
                json["is_buyer_accepted"] != null
            ? json["is_buyer_accepted"]
            : false,
        draftCreditNote: json.containsKey("draft_credit_note") &&
                json["draft_credit_note"] != null
            ? DraftCreditNoteDAO.fromJson(json['draft_credit_note'])
            : null,
      );

  Map<String, dynamic> toJson() => {
        "created_dt": docCreatedDate!.toIso8601String(),
        "doc_number": docNumber,
        "id": docId,
        "seller_name": sellerName,
        "seller_id": sellerId,
        "buyer_name": buyerName,
        "buyer_id": buyerId,
        "packing_details": packingData!.toJson(),
        "preparedProducts":
            List<dynamic>.from(returnProductList!.map((e) => e.toJson())),
        "status": status,
        "order_track": deliveryDetails!.toJson(),
        "stock_reconciliation": grdReconciliation!.toJson(),
        "actual_delivery_date_time": actualDeliveryTimeStamp!.toIso8601String(),
        "actual_delivery_date": actualDeliveryDate,
        "actual_delivery_time": actualDeliveryTime,
        "stock_received_by": stockReceivedBy,
        "stock_received_status": stockReceivedStatus,
        "is_buyer_accepted": false,
        "draft_credit_note": draftCreditNote!.toJson(),
      };
}
