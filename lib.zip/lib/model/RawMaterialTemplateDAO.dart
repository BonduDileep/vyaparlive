import 'package:vyaparlive/model/product_model/ProductModel.dart';

class RawMaterialTemplateDAO {
  String? templateName;
  String? description;
  List<TemplateRawProductsDAO>? rawProducts;
  BuProductModal? finishedProduct;
  String? templateId;
  List<BuProductModal>? finishedProductsList;

  RawMaterialTemplateDAO(
      {this.description,
      this.templateName,
      this.rawProducts,
      this.finishedProduct,
      this.templateId,
      this.finishedProductsList});

  factory RawMaterialTemplateDAO.fromJson(Map<String, dynamic> json) =>
      RawMaterialTemplateDAO(
          templateName: json.containsKey("name") && json["name"] != null
              ? json["name"]
              : "",
          description:
              json.containsKey("description") && json["description"] != null
                  ? json["description"]
                  : "",
          rawProducts: json.containsKey("raw_material_products") &&
                  json["raw_material_products"] != null
              ? List<TemplateRawProductsDAO>.from(json["raw_material_products"]
                  .map((e) => TemplateRawProductsDAO.fromJson(e)))
              : [],
          finishedProduct: json.containsKey("products") && json["products"] != null
              ? BuProductModal.fromJson(json["products"])
              : null,
          templateId:
              json.containsKey("id") && json["id"] != null ? json["id"] : "",
          finishedProductsList: json.containsKey("finished_products") &&
                  json["finished_products"] != null
              ? List<BuProductModal>.from(
                  json["finished_products"].map((x) => BuProductModal.fromJson(x)))
              : []);

  Map<String, dynamic> toJson() => {
        "name": templateName,
        "description": description,
        "raw_material_products":
            List<dynamic>.from(rawProducts!.map((e) => e.toJson())),
        "finished_products":
            List<dynamic>.from(finishedProductsList!.map((e) => e.toJson())),
        "products": finishedProduct!.toJson(),
        "id": templateId
      };
}

class TemplateRawProductsDAO {
  String? rawProductName;
  num? quantity;
  String? quantityIn;
  String? productId;

  TemplateRawProductsDAO(
      {this.quantity, this.quantityIn, this.rawProductName, this.productId});
  factory TemplateRawProductsDAO.fromJson(Map<String, dynamic> json) =>
      TemplateRawProductsDAO(
          productId:
              json.containsKey("id") && json["id"] != null ? json["id"] : "",
          quantity: json.containsKey("quantity") && json["quantity"] != null
              ? json["quantity"]
              : "" as num?,
          quantityIn:
              json.containsKey("quantity_in") && json["quantity_in"] != null
                  ? json["quantity_in"]
                  : "",
          rawProductName:
              json.containsKey("product_name") && json["product_name"] != null
                  ? json["product_name"]
                  : "");

  Map<String, dynamic> toJson() => {
        "quantity_in": quantityIn,
        "quantity": quantity,
        "id": productId,
        "product_name": rawProductName
      };
}
