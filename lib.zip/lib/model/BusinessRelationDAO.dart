class BusinessRelationDAO {
  String? id;
  String? type;

  BusinessRelationDAO({this.id, this.type});

  factory BusinessRelationDAO.fromJson(Map<String, dynamic> json) =>
      BusinessRelationDAO(
          id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
          type: json.containsKey("type") && json["type"] != null
              ? json["type"]
              : "");

  Map<String, dynamic> toJson() => {"id": id, "type": type};
}
