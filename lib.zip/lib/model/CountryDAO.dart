class CountryDAO {
  String? name;
  String? id;
  String? code;
  String? currencyCode;
  String? currencySymbol;
  String? countryCode;
  String? currencyName;

  CountryDAO(
      {this.name,
      this.id,
      this.code,
      this.currencyCode,
      this.currencySymbol,
      this.countryCode,
      this.currencyName});

  factory CountryDAO.fromJaon(Map<String, dynamic> json) => CountryDAO(
      name:
          json.containsKey("name") && json["name"] != null ? json["name"] : "",
      id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
      code:
          json.containsKey("code") && json["code"] != null ? json["code"] : "",
      currencyCode: json.containsKey("currency_code")
          ? json["currency_code"]
          : "",
      currencySymbol:
          json.containsKey("currency_symbol") && json["currency_symbol"] != null
              ? json["currency_symbol"]
              : "",
      countryCode:
          json.containsKey("country_code") && json["country_code"] != null
              ? json["country_code"]
              : "",
      currencyName:
          json.containsKey("currency_name") && json["currency_name"] != null
              ? json["currency_name"]
              : "");

  Map<String, dynamic> toJson() => {
        "name": name,
        "id": id,
        "code": code,
        "currency_code": currencyCode,
        "currency_symbol": currencySymbol,
        "country_code": countryCode,
        "currency_name": currencyName
      };
}
