import 'package:vyaparlive/model/bu_model/AddressDetailsModel.dart';

class BuListModel {
  String? name;
  String? emailId;
  String? contact;
  String? buId;
  DateTime? createdDate;
  String? recordId;
  Address? address;
  String? gstNo;
  BuListModel(
      {this.buId,
      this.contact,
      this.createdDate,
      this.emailId,
      this.name,
      this.recordId,
      this.address,
      this.gstNo});
  factory BuListModel.fromJson(Map<String, dynamic> json) => BuListModel(
      name:
          json.containsKey('name') && json['name'] != null ? json['name'] : "",
      emailId: json.containsKey('email_id') && json['email_id'] != null
          ? json['email_id']
          : "",
      contact: json.containsKey('contact') && json['contact'] != null
          ? json['contact']
          : "",
      buId:
          json.containsKey('buId') && json['buId'] != null ? json['buId'] : "",
      createdDate:
          json.containsKey('created_date') && json['created_date'] != null
              ? DateTime.parse(json['created_date'])
              : null,
      recordId: json.containsKey('id') && json['id'] != null ? json['id'] : "",
      gstNo: json.containsKey('GST_No') && json['GST_No'] != null ? json['GST_No'] : "",
      address: json.containsKey('address') && json['address'] != null
          ? Address.fromJson(json['address'])
          : null);

  Map<String, dynamic> toJson() => {
        'name': name,
        "buId": buId,
        'email_id': emailId,
        'id': recordId,
        'contact': contact,
        'created_date': createdDate!.toIso8601String(),
        'address': address.toString()
      };

  @override
  String toString() {
    return '$name'.toLowerCase() + '$name'.toUpperCase();
  }
}
