import 'package:vyaparlive/model/product_model/BatchPriceDAO.dart';
import 'package:vyaparlive/model/product_model/ImageUrl.dart';
import 'package:vyaparlive/model/product_model/InventoryDetailsDAO.dart';
import 'package:vyaparlive/model/product_model/ManufactureDetailsDAO.dart';
import 'package:vyaparlive/model/product_model/ShippingDetailsDAO.dart';

class ProductConsumptionDAO {
  String? id;
  String? buId;
  String? name;
  String? productCategory;
  String? productSubCategory;
  String? productSegment;
  String? brand;
  String? description;
  bool? isConsumable;
  bool? isNonConsumable;
  List? attributesList;
  List<InventoryDetailsDAO>? inventoryData;
  List<BatchPriceDAO>? batchPrice;
  ManufactureDetailsDAO? manufactureDetails;
  ShippingDetailsDAO? shippingDetails;
  List<ImageUrl>? imageThumbnail;
  List<IssueDetails>? issueDetailsData;

  ProductConsumptionDAO(
      {this.attributesList,
      this.batchPrice,
      this.brand,
      this.buId,
      this.description,
      this.id,
      this.inventoryData,
      this.isConsumable,
      this.isNonConsumable,
      this.manufactureDetails,
      this.name,
      this.productCategory,
      this.productSegment,
      this.productSubCategory,
      this.shippingDetails,
      this.imageThumbnail,
      this.issueDetailsData});

  factory ProductConsumptionDAO.fromJson(Map<String, dynamic> json) => ProductConsumptionDAO(
      buId: json.containsKey("bu_id") && json["bu_id"] != null
          ? json["bu_id"]
          : "",
      name:
          json.containsKey("name") && json["name"] != null ? json["name"] : "",
      brand: json.containsKey("brand") && json["brand"] != null
          ? json["brand"]
          : "",
      isConsumable: json.containsKey("consumable") && json["consumable"] != null
          ? json["consumable"]
          : false,
      isNonConsumable: json.containsKey("non_consumable") && json["non_consumable"] != null
          ? json["non_consumable"]
          : false,
      description: json.containsKey("description") && json["description"] != null
          ? json["description"]
          : "",
      productSegment:
          json.containsKey("product_segment") && json["product_segment"] != null
              ? json["product_segment"]
              : "",
      productCategory:
          json.containsKey("product_category") && json["product_category"] != null
              ? json["product_category"]
              : "",
      productSubCategory:
          json.containsKey("product_sub_category") && json["product_sub_category"] != null
              ? json["product_sub_category"]
              : "",
      inventoryData: json.containsKey("inventory_management") &&
              json["inventory_management"] != null
          ? List<InventoryDetailsDAO>.from(json["inventory_management"].map((x) => InventoryDetailsDAO.fromJson(x)))
          : [],
      attributesList: json.containsKey("attributes") && json["attributes"] != null ? List.from(json["attributes"].map((x) => x)) : [],
      manufactureDetails: json.containsKey("manufacture_details") && json["manufacture_details"] != null ? ManufactureDetailsDAO.fromJson(json["manufacture_details"]) : null,
      batchPrice: json.containsKey("batch_pricing") && json["batch_pricing"] != null ? List<BatchPriceDAO>.from(json["batch_pricing"].map((e) => BatchPriceDAO.fromJson(e))) : [],
      shippingDetails: json.containsKey("shipping_details") && json["shipping_details"] != null ? ShippingDetailsDAO.fromJson(json["shipping_details"]) : null,
      id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
      imageThumbnail: json.containsKey("image_dps") && json["image_dps"] != null ? List<ImageUrl>.from(json["image_dps"].map((x) => ImageUrl.fromJson(x))) : [],
      issueDetailsData: json.containsKey("issues") && json["issues"] != null ? List<IssueDetails>.from(json["issues"].map((x) => IssueDetails.fromJson(x))) : []);

  Map<String, dynamic> toJson() => {
        "bu_id": buId,
        "name": name,
        "brand": brand,
        "description": description,
        "product_segment": productSegment,
        "product_category": productCategory,
        "product_sub_category": productSubCategory,
        "consumable": isConsumable,
        "non_consumable": isNonConsumable,
        "manufacture_details": manufactureDetails!.toJson(),
        "shipping_details": shippingDetails!.toJson(),
        "id": id,
        "inventory_management":
            List<dynamic>.from(inventoryData!.map((e) => e.toJson())),
        "batch_pricing": List<dynamic>.from(batchPrice!.map((e) => e.toJson())),
        "image_dps": List<dynamic>.from(imageThumbnail!.map((e) => e)),
        "issues": List<dynamic>.from(issueDetailsData!.map((e) => e)),
      };
}

class IssueDetails {
  String? issuedDate;
  String? issuedTo;
  String? approvedBy;
  String? batchNumber;
  String? purpose;
  num? issuedQuantity;
  num? remaingQuantity;
  String? productName;
  String? department;

  IssueDetails(
      {this.approvedBy,
      this.batchNumber,
      this.issuedDate,
      this.issuedQuantity,
      this.issuedTo,
      this.purpose,
      this.remaingQuantity,
      this.productName,
      this.department});

  factory IssueDetails.fromJson(Map<String, dynamic> json) => IssueDetails(
      issuedDate: json.containsKey("issued_date") && json["issued_date"] != null
          ? json["issued_date"]
          : "",
      issuedQuantity:
          json.containsKey("issued_quantity") && json["issued_quantity"] != null
              ? json["issued_quantity"]
              : 0,
      issuedTo: json.containsKey("issued_to") && json["issued_to"] != null
          ? json["issued_to"]
          : "",
      approvedBy: json.containsKey("approved_by") && json["approved_by"] != null
          ? json["approved_by"]
          : "",
      purpose: json.containsKey("purpose") && json["purpose"] != null
          ? json["purpose"]
          : "",
      batchNumber: json.containsKey("batch_no") && json["batch_no"] != null
          ? json["batch_no"]
          : "",
      remaingQuantity: json.containsKey("remaining_quantity") &&
              json["remaining_quantity"] != null
          ? json["remaining_quantity"]
          : 0,
      department: json.containsKey("department") && json["department"] != null
          ? json["department"]
          : "");

  Map<String, dynamic> toJson() => {
        "issued_date": issuedDate,
        "issued_to": issuedTo,
        "purpose": purpose,
        "approved_by": approvedBy,
        "issued_quantity": issuedQuantity,
        "batch_no": batchNumber,
        "remaining_quantity": remaingQuantity,
        "department": department
      };
}
