class ReceiveAddressModel {
  String? name;
  String? address;
  String? number;

  ReceiveAddressModel({this.name, this.address, this.number});
}
