class RoleRelationDAO {
  String? id;
  String? type;

  RoleRelationDAO({this.id, this.type});

  factory RoleRelationDAO.fromJson(Map<String, dynamic> json) =>
      RoleRelationDAO(
          id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
          type: json.containsKey("type") && json["type"] != null
              ? json["type"]
              : "");

  Map<String, dynamic> toJson() => {"id": id, "type": type};
}
