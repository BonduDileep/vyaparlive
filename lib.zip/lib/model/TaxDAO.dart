class TaxDAO {
  String? type;
  String? value;
  String? id;

  TaxDAO({this.type, this.value, this.id});

  factory TaxDAO.from(Map<String, dynamic> json) => TaxDAO(
      type:
          json.containsKey("type") && json["type"] != null ? json["type"] : "",
      value: json.containsKey("value") && json["value"] != null
          ? json["value"]
          : "",
      id: json.containsKey("id") && json["id"] != null ? json["id"] : "");

  Map<String, dynamic> toJson() => {"type": type, "value": value, "id": id};
}
