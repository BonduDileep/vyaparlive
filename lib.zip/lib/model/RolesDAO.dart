import 'package:vyaparlive/model/PrivilegesDAO.dart';

class RolesDAO {
  String? roleId;
  String? name;
  String? code;
  Permissions? permissions;
  List<String>? privilegesList;
  RolesDAO(
      {this.roleId,
      this.name,
      this.code,
      this.permissions,
      this.privilegesList});

  factory RolesDAO.fromJson(Map<String, dynamic> json) => RolesDAO(
        roleId: json.containsKey("role_id") && json["role_id"] != null
            ? json["role_id"]
            : "",
        name: json.containsKey("name") && json["name"] != null
            ? json["name"]
            : "",
        code: json.containsKey("code") && json["code"] != null
            ? json["code"]
            : "",
        // permissions:
        //     json.containsKey("permissions") && json['permissions'] != null
        //         ? Permissions.fromJson(json['permissions'])
        //         : null,
        privilegesList:
            json.containsKey("permissions") && json['permissions'] != null
                ? List<String>.from(json['permissions'].map((x) => x))
                : null,
      );

  Map<String, dynamic> toJson() => {
        "role_id": roleId,
        "name": name,
        "code": code,
        "permissions": List<dynamic>.from(privilegesList!.map((e) => e))
      };
}

class Permissions {
  List<PrivilegesDAO>? transactionsPermissions;
  List<PrivilegesDAO>? connectionPermissions;
  List<PrivilegesDAO>? productPermissions;
  List<PrivilegesDAO>? subscriptionPermissions;
  List<PrivilegesDAO>? inPersonOrderPermissions;
  List<PrivilegesDAO>? usersPermissions;
  List<PrivilegesDAO>? invitationsPermissions;
  List<PrivilegesDAO>? buPermissions;
  List<PrivilegesDAO>? assetManagementPrivileges;
  List<PrivilegesDAO>? productConsumptionPrivileges;
  List<PrivilegesDAO>? reportsPrivileges;
  List<PrivilegesDAO>? retailSalesPrivileges;
  List<PrivilegesDAO>? expensesPrivileges;

  Permissions(
      {this.buPermissions,
      this.connectionPermissions,
      this.inPersonOrderPermissions,
      this.invitationsPermissions,
      this.productPermissions,
      this.subscriptionPermissions,
      this.transactionsPermissions,
      this.usersPermissions,
      this.assetManagementPrivileges,
      this.productConsumptionPrivileges,
      this.reportsPrivileges,
      this.retailSalesPrivileges,
      this.expensesPrivileges});

  factory Permissions.fromJson(Map<String, dynamic> json) => Permissions(
      transactionsPermissions:
          json.containsKey("TRANSACTION") && json['TRANSACTION'] != null
              ? List<PrivilegesDAO>.from(
                  json['TRANSACTION'].map((x) => PrivilegesDAO.fromJson(x)))
              : [],
      connectionPermissions: json.containsKey("CONNECTIONS") && json['CONNECTIONS'] != null
          ? List<PrivilegesDAO>.from(
              json['CONNECTIONS'].map((x) => PrivilegesDAO.fromJson(x)))
          : [],
      productPermissions: json.containsKey("PRODUCT") && json['PRODUCT'] != null
          ? List<PrivilegesDAO>.from(
              json['PRODUCT'].map((x) => PrivilegesDAO.fromJson(x)))
          : [],
      subscriptionPermissions:
          json.containsKey("SUBSCRIPTION") && json['SUBSCRIPTION'] != null
              ? List<PrivilegesDAO>.from(
                  json['SUBSCRIPTION'].map((x) => PrivilegesDAO.fromJson(x)))
              : [],
      inPersonOrderPermissions:
          json.containsKey("IN_PERSON_ORDER") && json['IN_PERSON_ORDER'] != null
              ? List<PrivilegesDAO>.from(json['IN_PERSON_ORDER'].map((x) => PrivilegesDAO.fromJson(x)))
              : [],
      usersPermissions: json.containsKey("USERS") && json['USERS'] != null ? List<PrivilegesDAO>.from(json['USERS'].map((x) => PrivilegesDAO.fromJson(x))) : [],
      invitationsPermissions: json.containsKey("INVITATION") && json['INVITATION'] != null ? List<PrivilegesDAO>.from(json['INVITATION'].map((x) => PrivilegesDAO.fromJson(x))) : [],
      buPermissions: json.containsKey("BUSINESS_UNIT") && json['BUSINESS_UNIT'] != null ? List<PrivilegesDAO>.from(json['BUSINESS_UNIT'].map((x) => PrivilegesDAO.fromJson(x))) : [],
      assetManagementPrivileges: json.containsKey("ASSETS_MANAGEMENT") && json['ASSETS_MANAGEMENT'] != null ? List<PrivilegesDAO>.from(json['ASSETS_MANAGEMENT'].map((x) => PrivilegesDAO.fromJson(x))) : [],
      productConsumptionPrivileges: json.containsKey("PRODUCTION_CONSUMPTION") && json['PRODUCTION_CONSUMPTION'] != null ? List<PrivilegesDAO>.from(json['PRODUCTION_CONSUMPTION'].map((x) => PrivilegesDAO.fromJson(x))) : [],
      reportsPrivileges: json.containsKey("REPORTS") && json["REPORTS"] != null ? List<PrivilegesDAO>.from(json["REPORTS"].map((x) => PrivilegesDAO.fromJson(x))) : [],
      retailSalesPrivileges: json.containsKey("RETAIL_SALES") && json["RETAIL_SALES"] != null ? List<PrivilegesDAO>.from(json["RETAIL_SALES"].map((x) => PrivilegesDAO.fromJson(x))) : [],
      expensesPrivileges: json.containsKey("EXPENSES") && json["EXPENSES"] != null ? List<PrivilegesDAO>.from(json["EXPENSES"].map((x) => PrivilegesDAO.fromJson(x))) : []);

  Map<String, dynamic> toJson() => {
        "TRANSACTION":
            List<dynamic>.from(transactionsPermissions!.map((e) => e.toJson())),
        "CONNECTIONS":
            List<dynamic>.from(connectionPermissions!.map((e) => e.toJson())),
        "PRODUCT":
            List<dynamic>.from(productPermissions!.map((e) => e.toJson())),
        "SUBSCRIPTION":
            List<dynamic>.from(subscriptionPermissions!.map((e) => e.toJson())),
        "IN_PERSON_ORDER": List<dynamic>.from(
            inPersonOrderPermissions!.map((e) => e.toJson())),
        "USERS": List<dynamic>.from(usersPermissions!.map((e) => e.toJson())),
        "INVITATION":
            List<dynamic>.from(invitationsPermissions!.map((e) => e.toJson())),
        "BUSINESS_UNIT":
            List<dynamic>.from(buPermissions!.map((e) => e.toJson())),
        "PRODUCTION_CONSUMPTION": List<dynamic>.from(
            productConsumptionPrivileges!.map((e) => e.toJson())),
        "ASSETS_MANAGEMENT": List<dynamic>.from(
            assetManagementPrivileges!.map((e) => e.toJson())),
        "REPORTS":
            List<dynamic>.from(reportsPrivileges!.map((e) => e.toJson())),
        "RETAIL_SALES":
            List<dynamic>.from(retailSalesPrivileges!.map((e) => e.toJson())),
        "EXPENSES":
            List<dynamic>.from(expensesPrivileges!.map((e) => e.toJson())),
      };
}
