import 'package:vyaparlive/model/product_model/OffersDAO.dart';
import 'package:vyaparlive/model/product_model/PriceDetailsDAO.dart';
import 'package:vyaparlive/model/TransactionsModel.dart';
import 'package:vyaparlive/model/product_model/ShippingDetailsDAO.dart';

class ProductPackageDao {
  ProductPackageDao(
      {this.sku,
      this.buId,
      this.type,
      this.products,
      this.shippingDetails,
      this.quantity,
      this.pricing,
      this.offers,
      this.id,
      this.packageName});

  String? sku;
  String? buId;
  String? type;
  List<Product>? products;
  ShippingDetailsDAO? shippingDetails;
  num? quantity;
  PriceDetailsDAO? pricing;
  List<OffersDAO>? offers;

  String? id;
  String? packageName;

  factory ProductPackageDao.fromJson(Map<String, dynamic> json) =>
      ProductPackageDao(
        sku: json.containsKey("sku") && json["sku"] != null ? json["sku"] : "",
        buId: json.containsKey("bu_id") && json["bu_id"] != null
            ? json["bu_id"]
            : "",
        type: json.containsKey("type") && json["type"] != null
            ? json["type"]
            : "",
        products: json.containsKey("products") && json["products"] != null
            ? List<Product>.from(
                json["products"].map((x) => Product.fromJson(x)))
            : "" as List<Product>?,
        packageName:
            json.containsKey("package_name") && json['package_name'] != null
                ? json['package_name']
                : "",
        shippingDetails: json.containsKey("shipping_details") &&
                json['shipping_details'] != null
            ? ShippingDetailsDAO.fromJson(json["shipping_details"])
            : "" as ShippingDetailsDAO?,
        quantity: json.containsKey("quantity") && json["quantity"] != null
            ? json["quantity"]
            : 0,
        pricing: json.containsKey("pricing") && json["pricing"] != null
            ? PriceDetailsDAO.fromJson(json["pricing"])
            : "" as PriceDetailsDAO?,
        offers: json.containsKey("offers") && json["offers"] != null
            ? List<OffersDAO>.from(
                json["offers"].map((x) => OffersDAO.fromJson(x)))
            : "" as List<OffersDAO>?,
        id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
      );

  Map<String, dynamic> toJson() => {
        "sku": sku,
        "bu_id": buId,
        "type": type,
        "products": List<dynamic>.from(products!.map((x) => x.toJson())),
        "shipping_details": shippingDetails!.toJson(),
        "quantity": quantity,
        "pricing": pricing!.toJson(),
        "offers": List<dynamic>.from(offers!.map((x) => x.toJson())),
        "id": id,
        "package_name": packageName
      };
}
