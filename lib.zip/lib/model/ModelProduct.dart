import 'package:flutter/cupertino.dart';
import 'package:vyaparlive/model/product_model/BatchPriceDAO.dart';
import 'package:vyaparlive/model/product_model/OffersDAO.dart';

class ModelProduct {
  String? id;
  String? name;
  int? counter;
  bool? isButton;
  String? images;
  num? price;
  num? quantity;
  bool isItemSelected;
  List<OffersDAO>? offerList;
  num? unitPrice;
  OffersDAO? offerData;
  bool? offerSelected;
  List<BatchPriceDAO>? batchPriceList;
  String? batchNumber;
  String? quantityIn;
  List<TextEditingController>? returnProductsController;
  List<String>? returnReasonText;
  num totalReturnProductsQuantity;
  List<num>? invoiceList;
  List<DateTime>? invoiceDate;
  List<num>? invoiceQuantity;
  bool isEditable;
  bool isCustomProduct;
  num totalPrice;
  num? counterNew;
  bool? isPriceChanged;
  bool? isDisposable;
  String? selectedUnit; // kg / gram / ltr / ml
  num? unitMultiplier = 1; // for gram/ml conversion
  num? actual_quantity;
  ModelProduct(
      {this.id,
      this.name,
      this.counter,
      this.isButton,
      this.images,
      this.price,
      this.quantity,
      this.isItemSelected = false,
      this.unitPrice,
      this.offerData,
      this.offerSelected = false,
      this.offerList,
      this.batchPriceList,
      this.batchNumber,
      this.quantityIn,
      this.returnProductsController,
      this.returnReasonText,
      this.totalReturnProductsQuantity = 0,
      this.invoiceDate,
      this.invoiceList,
      this.invoiceQuantity,
      this.isEditable = false,
      this.isCustomProduct = false,
      this.totalPrice = 0,
      this.counterNew = 0.0,
      this.isPriceChanged = false,
      this.isDisposable = false,
      this.selectedUnit,
      this.unitMultiplier,
      this.actual_quantity});

  ModelProduct.clone(ModelProduct source)
      : id = source.id,
        name = source.name,
        counter = source.counter,
        isButton = source.isButton,
        images = source.images,
        price = source.price,
        quantity = source.quantity,
        isItemSelected = source.isItemSelected,
        unitPrice = source.unitPrice,
        offerData = source.offerData,
        offerSelected = source.offerSelected,
        offerList = source.offerList,
        batchPriceList = source.batchPriceList,
        batchNumber = source.batchNumber,
        quantityIn = source.quantityIn,
        returnProductsController = source.returnProductsController,
        returnReasonText = source.returnReasonText,
        totalReturnProductsQuantity = source.totalReturnProductsQuantity,
        invoiceDate = source.invoiceDate,
        invoiceList = source.invoiceList,
        invoiceQuantity = source.invoiceQuantity,
        isEditable = source.isEditable,
        isCustomProduct = source.isCustomProduct,
        totalPrice = source.totalPrice,
        counterNew = source.counterNew,
        isPriceChanged = source.isPriceChanged,
        isDisposable = source.isDisposable,
        selectedUnit = source.selectedUnit,
        unitMultiplier = source.unitMultiplier,
        actual_quantity = source.actual_quantity;

  get length => null;

  @override
  String toString() {
    return '$name'.toUpperCase() + '$name'.toLowerCase();
  }
}
