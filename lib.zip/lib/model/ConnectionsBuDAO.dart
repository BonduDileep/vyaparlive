import 'package:vyaparlive/model/bu_model/PaymentTermsModel.dart';
import 'package:vyaparlive/model/bu_model/TaxSchemeModel.dart';

class ConnectionsBuDAO {
  String? businessName;
  String? headOfBusiness;
  String? website;
  String? type;
  String? contactNumber;
  String? countryCode;
  String? currencyCode;
  ContactDetails? contactDetails;
  PaymentTerms? paymentTerms;
  String? gstNo;
  List<TaxScheme>? taxData;

  ConnectionsBuDAO(
      {this.businessName,
      this.headOfBusiness,
      this.website,
      this.type,
      this.countryCode,
      this.currencyCode,
      this.contactDetails,
      this.contactNumber,
      this.paymentTerms,
      this.gstNo,
      this.taxData});

  factory ConnectionsBuDAO.fromJson(Map<String, dynamic> json) => ConnectionsBuDAO(
      businessName: json.containsKey("business_name") && json["business_name"] != null
          ? json["business_name"]
          : "",
      headOfBusiness:
          json.containsKey("head_of_business") && json["head_of_business"] != null
              ? json["head_of_business"]
              : "",
      website: json.containsKey("website") && json["website"] != null
          ? json["website"]
          : "",
      type:
          json.containsKey("type") && json["type"] != null ? json["type"] : "",
      contactNumber:
          json.containsKey("contact_number") && json["contact_number"] != null
              ? json["contact_number"]
              : "",
      countryCode: json.containsKey("country_code") && json["country_code"] != null
          ? json["country_code"]
          : "",
      currencyCode: json.containsKey("currency_code") && json["currency_code"] != null
          ? json["currency_code"]
          : "",
      contactDetails:
          json.containsKey("contact_details") && json["contact_details"] != null
              ? ContactDetails.fromJson(json["contact_details"])
              : null,
      paymentTerms:
          json.containsKey("payment_terms") && json["payment_terms"] != null
              ? PaymentTerms.fromJson(json["payment_terms"])
              : null,
      gstNo: json.containsKey("GST_No") && json["GST_No"] != null ? json["GST_No"] : "",
      taxData: json.containsKey("tax_scheme") && json["tax_scheme"] != null ? List<TaxScheme>.from(json["tax_scheme"].map((e) => TaxScheme.fromJson(e))) : []);
}

class ContactDetails {
  ContactDetails({
    this.primarycontactname,
    this.address,
  });

  String? primarycontactname;
  Address? address;

  factory ContactDetails.fromJson(Map<String, dynamic> json) => ContactDetails(
        primarycontactname: json.containsKey("primarycontactname") &&
                json["primarycontactname"] != null
            ? json["primarycontactname"]
            : json[""],
        address: json.containsKey("address") && json["address"] != null
            ? Address.fromJson(json["address"])
            : "" as Address?,
      );

  Map<String, dynamic> toJson() => {
        "primarycontactname": primarycontactname,
        "address": address!.toJson(),
      };
}

class Address {
  Address({
    this.addressformat,
    this.businesslocationnumber,
    this.buildinghousenumber,
    this.buildingstreetname,
    this.colonysectorArealocality,
    this.villagetowncity,
    this.taluk,
    this.landmark,
    this.state,
    this.district,
    this.postcode,
    this.country,
    this.buildingNo,
  });

  String? addressformat;
  String? businesslocationnumber;
  String? buildinghousenumber;
  String? buildingstreetname;
  String? colonysectorArealocality;
  String? villagetowncity;
  String? taluk;
  String? landmark;
  String? state;
  String? district;
  String? postcode;
  String? buildingNo;
  String? country;

  factory Address.fromJson(Map<String, dynamic> json) => Address(
        addressformat:
            json.containsKey("addressformat") && json["addressformat"] != null
                ? json["addressformat"]
                : "",
        businesslocationnumber: json.containsKey("businesslocationnumber") &&
                json["businesslocationnumber"] != null
            ? json["businesslocationnumber"]
            : "",
        buildinghousenumber: json.containsKey("buildinghousenumber") &&
                json["buildinghousenumber"] != null
            ? json["buildinghousenumber"]
            : "",
        buildingstreetname: json.containsKey("buildingstreetname") &&
                json["buildingstreetname"] != null
            ? json["buildingstreetname"]
            : "",
        colonysectorArealocality:
            json.containsKey("colonysector_arealocality") &&
                    json["colonysector_arealocality"] != null
                ? json["colonysector_arealocality"]
                : "",
        villagetowncity: json.containsKey("villagetowncity") &&
                json["villagetowncity"] != null
            ? json["villagetowncity"]
            : "",
        taluk: json.containsKey("taluk") && json["taluk"] != null
            ? json["taluk"]
            : "",
        landmark: json.containsKey("landmark") && json["landmark"] != null
            ? json["landmark"]
            : "",
        state: json.containsKey("state") && json["state"] != null
            ? json["state"]
            : "",
        district: json.containsKey("district") && json["district"] != null
            ? json["district"]
            : "",
        postcode: json.containsKey("postcode") && json["postcode"] != null
            ? json["postcode"]
            : "",
        country: json.containsKey("country") && json["country"] != null
            ? json["country"]
            : "",
        buildingNo:
            json.containsKey("building_no") && json["building_no"] != null
                ? json["building_no"]
                : "",
      );

  Map<String, dynamic> toJson() => {
        "addressformat": addressformat,
        "businesslocationnumber": businesslocationnumber,
        "buildinghousenumber": buildinghousenumber,
        "building_no": buildingNo,
        "buildingstreetname": buildingstreetname,
        "colonysector_arealocality": colonysectorArealocality,
        "villagetowncity": villagetowncity,
        "taluk": taluk,
        "landmark": landmark,
        "state": state,
        "district": district,
        "postcode": postcode,
        "country": country,
      };
}
