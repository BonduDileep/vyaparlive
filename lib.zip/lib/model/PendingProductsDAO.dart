import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/model/InvoiceDAO.dart';

class PendingProductsDAO {
  String? transactionId;
  num? invoiceNo;
  String? status;
  DateTime? invoiceDate;
  List<Product>? productData;
  BuyerDetails? buyerData;
  String? invoiceId;
  PendingProductsDAO(
      {this.buyerData,
      this.invoiceDate,
      this.invoiceNo,
      this.productData,
      this.status,
      this.transactionId,
      this.invoiceId});

  factory PendingProductsDAO.fromJson(Map<String, dynamic> json) =>
      PendingProductsDAO(
          buyerData: json.containsKey("buyer") && json['buyer'] != null
              ? BuyerDetails.fromJson(json['buyer'])
              : null,
          transactionId: CommonMethods.getTransactionIdFromRes(json),
          status: json.containsKey("status") && json['status'] != null
              ? json['status']
              : "",
          invoiceDate:
              json.containsKey("invoice_date") && json["invoice_date"] != null
                  ? DateTime.parse(json['invoice_date'])
                  : DateTime.now(),
          productData: json.containsKey("products") && json['products'] != null
              ? List<Product>.from(
                  json['products'].map((x) => Product.fromJson(x)))
              : [],
          invoiceNo: json.containsKey("bill_no") && json['bill_no'] != null
              ? json['bill_no']
              : 0,
          invoiceId:
              json.containsKey("id") && json['id'] != null ? json['id'] : "");

  Map<String, dynamic> toJson() => {
        "buyer": buyerData!.toJson(),
        "txnId": transactionId,
        "status": status,
        "invoice_date": invoiceDate!.toIso8601String(),
        "products": List<dynamic>.from(productData!.map((e) => e.toJson())),
        "bill_no": invoiceNo,
        'id': invoiceId
      };
}

class BuyerDetails {
  String? buId;
  String? buName;

  BuyerDetails({this.buId, this.buName});

  factory BuyerDetails.fromJson(Map<String, dynamic> json) => BuyerDetails(
      buId: json.containsKey("id") && json['id'] != null ? json['id'] : "",
      buName:
          json.containsKey("name") && json['name'] != null ? json["name"] : "");
  Map<String, dynamic> toJson() => {"id": buId, "name": buName};
}
