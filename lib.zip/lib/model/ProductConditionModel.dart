class ProductConditionModel {
  ProductConditionModel({
    this.id,
    this.name,
  });

  String? id;
  String? name;

  factory ProductConditionModel.fromJson(Map<String, dynamic> json) =>
      ProductConditionModel(
        id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
        name: json.containsKey("name") && json["name"] != null
            ? json["name"]
            : "",
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
      };
}
