import 'package:vyaparlive/model/bu_model/LocationsModel.dart';

class BuBasicDataModel {
  BuBasicDataModel(
      {this.businessName,
      this.website,
      this.headOfBusiness,
      this.location,
      this.id,
      this.city,
      this.landmark,
      this.contactNumber,
      this.locationsData,
      this.rootValue,
      this.isInpersonOrderAccept,
      this.orgCurrencySymbol,
      this.orgCountryCode,
      this.dialerCode,
      this.buFeatures});

  String? businessName;
  String? website;
  dynamic headOfBusiness;
  dynamic location;
  String? id;
  String? city;
  String? landmark;
  List<Locations>? locationsData;
  String? contactNumber;
  var rootValue;
  bool? isInpersonOrderAccept;
  String? orgCurrencySymbol;
  String? orgCountryCode;
  String? dialerCode;
  List<String>? buFeatures;
  factory BuBasicDataModel.fromJson(Map<String, dynamic> json) => BuBasicDataModel(
      businessName: json.containsKey("business_name") && json["business_name"] != null
          ? json["business_name"]
          : "",
      website: json.containsKey("website") && json["website"] != null
          ? json["website"]
          : "",
      headOfBusiness: json.containsKey("head_of_business") && json["head_of_business"] != null
          ? json["head_of_business"]
          : "",
      location: json.containsKey("location") && json["location"] != null
          ? json["location"]
          : "",
      contactNumber: json.containsKey("contact_number") && json["contact_number"] != null
          ? json["contact_number"]
          : "",
      city:
          json.containsKey("city") && json["city"] != null ? json["city"] : "",
      landmark: json.containsKey("landmark") && json["landmark"] != null
          ? json["landmark"]
          : "",
      locationsData: json.containsKey("locations") && json["locations"] != null
          ? List<Locations>.from(
              json["locations"].map((x) => Locations.fromJson(x)))
          : [],
      id: json["id"],
      rootValue:
          json.containsKey("root") && json["root"] != null ? json["root"] : "",
      isInpersonOrderAccept: json.containsKey("confirm_order") && json["confirm_order"] != null
          ? json["confirm_order"]
          : false,
      orgCurrencySymbol: json.containsKey("currency_symbol") && json["currency_symbol"] != null ? json["currency_symbol"] : "",
      orgCountryCode: json.containsKey("country_code") && json["country_code"] != null ? json["country_code"] : "",
      dialerCode: json.containsKey("dailer_code") && json["dailer_code"] != null ? json["dailer_code"] : "",
      buFeatures: json.containsKey("features") && json["features"] != null ? List<String>.from(json["features"].map((x) => x)) : []);

  Map<String, dynamic> toJson() => {
        "business_name": businessName,
        "website": website,
        "head_of_business": headOfBusiness,
        "location": location,
        "id": id,
        "contact_number": contactNumber,
        "city": city,
        "landmark": landmark,
        "locations": List<dynamic>.from(locationsData!.map((e) => e.toJson())),
        "root": rootValue,
        "confirm_order": isInpersonOrderAccept,
        "currency_symbol": orgCurrencySymbol,
        "country_code": orgCountryCode,
        "dailer_code": dialerCode,
        "features": List<dynamic>.from(buFeatures!.map((e) => e))
      };
}
