import 'package:flutter/cupertino.dart';
import 'package:vyaparlive/model/product_model/BatchPriceDAO.dart';
import 'package:vyaparlive/model/product_model/OffersDAO.dart';

class ModelProduct_v2 {
  String? id;
  String? name;
  double? counter;
  bool? isButton;
  String? images;
  num? price;
  num? quantity;
  bool isItemSelected;
  List<OffersDAO>? offerList;
  num? unitPrice;
  OffersDAO? offerData;
  bool? offerSelected;
  List<BatchPriceDAO>? batchPriceList;
  String? batchNumber;
  String? quantityIn;
  List<TextEditingController>? returnProductsController;
  List<String>? returnReasonText;
  num totalReturnProductsQuantity;
  List<num>? invoiceList;
  List<DateTime>? invoiceDate;
  List<num>? invoiceQuantity;
  bool isEditable;
  bool isCustomProduct;
  num totalPrice;
  ModelProduct_v2(
      {this.id,
      this.name,
      this.counter,
      this.isButton,
      this.images,
      this.price,
      this.quantity,
      this.isItemSelected = false,
      this.unitPrice,
      this.offerData,
      this.offerSelected = false,
      this.offerList,
      this.batchPriceList,
      this.batchNumber,
      this.quantityIn,
      this.returnProductsController,
      this.returnReasonText,
      this.totalReturnProductsQuantity = 0,
      this.invoiceDate,
      this.invoiceList,
      this.invoiceQuantity,
      this.isEditable = false,
      this.isCustomProduct = false,
      this.totalPrice = 0});

  get length => null;

  @override
  String toString() {
    return '$name'.toUpperCase() + '$name'.toLowerCase();
  }
}
