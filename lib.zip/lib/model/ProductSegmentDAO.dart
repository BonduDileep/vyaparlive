class ProductSegmentDAO {
  String? id;
  String? type;
  int? code;

  ProductSegmentDAO({this.id, this.type, this.code});

  factory ProductSegmentDAO.fromJson(Map<String, dynamic> json) =>
      ProductSegmentDAO(
          id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
          type: json.containsKey("product_segment") &&
                  json["product_segment"] != null
              ? json["product_segment"]
              : "",
          code: json.containsKey("UNSPSC_code") && json["UNSPSC_code"] != null
              ? json["UNSPSC_code"]
              : 0);

  Map<String, dynamic> toJon() =>
      {"id": id, "product_segment": type, "UNSPSC_code": code};

  /// Using for search by type in CategorySearchPage.dart and EditMyProduct.dart
  @override
  String toString() {
    return '$type'.toLowerCase() + '$type'.toUpperCase();
  }
}
