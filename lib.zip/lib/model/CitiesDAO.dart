class CitiesDAO {
  String? stateId;
  String? state;
  List<String>? cities;

  CitiesDAO({this.cities, this.state, this.stateId});

  factory CitiesDAO.fromJson(Map<String, dynamic> json) => CitiesDAO(
      stateId: json.containsKey("id") && json['id'] != null ? json['id'] : "",
      state: json.containsKey("state") && json['state'] != null
          ? json["state"]
          : "",
      cities: json.containsKey('cities') && json['cities'] != null
          ? List<String>.from(json['cities'].map((x) => x))
          : []);

  Map<String, dynamic> toJson() => {
        "id": stateId,
        "state": state,
        "cities": List<dynamic>.from(cities!.map((e) => e))
      };
}
