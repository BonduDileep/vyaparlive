class ProductLogDAO {
  String? userName;
  String? userId;
  DateTime? createdDate;
  String? type;
  String? transactionId;
  num? invoiceNumber;
  String? productId;
  String? productName;
  String? recordId;
  List<ChangesDAO>? changesList;
  DateTime? invoiceAcceptedDate;

  ProductLogDAO(
      {this.changesList,
      this.createdDate,
      this.invoiceNumber,
      this.productId,
      this.productName,
      this.recordId,
      this.transactionId,
      this.type,
      this.userId,
      this.userName,
      this.invoiceAcceptedDate});

  factory ProductLogDAO.fromJson(Map<String, dynamic> json) => ProductLogDAO(
      userId: json.containsKey('user_id') && json['user_id'] != null
          ? json['user_id']
          : '',
      userName: json.containsKey('user_name') && json['user_name'] != null
          ? json['user_name']
          : '',
      createdDate: json.containsKey('created_dt') && json['created_dt'] != null
          ? DateTime.parse(json['created_dt'])
          : null,
      type:
          json.containsKey('type') && json['type'] != null ? json['type'] : '',
      transactionId:
          json.containsKey('transaction_id') && json['transaction_id'] != null
              ? json['transaction_id']
              : '',
      invoiceNumber:
          json.containsKey('invoice_number') && json['invoice_number'] != null
              ? json['invoice_number']
              : 0,
      productId: json.containsKey('product_id') && json['product_id'] != null
          ? json['product_id']
          : '',
      productName: json.containsKey('product_name') && json['product_name'] != null
          ? json['product_name']
          : '',
      recordId: json.containsKey('id') && json['id'] != null ? json['id'] : '',
      changesList: json.containsKey('changes') && json['changes'] != null
          ? List<ChangesDAO>.from(
              json['changes'].map((x) => ChangesDAO.fromJson(x)))
          : [],
      invoiceAcceptedDate: json.containsKey('invoice_accepted_dt') &&
              json['invoice_accepted_dt'] != null
          ? DateTime.parse(json['invoice_accepted_dt'])
          : null);

  Map<String, dynamic> toJson() => {
        'user_id': userId,
        'user_n ame': userName,
        'created_dt': createdDate!.toIso8601String(),
        'type': type,
        'transaction_ id': transactionId,
        'invoice_number ': invoiceNumber,
        'prod uct_id': productId,
        'product_n ame': productName,
        'invoice_accepted_dt': invoiceAcceptedDate!.toIso8601String(),
        'id': recordId,
        'changes': List<dynamic>.from(changesList!.map((e) => e.toJson()))
      };
}

class ChangesDAO {
  String? attribute;
  var actualData;
  var updatedData;

  ChangesDAO({this.actualData, this.attribute, this.updatedData});
  factory ChangesDAO.fromJson(Map<String, dynamic> json) => ChangesDAO(
      actualData: json.containsKey('from') ? json['from'] : null,
      updatedData: json.containsKey('to') ? json['to'] : null,
      attribute: json.containsKey('attribute') && json['attribute'] != null
          ? json['attribute']
          : "");

  Map<String, dynamic> toJson() =>
      {'from': actualData, 'to': updatedData, 'attribute': attribute};
}
