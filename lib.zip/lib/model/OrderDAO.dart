import 'dart:convert';
import 'package:vyaparlive/model/TransactionsModel.dart';

OrderDAO orderDaoFromJson(String str) => OrderDAO.fromJson(json.decode(str));

String orderDaoToJson(OrderDAO data) => json.encode(data.toJson());

class OrderDAO {
  OrderDAO(
      {this.buyer,
      this.seller,
      this.orderDetails,
      this.id,
      this.transactionId});

  Buyer? buyer;
  Buyer? seller;
  OrderDetails? orderDetails;
  String? transactionId;

  String? id;

  factory OrderDAO.fromJson(Map<String, dynamic> json) => OrderDAO(
        buyer: json.containsKey("buyer") && json["buyer"] != null
            ? Buyer.fromJson(json["buyer"])
            : null,
        transactionId:
            json.containsKey("transactionId") && json['transactionId'] != null
                ? json['transactionId']
                : "",
        seller: json.containsKey("seller") && json["seller"] != null
            ? Buyer.fromJson(json["seller"])
            : null,
        orderDetails:
            json.containsKey("order_details") && json["order_details"] != null
                ? OrderDetails.fromJson(json["order_details"])
                : null,
        id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
      );

  Map<String, dynamic> toJson() => {
        "buyer": buyer!.toJson(),
        "seller": seller!.toJson(),
        "order_details": orderDetails!.toJson(),
        "id": id,
        "transactionId": transactionId
      };
}

class OrderDetails {
  OrderDetails({
    this.products,
    this.orderDate,
    this.status,
  });

  List<Product>? products;
  DateTime? orderDate;
  String? status;

  factory OrderDetails.fromJson(Map<String, dynamic> json) => OrderDetails(
        products: json.containsKey("products") && json["products"] != null
            ? List<Product>.from(
                json["products"].map((x) => Product.fromJson(x)))
            : [],
        orderDate: json.containsKey("order_date") && json["order_date"] != null
            ? DateTime.parse(json["order_date"])
            : null,
        status: json.containsKey("status") && json["status"] != null
            ? json["status"]
            : "",
      );

  Map<String, dynamic> toJson() => {
        "products": List<dynamic>.from(products!.map((x) => x.toJson())),
        "order_date": orderDate!.toIso8601String(),
        "status": status,
      };
}
