import 'package:vyaparlive/model/TransactionsModel.dart';

class DeliveryReportsDAO {
  Buyer? buyerData;
  Buyer? sellerData;
  String? transactionId;
  DateTime? createdDate;
  num? invoiceNo;
  String? stockReceivedStatus;
  String? status;
  num? invoiceAmount;
  String? deliveryStatus;
  String? invoiceId;

  DeliveryReportsDAO(
      {this.buyerData,
      this.createdDate,
      this.invoiceNo,
      this.sellerData,
      this.stockReceivedStatus,
      this.status,
      this.transactionId,
      this.invoiceAmount,
      this.deliveryStatus,
      this.invoiceId});

  factory DeliveryReportsDAO.fromJson(Map<String, dynamic> json) =>
      DeliveryReportsDAO(
          buyerData: json.containsKey("buyer") && json['buyer'] != null
              ? Buyer.fromJson(json['buyer'])
              : null,
          sellerData: json.containsKey("seller") && json['seller'] != null
              ? Buyer.fromJson(json['seller'])
              : null,
          transactionId:
              json.containsKey("transactionId") && json['transactionId'] != null
                  ? json['transactionId']
                  : "",
          invoiceNo: json.containsKey("bill_no") && json['bill_no'] != null
              ? json['bill_no']
              : 0,
          stockReceivedStatus: json.containsKey("stock_received_status") &&
                  json["stock_received_status"] != null
              ? json["stock_received_status"]
              : "",
          status: json.containsKey("status") && json['status'] != null
              ? json['status']
              : "",
          createdDate:
              json.containsKey("created_date") && json["created_date"] != null
                  ? DateTime.parse(json["created_date"])
                  : DateTime.now(),
          invoiceAmount: json.containsKey("invoice_amount") &&
                  json["invoice_amount"] != null
              ? json["invoice_amount"]
              : 0,
          deliveryStatus:
              json.containsKey("delivery_status") && json["delivery_status"] != null
                  ? json["delivery_status"]
                  : "",
          invoiceId: json.containsKey("invoice_id") && json["invoice_id"] != null
              ? json["invoice_id"]
              : "");
}
