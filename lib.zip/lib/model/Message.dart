class Message {
  Message(
      {this.bu,
      this.message,
      this.messageDate,
      this.buName,
      this.userName,
      this.orderStatus,
      this.userId,
      this.orderStatusDate,
      this.orderPlacedBy,
      this.type,
      this.buyerBu,
      this.senderBu,
      this.quotationId});

  String? bu;
  String? message;
  String? buName;
  DateTime? messageDate;
  String? userName;
  String? userId;
  String? orderStatus;
  DateTime? orderPlacedBy;
  DateTime? orderStatusDate;
  String? type;
  String? buyerBu;
  String? senderBu;
  String? quotationId;

  factory Message.fromJson(Map<String, dynamic> json) => Message(
      bu: json.containsKey("bu") && json["bu"] != null ? json["bu"] : "",
      message: json.containsKey("messages") && json["messages"] != null
          ? json["messages"]
          : "",
      messageDate:
          json.containsKey("message_date") && json["message_date"] != null
              ? DateTime.parse(json["message_date"])
              : null,
      userName: json.containsKey("user_name") && json["user_name"] != null
          ? json["user_name"]
          : "",
      buName:
          json.containsKey("name") && json["name"] != null ? json["name"] : "",
      userId: json.containsKey("user_id") && json["user_id"] != null
          ? json["user_id"]
          : "",
      orderStatus:
          json.containsKey("order_status") && json["order_status"] != null
              ? json["order_status"]
              : "",
      orderPlacedBy:
          json.containsKey("order_placed_by") && json["order_placed_by"] != null
              ? DateTime.parse(json["order_placed_by"])
              : null,
      type:
          json.containsKey("type") && json["type"] != null ? json["type"] : "",
      orderStatusDate: json.containsKey("order_status_date") &&
              json["order_status_date"] != null
          ? DateTime.parse(json["order_status_date"])
          : null,
      buyerBu: json.containsKey("buyer_bu") && json["buyer_bu"] != null
          ? json["buyer_bu"]
          : "",
      senderBu: json.containsKey("sender_bu") && json["sender_bu"] != null
          ? json["sender_bu"]
          : "",
      quotationId: json.containsKey("quotationId") && json["quotationId"] != null
          ? json["quotationId"]
          : "");

  Map<String, dynamic> toJson() => {
        "bu": bu,
        "name": buName,
        "messages": message,
        "message_date": messageDate,
        "user_name": userName,
        "user_id": userId,
        "order_status": orderStatus,
        "type": type,
        "order_placed_by": orderPlacedBy!.toIso8601String(),
        "order_status_date": orderStatusDate!.toIso8601String(),
        "sender_bu": senderBu,
        "buyer_bu": buyerBu,
        "quotationId":quotationId
      };
}
