import 'package:vyaparlive/model/TransactionsModel.dart';
import 'package:vyaparlive/model/transaction/InvoiceDetailsModel.dart';

class DistributorReportsDAO {
  String? buyer;
  String? seller;
  String? id;
  List<Product>? productList;
  num? totalSales;
  DateTime? createdDate;
  String? status;
  dynamic invoiceNumber;
  String? txnId;
  String? deliveryStatus;
  String? paymentStatus;
  InvoiceDetails? invoiceDetails;
  String? invoiceId;
  num? invoiceAmount;
  num? productPrice;
  num? productPriceWithOffer;
  num? productPriceWithTax;
  DateTime? invoiceDate;
  DistributorReportsDAO(
      {this.productList,
      this.buyer,
      this.id,
      this.seller,
      this.totalSales,
      this.createdDate,
      this.status,
      this.invoiceNumber,
      this.txnId,
      this.deliveryStatus,
      this.paymentStatus,
      this.invoiceDetails,
      this.invoiceId,
      this.invoiceAmount,
      this.productPrice,
      this.productPriceWithOffer,
      this.productPriceWithTax,
      this.invoiceDate});
  factory DistributorReportsDAO.fromJson(Map<String, dynamic> json) => DistributorReportsDAO(
      buyer: json.containsKey("Buyer") && json["Buyer"] != null
          ? json["Buyer"]
          : "",
      seller: json.containsKey("Seller") && json["Seller"] != null
          ? json["Seller"]
          : "",
      totalSales: json.containsKey("product_sales") && json["product_sales"] != null
          ? json["product_sales"]
          : 0,
      id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
      productList: json.containsKey("products") && json["products"] != null
          ? List<Product>.from(json["products"].map((x) => Product.fromJson(x)))
          : [],
      createdDate: json.containsKey("created_date") && json["created_date"] != null
          ? DateTime.parse(json["created_date"])
          : DateTime.now(),
      status: json.containsKey("status") && json["status"] != null
          ? json["status"]
          : "",
      invoiceNumber: json.containsKey("bill_no") && json["bill_no"] != null
          ? json["bill_no"]??0
          : 0,
      txnId: json.containsKey("txnId") && json["txnId"] != null
          ? json["txnId"]
          : "",
      deliveryStatus: json.containsKey("delivery_status") && json["delivery_status"] != null
          ? json["delivery_status"]
          : "",
      paymentStatus: json.containsKey("payment_status") && json["payment_status"] != null
          ? json["payment_status"]
          : "",
      invoiceDetails:
          json.containsKey("invoice_details") && json["invoice_details"] != null
              ? InvoiceDetails.fromJson(json["invoice_details"])
              : null,
      invoiceId: json.containsKey("invoice_id") && json["invoice_id"] != null
          ? json["invoice_id"]
          : "",
      invoiceAmount: json.containsKey("invoice_amout") && json["invoice_amout"] != null
          ? json["invoice_amout"]
          : 0,
      productPrice: json.containsKey("product_price") && json["product_price"] != null ? json["product_price"] : 0,
      productPriceWithOffer: json.containsKey("product_price_with_offer") && json["product_price_with_offer"] != null ? json["product_price_with_offer"] : 0,
      productPriceWithTax: json.containsKey("product_price_including_tax") && json["product_price_including_tax"] != null ? json["product_price_including_tax"] : 0,
      invoiceDate: json.containsKey("invoice_date") && json["invoice_date"] != null ? DateTime.parse(json["invoice_date"]) : null);

  Map<String, dynamic> toJson() => {
        "buyer": buyer,
        "seller": seller,
        "id": id,
        "products": List<dynamic>.from(productList!.map((e) => e)),
        "product_sales": totalSales,
        "status": status,
        "created_date": createdDate!.toIso8601String(),
        "bill_no": invoiceNumber,
        "txnId": txnId,
        "delivery_status": deliveryStatus,
        "payment_status": paymentStatus,
        "invoice_details": invoiceDetails!.toJson(),
        "invoice_id": invoiceId,
        "invoice_amout": invoiceAmount,
        "product_price_including_tax": productPriceWithTax,
        "product_price_with_offer": productPriceWithOffer,
        "product_price": productPrice,
        "invoice_date": invoiceDate!.toIso8601String()
      };
}
