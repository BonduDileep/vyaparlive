import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/model/TransactionsModel.dart';

class GSTReportDAO {
  num? invoiceCount;
  num? allRecordsCgstTotal;
  num? allRecordsSgstTotal;
  num? allRecordsIgstTotal;
  num? totalGstValues;
  List<ResultsData>? resultData;
  num? cancelledInvoicesTotal;

  GSTReportDAO(
      {this.allRecordsCgstTotal,
      this.allRecordsIgstTotal,
      this.allRecordsSgstTotal,
      this.invoiceCount,
      this.resultData,
      this.totalGstValues,
      this.cancelledInvoicesTotal});

  factory GSTReportDAO.fromJson(Map<String, dynamic> json) => GSTReportDAO(
      resultData: json.containsKey("results") && json["results"] != null
          ? List<ResultsData>.from(
              json['results'].map((x) => ResultsData.fromJson(x)))
          : [],
      allRecordsCgstTotal:
          json.containsKey("cgst_total") && json['cgst_total'] != null
              ? json['cgst_total']
              : 0,
      allRecordsIgstTotal:
          json.containsKey("igst_total") && json['igst_total'] != null
              ? json['igst_total']
              : 0,
      totalGstValues: json.containsKey("gst_total") && json["gst_total"] != null
          ? json['gst_total']
          : 0,
      allRecordsSgstTotal:
          json.containsKey("sgst_total") && json['sgst_total'] != null
              ? json['sgst_total']
              : 0,
      cancelledInvoicesTotal: json.containsKey("cancelled_invoices_count") &&
              json["cancelled_invoices_count"] != null
          ? json["cancelled_invoices_count"]
          : 0);
}

class ResultsData {
  Buyer? buyer;
  Buyer? seller;
  String? transactionId;
  dynamic invoiceNo;
  DateTime? invoiceDate;
  num? cgstTotal;
  num? sgstTotal;
  num? isgstTotal;
  num? totalGst;
  num? subTotal;
  String? invoiceId;
  String? invoiceStatus;

  ResultsData(
      {this.buyer,
      this.cgstTotal,
      this.invoiceDate,
      this.invoiceNo,
      this.isgstTotal,
      this.seller,
      this.sgstTotal,
      this.subTotal,
      this.totalGst,
      this.transactionId,
      this.invoiceId,
      this.invoiceStatus});

  factory ResultsData.fromJson(Map<String, dynamic> json) => ResultsData(
      buyer: json.containsKey("buyer") && json["buyer"] != null
          ? Buyer.fromJson(json["buyer"])
          : null,
      seller: json.containsKey("seller") && json['seller'] != null
          ? Buyer.fromJson(json['seller'])
          : null,
      invoiceDate:
          json.containsKey("invoice_date") && json["invoice_date"] != null
              ? DateTime.parse(json['invoice_date'])
              : DateTime.now(),
      transactionId: CommonMethods.getTransactionIdFromRes(json),
      invoiceNo: json.containsKey("bill_no") && json["bill_no"] != null
          ? json["bill_no"]??0
          : 0,
      subTotal: json.containsKey("sub_total") && json["sub_total"] != null
          ? json["sub_total"]
          : 0,
      cgstTotal: json.containsKey("cgst_total") && json['cgst_total'] != null
          ? json["cgst_total"]
          : 0,
      sgstTotal: json.containsKey("sgst_total") && json['sgst_total'] != null
          ? json['sgst_total']
          : 0,
      isgstTotal: json.containsKey("igst_total") && json["igst_total"] != null
          ? json['igst_total']
          : 0,
      totalGst: json.containsKey("total_gst") && json['total_gst'] != null
          ? json['total_gst']
          : 0,
      invoiceId: json.containsKey("invoice_id") && json["invoice_id"] != null
          ? json["invoice_id"]
          : "",
      invoiceStatus: json.containsKey("status") && json["status"] != null
          ? json["status"]
          : "");
}
