class AvailableTemplatesDAO {
  int? tempId;
  String? tempName;

  AvailableTemplatesDAO({this.tempName, this.tempId});

  factory AvailableTemplatesDAO.fromJson(Map<String, dynamic> json) =>
      AvailableTemplatesDAO(
          tempName:
              json.containsKey("template_name") && json["template_name"] != null
                  ? json["template_name"]
                  : "",
          tempId: json.containsKey("template_id") && json["template_id"] != null
              ? json["template_id"]
              : 0);

  Map<String, dynamic> toJson() =>
      {"template_id": tempId, "template_name": tempName};
}
