// To parse this JSON data, do
//
//     final inviteesModel = inviteesModelFromJson(jsonString);

import 'dart:convert';

InviteesModel inviteesModelFromJson(String str) =>
    InviteesModel.fromJson(json.decode(str));

String inviteesModelToJson(InviteesModel data) => json.encode(data.toJson());

class InviteesModel {
  InviteesModel({
    this.inviter,
    this.invitee,
    this.status,
    this.code,
    this.metadata,
    this.id,
  });

  Inviter? inviter;
  Invitee? invitee;
  String? status;
  String? code;
  Metadata? metadata;
  String? id;

  factory InviteesModel.fromJson(Map<String, dynamic> json) => InviteesModel(
        inviter: json.containsKey("inviter") && json["inviter"] != null
            ? Inviter.fromJson(json["inviter"])
            : null,
        invitee: json.containsKey("invitee") && json["invitee"] != null
            ? Invitee.fromJson(json["invitee"])
            : null,
        status: json.containsKey("status") && json["status"] != null
            ? json["status"]
            : "",
        code: json.containsKey("code") && json["code"] != null
            ? json["code"]
            : "",
        metadata: json.containsKey("@metadata") && json["@metadata"] != null
            ? Metadata.fromJson(json["@metadata"])
            : null,
        id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
      );

  Map<String, dynamic> toJson() => {
        "inviter": inviter!.toJson(),
        "invitee": invitee!.toJson(),
        "status": status,
        "code": code,
        "@metadata": metadata!.toJson(),
        "id": id,
      };
}

class Invitee {
  Invitee(
      {this.emailId,
      this.contact,
      this.companyName,
      this.relation,
      this.acceptedDateTime,
      // this.supplier,
      // this.buyer,
      this.countryCode});

  String? emailId;
  String? contact;
  String? companyName;
  String? relation;
  DateTime? acceptedDateTime;
  // bool supplier;
  // bool buyer;
  String? countryCode;

  factory Invitee.fromJson(Map<String, dynamic> json) => Invitee(
      emailId: json.containsKey("email_id") && json["email_id"] != null
          ? json["email_id"]
          : "",
      contact: json.containsKey("contact") && json["contact"] != null
          ? json["contact"]
          : "",
      companyName:
          json.containsKey("company_name") && json["company_name"] != null
              ? json["company_name"]
              : "",
      relation: json.containsKey("relation") && json["relation"] != null
          ? json["relation"]
          : "",
      acceptedDateTime: json.containsKey("accepted_date_time") &&
              json["accepted_date_time"] != null &&
              json["accepted_date_time"] != ""
          ? DateTime.parse(json["accepted_date_time"])
          : null,
      // supplier: json["supplier"],
      // buyer: json["buyer"],
      countryCode:
          json.containsKey("country_code") && json["country_code"] != null
              ? json["country_code"]
              : "");

  Map<String, dynamic> toJson() => {
        "email_id": emailId,
        "contact": contact,
        "company_name": companyName,
        "relation": relation,
        "accepted_date_time": acceptedDateTime!.toIso8601String(),
        // "supplier": supplier,
        // "buyer": buyer,
        "country_code": countryCode
      };
}

class Inviter {
  Inviter(
      {this.inviteCompany,
      this.contactPerson,
      this.contact,
      this.businessRelation,
      this.url,
      this.invitedDateTime,
      // this.supplier,
      // this.buyer,
      this.inviteCompanyName});

  dynamic inviteCompany;
  String? contactPerson;
  String? inviteCompanyName;
  String? contact;
  String? businessRelation;
  String? url;
  DateTime? invitedDateTime;
  // bool supplier;
  // bool buyer;

  factory Inviter.fromJson(Map<String, dynamic> json) => Inviter(
      inviteCompany: json["invite_company"],
      contactPerson: json["contact_person"],
      contact: json["contact"],
      businessRelation: json["business_relation"],
      url: json["url"],
      invitedDateTime: json.containsKey("invited_date_time") &&
              json["invited_date_time"] != null &&
              json["invited_date_time"] != ""
          ? DateTime.parse(json["invited_date_time"])
          : null,
      // supplier: json["supplier"],
      // buyer: json["buyer"],
      inviteCompanyName: json.containsKey("invite_company_name")
          ? json["invite_company_name"]
          : "");

  Map<String, dynamic> toJson() => {
        "invite_company": inviteCompany,
        "contact_person": contactPerson,
        "contact": contact,
        "business_relation": businessRelation,
        "url": url,
        "invited_date_time": invitedDateTime!.toIso8601String(),
        // "supplier": supplier,
        // "buyer": buyer,
      };
}

class Metadata {
  Metadata({
    this.collection,
    this.nestedObjectTypes,
    this.ravenNodeType,
    this.changeVector,
    this.id,
    this.indexScore,
    this.lastModified,
  });

  String? collection;
  NestedObjectTypes? nestedObjectTypes;
  dynamic ravenNodeType;
  String? changeVector;
  String? id;
  double? indexScore;
  DateTime? lastModified;

  factory Metadata.fromJson(Map<String, dynamic> json) => Metadata(
        collection: json["@collection"],
        lastModified: DateTime.parse(json["@last-modified"]),
      );

  Map<String, dynamic> toJson() => {
        "@collection": collection,
        "@last-modified": lastModified!.toIso8601String(),
      };
}

class NestedObjectTypes {
  NestedObjectTypes();

  factory NestedObjectTypes.fromJson(Map<String, dynamic> json) =>
      NestedObjectTypes();

  Map<String, dynamic> toJson() => {};
}
