import 'RawProductsIssueDAO.dart';

class RawMaterialIOReportDAO {
  String? id;
  int? count;
  String? productName;
  List<FinalProduct>? finalProduct;
  int? usedQuantity;
  String? quantityIn;

  RawMaterialIOReportDAO(
      {this.id,
      this.count,
      this.productName,
      this.finalProduct,
      this.usedQuantity,
      this.quantityIn});

  factory RawMaterialIOReportDAO.fromJson(Map<String, dynamic> json) =>
      RawMaterialIOReportDAO(
          id: json.containsKey("_id") && json["_id"] != null ? json["_id"] : "",
          count: json.containsKey("count") && json["count"] != null
              ? json["count"]
              : 0,
          productName:
              json.containsKey("product_name") && json["product_name"] != null
                  ? json["product_name"]
                  : "",
          finalProduct: json.containsKey("final_product") &&
                  json["final_product"] != null
              ? List<FinalProduct>.from(
                  json["final_product"].map((x) => FinalProduct.fromJson(x)))
              : null,
          usedQuantity:
              json.containsKey("used_quantity") && json["used_quantity"] != null
                  ? json["used_quantity"]
                  : 0,
          quantityIn:
              json.containsKey("quantity_in") && json["quantity_in"] != null
                  ? json["quantity_in"]
                  : "");

  Map<String, dynamic> toJson() => {
        "_id": id,
        "count": count,
        "product_name": productName,
        "final_product": finalProduct,
        "used_quantity": usedQuantity,
        "quantity_in": quantityIn
      };
}
