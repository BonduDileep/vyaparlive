class ExpensesDAO {
  String? expId;
  String? expenseType;
  num? expenseAmount;
  String? expenseDescription;
  String? id;
  String? expensesId;
  String? expensesDate;
  ExpensesDAO(
      {this.expenseAmount,
      this.expenseDescription,
      this.expenseType,
      this.id,
      this.expensesDate,
      this.expensesId,
      this.expId});

  factory ExpensesDAO.fromJson(Map<String, dynamic> json) => ExpensesDAO(
      expId: json.containsKey("_id") && json["_id"] != null ? json["_id"] : "",
      expenseType:
          json.containsKey("expense_type") && json["expense_type"] != null
              ? json["expense_type"]
              : "",
      expenseAmount: (() {
        final val = json["expense_amount"];
        if (val == null) return 0;
        if (val is num) return val; // int or double
        if (val is String) {
          return num.tryParse(val) ?? 0;
        }
        return 0;
      })(),
      expenseDescription: json.containsKey("expense_description") &&
              json["expense_description"] != null
          ? json["expense_description"]
          : "",
      expensesDate:
          json.containsKey("expense_date") && json["expense_date"] != null
              ? json["expense_date"]
              : "",
      expensesId: json.containsKey("expense_id") && json["expense_id"] != null
          ? json["expense_id"]
          : "",
      id: json.containsKey("id") && json["id"] != null ? json["id"] : "");

  Map<String, dynamic> toJson() => {
        "id": id,
        "expense_type": expenseType,
        "expense_amount": expenseAmount,
        "expense_description": expenseDescription,
        "expense_date": expensesDate,
        "expense_id": expensesId
      };
}

class ExpensesModel {
  String? buName;
  String? buId;
  List<ExpensesDAO>? expensesList;
  ExpensesModel({this.buId, this.expensesList, this.buName});

  factory ExpensesModel.fromJson(Map<String, dynamic> json) => ExpensesModel(
      buId: json.containsKey("id") && json["id"] != null ? json["id"] : "",
      buName: json.containsKey("business_name") && json["business_name"] != null
          ? json["business_name"]
          : "",
      expensesList: json.containsKey("expenses") && json["expenses"] != null
          ? List<ExpensesDAO>.from(
              json["expenses"].map((e) => ExpensesDAO.fromJson(e)))
          : []);
}
