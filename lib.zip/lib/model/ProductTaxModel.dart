class ProductTaxModel {
  ProductTaxModel({
    this.type,
    this.value,
    this.id,
  });

  String? type;
  String? value;
  String? id;

  factory ProductTaxModel.fromJson(Map<String, dynamic> json) =>
      ProductTaxModel(
        type: json.containsKey("type") && json["type"] != null
            ? json["type"]
            : "",
        value: json.containsKey("value") && json["value"] != null
            ? json["value"]
            : "",
        id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
      );

  Map<String, dynamic> toJson() => {
        "type": type,
        "value": value,
        "id": id,
      };
}
