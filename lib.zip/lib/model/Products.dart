class Products {
  String productname;
  int id;
  int counter;
  bool isButton;
  String productImage;
  int price;
  int quantity;
  String category;
  String date;
  String orderfrom;
//  String orderfrom;
  int batchOneQuantity;
  int batchTwoQuantity;
  int batchThreeQuantity;
  int batchOnePrice;
  int batchTwoPrice;
  int batchThreePrice;
  String productQuality;
  Products(
      this.id,
      this.productname,
      this.counter,
      this.isButton,
      this.productImage,
      this.price,
      this.quantity,
      this.category,
      this.date,
      this.orderfrom,
      this.batchOneQuantity,
      this.batchTwoQuantity,
      this.batchThreeQuantity,
      this.batchOnePrice,
      this.batchTwoPrice,
      this.batchThreePrice,
      this.productQuality);
}
