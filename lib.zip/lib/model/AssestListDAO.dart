import 'package:vyaparlive/model/AssetsGroupModel.dart';
import 'package:vyaparlive/model/product_model/BatchPriceDAO.dart';
import 'package:vyaparlive/model/product_model/ImageUrl.dart';
import 'package:vyaparlive/model/product_model/InventoryDetailsDAO.dart';

class AssetsListDAO {
  String? buId;
  String? name;
  String? description;
  String? purchasedDate;
  UsefulLifeDuration? usefulLifeDuration;
  String? usefulLifeRemaining;
  num? netCost;
  String? depreciationPercentage;
  num? depreciationExpenses;
  bool? isLiability;
  bool? isScrap;
  String? scrapDeclaredDate;
  bool? isDisposed;
  String? disposedDate;
  String? disposedValue;
  AssetsGroupModel? groupDetails;
  String? id;
  String? brand;
  List? attributesList;
  List<InventoryDetailsDAO>? inventoryData;
  List<BatchPriceDAO>? batchPrice;
  QuantityDetails? quantityDetails;
  List<ImageUrl>? imageUrl;
  String? invoiceAttachment;
  List<ImageUrl>? invoiceAttachementUrl;

  AssetsListDAO(
      {this.buId,
      this.depreciationExpenses,
      this.depreciationPercentage,
      this.description,
      this.disposedDate,
      this.disposedValue,
      this.isDisposed,
      this.isLiability,
      this.isScrap,
      this.name,
      this.purchasedDate,
      this.scrapDeclaredDate,
      this.usefulLifeDuration,
      this.usefulLifeRemaining,
      this.netCost,
      this.groupDetails,
      this.id,
      this.brand,
      this.attributesList,
      this.batchPrice,
      this.inventoryData,
      this.quantityDetails,
      this.imageUrl,
      this.invoiceAttachment,
      this.invoiceAttachementUrl});

  factory AssetsListDAO.fromJson(Map<String, dynamic> json) => AssetsListDAO(
      buId: json.containsKey("bu_id") && json["bu_id"] != null
          ? json["bu_id"]
          : "",
      depreciationExpenses: json.containsKey("depreciation_expense") &&
              json["depreciation_expense"] != null
          ? json["depreciation_expense"]
          : "" as num?,
      depreciationPercentage:
          json.containsKey("depreciation_percent") && json["depreciation_percent"] != null
              ? json["depreciation_percent"]
              : "",
      description: json.containsKey("description") && json["description"] != null
          ? json["description"]
          : "",
      disposedDate: json.containsKey("disposed_date") && json["disposed_date"] != null
          ? json["disposed_date"]
          : "",
      disposedValue: json.containsKey("disposed_value") && json["disposed_value"] != null
          ? json["disposed_value"]
          : "",
      isDisposed: json.containsKey("disposed") && json["disposed"] != null
          ? json["disposed"]
          : false,
      isLiability: json.containsKey("is_liability") && json["is_liability"] != null
          ? json["is_liability"]
          : false,
      isScrap: json.containsKey("is_scrap") && json["is_scrap"] != null ? json["is_scrap"] : false,
      name: json.containsKey("name") && json["name"] != null ? json["name"] : "",
      purchasedDate: json.containsKey("purchased_date") && json["purchased_date"] != null ? json["purchased_date"] : "",
      scrapDeclaredDate: json.containsKey("scrap_declared_date") && json["scrap_declared_date"] != null ? json["scrap_declared_date"] : "",
      usefulLifeDuration: json.containsKey('useful_life_duration') && json["useful_life_duration"] != null ? UsefulLifeDuration.fromJson(json["useful_life_duration"]) : "" as UsefulLifeDuration?,
      usefulLifeRemaining: json.containsKey("useful_life_remaining") && json["useful_life_remaining"] != null ? json["useful_life_remaining"] : "",
      netCost: json.containsKey("net_cost") && json["net_cost"] != null ? json["net_cost"] : 0,
      groupDetails: json.containsKey("group") && json["group"] != null ? AssetsGroupModel.fromJson(json["group"]) : null,
      id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
      brand: json.containsKey("brand") && json["brand"] != null ? json["brand"] : "",
      batchPrice: json.containsKey("batch_pricing") && json["batch_pricing"] != null ? List<BatchPriceDAO>.from(json["batch_pricing"].map((e) => BatchPriceDAO.fromJson(e))) : [],
      inventoryData: json.containsKey("inventory_management") && json["inventory_management"] != null ? List<InventoryDetailsDAO>.from(json["inventory_management"].map((x) => InventoryDetailsDAO.fromJson(x))) : [],
      attributesList: json.containsKey("attributes") && json["attributes"] != null ? List.from(json["attributes"].map((x) => x)) : [],
      quantityDetails: json.containsKey("quantity_details") && json["quantity_details"] != null ? QuantityDetails.fromJson(json["quantity_details"]) : null,
      imageUrl: json.containsKey("image_dps") && json["image_dps"] != null ? List<ImageUrl>.from(json["image_dps"].map((e) => ImageUrl.fromJson(e))) : [],
      invoiceAttachment: json.containsKey("invoice_attachment") && json["invoice_attachment"] != null ? json["invoice_attachment"] : "",
      invoiceAttachementUrl: json.containsKey("imageAttachmentDps") && json["imageAttachmentDps"] != null ? List<ImageUrl>.from(json["imageAttachmentDps"].map((e) => ImageUrl.fromJson(e))) : []);

  Map<String, dynamic> toJson() => {
        "bu_id": buId,
        "name": name,
        "description": description,
        "group": groupDetails!.toJson(),
        "image": "",
        "purchased_date": purchasedDate,
        "useful_life_duration": usefulLifeDuration!.toJso(),
        "useful_life_remaining": usefulLifeRemaining,
        "net_cost": netCost,
        "depreciation_percent": depreciationPercentage,
        "depreciation_expense": depreciationExpenses,
        "is_liability": isLiability,
        "is_scrap": isScrap,
        "scrap_declared_date": scrapDeclaredDate,
        "disposed": isDisposed,
        "disposed_date": disposedDate,
        "disposed_value": disposedValue,
        "id": id,
        "brand": brand,
        "inventory_management":
            List<dynamic>.from(inventoryData!.map((e) => e.toJson())),
        "batch_pricing": List<dynamic>.from(batchPrice!.map((e) => e.toJson())),
        "quantity_details": quantityDetails!.toJson(),
        "image_dps": List<dynamic>.from(imageUrl!.map((e) => e.toString())),
        "invoice_attachment": invoiceAttachment,
        "imageAttachmentDps":
            List<dynamic>.from(invoiceAttachementUrl!.map((e) => e.toString())),
      };
}

class UsefulLifeDuration {
  String? year;
  String? month;

  UsefulLifeDuration({this.month, this.year});

  factory UsefulLifeDuration.fromJson(Map<String, dynamic> json) =>
      UsefulLifeDuration(
          year: json.containsKey("year") && json["year"] != null
              ? json["year"]
              : "",
          month: json.containsKey("month") && json["month"] != null
              ? json["month"]
              : "");

  Map<String, dynamic> toJso() => {"year": year, "month": month};
}

class QuantityDetails {
  num? quantity;
  String? quantityIn;

  QuantityDetails({this.quantity, this.quantityIn});

  factory QuantityDetails.fromJson(Map<String, dynamic> json) =>
      QuantityDetails(
          quantity: json.containsKey("quantity") && json["quantity"] != null
              ? json["quantity"]
              : 0,
          quantityIn:
              json.containsKey("quantity_in") && json["quantity_in"] != null
                  ? json["quantity_in"]
                  : "");

  Map<String, dynamic> toJson() =>
      {"quantity": quantity, "quantity_in": quantityIn};
}
