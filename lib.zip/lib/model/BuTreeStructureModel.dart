class BuTreeStructureModel {
  bool? selectFirstStep = false;
  bool? selectSecondStep = false;
  String? buId;
  String? buName;
  String? buLocation;
  String? buAdmin;
  String? buPhoneNumber;
  List<Children>? children;

  BuTreeStructureModel(
      {this.selectFirstStep,
      this.selectSecondStep,
      this.buName,
      this.children,
      this.buId});

  factory BuTreeStructureModel.fromJson(Map<String, dynamic> json) =>
      BuTreeStructureModel(
          buId: json.containsKey("bu_id") && json['bu_id'] != null
              ? json['bu_id']
              : "",
          buName:
              json.containsKey("business_name") && json['business_name'] != null
                  ? json['business_name']
                  : "",
          children: json.containsKey("children") && json["children"] != null
              ? List<Children>.from(
                  json["children"].map((x) => Children.fromJson(x)))
              : [],
          selectFirstStep: false,
          selectSecondStep: false);

  Map<String, dynamic> toJson() => {
        "bu_id": buId,
        "children": List<dynamic>.from(children!.map((x) => x.toJson())),
        "business_name": buName
      };
}

class Children {
  String? buId;
  String? buName;
  List<Children>? children;
  Children({this.buId, this.buName, this.children});
  factory Children.fromJson(Map<String, dynamic> json) => Children(
      buId: json.containsKey("bu_id") && json['bu_id'] != null
          ? json['bu_id']
          : "",
      buName: json.containsKey("business_name") && json['business_name'] != null
          ? json['business_name']
          : "",
      children: json.containsKey("children") && json['children'] != null
          ? List<Children>.from(
              json['children'].map((x) => Children.fromJson(x)))
          : []);

  Map<String, dynamic> toJson() => {
        "bu_id": buId,
        "children": List<dynamic>.from(children!.map((x) => x.toJson())),
        "business_name": buName
      };
}
