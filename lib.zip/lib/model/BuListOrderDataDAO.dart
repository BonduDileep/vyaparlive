import 'package:vyaparlive/model/TransactionsModel.dart';
import 'package:vyaparlive/model/transaction/InvoiceDetailsModel.dart';

class BuListOrderDataDAO {
  Buyer? buyer;
  Buyer? seller;
  dynamic invoiceNumber;
  InvoiceDetails? invoiceDetails;
  String? txnId;
  String? invoiceId;

  BuListOrderDataDAO(
      {this.buyer,
      this.invoiceDetails,
      this.invoiceNumber,
      this.txnId,
      this.seller,
      this.invoiceId});

  factory BuListOrderDataDAO.fromJson(Map<String, dynamic> json) =>
      BuListOrderDataDAO(
          buyer: json.containsKey("buyer") && json["buyer"] != null
              ? Buyer.fromJson(json["buyer"])
              : null,
          seller: json.containsKey("seller") && json["seller"] != null
              ? Buyer.fromJson(json["seller"])
              : null,
          invoiceDetails: json.containsKey("invoice_details") &&
                  json["invoice_details"] != null
              ? InvoiceDetails.fromJson(json["invoice_details"])
              : null,
          txnId:
              json.containsKey("transactionId") && json["transactionId"] != null
                  ? json["transactionId"]
                  : "",
          invoiceNumber: json.containsKey("invoice_number") &&
                  json["invoice_number"] != null
              ? json["invoice_number"]??0
              : 0,
          invoiceId:
              json.containsKey("id") && json["id"] != null ? json["id"] : "");

  Map<String, dynamic> toJson() => {
        "buyer": buyer.toString(),
        "seller": seller.toString(),
        "invoice_details": invoiceDetails.toString(),
        "transactionId": txnId,
        "invoice_number": invoiceNumber,
        "id": invoiceId
      };
}
