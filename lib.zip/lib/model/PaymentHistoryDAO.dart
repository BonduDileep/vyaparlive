import 'package:vyaparlive/components/common_methods.dart';

class PaymentHistoryDAO {
  num? orderNumber;
  String? payerVpa;
  num? amount;
  String? buId;
  String? buName;
  String? userId;
  String? userName;
  String? contactNumber;
  DateTime? userReqDate;
  DateTime? upiReqDate;
  DateTime? upiResDate;
  String? userReqData;
  String? status;
  num? cgst;
  num? sgst;
  num? igst;
  String? invoiceId;
  PaymentHistoryDAO(
      {this.amount,
      this.buId,
      this.buName,
      this.contactNumber,
      this.orderNumber,
      this.payerVpa,
      this.status,
      this.upiReqDate,
      this.upiResDate,
      this.userId,
      this.userName,
      this.userReqData,
      this.userReqDate,
      this.cgst,
      this.igst,
      this.sgst,
      this.invoiceId});

  factory PaymentHistoryDAO.fromJson(Map<String, dynamic> json) => PaymentHistoryDAO(
      amount: json.containsKey("amount") && json["amount"] != null
          ? json["amount"]
          : 0,
      buId: json.containsKey("bu") && json['bu'] != null ? json['bu'] : "",
      buName: json.containsKey("bu_name") && json["bu_name"] != null
          ? json["bu_name"]
          : "",
      contactNumber: json.containsKey("contact_num") && json["contact_num"] != null
          ? json["contact_num"]
          : "",
      orderNumber: json.containsKey("order_num") && json["order_num"] != null
          ? json["order_num"]
          : 0,
      payerVpa: json.containsKey("payer_vpa") && json['payer_vpa'] != null
          ? json['payer_vpa']
          : "",
      status: json.containsKey("status") && json["status"] != null
          ? json["status"]
          : "",
      upiReqDate: json.containsKey("upi_requested_dt_time") && json["upi_requested_dt_time"] != null
          ? DateTime.parse(json["upi_requested_dt_time"])
          : null,
      upiResDate: json.containsKey("upi_response_dt_time") && json["upi_response_dt_time"] != null
          ? DateTime.parse(json["upi_response_dt_time"])
          : null,
      userId: json.containsKey("user_id") && json["user_id"] != null
          ? json["user_id"]
          : "",
      userName: json.containsKey("user_name") && json['user_name'] != null
          ? json['user_name']
          : "",
      userReqDate: json.containsKey("user_requested_dt_time") &&
              json["user_requested_dt_time"] != null
          ? DateTime.parse(json["user_requested_dt_time"])
          : null,
      userReqData: json.containsKey("user_req_data") && json["user_req_data"] != null
          ? json["user_req_data"]
          : "",
      cgst: json.containsKey("cgst") && json["cgst"] != null ? json["cgst"] : 0,
      sgst: json.containsKey("sgst") && json["sgst"] != null ? json["sgst"] : 0,
      igst: json.containsKey("igst") && json["igst"] != null ? json["igst"] : 0,
      invoiceId: CommonMethods.getInvoiceIdFromRes(json));

  Map<String, dynamic> toJson() => {
        "amount": amount,
        "bu": buId,
        "bu_name": buName,
        "contact_num": contactNumber,
        "order_num": orderNumber,
        "status": status,
        "user_requested_dt_time": userReqDate,
        "igst": igst,
        "cgst": cgst,
        "sgst": sgst,
      };
}
