class ProductIssueDetailsModel {
  String? issuedDate;
  String? issuedTo;
  String? purpose;
  String? approvedBy;
  String? issuedQuantity;
  String? batchNumber;
  num? remaingQuantity;
  String? department;

  ProductIssueDetailsModel(
      {this.approvedBy,
      this.issuedDate,
      this.issuedQuantity,
      this.issuedTo,
      this.purpose,
      this.batchNumber,
      this.remaingQuantity,this.department});
}
