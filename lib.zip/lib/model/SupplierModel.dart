class SupplierModel {
  String? name;
  String? id;
  String? city;
  String? district;
  String? locality;
  String? contact;
  SupplierModel(
      {this.id,
      this.name,
      this.city,
      this.district,
      this.locality,
      this.contact});
}
