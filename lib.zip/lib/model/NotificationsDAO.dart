import 'package:vyaparlive/model/TransactionsModel.dart';

class NotificationsDAO {
  NotificationsDAO(
      {this.buyer,
      this.id,
      this.message,
      this.seller,
      this.transactionId,
      this.notificationType,
      this.createdDate});

  Buyer? buyer;
  Buyer? seller;
  String? message;
  String? id;
  String? transactionId;
  DateTime? createdDate;
  String? notificationType;

  factory NotificationsDAO.fromJson(Map<String, dynamic> json) =>
      NotificationsDAO(
        buyer: json.containsKey("buyer") && json["buyer"] != null
            ? Buyer.fromJson(json["buyer"])
            : null,
        seller: json.containsKey("seller") && json["seller"] != null
            ? Buyer.fromJson(json["seller"])
            : null,
        message: json.containsKey("message") && json["message"] != null
            ? json["message"]
            : "",
        notificationType: json.containsKey("notification_type") &&
                json["notification_type"] != null
            ? json["notification_type"]
            : "",
        id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
        transactionId:
            json.containsKey("transaction_id") && json["transaction_id"] != null
                ? json["transaction_id"]
                : "",
        createdDate:
            json.containsKey("created_date") && json["created_date"] != null
                ? DateTime.parse(json["created_date"])
                : null,
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "transaction_id": transactionId,
        "message": message,
        "buyer": buyer!.toJson(),
        "seller": seller!.toJson(),
        "created_date": createdDate, //.toIso8601String(),
        "notification_type": notificationType
      };
}
