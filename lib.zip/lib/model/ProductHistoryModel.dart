import 'package:vyaparlive/model/TransactionsModel.dart';
import 'package:vyaparlive/model/product_model/OffersDAO.dart';

class ProductHistoryModel {
  Buyer? buyer;
  Buyer? seller;
  String? id;
  dynamic billNo;
  String? productName;
  String? quantity;
  String? totalPrice;
  DateTime? createdDate;
  DateTime? invocieDate;
  InvoiceProducts? productData;
  String? transactionId;
  String? invoiceStatus;
  num? invoiceAmount;
  String? deliveryStatus;
  String? paymentStatus;
  String? invoiceId;
  List<InvoiceProducts>? invoiceProductList;
  num? totalProductQuantity;
  ProductHistoryModel(
      {this.billNo,
      this.buyer,
      this.id,
      this.productName,
      this.quantity,
      this.seller,
      this.createdDate,
      this.totalPrice,
      this.invocieDate,
      this.productData,
      this.transactionId,
      this.invoiceStatus,
      this.invoiceAmount,
      this.deliveryStatus,
      this.paymentStatus,
      this.invoiceId,
      this.invoiceProductList,
      this.totalProductQuantity});

  factory ProductHistoryModel.fromJson(Map<String, dynamic> json) =>
      ProductHistoryModel(
        transactionId:
            json.containsKey("transactionId") && json['transactionId'] != null
                ? json['transactionId']
                : "",
        billNo:
            json.containsKey("invoice_number") && json["invoice_number"] != null
                ? json["invoice_number"]??0
                : 0,
        buyer: json.containsKey("buyer") && json["buyer"] != null
            ? Buyer.fromJson(json["buyer"])
            : null,
        seller: json.containsKey("seller") && json["seller"] != null
            ? Buyer.fromJson(json["seller"])
            : null,
        id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
        productName:
            json.containsKey("product_name") && json["product_name"] != null
                ? json["product_name"]
                : "",
        productData: json.containsKey("product")
            ? InvoiceProducts.fromJson(json["product"])
            : null,
        quantity: json.containsKey("quantity") && json["quantity"] != null
            ? json["quantity"]
            : "",
        createdDate:
            json.containsKey("created_date") && json["created_date"] != null
                ? DateTime.parse(json["created_date"])
                : DateTime.now(),
        invocieDate:
            json.containsKey("invoice_date") && json["invoice_date"] != null
                ? DateTime.parse(json["invoice_date"])
                : DateTime.now(),
        totalPrice:
            json.containsKey('total_price') && json["total_price"] != null
                ? json["total_price"]
                : "",
        invoiceStatus: json.containsKey("status") && json["status"] != null
            ? json["status"]
            : "",
        invoiceAmount:
            json.containsKey("invoice_amount") && json["invoice_amount"] != null
                ? json["invoice_amount"]
                : 0,
        deliveryStatus: json.containsKey("delivery_status") &&
                json["delivery_status"] != null
            ? json["delivery_status"]
            : "",
        paymentStatus:
            json.containsKey("payment_status") && json["payment_status"] != null
                ? json["payment_status"]
                : "",
        invoiceId: json.containsKey("invoice_id") && json["invoice_id"] != null
            ? json["invoice_id"]
            : "",
        invoiceProductList:
            json.containsKey("products") && json["products"] != null
                ? List<InvoiceProducts>.from(
                    json["products"].map((i) => InvoiceProducts.fromJson(i)))
                : [],
        totalProductQuantity: json.containsKey("product_quantity_total") &&
                json["product_quantity_total"] != null
            ? json["product_quantity_total"]
            : 0,
      );
}

class InvoiceProducts {
  InvoiceProducts(
      {this.id,
      this.quantity,
      this.unitPrice,
      this.total,
      this.productName,
      this.gst,
      this.gstValue,
      this.offerData,
      this.subTotal,
      this.unitPriceWithOffer,
      this.taxType,
      this.totalPrice,
      this.totalTax,
      this.cgst,
      this.cgstValue,
      this.sgst,
      this.subTotalWithoutOffer,
      this.sgstValue,
      this.productImage,
      this.gstTotal,
      this.offerAmount,
      this.productAmountTotal,
      this.productCost,
      this.productTotalOffer,
      this.batchNumber});

  String? id;
  num? quantity;
  num? total;
  num? unitPrice;
  String? productName;
  String? productImage;
  String? taxType;
  OffersDAO? offerData;
  num? unitPriceWithOffer;
  num? totalTax;
  num? subTotal;
  num? subTotalWithoutOffer;
  num? totalPrice;
  num? gstValue;
  dynamic gst;
  num? cgst;
  num? sgst;
  num? cgstValue;
  num? sgstValue;

  num? gstTotal;
  num? productCost;
  num? offerAmount;
  num? productTotalOffer;
  num? productAmountTotal;
  String? batchNumber;

  factory InvoiceProducts.fromJson(Map<String, dynamic> json) =>
      InvoiceProducts(
        id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
        quantity: json.containsKey("quantity") && json["quantity"] != null
            ? json["quantity"]
            : 0,
        unitPrice: json.containsKey("unit_price") && json["unit_price"] != null
            ? json["unit_price"]
            : 0,
        total: json.containsKey("total") && json["total"] != null
            ? json["total"]
            : 0,
        subTotalWithoutOffer: json.containsKey("sub_total_without_offer") &&
                json["sub_total_without_offer"] != null
            ? json["sub_total_without_offer"]
            : 0,
        productName:
            json.containsKey("product_name") && json["product_name"] != null
                ? json["product_name"]
                : "",
        gst: json.containsKey("gst") && json["gst"] != null ? json["gst"] : 0,
        offerData: json.containsKey("offer") && json["offer"] != null
            ? OffersDAO.fromJson(json["offer"])
            : null,
        taxType: json.containsKey("tax_type") && json["tax_type"] != null
            ? json["tax_type"]
            : "",
        unitPriceWithOffer: json.containsKey("unit_price_with_offer") &&
                json["unit_price_with_offer"] != null
            ? json["unit_price_with_offer"]
            : 0,
        totalTax: json.containsKey("total_tax") && json["total_tax"] != null
            ? json["total_tax"]
            : 0,
        subTotal: json.containsKey("sub_total") && json["sub_total"] != null
            ? json["sub_total"]
            : 0,
        totalPrice:
            json.containsKey("total_price") && json["total_price"] != null
                ? json["total_price"]
                : 0,
        gstValue: json.containsKey("gst_value") && json["gst_value"] != null
            ? json["gst_value"]
            : 0,
        cgst:
            json.containsKey("cgst") && json["cgst"] != null ? json["cgst"] : 0,
        sgst:
            json.containsKey("sgst") && json["sgst"] != null ? json["sgst"] : 0,
        cgstValue: json.containsKey("cgst_value") && json["cgst_value"] != null
            ? json["cgst_value"]
            : 0,
        sgstValue: json.containsKey("sgst_value") && json["sgst_value"] != null
            ? json["sgst_value"]
            : 0,
        productImage:
            json.containsKey("product_image") && json['product_image'] != null
                ? json['product_image']
                : "",
        productCost:
            json.containsKey("product_cost") && json["product_cost"] != null
                ? json["product_cost"]
                : 0,
        gstTotal: json.containsKey("gst_total") && json["gst_total"] != null
            ? json["gst_total"]
            : 0,
        offerAmount:
            json.containsKey("offer_amount") && json["offer_amount"] != null
                ? json["offer_amount"]
                : 0,
        productAmountTotal: json.containsKey("product_amount_total") &&
                json["product_amount_total"] != null
            ? json["product_amount_total"]
            : 0,
        productTotalOffer: json.containsKey("product_total_offer") &&
                json["product_total_offer"] != null
            ? json["product_total_offer"]
            : 0,
        batchNumber:
            json.containsKey("batch_number") && json["batch_number"] != null
                ? json["batch_number"]
                : "",
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "quantity": quantity,
        "unit_price": unitPrice,
        "total": total,
        "product_name": productName,
        "product_image": productImage,
        "gst": gst,
        "offer": offerData,
        "tax_type": taxType,
        "unit_price_with_offer": unitPriceWithOffer,
        "total_tax": totalTax,
        "sub_total": subTotal,
        "total_price": totalPrice,
        "gst_value": gstValue,
        "cgst": cgst,
        "sgst": sgst,
        "cgst_value": cgstValue,
        "sgst_value": sgstValue,
        "product_total_offer": productTotalOffer,
        "product_amount_total": productAmountTotal,
        "offer_amount": offerAmount,
        "gst_total": gstTotal,
        "product_cost": productCost,
        "batch_number": batchNumber,
      };
}
