class ProductAttributeModel {
  String? attributeValue;
  String? attributeKey;

  ProductAttributeModel({this.attributeValue, this.attributeKey});
}
