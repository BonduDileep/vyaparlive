import 'package:vyaparlive/model/TransactionsModel.dart';
import 'package:vyaparlive/model/transaction/DeliveryDetailsModel.dart';

class StockDeliveryDAO {
  Buyer? buyer;
  Buyer? seller;
  dynamic invoiceNo;
  String? invoiceId;
  DateTime? invoiceDate;
  OrderTrack? deliveryDetails;
  String? transactionId;
  String? invoiceStatus;
  OrderTrack? ctrTrackingDetails;

  StockDeliveryDAO(
      {this.buyer,
      this.invoiceId,
      this.invoiceDate,
      this.invoiceNo,
      this.seller,
      this.deliveryDetails,
      this.transactionId,
      this.invoiceStatus,
      this.ctrTrackingDetails});

  factory StockDeliveryDAO.fromJson(Map<String, dynamic> json) =>
      StockDeliveryDAO(
          buyer: json.containsKey("buyer") && json["buyer"] != null
              ? Buyer.fromJson(json["buyer"])
              : null,
          seller: json.containsKey("seller") && json["seller"] != null
              ? Buyer.fromJson(json["seller"])
              : null,
          invoiceNo: json.containsKey("bill_no") && json["bill_no"] != null
              ? json["bill_no"]??0
              : 0,
          transactionId:
              json.containsKey("transactionId") && json['transactionId'] != null
                  ? json["transactionId"]
                  : "",
          invoiceDate:
              json.containsKey("invoice_date") && json['invoice_date'] != null
                  ? DateTime.parse(json['invoice_date'])
                  : DateTime.now(),
          deliveryDetails:
              json.containsKey("order_track") && json["order_track"] != null
                  ? OrderTrack.fromJson(json["order_track"])
                  : null,
          invoiceId:
              json.containsKey("id") && json["id"] != null ? json["id"] : "",
          invoiceStatus: json.containsKey("status") && json["status"] != null
              ? json["status"]
              : "",
          ctrTrackingDetails: json.containsKey("ctr_tracking_details") &&
                  json["ctr_tracking_details"] != null
              ? OrderTrack.fromJson(json["ctr_tracking_details"])
              : null);
}
