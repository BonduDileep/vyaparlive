class ProductSubCategoryDAO implements Comparable<ProductSubCategoryDAO> {
  String? id;
  String? type;
  int? code;
  int? parentCode;
  String? name;
  String? strCode;

  ProductSubCategoryDAO(
      {this.id,
      this.type,
      this.code,
      this.parentCode,
      this.name,
      this.strCode});

  factory ProductSubCategoryDAO.fromJson(Map<String, dynamic> json) =>
      ProductSubCategoryDAO(
          id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
          type: json.containsKey("product_sub_category") &&
                  json["product_sub_category"] != null
              ? json["product_sub_category"]
              : "",
          code: json.containsKey("UNSPSC_code") && json["UNSPSC_code"] != null
              ? json["UNSPSC_code"]
              : 0,
          parentCode: json.containsKey("parent_UNSPSC_code") &&
                  json["parent_UNSPSC_code"] != null
              ? json["parent_UNSPSC_code"]
              : 0,
          name: json.containsKey("name") && json["name"] != null
              ? json["name"]
              : "",
          strCode: json.containsKey("code") && json["code"] != null
              ? json["code"]
              : "");

  Map<String, dynamic> toJson() => {
        "id": id,
        "product_sub_category": type,
        "parent_UNSPSC_code": parentCode,
        "UNSPSC_code": code,
        "name": name,
        "code": strCode
      };

  /// Using for search by type in CategorySearchPage.dart and EditMyProduct.dart
  @override
  String toString() {
    return '$type'.toLowerCase() + '$type'.toUpperCase();
  }

  @override
  int compareTo(ProductSubCategoryDAO other) {
    // Compare based on the 'name' field
    return name!.compareTo(other.name!);
  }
}
