class Chat {
  int? id;
  String? name;
  String? message;
  String? productname;
  int? counter;
  int? isButton;
  String? productImage;
  int? price;
  int? quantity;
  String? category;
  String? date;
  String? orderfrom;
  int? batchOneQuantity;
  int? batchTwoQuantity;
  int? batchThreeQuantity;
  int? batchOnePrice;
  int? batchTwoPrice;
  int? batchThreePrice;
  String? productQuality;
  Chat(
      this.id,
      this.name,
      this.message,
      this.productname,
      this.counter,
      this.isButton,
      this.productImage,
      this.price,
      this.quantity,
      this.category,
      this.date,
      this.orderfrom,
      this.batchOneQuantity,
      this.batchTwoQuantity,
      this.batchThreeQuantity,
      this.batchOnePrice,
      this.batchTwoPrice,
      this.batchThreePrice,
      this.productQuality);
  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      'id': id,
      'name': name,
      'message': message,
      'productname': productname,
      'counter': counter,
      'isButton': isButton,
      'product_image': productImage,
      'price': price,
      'quantity': quantity,
      'category': category,
      'date': date,
      'orderfrom': orderfrom,
      'batch_one_quantity': batchOneQuantity,
      'batch_two_quantity': batchTwoQuantity,
      'batch_three_quantity': batchThreeQuantity,
      'batch_one_price': batchOnePrice,
      'batch_two_price': batchTwoPrice,
      'batch_three_price': batchThreePrice,
      'product_quality': productQuality,
    };
    return map;
  }

  Chat.fromMap(Map<String, dynamic> map) {
    id = map['id'];
    name = map['name'];
    message = map['message'];
    productname = map['productname'];
    counter = map['counter'];
    isButton = map['isButton'];
    productImage = map['product_image'];
    price = map['price'];
    quantity = map['quantity'];
    category = map['category'];
    date = map['date'];
    orderfrom = map['orderfrom'];
    batchOneQuantity = map['batch_one_quantity'];
    batchTwoQuantity = map['batch_two_quantity'];
    batchThreeQuantity = map['batch_three_quantity'];
    batchOnePrice = map['batch_one_price'];
    batchTwoPrice = map['batch_two_price'];
    batchThreePrice = map['batch_three_price'];
    productQuality = map['product_quality'];
  }
}
