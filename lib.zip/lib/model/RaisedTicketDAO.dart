class RaisedTicketDAO {
  String? id;
  String? email;
  String? message;
  String? name;
  String? subject;
  DateTime? createdDate;
  List<TicketMessages>? messages;

  RaisedTicketDAO(
      {this.id,
      this.email,
      this.message,
      this.name,
      this.subject,
      this.messages,
      this.createdDate});

  factory RaisedTicketDAO.fromJson(Map<String, dynamic> json) =>
      RaisedTicketDAO(
        id: json.containsKey("_id") && json["_id"] != null ? json["_id"] : "",
        email: json.containsKey("email") && json["email"] != null
            ? json["email"]
            : "",
        message: json.containsKey("message") && json["message"] != null
            ? json["message"]
            : "",
        name: json.containsKey("name") && json["name"] != null
            ? json["name"]
            : "",
        subject: json.containsKey("subject") && json["subject"] != null
            ? json["subject"]
            : "",
        createdDate:
            json.containsKey("created_dt") && json["created_dt"] != null
                ? DateTime.parse(json["created_dt"])
                : null,
        messages: json.containsKey("messages") && json["messages"] != null
            ? List<TicketMessages>.from(
                json["messages"].map((x) => TicketMessages.fromJson(x)))
            : [],
      );

  Map<String, dynamic> toJson() => {
        "_id": id,
        "email": email,
        "message": message,
        "name": name,
        "subject": subject,
        "created_dt": createdDate
      };
}

class TicketMessages {
  String? message;
  DateTime? createdDate;
  TicketMessages({this.message, this.createdDate});

  factory TicketMessages.fromJson(Map<String, dynamic> json) => TicketMessages(
      message: json.containsKey("message") && json["message"] != null
          ? json["message"]
          : "",
      createdDate: json.containsKey("created_at") && json["created_at"]!=null
          ? DateTime.parse(json["created_at"])
          : null);
}
