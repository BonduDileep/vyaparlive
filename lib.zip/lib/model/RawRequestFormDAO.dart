
import 'package:vyaparlive/model/InvoiceDAO.dart';

class RawRequestFormDAO {
  String? buId;
  String? id;
  IssuedTo? issuedTo;
  String? purpose;
  List<Product>? productList;
  DateTime? createdDate;
  num? status;
  num? requestNumber;
  num? issueNumber;
  String? batchNumber;
  String? department;
  IssuedTo? requestedBy;

  RawRequestFormDAO(
      {this.buId,
      this.id,
      this.issuedTo,
      this.purpose,
      this.productList,
      this.createdDate,
      this.status,
      this.requestNumber,
      this.issueNumber,
      this.batchNumber,
      this.department,
      this.requestedBy});

  factory RawRequestFormDAO.fromJson(Map<String, dynamic> json) => RawRequestFormDAO(
      buId: json.containsKey("bu") && json["bu"] != null ? json["bu"] : "",
      id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
      issuedTo: json.containsKey("issued_to") && json["issued_to"] != null
          ? IssuedTo.fromJson(json["issued_to"])
          : null,
      purpose:
          json.containsKey("issued_purpose") && json["issued_purpose"] != null
              ? json["issued_purpose"]
              : "",
      productList: json.containsKey("products") && json["products"] != null
          ? List<Product>.from(json["products"].map((x) => Product.fromJson(x)))
          : [],
      createdDate: json.containsKey("created_dt") && json["created_dt"] != null
          ? DateTime.parse(json["created_dt"])
          : null,
      status: json.containsKey("status") && json["status"] != null
          ? json["status"]
          : 0,
      requestNumber:
          json.containsKey("req_number") && json["req_number"] != null
              ? json["req_number"]
              : 0,
      issueNumber:
          json.containsKey("issue_number") && json["issue_number"] != null
              ? json["issue_number"]
              : 0,
      batchNumber: json.containsKey("issue_batch_number") &&
              json["issue_batch_number"] != null
          ? json["issue_batch_number"]
          : "",
      department: json.containsKey("department") && json["department"] != null
          ? json["department"]
          : "",
      requestedBy:
          json.containsKey("requested_by") && json["requested_by"] != null
              ? IssuedTo.fromJson(json["requested_by"])
              : null);

  Map<String, dynamic> toJson() => {
        "bu": buId,
        "id": id,
        "products": List<dynamic>.from(productList!.map((e) => e.toJson())),
        "note": purpose,
        "issued_to": issuedTo,
        "created_dt": createdDate!.toIso8601String(),
        "status": status,
        "issue_number": issueNumber,
        "req_number": requestNumber,
        "department": department,
        "issue_batch_number": issueNumber,
        "requested_by": requestedBy!.toJson()
      };
}

class IssuedTo {
  String? userId;
  String? userName;

  IssuedTo({this.userId, this.userName});

  factory IssuedTo.fromJson(Map<String, dynamic> json) => IssuedTo(
      userId: json.containsKey("user_id") && json["user_id"] != null
          ? json["user_id"]
          : "",
      userName: json.containsKey("user_name") && json["user_name"] != null
          ? json["user_name"]
          : "");

  Map<String, dynamic> toJson() => {"user_id": userId, "user_name": userName};
}
