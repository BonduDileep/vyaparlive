import 'package:vyaparlive/model/TransactionsModel.dart';

class StockDAO {
  Buyer? buyer;
  Buyer? seller;
  String? message;
  String? transactionId;
  String? notificationType;
  String? id;
  DateTime? createdDate;

  StockDAO(
      {this.buyer,
      this.createdDate,
      this.id,
      this.message,
      this.notificationType,
      this.seller,
      this.transactionId});

  factory StockDAO.fromJson(Map<String, dynamic> json) => StockDAO(
      buyer: json.containsKey("buyer") && json["buyer"] != null
          ? Buyer.fromJson(json["buyer"])
          : null,
      seller: json.containsKey("seller") && json["seller"] != null
          ? Buyer.fromJson(json["seller"])
          : null,
      message: json.containsKey("message") && json["message"] != null
          ? json["message"]
          : "",
      transactionId:
          json.containsKey("transaction_id") && json["transaction_id"] != null
              ? json["transaction_id"]
              : "",
      notificationType: json.containsKey("notification_type") &&
              json["notification_type"] != null
          ? json["notification_type"]
          : "",
      createdDate:
          json.containsKey("created_date") && json["created_date"] != null
              ? DateTime.parse(json["created_date"])
              : DateTime.now(),
      id: json.containsKey("id") && json["id"] != null ? json["id"] : "");

  Map<String, dynamic> toJson() => {
        "seller": seller!.toJson(),
        "buyer": buyer!.toJson(),
        "message": message,
        "transaction_id": transactionId,
        "notification_type": notificationType,
        "created_date": createdDate!.toIso8601String(),
        "id": id
      };
}
