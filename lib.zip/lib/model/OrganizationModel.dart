import 'dart:convert';

OrganizationModel organizationModelFromJson(String str) =>
    OrganizationModel.fromJson(json.decode(str));

String organizationModelToJson(OrganizationModel data) =>
    json.encode(data.toJson());

class OrganizationModel {
  OrganizationModel({
    this.userId,
    this.businessName,
    this.shortName,
    this.website,
    this.type,
    this.countryCode,
    this.currencyCode,
    this.createdDate,
    this.createdBy,
    this.updatedDate,
    this.updatedBy,
    this.registration,
    this.directors,
    this.contactDetails,
    this.regulation,
    this.exports,
    this.imports,
    this.paymentTerms,
    this.stockReceiveLocations,
    this.stockDispatchLocations,
    this.bankDetailsReceives,
    this.bankDetailsPayments,
    this.yrDetails,
    this.yrSubscriptions,
    this.root,
    this.metadata,
    this.id,
  });

  String? userId;
  String? businessName;
  String? shortName;
  String? website;
  String? type;
  String? countryCode;
  String? currencyCode;
  String? createdDate;
  String? createdBy;
  String? updatedDate;
  String? updatedBy;
  Registration? registration;
  Directors? directors;
  ContactDetails? contactDetails;
  Regulation? regulation;
  Ports? exports;
  Ports? imports;
  PaymentTerms? paymentTerms;
  StockReceiveLocations? stockReceiveLocations;
  StockDispatchLocations? stockDispatchLocations;
  BankDetails? bankDetailsReceives;
  BankDetails? bankDetailsPayments;
  YrDetails? yrDetails;
  YrSubscriptions? yrSubscriptions;
  var root;
  Metadata? metadata;
  String? id;

  factory OrganizationModel.fromJson(Map<String, dynamic> json) =>
      OrganizationModel(
        userId: json.containsKey("user_id") && json["user_id"] != null
            ? json["user_id"]
            : "",
        businessName:
            json.containsKey("business_name") && json["business_name"] != null
                ? json["business_name"]
                : "",
        shortName: json.containsKey("short_name") && json["short_name"] != null
            ? json["short_name"]
            : "",
        website: json.containsKey("website") && json["website"] != null
            ? json["website"]
            : "",
        type: json.containsKey("type") && json["type"] != null
            ? json["type"]
            : "",
        countryCode:
            json.containsKey("country_code") && json["country_code"] != null
                ? json["country_code"]
                : "",
        currencyCode:
            json.containsKey("currency_code") && json["currency_code"] != null
                ? json["currency_code"]
                : "",
        createdDate:
            json.containsKey("created_date") && json["created_date"] != null
                ? json["created_date"]
                : "",
        createdBy: json.containsKey("created_by") && json["created_by"] != null
            ? json["created_by"]
            : "",
        updatedDate:
            json.containsKey("updated_date") && json["updated_date"] != null
                ? json["updated_date"]
                : "",
        updatedBy: json.containsKey("updated_by") && json["updated_by"] != null
            ? json["updated_by"]
            : "",
        registration:
            json.containsKey("registration") && json["registration"] != null
                ? Registration.fromJson(json["registration"])
                : null,
        directors: json.containsKey("directors") && json["directors"] != null
            ? Directors.fromJson(json["directors"])
            : null,
        contactDetails: json.containsKey("contact_details") &&
                json["contact_details"] != null
            ? ContactDetails.fromJson(json["contact_details"])
            : null,
        regulation: json.containsKey("regulation") && json["regulation"] != null
            ? Regulation.fromJson(json["regulation"])
            : null,
        exports: json.containsKey("exports") && json["exports"] != null
            ? Ports.fromJson(json["exports"])
            : null,
        imports: json.containsKey("imports") && json["imports"] != null
            ? Ports.fromJson(json["imports"])
            : null,
        paymentTerms:
            json.containsKey("payment_terms") && json["payment_terms"] != null
                ? PaymentTerms.fromJson(json["payment_terms"])
                : null,
        stockReceiveLocations: json.containsKey("stock_receive_locations") &&
                json["stock_receive_locations"] != null
            ? StockReceiveLocations.fromJson(json["stock_receive_locations"])
            : null,
        stockDispatchLocations: json.containsKey("stock_dispatch_locations") &&
                json["stock_dispatch_locations"] != null
            ? StockDispatchLocations.fromJson(json["stock_dispatch_locations"])
            : null,
        bankDetailsReceives: json.containsKey("bank_details_receives") &&
                json["bank_details_receives"] != null
            ? BankDetails.fromJson(json["bank_details_receives"])
            : null,
        bankDetailsPayments: json.containsKey("bank_details_payments") &&
                json["bank_details_payments"] != null
            ? BankDetails.fromJson(json["bank_details_payments"])
            : null,
        yrDetails: json.containsKey("yr_details") && json["yr_details"] != null
            ? YrDetails.fromJson(json["yr_details"])
            : null,
        yrSubscriptions: json.containsKey("yr_subscriptions")
            ? YrSubscriptions.fromJson(json["yr_subscriptions"])
            : null,
        root: json.containsKey("root") && json["root"] != null
            ? json["root"]
            : null,
        metadata: json.containsKey("@metadata") && json["@metadata"] != null
            ? Metadata.fromJson(json["@metadata"])
            : null,
        id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
      );

  Map<String, dynamic> toJson() => {
        "user_id": userId,
        "business_name": businessName,
        "short_name": shortName,
        "website": website,
        "type": type,
        "country_code": countryCode,
        "currency_code": currencyCode,
        "created_date": createdDate,
        "created_by": createdBy,
        "updated_date": updatedDate,
        "updated_by": updatedBy,
        "registration": registration!.toJson(),
        "directors": directors!.toJson(),
        "contact_details": contactDetails!.toJson(),
        "regulation": regulation!.toJson(),
        "exports": exports!.toJson(),
        "imports": imports!.toJson(),
        "payment_terms": paymentTerms!.toJson(),
        "stock_receive_locations": stockReceiveLocations!.toJson(),
        "stock_dispatch_locations": stockDispatchLocations!.toJson(),
        "bank_details_receives": bankDetailsReceives!.toJson(),
        "bank_details_payments": bankDetailsPayments!.toJson(),
        "yr_details": yrDetails!.toJson(),
        "yr_subscriptions": yrSubscriptions!.toJson(),
        "root": root,
        "@metadata": metadata!.toJson(),
        "id": id,
      };
}

class BankDetails {
  BankDetails({
    this.id,
    this.bankName,
    this.bankAccountName,
    this.bankAccountNumber,
    this.ePayCode,
    this.swifTcode,
    this.micrCode,
  });

  String? id;
  String? bankName;
  String? bankAccountName;
  String? bankAccountNumber;
  String? ePayCode;
  String? swifTcode;
  String? micrCode;

  factory BankDetails.fromJson(Map<String, dynamic> json) => BankDetails(
        id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
        bankName: json.containsKey("BankName") && json["BankName"] != null
            ? json["BankName"]
            : "",
        bankAccountName: json.containsKey("BankAccountName") &&
                json["BankAccountName"] != null
            ? json["BankAccountName"]
            : "",
        bankAccountNumber: json.containsKey("BankAccountNumber") &&
                json["BankAccountNumber"] != null
            ? json["BankAccountNumber"]
            : "",
        ePayCode: json.containsKey("EPayCode") && json["EPayCode"] != null
            ? json["EPayCode"]
            : "",
        swifTcode: json.containsKey("SWIFTcode") && json["SWIFTcode"] != null
            ? json["SWIFTcode"]
            : "",
        micrCode: json.containsKey("MICRCode") && json["MICRCode"] != null
            ? json["MICRCode"]
            : "",
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "BankName": bankName,
        "BankAccountName": bankAccountName,
        "BankAccountNumber": bankAccountNumber,
        "EPayCode": ePayCode,
        "SWIFTcode": swifTcode,
        "MICRCode": micrCode,
      };
}

class ContactDetails {
  ContactDetails({
    this.primarycontactname,
    this.address,
  });

  String? primarycontactname;
  Address? address;

  factory ContactDetails.fromJson(Map<String, dynamic> json) => ContactDetails(
        primarycontactname: json.containsKey("primarycontactname") &&
                json["primarycontactname"] != null
            ? json["primarycontactname"]
            : "",
        address: json.containsKey("address") && json["address"] != null
            ? Address.fromJson(json["address"])
            : null,
      );

  Map<String, dynamic> toJson() => {
        "primarycontactname": primarycontactname,
        "address": address!.toJson(),
      };
}

class Address {
  Address({
    this.addressformat,
    this.businesslocationnumber,
    this.buildinghousenumber,
    this.buildingstreetname,
    this.colonysectorArealocality,
    this.villagetowncity,
    this.taluk,
    this.landmark,
    this.state,
    this.district,
    this.postcode,
    this.country,
  });

  String? addressformat;
  String? businesslocationnumber;
  String? buildinghousenumber;
  String? buildingstreetname;
  String? colonysectorArealocality;
  String? villagetowncity;
  String? taluk;
  String? landmark;
  String? state;
  String? district;
  String? postcode;
  String? country;

  factory Address.fromJson(Map<String, dynamic> json) => Address(
        addressformat:
            json.containsKey("addressformat") && json["addressformat"] != null
                ? json["addressformat"]
                : "",
        businesslocationnumber: json.containsKey("businesslocationnumber") &&
                json["businesslocationnumber"] != null
            ? json["businesslocationnumber"]
            : "",
        buildinghousenumber: json.containsKey("buildinghousenumber") &&
                json["buildinghousenumber"] != null
            ? json["buildinghousenumber"]
            : "",
        buildingstreetname: json.containsKey("buildingstreetname") &&
                json["buildingstreetname"] != null
            ? json["buildingstreetname"]
            : "",
        colonysectorArealocality:
            json.containsKey("colonysector_arealocality") &&
                    json["colonysector_arealocality"] != null
                ? json["colonysector_arealocality"]
                : "",
        villagetowncity: json.containsKey("villagetowncity") &&
                json["villagetowncity"] != null
            ? json["villagetowncity"]
            : "",
        taluk: json.containsKey("taluk") && json["taluk"] != null
            ? json["taluk"]
            : "",
        landmark: json.containsKey("landmark") && json["landmark"] != null
            ? json["landmark"]
            : "",
        state: json.containsKey("state") && json["state"] != null
            ? json["state"]
            : "",
        district: json.containsKey("district") && json["district"] != null
            ? json["district"]
            : "",
        postcode: json.containsKey("postcode") && json["postcode"] != null
            ? json["postcode"]
            : "",
        country: json.containsKey("country") && json["country"] != null
            ? json["country"]
            : "",
      );

  Map<String, dynamic> toJson() => {
        "addressformat": addressformat,
        "businesslocationnumber": businesslocationnumber,
        "buildinghousenumber": buildinghousenumber,
        "buildingstreetname": buildingstreetname,
        "colonysector_arealocality": colonysectorArealocality,
        "villagetowncity": villagetowncity,
        "taluk": taluk,
        "landmark": landmark,
        "state": state,
        "district": district,
        "postcode": postcode,
        "country": country,
      };
}

class Directors {
  Directors({
    this.id,
    this.personName,
    this.personidentificationSchemename,
    this.personidentificationNumber,
    this.digitalSignature,
  });

  String? id;
  String? personName;
  String? personidentificationSchemename;
  String? personidentificationNumber;
  String? digitalSignature;

  factory Directors.fromJson(Map<String, dynamic> json) => Directors(
        id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
        personName:
            json.containsKey("person_name") && json["person_name"] != null
                ? json["person_name"]
                : "",
        personidentificationSchemename:
            json.containsKey("personidentification_schemename") &&
                    json["personidentification_schemename"] != null
                ? json["personidentification_schemename"]
                : "",
        personidentificationNumber:
            json.containsKey("personidentification_number") &&
                    json["personidentification_number"] != null
                ? json["personidentification_number"]
                : "",
        digitalSignature: json.containsKey("digital_signature") &&
                json["digital_signature"] != null
            ? json["digital_signature"]
            : "",
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "person_name": personName,
        "personidentification_schemename": personidentificationSchemename,
        "personidentification_number": personidentificationNumber,
        "digital_signature": digitalSignature,
      };
}

class Ports {
  Ports({
    this.country,
    this.govtregistrationSchemename,
    this.govtregistrationSchemeid,
  });

  String? country;
  String? govtregistrationSchemename;
  String? govtregistrationSchemeid;

  factory Ports.fromJson(Map<String, dynamic> json) => Ports(
        country: json.containsKey("country") && json["country"] != null
            ? json["country"]
            : "",
        govtregistrationSchemename:
            json.containsKey("govtregistration_schemename") &&
                    json["govtregistration_schemename"] != null
                ? json["govtregistration_schemename"]
                : "",
        govtregistrationSchemeid:
            json.containsKey("govtregistration_schemeid") &&
                    json["govtregistration_schemeid"] != null
                ? json["govtregistration_schemeid"]
                : "",
      );

  Map<String, dynamic> toJson() => {
        "country": country,
        "govtregistration_schemename": govtregistrationSchemename,
        "govtregistration_schemeid": govtregistrationSchemeid,
      };
}

class Metadata {
  Metadata({
    this.collection,
    this.nestedObjectTypes,
    this.ravenNodeType,
    this.changeVector,
    this.id,
    this.indexScore,
    this.lastModified,
  });

  String? collection;
  NestedObjectTypes? nestedObjectTypes;
  dynamic ravenNodeType;
  String? changeVector;
  String? id;
  double? indexScore;
  DateTime? lastModified;

  factory Metadata.fromJson(Map<String, dynamic> json) => Metadata(
        collection:
            json.containsKey("@collection") && json["@collection"] != null
                ? json["@collection"]
                : "",
        nestedObjectTypes: json.containsKey("@nested-object-types") &&
                json["@nested-object-types"] != null
            ? NestedObjectTypes.fromJson(json["@nested-object-types"])
            : null,
        ravenNodeType: json.containsKey("Raven-Node-Type") &&
                json["Raven-Node-Type"] != null
            ? json["Raven-Node-Type"]
            : "",
        changeVector:
            json.containsKey("@change-vector") && json["@change-vector"] != null
                ? json["@change-vector"]
                : "",
        id: json.containsKey("@id") && json["@id"] != null ? json["@id"] : 0 as String?,
        indexScore:
            json.containsKey("@index-score") && json["@index-score"] != null
                ? json["@index-score"].toDouble()
                : 0.0,
        lastModified:
            json.containsKey("@last-modified") && json["@last-modified"] != null
                ? DateTime.parse(json["@last-modified"])
                : DateTime.now(),
      );

  Map<String, dynamic> toJson() => {
        "@collection": collection,
        "@nested-object-types": nestedObjectTypes!.toJson(),
        "Raven-Node-Type": ravenNodeType,
        "@change-vector": changeVector,
        "@id": id,
        "@index-score": indexScore,
        "@last-modified": lastModified!.toIso8601String(),
      };
}

class NestedObjectTypes {
  NestedObjectTypes();

  factory NestedObjectTypes.fromJson(Map<String, dynamic>? json) =>
      NestedObjectTypes();

  Map<String, dynamic> toJson() => {};
}

class PaymentTerms {
  PaymentTerms({
    this.id,
    this.invoicecurrencycode,
    this.paymentperiodcode,
    this.numberofdays,
    this.invoiceDescription,
    this.partialpaymentpercent,
    this.penaltyamount,
    this.penaltypercentrate,
    this.description,
    this.penaltybasisamount,
  });

  String? id;
  String? invoicecurrencycode;
  String? paymentperiodcode;
  String? numberofdays;
  String? invoiceDescription;
  String? partialpaymentpercent;
  String? penaltyamount;
  String? penaltypercentrate;
  String? description;
  String? penaltybasisamount;

  factory PaymentTerms.fromJson(Map<String, dynamic> json) => PaymentTerms(
        id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
        invoicecurrencycode: json.containsKey("invoicecurrencycode") &&
                json["invoicecurrencycode"] != null
            ? json["invoicecurrencycode"]
            : "",
        paymentperiodcode: json.containsKey("paymentperiodcode") &&
                json["paymentperiodcode"] != null
            ? json["paymentperiodcode"]
            : "",
        numberofdays:
            json.containsKey("numberofdays") && json["numberofdays"] != null
                ? json["numberofdays"]
                : "",
        invoiceDescription: json.containsKey("invoice_description") &&
                json["invoice_description"] != null
            ? json["invoice_description"]
            : "",
        partialpaymentpercent: json.containsKey("partialpaymentpercent") &&
                json["partialpaymentpercent"] != null
            ? json["partialpaymentpercent"]
            : "",
        penaltyamount:
            json.containsKey("penaltyamount") && json["penaltyamount"] != null
                ? json["penaltyamount"]
                : "",
        penaltypercentrate: json.containsKey("penaltypercentrate") &&
                json["penaltypercentrate"] != null
            ? json["penaltypercentrate"]
            : "",
        description:
            json.containsKey("description") && json["description"] != null
                ? json["description"]
                : "",
        penaltybasisamount: json.containsKey("penaltybasisamount") &&
                json["penaltybasisamount"] != null
            ? json["penaltybasisamount"]
            : "",
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "invoicecurrencycode": invoicecurrencycode,
        "paymentperiodcode": paymentperiodcode,
        "numberofdays": numberofdays,
        "invoice_description": invoiceDescription,
        "partialpaymentpercent": partialpaymentpercent,
        "penaltyamount": penaltyamount,
        "penaltypercentrate": penaltypercentrate,
        "description": description,
        "penaltybasisamount": penaltybasisamount,
      };
}

class Registration {
  Registration({
    this.govtregisteredName,
    this.legalentityType,
    this.govtregistrationScheme,
    this.govtregisteredSchemeid,
    this.registrationDate,
    this.registrationCity,
    this.registrationState,
    this.govtclassifiedLineofbusiness,
  });

  String? govtregisteredName;
  String? legalentityType;
  String? govtregistrationScheme;
  String? govtregisteredSchemeid;
  String? registrationDate;
  String? registrationCity;
  String? registrationState;
  String? govtclassifiedLineofbusiness;

  factory Registration.fromJson(Map<String, dynamic> json) => Registration(
        govtregisteredName: json.containsKey("govtregistered_name") &&
                json["govtregistered_name"] != null
            ? json["govtregistered_name"]
            : "",
        legalentityType: json.containsKey("legalentity_type") &&
                json["legalentity_type"] != null
            ? json["legalentity_type"]
            : "",
        govtregistrationScheme: json.containsKey("govtregistration_scheme") &&
                json["govtregistration_scheme"] != null
            ? json["govtregistration_scheme"]
            : "",
        govtregisteredSchemeid: json.containsKey("govtregistered_schemeid") &&
                json["govtregistered_schemeid"] != null
            ? json["govtregistered_schemeid"]
            : "",
        registrationDate: json.containsKey("registration_date") &&
                json["registration_date"] != null
            ? json["registration_date"]
            : "",
        registrationCity: json.containsKey("registration_city") &&
                json["registration_city"] != null
            ? json["registration_city"]
            : "",
        registrationState: json.containsKey("registration_state") &&
                json["registration_state"] != null
            ? json["registration_state"]
            : "",
        govtclassifiedLineofbusiness:
            json.containsKey("govtclassified_lineofbusiness") &&
                    json["govtclassified_lineofbusiness"] != null
                ? json["govtclassified_lineofbusiness"]
                : "",
      );

  Map<String, dynamic> toJson() => {
        "govtregistered_name": govtregisteredName,
        "legalentity_type": legalentityType,
        "govtregistration_scheme": govtregistrationScheme,
        "govtregistered_schemeid": govtregisteredSchemeid,
        "registration_date": registrationDate,
        "registration_city": registrationCity,
        "registration_state": registrationState,
        "govtclassified_lineofbusiness": govtclassifiedLineofbusiness,
      };
}

class Regulation {
  Regulation({
    this.govtbusinessSchemeid,
    this.govtregistrationId,
  });

  String? govtbusinessSchemeid;
  String? govtregistrationId;

  factory Regulation.fromJson(Map<String, dynamic> json) => Regulation(
        govtbusinessSchemeid: json.containsKey("govtbusiness_schemeid") &&
                json["govtbusiness_schemeid"] != null
            ? json["govtbusiness_schemeid"]
            : "",
        govtregistrationId: json.containsKey("govtregistration_id") &&
                json["govtregistration_id"] != null
            ? json["govtregistration_id"]
            : "",
      );

  Map<String, dynamic> toJson() => {
        "govtbusiness_schemeid": govtbusinessSchemeid,
        "govtregistration_id": govtregistrationId,
      };
}

class StockDispatchLocations {
  StockDispatchLocations({
    this.id,
    this.dispatchlocationNumber,
    this.dispatchbusinessName,
    this.taxinfo,
    this.addressofsender,
  });

  String? id;
  String? dispatchlocationNumber;
  String? dispatchbusinessName;
  Taxinfo? taxinfo;
  Addressof? addressofsender;

  factory StockDispatchLocations.fromJson(Map<String, dynamic> json) =>
      StockDispatchLocations(
        id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
        dispatchlocationNumber: json.containsKey("dispatchlocation_number") &&
                json["dispatchlocation_number"] != null
            ? json["dispatchlocation_number"]
            : "",
        dispatchbusinessName: json.containsKey("dispatchbusiness_name") &&
                json["dispatchbusiness_name"] != null
            ? json["dispatchbusiness_name"]
            : "",
        taxinfo: json.containsKey("taxinfo") && json["taxinfo"] != null
            ? Taxinfo.fromJson(json["taxinfo"])
            : null,
        addressofsender: json.containsKey("addressofsender") &&
                json["addressofsender"] != null
            ? Addressof.fromJson(json["addressofsender"])
            : null,
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "dispatchlocation_number": dispatchlocationNumber,
        "dispatchbusiness_name": dispatchbusinessName,
        "taxinfo": taxinfo!.toJson(),
        "addressofsender": addressofsender!.toJson(),
      };
}

class Addressof {
  Addressof({
    this.id,
    this.name,
    this.address,
    this.contactNo,
  });

  String? id;
  String? name;
  String? address;
  String? contactNo;

  factory Addressof.fromJson(Map<String, dynamic> json) => Addressof(
        id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
        name: json.containsKey("name") && json["name"] != null
            ? json["name"]
            : "",
        address: json.containsKey("address") && json["address"] != null
            ? json["address"]
            : "",
        contactNo: json.containsKey("contact_no") && json["contact_no"] != null
            ? json["contact_no"]
            : "",
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "address": address,
        "contact_no": contactNo,
      };
}

class Taxinfo {
  Taxinfo({
    this.id,
    this.taxname,
    this.taxid,
    this.exemptionReason,
  });

  String? id;
  String? taxname;
  String? taxid;
  String? exemptionReason;

  factory Taxinfo.fromJson(Map<String, dynamic> json) => Taxinfo(
        id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
        taxname: json.containsKey("taxname") && json["taxname"] != null
            ? json["taxname"]
            : "",
        taxid: json.containsKey("taxid") && json["taxid"] != null
            ? json["taxid"]
            : "",
        exemptionReason: json.containsKey("exemption_reason") &&
                json["exemption_reason"] != null
            ? json["exemption_reason"]
            : "",
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "taxname": taxname,
        "taxid": taxid,
        "exemption_reason": exemptionReason,
      };
}

class StockReceiveLocations {
  StockReceiveLocations({
    this.id,
    this.receivelocationNumber,
    this.receivebusinessName,
    this.taxinfo,
    this.addressofreceiver,
  });

  String? id;
  String? receivelocationNumber;
  String? receivebusinessName;
  Taxinfo? taxinfo;
  Addressof? addressofreceiver;

  factory StockReceiveLocations.fromJson(Map<String, dynamic> json) =>
      StockReceiveLocations(
        id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
        receivelocationNumber: json.containsKey("receivelocation_number") &&
                json["receivelocation_number"] != null
            ? json["receivelocation_number"]
            : "",
        receivebusinessName: json.containsKey("receivebusiness_name") &&
                json["receivebusiness_name"] != null
            ? json["receivebusiness_name"]
            : "",
        taxinfo: json.containsKey("taxinfo") && json["taxinfo"] != null
            ? Taxinfo.fromJson(json["taxinfo"])
            : null,
        addressofreceiver: json.containsKey("addressofreceiver") &&
                json["addressofreceiver"] != null
            ? Addressof.fromJson(json["addressofreceiver"])
            : null,
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "receivelocation_number": receivelocationNumber,
        "receivebusiness_name": receivebusinessName,
        "taxinfo": taxinfo!.toJson(),
        "addressofreceiver": addressofreceiver!.toJson(),
      };
}

class YrDetails {
  YrDetails({
    this.businessunitId,
    this.legalentityId,
    this.groupheadId,
    this.bulegalentity,
    this.bugrouphead,
  });

  String? businessunitId;
  String? legalentityId;
  String? groupheadId;
  String? bulegalentity;
  String? bugrouphead;

  factory YrDetails.fromJson(Map<String, dynamic> json) => YrDetails(
        businessunitId: json.containsKey("businessunit_id") &&
                json["businessunit_id"] != null
            ? json["businessunit_id"]
            : "",
        legalentityId:
            json.containsKey("legalentity_id") && json["legalentity_id"] != null
                ? json["legalentity_id"]
                : "",
        groupheadId:
            json.containsKey("grouphead_id") && json["grouphead_id"] != null
                ? json["grouphead_id"]
                : "",
        bulegalentity:
            json.containsKey("bulegalentity") && json["bulegalentity"] != null
                ? json["bulegalentity"]
                : "",
        bugrouphead:
            json.containsKey("bugrouphead") && json["bugrouphead"] != null
                ? json["bugrouphead"]
                : "",
      );

  Map<String, dynamic> toJson() => {
        "businessunit_id": businessunitId,
        "legalentity_id": legalentityId,
        "grouphead_id": groupheadId,
        "bulegalentity": bulegalentity,
        "bugrouphead": bugrouphead,
      };
}

class YrSubscriptions {
  YrSubscriptions({
    this.numberofbuyer,
    this.numberofseller,
    this.numberofdeliverymanagement,
    this.startDateTime,
  });

  String? numberofbuyer;
  String? numberofseller;
  String? numberofdeliverymanagement;
  String? startDateTime;

  factory YrSubscriptions.fromJson(Map<String, dynamic> json) =>
      YrSubscriptions(
        numberofbuyer:
            json.containsKey("numberofbuyer") && json["numberofbuyer"] != null
                ? json["numberofbuyer"]
                : "",
        numberofseller:
            json.containsKey("numberofseller") && json["numberofseller"] != null
                ? json["numberofseller"]
                : "",
        numberofdeliverymanagement:
            json.containsKey("numberofdeliverymanagement") &&
                    json["numberofdeliverymanagement"] != null
                ? json["numberofdeliverymanagement"]
                : "",
        startDateTime:
            json.containsKey("StartDateTime") && json["StartDateTime"] != null
                ? json["StartDateTime"]
                : "",
      );

  Map<String, dynamic> toJson() => {
        "numberofbuyer": numberofbuyer,
        "numberofseller": numberofseller,
        "numberofdeliverymanagement": numberofdeliverymanagement,
        "StartDateTime": startDateTime,
      };
}
