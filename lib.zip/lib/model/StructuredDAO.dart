class StructuredDAO {
  StructuredDAO({this.id, this.name, this.description, this.code});
  String? id;
  String? name;
  String? description;
  String? code;

  factory StructuredDAO.fromJson(Map<String, dynamic> json) => StructuredDAO(
      id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
      name:
          json.containsKey("name") && json["name"] != null ? json["name"] : "",
      description:
          json.containsKey("description") && json["description"] != null
              ? json["description"]
              : "",
      code:
          json.containsKey("code") && json["code"] != null ? json["code"] : "");

  Map<String, dynamic> toJson() =>
      {"id": id, "name": name, "description": description, "code": code};
}
