class UserConnectionsDAO {
  String? buName;
  String? buId;

  UserConnectionsDAO({this.buId, this.buName});

  factory UserConnectionsDAO.fromJson(Map<String, dynamic> json) =>
      UserConnectionsDAO(
          buName: json.containsKey("bu_name") && json["bu_name"] != null
              ? json["bu_name"]
              : "",
          buId: json.containsKey("bu_id") && json["bu_id"] != null
              ? json["bu_id"]
              : "");

  Map<String, dynamic> toJson() => {"bu_name": buName, "bu_id": buId};
}
