import 'package:vyaparlive/model/TransactionsModel.dart';
import 'package:vyaparlive/model/bu_model/ContactDetailsModel.dart';
import 'package:vyaparlive/model/bu_model/LocationsModel.dart';
import 'package:vyaparlive/model/transaction/CtrServiceDAO.dart';
import 'package:vyaparlive/model/transaction/InvoiceDetailsModel.dart';

class CTR1InvoiceDAO {
  InvoiceDetails? invoiceDetails;
  ContactDetails? fromAddress;
  ContactDetails? toAddress;
  num? billNo;
  num? refBillNo;
  num? cgst;
  num? sgst;
  num? gstTotal;
  String? invoiceId;
  String? noOfBoxes;
  String? weight;
  String? transactionId;
  num? igst;
  Buyer? buyerDetails;
  Locations? pickupLocation;
  CtrServiceDAO? ctrService;

  CTR1InvoiceDAO(
      {this.billNo,
      this.cgst,
      this.fromAddress,
      this.gstTotal,
      this.invoiceId,
      this.invoiceDetails,
      this.refBillNo,
      this.sgst,
      this.toAddress,
      this.noOfBoxes,
      this.weight,
      this.transactionId,
      this.igst,
      this.buyerDetails,
      this.pickupLocation,
      this.ctrService});

  factory CTR1InvoiceDAO.fromJson(Map<String, dynamic> json) => CTR1InvoiceDAO(
      billNo: json.containsKey("invoice_number") && json["invoice_number"] != null
          ? json["invoice_number"]
          : 0,
      fromAddress:
          json.containsKey("from_address") && json["from_address"] != null
              ? ContactDetails.fromJson(json["from_address"])
              : null,
      toAddress: json.containsKey("to_address") && json["to_address"] != null
          ? ContactDetails.fromJson(json["to_address"])
          : null,
      refBillNo:
          json.containsKey("ref_invoice_no") && json["ref_invoice_no"] != null
              ? json["ref_invoice_no"]
              : 0,
      cgst: json.containsKey("cgst") && json["cgst"] != null ? json["cgst"] : 0,
      sgst: json.containsKey("sgst") && json["sgst"] != null ? json["sgst"] : 0,
      gstTotal: json.containsKey("gst_total") && json["gst_total"] != null
          ? json["gst_total"]
          : 0,
      noOfBoxes: json.containsKey("no_of_boxed") && json["no_of_boxed"] != null
          ? json["no_of_boxed"]
          : "0",
      weight: json.containsKey("weight") && json["weight"] != null
          ? json["weight"]
          : "0",
      invoiceId: json.containsKey("id") && json["id"] != null ? json["id"] : "",
      invoiceDetails:
          json.containsKey("invoice_details") && json["invoice_details"] != null
              ? InvoiceDetails.fromJson(json["invoice_details"])
              : null,
      transactionId:
          json.containsKey("transactionId") && json["transactionId"] != null
              ? json["transactionId"]
              : "",
      igst: json.containsKey("igst") && json["igst"] != null ? json.containsKey("igst") as num? : 0,
      buyerDetails: json.containsKey("buyer") && json["buyer"] != null ? Buyer.fromJson(json["buyer"]) : null,
      pickupLocation: json.containsKey("pick_up_location") && json["pick_up_location"] != null ? Locations.fromJson(json["pick_up_location"]) : null,
      ctrService: json.containsKey("ctr_service") && json["ctr_service"] != null ? CtrServiceDAO.fromJson(json["ctr_service"]) : null);

  Map<String, dynamic> toJson() => {
        "id": invoiceId,
        "ref_invoice_no": refBillNo,
        "from_address": fromAddress,
        "to_address": toAddress,
        "weight": weight,
        "no_of_boxed": noOfBoxes,
        "invoice_details": invoiceDetails!.toJson(),
        "cgst": cgst,
        "sgst": sgst,
        "gst_total": gstTotal,
        "invoice_number": billNo,
        "igst": igst,
        "buyer": buyerDetails.toString(),
        "pick_up_location": pickupLocation!.toJson(),
        "ctr_service": ctrService!.toJson()
      };
}
