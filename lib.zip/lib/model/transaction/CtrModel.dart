import 'package:vyaparlive/model/bu_model/AddressDetailsModel.dart';
import 'package:vyaparlive/model/bu_model/ContactDetailsModel.dart';
import 'package:vyaparlive/model/transaction/DeliveryDetailsModel.dart';

class Ctr {
  Ctr(
      {this.refTransactionId,
      this.type,
      this.inDirectDelivery,
      this.deliveryAddress,
      this.pickupLocation});
  String? type;
  String? refTransactionId;
  OrderTrack? inDirectDelivery;
  ContactDetails? pickupLocation;
  Address? deliveryAddress;

  factory Ctr.fromJson(Map<String, dynamic> json) => Ctr(
      type:
          json.containsKey("type") && json["type"] != null ? json["type"] : "",
      refTransactionId:
          json.containsKey("transaction_ref") && json["transaction_ref"] != null
              ? json["transaction_ref"]
              : "",
      inDirectDelivery: json.containsKey("indirect_delivery") &&
              json["indirect_delivery"] != null
          ? OrderTrack.fromJson(json["indirect_delivery"])
          : null,
      pickupLocation: json.containsKey("pick_up_location") &&
              json["pick_up_location"] != null
          ? ContactDetails.fromJson(json["pick_up_location"])
          : null,
      deliveryAddress:
          json.containsKey("ship_to_address") && json["ship_to_address"] != null
              ? Address.fromJson(json["ship_to_address"])
              : null);

  Map<String, dynamic> toJson() => {
        "type": type,
        "transaction_ref": refTransactionId,
        "ship_to_address": deliveryAddress!.toJson(),
        "pick_up_location": pickupLocation!.toJson()
      };
}
