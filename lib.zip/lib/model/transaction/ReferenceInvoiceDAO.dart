class ReferenceInvoiceDAO {
  String? invoiceId;
  dynamic invoiceNo;
  String? status;

  ReferenceInvoiceDAO({this.invoiceId, this.invoiceNo, this.status});

  factory ReferenceInvoiceDAO.fromJson(Map<String, dynamic> json) =>
      ReferenceInvoiceDAO(
          invoiceId:
              json.containsKey("invoice_id") && json["invoice_id"] != null
                  ? json["invoice_id"]
                  : "",
          invoiceNo: json.containsKey("bill_no") && json["bill_no"] != null
              ? json["bill_no"]??0
              : 0,
          status: json.containsKey("status") && json["status"] != null
              ? json["status"]
              : "");

  Map<String, dynamic> toJson() =>
      {"invoice_id": invoiceId, "bill_no": invoiceNo, "status": status};
}
