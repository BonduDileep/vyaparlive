import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/common_methods.dart';

class PackingLocationsDAO {
  String? uid;
  List<QuantityLocationDAO>? packingLocationList;

  PackingLocationsDAO({this.packingLocationList, this.uid});

  factory PackingLocationsDAO.fromJson(Map<String, dynamic> json) =>
      PackingLocationsDAO(
          uid:
              json.containsKey("uid") && json["uid"] != null ? json["uid"] : "",
          packingLocationList: json.containsKey("locations") &&
                  json["locations"] != null
              ? List<QuantityLocationDAO>.from(
                  json["locations"].map((e) => QuantityLocationDAO.fromJson(e)))
              : []);

  Map<String, dynamic> toJson() => {
        "locations":
            List<dynamic>.from(packingLocationList!.map((e) => e.toJson())),
        "uid": uid
      };
}

class QuantityLocationDAO {
  String? locationId;
  num? quantity;
  String? batchNumber;

  QuantityLocationDAO({this.quantity, this.locationId, this.batchNumber});

  factory QuantityLocationDAO.fromJson(Map<String, dynamic> json) =>
      QuantityLocationDAO(
        locationId: CommonMethods.getValueFromJSON(
            json, "location", Constants.TYPE_STRING),
        quantity: CommonMethods.getValueFromJSON(
            json, "quantity", Constants.TYPE_NUMBER),
        batchNumber: CommonMethods.getValueFromJSON(
            json, "batch_number", Constants.TYPE_STRING),
      );

  Map<String, dynamic> toJson() => {
        "quantity": quantity,
        "location": locationId,
        "batch_number": batchNumber
      };
}
