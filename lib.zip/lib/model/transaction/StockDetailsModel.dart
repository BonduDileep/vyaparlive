import 'package:vyaparlive/model/transaction/ReconciliationModel.dart';

class StockReconciliation {
  StockReconciliation({this.status, this.messages, this.ctrMessage});
  String? status;
  List<ReconciliationDetails>? messages;
  String? ctrMessage;

  factory StockReconciliation.fromJson(Map<String, dynamic> json) =>
      StockReconciliation(
          status: json.containsKey("status") && json["status"] != null
              ? json["status"]
              : "",
          ctrMessage:
              json.containsKey("ctr3_message") && json["ctr3_message"] != null
                  ? json["ctr3_message"]
                  : "",
          messages: json.containsKey("messages") && json["messages"] != null
              ? List<ReconciliationDetails>.from(json["messages"]
                  .map((x) => ReconciliationDetails.fromJson(x)))
              : []);

  Map<String, dynamic> toJson() => {
        "status": status,
        "messages": List<dynamic>.from(messages!.map((x) => x.toJson()))
      };
}
