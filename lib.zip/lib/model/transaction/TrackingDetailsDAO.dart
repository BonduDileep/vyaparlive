class TrackingDetailsDAO {
  String? docType;
  String? docNumber;
  TrackingDetailsDAO({this.docNumber, this.docType});

  factory TrackingDetailsDAO.fromJson(Map<String, dynamic> json) =>
      TrackingDetailsDAO(
          docType:
              json.containsKey("delivery_type") && json["delivery_type"] != null
                  ? json["delivery_type"]
                  : "",
          docNumber: json.containsKey("value") && json["value"] != null
              ? json["value"]
              : "");

  Map<String, dynamic> toJson() =>
      {"delivery_type": docType, "value": docNumber};
}
