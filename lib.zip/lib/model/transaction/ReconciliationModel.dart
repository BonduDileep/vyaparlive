class ReconciliationDetails {
  ReconciliationDetails(
      {this.bu,
      this.message,
      this.messageType,
      this.messageDate,
      this.userName,
      this.invoiceImage,
      this.discrepancyCode});
  String? bu;
  String? messageType;
  String? message;
  String? userName;
  DateTime? messageDate;
  String? invoiceImage;
  String? discrepancyCode;

  factory ReconciliationDetails.fromJson(Map<String, dynamic> json) =>
      ReconciliationDetails(
          bu: json.containsKey("bu") && json["bu"] != null ? json["bu"] : "",
          message: json.containsKey("messages") && json["messages"] != null
              ? json["messages"]
              : "",
          userName: json.containsKey("user_name") && json["user_name"] != null
              ? json["user_name"]
              : "",
          messageType:
              json.containsKey("message_type") && json["message_type"] != null
                  ? json["message_type"]
                  : "",
          messageDate:
              json.containsKey("message_date") && json["message_date"] != null
                  ? DateTime.parse(json["message_date"])
                  : null,
          invoiceImage:
              json.containsKey("invoice_image") && json['invoice_image'] != null
                  ? json['invoice_image']
                  : "",
          discrepancyCode: json.containsKey("discrepancy_code") &&
                  json["discrepancy_code"] != null
              ? json["discrepancy_code"]
              : "");

  Map<String, dynamic> toJson() => {
        "bu": bu,
        "messages": message,
        "message_type": messageType,
        "user_name": userName,
        "message_date": messageDate!.toIso8601String(),
        "invoice_image": invoiceImage,
        "discrepancy_code": discrepancyCode
      };
}
