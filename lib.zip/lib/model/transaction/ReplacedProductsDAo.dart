import 'package:vyaparlive/model/InvoiceDAO.dart';

class ReplacedProductsDAO {
  List<Product>? replacedProducts;
  ReplacedProductsDAO({this.replacedProducts});
  factory ReplacedProductsDAO.fromJson(Map<String, dynamic> json) =>
      ReplacedProductsDAO(
        replacedProducts:
            json.containsKey("products") && json["products"] != null
                ? List<Product>.from(
                    json["products"].map((x) => Product.fromJson(x)))
                : [],
      );

  Map<String, dynamic> toJson() => {
        "products": List<dynamic>.from(replacedProducts!.map((x) => x.toJson())),
      };
}
