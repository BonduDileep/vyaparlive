import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/model/InvoiceDAO.dart';
import 'package:vyaparlive/model/transaction/AssignPackingModel.dart';
import 'package:vyaparlive/model/transaction/DeliveryDetailsModel.dart';
import 'package:vyaparlive/model/transaction/PackingDetailsModel.dart';
import 'package:vyaparlive/model/transaction/PackingLocationsDAO.dart';
import 'package:vyaparlive/model/transaction/ReceivedPaymnetDAO.dart';
import 'package:vyaparlive/model/transaction/ReferenceInvoiceDAO.dart';
import 'package:vyaparlive/model/transaction/StockDetailsModel.dart';

class InvoiceDetails {
  InvoiceDetails(
      {this.invoiceDate,
      this.billNo,
      this.taxReferences,
      this.address,
      this.authority,
      this.products,
      this.packageDetails,
      this.orderTrackDetails,
      this.inDirectDetails,
      this.stockReconciliation,
      this.paymentReconciliation,
      this.status,
      this.actualDeliveryDate,
      this.receivedBy,
      this.stockReceivedStatus,
      this.actualDeliveryTime,
      this.refInvoice,
      this.assignPackingDetails,
      this.paymentDueDate,
      this.paymentReceivedBy,
      this.paymentReceivedDate,
      this.paymentReceivedTime,
      this.paymentReceivedStatus,
      this.amountPaid,
      this.balanceDue,
      this.gstTotal,
      this.subTotal,
      this.cgstTotal,
      this.finalTotal,
      this.sgstTotal,
      this.taxTotal,
      this.total,
      this.additionalDiscount,
      this.productToatalCost,
      this.totalOffer,
      this.totalPrice,
      this.pendingAmount,
      this.receivedPayments,
      this.invoiceType,
      this.invoiceId,
      this.ctrTransactionDetails,
      this.replacedProducts,
      this.igstTotal,
      this.referenceInvoiceFrom,
      this.referenceInvoiceTo,
      this.ctrPrice,
      this.deliveryStatus,
      this.additionalDiscountType,
      this.additionalDiscountValue,
      this.packingData,
      this.advanceAmountTotal,
      this.penaltyAmountTotal,
      this.deliveryDate,
      this.sellerInvocie,
      this.additionalDiscountTotal,
      this.paymentStatus,
      this.packingStatus,
      this.pickupStatus,
      this.additionalCharges});

  DateTime? invoiceDate;
  dynamic billNo;
  TaxReferences? taxReferences;
  String? address;
  String? authority;
  List<Product>? products;
  PackageDetails? packageDetails;
  AssignPackingDetails? assignPackingDetails;
  OrderTrack? orderTrackDetails;
  OrderTrack? inDirectDetails;
  StockReconciliation? stockReconciliation;
  StockReconciliation? paymentReconciliation;
  String? status;
  List<int>? refInvoice;
  String? actualDeliveryDate;
  String? receivedBy;
  String? stockReceivedStatus;
  String? actualDeliveryTime;
  DateTime? paymentDueDate;
  String? paymentReceivedDate;
  String? paymentReceivedTime;
  String? paymentReceivedBy;
  String? paymentReceivedStatus;
  num? subTotal;
  num? total;
  var amountPaid;
  num? gstTotal;
  var balanceDue;
  num? cgstTotal;
  num? sgstTotal;
  num? taxTotal;
  num? finalTotal;
  num? productToatalCost;
  num? totalOffer;
  num? totalPrice;
  num? additionalDiscount;
  num? pendingAmount;
  List<ReceivedPaymentDAO>? receivedPayments;
  String? invoiceType;
  String? invoiceId;
  OrderTrack? ctrTransactionDetails;
  List<Product>? replacedProducts;
  num? igstTotal;
  ReferenceInvoiceDAO? referenceInvoiceFrom;
  ReferenceInvoiceDAO? referenceInvoiceTo;
  num? ctrPrice;
  String? deliveryStatus;
  String? additionalDiscountType;
  num? additionalDiscountValue;
  List<PackingLocationsDAO>? packingData;
  num? penaltyAmountTotal;
  num? advanceAmountTotal;
  String? deliveryDate;
  String? sellerInvocie;
  num? additionalDiscountTotal;

  String? paymentStatus;
  String? packingStatus;
  String? pickupStatus;
  List<AdditionalCharges>? additionalCharges;

  factory InvoiceDetails.fromJson(Map<String, dynamic> json) => InvoiceDetails(
        invoiceDate:
            json.containsKey("invoice_date") && json["invoice_date"] != null
                ? DateTime.parse(json["invoice_date"])
                : null,
        billNo: json.containsKey("bill_no") && json["bill_no"] != null
            ? json["bill_no"] ?? 0
            : 0,
        taxReferences:
            json.containsKey("tax_references") && json["tax_references"] != null
                ? TaxReferences.fromJson(json["tax_references"])
                : null,
        address: json.containsKey("address") && json["address"] != null
            ? json["address"]
            : "",
        authority: json.containsKey("authority") && json["authority"] != null
            ? json["authority"]
            : "",
        products: json.containsKey("products") && json["products"] != null
            ? List<Product>.from(
                json["products"].map((x) => Product.fromJson(x)))
            : [],
        packageDetails: json.containsKey("package_details") &&
                json["package_details"] != null
            ? PackageDetails.fromJson(json["package_details"])
            : null,
        assignPackingDetails:
            json.containsKey("assign_packing") && json["assign_packing"] != null
                ? AssignPackingDetails.fromJson(json["assign_packing"])
                : null,
        orderTrackDetails:
            json.containsKey("order_track") && json["order_track"] != null
                ? OrderTrack.fromJson(json["order_track"])
                : null,
        inDirectDetails: json.containsKey("indirect_delivery") &&
                json["indirect_delivery"] != null
            ? OrderTrack.fromJson(json["indirect_delivery"])
            : null,
        stockReconciliation: json.containsKey("stock_reconciliation") &&
                json["stock_reconciliation"] != null
            ? StockReconciliation.fromJson(json["stock_reconciliation"])
            : null,
        paymentReconciliation: json.containsKey("payment_reconciliation") &&
                json["payment_reconciliation"] != null
            ? StockReconciliation.fromJson(json["payment_reconciliation"])
            : null,
        status: json.containsKey("status") && json["status"] != null
            ? json["status"]
            : "",
        actualDeliveryDate: json.containsKey("actual_delivery_date") &&
                json["actual_delivery_date"] != null
            ? json["actual_delivery_date"]
            : "",
        paymentDueDate: json.containsKey("payment_due_date") &&
                json["payment_due_date"] != null
            ? DateTime.parse(json['payment_due_date'])
            : null,
        actualDeliveryTime: json.containsKey("actual_delivery_time") &&
                json["actual_delivery_time"] != null
            ? json["actual_delivery_time"]
            : "",
        receivedBy: json.containsKey("stock_received_by") &&
                json["stock_received_by"] != null
            ? json["stock_received_by"]
            : "",
        stockReceivedStatus: json.containsKey("stock_received_status") &&
                json["stock_received_status"] != null
            ? json["stock_received_status"]
            : "",
        paymentReceivedBy: json.containsKey("payment_received_by") &&
                json["payment_received_by"] != null
            ? json["payment_received_by"]
            : "",
        paymentReceivedDate:
            json.containsKey("payment_date") && json["payment_date"] != null
                ? json["payment_date"]
                : "",
        paymentReceivedTime:
            json.containsKey("payment_time") && json["payment_time"] != null
                ? json["payment_time"]
                : "",
        paymentReceivedStatus: json.containsKey("payment_received_status") &&
                json["payment_received_status"] != null
            ? json["payment_received_status"]
            : "",
        refInvoice:
            json.containsKey("ref_invoice_no") && json["ref_invoice_no"] != null
                ? List<int>.from(json["ref_invoice_no"].map((x) => x))
                : [],
        cgstTotal: json.containsKey("cgst_total") && json["cgst_total"] != null
            ? json["cgst_total"]
            : 0,
        sgstTotal: json.containsKey("sgst_total") && json["sgst_total"] != null
            ? json["sgst_total"]
            : 0,
        taxTotal: json.containsKey("tax_total") && json["tax_total"] != null
            ? json["tax_total"]
            : 0,
        finalTotal:
            json.containsKey("invoice_amount") && json["invoice_amount"] != null
                ? json["invoice_amount"]
                : 0,
        productToatalCost:
            json.containsKey("products_cost") && json["products_cost"] != null
                ? json["products_cost"]
                : 0,
        totalOffer:
            json.containsKey("total_offer") && json["total_offer"] != null
                ? json["total_offer"]
                : 0,
        totalPrice:
            json.containsKey("total_price") && json["total_price"] != null
                ? json["total_price"]
                : 0,
        additionalDiscount: json.containsKey("additional_discount") &&
                json["additional_discount"] != null
            ? json["additional_discount"]
            : 0,
        subTotal: json.containsKey("sub_total") && json["sub_total"] != null
            ? json["sub_total"]
            : 0,
        gstTotal: json.containsKey("gst_total") && json["gst_total"] != null
            ? json["gst_total"]
            : 0,
        total: json.containsKey("total") && json["total"] != null
            ? json["total"]
            : 0,
        amountPaid:
            json.containsKey("amount_paid") && json["amount_paid"] != null
                ? json["amount_paid"]
                : 0,
        balanceDue:
            json.containsKey("balance_due") && json["balance_due"] != null
                ? json["balance_due"]
                : 0,
        pendingAmount:
            json.containsKey("pending_amount") && json["pending_amount"] != null
                ? json["pending_amount"]
                : 0,
        receivedPayments: json.containsKey("payment_received") &&
                json["payment_received"] != null
            ? List<ReceivedPaymentDAO>.from(json["payment_received"]
                .map((e) => ReceivedPaymentDAO.fromJson(e)))
            : [],
        invoiceType: json.containsKey("type") && json["type"] != null
            ? json["type"]
            : "",
        invoiceId: CommonMethods.getInvoiceIdFromRes(json),

        // json.containsKey("invoice_id")&& json["invoice_id"] != null
        //     ? json["invoice_id"]
        //     : "",
        ctrTransactionDetails: json.containsKey("ctr_tracking_details") &&
                json["ctr_tracking_details"] != null
            ? OrderTrack.fromJson(json["ctr_tracking_details"])
            : null,
        replacedProducts: json.containsKey("replaced_products") &&
                json["replaced_products"] != null
            ? List<Product>.from(
                json["replaced_products"].map((x) => Product.fromJson(x)))
            : [],
        igstTotal: json.containsKey("igst_total") && json["igst_total"] != null
            ? json["igst_total"]
            : 0,
        referenceInvoiceFrom: json.containsKey("ref_invoice_from") &&
                json["ref_invoice_from"] != null
            ? ReferenceInvoiceDAO.fromJson(json["ref_invoice_from"])
            : null,
        referenceInvoiceTo:
            json.containsKey("ref_invoice_to") && json["ref_invoice_to"] != null
                ? ReferenceInvoiceDAO.fromJson(json["ref_invoice_to"])
                : null,
        ctrPrice: json.containsKey("price") && json["price"] != null
            ? json["price"]
            : 0,
        deliveryStatus: json.containsKey("delivery_status") &&
                json["delivery_status"] != null
            ? json["delivery_status"]
            : "",
        additionalDiscountType: json.containsKey("additional_discount_type") &&
                json["additional_discount_type"] != null
            ? json["additional_discount_type"]
            : "",
        additionalDiscountValue:
            json.containsKey("additional_discount_value") &&
                    json["additional_discount_value"] != null
                ? json["additional_discount_value"]
                : 0,
        packingData: json.containsKey("packing_locations") &&
                json["packing_locations"] != null
            ? List<PackingLocationsDAO>.from(json["packing_locations"]
                .map((x) => PackingLocationsDAO.fromJson(x)))
            : [],
        penaltyAmountTotal: json.containsKey("penalty_amount_total") &&
                json["penalty_amount_total"] != null
            ? json["penalty_amount_total"]
            : 0,
        advanceAmountTotal: json.containsKey("advance_amount_total") &&
                json["advance_amount_total"] != null
            ? json["advance_amount_total"]
            : 0,
        deliveryDate:
            json.containsKey("delivery_date") && json["delivery_date"] != null
                ? json["delivery_date"]
                : "",
        sellerInvocie:
            json.containsKey('seller_invoice') && json['seller_invoice'] != null
                ? json['seller_invoice']
                : "",
        additionalDiscountTotal:
            json.containsKey("additional_discount_total") &&
                    json["additional_discount_total"] != null
                ? json["additional_discount_total"]
                : 0,
        paymentStatus:
            json.containsKey("payment_status") && json["payment_status"] != null
                ? json["payment_status"]
                : "",
        packingStatus:
            json.containsKey("packing_status") && json["packing_status"] != null
                ? json["packing_status"]
                : "",
        pickupStatus:
            json.containsKey("pickup_status") && json["pickup_status"] != null
                ? json["pickup_status"]
                : "",
        additionalCharges: json.containsKey("additional_charges") &&
                json["additional_charges"] != null
            ? List<AdditionalCharges>.from(json["additional_charges"]
                .map((x) => AdditionalCharges.fromJson(x)))
            : [],
      );

  Map<String, dynamic> toJson() => {
        "actual_delivery_date": actualDeliveryDate,
        "actual_delivery_time": actualDeliveryTime,
        "stock_received_by": receivedBy,
        "stock_received_status": stockReceivedStatus,
        "payment_date": paymentReceivedDate,
        "payment_time": paymentReceivedTime,
        "payment_received_status": paymentReceivedStatus,
        "payment_received_by": paymentReceivedStatus,
        "invoice_date": invoiceDate,
        "bill_no": billNo,
        "tax_references": taxReferences!.toJson(),
        "address": address,
        "authority": authority,
        "products": List<dynamic>.from(products!.map((x) => x.toJson())),
        "package_details": packageDetails!.toJson(),
        "order_track": orderTrackDetails!.toJson(),
        "indirect_delivery": inDirectDetails!.toJson(),
        "stock_reconciliation": stockReconciliation!.toJson(),
        "payment_reconciliation": paymentReconciliation!.toJson(),
        "status": status,
        "assign_packing": assignPackingDetails!.toJson(),
        "payment_due_date": paymentDueDate!.toIso8601String(),
        "ref_invoice_no": List<dynamic>.from(refInvoice!.map((x) => x)),
        "balance_due": balanceDue,
        "amount_paid": amountPaid,
        "total": total,
        "gst_total": gstTotal,
        "sub_total": subTotal,
        "cgst_total": cgstTotal,
        "sgst_total": sgstTotal,
        "tax_total": taxTotal,
        "final_price": finalTotal,
        "pending_amount": pendingAmount,
        "type": invoiceType,
        "payment_received":
            List<dynamic>.from(receivedPayments!.map((e) => e.toJson())),
        "invoice_id": invoiceId,
        "ctr_tracking_details": ctrTransactionDetails,
        "replaced_products":
            List<dynamic>.from(replacedProducts!.map((x) => x.toJson())),
        "igst_total": igstTotal,
        "ref_invoice_to": referenceInvoiceTo,
        "ref_invoice_from": referenceInvoiceFrom,
        "price": ctrPrice,
        "delivery_status": deliveryStatus,
        "additional_discount_value": additionalDiscountValue,
        "additional_discount_type": additionalDiscountType,
        "packing_locations":
            List<dynamic>.from(packingData!.map((e) => e.toJson())),
        "advance_amount_total": advanceAmountTotal,
        "penalty_amount_total": penaltyAmountTotal,
        "delivery_date": deliveryDate,
        "seller_invoice": sellerInvocie,
        "additional_discount_total": additionalDiscountTotal
      };
}
