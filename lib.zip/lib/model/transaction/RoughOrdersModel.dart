import 'package:vyaparlive/model/TransactionsModel.dart';

class RoughOrderDetails {
  RoughOrderDetails({
    this.products,
  });

  List<Product>? products;

  factory RoughOrderDetails.fromJson(Map<String, dynamic> json) =>
      RoughOrderDetails(
        products: json.containsKey("products") && json["products"] != null
            ? List<Product>.from(
                json["products"].map((x) => Product.fromJson(x)))
            : [],
      );

  Map<String, dynamic> toJson() => {
        "products": List<dynamic>.from(products!.map((x) => x.toJson())),
      };
}
