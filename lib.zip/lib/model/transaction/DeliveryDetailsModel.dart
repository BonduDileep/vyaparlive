import 'package:vyaparlive/model/transaction/TrackingDetailsDAO.dart';

class OrderTrack {
  OrderTrack(
      {this.assignedTo,
      this.packingDate,
      this.despatchDate,
      this.deliveryDate,
      this.accptenceDate,
      this.assignedBu,
      this.assignedUser,
      this.fromAddress,
      this.toAddress,
      this.contactName,
      this.contactNumber,
      this.deliveryMode,
      this.deliveryTime,
      this.deliveryDetails,
      this.deliveryStatus,
      this.assignedUserMobileNumber,
      this.deliveryTrackingList,
      this.grnNumber,
      this.deliveryDateTime,
      this.stockPickupDateTime,
      this.stockDeliveredDateTime,
      this.stockPickupScheduleDateTime,
      this.transpoterExpectedDateTime,
      this.dispatchDeliveryDateTime,
      this.dispatchDeliveryDateTimeFormat,
      this.deliveryImagePath,
      this.status});

  String? assignedTo;
  String? packingDate;
  String? despatchDate;
  String? deliveryDate;
  String? accptenceDate;
  String? assignedBu;
  String? assignedUser;
  String? fromAddress;
  String? toAddress;
  String? contactName;
  String? contactNumber;
  String? deliveryStatus;
  String? deliveryMode;
  String? deliveryTime;
  String? assignedUserMobileNumber;
  DeliveryDetails? deliveryDetails;
  List<TrackingDetailsDAO>? deliveryTrackingList;
  String? grnNumber;
  DateTime? deliveryDateTime;
  String? stockPickupDateTime;
  String? stockPickupScheduleDateTime;
  String? stockDeliveredDateTime;
  String? transpoterExpectedDateTime;
  String? dispatchDeliveryDateTime;
  String? dispatchDeliveryDateTimeFormat;
  String? deliveryImagePath;
  String? status;

  factory OrderTrack.fromJson(Map<String, dynamic> json) => OrderTrack(
      assignedTo: json.containsKey("assigned_to") && json["assigned_to"] != null
          ? json["assigned_to"]
          : "",
      packingDate: json.containsKey("packing_date") && json["packing_date"] != null
          ? json["packing_date"]
          : "",
      despatchDate: json.containsKey("despatch_date") && json["despatch_date"] != null
          ? json["despatch_date"]
          : "",
      deliveryDate: json.containsKey("delivery_date") && json["delivery_date"] != null
          ? json["delivery_date"]
          : "",
      accptenceDate: json.containsKey("accptence_date") && json["accptence_date"] != null
          ? json["accptence_date"]
          : "",
      assignedBu: json.containsKey("assigned_to_bu") && json["assigned_to_bu"] != null
          ? json["assigned_to_bu"]
          : "",
      assignedUser:
          json.containsKey("assigned_to_user") && json["assigned_to_user"] != null
              ? json["assigned_to_user"]
              : "",
      assignedUserMobileNumber: json.containsKey("assigned_user_mobile_number") &&
              json["assigned_user_mobile_number"] != null
          ? json["assigned_user_mobile_number"]
          : "",
      fromAddress: json.containsKey("from_address") && json["from_address"] != null
          ? json["from_address"]
          : "",
      toAddress: json.containsKey("to_address") && json["to_address"] != null ? json["to_address"] : "",
      contactName: json.containsKey("contact_name") && json["contact_name"] != null ? json["contact_name"] : "",
      contactNumber: json.containsKey("contact_number") && json["contact_number"] != null ? json["contact_number"] : "",
      deliveryMode: json.containsKey("delivery_mode") && json["delivery_mode"] != null ? json["delivery_mode"] : "",
      deliveryTime: json.containsKey("delivery_time") && json["delivery_time"] != null ? json["delivery_time"] : "",
      deliveryDetails: json.containsKey("delivery_details") && json["delivery_details"] != null ? DeliveryDetails.fromJson(json["delivery_details"]) : null,
      deliveryStatus: json.containsKey("delivery_status") && json["delivery_status"] != null ? json["delivery_status"] : "",
      deliveryTrackingList: json.containsKey("delivery_details_arr") && json["delivery_details_arr"] != null ? List<TrackingDetailsDAO>.from(json["delivery_details_arr"].map((x) => TrackingDetailsDAO.fromJson(x))) : [],
      grnNumber: json.containsKey("GRN_No") && json["GRN_No"] != null ? json["GRN_No"] : "",
      deliveryDateTime: json.containsKey("delivery_date_time") && json["delivery_date_time"] != null ? DateTime.parse(json["delivery_date_time"]) : null,
      stockPickupDateTime: json.containsKey("stock_pick_up_date_time") && json["stock_pick_up_date_time"] != null ? json["stock_pick_up_date_time"] : "",
      stockPickupScheduleDateTime: json.containsKey("schedule_pick_up_date_time") && json["schedule_pick_up_date_time"] != null ? json["schedule_pick_up_date_time"] : "",
      stockDeliveredDateTime: json.containsKey("stock_delivered_date_time") && json["stock_delivered_date_time"] != null ? json["stock_delivered_date_time"] : "",
      transpoterExpectedDateTime: json.containsKey("transpoter_expected_delivery_date_time") && json["transpoter_expected_delivery_date_time"] != null ? json["transpoter_expected_delivery_date_time"] : "",
      dispatchDeliveryDateTime: json.containsKey("dispatch_date_time") && json['dispatch_date_time'] != null ? json['dispatch_date_time'] : "",
      dispatchDeliveryDateTimeFormat: json.containsKey("dispatch_date_time_format") && json['dispatch_date_time_format'] != null ? json['dispatch_date_time_format'] : "",
      deliveryImagePath: json.containsKey("delivery_image") && json["delivery_image"] != null ? json["delivery_image"] : "",
      status: json.containsKey("status") && json["status"] != null ? json["status"] : "");

  Map<String, dynamic> toJson() => {
        "assigned_to": assignedTo,
        "packing_date": packingDate,
        "despatch_date": despatchDate,
        "delivery_date": deliveryDate,
        "accptence_date": accptenceDate,
        "assigned_to_bu": assignedBu,
        "assigned_to_user": assignedUser,
        "assigned_user_mobile_number": assignedUserMobileNumber,
        "from_address": fromAddress,
        "to_address": toAddress,
        "contact_name": contactName,
        "contact_number": contactNumber,
        "delivery_mode": deliveryMode,
        "delivery_status": deliveryStatus,
        "delivery_time": deliveryTime,
        "delivery_details": deliveryDetails,
        "delivery_details_arr":
            List<dynamic>.from(deliveryTrackingList!.map((e) => e.toJson())),
        "GRN_No": grnNumber,
        "delivery_date_time": deliveryDateTime!.toIso8601String(),
        "stock_pick_up_date_time": stockPickupDateTime,
        "transpoter_expected_delivery_date_time": transpoterExpectedDateTime,
        "stock_delivered_date_time": stockDeliveredDateTime,
        "schedule_pick_up_date_time": stockPickupScheduleDateTime,
        "dispatch_date_time": dispatchDeliveryDateTime,
        "dispatch_date_time_format": dispatchDeliveryDateTimeFormat,
        "delivery_image": deliveryImagePath,
      };
}

class DeliveryDetails {
  String? deliveryType;
  String? number;
  String? deliveryStatus;
  String? cancelReason;
  DeliveryDetails({this.deliveryType, this.number, this.deliveryStatus,this.cancelReason});

  factory DeliveryDetails.fromJson(Map<String, dynamic> json) =>
      DeliveryDetails(
          deliveryType:
              json.containsKey("delivery_type") && json["delivery_type"] != null
                  ? json["delivery_type"]
                  : "",
          deliveryStatus: json.containsKey("delivery_status") &&
                  json["delivery_status"] != null
              ? json["delivery_status"]
              : "",
          number: json.containsKey("value") && json["value"] != null
              ? json["value"]
              : "",
          cancelReason:
              json.containsKey("cancel_reason") && json["cancel_reason"] != null
                  ? json["cancel_reason"]
                  : "");

  Map<String, dynamic> toJson() => {
        "delivery_type": deliveryType,
        "value": number,
        "delivery_status": deliveryStatus,
        "cancel_reason":cancelReason
      };
}
