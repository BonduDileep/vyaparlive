import 'package:vyaparlive/model/Message.dart';
import 'package:vyaparlive/model/transaction/ConfirmationMessagesModel.dart';

class Discussion {
  Discussion(
      {this.initiator,
      this.messageStartDate,
      this.messages,
      this.confirmationMessages,
      this.buyerAccepted,
      this.sellerAccepted,
      this.placeOrderAccepted,
      this.confirmationStatus,
      this.discussionStatus});

  String? initiator;
  String? messageStartDate;
  List<Message>? messages;
  List<ConfirmationMessagesDetails>? confirmationMessages;
  String? confirmationStatus;
  bool? buyerAccepted;
  bool? sellerAccepted;
  bool? placeOrderAccepted;
  String? discussionStatus;

  factory Discussion.fromJson(Map<String, dynamic> json) => Discussion(
      initiator: json.containsKey("initiator") && json["initiator"] != null
          ? json["initiator"]
          : "",
      messageStartDate: json.containsKey("messageStartDate") && json["messageStartDate"] != null
          ? json["messageStartDate"]
          : "",
      messages: json.containsKey("messages") && json["messages"] != null
          ? List<Message>.from(json["messages"].map((x) => Message.fromJson(x)))
          : [],
      confirmationMessages:
          json.containsKey("confirmation_message") && json["confirmation_message"] != null
              ? List<ConfirmationMessagesDetails>.from(json["confirmation_message"]
                  .map((x) => ConfirmationMessagesDetails.fromJson(x)))
              : [],
      buyerAccepted: json.containsKey("buyer_accepted") && json["buyer_accepted"] != null
          ? json["buyer_accepted"]
          : false,
      sellerAccepted: json.containsKey("seller_accepted") && json["seller_accepted"] != null
          ? json["seller_accepted"]
          : false,
      placeOrderAccepted: json.containsKey("po_accepted") && json["po_accepted"] != null
          ? json["po_accepted"]
          : false,
      confirmationStatus:
          json.containsKey("confirmation_status") && json["confirmation_status"] != null
              ? json["confirmation_status"]
              : "",
              discussionStatus: json.containsKey("discussion_status") && json["discussion_status"] != null
          ? json["discussion_status"]
          : "");

  Map<String, dynamic> toJson() => {
        "initiator": initiator,
        "messageStartDate": messageStartDate,
        "messages": List<dynamic>.from(messages!.map((x) => x.toJson())),
        "buyer_accepted": buyerAccepted,
        "seller_accepted": sellerAccepted,
        "po_accepted": placeOrderAccepted,
        "confirmation_message":
            List<dynamic>.from(confirmationMessages!.map((x) => x.toJson())),
        "confirmation_status": confirmationStatus,
        "discussion_status": discussionStatus,
      };
}
