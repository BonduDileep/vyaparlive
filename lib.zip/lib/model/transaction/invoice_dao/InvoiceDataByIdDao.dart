import 'package:vyaparlive/model/ondc_dao/OndcDao.dart';

import '../../ondc_dao/LogisticProvider.dart';
import '../../ondc_dao/logistic_confirmation/LogisticConfirmation.dart';
import '../InvoiceDetailsModel.dart';

class InvoiceDataByIdDao {
  String? id;
  dynamic billNo;
  String? transactionId;
  InvoiceDetails? invoiceDetails;
  LogisticProvider? logisticProvider;
  LogisticConfirmationDao? logisticConfirmationDao;
  OndcDao?ondcDao;
  InvoiceDataByIdDao(
      {this.logisticProvider,
      this.billNo,
      this.id,
      this.invoiceDetails,
      this.transactionId,
      this.logisticConfirmationDao,
      this.ondcDao});

  factory InvoiceDataByIdDao.fromJson(Map<String, dynamic> json) =>
      InvoiceDataByIdDao(
          logisticProvider: json.containsKey("logistic_provider") &&
                  json["logistic_provider"] != null
              ? LogisticProvider.fromJson(json["logistic_provider"])
              : null,
          id: json.containsKey("_id") && json["_id"] != null ? json["_id"] : "",
          billNo: json.containsKey("invoice_number") &&
                  json["invoice_number"] != null
              ? json["invoice_number"]??0
              : 0,
          transactionId:
              json.containsKey("transactionId") && json["transactionId"] != null
                  ? json["transactionId"]
                  : "",
          invoiceDetails: json.containsKey("invoice_details") &&
                  json["invoice_details"] != null
              ? InvoiceDetails.fromJson(json["invoice_details"])
              : null,
          logisticConfirmationDao: json.containsKey("logistic_conformation") &&
                  json["logistic_conformation"] != null
              ? LogisticConfirmationDao.fromJson(json["logistic_conformation"])
              : null,
              ondcDao: json.containsKey("ondc")&&json["ondc"]!=null?OndcDao.from(json["ondc"]):null);

  Map<String, dynamic> toJson() => {
        "logistic_provider": logisticProvider!.toJson(),
        "_id": id.toString(),
        "invoice_number": billNo,
        "transactionId": transactionId,
        "invoice_details": invoiceDetails!.toJson(),
        "logistic_conformation": logisticConfirmationDao!.toJson(),
        "ondc":ondcDao!.toJson()
      };
}
