import 'package:vyaparlive/model/product_model/BatchPriceDAO.dart';
import 'package:vyaparlive/model/product_model/OffersDAO.dart';

class ProductDetails {
  ProductDetails(
      {this.productId,
      this.priceUnit,
      this.quantity,
      this.totalPrice,
      this.productName,
      this.offerData,
      this.offerSelected,
      this.productImage,
      this.batchPricingList,
      this.id,
      this.name,
      this.count,
      this.quantityIn,
      this.batchNumber});
  String? productId;
  num? priceUnit;
  num? quantity;
  num? totalPrice;
  String? productName;
  String? productImage;
  OffersDAO? offerData;
  bool? offerSelected;
  List<BatchPriceDAO>? batchPricingList;
  String? id;
  String? name;
  num? count;
  String? quantityIn;
  String? batchNumber;

  factory ProductDetails.fromJson(Map<String, dynamic> json) => ProductDetails(
      productId: json.containsKey("id") && json["id"] != null ? json["id"] : "",
      priceUnit: json.containsKey("unit_price") &&
              json["unit_price"] != null &&
              json['unit_price'] != ""
          ? json["unit_price"]
          : 0,
      quantity: json.containsKey("quantity") && json["quantity"] != null
          ? json["quantity"]
          : 0,
      totalPrice:
          json.containsKey("total") && json["total"] != null && json["total"] != ""
              ? json["total"]
              : 0,
      productName: json.containsKey("product_name") && json["product_name"] != null
          ? json["product_name"]
          : "",
      offerData: json.containsKey("offer") && json["offer"] != null
          ? OffersDAO.fromJson(json["offer"])
          : null,
      offerSelected:
          json.containsKey("offer_selected") && json["offer_selected"] != null
              ? json["offer_selected"]
              : false,
      productImage:
          json.containsKey("product_image") && json["product_image"] != null
              ? json["product_image"]
              : "",
      batchPricingList:
          json.containsKey("batch_pricing") && json["batch_pricing"] != null
              ? List<BatchPriceDAO>.from(json["batch_pricing"].map((x) => BatchPriceDAO.fromJson(x)))
              : [],
      id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
      name: json.containsKey("name") && json["name"] != null ? json["name"] : "",
      count: json.containsKey("count") && json["count"] != null ? json["count"] : 0,
      quantityIn: json.containsKey("quantity_in") && json["quantity_in"] != null ? json["quantity_in"] : "",
      batchNumber: json.containsKey("batch_number") && json["batch_number"] != null ? json["batch_number"] : "");

  Map<String, dynamic> toJson() => {
        "product_id": productId,
        "price_unit": priceUnit,
        "quantity": quantity,
        "total_price": totalPrice,
        "product_name":
            productName, //List<dynamic>.from(productImage!.map((e) => e)),
        "product_image": productImage,
        "offer_selected": offerSelected,
        "offer": offerData!.toJson(),
        "batch_pricing":
            List<dynamic>.from(batchPricingList!.map((e) => e.toJson())),
        "id": id,
        "name": name,
        "count": count,
        "quantity_in": quantityIn,
        "batch_number": batchNumber,
      };
}
