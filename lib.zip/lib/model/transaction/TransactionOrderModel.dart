import 'package:vyaparlive/model/transaction/ProductDetailsModel.dart';

class OffersDetails {
  OffersDetails({this.productDetails, this.status, this.message});
  List<ProductDetails>? productDetails;
  String? status;
  String? message;

  factory OffersDetails.fromJson(Map<String, dynamic> json) => OffersDetails(
      productDetails: json.containsKey("products") && json["products"] != null
          ? List<ProductDetails>.from(
              json["products"].map((x) => ProductDetails.fromJson(x)))
          : [],
      status: json.containsKey("status") && json["status"] != null
          ? json["status"]
          : "",
      message: json.containsKey("message") && json["message"] != null
          ? json["message"]
          : "");
  Map<String, dynamic> toJson() => {
        "products": List<dynamic>.from(productDetails!.map((x) => x.toJson())),
        "status": status,
        "message": message
      };
}
