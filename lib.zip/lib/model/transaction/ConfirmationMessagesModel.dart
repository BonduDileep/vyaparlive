class ConfirmationMessagesDetails {
  String? bu;
  String? messages;
  String? userId;
  String? userName;
  String? type;
  DateTime? orderPlacedBy;
  DateTime? orderStatusDate;
  DateTime? messageDate;
  String? quotationId;

  ConfirmationMessagesDetails(
      {this.bu,
      this.messages,
      this.type,
      this.userId,
      this.userName,
      this.orderStatusDate,
      this.orderPlacedBy,
      this.messageDate,
      this.quotationId});

  factory ConfirmationMessagesDetails.fromJson(Map<String, dynamic> json) =>
      ConfirmationMessagesDetails(
          bu: json.containsKey("bu") && json["bu"] != null ? json["bu"] : "",
          messages: json.containsKey("messages") && json["messages"] != null
              ? json["messages"]
              : "",
          userId: json.containsKey("user_id") && json["user_id"] != null
              ? json["user_id"]
              : "",
          userName: json.containsKey("user_name") && json['user_name'] != null
              ? json['user_name']
              : "",
          type: json.containsKey("type") && json["type"] != null
              ? json["type"]
              : "",
          orderPlacedBy: json.containsKey("order_placed_by") &&
                  json["order_placed_by"] != null
              ? DateTime.parse(json["order_placed_by"])
              : null,
          orderStatusDate: json.containsKey("order_status_date") &&
                  json["order_status_date"] != null
              ? DateTime.parse(json["order_status_date"])
              : null,
          messageDate:
              json.containsKey("message_date") && json["message_date"] != null
                  ? DateTime.parse(json["message_date"])
                  : null,
          quotationId: json.containsKey("quotationId") && json["quotationId"] != null
              ? json["quotationId"]
              : "");

  Map<String, dynamic> toJson() => {
        "bu": bu,
        "message": messages,
        "order_placed_by": orderPlacedBy!.toIso8601String(),
        "order_status_date": orderStatusDate!.toIso8601String(),
        "user_id": userId,
        "user_name": userName,
        "type": type,
        "message_date": messageDate!.toIso8601String(),
        "quotationId":quotationId
      };
}
