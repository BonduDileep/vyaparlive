class AssignPackingDetails {
  String? assignUser;
  String? assignUserId;
  String? location;
  String? contactName;
  String? contactNumber;
  String? dispatchDate;
  String? dispatchTime;
  AssignPackingDetails(
      {this.assignUser,
      this.contactNumber,
      this.contactName,
      this.dispatchDate,
      this.dispatchTime,
      this.assignUserId,
      this.location});
  factory AssignPackingDetails.fromJson(Map<String, dynamic> json) =>
      AssignPackingDetails(
        assignUser:
            json.containsKey("assigned_user") && json["assigned_user"] != null
                ? json["assigned_user"]
                : "",
        assignUserId: json.containsKey("assigned_user_id") &&
                json["assigned_user_id"] != null
            ? json["assigned_user_id"]
            : "",
        location: json.containsKey("location") && json["location"] != null
            ? json["location"]
            : "",
        contactName:
            json.containsKey("contact_name") && json["contact_name"] != null
                ? json["contact_name"]
                : "",
        contactNumber:
            json.containsKey("contact_number") && json["contact_number"] != null
                ? json["contact_number"]
                : "",
        dispatchDate:
            json.containsKey("dispatch_date") && json["dispatch_date"] != null
                ? json["dispatch_date"]
                : "",
        dispatchTime:
            json.containsKey("dispatch_time") && json["dispatch_time"] != null
                ? json["dispatch_time"]
                : "",
      );

  Map<String, dynamic> toJson() => {
        "assigned_user": assignUser,
        "assigned_user_id": assignUserId,
        "location": location,
        "contact_name": contactName,
        "contact_number": contactNumber,
        "dispatch_date": dispatchDate,
        "dispatch_time": dispatchTime
      };
}
