class PackageDetails {
  PackageDetails({
    this.noPackages,
    this.unitPerPackage,
    this.assignedUser,
    this.assignedUserId,
    this.unitOfMesurments,
    this.packingLocation,
    this.contactName,
    this.contactNumber,
    this.dispatchTime,
    this.dispatchDate,
    this.packingImagePath,
    this.status
  });

  String? noPackages;
  String? unitPerPackage;
  String? assignedUser;
  String? assignedUserId;
  UnitOfMesurments? unitOfMesurments;
  String? packingLocation;
  String? contactName;
  String? contactNumber;
  String? dispatchDate;
  String? dispatchTime;
  String? packingImagePath;
  String? status;

  factory PackageDetails.fromJson(Map<String, dynamic> json) => PackageDetails(
      noPackages: json.containsKey("no_packages") && json["no_packages"] != null
          ? json["no_packages"]
          : "",
      unitPerPackage:
          json.containsKey("unit_per_package") && json["unit_per_package"] != null
              ? json["unit_per_package"]
              : "",
      assignedUser: json.containsKey("assigned_user") && json["assigned_user"] != null
          ? json["assigned_user"]
          : "",
      assignedUserId:
          json.containsKey("assigned_user_id") && json["assigned_user_id"] != null
              ? json["assigned_user_id"]
              : "",
      unitOfMesurments:
          json.containsKey("unit_of_mesurments") && json["unit_of_mesurments"] != null
              ? UnitOfMesurments.fromJson(json["unit_of_mesurments"])
              : null,
      packingLocation: json.containsKey("location") && json["location"] != null
          ? json["location"]
          : "",
      contactName: json.containsKey("contact_name") && json["contact_name"] != null
          ? json["contact_name"]
          : "",
      contactNumber:
          json.containsKey("contact_number") && json["contact_number"] != null
              ? json["contact_number"]
              : "",
      packingImagePath: json.containsKey("packing_image") && json["packing_image"] != null ? json["packing_image"] : "",
      dispatchTime: json.containsKey("despatch_time") && json["despatch_time"] != null ? json["despatch_time"] : "",
      dispatchDate: json.containsKey("despatch_date") && json["despatch_date"] != null ? json["despatch_date"] : "",
      status: json.containsKey("status") && json["status"] != null ? json["status"] : "");

  Map<String, dynamic> toJson() => {
        "no_packages": noPackages,
        "unit_per_package": unitPerPackage,
        "assigned_user": assignedUser,
        "assigned_user_id": assignedUserId,
        "packing_location": packingLocation,
        "contact_name": contactName,
        "contact_number": contactNumber,
        "unit_of_mesurments": unitOfMesurments!.toJson(),
        "despatch_time": dispatchTime,
        "packing_image": packingImagePath
      };
}

class UnitOfMesurments {
  UnitOfMesurments({
    this.weight,
    this.height,
    this.width,
    this.volume,
    this.length,
    this.depth,
  });

  String? weight;
  String? height;
  String? width;
  String? volume;
  String? length;
  String? depth;

  factory UnitOfMesurments.fromJson(Map<String, dynamic> json) =>
      UnitOfMesurments(
        weight: json.containsKey("weight") && json["weight"] != null
            ? json["weight"]
            : "",
        height: json.containsKey("height") && json["height"] != null
            ? json["height"]
            : "",
        width: json.containsKey("width") && json["width"] != null
            ? json["width"]
            : "",
        volume: json.containsKey("volume") && json["volume"] != null
            ? json["volume"]
            : "",
        length: json.containsKey("length") && json['length'] != null
            ? json['length']
            : "",
        depth: json.containsKey("depth") && json["depth"] != null
            ? json["depth"]
            : "",
      );

  Map<String, dynamic> toJson() => {
        "weight": weight,
        "height": height,
        "width": width,
        "volume": volume,
        'length': length,
        "depth": depth
      };
}
