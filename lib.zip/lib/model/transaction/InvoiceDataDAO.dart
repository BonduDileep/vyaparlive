import 'package:vyaparlive/model/ondc_dao/LogisticProvider.dart';
import 'package:vyaparlive/model/ondc_dao/logistic_confirmation/LogisticConfirmation.dart';
import 'package:vyaparlive/model/product_model/ImageUrl.dart';
import 'package:vyaparlive/model/TransactionsModel.dart';
import 'package:vyaparlive/model/transaction/InvoiceDetailsModel.dart';

class InvoiceDataDAO {
  dynamic invoiceNumber;
  Buyer? buyerDetails;
  Buyer? sellerDetails;
  InvoiceDetails? invoiceDetails;
  String? transactionId;
  List<ImageUrl>? imageDps;
  String? invoiceId;
  String? invoiceAttachment;
  LogisticProvider? logisticProvider;
  LogisticConfirmationDao? logisticConfirmationDao;
  InvoiceDataDAO(
      {this.buyerDetails,
      this.imageDps,
      this.invoiceNumber,
      this.invoiceDetails,
      this.invoiceId,
      this.sellerDetails,
      this.transactionId,
      this.invoiceAttachment,
      this.logisticProvider,
      this.logisticConfirmationDao});

  factory InvoiceDataDAO.fromJson(Map<String, dynamic> json) => InvoiceDataDAO(
      invoiceNumber: json.containsKey("invoice_number") && json["invoice_number"] != null
          ? json["invoice_number"]??0
          : 0,
      buyerDetails: json.containsKey("buyer") && json["buyer"] != null
          ? Buyer.fromJson(json["buyer"])
          : null,
      sellerDetails: json.containsKey("seller") && json["seller"] != null
          ? Buyer.fromJson(json["seller"])
          : null,
      invoiceDetails:
          json.containsKey("invoice_details") && json["invoice_details"] != null
              ? InvoiceDetails.fromJson(json["invoice_details"])
              : null,
      invoiceId: json.containsKey("id") && json["id"] != null ? json["id"] : "",
      transactionId: json.containsKey("txnId") && json["txnId"] != null
          ? json["txnId"]
          : "",
      imageDps: json.containsKey("image_dps") && json["image_dps"] != null
          ? List<ImageUrl>.from(
              json["image_dps"].map((e) => ImageUrl.fromJson(e)))
          : [],
      invoiceAttachment:
          json.containsKey("invoice_attachment") && json["invoice_attachment"] != null
              ? json["invoice_attachment"]
              : "",
      logisticProvider:
          json.containsKey("logistic_provider") && json["logistic_provider"] != null
              ? LogisticProvider.fromJson(json["logistic_provider"])
              : null,
      logisticConfirmationDao: json.containsKey("logistic_conformation") &&
              json["logistic_conformation"] != null
          ? LogisticConfirmationDao.fromJson(json["logistic_conformation"])
          : null);

  Map<String, dynamic> toJson() => {
        "invoice_number": invoiceNumber,
        "buyer": buyerDetails!.toJson(),
        "seller": sellerDetails!.toJson(),
        "invoice_details": invoiceDetails!.toJson(),
        "id": invoiceId,
        "txnId": transactionId,
        "image_dps": List<dynamic>.from(imageDps!.map((e) => e)),
        "invoice_attachment": invoiceAttachment,
        "logistic_provider": logisticProvider!.toJson(),
        "logistic_conformation": logisticConfirmationDao!.toJson()
      };
}
