import 'package:vyaparlive/model/TransactionsModel.dart';
import 'package:vyaparlive/model/bu_model/AddressDetailsModel.dart';
import 'package:vyaparlive/model/bu_model/ContactDetailsModel.dart';

class CtrServiceDAO {
  String? ctrType;
  ContactDetails? pickupAddress;
  Address? toAddress;
  Buyer? buyerAddress;
  Buyer? sellerAddress;
  String? contactNumber;
  String? contactName;
  String? description;

  CtrServiceDAO({
    this.buyerAddress,
    this.ctrType,
    this.pickupAddress,
    this.sellerAddress,
    this.toAddress,
    this.contactName,
    this.contactNumber,
    this.description,
  });

  factory CtrServiceDAO.fromJson(Map<String, dynamic> json) => CtrServiceDAO(
      ctrType:
          json.containsKey("type") && json["type"] != null ? json["type"] : "",
      pickupAddress: json.containsKey("pick_up_location") &&
              json["pick_up_location"] != null
          ? ContactDetails.fromJson(json["pick_up_location"])
          : null,
      toAddress:
          json.containsKey("ship_to_address") && json["ship_to_address"] != null
              ? Address.fromJson(json["ship_to_address"])
              : null,
      buyerAddress: json.containsKey("buyer") && json["buyer"] != null
          ? Buyer.fromJson(json["buyer"])
          : null,
      sellerAddress: json.containsKey("seller") && json["seller"] != null
          ? Buyer.fromJson(json["seller"])
          : null,
      contactName:
          json.containsKey("contact_name") && json["contact_name"] != null
              ? json["contact_name"]
              : "",
      contactNumber:
          json.containsKey("contact_number") && json["contact_number"] != null
              ? json["contact_number"]
              : "",
      description: json.containsKey("message") && json["message"] != null
          ? json["message"]
          : "");

  Map<String, dynamic> toJson() => {
        "type": ctrType,
        "pick_up_location": pickupAddress!.toJson(),
        "ship_to_address": toAddress!.toJson(),
        "buyer": buyerAddress!.toJson(),
        "seller": sellerAddress!.toJson(),
        "contact_name": contactName,
        "contact_number": contactNumber,
        "message": description
      };
}
