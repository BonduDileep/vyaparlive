import 'package:vyaparlive/model/InvoiceDAO.dart';

class TransactionPendingProducts {
  List<Product>? pendingProductsList;
  TransactionPendingProducts({this.pendingProductsList});
  factory TransactionPendingProducts.fromJson(Map<String, dynamic> json) =>
      TransactionPendingProducts(
        pendingProductsList:
            json.containsKey("products") && json['products'] != null
                ? List<Product>.from(
                    json['products'].map((x) => Product.fromJson(x)))
                : [],
      );

  Map<String, dynamic> toJson() => {
        "products":
            List<dynamic>.from(pendingProductsList!.map((e) => e.toJson())),
      };
}
