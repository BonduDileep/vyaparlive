class TrackingDetailsModel {
  String? docType;
  String? docNumber;
  TrackingDetailsModel({this.docNumber, this.docType});
}
