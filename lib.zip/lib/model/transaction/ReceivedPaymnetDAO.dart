class ReceivedPaymentDAO {
  String? receivedDate;
  num? receivedAmount;

  ReceivedPaymentDAO({this.receivedAmount, this.receivedDate});
  factory ReceivedPaymentDAO.fromJson(Map<String, dynamic> json) =>
      ReceivedPaymentDAO(
          receivedDate:
              json.containsKey("received_date") && json["received_date"] != null
                  ? json["received_date"]
                  : "",
          receivedAmount: json.containsKey("received_amount") &&
                  json["received_amount"] != null
              ? json["received_amount"]
              : 0);

  Map<String, dynamic> toJson() =>
      {"received_date": receivedDate, "received_amount": receivedAmount};
}
