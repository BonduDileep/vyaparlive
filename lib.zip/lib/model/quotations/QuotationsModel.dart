import 'dart:convert';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/model/bu_model/AddressDetailsModel.dart';
import 'package:vyaparlive/model/product_model/BatchPriceDAO.dart';

QuotationsModel transactionsModelFromJson(String str) =>
    QuotationsModel.fromJson(json.decode(str));

String QuotationsModelToJson(QuotationsModel data) =>
    json.encode(data.toJson());

class QuotationsModel {
  QuotationsModel(
      {this.buyer,
      this.seller,
      this.id,
      this.isOffline,
      this.quotation_details,
      this.transactionDate,
      this.challan_details,
      this.quotationNo,
      this.status,
      this.updatedDate});

  Buyer? buyer;
  Buyer? seller;
  String? id;
  bool? isOffline;
  QuotationDetails? quotation_details;
  DateTime? transactionDate;
  QuotationDetails? challan_details;
  String? quotationNo;
  String? status;
  DateTime? updatedDate;

  factory QuotationsModel.fromJson(Map<String, dynamic> json) =>
      QuotationsModel(
        buyer: json.containsKey("buyer") && json["buyer"] != null
            ? Buyer.fromJson(json["buyer"])
            : null,
        seller: json.containsKey("seller") && json["seller"] != null
            ? Buyer.fromJson(json["seller"])
            : null,
        id: json.containsKey("_id") ? json["_id"] : "",
        isOffline: json.containsKey("is_offline") && json["is_offline"] != null
            ? json["is_offline"]
            : false,
        quotation_details: json.containsKey("quotation_details") &&
                json["quotation_details"] != null
            ? QuotationDetails.fromJson(json["quotation_details"])
            : null,
        challan_details: json.containsKey("challan_details") &&
                json["challan_details"] != null
            ? QuotationDetails.fromJson(json["challan_details"])
            : null,
        transactionDate:
            json.containsKey("created_dt") && json["created_dt"] != null
                ? DateTime.parse(json["created_dt"])
                : DateTime.now(),
        quotationNo: json.containsKey("quotation_number") &&
                json["quotation_number"] != null
            ? json["quotation_number"]
            : "",
        status: json.containsKey("status") && json["status"] != null
            ? json["status"]
            : "",
        updatedDate:
            json.containsKey("updated_dt") && json["updated_dt"] != null
                ? DateTime.parse(json["updated_dt"])
                : null,
      );

  Map<String, dynamic> toJson() => {
        "buyer": buyer!.toJson(),
        "seller": seller!.toJson(),
        "is_offline": isOffline,
        "quotation_no": quotationNo,
        "_id": id,
        "quotation_details": quotation_details!.toJson(),
        "challan_details":
            challan_details != null ? challan_details!.toJson() : null,
        "created_dt": transactionDate!.toIso8601String(),
        "status": status
      };
}

class Buyer {
  Buyer({
    this.id,
    this.name,
    this.address,
    this.isOffline,
    this.gstNumber,
    this.shipToAddress,
    this.contactNumber,
    this.retailNumber,
    this.countryCode,
    this.businessName,
  });

  String? id;
  String? name;
  String? userId;
  String? userName;
  Address? address;
  bool? isOffline;
  String? gstNumber;
  Address? shipToAddress;
  String? contactNumber;
  String? retailNumber;
  String? countryCode;
  String? businessName;

  factory Buyer.fromJson(Map<String, dynamic> json) => Buyer(
      id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
      name:
          json.containsKey("name") && json["name"] != null ? json["name"] : "",
      address: json.containsKey("address") && json["address"] != null
          ? Address.fromJson(json["address"])
          : null,
      isOffline: json.containsKey("is_offline") && json["is_offline"] != null
          ? json["is_offline"]
          : false,
      gstNumber: json.containsKey("GST_No") && json["GST_No"] != null
          ? json["GST_No"]
          : "",
      shipToAddress:
          json.containsKey("ship_to_address") && json["ship_to_address"] != null
              ? Address.fromJson(json["ship_to_address"])
              : null,
      contactNumber:
          json.containsKey("contact_number") && json["contact_number"] != null
              ? json["contact_number"]
              : "",
      retailNumber:
          json.containsKey("mobile_number") && json["mobile_number"] != null
              ? json["mobile_number"]
              : "",
      businessName:
          json.containsKey("business_name") && json["business_name"] != null
              ? json["business_name"]
              : "",
      countryCode: CommonMethods.getCountryCodeFromRes(json));

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "user_id": userId,
        "user_name": userName,
        "address": address!.toJson(),
        "is_offline": isOffline,
        "GST_No": gstNumber,
        "ship_to_address": shipToAddress,
        "contact_number": contactNumber,
        "mobile_number": retailNumber,
        "country_code": countryCode
      };
}

class Product {
  Product(
      {this.id,
      this.quantity,
      this.unitPrice,
      this.total,
      this.productName,
      this.productImage,
      this.quantityIn,
      this.productCost,
      this.productTotalAmount,
      this.productTotalOffer,
      this.batchNumber,
      this.productBatches,
      this.uId,
      this.batchPricing});

  String? id;
  num? quantity;
  num? unitPrice;
  num? total;
  String? productName;
  String? productImage;
  String? quantityIn;
  num? productCost;
  num? productTotalOffer;
  num? productTotalAmount;
  String? batchNumber;
  List<BatchPriceDAO>? productBatches;
  List<BatchPriceDAO>? batchPricing;
  String? uId;

  factory Product.fromJson(Map<String, dynamic> json) => Product(
      id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
      quantity: json.containsKey("quantity") && json["quantity"] != null
          ? json["quantity"]
          : 0,
      unitPrice: json.containsKey("unit_price") && json["unit_price"] != null
          ? json["unit_price"]
          : 0,
      total: json.containsKey("total") && json["total"] != null
          ? json["total"]
          : 0,
      productName: json.containsKey("product_name") && json["product_name"] != null
          ? json["product_name"]
          : "",
      productImage: json.containsKey("product_image") && json['product_image'] != null
          ? json["product_image"]
          : "",
      quantityIn: json.containsKey("quantity_in") && json["quantity_in"] != null
          ? json["quantity_in"]
          : "",
      productCost: json.containsKey("product_cost") && json["product_cost"] != null
          ? json["product_cost"]
          : 0,
      productTotalAmount:
          json.containsKey("product_amount_total") && json["product_amount_total"] != null
              ? json["product_amount_total"]
              : 0,
      productTotalOffer: json.containsKey("product_total_offer") && json["product_total_offer"] != null
          ? json["product_total_offer"]
          : 0,
      batchNumber: json.containsKey("batch_number") && json["batch_number"] != null
          ? json["batch_number"].toString()
          : "",
      productBatches: json.containsKey("product_batches") && json["product_batches"] != null
          ? List<BatchPriceDAO>.from(json["product_batches"].map((e) => BatchPriceDAO.fromJson(e)))
          : [],
      batchPricing: json.containsKey("batch_pricing") && json["batch_pricing"] != null ? List<BatchPriceDAO>.from(json["batch_pricing"].map((e) => BatchPriceDAO.fromJson(e))) : [],
      uId: json.containsKey("u_id") && json["u_id"] != null ? json["u_id"] : "");

  Map<String, dynamic> toJson() => {
        "id": id,
        "quantity": quantity,
        "unit_price": unitPrice,
        "total": total,
        "product_name": productName,
        "product_image": productImage,
        "quantity_in": quantityIn,
        "product_total_offer": productTotalOffer,
        "product_amount_total": productTotalAmount,
        "product_cost": productCost,
        "batch_number": batchNumber,
        "product_batches":
            List<dynamic>.from(productBatches!.map((e) => e.toJson())),
        "batch_pricing":
            List<dynamic>.from(batchPricing!.map((e) => e.toJson())),
        "u_id": uId
      };
}

class QuotationDetails {
  QuotationDetails(
      {this.products,
      this.products_cost,
      this.total_offer,
      this.total_profit_value,
      this.sub_total,
      this.cgst_total,
      this.sgst_total,
      this.igst_total,
      this.total_price,
      this.final_amount});

  List<Product>? products;
  num? products_cost;
  num? total_offer;
  num? total_profit_value;
  num? sub_total;
  num? cgst_total;
  num? sgst_total;
  num? igst_total;
  num? total_price;
  num? final_amount;

  factory QuotationDetails.fromJson(Map<String, dynamic> json) =>
      QuotationDetails(
        products: json.containsKey("products") && json["products"] != null
            ? List<Product>.from(
                json["products"].map((e) => Product.fromJson(e)))
            : [],
        products_cost:
            json.containsKey("products_cost") && json["products_cost"] != null
                ? json["products_cost"]
                : 0,
        total_offer:
            json.containsKey("total_offer") && json["total_offer"] != null
                ? json["total_offer"]
                : 0,
        total_profit_value: json.containsKey("total_profit_value") &&
                json["total_profit_value"] != null
            ? json["total_profit_value"]
            : 0,
        sub_total: json.containsKey("sub_total") && json["sub_total"] != null
            ? json["sub_total"]
            : 0,
        cgst_total: json.containsKey("cgst_total") && json["cgst_total"] != null
            ? json["cgst_total"]
            : 0,
        sgst_total: json.containsKey("sgst_total") && json["sgst_total"] != null
            ? json["sgst_total"]
            : 0,
        igst_total: json.containsKey("igst_total") && json["igst_total"] != null
            ? json["igst_total"]
            : 0,
        total_price:
            json.containsKey("total_price") && json["total_price"] != null
                ? json["total_price"]
                : 0,
        final_amount:
            json.containsKey("final_amount") && json["final_amount"] != null
                ? json["final_amount"]
                : 0,
      );

  Map<String, dynamic> toJson() => {
        "products": List<dynamic>.from(products!.map((e) => e.toJson())),
        "products_cost": products_cost,
        "total_offer": total_offer,
        "total_profit_value": total_profit_value,
        "sub_total": sub_total,
        "cgst_total": cgst_total,
        "sgst_total": sgst_total,
        "igst_total": igst_total,
        "total_price": total_price,
        "final_amount": final_amount,
      };
}
