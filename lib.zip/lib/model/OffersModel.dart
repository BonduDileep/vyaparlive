class OffersModel {
  String? offerName;
  num? offerQuantity;
  num? minOrder;
  num? maxOrder;
  String? startDate;
  String? endDate;
  String? details;
  bool? isOfferActive;
  String? offerDiscount;
  String? offerId;
  bool? isOfferExpired;
  String? id;

  OffersModel(
      {this.offerName,
      this.offerQuantity,
      this.minOrder,
      this.maxOrder,
      this.startDate,
      this.endDate,
      this.isOfferActive,
      this.offerDiscount,
      this.details,
      this.offerId,
      this.isOfferExpired=false,
      this.id
      });
}
