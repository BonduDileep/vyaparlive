import 'package:vyaparlive/model/AssetsGroupModel.dart';

class ScrapListDAO {
  String? id;
  String? buId;
  String? name;
  String? scrapDeclaredDate;
  String? disposedDate;
  String? disposedValue;
  bool? isScrap;
  bool? isDisposed;
  AssetsGroupModel? groupData;
  DateTime? createdDate;

  ScrapListDAO(
      {this.buId,
      this.disposedDate,
      this.disposedValue,
      this.id,
      this.isDisposed,
      this.isScrap,
      this.name,
      this.scrapDeclaredDate,
      this.groupData,
      this.createdDate});

  factory ScrapListDAO.fromJson(Map<String, dynamic> json) => ScrapListDAO(
      buId: json.containsKey("bu_id") && json["bu_id"] != null
          ? json["bu_id"]
          : "",
      disposedDate:
          json.containsKey("disposed_date") && json["disposed_date"] != null
              ? json["disposed_date"]
              : "",
      disposedValue:
          json.containsKey("disposed_value") && json["disposed_value"] != null
              ? json["disposed_value"]
              : "",
      id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
      isDisposed: json.containsKey("disposed") && json["disposed"] != null
          ? json["disposed"]
          : false,
      isScrap: json.containsKey("is_scrap") && json["is_scrap"] != null
          ? json["is_scrap"]
          : false,
      name:
          json.containsKey("name") && json["name"] != null ? json["name"] : "",
      scrapDeclaredDate: json.containsKey("scrap_declared_date") &&
              json["scrap_declared_date"] != null
          ? json["scrap_declared_date"]
          : "",
      groupData: json.containsKey("group") && json["group"] != null
          ? AssetsGroupModel.fromJson(json["group"])
          : null,
      createdDate:
          json.containsKey("created_date") && json["created_date"] != null
              ? DateTime.parse(json["created_date"])
              : DateTime.now());

  Map<String, dynamic> toJson() => {
        "id": id,
        "bu_id": buId,
        "name": name,
        "is_scrap": isScrap,
        "scrap_declared_date": scrapDeclaredDate,
        "disposed": isDisposed,
        "disposed_date": disposedDate,
        "disposed_value": disposedValue,
        "group": groupData!.toJson(),
        "created_date": createdDate!.toIso8601String()
      };
}
