class TaxInfoModel {
  String? taxName;
  String? taxId;
  String? taxReason;
  int? count;

  TaxInfoModel({this.taxName, this.taxId, this.taxReason, this.count});
}
