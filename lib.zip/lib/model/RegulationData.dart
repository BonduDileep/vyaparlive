class RegulationData {
  String? govtbusinessSchemeid;
  String? govtregistrationId;

  RegulationData({this.govtbusinessSchemeid, this.govtregistrationId});
}
