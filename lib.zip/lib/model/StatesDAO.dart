// To parse this JSON data, do
//
//     final statesDao = statesDaoFromJson(jsonString);

import 'dart:convert';

StatesDAO statesDaoFromJson(String str) => StatesDAO.fromJson(json.decode(str));

String statesDaoToJson(StatesDAO data) => json.encode(data.toJson());

class StatesDAO {
  StatesDAO({
    this.id,
    this.state,
    this.cities,
  });

  String? id;
  String? state;
  List<String>? cities;

  factory StatesDAO.fromJson(Map<String, dynamic> json) => StatesDAO(
        id: json.containsKey('id') && json['id'] != null ? json["id"] : "",
        state: json.containsKey('state') && json['state'] != null
            ? json["state"]
            : "",
        cities: json.containsKey('districts') && json['districts'] != null
            ? List<String>.from(json["districts"].map((x) => x))
            : [],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "state": state,
        "districts": List<dynamic>.from(cities!.map((x) => x)),
      };
}
