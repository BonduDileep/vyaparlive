import 'dart:convert';

import 'package:vyaparlive/model/ExpensesDAO.dart';
import 'package:vyaparlive/model/RolesDAO.dart';
import 'package:vyaparlive/model/bu_model/BankDetailsModel.dart';
import 'package:vyaparlive/model/bu_model/ContactDetailsModel.dart';
import 'package:vyaparlive/model/bu_model/DirectorDetailsModel.dart';
import 'package:vyaparlive/model/bu_model/ExportsModel.dart';
import 'package:vyaparlive/model/bu_model/InvoiceTemplateDAO.dart';
import 'package:vyaparlive/model/bu_model/LocationsModel.dart';
import 'package:vyaparlive/model/bu_model/ParentDetailsModel.dart';
import 'package:vyaparlive/model/bu_model/PaymentTermsModel.dart';
import 'package:vyaparlive/model/bu_model/RegistrationDetailsModel.dart';
import 'package:vyaparlive/model/bu_model/RegulationDetailsModel.dart';
import 'package:vyaparlive/model/bu_model/StockDispatchModel.dart';
import 'package:vyaparlive/model/bu_model/StockReceiveModel.dart';
import 'package:vyaparlive/model/bu_model/TaxSchemeModel.dart';
import 'package:vyaparlive/model/bu_model/YrDetailsModel.dart';
import 'package:vyaparlive/model/bu_model/YrSubscriptionModel.dart';

BusinessUnitModel businessUnitModelFromJson(String str) =>
    BusinessUnitModel.fromJson(json.decode(str));

String businessUnitModelToJson(BusinessUnitModel data) =>
    json.encode(data.toJson());

class BusinessUnitModel {
  BusinessUnitModel(
      {this.userId,
      this.businessName,
      this.shortName,
      this.website,
      this.businessHob,
      this.businessLocation,
      this.type,
      this.buContactNumber,
      this.mobileNumber,
      this.countryCode,
      this.currencyCode,
      this.createdDate,
      this.createdBy,
      this.updatedDate,
      this.updatedBy,
      this.registration,
      this.directors,
      this.taxScheme,
      this.parentDetails,
      this.contactDetails,
      this.regulation,
      this.exports,
      this.imports,
      this.paymentTerms,
      this.stockReceiveLocations,
      this.stockDispatchLocations,
      this.bankDetailsReceives,
      this.bankDetailsPayments,
      this.yrDetails,
      this.root,
      this.id,
      this.rolesList,
      this.expensesList,
      this.subscription,
      this.locationsList,
      this.isInpersonOrderAccept,
      this.orgGstNumber,
      this.invoiceTemplate,
      this.dialCode,
      this.officeDialCode,
      this.currencyName,
      this.currencySymbol,
      this.emailAddress,
      this.panNumber,
      this.buLogoImagePath});

  String? userId;
  String? businessName;
  String? shortName;
  String? website;
  String? businessHob;
  String? businessLocation;
  String? type;
  String? buContactNumber;
  String? mobileNumber;
  String? countryCode;
  String? currencyCode;
  String? createdDate;
  String? createdBy;
  String? updatedDate;
  String? updatedBy;
  Registration? registration;
  List<Directors>? directors;
  List<TaxScheme>? taxScheme;
  ParentDetails? parentDetails;
  ContactDetails? contactDetails;
  List<Regulation>? regulation;
  List<Ports>? exports;
  List<Ports>? imports;
  PaymentTerms? paymentTerms;
  List<StockReceiveLocations>? stockReceiveLocations;
  List<StockDispatchLocations>? stockDispatchLocations;
  List<BankDetail>? bankDetailsReceives;
  List<BankDetail>? bankDetailsPayments;
  YrDetails? yrDetails;
  List<ExpensesDAO>? expensesList;
  List<RolesDAO>? rolesList;
  var root; //int? root;
  String? id;
  List<Locations>? locationsList;
  List<YrSubscriptions>? subscription;
  bool? isInpersonOrderAccept;
  String? orgGstNumber;
  InvoiceTemplateDAO? invoiceTemplate;
  String? dialCode;
  String? officeDialCode;
  String? currencyName;
  String? currencySymbol;
  String? emailAddress;
  String? panNumber;
  String? buLogoImagePath;

  factory BusinessUnitModel.fromJson(Map<String, dynamic> json) =>
      BusinessUnitModel(
          userId: (json.containsKey("user_id") && json["user_id"] != null)
              ? json["user_id"]
              : "",
          businessName:
              json.containsKey("business_name") && json["business_name"] != null
                  ? json["business_name"]
                  : "",
          shortName: json.containsKey("short_name") && json["short_name"] != null
              ? json["short_name"]
              : "",
          website: json.containsKey("website") && json["website"] != null
              ? json["website"]
              : "",
          businessHob: json.containsKey("head_of_business") && json["head_of_business"] != null
              ? json["head_of_business"]
              : "",
          businessLocation: json.containsKey("location") && json["location"] != null
              ? json["location"]
              : "",
          type: json.containsKey("type") && json["type"] != null
              ? json["type"]
              : "",
          buContactNumber:
              json.containsKey("contact_number") && json["contact_number"] != null
                  ? json["contact_number"]
                  : "",
          mobileNumber:
              json.containsKey("mobile_number") && json["mobile_number"] != null
                  ? json["mobile_number"]
                  : "",
          countryCode: json.containsKey("country_code") && json["country_code"] != null
              ? json["country_code"]
              : "",
          currencyCode:
              json.containsKey("currency_code") && json["currency_code"] != null
                  ? json["currency_code"]
                  : "",
          createdDate: json.containsKey("created_date") && json["created_date"] != null ? json["created_date"] : "",
          createdBy: json.containsKey("created_by") && json["created_by"] != null ? json["created_by"] : "",
          updatedDate: json.containsKey("updated_date") && json["updated_date"] != null ? json["updated_date"] : "",
          updatedBy: json.containsKey("updated_by") && json["updated_by"] != null ? json["updated_by"] : "",
          registration: (json.containsKey("registration") && json["registration"] != null) ? Registration.fromJson(json["registration"]) : null,
          directors: (json.containsKey("directors") && json["directors"] != null) ? List<Directors>.from(json["directors"].map((x) => Directors.fromJson(x))) : [],
          taxScheme: json.containsKey("tax_scheme") && json["tax_scheme"] != null ? List<TaxScheme>.from(json["tax_scheme"].map((x) => TaxScheme.fromJson(x))) : [],
          parentDetails: (json.containsKey("parent_details") && json["parent_details"] != null) ? ParentDetails.fromJson(json["parent_details"]) : null,
          contactDetails: json.containsKey("contact_details") && json["contact_details"] != null ? ContactDetails.fromJson(json["contact_details"]) : null,
          regulation: json.containsKey("regulation") && json["regulation"] != null ? List<Regulation>.from(json["regulation"].map((x) => Regulation.fromJson(x))) : [],
          exports: json.containsKey("exports") && json["exports"] != null ? List<Ports>.from(json["exports"].map((x) => Ports.fromJson(x))) : [],
          imports: json.containsKey("imports")
              ? json["imports"] != null
                  ? List<Ports>.from(json["imports"].map((x) => Ports.fromJson(x)))
                  : []
              : "" as List<Ports>?,
          paymentTerms: json.containsKey("payment_terms") && json["payment_terms"] != null ? PaymentTerms.fromJson(json["payment_terms"]) : null,
          stockReceiveLocations: json.containsKey("stock_receive_locations") && json["stock_receive_locations"] != null ? List<StockReceiveLocations>.from(json["stock_receive_locations"].map((x) => StockReceiveLocations.fromJson(x))) : [],
          stockDispatchLocations: json.containsKey("stock_dispatch_locations") && json["stock_dispatch_locations"] != null ? List<StockDispatchLocations>.from(json["stock_dispatch_locations"].map((x) => StockDispatchLocations.fromJson(x))) : [],
          bankDetailsReceives: json.containsKey("bank_details_receives") && json["bank_details_receives"] != null ? List<BankDetail>.from(json["bank_details_receives"].map((x) => BankDetail.fromJson(x))) : [],
          bankDetailsPayments: json.containsKey("bank_details_payments") && json["bank_details_payments"] != null ? List<BankDetail>.from(json["bank_details_payments"].map((x) => BankDetail.fromJson(x))) : [],
          yrDetails: json.containsKey("yr_details") && json["yr_details"] != null ? YrDetails.fromJson(json["yr_details"]) : null,
          rolesList: json.containsKey("roles") && json["roles"] != null ? List<RolesDAO>.from(json["roles"].map((x) => RolesDAO.fromJson(x))) : [],
          root: json.containsKey("root") && json["root"] != null ? json["root"] : null, //0,
          id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
          locationsList: json.containsKey("locations") ? List<Locations>.from(json["locations"].map((x) => Locations.fromJson(x))) : [],
          expensesList: json.containsKey("expenses") && json["expenses"] != null ? List<ExpensesDAO>.from(json["expenses"].map((x) => ExpensesDAO.fromJson(x))) : [],
          subscription: json.containsKey("yr_subscription") && json["yr_subscription"] != null ? List<YrSubscriptions>.from(json["yr_subscription"].map((x) => YrSubscriptions.fromJson(x))) : [],
          isInpersonOrderAccept: json.containsKey("confirm_order") && json["confirm_order"] != null ? json["confirm_order"] : false,
          orgGstNumber: json.containsKey("GST_No") && json["GST_No"] != null ? json["GST_No"] : "",
          invoiceTemplate: json.containsKey("invoice_template") && json["invoice_template"] != null ? InvoiceTemplateDAO.fromJson(json["invoice_template"]) : null,
          dialCode: json.containsKey("dial_code") && json["dial_code"] != null ? json["dial_code"] : "",
          officeDialCode: json.containsKey("office_dial_code") && json["office_dial_code"] != null ? json["office_dial_code"] : "",
          currencyName: json.containsKey("currency_name") && json["currency_name"] != null ? json["currency_name"] : "",
          currencySymbol: json.containsKey("currency_symbol") && json['currency_symbol'] != null ? json['currency_symbol'] : "",
          emailAddress: json.containsKey("email_id") && json["email_id"] != null ? json['email_id'] : "",
          panNumber: json.containsKey("pan_no") && json["pan_no"] != null ? json["pan_no"] : "",
          buLogoImagePath: json.containsKey("bu_logo_image") && json["bu_logo_image"] != null ? json["bu_logo_image"] : "");

  Map<String, dynamic> toJson() => {
        "user_id": userId,
        "business_name": businessName,
        "short_name": shortName,
        "website": website,
        "mobile_number": mobileNumber,
        "type": type,
        "country_code": countryCode,
        "currency_code": currencyCode,
        "created_date": createdDate,
        "created_by": createdBy,
        "updated_date": updatedDate,
        "updated_by": updatedBy,
        "registration": registration!.toJson(),
        "directors": List<dynamic>.from(directors!.map((e) => e.toJson())),
        "expenses": List<dynamic>.from(expensesList!.map((e) => e.toJson())),
        "tax_scheme": List<dynamic>.from(taxScheme!.map((e) => e.toJson())),
        "contact_details": contactDetails!.toJson(),
        "regulation": List<dynamic>.from(regulation!.map((e) => e.toJson())),
        "exports": List<dynamic>.from(exports!.map((e) => e.toJson())),
        "imports": List<dynamic>.from(imports!.map((e) => e.toJson())),
        "payment_terms": paymentTerms!.toJson(),
        "stock_receive_locations":
            List<dynamic>.from(stockReceiveLocations!.map((e) => e.toJson())),
        "stock_dispatch_locations":
            List<dynamic>.from(stockDispatchLocations!.map((e) => e.toJson())),
        "bank_details_receives":
            List<dynamic>.from(bankDetailsReceives!.map((e) => e.toJson())),
        "bank_details_payments":
            List<dynamic>.from(bankDetailsPayments!.map((e) => e.toJson())),
        "yr_details": yrDetails!.toJson(),
        "roles": List<dynamic>.from(rolesList!.map((x) => x.toJson())),
        "root": root,
        "id": id,
        "yr_subscription":
            List<dynamic>.from(subscription!.map((e) => e.toJson())),
        "locations": List<dynamic>.from(locationsList!.map((e) => e.toJson())),
        "confirm_order": isInpersonOrderAccept,
        "GST_No": orgGstNumber,
        "invoice_template": invoiceTemplate!.toJson(),
        "dial_code": dialCode,
        "office_dial_code": officeDialCode,
        "currency_name": currencyName,
        "currency_symbol": currencySymbol,
        "pan_no": panNumber,
        "email_id": emailAddress,
        "bu_logo_image": buLogoImagePath
      };
}
