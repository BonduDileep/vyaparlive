class PriceModel {
  String? batchNumber;
  String? manufacturDate;
  String? expireDate;
  String? price;
  String? priceIn;
  String? mrp;
  String? netRate;
  String? currencyName;
  String? quantity;
  String? quantityIn;
  String? issuedId;
  String? issuedTo;
  bool? isRawMaterial;
  bool? isActualProduct;
  String? description;
  num? issueNumber;
  String? batchUpdatedBy;
  DateTime? batchUpdatedDate;
  String? barcode;
  String? quantity_value;
  String? quantity_unit;

  PriceModel(
      {this.batchNumber,
      this.currencyName,
      this.expireDate,
      this.manufacturDate,
      this.mrp,
      this.netRate,
      this.price,
      this.quantity,
      this.quantityIn,
      this.priceIn,
      this.issuedId,
      this.issuedTo,
      this.isRawMaterial = false,
      this.isActualProduct = false,
      this.description,
      this.issueNumber,
      this.batchUpdatedBy,
      this.batchUpdatedDate,
      this.barcode,
      this.quantity_value,
      this.quantity_unit});
}
