class BuyProductReportsDAO {
  String? id;
  String? name;
  num? buyQuantity;
  num? soldQuantity;
  String? buId;

  BuyProductReportsDAO(
      {this.buId, this.buyQuantity, this.id, this.name, this.soldQuantity});

  factory BuyProductReportsDAO.fromJson(Map<String, dynamic> json) =>
      BuyProductReportsDAO(
          id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
          name: json.containsKey("name") && json["name"] != null
              ? json["name"]
              : "",
          buId: json.containsKey("bu_id") && json["bu_id"] != null
              ? json["bu_id"]
              : "",
          soldQuantity:
              json.containsKey("sold_quantity") && json["sold_quantity"] != null
                  ? json["sold_quantity"]
                  : 0,
          buyQuantity:
              json.containsKey("buy_quantity") && json["buy_quantity"] != null
                  ? json["buy_quantity"]
                  : 0);

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "bu_id": buId,
        "sold_quantity": soldQuantity,
        "buy_quantity": buyQuantity
      };
}
