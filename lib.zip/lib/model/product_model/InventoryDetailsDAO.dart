import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/model/product_model/BatchPriceDAO.dart';
import 'package:vyaparlive/model/product_model/TransitDetailsDAO.dart';

class InventoryDetailsDAO {
  InventoryDetailsDAO(
      {this.locationName,
      this.quantity,
      this.transitData,
      this.batchNumber,
      this.quantityIn,
      this.locationBatchList,
      this.quantityAdjustmentReason,
      this.locationId,
      this.updatedDate,
      this.updatedUser});
  String? locationName;
  num? quantity;
  List<TransitDetailsDAO>? transitData;
  String? batchNumber;
  String? quantityIn;
  List<BatchPriceDAO>? locationBatchList;
  String? quantityAdjustmentReason;
  String? locationId;
  String? updatedUser;
  String? updatedDate;

  factory InventoryDetailsDAO.fromJson(Map<String, dynamic> json) =>
      InventoryDetailsDAO(
          locationName:
              json.containsKey("location_name") && json["location_name"] != null
                  ? json["location_name"]
                  : "",
          quantity: json.containsKey("quantity") && json["quantity"] != null
              ? json["quantity"]
              : 0,
          transitData: json.containsKey("transit") && json["transit"] != null
              ? List<TransitDetailsDAO>.from(
                  json["transit"].map((x) => TransitDetailsDAO.fromJson(x)))
              : [],
          batchNumber: CommonMethods.getBatchNumberFromRes(json),
          // json.containsKey("batch_no") && json["batch_no"] != null
          //     ? json["batch_no"]
          //     : "",
          quantityIn: json.containsKey("quantity_in") && json["quantity_in"] != null
              ? json["quantity_in"]
              : "",
          locationBatchList: json.containsKey("location_batch_list") &&
                  json["location_batch_list"] != null
              ? List<BatchPriceDAO>.from(json['location_batch_list']
                  .map((e) => BatchPriceDAO.fromJson(e)))
              : [],
          locationId: json.containsKey("location_id") && json["location_id"] != null
              ? json["location_id"]
              : "",
          updatedDate:
              json.containsKey("updated_date") && json["updated_date"] != null
                  ? json["updated_date"]
                  : "",
          updatedUser:
              json.containsKey("updated_user") && json["updated_user"] != null
                  ? json["updated_user"]
                  : "");

  Map<String, dynamic> toJson() => {
        "location_name": locationName,
        "quantity": quantity,
        "transit": List<dynamic>.from(transitData!.map((e) => e.toJson())),
        "batch_no": batchNumber,
        "quantity_in": quantityIn,
        "location_batch_list":
            List<dynamic>.from(locationBatchList!.map((e) => e.toJson())),
        "location_id": locationId,
        "updated_user": updatedUser,
        "updated_date": updatedDate
      };
}
