class OffersDAO {
  OffersDAO(
      {this.offerName,
      this.offerQuantity,
      this.minOrder,
      this.maxOrder,
      this.startDate,
      this.endDate,
      this.details,
      this.isOfferActive,
      this.offerId,
      this.offerType,
      this.isOfferExpired});

  String? offerName;
  num? offerQuantity;
  num? minOrder;
  num? maxOrder;
  String? startDate;
  String? endDate;
  String? details;
  bool? isOfferActive;
  String? offerType;
  String? offerId;
  bool? isOfferExpired;

  factory OffersDAO.fromJson(Map<String, dynamic> json) => OffersDAO(
      offerName: json.containsKey("offer_name") && json["offer_name"] != null
          ? json["offer_name"]
          : "",
      offerQuantity:
          json.containsKey("offer_quantity") && json["offer_quantity"] != null
              ? json["offer_quantity"]
              : 0,
      minOrder: json.containsKey("min_order") && json["min_order"] != null
          ? json["min_order"]
          : 0,
      maxOrder: json.containsKey("max_order") && json["max_order"] != null
          ? json["max_order"]
          : 0,
      startDate: json.containsKey("start_date") && json["start_date"] != null
          ? json["start_date"]
          : "",
      endDate: json.containsKey("end_date") && json["end_date"] != null
          ? json["end_date"]
          : "",
      details: json.containsKey("details") && json["details"] != null
          ? json["details"]
          : "",
      offerId: json.containsKey("offer_id") && json["offer_id"] != null
          ? json["offer_id"]
          : "",
      isOfferActive:
          json.containsKey("is_offer_active") && json["is_offer_active"] != null
              ? json["is_offer_active"]
              : false,
      offerType: json.containsKey("offer_type") && json["offer_type"] != null
          ? json["offer_type"]
          : "",
      isOfferExpired:
          json.containsKey("is_offer_expire") && json["is_offer_expire"] != null
              ? json["is_offer_expire"]
              : false);

  Map<String, dynamic> toJson() => {
        "offer_name": offerName,
        "offer_quantity": offerQuantity,
        "min_order": minOrder,
        "max_order": maxOrder,
        "start_date": startDate,
        "end_date": endDate,
        "details": details,
        "offer_id": offerId,
        "is_offer_expire": isOfferExpired
      };
}
