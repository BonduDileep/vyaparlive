import 'package:flutter/cupertino.dart';
import 'package:vyaparlive/model/stock_returns/GoodsInvoiceModel.dart';

class BatchPriceDAO {
  num? price;
  String? unitPrice;
  String? currencyName;
  String? batchNumber;
  num? quantity;
  String? quantityIn;
  num? netRate;
  num? mrp;
  String? manufactureDate;
  String? expiryDate;
  String? issuedTo;
  bool? isRawMaterial;
  bool? isActualProduct;
  String? description;
  num? issueNumber;
  String? issueId;
  String? updatedUser;
  String? updatedDate;
  bool isBatchChecked;
  List<TextEditingController>? listTextControllers;
  List<String>? listStructureMessages;
  List<GoodsInvoiceModel> invoiceList;
  List<DateTime> invoiceDate;
  List<String> invoiceId;
  List<String> transactionId;
  num totalReturnProducts;
  final String internalId = UniqueKey().toString();
  String? barcode;
  BatchPriceDAO(
      {this.batchNumber,
      this.currencyName,
      this.expiryDate,
      this.manufactureDate,
      this.mrp,
      this.netRate,
      this.price,
      this.quantity,
      this.quantityIn,
      this.unitPrice,
      this.isActualProduct,
      this.isRawMaterial,
      this.issuedTo,
      this.description,
      this.issueNumber,
      this.issueId,
      this.updatedUser,
      this.updatedDate,
      this.isBatchChecked = false,
      this.listStructureMessages,
      this.listTextControllers,
      this.totalReturnProducts = 0,
      this.barcode})
      : this.invoiceDate = [],
        this.invoiceList = [],
        this.invoiceId = [],
        this.transactionId = [];

  // Copy constructor
  BatchPriceDAO.clone(BatchPriceDAO source)
      : batchNumber = source.batchNumber,
        currencyName = source.currencyName,
        expiryDate = source.expiryDate,
        manufactureDate = source.manufactureDate,
        mrp = source.mrp,
        netRate = source.netRate,
        price = source.price,
        quantity = source.quantity,
        quantityIn = source.quantityIn,
        unitPrice = source.unitPrice,
        isActualProduct = source.isActualProduct,
        isRawMaterial = source.isRawMaterial,
        issuedTo = source.issuedTo,
        description = source.description,
        issueNumber = source.issueNumber,
        issueId = source.issueId,
        updatedUser = source.updatedUser,
        updatedDate = source.updatedDate,
        isBatchChecked = source.isBatchChecked,
        listStructureMessages = source.listStructureMessages != null
            ? List.from(source.listStructureMessages!)
            : null,
        listTextControllers = source.listTextControllers != null
            ? List.from(source.listTextControllers!)
            : null,
        totalReturnProducts = source.totalReturnProducts,
        barcode = source.barcode,
        invoiceDate = List.from(source.invoiceDate),
        invoiceList = List.from(source.invoiceList),
        invoiceId = List.from(source.invoiceId),
        transactionId = List.from(source.transactionId);

  factory BatchPriceDAO.fromJson(Map<String, dynamic> json) => BatchPriceDAO(
      batchNumber:
          json.containsKey("batch_number") && json["batch_number"] != null
              ? (json["batch_number"].runtimeType == int)
                  ? json["batch_number"].toString()
                  : json["batch_number"]
              : "",
      currencyName: json.containsKey("currency_name") && json["currency_name"] != null
          ? json["currency_name"]
          : "",
      expiryDate: json.containsKey("expiry_date") && json["expiry_date"] != null
          ? json["expiry_date"]
          : "",
      manufactureDate: json.containsKey("manufacture_date_time") &&
              json["manufacture_date_time"] != null
          ? json["manufacture_date_time"]
          : "",
      mrp: json.containsKey("mrp") && json["mrp"] != null ? json["mrp"] : 0,
      netRate: json.containsKey("net_rate") && json["net_rate"] != null
          ? json["net_rate"]
          : 0,
      price: json.containsKey("price") && json["price"] != null
          ? json["price"]
          : 0,
      quantity: json.containsKey("quantity") && json["quantity"] != null
          ? (json["quantity"] is String)
              ? num.parse(json["quantity"])
              : json["quantity"]
          : 0,
      quantityIn: json.containsKey("quantity_in") && json["quantity_in"] != null
          ? json["quantity_in"]
          : "",
      unitPrice:
          json.containsKey("unit") && json["unit"] != null ? json["unit"] : "",
      isActualProduct:
          json.containsKey("is_actual_product") && json["is_actual_product"] != null
              ? json["is_actual_product"]
              : false,
      isRawMaterial:
          json.containsKey("is_raw_material") && json["is_raw_material"] != null
              ? json["is_raw_material"]
              : false,
      issuedTo: json.containsKey("issued_to") && json["issued_to"] != null
          ? json["issued_to"]
          : "",
      description:
          json.containsKey("price_description") && json["price_description"] != null
              ? json["price_description"]
              : "",
      issueNumber: json.containsKey("issue_number") && json["issue_number"] != null
          ? json["issue_number"]
          : 0,
      issueId: json.containsKey("issue_id") && json["issue_id"] != null ? json["issue_id"] : "",
      updatedUser: json.containsKey("updated_user") && json["updated_user"] != null ? json["updated_user"] : "",
      updatedDate: json.containsKey("updated_date") && json["updated_date"] != null ? json["updated_date"] : null,
      barcode: json.containsKey("barcode") && json["barcode"] != null ? json["barcode"] : "",
      );

  Map<String, dynamic> toJson() => {
        "batch_number": batchNumber,
        "currency_name": currencyName,
        "expiry_date": expiryDate,
        "manufacture_date_time": manufactureDate,
        "mrp": mrp,
        "net_rate": netRate,
        "price": price,
        "quantity": quantity,
        "quantity_in": quantityIn,
        "unit": unitPrice,
        "issued_to": issuedTo,
        "is_raw_material": isRawMaterial,
        "is_actual_product": isActualProduct,
        "price_description": description,
        "issue_number": issueNumber,
        "issue_id": issueId,
        "updated_date": updatedDate,
        "updated_user": updatedUser
      };

  @override
  bool operator ==(Object other) {
    return other is BatchPriceDAO && other.internalId == internalId;
  }

  @override
  int get hashCode => internalId.hashCode;
}
