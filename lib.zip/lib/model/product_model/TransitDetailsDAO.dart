class TransitDetailsDAO {
  TransitDetailsDAO(
      {this.billNo,
      this.quantity,
      this.invoiceNumber,
      this.productQuantity,
      this.invoiceId,
      this.transactionId});

  dynamic billNo;
  num? quantity;
  num? invoiceNumber;
  num? productQuantity;
  String? invoiceId;
  String? transactionId;
  factory TransitDetailsDAO.fromJson(Map<String, dynamic> json) =>
      TransitDetailsDAO(
          billNo: json.containsKey("bill_no") && json["bill_no"] != null
              ? json["bill_no"]??0
              : 0,
          quantity: json.containsKey("transit") && json["transit"] != null
              ? json["transit"]
              : 0,
          invoiceNumber: json.containsKey("invoice_number") &&
                  json["invoice_number"] != null
              ? json["invoice_number"]
              : 0,
          productQuantity: json.containsKey("product_quantity") &&
                  json["product_quantity"] != null
              ? json["product_quantity"]
              : 0,
          invoiceId:
              json.containsKey("invoice_id") && json["invoice_id"] != null
                  ? json["invoice_id"]
                  : "",
          transactionId:
              json.containsKey("transactionId") && json['transactionId'] != null
                  ? json['transactionId']
                  : "");

  Map<String, dynamic> toJson() => {
        "bill_no": billNo,
        "transit": quantity,
        "product_quantity": productQuantity,
        "invoice_number": invoiceNumber,
        "invoice_id": invoiceId,
        'transactionId': transactionId
      };
}
