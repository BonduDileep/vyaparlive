class ShippingDetailsDAO {
  ShippingDetailsDAO(
      {this.weight, this.width, this.height, this.depth, this.volume});

  String? weight;
  String? width;
  String? height;
  String? depth;
  String? volume;

  factory ShippingDetailsDAO.fromJson(Map<String, dynamic> json) =>
      ShippingDetailsDAO(
          weight: json.containsKey("weight") && json["weight"] != null
              ? json["weight"]
              : "",
          width: json.containsKey("width") && json["width"] != null
              ? json["width"]
              : "",
          height: json.containsKey("height") && json["height"] != null
              ? json["height"]
              : "",
          depth: json.containsKey("depth") && json["depth"] != null
              ? json["depth"]
              : "",
          volume: json.containsKey("volume") && json["volume"] != null
              ? json["volume"]
              : "");

  Map<String, dynamic> toJson() => {
        "weight": weight,
        "width": width,
        "height": height,
        "depth": depth,
        "volume": volume
      };
}
