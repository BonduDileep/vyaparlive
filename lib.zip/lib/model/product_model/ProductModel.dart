import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/model/RawInventory.dart';
import 'package:vyaparlive/model/ondc_dao/OndcFeaturesDAO.dart';
import 'package:vyaparlive/model/product_model/BatchPriceDAO.dart';
import 'package:vyaparlive/model/product_model/ImageUrl.dart';
import 'package:vyaparlive/model/product_model/InventoryDetailsDAO.dart';
import 'package:vyaparlive/model/product_model/ManufactureDetailsDAO.dart';
import 'package:vyaparlive/model/product_model/OffersDAO.dart';
import 'package:vyaparlive/model/product_model/QuantityAdjustmentDAO.dart';
import 'package:vyaparlive/model/product_model/ShippingDetailsDAO.dart';
import 'package:vyaparlive/model/product_model/SupplierDAO.dart';
import 'package:vyaparlive/model/product_model/TaxDetailsDAO.dart';
import 'package:vyaparlive/model/product_model/TransitDetailsDAO.dart';

class BuProductModal {
  BuProductModal(
      {this.buId,
      this.sku,
      this.type,
      this.name,
      this.brand,
      this.description,
      this.productSegment,
      this.productCategory,
      this.productSubCategory,
      this.productType,
      this.productSubType,
      this.batchNumber,
      this.manufactureDateTime,
      this.expiryDate,
      this.images,
      this.attributes,
      this.manufactureDetails,
      this.suppliers,
      this.shippingDetails,
      this.tax,
      this.offers,
      this.collection,
      this.id,
      this.inventoryData,
      this.inStock,
      this.quantityIn,
      this.forSale,
      this.imageThumbnail,
      this.transitList,
      this.batchPrice,
      this.rawInventoryData,
      this.isFromRawMaterial,
      this.isRawProduct,
      this.quantityAdjustList,
      this.productSector,
      this.isProductSelected = false,
      this.totalSoldQuantity,
      this.publishToOndc,
      // this.ondcFeatures,
      this.ondcFeatureDao,
      this.barcode});

  String? buId;
  String? sku;
  String? type;
  String? name;
  String? brand;
  String? description;
  String? productSegment;
  String? productCategory;
  String? productSubCategory;
  String? productType;
  String? productSubType;
  String? batchNumber;
  DateTime? manufactureDateTime;
  DateTime? expiryDate;
  String? images;
  List? attributes;
  // List? ondcFeatures;
  ManufactureDetailsDAO? manufactureDetails;
  List<SupplierDAO>? suppliers;
  ShippingDetailsDAO? shippingDetails;
  String? quantityIn;
  List<BatchPriceDAO>? batchPrice;
  TaxDetailsDAO? tax;
  List<OffersDAO>? offers;
  String? collection;
  List<TransitDetailsDAO>? transitList;
  String? id;
  List<InventoryDetailsDAO>? inventoryData;
  bool? inStock;
  bool? forSale;
  List<ImageUrl>? imageThumbnail;
  List<RawInventory>? rawInventoryData;
  bool? isRawProduct;
  bool? isFromRawMaterial;
  num? soldQuantity;
  List<QuantityAdjustmentDAO>? quantityAdjustList;
  String? productSector;
  bool? isProductSelected;
  num? totalSoldQuantity;
  bool? publishToOndc;
  List<OndcFeaturesDAO>? ondcFeatureDao;
  String? barcode;

  factory BuProductModal.fromJson(Map<String, dynamic> json) => BuProductModal(
      buId: json.containsKey("bu_id") && json["bu_id"] != null
          ? json["bu_id"]
          : "",
      sku: json.containsKey("sku") && json["sku"] != null ? json["sku"] : "",
      type:
          json.containsKey("type") && json["type"] != null ? json["type"] : "",
      name: CommonMethods.getProductNameFromRes(json),
      // json.containsKey("name") && json["name"] != null ? json["name"] : "",
      brand: json.containsKey("brand") && json["brand"] != null
          ? json["brand"]
          : "",
      inStock: json.containsKey("in_stock") && json["in_stock"] != null
          ? AppUtills.parseBool(json["in_stock"])
          : false,
      forSale: json.containsKey("for_sale") && json["for_sale"] != null
          ? AppUtills.parseBool(json["for_sale"])
          : false,
      description: json.containsKey("description") && json["description"] != null
          ? json["description"]
          : "",
      productSegment: json.containsKey("product_segment") && json["product_segment"] != null
          ? json["product_segment"]
          : "",
      productCategory: json.containsKey("product_category") && json["product_category"] != null
          ? json["product_category"]
          : "",
      productSubCategory: json.containsKey("product_sub_category") && json["product_sub_category"] != null
          ? json["product_sub_category"]
          : "",
      productType: json.containsKey("product_type") && json["product_type"] != null
          ? json["product_type"]
          : "",
      productSubType: json.containsKey("product_sub_type") && json["product_sub_type"] != null
          ? json["product_sub_type"]
          : "",
      batchNumber: json.containsKey("batch_number") && json["batch_number"] != null
          ? json["batch_number"]
          : "",
      manufactureDateTime:
          json.containsKey("manufacture_date_time") && json["manufacture_date_time"] != null
              ? DateTime.tryParse(json["manufacture_date_time"])
              : DateTime.now(),
      expiryDate: json.containsKey("expiry_date") && json["expiry_date"] != null
          ? DateTime.tryParse(json["expiry_date"])
          : DateTime.now(),
      images: json.containsKey("images") ? json["images"] : null,
      attributes: json.containsKey("attributes") && json["attributes"] != null ? List.from(json["attributes"].map((x) => x)) : [],
      manufactureDetails: json.containsKey("manufacture_details") && json["manufacture_details"] != null ? ManufactureDetailsDAO.fromJson(json["manufacture_details"]) : null,
      suppliers: json.containsKey("suppliers") && json["suppliers"] != null ? List<SupplierDAO>.from(json["suppliers"].map((x) => SupplierDAO.fromJson(x))) : [],
      batchPrice: CommonMethods.getProductBatchListFromRes(json),
      //json.containsKey("batch_pricing") && json["batch_pricing"] != null ? List<BatchPriceDAO>.from(json["batch_pricing"].map((e) => BatchPriceDAO.fromJson(e))) : [],
      shippingDetails: json.containsKey("shipping_details") && json["shipping_details"] != null ? ShippingDetailsDAO.fromJson(json["shipping_details"]) : null,
      quantityIn: json.containsKey("quantity_in") && json["quantity_in"] != null ? json['quantity_in'] : "",
      tax: json.containsKey("tax") && json["tax"] != null ? TaxDetailsDAO.fromJson(json["tax"]) : null,
      offers: json.containsKey("offers") && json["offers"] != null ? List<OffersDAO>.from(json["offers"].map((x) => OffersDAO.fromJson(x))) : [],
      id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
      inventoryData: json.containsKey("inventory_management") && json["inventory_management"] != null ? List<InventoryDetailsDAO>.from(json["inventory_management"].map((x) => InventoryDetailsDAO.fromJson(x))) : [],
      transitList: json.containsKey("transit") && json["transit"] != null ? List<TransitDetailsDAO>.from(json["transit"].map((e) => TransitDetailsDAO.fromJson(e))) : [],
      imageThumbnail: json.containsKey("image_dps") && json["image_dps"] != null ? List<ImageUrl>.from(json["image_dps"].map((x) => ImageUrl.fromJson(x))) : [],
      rawInventoryData: json.containsKey("raw_inventory_management") && json["raw_inventory_management"] != null ? List<RawInventory>.from(json["raw_inventory_management"].map((x) => RawInventory.fromJson(x))) : [],
      isRawProduct: json.containsKey("raw_material") && json["raw_material"] != null ? json["raw_material"] : false,
      isFromRawMaterial: json.containsKey("from_raw_material") && json["from_raw_material"] != null ? json["from_raw_material"] : false,
      // soldQuantity: json.containsKey("sold_quantity") && json["sold_quantity"] != null ? json["sold_quantity"] : 0,
      quantityAdjustList: json.containsKey("quantity_adjustments") && json["quantity_adjustments"] != null ? List<QuantityAdjustmentDAO>.from(json["quantity_adjustments"].map((x) => QuantityAdjustmentDAO.fromJson(x))) : [],
      productSector: json.containsKey("product_sector") && json["product_sector"] != null ? json["product_sector"] : "",
      totalSoldQuantity: json.containsKey("totalSoldQuantity") && json['totalSoldQuantity'] != null ? json['totalSoldQuantity'] : 0,
      publishToOndc: json.containsKey("publish_to_ondc") && json["publish_to_ondc"] != null ? AppUtills.parseBool(json["publish_to_ondc"]) : false,
      ondcFeatureDao: json.containsKey("ondc_features") && json["ondc_features"] != null ? List<OndcFeaturesDAO>.from(json["ondc_features"].map((x) => OndcFeaturesDAO.fromJson(x))) : [],
      barcode: json.containsKey("barcode") && json["barcode"] != null ? json["barcode"] : "");

  Map<String, dynamic> toJson() => {
        "bu_id": buId,
        "sku": sku,
        "type": type,
        "name": name,
        "brand": brand,
        "description": description,
        "product_segment": productSegment,
        "product_category": productCategory,
        "product_sub_category": productSubCategory,
        "product_type": productType,
        "product_sub_type": productSubType,
        "batch_number": batchNumber,
        "manufacture_date_time": manufactureDateTime!.toIso8601String(),
        "expiry_date": expiryDate!.toIso8601String(),
        "images": images,
        "in_stock": inStock,
        "for_sale": forSale,
        "transit": List<dynamic>.from(transitList!.map((e) => e)),
        "image_dps": List<dynamic>.from(imageThumbnail!.map((e) => e)),
        "manufacture_details": manufactureDetails!.toJson(),
        "suppliers": List<dynamic>.from(suppliers!.map((x) => x.toJson())),
        "shipping_details": shippingDetails!.toJson(),
        "tax": tax!.toJson(),
        "offers": List<dynamic>.from(offers!.map((x) => x.toJson())),
        "quantity_in": quantityIn,
        "id": id,
        "inventory_management":
            List<dynamic>.from(inventoryData!.map((e) => e.toJson())),
        "batch_pricing": List<dynamic>.from(batchPrice!.map((e) => e.toJson())),
        "raw_inventory_management":
            List<dynamic>.from(rawInventoryData!.map((e) => e.toJson())),
        "from_raw_material": isFromRawMaterial,
        "raw_material": isRawProduct,
        // "sold_quantity": soldQuantity,
        "quantity_adjustments":
            List<dynamic>.from(quantityAdjustList!.map((e) => e.toJson())),
        "product_sector": productSector,
        "totalSoldQuantity": totalSoldQuantity,
        "publish_to_ondc": publishToOndc,
        "ondc_feature":
            List<dynamic>.from(ondcFeatureDao!.map((e) => e.toJson())),
      };
}
