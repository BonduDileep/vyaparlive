class TaxDetailsDAO {
  TaxDetailsDAO({this.type, this.value, this.hsnCode});

  String? type;
  num? value;
  String? hsnCode;

  factory TaxDetailsDAO.fromJson(Map<String, dynamic> json) => TaxDetailsDAO(
      type:
          json.containsKey("type") && json["type"] != null ? json["type"] : "",
      value: json.containsKey("value") && json["value"] != null
          ? json["value"]
          : 0,
      hsnCode: json.containsKey("hsn_code") && json["hsn_code"] != null
          ? json["hsn_code"].toString()
          : "");

  Map<String, dynamic> toJson() =>
      {"type": type, "value": value, "hsn_code": hsnCode};
}
