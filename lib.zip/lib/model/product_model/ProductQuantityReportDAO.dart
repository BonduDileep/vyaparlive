import 'package:vyaparlive/model/product_model/BatchPriceDAO.dart';

class ProductQuantityReportDAO {
  String? productName;
  String? buId;
  String? productId;
  num? availableQuantity;
  num? soldQuantity;
  num? buyQuantity;
  List<BatchPriceDAO>? batchPriceData;
  bool? isRawMaterial;
  num? openingBalance;
  num? consumedQuantity;
  num? inHouseQuantity;
  num? manualQuantityChanges;
  num? quantityAdjustment;
  num? batch_pricing_total;  //stock value based on batch pricing
  ProductQuantityReportDAO(
      {this.availableQuantity,
      this.buId,
      this.buyQuantity,
      this.productId,
      this.productName,
      this.soldQuantity,
      this.batchPriceData,
      this.isRawMaterial,
      this.openingBalance,
      this.consumedQuantity,
      this.inHouseQuantity,
      this.manualQuantityChanges,
      this.quantityAdjustment,
      this.batch_pricing_total});

  factory ProductQuantityReportDAO.fromJson(Map<String, dynamic> json) => ProductQuantityReportDAO(
      availableQuantity:
          json.containsKey("available_quantity") && json["available_quantity"] != null
              ? num.tryParse(json["available_quantity"].toString()) ?? 0
              : 0,
      buId: json.containsKey("bu_id") && json["bu_id"] != null
          ? json["bu_id"]
          : "",
      buyQuantity: json.containsKey("buy_quantity") && json["buy_quantity"] != null
          ? num.tryParse(json["buy_quantity"].toString()) ?? 0
          : 0,
      productId: json.containsKey("id") && json["id"] != null ? json["id"] : "",
      productName:
          json.containsKey("name") && json["name"] != null ? json["name"] : "",
      soldQuantity: json.containsKey("sold_quantity") && json["sold_quantity"] != null
          ? num.tryParse(json["sold_quantity"].toString()) ?? 0
          : 0,
      batchPriceData: json.containsKey("batch_pricing") && json["batch_pricing"] != null
          ? List<BatchPriceDAO>.from(
              json["batch_pricing"].map((x) => BatchPriceDAO.fromJson(x)))
          : [],
      isRawMaterial: json.containsKey("raw_material") && json["raw_material"] != null
          ? json["raw_material"]
          : false,
      openingBalance: json.containsKey("opening_balance") && json["opening_balance"] != null
          ? num.tryParse(json["opening_balance"].toString()) ?? 0
          : 0,
      consumedQuantity:
          json.containsKey("consumed_quantity") && json["consumed_quantity"] != null
              ? num.tryParse(json["consumed_quantity"].toString()) ?? 0
              : 0,
      inHouseQuantity: json.containsKey("in_house_qty") && json["in_house_qty"] != null ? num.tryParse(json["in_house_qty"].toString()) ?? 0 : 0,
      manualQuantityChanges: json.containsKey("manual_quantity_changes") && json["manual_quantity_changes"] != null ? num.tryParse(json["manual_quantity_changes"].toString()) ?? 0 : 0,
      quantityAdjustment: json.containsKey("quantity_adjustments") && json["quantity_adjustments"] != null ? num.tryParse(json["quantity_adjustments"].toString()) ?? 0 : 0,
      batch_pricing_total: json.containsKey("batch_pricing_total") && json["batch_pricing_total"] != null ? num.tryParse(json["batch_pricing_total"].toString()) ?? 0 : 0);

  Map<String, dynamic> toJson() => {
        "available_quantity": availableQuantity,
        "bu_id": buId,
        "buy_quantity": buyQuantity,
        "id": productId,
        "name": productName,
        "sold_quantity": soldQuantity,
        "batch_pricing":
            List<dynamic>.from(batchPriceData!.map((e) => e.toJson())),
        "raw_material": isRawMaterial,
        "opening_balance": openingBalance,
        "consumed_quantity": consumedQuantity,
        "in_house_qty": inHouseQuantity,
        "manual_quantity_changes": manualQuantityChanges,
        "quantity_adjustments": quantityAdjustment,
        "batch_pricing_total": batch_pricing_total
      };
}
