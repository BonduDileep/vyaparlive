import 'package:vyaparlive/model/product_model/QuantityAdjustmentDAO.dart';
import 'package:vyaparlive/model/transaction/PackingLocationsDAO.dart';

class ModelQuantityAdjustmentDAO {
  String? userName;
  String? userId;
  DateTime? date;
  QuantityAdjustmentDAO? quantityAdjustmentData;
  List<QuantityLocationDAO>? quantityChangeList;

  ModelQuantityAdjustmentDAO(
      {this.userName,
      this.userId,
      this.date,
      this.quantityAdjustmentData,
      this.quantityChangeList});

  factory ModelQuantityAdjustmentDAO.fromJson(Map<String, dynamic> json) =>
      ModelQuantityAdjustmentDAO(
          userName: json.containsKey("user_name") && json["user_name"] != null
              ? json["user_name"]
              : "",
          userId: json.containsKey("user_id") && json['user_id'] != null
              ? json["user_id"]
              : "",
          date: json.containsKey("created_dt") && json["created_dt"] != null
              ? DateTime.parse(json["created_dt"])
              : null,
          quantityAdjustmentData: json.containsKey("quantity_adjustment") &&
                  json["quantity_adjustment"] != null
              ? QuantityAdjustmentDAO.fromJson(json["quantity_adjustment"])
              : null,
          quantityChangeList: json.containsKey("quantity_changes") &&
                  json["quantity_changes"] != null
              ? List<QuantityLocationDAO>.from(json["quantity_changes"]
                  .map((e) => QuantityLocationDAO.fromJson(e)))
              : []);

  Map<String, dynamic> toJson() => {
        "user_name": userName,
        "user_id": userId,
        "created_dt": date!.toIso8601String(),
        "quantity_adjustment": quantityAdjustmentData!.toJson(),
        "quantity_changes":
            List<dynamic>.from(quantityChangeList!.map((t) => t.toJson())),
      };
}
