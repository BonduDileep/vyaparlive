class PriceDetailsDAO {
  PriceDetailsDAO(
      {this.price,
      this.unit,
      this.currencyCode,
      this.currencyName,
      this.slabPricingTiers,
      this.mrp,
      this.netRate});

  num? price;
  num? netRate;
  num? mrp;
  String? unit;
  String? currencyCode;
  String? currencyName;
  String? slabPricingTiers;

  factory PriceDetailsDAO.fromJson(Map<String, dynamic> json) =>
      PriceDetailsDAO(
        price: json.containsKey("price") && json["price"] != null
            ? json["price"]
            : 0,
        netRate: json.containsKey("net_rate") && json["net_rate"] != null
            ? json["net_rate"]
            : 0,
        mrp: json.containsKey("mrp") && json["mrp"] != null ? json["mrp"] : 0,
        unit: json.containsKey("unit") && json["unit"] != null
            ? json["unit"]
            : "",
        currencyCode:
            json.containsKey("currency_code") && json["currency_code"] != null
                ? json["currency_code"]
                : "",
        currencyName:
            json.containsKey("currency_name") && json["currency_name"] != null
                ? json["currency_name"]
                : "",
        slabPricingTiers: json.containsKey("slab_pricing_tiers") &&
                json["slab_pricing_tiers"] != null
            ? json["slab_pricing_tiers"]
            : "",
      );

  Map<String, dynamic> toJson() => {
        "price": price,
        "unit": unit,
        "net_rate": netRate,
        "mrp": mrp,
        "currency_code": currencyCode,
        "currency_name": currencyName,
        "slab_pricing_tiers": slabPricingTiers,
      };
}
