class ManufactureDetailsDAO {
  ManufactureDetailsDAO(
      {this.modelNumber,
      this.releaseDate,
      this.name,
      this.manufacturerAddress,
      this.buildiName,
      this.area,
      this.city,
      this.taluka,
      this.landmark,
      this.state,
      this.district,
      this.pin,
      this.country,
      this.dialCode});

  String? modelNumber;
  DateTime? releaseDate;
  String? name;
  String? manufacturerAddress;
  String? buildiName;
  String? area;
  String? city;
  String? taluka;
  String? landmark;
  String? state;
  String? district;
  String? pin;
  String? country;
  String? dialCode;

  factory ManufactureDetailsDAO.fromJson(Map<String, dynamic> json) => ManufactureDetailsDAO(
      modelNumber: json.containsKey("model_number") && json["model_number"] != null
          ? json["model_number"]
          : "",
      releaseDate: json.containsKey("release_date") && json["release_date"] != null
          ? DateTime.tryParse(json["release_date"])
          : null,
      name:
          json.containsKey("name") && json["name"] != null ? json["name"] : "",
      manufacturerAddress: json.containsKey("manufacturer_Address") &&
              json["manufacturer_Address"] != null
          ? json["manufacturer_Address"]
          : "",
      buildiName: json.containsKey("building_name") && json["building_name"] != null
          ? json["building_name"]
          : "",
      area:
          json.containsKey("area") && json["area"] != null ? json["area"] : "",
      city:
          json.containsKey("city") && json["city"] != null ? json["city"] : "",
      taluka: json.containsKey("taluka") && json["taluka"] != null
          ? json["taluka"]
          : "",
      landmark: json.containsKey("landmark") && json["landmark"] != null
          ? json["landmark"]
          : "",
      state: json.containsKey("state") && json["state"] != null
          ? json["state"]
          : "",
      district: json.containsKey("district") && json["district"] != null
          ? json["district"]
          : "",
      pin: json.containsKey("pin") && json["pin"] != null ? json["pin"] : "",
      country: json.containsKey("country") && json["country"] != null ? json["country"] : "",
      dialCode: json.containsKey("dial_code") && json["dial_code"] != null ? json["dial_code"] : "");

  Map<String, dynamic> toJson() => {
        "model_number": modelNumber,
        "release_date": releaseDate!.toIso8601String(),
        "name": name,
        "manufacturer_Address": manufacturerAddress,
        "building_name": buildiName,
        "area": area,
        "city": city,
        "taluka": taluka,
        "landmark": landmark,
        "state": state,
        "district": district,
        "pin": pin,
        "country": country,
        "dial_code": dialCode
      };
}
