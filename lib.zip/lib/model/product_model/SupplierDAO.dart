class SupplierDAO {
  SupplierDAO({
    this.name,
    this.id,
    this.city,
    this.district,
    this.locality,
    this.phoneNo,
  });

  String? name;
  String? id;
  String? city;
  String? district;
  String? locality;
  String? phoneNo;

  factory SupplierDAO.fromJson(Map<String, dynamic> json) => SupplierDAO(
        name: json.containsKey("name") && json["name"] != null
            ? json["name"]
            : "",
        id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
        city: json.containsKey("city") && json["city"] != null
            ? json["city"]
            : "",
        district: json.containsKey("district") && json["district"] != null
            ? json["district"]
            : "",
        locality: json.containsKey("colonysector_arealocality") &&
                json["colonysector_arealocality"] != null
            ? json["colonysector_arealocality"]
            : "",
        phoneNo:
            json.containsKey("contact_number") && json["contact_number"] != null
                ? json["contact_number"].toString()
                : "",
      );

  Map<String, dynamic> toJson() => {
        "name": name,
        "id": id,
        "city": city,
        "district": district,
        "colonysector_arealocality": locality,
        "contact_number": phoneNo
      };
}
