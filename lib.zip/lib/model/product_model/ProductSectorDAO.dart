class ProductSectorDAO {
  String? id;
  String? sectorName;
  int? parentId;

  ProductSectorDAO({this.id, this.sectorName, this.parentId});

  factory ProductSectorDAO.fromJson(Map<String, dynamic> json) =>
      ProductSectorDAO(
          id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
          sectorName: json.containsKey("product_sector") &&
                  json["product_sector"] != null
              ? json["product_sector"]
              : "",
          parentId:
              json.containsKey("UNSPSC_code") && json["UNSPSC_code"] != null
                  ? json["UNSPSC_code"]
                  : 0);

  Map<String, dynamic> toJson() =>
      {"id": id, "product_sector": sectorName, "UNSPSC_code": parentId};
}
