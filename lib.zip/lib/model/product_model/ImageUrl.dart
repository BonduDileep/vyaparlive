class ImageUrl {
  String? image;
  ImageUrl({this.image});

  factory ImageUrl.fromJson(Map<String, dynamic> json) => ImageUrl(
      image:
          json.containsKey("s_64") && json["s_64"] != null ? json["s_64"] : "");
}
