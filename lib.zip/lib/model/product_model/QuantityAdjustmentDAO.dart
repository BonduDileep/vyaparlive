import 'package:vyaparlive/model/product_model/InventoryDetailsDAO.dart';
import 'package:vyaparlive/model/transaction/PackingLocationsDAO.dart';

class QuantityAdjustmentDAO {
  String? locationName;
  num? quantity;
  String? batchNumber;
  String? reason;
  String? updatedBy;
  String? updatedDate;
  String? locationId;
  List<InventoryDetailsDAO>? quantityAdjustLocationsList;
  List<QuantityLocationDAO>? quantityChangeList;
  String? userName;
  DateTime? quantityChangeDate;

  QuantityAdjustmentDAO(
      {this.batchNumber,
      this.locationName,
      this.quantity,
      this.reason,
      this.updatedBy,
      this.updatedDate,
      this.quantityAdjustLocationsList,
      this.locationId,
      this.quantityChangeList,
      this.quantityChangeDate,
      this.userName});

  factory QuantityAdjustmentDAO.fromJson(Map<String, dynamic> json) => QuantityAdjustmentDAO(
      batchNumber: json.containsKey("batch_no") && json["batch_no"] != null
          ? json["batch_no"]
          : "",
      locationName: json.containsKey("location") && json["location"] != null
          ? json["location"]
          : "",
      quantity: json.containsKey("quantity") && json["quantity"] != null
          ? json["quantity"]
          : 0,
      reason: json.containsKey("reason") && json["reason"] != null
          ? json["reason"]
          : "",
      updatedBy: json.containsKey("updated_by") && json["updated_by"] != null
          ? json["updated_by"]
          : "",
      updatedDate: json.containsKey("updated_date") && json["updated_date"] != null
          ? json["updated_date"]
          : "",
      quantityAdjustLocationsList: json.containsKey("location_batch_list") &&
              json["location_batch_list"] != null
          ? List<InventoryDetailsDAO>.from(json["location_batch_list"]
              .map((e) => InventoryDetailsDAO.fromJson(e)))
          : [],
      locationId: json.containsKey("location_id") && json["location_id"] != null
          ? json["location_id"]
          : "",
      quantityChangeList:
          json.containsKey("quantity_changes") && json["quantity_changes"] != null
              ? List<QuantityLocationDAO>.from(
                  json["quantity_changes"].map((e) => QuantityLocationDAO.fromJson(e)))
              : [],
      userName: json.containsKey("user_name") && json["user_name"] != null ? json["user_name"] : "",
      quantityChangeDate: json.containsKey("created_dt") && json["created_dt"] != null ? DateTime.parse(json["created_dt"]) : null);

  Map<String, dynamic> toJson() => {
        "batch_number": batchNumber,
        "location_name": locationName,
        "quantity": quantity,
        "reason": reason,
        "updated_by": updatedBy,
        "updated_date": updatedDate,
        "location_batch_list": List<dynamic>.from(
            quantityAdjustLocationsList!.map((e) => e.toString())),
        "location_id": locationId,
        "quantity_changes":
            List<dynamic>.from(quantityChangeList!.map((t) => t.toJson())),
        "created_dt": quantityChangeDate!.toIso8601String()
      };
}
