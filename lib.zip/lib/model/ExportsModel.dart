class ExportsModel {
  String? govtregistrationSchemename;
  String? govtregistrationSchemeid;

  ExportsModel(
      {this.govtregistrationSchemename, this.govtregistrationSchemeid});
}
