class TermsData {
  String? termType;
  String? termDescription;
  String? imageRelativePath;

  TermsData({this.termType, this.termDescription, this.imageRelativePath});
}
