class ProductSubType {
  ProductSubType({
    this.id,
    this.type,
  });

  String? id;
  String? type;

  factory ProductSubType.fromJson(Map<String, dynamic> json) => ProductSubType(
        id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
        type: json.containsKey("type") && json["type"] != null
            ? json["type"]
            : "",
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "type": type,
      };
}
