import 'package:vyaparlive/model/TransactionsModel.dart';
import 'package:vyaparlive/model/transaction/DeliveryDetailsModel.dart';

class SalesDAO {
  Buyer? buyer;
  Buyer? seller;
  dynamic invoiceNo;
  String? invoiceId;
  DateTime? invoiceDate;
  OrderTrack? deliveryDetails;
  String? transactionId;
  num? invoiceAmount;
  num? paidAmount;
  num? total;
  num? invoiceTotalAmount;
  String? invoiceStatus;
  String? deliveryStatus;
  String? paymentStatus;
  num? saleProfit;

  SalesDAO(
      {this.buyer,
      this.invoiceId,
      this.invoiceDate,
      this.invoiceNo,
      this.seller,
      this.deliveryDetails,
      this.transactionId,
      this.invoiceAmount,
      this.paidAmount,
      this.total,
      this.invoiceTotalAmount,
      this.invoiceStatus,
      this.deliveryStatus,
      this.paymentStatus,
      this.saleProfit});

  factory SalesDAO.fromJson(Map<String, dynamic> json) => SalesDAO(
      buyer: json.containsKey("buyer") && json["buyer"] != null
          ? Buyer.fromJson(json["buyer"])
          : null,
      seller: json.containsKey("seller") && json["seller"] != null
          ? Buyer.fromJson(json["seller"])
          : null,
      invoiceNo: json.containsKey("bill_no") && json["bill_no"] != null
          ? json["bill_no"]??0
          : 0,
      transactionId: json.containsKey("transactionId") && json['transactionId'] != null
          ? json["transactionId"]
          : "",
      total: json.containsKey("total") && json["total"] != null
          ? json["total"]
          : 0,
      invoiceAmount: json.containsKey("invoice_amount") && json["invoice_amount"] != null
          ? json["invoice_amount"]
          : 0,
      paidAmount: json.containsKey('paid_amount') && json['paid_amount'] != null
          ? json['paid_amount']
          : 0,
      invoiceDate: json.containsKey("invoice_date") && json['invoice_date'] != null
          ? DateTime.parse(json['invoice_date'])
          : DateTime.now(),
      deliveryDetails: json.containsKey("order_track") && json["order_track"] != null
          ? OrderTrack.fromJson(json["order_track"])
          : null,
      invoiceTotalAmount:
          json.containsKey("InvoiceTotalAmount") && json["InvoiceTotalAmount"] != null
              ? json["InvoiceTotalAmount"]
              : 0,
      invoiceStatus: json.containsKey("status") && json["status"] != null
          ? json["status"]
          : "",
      deliveryStatus:
          json.containsKey("delivery_status") && json["delivery_status"] != null
              ? json["delivery_status"]
              : "",
      paymentStatus: json.containsKey("payment_status") && json["payment_status"] != null ? json["payment_status"] : "",
      invoiceId: json.containsKey("invoice_id") && json["invoice_id"] != null ? json["invoice_id"] : "",
      saleProfit: json.containsKey('sale_profit') && json['sale_profit'] != null
          ? json['sale_profit']
          : 0);

  Map<String, dynamic> toJson() => {
        "buyer": buyer!.toJson(),
        "seller": seller!.toJson(),
        "bill_no": invoiceNo,
        "transactionId": transactionId,
        "total": total,
        "invoice_amount": invoiceAmount,
        "paid_amount": paidAmount,
        "invoice_date": invoiceDate!.toIso8601String(),
        "order_track": deliveryDetails!.toJson(),
        "InvoiceTotalAmount": invoiceTotalAmount,
        "status": invoiceStatus,
        "delivery_status": deliveryStatus,
        "payment_status": paymentStatus,
        "invoice_id": invoiceId
      };
}
