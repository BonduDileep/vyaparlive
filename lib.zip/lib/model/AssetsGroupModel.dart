class AssetsGroupModel {
  String? name;
  String? description;
  String? id;

  AssetsGroupModel({this.name, this.description, this.id});

  factory AssetsGroupModel.fromJson(Map<String, dynamic> json) =>
      AssetsGroupModel(
          name: json.containsKey("name") && json["name"] != null
              ? json["name"]
              : "",
          description:
              json.containsKey("description") && json["description"] != null
                  ? json["description"]
                  : "",
          id: json.containsKey("id") && json["id"] != null ? json["id"] : "");

  Map<String, dynamic> toJson() =>
      {"name": name, "description": description, "id": id};
}
