import 'dart:convert';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/model/bu_model/AddressDetailsModel.dart';
import 'package:vyaparlive/model/ondc_dao/OndcDao.dart';
import 'package:vyaparlive/model/product_model/BatchPriceDAO.dart';
import 'package:vyaparlive/model/transaction/CtrModel.dart';
import 'package:vyaparlive/model/transaction/DiscussionModel.dart';
import 'package:vyaparlive/model/transaction/InvoiceDetailsModel.dart';
import 'package:vyaparlive/model/transaction/RoughOrdersModel.dart';
import 'package:vyaparlive/model/transaction/TransactionOrderModel.dart';

TransactionsModel transactionsModelFromJson(String str) =>
    TransactionsModel.fromJson(json.decode(str));

String transactionsModelToJson(TransactionsModel data) =>
    json.encode(data.toJson());

class TransactionsModel {
  TransactionsModel(
      {this.buyer,
      this.seller,
      this.discussion,
      this.collection,
      this.metadata,
      this.id,
      this.offerDetails,
      this.invoiceDetails,
      this.ctrDetails,
      this.status,
      this.transactionDate,
      this.transactionType,
      this.roughOrderDetails,
      this.modifiedDate,
      this.isOffline,
      this.buyerApp,
      this.showPOAcceptance,
      this.id_new,
      this.assignedOrderType,
      this.orderType,
      this.canGenerateInvoice,
      this.quotationInfo,
      this.transactionId,
      this.retailId,
      this.sellerInvoice});

  Buyer? buyer;
  Buyer? seller;
  Ctr? ctrDetails;
  Discussion? discussion;
  String? collection;
  Metadata? metadata;
  String? id;
  OffersDetails? offerDetails;
  List<InvoiceDetails>? invoiceDetails;
  String? status;
  DateTime? transactionDate;
  String? transactionType;
  RoughOrderDetails? roughOrderDetails;
  DateTime? modifiedDate;
  bool? isOffline;
  OndcDao? buyerApp;
  bool? showPOAcceptance = false;
  String? id_new;
  String? assignedOrderType;
  String? orderType;
  bool? canGenerateInvoice;
  QuotationInfo? quotationInfo;
  String? transactionId;
  String? retailId;
  String? sellerInvoice;

  factory TransactionsModel.fromJson(Map<String, dynamic> json) =>
      TransactionsModel(
        buyer: json.containsKey("buyer") && json["buyer"] != null
            ? Buyer.fromJson(json["buyer"])
            : null,
        seller: json.containsKey("seller") && json["seller"] != null
            ? Buyer.fromJson(json["seller"])
            : null,
        discussion: json.containsKey("discussion") && json["discussion"] != null
            ? Discussion.fromJson(json["discussion"])
            : null,
        collection: json.containsKey("collection") && json["collection"] != null
            ? json["collection"]
            : "",
        invoiceDetails: json.containsKey("invoice_details") &&
                json["invoice_details"] != null
            ? List<InvoiceDetails>.from(
                json["invoice_details"].map((x) => InvoiceDetails.fromJson(x)))
            : [],
        ctrDetails: json.containsKey("ctr") && json["ctr"] != null
            ? Ctr.fromJson(json["ctr"])
            : null,
        metadata: json.containsKey("@metadata") && json["@metadata"] != null
            ? Metadata.fromJson(json["@metadata"])
            : null,
        offerDetails:
            json.containsKey("order_details") && json["order_details"] != null
                ? OffersDetails.fromJson(json["order_details"])
                : null,
        id: json.containsKey("id") ? json["id"] : "",
        id_new: json.containsKey("_id") ? json["_id"] : "",
        assignedOrderType: json.containsKey("type") && json["type"] != null
            ? json["type"]
            : "",
        transactionDate:
            json.containsKey("created_date") && json["created_date"] != null
                ? DateTime.parse(json["created_date"])
                : DateTime.now(),
        roughOrderDetails:
            json.containsKey("rough_orders") && json["rough_orders"] != null
                ? RoughOrderDetails.fromJson(json["rough_orders"])
                : null,
        modifiedDate:
            json.containsKey("modified_date") && json["modified_date"] != null
                ? DateTime.parse(json["modified_date"])
                : DateTime.now(),
        isOffline: json.containsKey("is_offline") && json["is_offline"] != null
            ? json["is_offline"]
            : false,
        status: json.containsKey("status") && json["status"] != null
            ? json["status"]
            : "",
        transactionType: CommonMethods.getTransactionType(json),
        buyerApp: json.containsKey("ondc") && json["ondc"] != null
            ? OndcDao.from(json['ondc'])
            : null,
        showPOAcceptance: json.containsKey("show_po_acceptance") &&
                json["show_po_acceptance"] != null
            ? json["show_po_acceptance"]
            : false,
        orderType: json.containsKey("order_type") && json["order_type"] != null
            ? json["order_type"]
            : "",
        canGenerateInvoice: json.containsKey("can_generate_invoice") &&
                json["can_generate_invoice"] != null
            ? json["can_generate_invoice"]
            : false,
        quotationInfo:
            json.containsKey("quotation") && json["quotation"] != null
                ? QuotationInfo.fromJson(json["quotation"])
                : null,
        transactionId:
            json.containsKey("transaction_id") && json["transaction_id"] != null
                ? json["transaction_id"]
                : "",
        retailId: json.containsKey("retail_id") && json["retail_id"] != null
            ? json["retail_id"]
            : "",
        sellerInvoice:
            json.containsKey('seller_invoice') && json['seller_invoice'] != null
                ? json['seller_invoice']
                : "",
      );

  Map<String, dynamic> toJson() => {
        "buyer": buyer!.toJson(),
        "seller ": seller!.toJson(),
        "discussion": discussion!.toJson(),
        "collection": collection,
        "rough_orders": roughOrderDetails!.toJson(),
        "invoice_details":
            List<dynamic>.from(invoiceDetails!.map((x) => x.toJson())),
        "@metadata": metadata!.toJson(),
        "order_details": offerDetails,
        "id": id,
        "modified_date": modifiedDate!.toIso8601String(),
        "status": status,
        "is_offline": isOffline,
        "ondc": buyerApp,
        "show_po_acceptance": showPOAcceptance,
        "can_generate_invoice": canGenerateInvoice,
        "order_type": orderType,
        "quotation": quotationInfo!.toJson(),
        "transaction_id": transactionId,
        "retail_id": retailId,
        "seller_invoice": sellerInvoice
      };
}

class Buyer {
  Buyer(
      {this.id,
      this.name,
      this.userId,
      this.userName,
      this.address,
      this.isOffline,
      this.gstNumber,
      this.shipToAddress,
      this.contactNumber,
      this.retailNumber,
      this.countryCode,
      this.contact});

  String? id;
  String? name;
  String? userId;
  String? userName;
  Address? address;
  bool? isOffline;
  String? gstNumber;
  Address? shipToAddress;
  String? contactNumber;
  String? retailNumber;
  String? countryCode;
  String? contact;

  factory Buyer.fromJson(Map<String, dynamic> json) => Buyer(
        id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
        name: json.containsKey("name") && json["name"] != null
            ? json["name"]
            : "",
        userId: json.containsKey("user_id") && json["user_id"] != null
            ? json["user_id"]
            : "",
        userName: json.containsKey("user_name") && json["user_name"] != null
            ? json["user_name"]
            : "",
        address: json.containsKey("address") && json["address"] != null
            ? Address.fromJson(json["address"])
            : null,
        isOffline: json.containsKey("is_offline") && json["is_offline"] != null
            ? json["is_offline"]
            : false,
        gstNumber: json.containsKey("GST_No") && json["GST_No"] != null
            ? json["GST_No"]
            : "",
        shipToAddress: json.containsKey("ship_to_address") &&
                json["ship_to_address"] != null
            ? Address.fromJson(json["ship_to_address"])
            : null,
        contactNumber:
            json.containsKey("contact_number") && json["contact_number"] != null
                ? json["contact_number"]
                : "",
        retailNumber:
            json.containsKey("mobile_number") && json["mobile_number"] != null
                ? json["mobile_number"]
                : "",
        countryCode: CommonMethods.getCountryCodeFromRes(json),
        contact: json.containsKey("contact") && json["contact"] != null
            ? json["contact"]
            : "",
        // json.containsKey("country_code") && json["country_code"] != null
        //     ? json["country_code"]
        //     : "",
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "user_id": userId,
        "user_name": userName,
        "address": address!.toJson(),
        "is_offline": isOffline,
        "GST_No": gstNumber,
        "ship_to_address": shipToAddress,
        "contact_number": contactNumber,
        "mobile_number": retailNumber,
        "country_code": countryCode
      };
}

class Metadata {
  Metadata({
    this.collection,
    this.nestedObjectTypes,
    this.ravenNodeType,
    this.changeVector,
    this.id,
    this.indexScore,
    this.lastModified,
  });

  String? collection;
  NestedObjectTypes? nestedObjectTypes;
  dynamic ravenNodeType;
  String? changeVector;
  String? id;
  double? indexScore;
  DateTime? lastModified;

  factory Metadata.fromJson(Map<String, dynamic> json) => Metadata(
        collection:
            json.containsKey("@collection") ? json["@collection"] : null,
        nestedObjectTypes: json.containsKey("@nested-object-types")
            ? NestedObjectTypes.fromJson(json["@nested-object-types"])
            : null,
        ravenNodeType: json.containsKey("Raven-Node-Type")
            ? json["Raven-Node-Type"]
            : null,
        changeVector:
            json.containsKey("@change-vector") ? json["@change-vector"] : null,
        id: json.containsKey("@id") ? json["@id"] : null,
        indexScore: json.containsKey("@index-score")
            ? json["@index-score"].toDouble()
            : null,
        lastModified: json.containsKey("@last-modified")
            ? DateTime.parse(json["@last-modified"])
            : null,
      );

  Map<String, dynamic> toJson() => {
        "@collection": collection,
        "@nested-object-types": nestedObjectTypes!.toJson(),
        "Raven-Node-Type": ravenNodeType,
        "@change-vector": changeVector,
        "@id": id,
        "@index-score": indexScore,
        "@last-modified": lastModified!.toIso8601String(),
      };
}

class NestedObjectTypes {
  NestedObjectTypes();

  factory NestedObjectTypes.fromJson(Map<String, dynamic>? json) =>
      NestedObjectTypes();

  Map<String, dynamic> toJson() => {};
}

class Product {
  Product({
    this.id,
    this.quantity,
    this.unitPrice,
    this.total,
    this.productName,
    this.productImage,
    this.quantityIn,
    this.productCost,
    this.productTotalAmount,
    this.productTotalOffer,
    this.batchNumber,
    this.productBatches,
    this.uId,
  });

  String? id;
  num? quantity;
  num? unitPrice;
  num? total;
  String? productName;
  String? productImage;
  String? quantityIn;
  num? productCost;
  num? productTotalOffer;
  num? productTotalAmount;
  String? batchNumber;
  List<BatchPriceDAO>? productBatches;
  String? uId;

  factory Product.fromJson(Map<String, dynamic> json) => Product(
      id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
      quantity: json.containsKey("quantity") && json["quantity"] != null
          ? json["quantity"]
          : 0,
      unitPrice: json.containsKey("unit_price") && json["unit_price"] != null
          ? json["unit_price"]
          : 0,
      total: json.containsKey("total") && json["total"] != null
          ? json["total"]
          : 0,
      productName: json.containsKey("product_name") && json["product_name"] != null
          ? json["product_name"]
          : "",
      productImage: json.containsKey("product_image") && json['product_image'] != null
          ? json["product_image"]
          : "",
      quantityIn: json.containsKey("quantity_in") && json["quantity_in"] != null
          ? json["quantity_in"]
          : "",
      productCost: json.containsKey("product_cost") && json["product_cost"] != null
          ? json["product_cost"]
          : 0,
      productTotalAmount:
          json.containsKey("product_amount_total") && json["product_amount_total"] != null
              ? json["product_amount_total"]
              : 0,
      productTotalOffer: json.containsKey("product_total_offer") && json["product_total_offer"] != null
          ? json["product_total_offer"]
          : 0,
      batchNumber: json.containsKey("batch_number") && json["batch_number"] != null
          ? json["batch_number"]
          : "",
      productBatches: json.containsKey("product_batches") && json["product_batches"] != null
          ? List<BatchPriceDAO>.from(json["product_batches"].map((e) => BatchPriceDAO.fromJson(e)))
          : [],
      uId: json.containsKey("u_id") && json["u_id"] != null ? json["u_id"] : "");

  Map<String, dynamic> toJson() => {
        "id": id,
        "quantity": quantity,
        "unit_price": unitPrice,
        "total": total,
        "product_name": productName,
        "product_image": productImage,
        "quantity_in": quantityIn,
        "product_total_offer": productTotalOffer,
        "product_amount_total": productTotalAmount,
        "product_cost": productCost,
        "batch_number": batchNumber,
        "product_batches":
            List<dynamic>.from(productBatches!.map((e) => e.toJson())),
        "u_id": uId
      };
}

class TaxReferences {
  TaxReferences({
    this.gstNo,
  });

  String? gstNo;

  factory TaxReferences.fromJson(Map<String, dynamic> json) => TaxReferences(
        gstNo: json.containsKey("gst_no") && json["gst_no"] != null
            ? json["gst_no"]
            : "",
      );

  Map<String, dynamic> toJson() => {
        "gst_no": gstNo,
      };
}

class QuotationInfo {
  QuotationInfo({this.quotationNumber, this.status});

  String? quotationNumber;
  String? status;

  factory QuotationInfo.fromJson(Map<String, dynamic> json) => QuotationInfo(
        quotationNumber: json.containsKey("quotation_number") &&
                json["quotation_number"] != null
            ? json["quotation_number"]
            : "",
        status: json.containsKey("status") && json["status"] != null
            ? json["status"]
            : "",
      );

  Map<String, dynamic> toJson() => {
        "quotation_number": quotationNumber,
        "status": status,
      };
}
