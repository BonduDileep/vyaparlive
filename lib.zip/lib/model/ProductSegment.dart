import 'dart:convert';

ProductSegment productSegmentFromJson(String str) =>
    ProductSegment.fromJson(json.decode(str));

String productSegmentToJson(ProductSegment data) => json.encode(data.toJson());

class ProductSegment {
  ProductSegment({
    this.data,
  });

  List<Datum>? data;

  factory ProductSegment.fromJson(Map<String, dynamic> json) => ProductSegment(
        data: json.containsKey("data") && json["data"] != null
            ? List<Datum>.from(json["data"].map((x) => Datum.fromJson(x)))
            : [],
      );

  Map<String, dynamic> toJson() => {
        "data": List<dynamic>.from(data!.map((x) => x.toJson())),
      };
}

class Datum {
  Datum({
    this.id,
    this.type,
  });

  String? id;
  String? type;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
        id: json.containsKey("id") && json["id"] != null ? json["id"] : "",
        type: json.containsKey("type") && json["type"] != null
            ? json["type"]
            : "",
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "type": type,
      };
}
