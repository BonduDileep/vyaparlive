class DepartmentDAO {
  String? name;
  String? id;
  DepartmentDAO({this.name, this.id});

  factory DepartmentDAO.fromJson(Map<String, dynamic> json) => DepartmentDAO(
      name:
          json.containsKey("name") && json["name"] != null ? json["name"] : "",
      id: json.containsKey("id") && json["id"] != null ? json["id"] : "");

  Map<String, dynamic> toJson() => {"name": name, "id": id};
}
