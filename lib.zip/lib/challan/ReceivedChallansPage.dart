import 'package:vyaparlive/components/DateFilterUtil.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/model/BuListModel.dart';
import 'package:vyaparlive/model/Contacts.dart';
import 'package:vyaparlive/model/quotations/QuotationsModel.dart';
import 'package:vyaparlive/service/invitation_services.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:vyaparlive/utills/animation/list_loader/ListLoader.dart';
import 'package:custom_searchable_dropdown/custom_searchable_dropdown.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:flutx/flutx.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/TransactionsModel.dart';
import 'package:vyaparlive/service/Service.dart';
import 'dart:convert';
import 'package:vyaparlive/service/bu_list_grpc_service.dart';

class ReceivedChallansView extends StatefulWidget {
  final String? buId;
  final String? params;
  final String? connectionBuId;
  final bool isFromConnection;
  final bool isFromInternalBu;
  bool isMount = true;
  final bool isFromOfflineConnections;
  ReceivedChallansView(
      {this.buId,
      this.params = "",
      this.connectionBuId,
      this.isFromConnection = false,
      this.isFromInternalBu = false,
      this.isFromOfflineConnections = false});
  @override
  _ReceivedChallansViewState createState() => _ReceivedChallansViewState();
}

class _ReceivedChallansViewState extends State<ReceivedChallansView>
    with TickerProviderStateMixin {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  List<QuotationsModel> _sellTransactionsList = [];
  List<QuotationsModel> _resTransactionsList = [];
  final _searchController = TextEditingController();
  String? transactionName = "";
  String? transactionStatus = "";
  String? _buId = "";
  DateTime initialDate = DateTime.now();
  String transactionDate = "";
  DateFormat formatter = DateFormat("yyyy-MM-dd");
  String formattedDate = "";
  late Service _service;
  // ProgressDialog progressDialog;
  bool isLoading = false;
  bool isShowFloatButton = false;
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_SELL_TRANSACTIONS;
  String showLoaderText = Constants.NO_DATA_FOUND;
  String params = "";
  late BuListGrpcService _transactionService;
  bool isSearchParams = false;
  ScrollController? _scrollController;
  String? radioButtonValue = "";
  static const String OFFLINE = "Offline";
  static const String ONLINE = "Online";
  String? rawMaterialTransactionRadioValue;
  String? actualTransactionRadioValue = Constants.SALABLE_PRODUCTS;
  final fromDateController = TextEditingController();
  final toDateController = TextEditingController();
  late ThemeData theme;
  late AnimationController _animationController;

  final double calendarHeight = 40.0;
  List<BuListModel> _buList = [];
  BuListModel? offlineBuDropdownvalue;
  List<Contacts> _contactsModel = [];
  Contacts? connectionName;
  String selectedConnectionName = "";
  late InvitationService _invitationService;
  late TextEditingController statusTypeController = new TextEditingController();
  DateTime mnthStartDate =
      DateTime.utc(DateTime.now().year, DateTime.now().month, 1);

  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _invitationService = new InvitationService();
    _service = Service();
    _transactionService = BuListGrpcService();
    _buId = widget.buId;
    initBottomSheetAnimation();
    fromDateController.text = formatter.format(mnthStartDate);
    toDateController.text = formatter.format(DateTime.now());

    if (widget.isFromConnection ||
        widget.isFromInternalBu ||
        widget.isFromOfflineConnections) {
      // params = "?name=${widget.params}";
      _searchController.text = widget.params!;
      // loadConnectionTransactionHistory(params);
      this.loadTransactionsData(name: widget.params);
    } else {
      params = "";
      loadTransactionsData(name: widget.params);
    }
    _scrollController = new ScrollController();
  }

  initBottomSheetAnimation() {
    _animationController = BottomSheet.createAnimationController(this);
    _animationController.duration =
        const Duration(milliseconds: Constants.bottomSheet_duration);
    _animationController.reverseDuration =
        const Duration(milliseconds: Constants.bottomSheet_reverse_duration);
    _animationController.drive(CurveTween(curve: Curves.easeIn));
  }

  loadOfflineBulistData(String params) async {
    if (await NetworkStatus.getInternetStatus()) {
      this.getAllOfflineContacts(params).then((value) {
        setState(() {
          _buList.clear();
          _buList.addAll(value);
          setState(() {
            radioButtonValue = OFFLINE;
            rawMaterialTransactionRadioValue = null;
            actualTransactionRadioValue = Constants.SALABLE_PRODUCTS;
          });
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<BuListModel>> getAllOfflineContacts(String params) async {
    setState(() {
      isLoading = true;
    });

    String body = json.encode({"buId": widget.buId, "filters": {}});

    var response = await _invitationService
        .getContactsByBuId_grpc(
            body, AppController.instance.getAuthorizationKey, params)
        .catchError((onError) async {
      print("GET CONTACTS ERROR: $onError");
      setState(() {
        isLoading = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    setState(() {
      isLoading = false;
    });
    List<BuListModel> _list = [];
    GRPCResponse data = response;
    if (!data.getIsError! && !data.getIsException!) {
      var resBody = json.decode(data.message!);
      var resultArray = resBody['results'];
      for (var object in resultArray) {
        _list.add(BuListModel.fromJson(object));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          data.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return _list;
  }

  loadConnectionsData() async {
    if (await NetworkStatus.getInternetStatus()) {
      this.getContacts(widget.buId).then((onValue) {
        setState(() {
          _contactsModel.clear();
          _contactsModel.addAll(onValue);
          if (_contactsModel.length > 0) {
            for (int i = 0; i < _contactsModel.length; i++) {
              if (AppController.instance.getConnectionName ==
                  _contactsModel[i].buId) {
                connectionName = _contactsModel[i];
              }
            }
          }
          filterBottomView(context);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<Contacts>> getContacts(String? buId) async {
    setState(() {
      _contactsModel.clear();
      isLoading = true;
    });
    String body = json.encode({"buId": buId, "filters": {}});

    var response = await _invitationService
        .findAllConnections_grpc(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoading = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<Contacts> _model = [];
    setState(() {
      isLoading = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);

      for (var noteJson in resObj['results']) {
        _model.add(Contacts.fromJson(noteJson));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
      return _model;
  }

  loadTransactionsData(
      {String? name = "",
      String? status = "",
      String? fromDate = "",
      String? toDate = "",
      bool? isOffline = false,
      String? transactionType = ""}) async {
    if (await NetworkStatus.getInternetStatus()) {
      if (!isSearchParams) {
        setState(() {
          isLoadingProgress = true;
        });
      }
      _getAllChallans(
              name: name,
              status: status,
              fromDate: fromDate,
              toDate: toDate,
              isOffline: isOffline,
              transactionType: transactionType)
          .then((onValue) {
        // if (!mounted) return;
        setState(() {
          _sellTransactionsList.clear();
          _resTransactionsList.clear();
          _resTransactionsList.addAll(onValue);
          if (_resTransactionsList.length > 0) {
            _sellTransactionsList.clear();
            if (_resTransactionsList.length > 0) {
              for (int i = 0; i < _resTransactionsList.length; i++) {
                if (_resTransactionsList[i].buyer!.id == _buId) {
                  _sellTransactionsList.add(_resTransactionsList[i]);
                } else {
                  showLoaderText = Constants.NO_DATA_FOUND;
                }
              }
              // _sellTransactionsList = _sellTransactionsList.reversed.toList();
            }
          } else {
            showLoaderText = Constants.NO_DATA_FOUND;
          }
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<QuotationsModel>> _getAllChallans(
      {String? name = "",
      String? status = "",
      String? fromDate = "",
      String? toDate = "",
      bool? isOffline = false,
      String? transactionType = ""}) async {
    String body = json.encode({
      "filters": {
        "buId": _buId
        // "DateFrom": fromDateController.text,
        // "DateTo": toDateController.text,
      }
    });
    var response = await _transactionService
        .getAllChallansByBuId(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<QuotationsModel> _list = [];

    isLoading = true;

    // setState(() {
    isLoadingProgress = false;
    // });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(resObj)) {
        var resultArray = resObj;
        for (var i in resultArray) {
          _list.add(QuotationsModel.fromJson(i));
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return _list;
  }

  Future<List<TransactionsModel>> getConnectionHistrory(String param) async {
    setState(() {
      isLoadingProgress = true;
    });

    var response = await _service
        .getConnectionTransactionHistory(_buId, widget.connectionBuId, params)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<TransactionsModel> _list = [];

    isLoading = true;

    setState(() {
      isLoadingProgress = false;
    });

    if (response.statusCode == 200) {
      final object = json.decode(response.body);
      bool isString = false;
      if (object['data'] is String) {
        isString = true;
      }

      if (!isString) {
        var resultArray = object['data']['results'];
        for (var i in resultArray) {
          _list.add(TransactionsModel.fromJson(i));
        }
      }
    } else if (response.statusCode == 401) {
      CommonMethods.handleUnauthorizedAccess(context);
    } else {
      final object = json.decode(response.body);
      String? messgae = object['message'];

      Future.delayed(Duration.zero).then((value) {
        Dialogs.yesCancelDialog(
            context,
            Language().getString(Constants.ERROR, selectedLang),
            messgae,
            Language().getString(Constants.OKAY_STR, selectedLang),
            "",
            false);
      });
    }

    return _list;
  }

  renderClearFiltersData() {
    fromDateController.clear();
    toDateController.clear();
    connectionName = null;
    offlineBuDropdownvalue = null;
    statusTypeController.clear();
  }

  Widget _listViewData() {
    if (isLoadingProgress) {
      return Expanded(child: ListLoader());
    } else if (!isLoadingProgress && _sellTransactionsList.length == 0) {
      return Expanded(
          child: Center(
        child: Text(Language().getString(showLoaderText, selectedLang)),
      ));
    } else {
      return Expanded(
        child: Container(
          child: AnimationLimiter(
            child: ListView.separated(
              controller: _scrollController,
              physics: const BouncingScrollPhysics(
                  parent: AlwaysScrollableScrollPhysics()),
              shrinkWrap: true,
              separatorBuilder: (context, index) => Divider(
                height: 1.0,
                color: Colors.transparent,
              ),
              itemBuilder: (BuildContext ctxt, int index) {
                return AnimationConfiguration.staggeredList(
                  position: index,
                  // duration: Duration(milliseconds: 1200),
                  child: SlideAnimation(
                    verticalOffset: 50.0,
                    child: FadeInAnimation(
                      child: InkWell(
                          onTap: () {
                            
                          },
                          child: Container(
                            child: Container(child: listRow(index)),
                          )),
                    ),
                  ),
                );
              },
              itemCount: _sellTransactionsList.length,
            ),
          ),
        ),
      );
    }
  }

  Widget showRadiobuttonsView(StateSetter setState) {
    return Row(children: [
      Container(
        child: Row(
          children: [
            Radio(
              value: OFFLINE,
              activeColor: Color(Constants.APP_COLOR),
              groupValue: radioButtonValue,
              onChanged: (dynamic value) {
                this.renderClearFiltersData();
                if (_buList.length == 0) {
                  loadOfflineBulistData("");
                } else {
                  setState(() {
                    radioButtonValue = value;
                    rawMaterialTransactionRadioValue = null;
                    actualTransactionRadioValue = Constants.SALABLE_PRODUCTS;
                  });
                  Future.delayed(Duration(seconds: 1))
                      .then((value) => setState(() {
                            isLoadingProgress = false;
                          }));
                }
              },
            ),
            Text(
              OFFLINE,
              style: TextStyle(fontWeight: StyleView.fontSemiBold),
            ),
          ],
        ),
      ),
      Container(
        child: Row(
          children: [
            Radio(
              value: ONLINE,
              activeColor: Color(Constants.APP_COLOR),
              groupValue: radioButtonValue,
              onChanged: (dynamic value) {
                this.renderClearFiltersData();
                // AppController.instance.setTxnFilterOption = ONLINE;
                setState(() {
                  radioButtonValue = value;
                  isLoadingProgress = true;
                  rawMaterialTransactionRadioValue = null;
                  actualTransactionRadioValue = Constants.SALABLE_PRODUCTS;
                });
                Future.delayed(Duration(seconds: 1))
                    .then((value) => setState(() {
                          isLoadingProgress = false;
                        }));
              },
            ),
            Text(
              ONLINE,
              style: TextStyle(fontWeight: StyleView.fontSemiBold),
            ),
          ],
        ),
      ),
    ]);
  }

  dateFilterView() {
    return DateFilterUtill(
      isShowSearchButton: true,
      onFromDateSelected: (value) => fromDateController.text = value,
      onToDateSelected: (value) => toDateController.text = value,
      fromDateController: fromDateController,
      toDateController: toDateController,
      onSearchParms: () {
        Map data = {
          "status": statusTypeController.text,
          "DateFrom": fromDateController.text,
          "DateTo": toDateController.text,
          "name": widget.isFromConnection ? widget.params : selectedConnectionName,
          "offline": radioButtonValue == OFFLINE ? true : false,
          "transaction_type": rawMaterialTransactionRadioValue != null
              ? Constants.KEY_RAW_MATERIAL
              : ""
        };
        setState(() {
          isLoadingProgress = true;
        });
        loadTransactionsData(
            status: data['status'],
            fromDate: data['DateFrom'],
            toDate: data['DateTo'],
            name: data['name'],
            isOffline: data['offline'],
            transactionType: data['transaction_type']);
      },
    );
  }

  showConnectionsList() {
    return Container(
        margin: EdgeInsets.symmetric(vertical: 10.0),
        decoration: AppUtills.boxDecoration(),
        child: CustomSearchableDropDown(
          items: _contactsModel.toList(),
          label: Language()
              .getString(Constants.PLEASE_SELECT_BUSSINESS_UNIT, selectedLang),
          labelStyle:
              TextStyle(fontWeight: StyleView.fontSemiBold, fontSize: 14.0),
          suffixIcon: Padding(
            padding: const EdgeInsets.all(0.0),
            child: Icon(Icons.search),
          ),
          dropDownMenuItems: _contactsModel.map((item) {
            return item.buName;
          }).toList(),
          onChanged: (value) {
            if (value != null) {
              setState(() {
                connectionName = value;
                selectedConnectionName = connectionName!.buName!;
              });
            }
          },
        ));
  }

  showOfflineBulist() {
    return Container(
        margin: EdgeInsets.symmetric(vertical: 10.0),
        decoration: AppUtills.boxDecoration(),
        child: CustomSearchableDropDown(
          items: _buList.toList(),
          label: Language()
              .getString(Constants.PLEASE_SELECT_CONNECTION, selectedLang),
          labelStyle:
              TextStyle(fontWeight: StyleView.fontSemiBold, fontSize: 14.0),
          suffixIcon: Padding(
            padding: const EdgeInsets.all(0.0),
            child: Icon(Icons.search),
          ),
          dropDownMenuItems: _buList.map((item) {
            return item.name;
          }).toList(),
          onChanged: (value) {
            if (value != null) {
              setState(() {
                offlineBuDropdownvalue = value;
                selectedConnectionName = offlineBuDropdownvalue!.name!;
              });
            }
          },
        ));
  }

  showTransactionStatus() {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 5.0),
      decoration: AppUtills.boxDecoration(),
      child: CustomSearchableDropDown(
        items: Constants.transactionsStatusList.toList(),
        label: Language()
            .getString(Constants.SEARCH_BY_TRANSACTION_STATUS, selectedLang),
        labelStyle:
            TextStyle(fontWeight: StyleView.fontSemiBold, fontSize: 14.0),
        suffixIcon: Padding(
          padding: const EdgeInsets.all(0.0),
          child: Icon(Icons.search),
        ),
        dropDownMenuItems: Constants.transactionsStatusList.map((item) {
          return item;
        }).toList(),
        dropdownItemStyle: TextStyle(fontWeight: StyleView.fontMedium),
        onChanged: (value) {
          setState(() {
            transactionStatus = value;
          });
        },
      ),
    );
  }

  Widget showTransactionTypeView(StateSetter setState) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 5.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
              child: Text(
            Language().getString(Constants.TRANSACTION_TYPE, selectedLang),
            style: TextStyle(
                color: Colors.black, fontWeight: StyleView.fontSemiBold),
          )),
          Container(
            child: Row(
              children: [
                Row(
                  children: [
                    Radio(
                      value: Constants.KEY_RAW_MATERIAL,
                      activeColor: Color(Constants.APP_COLOR),
                      groupValue: rawMaterialTransactionRadioValue,
                      onChanged: (dynamic value) {
                        setState(() {
                          rawMaterialTransactionRadioValue = value;
                          actualTransactionRadioValue = null;
                        });
                      },
                    ),
                    Text(
                      Language()
                          .getString(Constants.RAW_MATERIALS, selectedLang),
                      style: TextStyle(fontWeight: StyleView.fontSemiBold),
                    ),
                  ],
                ),
                Row(
                  children: [
                    Radio(
                      value: Constants.SALABLE_PRODUCTS,
                      activeColor: Color(Constants.APP_COLOR),
                      groupValue: actualTransactionRadioValue,
                      onChanged: (dynamic value) {
                        setState(() {
                          actualTransactionRadioValue = value;
                          rawMaterialTransactionRadioValue = null;
                        });
                      },
                    ),
                    Text(
                      Language()
                          .getString(Constants.SALABLE_PRODUCTS, selectedLang),
                      style: TextStyle(fontWeight: StyleView.fontSemiBold),
                    ),
                  ],
                )
              ],
            ),
          )
        ],
      ),
    );
  }

  void filterBottomView(context) {
    showModalBottomSheet(
        transitionAnimationController: _animationController,
        isScrollControlled: true,
        backgroundColor: Colors.white,
        barrierColor: Colors.black54,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20.0),
                topRight: Radius.circular(20.0))),
        context: context,
        builder: (BuildContext buildContext) {
          return StatefulBuilder(
            builder: (BuildContext context,
                void Function(void Function()) setState) {
              return Padding(
                padding: const EdgeInsets.all(8.0),
                child: ListView(
                  shrinkWrap: true,
                  children: [
                    Column(children: [
                      Container(
                        width: MediaQuery.of(context).size.width * 0.25,
                        height: 3,
                        color: Colors.grey,
                      ),
                      showRadiobuttonsView(setState),
                      // dateFilterView(),
                      FxSpacing.height(5.0),
                      (radioButtonValue == OFFLINE)
                          ? this.showOfflineBulist()
                          : this.showConnectionsList(),
                      FxSpacing.height(10.0),
                      this.showTransactionStatus(),
                      FxSpacing.height(10.0),
                      this.showTransactionTypeView(setState)
                    ]),
                    FxSpacing.height(10.0),
                    Container(
                      padding: EdgeInsets.only(bottom: 10),
                      child: CommonButtonsView(
                        context: context,
                        b1Text: Language()
                            .getString(Constants.STR_CANCEL, selectedLang),
                        b2Text: Language()
                            .getString(Constants.APPLY_FILTER, selectedLang),
                        onb1Action: () => {Navigator.of(context).pop()},
                        onb2Action: () {
                          Map data = {
                            "status": statusTypeController.text,
                            "DateFrom": fromDateController.text,
                            "DateTo": toDateController.text,
                            "name": widget.isFromConnection ? widget.params :  selectedConnectionName,
                            "offline":
                                radioButtonValue == OFFLINE ? true : false,
                            "transaction_type":
                                rawMaterialTransactionRadioValue != null
                                    ? Constants.KEY_RAW_MATERIAL
                                    : ""
                          };
                          Navigator.of(context).pop();
                          setState(() {
                            isLoadingProgress = true;
                            isShowFloatButton = true;
                          });
                          loadTransactionsData(
                              status: data['status'],
                              fromDate: data['DateFrom'],
                              toDate: data['DateTo'],
                              name: data['name'],
                              isOffline: data['offline'],
                              transactionType: data['transaction_type']);
                        },
                      ),
                    )
                  ],
                ),
              );
            },
          );
        });
  }

  @override
  void dispose() {
    widget.isMount = false;
    this.renderClearFiltersData();
    _scrollController!.dispose();
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        SafeArea(
          child: Scaffold(
            key: _scaffoldkey,
            backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
            floatingActionButton: (isShowFloatButton)
                ? FloatingActionButton(
                    backgroundColor: Color(Constants.APP_COLOR),
                    onPressed: () {
                      // progressDialog.show();
          
                      isLoadingProgress = true;
                      this.renderClearFiltersData();
                      isShowFloatButton = false;
                      loadTransactionsData();
                      if (!widget.isFromConnection ||
                          !widget.isFromInternalBu ||
                          !widget.isFromOfflineConnections) {
                        _searchController.clear();
                      }
                    },
                    child: Text(
                      Language().getString(Constants.CLEAR_FILTERS, selectedLang),
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 10.0),
                    ),
                  )
                : null,
            body: Container(
                padding: EdgeInsets.only(left: 5),
                child: Card(
                  elevation: 20,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(10.0),
                          bottomLeft: Radius.circular(10.0))),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(children: <Widget>[
                      Container(height: 60, child: buildSearchBarView()),
                      Container(
                        child: dateFilterView(),
                        margin: EdgeInsets.symmetric(horizontal: 4, vertical: 3),
                      ),
                      // FxSpacing.height(5),
                      _listViewData()
                    ]),
                  ),
                )),
          ),
        ),
        // AppUtills.showLoadingView(
        //     context: context,
        //     message: Language().getString(progressMessage, selectedLang),
        //     isLoading: isLoadingProgress),
      ],
    );
  }

  // void setStateIfMounted(f) {
  //   if (mounted) setState(f);
  // }

  listRow(int index) {
    if (_sellTransactionsList[index].buyer!.id == widget.buId) {
      transactionName = _sellTransactionsList[index].seller!.name;
    } else {
      transactionName = _sellTransactionsList[index].buyer!.name;
    }

    return Card(
      elevation: 2.5,
      color: Colors.white,
      shadowColor: AppTheme.theme.colorScheme.primary, //Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(5),
        // side: BorderSide(color: AppTheme.theme.colorScheme.primary)
      ),
      child: Container(
        padding: EdgeInsets.only(left: 10.0, top: 8.0, bottom: 8.0),
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                "$transactionName",
                style: TextStyle(
                    color: AppTheme.theme.colorScheme
                        .primary, //Color(Constants.APP_COLOR),
                    fontSize: 15.0,
                    fontWeight: StyleView.fontSemiBold),
              ),
              FxSpacing.height(3.0),
              Text(
                "${_sellTransactionsList[index].challan_details!.products!.length} items | Total: ${CommonMethods.getCurrencyValues(_sellTransactionsList[index].challan_details!.total_price)}",
                style: TextStyle(
                    color: Color(0xFF282828), //Color(Constants.APP_COLOR),
                    fontSize: 12.5,
                    fontWeight: StyleView.fontMedium),
              ),
              FxSpacing.height(5.0),
              Row(
                children: [
                  FxSpacing.width(3.0),
                  Text(
                    AppUtills.getISTTime(
                        _sellTransactionsList[index].transactionDate.toString()),
                    style: TextStyle(
                        color: Color(0xFF282828), //Color(Constants.APP_COLOR),
                        fontSize: 12.5,
                        fontWeight: StyleView.fontMedium),
                  ),
                ],
              ),
            ]),
      ),
    );
  }

  buildSearchBarView() {
    return Card(
      elevation: 5,
      shadowColor: theme.colorScheme.primary,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(5.0),
          side:
              BorderSide(color: theme.colorScheme.primary, strokeAlign: 0.01)),
      child: Row(
        children: <Widget>[
          Expanded(
              flex: 5,
              child: Row(
                children: <Widget>[
                  Expanded(
                    flex: 5,
                    child: Container(
                      padding: EdgeInsets.only(left: 15),
                      child: TextFormField(
                        controller: _searchController,
                        onChanged: onSearchTextChanged,
                        style: TextStyle(fontWeight: StyleView.fontSemiBold),
                        decoration: InputDecoration(
                            border: InputBorder.none,
                            hintText: Language().getString(
                                Constants.SEARCH_BY_BUSINESS, selectedLang),
                            hintStyle: TextStyle(
                                fontSize: 13.0,
                                fontWeight: StyleView.fontSemiBold)),
                      ),
                    ),
                  ),
                  _searchController.text.isNotEmpty
                      ? Container(
                          color: Colors.white,
                          child: IconButton(
                              icon: Icon(
                                Icons.close,
                                color: Colors.red,
                                size: 20.0,
                              ),
                              onPressed: () {
                                setState(() {
                                  _searchController.clear();
                                  // applyFilterChanges(_searchController.text);
                                  onSearchTextChanged(_searchController.text);
                                });
                              }))
                      : new Container()
                ],
              )),
          Container(color: Colors.grey),
          Expanded(
              child: Container(
                  margin: EdgeInsets.only(left: 2),
                  padding: EdgeInsets.only(left: 5),
                  child: IconButton(
                      icon: Icon(Icons.filter_list),
                      onPressed: () async {
                        if (_contactsModel.length == 0) {
                          await loadConnectionsData();
                        } else {
                          filterBottomView(context);
                        }

                        return;
                        // var result = await Navigator.push(
                        //     context,
                        //     new MaterialPageRoute(
                        //         builder: (context) => FilterTransactionPage(
                        //               buId: _buId,
                        //               connectionBuId: widget.connectionBuId,
                        //             )));
                        // if (result != null) {
                        //   setState(() {
                        //     isLoadingProgress = true;
                        //     isShowFloatButton = true;
                        //   });

                        //   loadTransactionsData(
                        //       name: result['name'],
                        //       status: result['status'],
                        //       fromDate: result['DateFrom'],
                        //       toDate: result['DateTo'],
                        //       isOffline: result['offline'],
                        //       transactionType: result['transaction_type']);
                        // }
                      })))
        ],
      ),
    );
  }

  onSearchTextChanged(String text) async {
    showLoaderText = Constants.LOADING;
    if (text.isEmpty) {
      isSearchParams = false;
      loadTransactionsData();
    } else {
      isSearchParams = true;
      // String parm = "?name=$text";
      loadTransactionsData(name: text);
    }
  }
}
