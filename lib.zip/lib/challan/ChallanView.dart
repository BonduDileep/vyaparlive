import 'package:vyaparlive/challan/ReceivedChallansPage.dart';
import 'package:vyaparlive/challan/SentChallansPage.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/core/enums/privilleges_enum.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Transaction/direcr_order_view/DirectOrderPage.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/MyDrawer.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/core/locator.dart';
import 'package:vyaparlive/core/view_models/homeview_model.dart';
import 'package:vyaparlive/model/Contacts.dart';
import 'dart:convert';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/Transaction/buyer/DiscussionView.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:socket_io_client/socket_io_client.dart' as io;
import 'package:vyaparlive/service/bu_list_grpc_service.dart';
import 'package:vyaparlive/service/invitation_services.dart';
import 'package:vyaparlive/utills/SharePref.dart';

import '../model/BuListModel.dart';
import '../offline_connections/FillOrderForm.dart';
import '../service/api_service/InvitationApiService.dart';

class ChallanView extends StatefulWidget {
  final bool isFromConnections;
  final bool isFromInternalConnection;
  final String? buId;
  final String? buName;
  final bool isFromBuList;
  final bool isFromHomePage;
  final bool isFromOfflineConnections;

  ChallanView(
      {this.isFromConnections = false,
      this.buId,
      this.buName,
      this.isFromBuList = false,
      this.isFromInternalConnection = false,
      this.isFromHomePage = false,
      this.isFromOfflineConnections = false});
  @override
  _ChallanViewState createState() => _ChallanViewState();
}

class _ChallanViewState extends State<ChallanView>
    with TickerProviderStateMixin {
  late TabController _tabController;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  String? buName = "";
  String? buId = "";
  String? userId = "";
  String? connectionBuId = "";
  Contacts? _contacts;
  Contacts? connectionDropdownValue;
  List<Contacts> _connectionsList = [];
  bool isLoading = false;
  String? connectionType;
  int tabIndexColorChange = 0;
  bool isLoadingProgress = false;
  String progressMessage = "Getting Connections..";
  String? params = "";
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  HomeViewModel? _homeViewModel = locator<HomeViewModel>();
  io.Socket? socket;
  late InvitationService _invitationService;
  String? rawMaterialTransactionRadioValue;
  String? actualTransactionRadioValue;
  bool isBuyProductsSelected = false;
  late BuListGrpcService _transactionService;
  int tabIndex = 1;
  bool isBuyList = true;
  bool isSellList = false;
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _invitationService = InvitationService();
    SharePref().getUserId().then((value) {
      userId = value;
    });
    if (AppController.instance.getIsFromConfirmationPage) {
      _homeViewModel!.initSocket(AppController.instance.getCnfTransactionId);
      _homeViewModel!.sendMessage(
          type: AppController.instance.getCnfType,
          message: json.encode(
            {
              "bu_id": AppController.instance.getCnfBuId,
              "message": AppController.instance.getCnfMessage,
            },
          ),
          userName: AppController.instance.getCnfUserName,
          transactionId: AppController.instance.getCnfTransactionId);

      this.clearAppControllerData();
    } else {
      _homeViewModel!.unSubscribes();
    }

    _tabController = TabController(length: 2, vsync: this);

    if (widget.isFromConnections) {
      _contacts = AppController.instance.getConnectionsData;
      // buName = _contacts!.buName;
      buName = AppController.instance.getBuName;
      params = _contacts!.buName;
      connectionBuId = _contacts!.buId;
      buId = AppController.instance.getMyBuId;
    } else if (widget.isFromInternalConnection) {
      // buName = widget.buName;
      buName = AppController.instance.getBuName;
      connectionBuId = widget.buId;
      buId = AppController.instance.getMyBuId;
      params = widget.buName;
    } else if (widget.isFromBuList) {
      // buName = widget.buName;
      buName = AppController.instance.getBuName;
      buId = widget.buId;
      params = "";
    } else if (widget.isFromOfflineConnections) {
      // buName = widget.buName;
      buName = AppController.instance.getBuName;
      params = widget.buName;
      connectionBuId = widget.buId;
      buId = AppController.instance.getMyBuId;
    } else {
      buName = AppController.instance.getBuName;
      buId = AppController.instance.getMyBuId;

      params = "";
    }
    loadConnectionsData("");
    _transactionService = BuListGrpcService();
  }

  Future<bool> onBackPress() async {
    if (widget.isFromBuList || widget.isFromHomePage) {
      return Navigator.canPop(context);
    } else {
      return CommonMethods.onBackPress(context);
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  void setState(VoidCallback fn) {
    // TODO: implement setState
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  Widget build(BuildContext context) {
    Size screensize = MediaQuery.of(context).size;
    return AppBackgroundView(
      body: Stack(
        children: [
          WillPopScope(
            child: SafeArea(
              child: Scaffold(
                  key: _scaffoldkey,
                  backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                  appBar: AppBar(
                    elevation: 0,
                    iconTheme: IconThemeData(color: theme.colorScheme.primary),
                    backgroundColor: Colors.transparent,
                    centerTitle: true,
                    title: AppbarName(
                        title: Language()
                            .getString(Constants.CHALLANS_STR, selectedLang),
                        buName: buName),
                    actions: <Widget>[
                      if (CommonMethods.isPrivillegeExist(
                          context, PrivillegesActions.KEY_TRANSACTIONS_ADD_ICON))
                        IconButton(
                            icon: Icon(Icons.add),
                            onPressed: () {
                              CommonMethods.hideKeyboard(context);
                              if (_connectionsList.length > 0) {
                                connectionDropdownValue = null;
                                connectionType = null;
                                showAllConnections();
                                // showDiscussionChoiceDialog();
                              } else {
                                Dialogs.yesCancelDialog(
                                    context,
                                    Language()
                                        .getString(Constants.ERROR, selectedLang),
                                    Language().getString(
                                        Constants.NO_CONNECTIONS_FOUND,
                                        selectedLang),
                                    Language().getString(
                                        Constants.OKAY_STR, selectedLang),
                                    "",
                                    false);
                              }
                            }),
                    ],
                    bottom: PreferredSize(
                      preferredSize: Size.fromHeight(screensize.height * 0.09),
                      child: TabBar(
                          indicatorSize: TabBarIndicatorSize.tab,
                          controller: _tabController,
                          onTap: (index) {
                            setState(() {
                              tabIndexColorChange = index;
                            });
                            CommonMethods.hideKeyboard(context);
                          },
                          indicator: BoxDecoration(
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey,
                                  blurRadius: 6.0,
                                ),
                                BoxShadow(
                                    color: Colors.white, offset: Offset(0, 9)),
                              ],
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(10),
                                  topRight: Radius.circular(10)),
                              color: Colors.white),
                          tabs: <Widget>[
                            Tab(
                              child: Text(
                                Language().getString(
                                    Constants.CHALLANS_SENT_STR, selectedLang),
                                style: TextStyle(
                                    color: theme.colorScheme.primary,
                                    fontWeight: StyleView.fontBold),
                              ),
                            ),
                            Tab(
                              child: Text(
                                Language().getString(
                                    Constants.CHALLANS_RECEIVED_STR,
                                    selectedLang),
                                style: TextStyle(
                                    color: theme.colorScheme.primary,
                                    fontWeight: StyleView.fontBold),
                              ),
                            ),
                          ]),
                    ),
                  ),
                  drawer: (widget.isFromBuList || widget.isFromHomePage)
                      ? null
                      : MyDrawer(),
                  body: TabBarView(
                      physics: NeverScrollableScrollPhysics(),
                      controller: _tabController,
                      children: [
                        SentChallansView(
                            buId: buId,
                            params: params,
                            connectionBuId: connectionBuId,
                            isFromConnection: widget.isFromConnections,
                            isFromInternalBu: widget.isFromInternalConnection,
                            isFromOfflineConnections:
                                widget.isFromOfflineConnections),
                        ReceivedChallansView(
                            buId: buId,
                            params: params,
                            connectionBuId: connectionBuId,
                            isFromConnection: widget.isFromConnections,
                            isFromOfflineConnections:
                                widget.isFromOfflineConnections,
                            isFromInternalBu: widget.isFromInternalConnection)
                      ])),
            ),
            onWillPop: onBackPress,
          ),
          AppUtills.showLoadingView(
              context: context,
              message: Language().getString(progressMessage, selectedLang),
              isLoading: isLoadingProgress),
        ],
      ),
    );
  }

  showAllConnections() {
    return showDialog(
      barrierColor: Colors.black54,
      barrierDismissible: false,
      context: context,
      builder: (context) => AlertDialog(
        elevation: 100.0,
        contentPadding: EdgeInsets.fromLTRB(15.0, 0, 15.0, 0),
        backgroundColor: Colors.white, //Color(0XFFE0E0E0),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(
            Radius.circular(7.0),
          ),
        ),
        actions: [
          Container(
              width: MediaQuery.of(context).size.width,
              padding: EdgeInsets.only(bottom: 10),
              child: CommonButtonsView(
                context: context,
                b1Text:
                    Language().getString(Constants.STR_CANCEL, selectedLang),
                b2Text: Language().getString(Constants.OKAY_STR, selectedLang),
                onb1Action: () {
                  connectionDropdownValue = null;
                  connectionType = null;

                  Navigator.of(context).pop();
                },
                onb2Action: () {
                  Navigator.of(context).pop();
                  if (connectionDropdownValue!.isOnline) {
                    Navigator.push(
                      context,
                      PageTransition(
                        context: context,
                        page: DirectOrderPage(
                          isForSell: true,
                          isOnline: connectionDropdownValue!.isOnline,
                          connectionId: connectionDropdownValue!.buId,
                          connectionName: connectionDropdownValue!.buName,
                          isChallan: true,
                        ),
                      ),
                    );
                  } else {
                    Navigator.push(
                      context,
                      PageTransition(
                        context: context,
                        page: FillOrderForm(
                          contactName: connectionDropdownValue!.buName,
                          recordId: connectionDropdownValue!.buId,
                          isChallan: true,
                        ),
                      ),
                    );
                  }
                },
              ))
        ],
        title: Text(
          Language().getString(
              Constants.SELECT_CONNECTION,
              selectedLang),
          style: TextStyle(color: theme.colorScheme.primary, fontSize: 15.0),
        ),
        titlePadding: EdgeInsets.fromLTRB(17.0, 24.0, 0.0, 10.0),
        content: StatefulBuilder(
            builder: (BuildContext context, StateSetter setState) {
          return Container(
              padding: EdgeInsets.only(bottom: 20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    height: 50.0,
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(5.0),
                        border: Border.all(
                            color: const Color.fromARGB(255, 10, 2, 2))),
                    width: MediaQuery.of(context).size.width,
                    padding: EdgeInsets.all(5.0),
                    child: DropdownButton<Contacts>(
                      isExpanded: true,
                      value: connectionDropdownValue,
                      underline: SizedBox(),
                      hint: Text(Language().getString(
                          Constants.PLEASE_SELECT_CONNECTION, selectedLang)),
                      onChanged: (Contacts? newValue) {
                        setState(() {
                          connectionDropdownValue = newValue;
                        });
                      },
                      items: _connectionsList.map((Contacts value) {
                        return DropdownMenuItem<Contacts>(
                          value: value,
                          child: Container(
                              padding: EdgeInsets.all(7.0),
                              child: Text(value.isOnline
                                  ? value.buName!
                                  : "${value.buName!} (Offline)")),
                        );
                      }).toList(),
                    ),
                  ),
                ],
              ));
        }),
      ),
    );
  }

  showDiscussionChoiceDialog() {
    return showDialog(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(15.0))),
              title: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Container(
                    child: Text(
                      Language().getString("Discussion For", selectedLang),
                      style: TextStyle(
                          color: theme.colorScheme.primary,
                          fontWeight: FontWeight.w700,
                          fontSize: 15.0),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      isBuyProductsSelected = false;
                      rawMaterialTransactionRadioValue = null;
                      actualTransactionRadioValue = null;
                      Navigator.of(context).pop();
                    },
                    child: Icon(
                      Icons.close,
                      color: Colors.red,
                    ),
                  ),
                ],
              ),
              content:
                  StatefulBuilder(builder: (context, StateSetter setState) {
                return Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Container(
                      width: MediaQuery.of(context).size.width,
                      height: 50,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                            borderRadius: new BorderRadius.circular(30.0),
                          ),
                          backgroundColor: theme.colorScheme.primary,
                          textStyle: TextStyle(
                              color: Colors.white,
                              fontFamily: StyleView.FONT_TEXT),
                          elevation: 3.0,
                        ),
                        onPressed: () => {
                          setState(() {
                            isBuyProductsSelected = true;
                          }),
                          Navigator.of(context).pop(),
                          showAllConnections(),
                          // this.createProductTransaction()
                        },
                        child: Padding(
                          padding: EdgeInsets.symmetric(vertical: 15),
                          child: Text(Language()
                              .getString(Constants.BUY_PRODUCTS, selectedLang)),
                        ),
                      ),
                    ),
                    SizedBox(height: 10.0),
                    Container(
                      width: MediaQuery.of(context).size.width,
                      height: 50,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                            borderRadius: new BorderRadius.circular(30.0),
                          ),
                          backgroundColor: theme.colorScheme.primary,
                          textStyle: TextStyle(
                              color: Colors.white,
                              fontFamily: StyleView.FONT_TEXT),
                          elevation: 3.0,
                        ),
                        onPressed: () => {
                          setState(() {
                            isBuyProductsSelected = false;
                          }),
                          // Future.delayed(Duration.zero).then((value) async {
                          //   if (await NetworkStatus.getInternetStatus()) {
                          //     setState(() {
                          //       isLoadingProgress = true;
                          //     });
                          //     this.postBodyForProductsSell();
                          //   } else {
                          //     AppUtills.showSnackBar(
                          //         _scaffoldkey,
                          //         Language().getString(
                          //             Constants.NO_INTERNET, selectedLang),
                          //         snackBarBgColor: Colors.black,
                          //         messageColor: Colors.white,
                          //         buttonColor: Colors.white);
                          //   }
                          // }),
                          Navigator.of(context).pop(),
                          showAllConnections(),
                        },
                        child: Padding(
                          padding: EdgeInsets.symmetric(vertical: 15),
                          child: Text(Language().getString(
                              Constants.SELL_PRODUCTS, selectedLang)),
                        ),
                      ),
                    )
                  ],
                );
              }));
        });
  }

  postBodyForProductsSell() async {
    Map data = {
      "id": "",
      "is_offline": !connectionDropdownValue!
          .isOnline, // !connectionDropdownValue!.isOnline,
      "buyer": {
        "id": connectionDropdownValue!.buId,
        "name": connectionDropdownValue!.buName,
        "is_offline": !connectionDropdownValue!.isOnline
      },
      "seller": {
        "id": buId,
        "name": buName,
      },
      "sales": {
        "seller": {"id": userId}
      },
      "ctr": {"type": "", "Agent": "", "transaction_ref": ""},
      "discussion": {
        "initiator": buId,
        "initiator_user": buName,
        "message_start_date": "",
        "confirmation_message": [],
        "confirmation_status": ""
      }
    };
    String body = json.encode(data);
    print("post body buy products: $body");
    var response = await _transactionService
        .beginTransaction(body, AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);

      Navigator.push(
        context,
        new MaterialPageRoute(
          builder: (context) => DiscussionView(
              transactionId: data,
              transactionName: connectionDropdownValue!.buName,
              isFromTransaction: true),
        ),
      );
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  postBodyForProductsBuy({String? raw}) async {
    Map data = {
      "id": "",
      "is_offline": !connectionDropdownValue!.isOnline,
      "buyer": {
        "id": buId,
        "name": buName,
      },
      "seller": {
        "id": connectionDropdownValue!.buId,
        "name": connectionDropdownValue!.buName,
        "is_offline": !connectionDropdownValue!.isOnline
      },
      "sales": {
        "buyer": {"id": userId}
      },
      "ctr": {"type": "", "Agent": "", "transaction_ref": ""},
      "discussion": {
        "initiator": buId,
        "initiator_user": buName,
        "message_start_date": "",
        "confirmation_message": [],
        "confirmation_status": ""
      }
    };
    if (isBuyProductsSelected && rawMaterialTransactionRadioValue != null) {
      data['transaction_type'] = Constants.KEY_RAW_MATERIAL;
    }

    String body = json.encode(data);
    print("postBodyForProductsBuy ${body}");
    var response = await _transactionService
        .beginTransaction(body, AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);

      Navigator.push(
          context,
          new MaterialPageRoute(
              builder: (context) => DiscussionView(
                    transactionId: data,
                    transactionName: connectionDropdownValue!.buName,
                    isFromTransaction: true,
                  )));
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  clearAppControllerData() {
    AppController.instance.setCnfBuId = null;
    AppController.instance.setCnfMessage = null;
    AppController.instance.setCnfTransactionId = null;
    AppController.instance.setCnfType = null;
    AppController.instance.setCnfUserName = null;
    AppController.instance.setIsFromConfirmationPage = false;
  }

  loadConnectionsData(String parms) async {
    if (await NetworkStatus.getInternetStatus()) {
      this.getContacts(buId, parms).then((onValue) {
        setState(() {
          if (onValue.length > 0) {
            _connectionsList.clear();
            _connectionsList.addAll(onValue);
          }
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<Contacts>> getContacts(String? buId, String parms) async {
    setState(() {
      _connectionsList.clear();
    });
    String body = json.encode({"buId": buId, "filters": {}});

    List<Contacts> _model = [];

    Map<String, dynamic> mapData = {"name": params};
    List<BuListModel> fetchOfflineUsers = await InvitationApiService.instance
        .getOfflineUsersByBuId(
            context: context,
            buId: buId!,
            mapData: mapData,
            langError: Language().getString(Constants.ERROR, selectedLang),
            langOk: Language().getString(Constants.OKAY_STR, selectedLang));

    for (var i = 0; i < fetchOfflineUsers.length; i++) {
      var element = fetchOfflineUsers[i];
      Contacts contacts = new Contacts();
      contacts.buId = element.recordId;
      contacts.buName = element.name;
      contacts.contactNumber = element.contact;
      contacts.city =
          element.address != null && element.address!.villagetowncity != null
              ? element.address!.villagetowncity
              : "";
      contacts.isOnline = false;
      _model.add(contacts);
    }

    var response = await _invitationService
        .findAllConnections_grpc(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    // setState(() {
    isLoadingProgress = false;
    // });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(resObj)) {
        for (var noteJson in resObj['results']) {
          _model.add(Contacts.fromJson(noteJson));
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }

    _model.sort((a, b) => a.buName.toString().compareTo(b.buName.toString()));
    return _model;
  }

  createProductTransaction() async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
        progressMessage = Constants.CREATING;
      });
      this.postBodyForProductsBuy();
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }
}
