import 'package:flutter_redux/flutter_redux.dart';
import 'package:vyaparlive/Home/HomePageView.dart';
import 'package:vyaparlive/redux/actions/menu_action.dart';
import 'package:vyaparlive/redux/state/app_state.dart';
import 'package:vyaparlive/service/api_service/OrganizationApiService.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:vyaparlive/Organization/AllBUListPage.dart';
import 'package:vyaparlive/Organization/DirectorsPage.dart';
import 'package:vyaparlive/Organization/OrganizatioDetailsPage.dart';
import 'package:vyaparlive/Organization/OrganizationFieldsData.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/privileges/privilege_handler.dart';
import 'package:vyaparlive/locations_view/BuLocationsList.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/roles_view/RolesList.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/model/BusinessUnitModel.dart';
import 'package:vyaparlive/model/RolesDAO.dart';
import 'package:vyaparlive/service/organization_service.dart';
import 'package:vyaparlive/service/user_services.dart';
import 'dart:convert';
import 'package:vyaparlive/utills/SharePref.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';

class CreateBUView extends StatefulWidget {
  CreateBUView(
      {this.title,
      this.orgId,
      this.businessUnitModel,
      this.buName,
      this.isOrgUpdate});
  final String? title;
  final String? orgId;
  final String? buName;
  final bool? isOrgUpdate;
  final BusinessUnitModel? businessUnitModel;
  @override
  _CreateBUViewState createState() => _CreateBUViewState();
}

class _CreateBUViewState extends State<CreateBUView>
    with TickerProviderStateMixin {
  TabController? _tabController;
  bool isCompleteStepOne = false;
  bool isCompleteStepTwo = false;
  bool isCompleteStepThree = false;
  bool isCompleteStepFour = false;
  int currentStep = 0;
  int tabIndex = 0;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  String? userId;
  late SharedPreferences sharedPreferences;
  OrganizationFieldsData? _orgFieldsData;
  bool isLoading = false;
  List<RolesDAO> _rolesList = [];
  String? buName = "";

  List<String> titles = ["Roles", "Locations"];

  bool isForSaveAndExit = false;
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  late OrganizationService _organizationService;
  late UserService _userService;
  String? userPhoneNumber = "";
  String? password = "";
  String? userName = "";
  num nTabs = 2;
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _organizationService = OrganizationService();
    _userService = UserService();
    OrganizationFieldsData org = OrganizationFieldsData();
    AppController.instance.setOrganizationFieldsData = org;
    AppController.instance.saveCurrentOrgId = widget.orgId;
    buName = widget.buName != null
        ? widget.buName
        : AppController.instance.getBuName;
    AppController.instance.isOrganizationUpdate = widget.isOrgUpdate;
    _orgFieldsData = OrganizationFieldsData();
    _tabController = TabController(length: 3, vsync: this);
    SharePref().getUserId().then((onValue) {
      setState(() {
        userId = onValue;
      });
    });

    SharePref().getUserName().then((value) => this.userName = value);
    if (AppController.instance.isOrganizationUpdate!) {
      getRolePermissionsList().then((value) {
        setState(() {
          _rolesList.addAll(value);
        });
      });
    }

    SharePref().getPhoneNumber().then((value) {
      setState(() {
        userPhoneNumber = value;
      });
    });

    SharePref().getPassword().then((value) {
      setState(() {
        password = value;
      });
    });
  }

  /// Service call for get roles for bu

  Future<List<RolesDAO>> getRolePermissionsList() async {
    String body = json.encode({"id": AppController.instance.getCurrentOrgId});
    var response = await _organizationService
        .getOrganizationDataById(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<RolesDAO> _list = [];

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;

    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      if (resObj[0]["roles"] != null) {
        for (var data in resObj[0]["roles"]) _list.add(RolesDAO.fromJson(data));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }

    return _list;
  }

  onNextStep() {
    switch (_tabController!.index) {
      case 0:
        String validateError = validateFields();
        if (validateError.isNotEmpty) {
          Dialogs.yesCancelDialog(
              context,
              Language().getString(Constants.ALERT, selectedLang),
              Language().getString(validateError, selectedLang),
              Language().getString(Constants.OKAY_STR, selectedLang),
              "",
              false);
        } else {
          if (widget.isOrgUpdate!) {
            serviceCallUpdateBu();
          } else {
            serviceCallCreateBu();
          }
        }
        break;
      case 1:
        serviceCallUpdateBu();
        break;
      case 2:
        serviceCallUpdateBu();
        break;
      default:
    }
  }

  /// Validating bu basic details

  String validateFields() {
    if (AppController.instance.getOrganizationFieldsData.businessName == null ||
        AppController.instance.getOrganizationFieldsData.businessName.isEmpty) {
      return Constants.PLEASE_ENTER_BUSINESS_NAME;
    } else if (AppController.instance.getOrganizationFieldsData.businessHob ==
            null ||
        AppController.instance.getOrganizationFieldsData.businessHob.isEmpty) {
      return Constants.PLEASE_ENTER_HOB;
    }
    // else if (AppController.instance.getOrganizationFieldsData.businessType ==
    //         null ||
    //     AppController.instance.getOrganizationFieldsData.businessType.isEmpty) {
    //   return Constants.PLEASE_SELECT_BUSINESS_TYPE;
    // }
    //  else if (AppController
    //             .instance.getOrganizationFieldsData.buContactNumber ==
    //         null ||
    //     AppController
    //         .instance.getOrganizationFieldsData.buContactNumber.isEmpty) {
    //   return Constants.PLEASE_ENTER_OFFICE_NUMBER;
    // }
    else if (AppController.instance.getOrganizationFieldsData.mobileNumber ==
            null ||
        AppController.instance.getOrganizationFieldsData.mobileNumber.isEmpty) {
      return Constants.ENTER_MOBILE_NUMBER;
    } else if (AppController.instance.getLocations.length == 0) {
      return Constants.PLEASE_ADD_BU_LOCATION;
    } else {
      return "";
    }
  }

  Widget renderViews() {
    if (tabIndex == 0) {
      return Expanded(
        child: Container(
          color: Colors.transparent, //(Constants.APP_BACKGROUND_COLOR),
          child:
              new DirectorsView(orgId: AppController.instance.getCurrentOrgId),
        ),
      );
    }
    //  else if (tabIndex == 1) {
    //   return Expanded(
    //       child: Container(
    //     color: Colors.transparent,
    //     child: new BusinessDetailsView(
    //         orgId: AppController.instance.getCurrentOrgId),
    //   ));
    // }
    else {
      return Expanded(
          child: Container(
        color: Colors.transparent,
        child: new OrganizationDetailsView(
            organizationId: (widget.title == Constants.CREATE_BUSINESS_UNIT)
                ? AppController.instance.getMyBuId
                : widget.orgId),
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
        body: Stack(
      children: [
        SafeArea(
          child: Scaffold(
              key: _scaffoldkey,
              backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
              appBar: AppBar(
                iconTheme: IconThemeData(color: theme.colorScheme.primary),
                leading: IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: Icon(Icons.arrow_back)),
                title: AppbarName(
                    title: Language().getString(
                        widget.isOrgUpdate!
                            ? Constants.EDIT_BUSINESS_UNIT
                            : Constants.CREATE_BUSINESS_UNIT,
                        selectedLang),
                    buName: buName != null ? buName : ""),
                centerTitle: true,
                backgroundColor:
                    Colors.transparent, //Color(Constants.APP_COLOR),
                elevation: 0.0,
              ),
              bottomNavigationBar: bottomView(),
              // endDrawer: endDrawerView(),
              body: Container(
                padding: EdgeInsets.all(16),
                child: Column(
                  children: [
                    Row(children: stepperView()),
                    Expanded(child: Column(children: [renderViews()]))
                  ],
                ),
              )),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    ));
  }

  Widget? endDrawerView() {
    if (widget.title == Constants.EDIT_BUSINESS_UNIT) {
      return Container(
        width: MediaQuery.of(context).size.width * 0.55,
        child: Drawer(
          elevation: 5.0,
          child: Container(
              color: Color(Constants.APP_COLOR),
              child: ListView.separated(
                  separatorBuilder: (context, int index) => new Divider(),
                  itemCount: titles.length,
                  itemBuilder: (context, int index) => new ListTile(
                        title: Text(
                          titles[index],
                          style: TextStyle(color: Colors.white, fontSize: 18.0),
                        ),
                        onTap: () {
                          Navigator.of(context).pop();
                          switch (index) {
                            case 0:
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => RolesListView(
                                          buId: AppController
                                              .instance.getCurrentOrgId)));
                              break;
                            case 1:
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => BuLocationsListPage(
                                            buId: widget.orgId,
                                            buName: widget.buName,
                                          )));
                              break;
                            default:
                          }
                        },
                      ))),
        ),
      );
    } else {
      return null;
    }
  }

  Widget bottomView() {
    return Container(
      padding:
          EdgeInsets.symmetric(horizontal: 10, vertical: (kIsWeb) ? 30 : 10),
      child: CommonButtonsView(
        context: context,
        b1Color: theme.colorScheme.primary,
        b2Color: theme.colorScheme.primary,
        b1TextColor: Colors.white,
        b2TextColor: Colors.white,
        b1Text:
            Language().getString(Constants.SAVE_AND_EXIT_STRING, selectedLang),
        b2Text: Language().getString(Constants.SAVE_AND_NEXT, selectedLang),
        onb1Action: () {
          if (!AppController.instance.getCreateBuProgress) {
            setState(() {
              isForSaveAndExit = true;
            });
            onNextStep();
          }
        },
        onb2Action: () {
          if (!AppController.instance.getCreateBuProgress) {
            setState(() {
              isForSaveAndExit = false;
            });
            onNextStep();
          }
        },
      ),
    );
  }

  Color circleContainerColor(index) {
    Color _customColor;
    if (index < tabIndex) {
      _customColor = Colors.black;
    } else if (index == tabIndex) {
      _customColor = Colors.black;
    } else {
      _customColor = Colors.grey;
    }
    return _customColor;
  }

  Color circleContainerBorder(index) {
    Color _customBorder;
    if (index < tabIndex) {
      _customBorder = Colors.black;
    } else if (index == tabIndex) {
      _customBorder = Colors.black;
    } else {
      _customBorder = Colors.grey;
    }
    return _customBorder;
  }

  Widget completeSterView(index) {
    if (index < tabIndex) {
      return Icon(
        Icons.check,
        size: 20,
        color: Colors.white,
      );
    } else if (index == tabIndex) {
      return Text(
        "${index + 1}",
        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
      );
    } else {
      return Text("${index + 1}");
    }
  }

  Color? lineColor(index) {
    Color? _customLineColor;
    if (index < tabIndex) {
      _customLineColor = Colors.green;
    } else if (index == tabIndex) {
      _customLineColor = Colors.grey;
    }

    return _customLineColor;
  }

  List<Widget> stepperView() {
    List<Widget> _list = [];

    for (int i = 0; i < nTabs; i++) {
      _list.add(Container(
        height: 30,
        width: 30,
        alignment: Alignment.center,
        decoration: BoxDecoration(
            color: circleContainerColor(i),
            borderRadius: BorderRadius.all(Radius.circular(30 / 2)),
            border: Border.all(color: circleContainerBorder(i))),
        child: completeSterView(i),
      ));
      if (i != nTabs - 1) {
        _list.add(
          Expanded(
            child: Container(
              height: 3.5,
              color: Colors.grey,
            ),
          ),
        );
      }
    }
    return _list;
  }

  serviceCallUpdateBu() async {
    if (await NetworkStatus.getInternetStatus()) {
      this.updateBusinessDetaills();
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  serviceCallCreateBu() async {
    if (await NetworkStatus.getInternetStatus()) {
      this.createBusinessUnit();
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  /// Service call for updating bu details

  void updateBusinessDetaills() async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = Language().getString(Constants.UPDATING, selectedLang);
    });
    _orgFieldsData = AppController.instance.getOrganizationFieldsData;
    List<Map<String, dynamic>> directorsArray = [];
    var directorsObject;
    List<Map<String, dynamic>> taxSchemeArray = [];
    var taxSchemeObject;
    List<Map<String, dynamic>> regulationArray = [];
    var regulationObject;
    List<Map<String, dynamic>> exportsArray = [];
    var exportsObject;
    List<Map<String, dynamic>> importsArray = [];
    var importsObject;
    List<Map<String, dynamic>> stockReceiveArray = [];
    var stockReceiveObject;
    List<Map<String, dynamic>> stockDispatchArray = [];
    var stockDispatchObject;
    List<Map<String, dynamic>> bankReceiveArray = [];
    var bankReceiveObject;
    List<Map<String, dynamic>?> termsArray = [];
    var termsObject;

    if (_orgFieldsData!.termsAndConditionsList != null &&
        _orgFieldsData!.termsAndConditionsList!.length > 0) {
      for (int i = 0; i < _orgFieldsData!.termsAndConditionsList!.length; i++) {
        termsObject = {
          "term_type": _orgFieldsData!.termsAndConditionsList![i].termType,
          "term_description":
              _orgFieldsData!.termsAndConditionsList![i].termDescription,
          "file": _orgFieldsData!.termsAndConditionsList![i].imageRelativePath
        };
      }
      termsArray.add(termsObject);
    }

    if (_orgFieldsData!.directorsData != null &&
        _orgFieldsData!.directorsData!.length > 0) {
      for (int i = 0; i < _orgFieldsData!.directorsData!.length; i++) {
        directorsObject = {
          "id": "1",
          "person_name": _orgFieldsData!.directorsData![i].personName,
          "personidentification_schemename":
              _orgFieldsData!.directorsData![i].personSchemeName,
          "personidentification_number":
              _orgFieldsData!.directorsData![i].personIdentificationNumber,
          "digital_signature":
              _orgFieldsData!.directorsData![i].digitalSignature
        };
        directorsArray.add(directorsObject);
      }
    }

    if (_orgFieldsData!.stockReceiveArray != null &&
        _orgFieldsData!.stockReceiveArray!.length > 0) {
      for (int i = 0; i < _orgFieldsData!.stockReceiveArray!.length; i++) {
        stockReceiveObject = {
          "location_id": _orgFieldsData!.stockReceiveArray![i].locationId,
          "location_type": "STOCK_RECEIVE",
          "location_name":
              _orgFieldsData!.stockReceiveArray![i].stockLocationName,
          "contact_person": _orgFieldsData!.stockReceiveArray![i].userName,
          "contact_number":
              _orgFieldsData!.stockReceiveArray![i].stockLocationNumber,
          "address": {
            "buildinghousenumber":
                _orgFieldsData!.stockReceiveArray![i].houseNo,
            "building_no": _orgFieldsData!.stockReceiveArray![i].buildingNo,
            "buildingstreetname":
                _orgFieldsData!.stockReceiveArray![i].streetName,
            "colonysector_arealocality":
                _orgFieldsData!.stockReceiveArray![i].locality,
            "landmark": _orgFieldsData!.stockReceiveArray![i].landmark,
            "country": _orgFieldsData!.stockReceiveArray![i].country,
            "state": _orgFieldsData!.stockReceiveArray![i].state,
            "plot_no": _orgFieldsData!.stockReceiveArray![i].plotNo,
            "district": _orgFieldsData!.stockReceiveArray![i].district,
            "villagetowncity": _orgFieldsData!.stockReceiveArray![i].city,
            "taluka": _orgFieldsData!.stockReceiveArray![i].taluka,
            "postcode": _orgFieldsData!.stockReceiveArray![i].postalCode,
          }
        };
        stockReceiveArray.add(stockReceiveObject);
      }
    }

    if (_orgFieldsData!.stockDispatchArray != null &&
        _orgFieldsData!.stockDispatchArray!.length > 0) {
      for (int i = 0; i < _orgFieldsData!.stockDispatchArray!.length; i++) {
        stockDispatchObject = {
          "location_id": _orgFieldsData!.stockDispatchArray![i].locationId,
          "location_type": "STOCK_DISPATCH",
          // "dispatchlocation_number":
          //     _orgFieldsData.stockDispatchArray[i].stockLocationNumber,
          // "dispatchbusiness_name":
          //     _orgFieldsData.stockDispatchArray[i].stockLocationName,
          "location_name":
              _orgFieldsData!.stockDispatchArray![i].stockLocationName,
          "contact_person": _orgFieldsData!.stockDispatchArray![i].userName,
          "contact_number":
              _orgFieldsData!.stockDispatchArray![i].stockLocationNumber,

          // "addressofsender":
          "address": {
            "buildinghousenumber":
                _orgFieldsData!.stockDispatchArray![i].houseNo,
            "building_no": _orgFieldsData!.stockDispatchArray![i].buildingNo,
            "buildingstreetname":
                _orgFieldsData!.stockDispatchArray![i].streetName,
            "colonysector_arealocality":
                _orgFieldsData!.stockDispatchArray![i].locality,
            "landmark": _orgFieldsData!.stockDispatchArray![i].landmark,
            "country": _orgFieldsData!.stockDispatchArray![i].country,
            "state": _orgFieldsData!.stockDispatchArray![i].state,
            "plot_no": _orgFieldsData!.stockDispatchArray![i].plotNo,
            "district": _orgFieldsData!.stockDispatchArray![i].district,
            "villagetowncity": _orgFieldsData!.stockDispatchArray![i].city,
            "taluka": _orgFieldsData!.stockDispatchArray![i].taluka,
            "postcode": _orgFieldsData!.stockDispatchArray![i].postalCode,
            // "user": _orgFieldsData.stockDispatchArray[i].userName
          }
        };
        stockDispatchArray.add(stockDispatchObject);
      }
    }

    if (_orgFieldsData!.taxSchemeArray != null &&
        _orgFieldsData!.taxSchemeArray!.length > 0) {
      for (int i = 0; i < _orgFieldsData!.taxSchemeArray!.length; i++) {
        taxSchemeObject = {
          "id": "1",
          "govttaxscheme_name":
              _orgFieldsData!.taxSchemeArray![i].govttaxscheme_name,
          "govttaxscheme_number":
              _orgFieldsData!.taxSchemeArray![i].govttaxscheme_number,
          "taxexemption_reason":
              _orgFieldsData!.taxSchemeArray![i].taxexemption_reason
        };
        taxSchemeArray.add(taxSchemeObject);
      }
    }
    if (_orgFieldsData!.regulationArray != null &&
        _orgFieldsData!.regulationArray!.length > 0) {
      for (int i = 0; i < _orgFieldsData!.regulationArray!.length; i++) {
        regulationObject = {
          "govtbusiness_schemeid":
              _orgFieldsData!.regulationArray![i].govtbusinessSchemeid,
          "govtregistration_id":
              _orgFieldsData!.regulationArray![i].govtregistrationId
        };
        regulationArray.add(regulationObject);
      }
    }

    if (_orgFieldsData!.exportsArray != null &&
        _orgFieldsData!.exportsArray!.length > 0) {
      for (int i = 0; i < _orgFieldsData!.exportsArray!.length; i++) {
        exportsObject = {
          "country": "india",
          "govtregistration_schemename":
              _orgFieldsData!.exportsArray![i].govtregistrationSchemename,
          "govtregistration_schemeid":
              _orgFieldsData!.exportsArray![i].govtregistrationSchemeid
        };
        exportsArray.add(exportsObject);
      }
    }

    if (_orgFieldsData!.importsArray != null &&
        _orgFieldsData!.importsArray!.length > 0) {
      for (int i = 0; i < _orgFieldsData!.importsArray!.length; i++) {
        importsObject = {
          "country": "india",
          "govtregistration_schemename":
              _orgFieldsData!.importsArray![i].govtregistrationSchemename,
          "govtregistration_schemeid":
              _orgFieldsData!.importsArray![i].govtregistrationSchemeid
        };
        importsArray.add(importsObject);
      }
    }

    if (_orgFieldsData!.bankReceiveArray != null &&
        _orgFieldsData!.bankReceiveArray!.length > 0) {
      for (int i = 0; i < _orgFieldsData!.bankReceiveArray!.length; i++) {
        bankReceiveObject = {
          "id": "",
          "BankName": _orgFieldsData!.bankReceiveArray![i].bankname,
          "BankAccountName":
              _orgFieldsData!.bankReceiveArray![i].bankaccountname,
          "BankAccountNumber":
              _orgFieldsData!.bankReceiveArray![i].bankAccountNumber,
          "EPayCode": _orgFieldsData!.bankReceiveArray![i].epayCode,
          "SWIFTcode": _orgFieldsData!.bankReceiveArray![i].swiftCode,
          "MICRCode": _orgFieldsData!.bankReceiveArray![i].micrCode,
          "IFSC Code": _orgFieldsData!.bankReceiveArray![i].ifscCode,
          "show_bank_details":
              _orgFieldsData!.bankReceiveArray![i].isShowInvoiceView
        };
        bankReceiveArray.add(bankReceiveObject);
      }
    }

    List<String> advancePaymentValue = [];
    String advancePaymentType = "";

    if (_orgFieldsData!.advancePaymentValue == Constants.YES_STRING &&
        _orgFieldsData!.advancePaymentPercentage != null) {
      advancePaymentValue =
          _orgFieldsData!.advancePaymentPercentage!.split(' %');
      advancePaymentType = "percentage";
    }

    List<String> penaltyAmountValue = [];
    String penaltyAmountType = "";

    if (_orgFieldsData!.penaltyAmountPercentage != null) {
      penaltyAmountValue = _orgFieldsData!.penaltyAmountPercentage!.split(' %');
      penaltyAmountType = "percentage";
    }

    List<Map<String, dynamic>> mainLocation = [];
    var mainLocationObject = {
      // "primarycontactname": _orgFieldsData.contactName,
      "location_name": "Main Office",
      "contact_person": userName,
      "contact_number": userPhoneNumber,
      "location_type": "MAIN_OFFICE",
      "location_id": _orgFieldsData!.mainOfficeLocationId,
      "address": {
        // "addressformat": _orgFieldsData.contactAddressFormat,
        "businesslocationnumber": _orgFieldsData!.locality,
        "buildinghousenumber": _orgFieldsData!.houseNo,
        "building_no": _orgFieldsData!.buildingNo,
        "buildingstreetname": _orgFieldsData!.streetName,
        "colonysector_arealocality": _orgFieldsData!.locality,
        "villagetowncity": _orgFieldsData!.city,
        "taluk": _orgFieldsData!.taluk,
        "plot_no": _orgFieldsData!.orgPlotNo,
        "landmark": _orgFieldsData!.landMark,
        "state": _orgFieldsData!.state != null ? _orgFieldsData!.state : null,
        "district":
            _orgFieldsData!.district != null ? _orgFieldsData!.district : null,
        "postcode": _orgFieldsData!.postalCode,
        "country":
            _orgFieldsData!.country != null ? _orgFieldsData!.country : null,
        "phone_number_on_invoice": _orgFieldsData!.invoicePhoneNumber,
        "email_on_invoice": _orgFieldsData!.invoiceEmail
      }
    };
    mainLocation.add(mainLocationObject);
    List<Map<String, dynamic>> _locationsList = [];
    _locationsList.addAll(mainLocation);
    _locationsList.addAll(stockReceiveArray);
    _locationsList.addAll(stockDispatchArray);

    /// Preparing bu object
    Map data = {
      "id": AppController.instance.getCurrentOrgId,
      "user_id": userId,
      "business_name": _orgFieldsData!.businessName,
      "short_name": _orgFieldsData!.shortName,
      "website": _orgFieldsData!.website,
      "head_of_business": _orgFieldsData!.businessHob,
      "location": _orgFieldsData!.businessLocation,
      "type": _orgFieldsData!.businessType,
      "contact_number": _orgFieldsData!.buContactNumber,
      "mobile_number": _orgFieldsData!.mobileNumber,
      "country_code": _orgFieldsData!.countryCode != null
          ? _orgFieldsData!.countryCode
          : "",
      "currency_code": _orgFieldsData!.currencyCode != null
          ? _orgFieldsData!.currencyCode
          : "",
      "registration": {
        "govtregistered_name": _orgFieldsData!.regOrgName,
        "legalentity_type": _orgFieldsData!.regentityType != null
            ? _orgFieldsData!.regentityType
            : null,
        "govtregistration_scheme":
            _orgFieldsData!.regScheme != null ? _orgFieldsData!.regScheme : "",
        "registration_date": _orgFieldsData!.regOrgDate,
        "registration_city": _orgFieldsData!.regOrgCity != null
            ? _orgFieldsData!.regOrgCity
            : null,
        "registration_state": _orgFieldsData!.regOrgState != null
            ? _orgFieldsData!.regOrgState
            : null,
        "registration_country": _orgFieldsData!.regOrgCountry != null
            ? _orgFieldsData!.regOrgCountry
            : null,
        "pan_number": _orgFieldsData!.panCardNumber,
        "cin_number": _orgFieldsData!.cinCardNumber
      },
      "directors": directorsArray,
      "tax_scheme": taxSchemeArray,
      "contact_details": null,
      // {
      //   "primarycontactname": _orgFieldsData!.contactName,
      //   "address": {
      //     "businesslocationnumber": _orgFieldsData!.locality,
      //     "buildinghousenumber": _orgFieldsData!.houseNo,
      //     "building_no": _orgFieldsData!.buildingNo,
      //     "buildingstreetname": _orgFieldsData!.streetName,
      //     "colonysector_arealocality": _orgFieldsData!.locality,
      //     "villagetowncity": _orgFieldsData!.city,
      //     "taluk": _orgFieldsData!.taluk,
      //     "plot_no": _orgFieldsData!.orgPlotNo,
      //     "landmark": _orgFieldsData!.landMark,
      //     "state": _orgFieldsData!.state != null ? _orgFieldsData!.state : null,
      //     "district": _orgFieldsData!.district != null
      //         ? _orgFieldsData!.district
      //         : null,
      //     "postcode": _orgFieldsData!.postalCode,
      //     "country":
      //         _orgFieldsData!.country != null ? _orgFieldsData!.country : null,
      //     "phone_number_on_invoice": _orgFieldsData!.invoicePhoneNumber,
      //     "email_on_invoice": _orgFieldsData!.invoiceEmail
      //   }
      // },
      "regulation": regulationArray,
      "exports": exportsArray,
      "imports": importsArray,
      "payment_terms": {
        "id": "",
        "invoice_currency_code": _orgFieldsData!.invoiceCurrencyCode,
        "invoice_payment_terms": _orgFieldsData!.invoicePaymentTerms,
        "term_code": _orgFieldsData!.paymentTermCode,
        "days": _orgFieldsData!.paymentTermDays,
        "penalty_amount": {
          "code": _orgFieldsData!.penaltyCode,
          "reason": _orgFieldsData!.penaltyAmountReason,
          "value": penaltyAmountValue.length > 0
              ? int.parse(penaltyAmountValue[0])
              : null,
          "type": penaltyAmountType,
        },
        "comments": _orgFieldsData!.paymentComments,
        "advance_payment": {
          "active": _orgFieldsData!.advancePaymentValue == Constants.YES_STRING
              ? true
              : false,
          "value": advancePaymentValue.length > 0
              ? int.parse(advancePaymentValue[0])
              : null,
          "type": advancePaymentType
        },
        "terms": termsArray,
      },
      "bank_details_receives": bankReceiveArray,
      "bank_details_payments": [],
      "roles": _orgFieldsData!.rolesArray,
      "confirm_order": _orgFieldsData!.getInpersonOrderAccept != null
          ? _orgFieldsData!.getInpersonOrderAccept
          : false,
      "GST_No": _orgFieldsData!.getGSTNumber,
      "currency_symbol": _orgFieldsData!.orgCurrencySymbol,
      "dial_code": _orgFieldsData!.orgCountryDialCode,
      "office_dial_code": _orgFieldsData!.officeDialCode,
      "currency_name": _orgFieldsData!.currencyName,
      "pan_no": _orgFieldsData!.panCardNumber,
      "email_id": _orgFieldsData!.invoiceEmail,
      "locations": AppController.instance.getLocations,
      "bu_logo_image": AppController.instance.getBuLogoImagePath
    };
    if (AppController.instance.getBuList != null &&
        AppController.instance.getBuList.length > 0 &&
        _orgFieldsData!.parentBuId != null) {
      Map parentObj = {
        "OrgId": _orgFieldsData != null ? _orgFieldsData!.parentBuId : "",
      };

      data["parent_details"] = parentObj;
    }

    String body = json.encode(data);

    var response = await _organizationService
        .updateOrganization(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      AppController.instance.setBuCountryDialCode =
          _orgFieldsData!.orgCountryDialCode;
      if (!isForSaveAndExit) {
        setState(() {
          tabIndex = _tabController!.index + 1;
          if (_tabController!.index == 0) {
            isCompleteStepOne = true;
            _tabController!.animateTo(tabIndex,
                duration: Duration(milliseconds: 500), curve: Curves.easeIn);
          }
          //  else if (_tabController!.index == 1) {
          //   isCompleteStepTwo = true;
          //   _tabController!.animateTo(tabIndex,
          //       duration: Duration(milliseconds: 500), curve: Curves.easeIn);
          // }
          else {
            isCompleteStepThree = true;
          }
        });
      }
      if (isForSaveAndExit) {
        final action = await Dialogs.yesCancelDialog(
            context,
            Language().getString(Constants.SUCCESS, selectedLang),
            Language()
                .getString(Constants.BU_DETAILS_UPDATED_STRING, selectedLang),
            Language().getString(Constants.OKAY_STR, selectedLang),
            "",
            false);

        if (action == DialogAction.yes) {
          if (AppController.instance.buList != null &&
              AppController.instance.buList!.length == 0) {
            Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (context) => HomePageView()),
                (Route<dynamic> route) => false);
          } else {
            Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(
                  builder: (context) => AllBUListView(
                    title: Constants.BUSINESS_UNIT_LIST_STRING,
                  ),
                ),
                (Route<dynamic> route) => false);
          }
        }
      } else {
        if (isCompleteStepThree) {
          final action = await Dialogs.yesCancelDialog(
              context,
              Language().getString(Constants.SUCCESS, selectedLang),
              Language()
                  .getString(Constants.BU_DETAILS_UPDATED_STRING, selectedLang),
              Language().getString(Constants.OKAY_STR, selectedLang),
              "",
              false);

          if (action == DialogAction.yes) {
            if (AppController.instance.buList != null &&
                AppController.instance.buList!.length == 0) {
              Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (context) => HomePageView()),
                  (Route<dynamic> route) => false);
            } else {
              Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(
                      builder: (context) => AllBUListView(
                            title: Constants.BUSINESS_UNIT_LIST_STRING,
                          )),
                  (Route<dynamic> route) => false);
            }

            AppController.instance.setInpersonOrdeerAccept =
                _orgFieldsData!.getInpersonOrderAccept != null
                    ? _orgFieldsData!.getInpersonOrderAccept
                    : false;
          }
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  /// Service call for create bu

  void createBusinessUnit() async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = Constants.CREATING;
    });
    _orgFieldsData = AppController.instance.getOrganizationFieldsData;
    Map data = {
      "user_id": userId,
      "business_name": _orgFieldsData!.businessName,
      "short_name": _orgFieldsData!.shortName,
      "website": _orgFieldsData!.website,
      "head_of_business": _orgFieldsData!.businessHob,
      "location": _orgFieldsData!.businessLocation,
      "type": _orgFieldsData != null ? _orgFieldsData!.businessType : "",
      "contact_number": _orgFieldsData!.buContactNumber,
      "mobile_number": _orgFieldsData!.mobileNumber,
      "country_code": _orgFieldsData != null ? _orgFieldsData!.countryCode : "",
      "currency_code":
          _orgFieldsData != null ? _orgFieldsData!.currencyCode : "",
      "GST_No": _orgFieldsData!.getGSTNumber,
      "pan_no": _orgFieldsData!.panCardNumber,
      "email_id": _orgFieldsData!.invoiceEmail,
      "currency_symbol": _orgFieldsData!.orgCurrencySymbol,
      "dial_code": _orgFieldsData!.orgCountryDialCode,
      "office_dial_code": _orgFieldsData!.officeDialCode,
      "currency_name": _orgFieldsData!.currencyName,
      "registration": {
        "govtregistered_name": _orgFieldsData!.regOrgName,
        "legalentity_type": _orgFieldsData!.regentityType != null
            ? _orgFieldsData!.regentityType
            : null,
        "govtregistration_scheme":
            _orgFieldsData!.regScheme != null ? _orgFieldsData!.regScheme : "",
        "registration_date": _orgFieldsData!.regOrgDate,
        "registration_city": _orgFieldsData!.regOrgCity != null
            ? _orgFieldsData!.regOrgCity
            : null,
        "registration_state": _orgFieldsData!.regOrgState != null
            ? _orgFieldsData!.regOrgState
            : null,
        "registration_country": _orgFieldsData!.regOrgCountry != null
            ? _orgFieldsData!.regOrgCountry
            : null,
      },
      "locations": AppController.instance.getLocations,
      "bu_logo_image": AppController.instance.getBuLogoImagePath
    };

    if (AppController.instance.getBuList != null &&
        AppController.instance.getBuList.length > 0 &&
        _orgFieldsData!.parentBuId != null) {
      Map parentObj = {
        "OrgId": _orgFieldsData!.parentBuId,
      };
      data["parent_details"] = parentObj;
    }

    String body = json.encode(data);
    // print("Create bu $body");
    var response = await _organizationService
        .createOrganization(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      AppController.instance.setBuCountryDialCode =
          _orgFieldsData!.orgCountryDialCode;
      var data = json.decode(_grpcResponse.message!);
      if (AppController.instance.getMyBuId == null ||
          AppController.instance.getMyBuId == "") {
        setState(() {
          isLoadingProgress = true;
          progressMessage = Constants.GETTING_DATA;
        });
        AppController.instance.setMyBuId = data;
        AppController.instance.setLocations = [];
        AppController.instance.saveCurrentOrgId = data;
        if (AppController.instance.getBuList == null ||
            AppController.instance.getBuList.length == 0) {
          var bu_list = await OrganizationApiService.instance.getUserBuList(
              context: context,
              userId: userId!,
              isUpdateRedux: true,
              langError: Language().getString(Constants.ERROR, selectedLang),
              langOk: Language().getString(Constants.OKAY_STR, selectedLang));

          if (bu_list.length > 0) {
            for (var i = 0; i < bu_list.length; i++) {
              if (bu_list[i].id == data) {
                StoreProvider.of<AppState>(context)
                    .dispatch(MenuAppState(featureMenu: bu_list[i].buFeatures!));
              }
            }
          }
        }

        await onUserLogin(userPhoneNumber, password);
        setState(() {
          isLoadingProgress = false;
          progressMessage = Constants.GETTING_DATA;
        });
      }

      // if (!isForSaveAndExit) {
      //   setState(() {
      //     tabIndex = _tabController!.index + 1;
      //     isCompleteStepOne = true;
      //     _tabController!.animateTo(tabIndex,
      //         duration: Duration(milliseconds: 500), curve: Curves.easeIn);
      //   });
      // }

      if (isForSaveAndExit) {
        final action = await Dialogs.yesCancelDialog(
            context,
            Language().getString(Constants.SUCCESS, selectedLang),
            Language()
                .getString(Constants.ORG_CREATED_SUCCESSFULLY, selectedLang),
            Language().getString(Constants.OKAY_STR, selectedLang),
            "",
            false);
        if (action == DialogAction.yes) {
          if (AppController.instance.buList != null &&
              AppController.instance.buList!.length == 0) {
            Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (context) => HomePageView()),
                (Route<dynamic> route) => false);
          } else {
            Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(
                  builder: (context) => AllBUListView(
                    title: Constants.BUSINESS_UNIT_LIST_STRING,
                  ),
                ),
                (Route<dynamic> route) => false);
          }
        }
      } else {
        setState(() {
          tabIndex = _tabController!.index + 1;
          isCompleteStepOne = true;
          _tabController!.animateTo(tabIndex,
              duration: Duration(milliseconds: 500), curve: Curves.easeIn);
        });
        AppController.instance.saveCurrentOrgId = data;
        AppController.instance.saveCurrentOrgName =
            _orgFieldsData!.businessName;
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  onUserLogin(String? mobileNumber, String? userPassword) async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = "Getting Roles...";
    });
    PrivilegeHandler privilegeHandler = PrivilegeHandler();

    String body =
        json.encode({"contact": mobileNumber, "password": userPassword});

    /* Service call for login */
    var response = await
        // _service.login(body)
        _userService.login_grpc(body).catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var responseBody = json.decode(_grpcResponse.message!);
      // localStorage(responseBody);
      AppController.instance.setAuthorizationKey = responseBody['auth'];
      try {
        var roles = responseBody["bu"][0]["roles"];
        var role = roles[0];
        AppController.instance.setLoginUserRoleId = role['role_id'];
        AppController.instance.setLoginUserRole = role['name'];
        Map<String, dynamic>? permissions = role['permissions'];
        privilegeHandler.setPermissions(permissions);
      } catch (e) {
        privilegeHandler.resetPermissions();
      }
    } else {
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }
}
