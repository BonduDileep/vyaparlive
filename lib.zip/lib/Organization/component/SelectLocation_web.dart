import 'dart:async';
import 'dart:html';
import 'dart:js' as js;
import 'dart:math';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:google_places_flutter/DioErrorHandler.dart';
import 'package:google_places_flutter/model/prediction.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/model/CountryDAO.dart';
import 'package:vyaparlive/model/StatesDAO.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:toast/toast.dart';
import '../../components/AppUtills.dart';
import '../../components/Constants.dart';
import '../../components/Dialog.dart';
import '../../components/NetworkStatus.dart';
import '../../components/StyleView.dart';
import '../../components/common_methods.dart';
import '../../config/Language.dart';
import '../../model/UserModel.dart';
import '../../model/bu_model/LocationsModel.dart';
import '../../model/map_model/MapAutoSuggestResponse.dart';
import '../../service/api_service/OrganizationApiService.dart';
import '../../service/api_service/lookup_api_service/CountryApiService.dart';
import '../../service/api_service/UserApiService.dart';
import '../../theme/app_theme.dart';
import '../../utills/AppBarName.dart';
import '../../utills/CommonButtonsView.dart';
import '../../utills/SharePref.dart';
import 'PlaceDetails.dart';

class SelectLocation extends StatefulWidget {
  final bool isLocationUpdate;
  final Locations? locationData;
  final String? locationType;
  final bool? isFromLocationTab;
  final String? buId;
  const SelectLocation(
      {super.key,
      required this.isLocationUpdate,
      required this.locationData,
      required this.locationType,
      required this.isFromLocationTab,
      required this.buId});

  @override
  State<SelectLocation> createState() => _SelectLocationState();
}

class _SelectLocationState extends State<SelectLocation> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  // final String PLACES_API_KEY = "AIzaSyBo6qW72rIkCC7J6OOGBpUk_HxnHCNbSSE";
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  SharedPreferences? sharedPreferences;
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  CountryDAO? countryDropdown;
  StatesDAO? stateDropdown;
  List<CountryDAO> countryList = [];
  List<StatesDAO> statesList = [];
  List<String> citiesList = [];
  String? citiDropdown;
  TextEditingController locationNameController = new TextEditingController();
  TextEditingController plotNoController = new TextEditingController();
  TextEditingController houseNoController = new TextEditingController();
  TextEditingController buildingNoController = new TextEditingController();
  TextEditingController streetNameController = new TextEditingController();
  TextEditingController localityController = new TextEditingController();
  TextEditingController landmarkController = new TextEditingController();
  TextEditingController postalCodeController = new TextEditingController();
  TextEditingController userPhoneNoController = new TextEditingController();
  TextEditingController userNameController = new TextEditingController();

  TextEditingController addressController = new TextEditingController();

  UserModel? userDropdown;
  List<UserModel> usersList = [];
  List<SuggestedLocations> _elocation = [];
  List<Prediction> _elocation_geo = [];
  Locations? locationData;
  late ThemeData theme;
  Timer? timer;
  SuggestedLocations? selectedLocationData;
  TextEditingController searchLocation = new TextEditingController();
  // MapMyIndia? mapMyIndia;
  dynamic mapAuthInfo;
  Map<String, dynamic>? eLocData;
  String? userName;
  String? userPhoneNumber;
  String? userId;

  late var _dio;

  double latitude = 0;
  double longitude = 0;
  String helperText = "Location Name";

  @override
  void initState() {
    super.initState();
    _dio = Dio();
    initLoginUserData();
    theme = AppTheme.vyaparTheme;
    loadDropdownValues();
    bindLocationData();
    _focusNode.addListener(_handleFocusChange);
    // getToken();
  }

  void _handleFocusChange() {
    setState(() {
      if (_focusNode.hasFocus) {
        helperText = "Location name";
      } else {
        helperText =
            "Location Name (e.g. Main ofiice, Godown, Warehouse/Storage Area)";
      }
    });
  }

  void initLoginUserData() {
    SharePref().getUserId().then((onValue) {
      setState(() => userId = onValue);
    });
    SharePref()
        .getUserName()
        .then((onValue) => setState(() => userName = onValue));
    SharePref()
        .getPhoneNumber()
        .then((onValue) => setState(() => userPhoneNumber = onValue));
  }

  void bindLocationData() {
    if (widget.isLocationUpdate) {
      Locations locationData = widget.locationData!;
      locationNameController.text = locationData.locationName!;
      buildingNoController.text = locationData.addressDetails!.buildingNo!;
      streetNameController.text =
          locationData.addressDetails!.buildingstreetname!;
      localityController.text =
          locationData.addressDetails!.colonysectorArealocality!;
      postalCodeController.text = locationData.addressDetails!.postcode!;
      plotNoController.text = locationData.addressDetails!.plotNo!;
      houseNoController.text =
          locationData.addressDetails!.buildinghousenumber!;
      postalCodeController.text = locationData.addressDetails!.postcode!;
      String address = "";
      if (locationData.addressDetails!.plotNo!.isNotEmpty) {
        address = locationData.addressDetails!.plotNo! + " ,";
      }
      if (locationData.addressDetails!.buildingNo!.isNotEmpty) {
        address = locationData.addressDetails!.buildingNo! + " ,";
      }
      if (locationData.addressDetails!.buildingstreetname!.isNotEmpty) {
        address += locationData.addressDetails!.buildingstreetname! + " ,";
      }

      if (locationData.addressDetails!.colonysectorArealocality!.isNotEmpty) {
        address +=
            locationData.addressDetails!.colonysectorArealocality! + " ,";
      }

      print("Address: $address");

      if (address.isNotEmpty) {
        address = address.substring(0, address.lastIndexOf(","));
      }

      addressController.text = address;
    }
  }

  final FocusNode _focusNode = FocusNode();

  Widget autoSuggestSearch() {
    return Padding(
      padding: const EdgeInsets.only(top: 10.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
              height: 50,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5.0),
                  color: Colors.white),
              margin: EdgeInsets.symmetric(vertical: 3.0),
              child: new TextFormField(
                style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                controller: locationNameController,
                textInputAction: TextInputAction.done,
                focusNode: _focusNode,
                decoration: StyleView.getInputDecoration(
                    helper: helperText,
                    hintTex:
                        "Location Name (e.g. Main ofiice, Godown, Warehouse/Storage Area)"),
              )),
          TextButton.icon(
              icon: Icon(Icons.my_location_rounded, size: 18),
              onPressed: () => {
                    CommonMethods.hideKeyboard(context),
                    _elocation.clear(),
                    _elocation_geo.clear(),
                    searchLocationFromMap()
                    // searchLocationFromMap_geocode()
                  },
              label: Text(
                Language().getString(
                    Constants.SEARCH_LOCATION_FROM_DIRECTORY, selectedLang),
                style: TextStyle(
                    decoration: TextDecoration.underline,
                    color: Colors.blue,
                    fontSize: 15,
                    fontWeight: StyleView.fontSemiBold),
              )),
        ],
      ),
    );
  }

  // searchLocationFromMap_geocode() {
  //   return showDialog(
  //       barrierColor: Colors.black54,
  //       context: context,
  //       builder: (context) =>
  //           StatefulBuilder(builder: (context, StateSetter setState) {
  //             return Container(
  //               margin: EdgeInsets.symmetric(
  //                   vertical: MediaQuery.of(context).size.height * 0.05,
  //                   horizontal: MediaQuery.of(context).size.width * 0.05),
  //               decoration: BoxDecoration(
  //                   borderRadius: BorderRadius.circular(5.0),
  //                   color: Colors.white),
  //               child: Padding(
  //                 padding: const EdgeInsets.all(8.0),
  //                 child: Scaffold(
  //                   backgroundColor: Colors.transparent,
  //                   body: Padding(
  //                     padding:
  //                         const EdgeInsets.only(top: 10.0, left: 12, right: 12),
  //                     child: Column(
  //                       children: [
  //                         Container(
  //                             height: 50,
  //                             margin: EdgeInsets.symmetric(vertical: 3.0),
  //                             child: Row(
  //                               children: [
  //                                 Expanded(
  //                                   child: Container(
  //                                     child: GooglePlaceAutoCompleteTextField(
  //                                       textEditingController: searchLocation,
  //                                       googleAPIKey: PLACES_API_KEY,
  //                                       inputDecoration: InputDecoration(),
  //                                       debounceTime: 800, // default 600 ms,
  //                                       countries: [
  //                                         "in"
  //                                       ], // optional by default null is set
  //                                       isLatLngRequired:
  //                                           true, // if you required coordinates from place detail
  //                                       getPlaceDetailWithLatLng:
  //                                           (Prediction prediction) {
  //                                         // this method will return latlng with place detail
  //                                         print(
  //                                             "placeDetails ${prediction.toJson()}");
  //                                       }, // this callback is called when isLatLngRequired is true
  //                                       itemClick: (Prediction prediction) {
  //                                         CommonMethods.hideKeyboard(context);
  //                                         setState(() {
  //                                           stateDropdown = null;
  //                                           citiDropdown = null;
  //                                           citiesList.clear();
  //                                           buildingNoController.clear();
  //                                           plotNoController.clear();
  //                                           postalCodeController.clear();
  //                                           houseNoController.clear();
  //                                           localityController.clear();
  //                                           landmarkController.clear();
  //                                           streetNameController.clear();
  //                                         });

  //                                         getPlaceDetailsFromPlaceId(
  //                                             prediction);
  //                                         searchLocation.text =
  //                                             prediction.description!;
  //                                         searchLocation.selection =
  //                                             TextSelection.fromPosition(
  //                                                 TextPosition(
  //                                                     offset: prediction
  //                                                         .description!
  //                                                         .length));
  //                                       },
  //                                       // if we want to make custom list item builder
  //                                       itemBuilder: (context, index,
  //                                           Prediction prediction) {
  //                                         return Container(
  //                                           padding: EdgeInsets.all(10),
  //                                           child: Row(
  //                                             children: [
  //                                               Icon(Icons.location_on),
  //                                               SizedBox(
  //                                                 width: 7,
  //                                               ),
  //                                               Expanded(
  //                                                   child: Text(
  //                                                       "${prediction.description ?? ""}"))
  //                                             ],
  //                                           ),
  //                                         );
  //                                       },
  //                                       // if you want to add seperator between list items
  //                                       seperatedBuilder: Divider(),
  //                                       // want to show close icon
  //                                       isCrossBtnShown: true,
  //                                       // optional container padding
  //                                       containerHorizontalPadding: 10,
  //                                       // place type
  //                                       // placeType: PlaceType.geocode,
  //                                     ),
  //                                   ),
  //                                 ),
  //                               ],
  //                             )),
  //                       ],
  //                     ),
  //                   ),
  //                 ),
  //               ),
  //             );
  //           }));
  // }

  searchLocationFromMap() {
    return showDialog(
        barrierColor: Colors.black54,
        context: context,
        builder: (context) =>
            StatefulBuilder(builder: (context, StateSetter setState) {
              return Container(
                margin: EdgeInsets.symmetric(
                    vertical: MediaQuery.of(context).size.height * 0.05,
                    horizontal: MediaQuery.of(context).size.width * 0.05),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5.0),
                    color: Colors.white),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Scaffold(
                    backgroundColor: Colors.transparent,
                    body: Padding(
                      padding:
                          const EdgeInsets.only(top: 10.0, left: 12, right: 12),
                      child: Column(
                        children: [
                          Container(
                              height: 50,
                              decoration: AppUtills.boxDecoration(
                                  customBorderColor: Colors.black),
                              margin: EdgeInsets.symmetric(vertical: 3.0),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: Container(
                                      child: new TextFormField(
                                          style: TextStyle(
                                              fontFamily: StyleView.FONT_TITLE),
                                          controller: searchLocation,
                                          textInputAction: TextInputAction.done,
                                          decoration: InputDecoration(
                                              contentPadding:
                                                  EdgeInsets.only(left: 8),
                                              border: InputBorder.none,
                                              hintText: Language().getString(
                                                  Constants.SEARCH_PLACES,
                                                  selectedLang),
                                              hintStyle: TextStyle(
                                                  color: Colors.grey,
                                                  fontWeight:
                                                      StyleView.fontMedium)),
                                          onChanged: (text) {
                                            if (text.trim().isEmpty) {
                                              _elocation.clear();
                                              _elocation_geo.clear();
                                            }

                                            setState(() {});
                                            getLocation(text.trim(), setState);
                                            // callAutoSuggest(
                                            //     text.trim(), setState);
                                          }),
                                    ),
                                  ),
                                  IconButton(
                                      onPressed: () => {
                                            setState(() {
                                              _elocation.clear();
                                              _elocation_geo.clear();
                                            }),
                                            if (searchLocation.text.isNotEmpty)
                                              {searchLocation.clear()}
                                            else
                                              {
                                                Navigator.of(context).pop(),
                                              }
                                          },
                                      icon: Icon(
                                        Icons.close,
                                        color: Colors.red,
                                      ))
                                ],
                              )),
                          renderSuggestions()
                        ],
                      ),
                    ),
                  ),
                ),
              );
            }));
  }

  // renderSuggestions_mappls() {
  //   return Container(
  //     child: _elocation.length > 0
  //         ? Expanded(
  //             child: Container(
  //                 margin: EdgeInsets.only(top: 16),
  //                 decoration: const BoxDecoration(color: Colors.white),
  //                 child: ListView.builder(
  //                     itemCount: _elocation.length,
  //                     itemBuilder: (context, index) {
  //                       return ListTile(
  //                         contentPadding: const EdgeInsets.all(12),
  //                         focusColor: Colors.white,
  //                         title: Text(_elocation[index].placeName ?? ''),
  //                         subtitle: Text(_elocation[index].placeAddress ?? '',
  //                             maxLines: 2),
  //                         onTap: () {
  //                           CommonMethods.hideKeyboard(context);
  //                           setState(() {
  //                             stateDropdown = null;
  //                             citiDropdown = null;
  //                             citiesList.clear();
  //                             buildingNoController.clear();
  //                             plotNoController.clear();
  //                             postalCodeController.clear();
  //                             houseNoController.clear();
  //                             localityController.clear();
  //                             landmarkController.clear();
  //                             streetNameController.clear();
  //                           });
  //                           updateSelectedLocation(_elocation[index]);
  //                           // getLocation(_elocation[index].placeAddress!);
  //                         },
  //                       );
  //                     })),
  //           )
  //         : Container(),
  //   );
  // }

  renderSuggestions() {
    return Container(
      child: _elocation_geo.length > 0
          ? Expanded(
              child: Container(
                  margin: EdgeInsets.only(top: 16),
                  decoration: const BoxDecoration(color: Colors.white),
                  child: ListView.builder(
                      itemCount: _elocation_geo.length,
                      itemBuilder: (context, index) {
                        return ListTile(
                          contentPadding: const EdgeInsets.all(12),
                          focusColor: Colors.white,
                          title: Text(_elocation_geo[index].description ?? ''),
                          subtitle: Text(
                              _elocation_geo[index].description ?? '',
                              maxLines: 2),
                          onTap: () {
                            CommonMethods.hideKeyboard(context);
                            setState(() {
                              stateDropdown = null;
                              citiDropdown = null;
                              citiesList.clear();
                              buildingNoController.clear();
                              plotNoController.clear();
                              postalCodeController.clear();
                              houseNoController.clear();
                              localityController.clear();
                              landmarkController.clear();
                              streetNameController.clear();
                            });
                            // updateSelectedLocation(_elocation[index]);

                            getPlaceDetailsFromPlaceId(_elocation_geo[index]);
                          },
                        );
                      })),
            )
          : Container(),
    );
  }

  Future<void> updateSelectedLocation(SuggestedLocations elocation) async {
    print(elocation.placeAddress);
    print(elocation.placeName);

    List<String> splitLocation = elocation.placeAddress!.split(",");

    // if (splitLocation.length >= 8) {
    //   locationIndexing(
    //       splitLocation: splitLocation,
    //       postalcodeIndex: splitLocation.length - 1,
    //       stateIndex: splitLocation.length - 2,
    //       cityIndex: splitLocation.length - 3,
    //       localityIndex: splitLocation.length - 4,
    //       streetIndex: splitLocation.length - 5,
    //       houseIndex: splitLocation.length - 6,
    //       plotIndex: -1,
    //       placeName: elocation.placeName!);
    //   plotNoController.text =
    //       splitLocation.sublist(0, splitLocation.length - 6).join(',');
    // } else if (splitLocation.length == 7) {
    //   locationIndexing(
    //       splitLocation: splitLocation,
    //       postalcodeIndex: splitLocation.length - 1,
    //       stateIndex: splitLocation.length - 2,
    //       cityIndex: splitLocation.length - 3,
    //       localityIndex: splitLocation.length - 4,
    //       streetIndex: splitLocation.length - 5,
    //       houseIndex: splitLocation.length - 6,
    //       plotIndex: splitLocation.length - splitLocation.length,
    //       placeName: elocation.placeName!);
    // } else if (splitLocation.length == 6) {
    //   locationIndexing(
    //       splitLocation: splitLocation,
    //       postalcodeIndex: splitLocation.length - 1,
    //       stateIndex: splitLocation.length - 2,
    //       cityIndex: splitLocation.length - 3,
    //       localityIndex: splitLocation.length - 4,
    //       streetIndex: splitLocation.length - 5,
    //       houseIndex: splitLocation.length - 6,
    //       plotIndex: splitLocation.length - splitLocation.length,
    //       placeName: elocation.placeName!);
    //   // plotNoController.text = elocation.placeName!.trim();
    // } else if (splitLocation.length == 5) {
    //   locationIndexing(
    //       splitLocation: splitLocation,
    //       postalcodeIndex: splitLocation.length - 1,
    //       stateIndex: splitLocation.length - 2,
    //       cityIndex: splitLocation.length - 3,
    //       localityIndex: splitLocation.length - 4,
    //       streetIndex: splitLocation.length - splitLocation.length,
    //       houseIndex: -1,
    //       plotIndex: -1,
    //       placeName: elocation.placeName!);
    // } else if (splitLocation.length == 4) {
    //   locationIndexing(
    //       splitLocation: splitLocation,
    //       postalcodeIndex: splitLocation.length - 1,
    //       stateIndex: splitLocation.length - 2,
    //       cityIndex: splitLocation.length - 3,
    //       localityIndex: splitLocation.length - splitLocation.length,
    //       streetIndex: -1,
    //       houseIndex: -1,
    //       plotIndex: -1,
    //       placeName: elocation.placeName!);
    // } else if (splitLocation.length == 3) {
    //   locationIndexing(
    //       splitLocation: splitLocation,
    //       postalcodeIndex: splitLocation.length - 1,
    //       stateIndex: splitLocation.length - 2,
    //       cityIndex: splitLocation.length - 3,
    //       localityIndex: -1,
    //       streetIndex: -1,
    //       houseIndex: -1,
    //       plotIndex: -1,
    //       placeName: elocation.placeName!);
    // }

    searchLocation.clear();
    Navigator.of(context).pop();

    if (splitLocation.length == 2) {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          Language().getString(Constants.PINCODE_MANDATORY, selectedLang),
          Language().getString(Constants.OK_STRING, selectedLang),
          "",
          false);
    }
  }

  Future<void> updateSelectedLocation_geo(
      PlaceDetails elocation, Prediction prediction) async {
    // print("${elocation.result!.toJson()}");
    // print("Prediction ${prediction.toJson()}");
    List<AddressComponents>? addressComponents =
        elocation.result!.addressComponents;
    String postalCode = "";
    String locality = "";
    String state = "";
    String city = "";
    String street = "";
    String house = "";
    String plot = "";
    String placename = "";
    for (var i = 0; i < addressComponents!.length; i++) {
      List<String>? types = addressComponents[i].types!;
      for (var j = 0; j < types.length; j++) {
        if (types[j].toString() == "postal_code") {
          postalCode = addressComponents[i].longName!;
        }
        if (types[j].toString() == "locality") {
          locality = addressComponents[i].longName!;
        }
        if (types[j].toString() == "administrative_area_level_1") {
          state = addressComponents[i].longName!;
        }
        if (city.isEmpty && types[j].toString() == "locality") {
          city = addressComponents[i].longName!;
        }
        // if (types[j].toString() == "route") {
        //   street = addressComponents[i].longName!;
        // }
        // if(types[j].toString() == "house"){
        //   house = addressComponents[i].longName!;
        // }
        // if(types[j].toString() == "plot"){
        //   plot = addressComponents[i].longName!;
        // }
        if (types[j].toString() == "premise") {
          placename = addressComponents[i].longName!;
        }
      }
    }

    addressController.text = prediction.structuredFormatting!.mainText!;

    selectedLocationDetails(
        postalcode: postalCode,
        state: state,
        city: city,
        locality: locality,
        street: street,
        house: house,
        plot: plot,
        placeName: placename);

    searchLocation.clear();
    Navigator.of(context).pop();
  }

  // Future<void> callAutoSuggest(String text, StateSetter setState) async {
  //   timer?.cancel();
  //   timer = Timer(
  //     const Duration(milliseconds: 500),
  //     () async {
  //       try {
  //         await auto(_authInfo!.accessToken, text);
  //       } catch (e) {
  //         print(e);
  //       }
  //     },
  //   );
  // }

  getPlaceDetailsFromPlaceId(Prediction prediction) async {
    //String key = GlobalConfiguration().getString('google_maps_key');
    // print("get latlang ${prediction.placeId}");

    var url =
        "${Constants.NEW_BASE_URL}lookup/places/placeDetails?placeid=${prediction.placeId}";
    // "https://maps.googleapis.com/maps/api/place/details/json?placeid=${prediction.placeId}&key=${PLACES_API_KEY}";
    try {
      Response response = await _dio.get(
        url,
      );

      Map data = response.data;
      PlaceDetails placeDetails = PlaceDetails.fromJson(data["data"]);

      prediction.lat = placeDetails.result!.geometry!.location!.lat.toString();
      prediction.lng = placeDetails.result!.geometry!.location!.lng.toString();

      // print(" lat ${prediction.lat} lang: ${prediction.lng}");

      latitude = double.parse(prediction.lat!);
      longitude = double.parse(prediction.lng!);

      updateSelectedLocation_geo(placeDetails, prediction);
    } catch (e) {
      var errorHandler = ErrorHandler.internal().handleError(e);
    }
  }

  getLocation(String text, StateSetter setState) async {
    String apiURL = "${Constants.NEW_BASE_URL}lookup/places?input=${text}";
    try {
      Response response = await _dio.get(apiURL);
      Map map = response.data;
      // print("data of geocode: ${map.toString()}");

      PlacesAutocompleteResponse subscriptionResponse =
          PlacesAutocompleteResponse.fromJson(map["data"]);

      if (subscriptionResponse.predictions != null &&
          subscriptionResponse.predictions!.length > 0) {
        setState(() {
          _elocation_geo = subscriptionResponse.predictions!;
        });
        // getPlaceDetailsFromPlaceId(subscriptionResponse.predictions![0]);
      }
      if (map.containsKey("error_message")) {
        throw response.data;
      }
    } catch (e) {
      var errorHandler = ErrorHandler.internal().handleError(e);
    }
  }

  Future<void> getLocationByAddress(String text) async {
    String apiURL =
        "${Constants.NEW_BASE_URL}lookup/places/getLocationByAddress?address=$text";
    try {
      Response response = await _dio.get(apiURL);
      Map map = response.data;

      var data = map["data"];
      var results = data["results"];

      if (results != null && results.length > 0) {
        var object = results[0];
        if (object != null && object.containsKey("geometry")) {
          var geometry = object["geometry"];
          var location = geometry["location"];

          latitude = location["lat"];
          longitude = location["lng"];
          prepareLocationObject();
        } else {
          showLocationNotFoundAlert();
        }
      } else {
        showLocationNotFoundAlert();
      }
    } catch (e) {
      // var errorHandler = ErrorHandler.internal().handleError(e);
      showLocationNotFoundAlert();
    }
  }

  void showLocationNotFoundAlert() async {
    final action = await Dialogs.yesCancelDialog(
        context,
        Language().getString(Constants.ALERT, selectedLang),
        Language().getString(
            "This address is not found in google maps. Do you want to search in directory?",
            selectedLang),
        Language().getString(Constants.YES_STRING, selectedLang),
        "",
        false);

    if (action == DialogAction.yes) {
      CommonMethods.hideKeyboard(context);
      _elocation.clear();
      _elocation_geo.clear();
      searchLocationFromMap();
    }
  }

  Map<String, dynamic> prepareGpsMapData() {
    if (eLocData != null) {
      Map<String, dynamic> data = {
        "lang": eLocData!['longitude'],
        "lat": eLocData!['latitude']
      };
      return data;
    }

    Map<String, dynamic> data = {"lat": latitude, "lang": longitude};
    return data;
  }

  Future prepareLocationObject() async {
    Map<String, dynamic> mapData = {
      "location_id": "",
      "location_type": widget.locationType,
      "location_name": locationNameController.text,
      "contact_person": userDropdown != null
          ? userDropdown!.name
          : userNameController.text.trim(),
      "contact_number": userDropdown != null
          ? userDropdown!.contact
          : userPhoneNoController.text.trim(),
      "address": {
        "buildinghousenumber": "", //houseNoController.text,
        "building_no": "", //buildingNoController.text,
        "buildingstreetname":
            addressController.text, //streetNameController.text,
        "colonysector_arealocality": "", //localityController.text,
        "landmark": landmarkController.text,
        "country": countryDropdown!.name,
        "state": stateDropdown!.state,
        "plot_no": "", //plotNoController.text,
        "district": "",
        "villagetowncity": citiDropdown ?? "",
        "taluka": "",
        "postcode": postalCodeController.text,
        "gps": prepareGpsMapData()
      }
    };
    // print("mapData $mapData");
    // return;
    if (widget.isFromLocationTab!) {
      setState(() {
        isLoadingProgress = true;
      });
      mapData["id"] = widget.buId;
      if (widget.isLocationUpdate) {
        mapData["location_id"] = widget.locationData?.locationId!;
        final bool isLocationUpdate = await OrganizationApiService.instance
            .updateBuLocation(
                context: context,
                mapData: mapData,
                langError: Language().getString(Constants.ERROR, selectedLang),
                langOk: Language().getString(Constants.OKAY_STR, selectedLang));
        setState(() {
          isLoadingProgress = false;
        });
        if (isLocationUpdate) {
          final action = await Dialogs.yesCancelDialog(
              context,
              Language().getString(Constants.SUCCESS, selectedLang),
              Language().getString(Constants.LOCATION_UPDATED, selectedLang),
              Language().getString(Constants.OKAY_STR, selectedLang),
              "",
              false);
          if (action == DialogAction.yes) {
            Navigator.of(context).pop();
          }
        } else {
          Dialogs.yesCancelDialog(
              context,
              Language().getString(Constants.ERROR, selectedLang),
              Language()
                  .getString(Constants.FAILED_TO_UPDATE_LOCATION, selectedLang),
              Language().getString(Constants.OKAY_STR, selectedLang),
              "",
              false);
        }
      } else {
        final bool isLocationCreate = await OrganizationApiService.instance
            .createBuLocation(
                context: context,
                mapData: mapData,
                langError: Language().getString(Constants.ERROR, selectedLang),
                langOk: Language().getString(Constants.OKAY_STR, selectedLang));
        setState(() {
          isLoadingProgress = false;
        });
        if (isLocationCreate) {
          final action = await Dialogs.yesCancelDialog(
              context,
              Language().getString(Constants.SUCCESS, selectedLang),
              Language().getString(Constants.LOCATION_CREATED, selectedLang),
              Language().getString(Constants.OKAY_STR, selectedLang),
              "",
              false);
          if (action == DialogAction.yes) {
            Navigator.of(context).pop();
          }
        } else {
          Dialogs.yesCancelDialog(
              context,
              Language().getString(Constants.ERROR, selectedLang),
              Language()
                  .getString(Constants.FAILED_TO_CREATE_LOCATION, selectedLang),
              Language().getString(Constants.OKAY_STR, selectedLang),
              "",
              false);
        }
      }

      return;
    }
    locationData = new Locations.fromJson(mapData);
    Navigator.of(context).pop(locationData);
  }

  Widget buildTextFormFieldsDialog(String? _labelText,
      TextEditingController controller, bool isNumberKeyboard) {
    return Container(
        height: 50,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(5.0), color: Colors.white),
        margin: EdgeInsets.symmetric(vertical: 3.0),
        child: new TextFormField(
            keyboardType: isNumberKeyboard
                ? TextInputType.numberWithOptions(signed: true)
                : TextInputType.text,
            style: TextStyle(fontFamily: StyleView.FONT_TITLE),
            controller: controller,
            textInputAction: TextInputAction.done,
            inputFormatters: this.inputFormatters(_labelText),
            decoration: StyleView.getInputDecoration(helper: _labelText),
            onChanged: (text) => {}));
  }

  Widget buildAddressTextFormFieldsDialog(String? _labelText,
      TextEditingController controller, bool isNumberKeyboard) {
    return Container(
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(5.0), color: Colors.white),
        margin: EdgeInsets.symmetric(vertical: 3.0),
        child: new TextFormField(
            maxLines: null,
            keyboardType: isNumberKeyboard
                ? TextInputType.numberWithOptions(signed: true)
                : TextInputType.text,
            style: TextStyle(fontFamily: StyleView.FONT_TITLE),
            controller: controller,
            textInputAction: TextInputAction.done,
            inputFormatters: this.inputFormatters(_labelText),
            decoration: StyleView.getInputDecoration(helper: _labelText),
            onChanged: (text) => {}));
  }

  inputFormatters(String? validationText) {
    List<TextInputFormatter> formatter = [];
    if (validationText ==
        Language().getString(Constants.POST_CODE_STRING, selectedLang)) {
      formatter = [
        new LengthLimitingTextInputFormatter(6),
        FilteringTextInputFormatter.digitsOnly
      ];
    } else if (validationText ==
        Language().getString(Constants.LOCATION_PHONE_NUMBER, selectedLang)) {
      formatter = [
        new LengthLimitingTextInputFormatter(14),
        FilteringTextInputFormatter.allow(RegExp("[0-9 +]"))
      ];
    } else {
      formatter = [];
    }
    return formatter;
  }

  Widget buildTextField(String _text) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 5.0),
      child: Row(
        children: <Widget>[
          Text(
            _text,
            style: TextStyle(
                fontSize: StyleView.FONT_SIZE_15,
                fontFamily: StyleView.FONT_TITLE,
                color: Colors.black,
                fontWeight: StyleView.fontSemiBold),
          )
        ],
      ),
    );
  }

  // @override
  // void setState(VoidCallback fn) {
  //   if (mounted) {
  //     super.setState(fn);
  //   }
  // }

  @override
  Widget build(BuildContext context) {
    ToastContext().init(context);
    return AppBackgroundView(
        body: Stack(
      children: [
        SafeArea(
          child: Scaffold(
              key: _scaffoldkey,
              appBar: AppBar(
                iconTheme: IconThemeData(color: theme.colorScheme.primary),
                centerTitle: true,
                title: AppbarName(
                    title: Language().getString(
                        widget.isLocationUpdate
                            ? Constants.UPDATE_LOCATION
                            : Constants.SELECT_LOCATION,
                        selectedLang),
                    buName: AppController.instance.getBuName),
                backgroundColor: Colors.transparent,
                elevation: 0,
              ),
              backgroundColor: Colors.transparent,
              bottomNavigationBar: Container(
                margin: EdgeInsets.symmetric(horizontal: 10),
                padding: EdgeInsets.only(bottom: 10),
                child: CommonButtonsView(
                  context: context,
                  b1Text:
                      Language().getString(Constants.STR_CANCEL, selectedLang),
                  b2Text: Language().getString(Constants.STR_SAVE, selectedLang),
                  onb1Action: () {
                    Navigator.of(context).pop();
                  },
                  onb2Action: () async {
                    String? validationText = '';
                    if (locationNameController.text.isEmpty) {
                      validationText = Language().getString(
                          Constants.PLEASE_ENTER_LOCATION_NAME, selectedLang);
                    } else if (countryDropdown == null) {
                      validationText = Language().getString(
                          Constants.PLEASE_SELECT_COUNTRY, selectedLang);
                    } else if (stateDropdown == null) {
                      validationText = Language()
                          .getString(Constants.PLEASE_SELECT_STATE, selectedLang);
                    } else if (citiDropdown == null) {
                      validationText = Language()
                          .getString(Constants.PLEASE_SELECT_CITY, selectedLang);
                    }
          
                    if (validationText!.isEmpty) {
                      String address = "";
                      if (streetNameController.text.isNotEmpty) {
                        address = "${streetNameController.text},";
                      }
                      if (localityController.text.isNotEmpty) {
                        address = address + "${localityController.text},";
                      }
                      if (citiDropdown != null) {
                        address = address + "$citiDropdown,";
                      }
                      if (stateDropdown != null) {
                        address = address + "${stateDropdown!.state},";
                      }
                      // await getElocId(address);
                      if (latitude > 0 && longitude > 0) {
                        prepareLocationObject();
                      } else {
                        getLocationByAddress(address);
                      }
                    } else {
                      Dialogs.yesCancelDialog(
                          context,
                          Language().getString(Constants.ERROR, selectedLang),
                          Language().getString(validationText, selectedLang),
                          Language().getString(Constants.OKAY_STR, selectedLang),
                          "",
                          false);
                    }
                  },
                ),
              ),
              body: Stack(
                children: [
                  Container(
                    padding: EdgeInsets.only(top: 10.0, left: 12, right: 12),
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          // (kIsWeb)
                          //     ? FlutterGooglePlacesWeb(
                          //         apiKey: PLACES_API_KEY,
                          //         proxyURL: null,
                          //         //'https://cors-anywhere.herokuapp.com/',
                          //         components: 'country:in',
                          //         required: true,
                          //       )
                          //     :
                          autoSuggestSearch(),
                          // Container(
                          //   child: Row(
                          //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          //     children: <Widget>[
                          //       buildTextField(Language()
                          //           .getString(Constants.ADDRESS, selectedLang)),
                          //     ],
                          //   ),
                          // ),
                          SizedBox(height: 5.0),
                          buildAddressTextFormFieldsDialog(
                              Language()
                                  .getString(Constants.ADDRESS, selectedLang),
                              addressController,
                              false),
                          // buildTextFormFieldsDialog(
                          //     Language()
                          //         .getString(Constants.PLOT_NO, selectedLang),
                          //     plotNoController,
                          //     false),
                          // SizedBox(height: 5.0),
                          // buildTextFormFieldsDialog(
                          //     Language().getString(
                          //         Constants.HOUSE_BUILDING, selectedLang),
                          //     houseNoController,
                          //     false),
                          // SizedBox(height: 5.0),
                          // buildTextFormFieldsDialog(
                          //     Language()
                          //         .getString(Constants.BULIDING, selectedLang),
                          //     buildingNoController,
                          //     false),
                          // SizedBox(height: 5.0),
                          // buildTextFormFieldsDialog(
                          //     Language().getString(
                          //         Constants.BUILDING_STREET_NAME_STRING,
                          //         selectedLang),
                          //     streetNameController,
                          //     false),
                          // SizedBox(height: 5.0),
                          // buildTextFormFieldsDialog(
                          //     Language().getString(
                          //         Constants.COLONY_SELECTOR_AREA_LOCALITY_STRING,
                          //         selectedLang),
                          //     localityController,
                          //     false),
                          SizedBox(height: 5.0),
                          buildTextFormFieldsDialog(
                              Language().getString(
                                  Constants.LAND_MARK_STRING, selectedLang),
                              landmarkController,
                              false),
                          SizedBox(height: 5.0),
                          Container(
                              // color: Colors.white70,
                              padding: EdgeInsets.only(
                                left: 5,
                              ),
                              margin: EdgeInsets.symmetric(vertical: 3.0),
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  border: Border.all(color: Colors.grey),
                                  borderRadius: BorderRadius.circular(5.0)),
                              child: DropdownButton<CountryDAO>(
                                  onTap: () {
                                    return CommonMethods.hideKeyboard(context);
                                  },
                                  value: countryDropdown,
                                  isExpanded: true,
                                  hint: Text(
                                      Language().getString(
                                          Constants.SELECT_COUNTRY, selectedLang),
                                      style: TextStyle(
                                          fontFamily: StyleView.FONT_TITLE)),
                                  underline: SizedBox(),
                                  onChanged: (CountryDAO? data) async {
                                    List<StatesDAO> fetchStockStatesData =
                                        await CountryApiService.instance
                                            .getStates(
                                                countryName:
                                                    countryDropdown!.name!);
                                    setState(() {
                                      countryDropdown = data;
                                      statesList.clear();
                                      stateDropdown = null;
                                      statesList.addAll(fetchStockStatesData);
                                      citiDropdown = null;
                                      citiesList.clear();
                                    });
                                  },
                                  items: countryList.map((CountryDAO model) {
                                    return new DropdownMenuItem<CountryDAO>(
                                      child: new Text(model.name!,
                                          style: TextStyle(
                                              fontFamily: StyleView.FONT_TITLE)),
                                      value: model,
                                    );
                                  }).toList())),
                          SizedBox(height: 5.0),
                          GestureDetector(
                              onTap: () {
                                CommonMethods.hideKeyboard(context);
                                _showStateSearchDialog().then((data) {
                                  if (data != null) {
                                    setState(() {
                                      citiesList.clear();
                                      citiDropdown = null;
                                      stateDropdown = data;
                                      citiesList.addAll(data.cities!);
                                    });
                                  }
                                });
                              },
                              child: Container(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 14),
                                  margin: EdgeInsets.symmetric(vertical: 3.0),
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      border: Border.all(color: Colors.grey),
                                      borderRadius:
                                          BorderRadius.circular(5.0)),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: Text(
                                          stateDropdown != null
                                              ? stateDropdown!.state!
                                              : Language().getString(
                                                  Constants.SELECT_STATE,
                                                  selectedLang),
                                          style: TextStyle(
                                            fontFamily: StyleView.FONT_TITLE,
                                            color: stateDropdown != null
                                                ? Colors.black
                                                : Colors.grey,
                                          ),
                                        ),
                                      ),
                                      Icon(Icons.arrow_drop_down,
                                          color: Colors.grey),
                                    ],
                                  ))),
                          SizedBox(height: 5.0),
                          GestureDetector(
                              onTap: () {
                                CommonMethods.hideKeyboard(context);
                                _showCitySearchDialog().then((data) {
                                  if (data != null) {
                                    setState(() {
                                      citiDropdown = data;
                                    });
                                  }
                                });
                              },
                              child: Container(
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      border: Border.all(color: Colors.grey),
                                      borderRadius:
                                          BorderRadius.circular(5.0)),
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 14),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: Text(
                                          citiDropdown != null
                                              ? citiDropdown!
                                              : Language().getString(
                                                  Constants.SELECT_CITY,
                                                  selectedLang),
                                          style: TextStyle(
                                            fontFamily: StyleView.FONT_TITLE,
                                            color: citiDropdown != null
                                                ? Colors.black
                                                : Colors.grey,
                                          ),
                                        ),
                                      ),
                                      Icon(Icons.arrow_drop_down,
                                          color: Colors.grey),
                                    ],
                                  ))),
                          SizedBox(height: 5.0),
                          buildTextFormFieldsDialog(
                              Language()
                                  .getString(Constants.PIN_CODE, selectedLang),
                              postalCodeController,
                              true),
                          SizedBox(height: 5.0),
                          (usersList.length > 0)
                              ? userDropdownView()
                              : buildTextFormFieldsDialog(
                                  Language().getString(
                                      Constants.USER_STRING, selectedLang),
                                  userNameController,
                                  false),
                          SizedBox(height: 5.0),
                          buildTextFormFieldsDialog(
                              Language().getString(
                                  Constants.LOCATION_PHONE_NUMBER, selectedLang),
                              userPhoneNoController,
                              false),
                        ],
                      ),
                    ),
                  ),
                ],
              )),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    ));
  }

  Widget userDropdownView() {
    return Container(
        padding: EdgeInsets.all(1),
        margin: EdgeInsets.symmetric(vertical: 5.0),
        decoration: BoxDecoration(
            border: Border.all(color: Colors.grey),
            borderRadius: BorderRadius.circular(5.0)),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                            Language().getString(
                                Constants.CONTACT_PERSON, selectedLang),
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: StyleView.FONT_TITLE))),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5, right: 5),
                  child: DropdownButton<UserModel>(
                      onTap: () {
                        return CommonMethods.hideKeyboard(context);
                      },
                      value: userDropdown,
                      isExpanded: true,
                      hint: Text(
                          Language()
                              .getString(Constants.SELECT_USER, selectedLang),
                          style: TextStyle(fontFamily: StyleView.FONT_TITLE)),
                      underline: SizedBox(),
                      onChanged: (UserModel? data) {
                        setState(() {
                          userDropdown = data;
                          userPhoneNoController.text = data!.contact!;
                        });
                      },
                      items: usersList.map((UserModel model) {
                        return new DropdownMenuItem<UserModel>(
                          child: new Text(model.name!,
                              style:
                                  TextStyle(fontFamily: StyleView.FONT_TITLE)),
                          value: model,
                        );
                      }).toList())),
            )
          ],
        ));
  }

  Future<void> _fetchUserDetails() async {
    setState(() => isLoadingProgress = true);
    final fetchedData = await UserApiService.instance.getUsersByBuId(
        context, AppController.instance.getMyBuId!,
        langError: Language().getString(Constants.ERROR, selectedLang),
        langOk: Language().getString(Constants.OKAY_STR, selectedLang));
    setState(() {
      isLoadingProgress = false;
    });
    if (fetchedData.length > 0) {
      setState(() {
        userPhoneNoController.clear();
        userNameController.clear();
        usersList.addAll(fetchedData);
        if (widget.isLocationUpdate) {
          for (var element in fetchedData) {
            String contactNumber = element.contact!;
            if (widget.locationData!.contactNumber == contactNumber) {
              userDropdown = element;
              userPhoneNoController.text = contactNumber;
            }
          }
        }
      });
    } else {
      setState(() {
        userNameController.text = userName!;
        userPhoneNoController.text = userPhoneNumber!;
      });
    }
  }

  Future<StatesDAO?> _showStateSearchDialog() {
    String query = '';
    return showDialog<StatesDAO?>(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            List<StatesDAO> filtered = statesList
                .where((s) => (s.state ?? '')
                    .toLowerCase()
                    .contains(query.toLowerCase()))
                .toList();
            return Dialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Padding(
                    padding: EdgeInsets.fromLTRB(12, 12, 12, 0),
                    child: TextField(
                      autofocus: true,
                      decoration: InputDecoration(
                        hintText: Language().getString(
                            Constants.SELECT_STATE, selectedLang),
                        prefixIcon: Icon(Icons.search, color: Colors.grey),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        contentPadding: EdgeInsets.symmetric(vertical: 10),
                      ),
                      onChanged: (value) {
                        setState(() {
                          query = value;
                        });
                      },
                    ),
                  ),
                  SizedBox(
                    height: 300,
                    child: filtered.isEmpty
                        ? Center(
                            child: Text("No states found",
                                style: TextStyle(color: Colors.grey)))
                        : ListView.builder(
                            itemCount: filtered.length,
                            itemBuilder: (context, index) {
                              return ListTile(
                                title: Text(filtered[index].state!,
                                    style: TextStyle(
                                        fontFamily: StyleView.FONT_TITLE)),
                                onTap: () {
                                  Navigator.of(context).pop(filtered[index]);
                                },
                              );
                            },
                          ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(bottom: 8),
                    child: TextButton(
                      onPressed: () => Navigator.of(context).pop(null),
                      child: Text(
                        Language().getString(Constants.STR_CANCEL, selectedLang),
                        style: TextStyle(color: Colors.red),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Future<String?> _showCitySearchDialog() {
    String query = '';
    return showDialog<String?>(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            List<String> filtered = citiesList
                .where(
                    (c) => c.toLowerCase().contains(query.toLowerCase()))
                .toList();
            return Dialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Padding(
                    padding: EdgeInsets.fromLTRB(12, 12, 12, 0),
                    child: TextField(
                      autofocus: true,
                      decoration: InputDecoration(
                        hintText: Language().getString(
                            Constants.SELECT_CITY, selectedLang),
                        prefixIcon: Icon(Icons.search, color: Colors.grey),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        contentPadding: EdgeInsets.symmetric(vertical: 10),
                      ),
                      onChanged: (value) {
                        setState(() {
                          query = value;
                        });
                      },
                    ),
                  ),
                  SizedBox(
                    height: 300,
                    child: filtered.isEmpty
                        ? Center(
                            child: Text("No cities found",
                                style: TextStyle(color: Colors.grey)))
                        : ListView.builder(
                            itemCount: filtered.length,
                            itemBuilder: (context, index) {
                              return ListTile(
                                title: Text(filtered[index],
                                    style: TextStyle(
                                        fontFamily: StyleView.FONT_TITLE)),
                                onTap: () {
                                  Navigator.of(context).pop(filtered[index]);
                                },
                              );
                            },
                          ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(bottom: 8),
                    child: TextButton(
                      onPressed: () => Navigator.of(context).pop(null),
                      child: Text(
                        Language().getString(Constants.STR_CANCEL, selectedLang),
                        style: TextStyle(color: Colors.red),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Future<void> loadDropdownValues() async {
    if (await NetworkStatus.getInternetStatus()) {
      List<CountryDAO> countryData =
          await CountryApiService.instance.getCountries();
      if (countryData.length > 0) {
        setState(() {
          countryList.addAll(countryData);
          if (widget.isLocationUpdate) {
            for (int i = 0; i < countryList.length; i++) {
              if (widget.locationData?.addressDetails!.country ==
                  countryList[i].name) {
                countryDropdown = countryList[i];
                break;
              }
            }
          }
          for (int i = 0; i < countryList.length; i++) {
            if (countryList[i].name == "India") {
              countryDropdown = countryList[i];
              break;
            }
          }
        });
      }
      if (countryDropdown != null) {
        _fetchSatesData(countryName: countryDropdown!.name!);
      }
      if (AppController.instance.getMyBuId != null) {
        _fetchUserDetails();
      } else {
        setState(() {
          userNameController.text = userName!;
          userPhoneNoController.text = userPhoneNumber!;
        });
      }
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<void> _fetchSatesData({required String countryName}) async {
    List<StatesDAO> statesData =
        await CountryApiService.instance.getStates(countryName: countryName);
    if (statesData.length > 0) {
      setState(() => statesList.addAll(statesData));
      if (widget.isLocationUpdate) {
        for (int i = 0; i < statesList.length; i++) {
          if (widget.locationData?.addressDetails!.state ==
              statesList[i].state) {
            setState(() {
              stateDropdown = statesList[i];
            });
            break;
          }
        }

        if (stateDropdown != null) {
          for (var element in stateDropdown!.cities!) {
            if ((widget.locationData?.addressDetails!.villagetowncity ==
                    element) ||
                (widget.locationData?.addressDetails!.district == element)) {
              setState(() {
                citiesList.addAll(stateDropdown!.cities!);
                citiDropdown = element;
              });
              break;
            }
          }
        }
      }
    }
  }

  // Future<String> getToken() async {
  //   dynamic finalResponse = "";
  //   var headers = {'Content-Type': 'application/x-www-form-urlencoded'};
  //   var request = http.Request('POST',
  //       Uri.parse('https://outpost.mappls.com/api/security/oauth/token'));
  //   request.bodyFields = {
  //     'grant_type': 'client_credentials',
  //     'client_id':
  //         '96dHZVzsAutABCF3k2gFN2Xnp2Im-R4YSTlEKK9RKLr9bfXu9rrUflg6rY_BRIiiXXQPtcjpsm4B0MvvzXLG4Q==',
  //     'client_secret':
  //         'lrFxI-iSEg_DHCidH2fZvlW-85VD2KXitJKujU79oeMqI8PG2Vw80oR5zuR3HvaWYDTkevl4MYXO8rESAm3b4C2nrYTpsX_K'
  //   };
  //   request.headers.addAll(headers);

  //   http.StreamedResponse response = await request.send();

  //   if (response.statusCode == 200) {
  //     finalResponse = await response.stream.bytesToString();
  //     _authInfo = AuthInfo.fromJson(jsonDecode(finalResponse));
  //     // mapAuthInfo = finalResponse;
  //     // print(finalResponse);
  //   } else {
  //     // print(response.reasonPhrase);
  //   }
  //   return finalResponse;
  // }

  // Future<MapAutoSuggestResponse> autoSuggetionsByText(String text) async {
  //   var headers = {
  //     'Authorization': "${_authInfo?.tokenType} ${_authInfo?.accessToken}"
  //   };
  //   var request = http.Request(
  //       'GET',
  //       Uri.parse(
  //           'https://atlas.mappls.com/api/places/search/json?query=$text'));
  //   request.headers.addAll(headers);
  //   http.StreamedResponse response = await request.send();
  //   if (response.statusCode == 200) {
  //     String finalResponse = await response.stream.bytesToString();
  //     // print(finalResponse);
  //     return MapAutoSuggestResponse.fromJson(jsonDecode(finalResponse));
  //   } else {
  //     throw response.reasonPhrase!;
  //   }
  // }

  // Future<void> getElocCoordinates(String eLoc) async {
  //   // print("getElocCoordinates calling");
  //   setState(() => isLoadingProgress = true);
  //   var headers = {'Authorization': 'bearer ${_authInfo?.accessToken}'};
  //   var request = http.Request(
  //       'GET', Uri.parse('https://explore.mappls.com/apis/O2O/entity/$eLoc'));
  //   request.headers.addAll(headers);
  //   http.StreamedResponse response = await request.send();
  //   setState(() => isLoadingProgress = false);
  //   if (response.statusCode == 200) {
  //     String strELocData = await response.stream.bytesToString();
  //     eLocData = json.decode(strELocData);
  //     print("Lat/Log data " + eLoc);
  //     prepareLocationObject();
  //   } else {
  //     setState(() {
  //       isLoadingProgress = false;
  //     });
  //     Dialogs.yesCancelDialog(
  //         context,
  //         Language().getString(Constants.ERROR, selectedLang),
  //         "${response.reasonPhrase}",
  //         Language().getString(Constants.OKAY_STR, selectedLang),
  //         "",
  //         false);
  //     print(response.reasonPhrase);
  //   }
  // }

  // Future<void> getElocId(String address) async {
  //   print('https://atlas.mapmyindia.com/api/places/geocode?address=$address');
  //   setState(() => isLoadingProgress = true);

  //   jsonp(
  //     'https://atlas.mapmyindia.com/api/places/geocode?address=$address&access_token=${_authInfo?.accessToken}',
  //     (js.JsObject data) {
  //       // // Handle the response
  //       var coordinates =
  //           data["copResults"]["eLoc"]; //data['suggestedLocations'];
  //       getElocCoordinates(coordinates);
  //       window.console.log(coordinates);
  //       print(coordinates);
  //       return list;
  //     },
  //   );
  // }

  void jsonp(String url, Function callback) {
    if (kIsWeb) {
      final callbackName = 'jsonp_callback_${(Random().nextInt(100000))}';

      // Create the script element
      final script = ScriptElement();
      script.src =
          url + (url.contains('?') ? '&' : '?') + 'callback=$callbackName';
      document.body?.append(script);

      // Define the callback in the global scope
      js.context[callbackName] = (dynamic data) {
        window.console.debug('Callback data: $data');

        // Cleanup: remove the callback and script
        js.context.deleteProperty(callbackName);
        script.remove();

        // Call the provided callback function
        callback(data);
      };
    }
  }

  // Future<List<SuggestedLocations>> auto(String token, String text) async {
  //   if (kIsWeb) {
  //     print("Auto() is calling");
  //     List<SuggestedLocations> list = [];
  //     jsonp(
  //       'https://atlas.mappls.com/api/places/search/json?query=$text&access_token=$token',
  //       (js.JsObject data) {
  //         // // Handle the response
  //         var suggestedLocations = data['suggestedLocations'];
  //         List<Map<String, dynamic>> map = [];
  //         for (var i = 0; i < suggestedLocations.length; i++) {
  //           map.add(jsToMap(suggestedLocations[i]));
  //           list.add(
  //               SuggestedLocations.fromJson(jsToMap(suggestedLocations[i])));
  //         }
  //         if (list.length > 0) {
  //           setState(() => _elocation = list);
  //         }
  //         window.console.log(map);
  //         print(map);
  //         return list;
  //       },
  //     );
  //   }

  //   return [];
  // }

  // Map<String, dynamic> jsToMap(js.JsObject jsObject) {
  //   return {
  //     'type': jsObject['type'],
  //     'placeAddress': jsObject['placeAddress'],
  //     'eLoc': jsObject['eLoc'],
  //     'placeName': jsObject['placeName'],
  //     'alternateName': jsObject['alternateName'],
  //     'orderIndex': jsObject['orderIndex'],
  //     'suggester': jsObject['suggester'],
  //   };
  // }

//   locationIndexing(
//       {required List<String> splitLocation,
//       required int postalcodeIndex,
//       required int stateIndex,
//       required int cityIndex,
//       required int localityIndex,
//       required int streetIndex,
//       required int houseIndex,
//       required int plotIndex,
//       required String placeName}) {
//     if (postalcodeIndex != -1) {
//       postalCodeController.text = splitLocation[postalcodeIndex].trim();
//     }
//     if (stateIndex != -1) {
//       for (var i = 0; i < statesList.length; i++) {
//         if (statesList[i].state == splitLocation[stateIndex].trim()) {
//           setState(() {
//             stateDropdown = statesList[i];
//           });
//           break;
//         }
//       }
//     }

//     if (stateDropdown != null && cityIndex != -1) {
//       setState(() {
//         citiesList.addAll(stateDropdown!.cities!);
//       });
//       for (var i = 0; i < citiesList.length; i++) {
//         if (citiesList[i] == splitLocation[cityIndex].trim()) {
//           setState(() {
//             citiDropdown = citiesList[i];
//           });
//           break;
//         }
//       }
//     }
//     if (localityIndex != -1) {
//       localityController.text = splitLocation[localityIndex].trim();
//     }
//     if (streetIndex != -1) {
//       streetNameController.text = splitLocation[streetIndex].trim();
//     }
//     if (houseIndex != -1) {
//       houseNoController.text = splitLocation[houseIndex].trim();
//     }
//     if (plotIndex != -1) {
//       plotNoController.text = placeName +
//           "," +
//           splitLocation.sublist(0, splitLocation.length - 6).join(',');
//     }
//   }

// }

  selectedLocationDetails(
      {required String postalcode,
      required String state,
      required String city,
      required String locality,
      required String street,
      required String house,
      required String plot,
      required String placeName}) {
    if (postalcode.isNotEmpty) {
      postalCodeController.text = postalcode.trim();
    }
    if (state.isNotEmpty) {
      for (var i = 0; i < statesList.length; i++) {
        if (statesList[i].state == state) {
          setState(() {
            stateDropdown = statesList[i];
          });
          break;
        }
      }
    }

    if (stateDropdown != null && city.isNotEmpty) {
      setState(() {
        citiesList.addAll(stateDropdown!.cities!);
      });
      for (var i = 0; i < citiesList.length; i++) {
        if (citiesList[i] == city.trim()) {
          setState(() {
            citiDropdown = citiesList[i];
          });
          break;
        }
      }
    }
    if (locality.isNotEmpty) {
      localityController.text = locality.trim();
    }
    if (street.isNotEmpty) {
      streetNameController.text = street.trim();
    }
    if (house.isNotEmpty) {
      houseNoController.text = house.trim();
    }
    if (plot.isNotEmpty) {
      plotNoController.text = placeName + "," + plot;
    }
  }
}
