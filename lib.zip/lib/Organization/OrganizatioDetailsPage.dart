import 'dart:io';
import 'package:vyaparlive/components/display_attached_file/DisplayAttachedFile.dart';
import 'package:vyaparlive/core/enums/privilleges_enum.dart';
import 'package:vyaparlive/image_hero/ImageHeroView.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:vyaparlive/utills/webview_page.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/Organization/PaymentDetailsPage.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/TextView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/model/BusinessRelationDAO.dart';
import 'package:vyaparlive/model/BusinessUnitModel.dart';
import 'package:vyaparlive/model/CitiesDAO.dart';
import 'package:vyaparlive/model/CountryDAO.dart';
import 'package:vyaparlive/model/CurrecyNameDAO.dart';
import 'package:mime/mime.dart';
import 'package:vyaparlive/model/ExportsModel.dart';
import 'package:vyaparlive/model/RegulationData.dart';
import 'package:vyaparlive/model/StatesDAO.dart';
import 'package:vyaparlive/model/TaxInfoModel.dart';
import 'package:vyaparlive/model/TaxSchemeData.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/model/TermsData.dart';
import 'package:vyaparlive/model/bu_model/PaymentTermsDAO.dart';
import 'package:vyaparlive/model/bu_model/PenaltyAmountDAO.dart';
import 'package:vyaparlive/service/Service.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:vyaparlive/model/DirectorData.dart';
import 'package:toast/toast.dart';
import 'package:signature/signature.dart';

class OrganizationDetailsView extends StatefulWidget {
  final String? organizationId;
  OrganizationDetailsView({this.organizationId = ""});
  @override
  _OrganizationDetailsViewState createState() =>
      _OrganizationDetailsViewState();
}

class _OrganizationDetailsViewState extends State<OrganizationDetailsView> {
  List<DirectorsData> dynamicListData = [];
  final _personNameController = TextEditingController();
  static const List<String> DINDROPDOWNITEMS = ["DIN", "PAN"];
  final _personIdentificationNumberController = TextEditingController();
  final _digitalSignatureController = TextEditingController();
  String digitalSig = "";
  File? _image;
  final double verticalSize = 10.0;
  EdgeInsetsGeometry dialogTitlePadding =
      EdgeInsets.fromLTRB(17.0, 24.0, 24.0, 5.0);
  BusinessUnitModel? _buModel;
  final _exportsRegisterNameController = TextEditingController();
  final _exportsRegisterIdController = TextEditingController();
  final List<ExportsModel> _storeExportsData = [];
  final List<ExportsModel> _storeImportsData = [];
  List<BankDetails> dynamicListRecievesData = [];
  List<BankDetails> dynamicListPaymentsData = [];
  final _importsRegistrationNameController = TextEditingController();
  final _importsRegistrationIdController = TextEditingController();
  DateTime selectedDate = DateTime.now();
  DateFormat formatter = DateFormat("yyyy-MM-dd");
  String? registrationDate = "";
  List<CurrencyNameDAO> _currencyList = [];
  CurrencyNameDAO? currencyDropdown;
  List<BusinessRelationDAO> _regEntityList = [];
  BusinessRelationDAO? entityDropdown;
  CountryDAO? schemeDropdown;
  final TextEditingController _govtTaxschemeNumberController =
      TextEditingController();
  final TextEditingController _businessIdController =
      new TextEditingController();
  final TextEditingController _registerIdController =
      new TextEditingController();
  final List<TaxSchemeData> _storeTaxSchemeData = [];
  final List<RegulationData> _storeRegulationData = [];
  final regOrgNameController = TextEditingController();
  final regOrgCityController = TextEditingController();
  final regOrgStateController = TextEditingController();

  final receiveBankNameController = TextEditingController();
  final receiveAccountNameController = TextEditingController();
  final receiveAccountNumController = TextEditingController();
  final receiveEpayCodeController = TextEditingController();
  final receiveSwiftCodeController = TextEditingController();
  final receiveMicrCodeController = TextEditingController();
  final ifscCodeController = TextEditingController();

  final payBankNameController = TextEditingController();
  final payAccountNameController = TextEditingController();
  final payAccountNumController = TextEditingController();
  final payEpayCodeController = TextEditingController();
  final paySwiftCodeController = TextEditingController();
  final payMicrCodeController = TextEditingController();

  final invoiceCurrencyController = TextEditingController();
  final paymentPeriodController = TextEditingController();
  final numberOfDaysController = TextEditingController();
  final invoiceDiscriptionController = TextEditingController();
  final partialPaymentController = TextEditingController();
  final penaltyAmountController = TextEditingController();
  final penaltyPercentRateController = TextEditingController();
  final descriptionController = TextEditingController();
  final basisAmountController = TextEditingController();
  String? selectedLang = AppController.instance.getSelectedlanguage; // 'en';
  late SharedPreferences sharedPreferences;
  late Service _service;
  bool? isOrgUpdate = false;
  StatesDAO? statesDropdownValue;
  List<StatesDAO> _statesList = [];
  String? cityDropdownValue;
  List<String> _citiesList = [];
  String? citiesDropDownValue;
  bool isLoading = false;
  String? numberofdaysDropdown;
  String? paymentPercentage;
  String? penaltyPercentage;
  List<CountryDAO> _countryList = [];
  CountryDAO? countryDropdownValue;
  String? taxSchemeType;
  String? buId = "";
  String? dinDropdownValue;
  String? advancePaymentYesValue;
  String? advancePaymentNoValue;
  String? _radioValue;
  String? choice;
  bool isPaymentVisible = false;
  final _commentController = TextEditingController();
  String? penaltyAmountPercentage;
  List<String> _addTermsFields = [];
  List<TermsData> _termsList = [];
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? inpersonOrderRadioValue;
  String? bankDetailsRadioValue = Constants.NO_STRING;
  List<PaymentTermsDAO> paymentTermsList = [];
  PaymentTermsDAO? paymentTermDropdown;
  List<PenaltyAmountDAO> penaltyAmountList = [];
  PenaltyAmountDAO? penaltyAmountDropdown;
  TextEditingController _panController = new TextEditingController();
  TextEditingController _cinController = new TextEditingController();
  File? imageFile;
  String? imageBlob = '';
  String imageRelativePath = '';
  bool isSelectCaptureChoice = false;
  late SignatureController signatureController = new SignatureController();
  bool isEnableDigitalSignature = false;
  void initState() {
    super.initState();
    AppController.instance.setCreateBuProgress = true;
    buId = AppController.instance.getMyBuId;
    isOrgUpdate = AppController.instance.isOrganizationUpdate;
    _service = Service();
    if (CommonMethods.isPrivillegeExist(
        context,
        PrivillegesActions
            .KEY_MY_COMPANY_BU_STEP_3_DIRECTORS_POPUP_DIGITAL_SIGNITURE)) {
      isEnableDigitalSignature = true;
    }
    if (isOrgUpdate!) {
      updateOrganizationDetails();
    } else {
      loadDropdownValues();
      autoFillRegOrgDetails();
      inpersonOrderRadioValue = Constants.YES_STRING;
      AppController.instance.getOrganizationFieldsData.setInpersonOrderAccept =
          true;
    }
  }

  loadDropdownValues() async {
    if (await NetworkStatus.getInternetStatus()) {
      await this.getLegelEntityData().then((value) {
        setState(() {
          _regEntityList.clear();
          _regEntityList.addAll(value);
        });
      });

      // this.getCountries().then((value) {
      //   setState(() {
      //     _countryList.addAll(value);
      //   });
      // });
      this.getCurrency().then((value) {
        setState(() {
          _currencyList.addAll(value);
        });
      });
      await this.getPaymentTerms().then((value) {
        setState(() {
          paymentTermsList.clear();
          paymentTermsList.addAll(value);
        });
      });
      setState(() {
        penaltyAmountList.clear();
        penaltyAmountList.add(PenaltyAmountDAO(reason: "Select reason"));
      });
      await this.getPenaltyAmountList().then((value) {
        setState(() {
          // penaltyAmountList.clear();
          // penaltyAmountList.add(penaltyAmountDropdown!);
          // penaltyAmountList.add(PenaltyAmountDAO(reason: "Select reason"));
          penaltyAmountList.addAll(value);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  /// Service call for currency

  Future<List<CurrencyNameDAO>> getCurrency() async {
    http.Response response = await _service.getDropDownType("lookup/currency");

    List<CurrencyNameDAO> list = [];

    if (response.statusCode == 200) {
      var data = json.decode(response.body);
      for (var objects in data["data"])
        list.add(CurrencyNameDAO.fromJson(objects));
      if (_buModel != null &&
          _buModel!.paymentTerms != null &&
          list.length > 0 &&
          _buModel!.paymentTerms!.invoicecurrencycode != null) {
        for (int i = 0; i < list.length; i++) {
          if (_buModel!.paymentTerms!.invoicecurrencycode == list[i].code) {
            currencyDropdown = list[i];
            AppController.instance.getOrganizationFieldsData
                .invoiceCurrencyCode = currencyDropdown!.code;
          }
        }
      } else {
        if (list.length > 0 &&
            AppController.instance.organizationFieldsData!.currencyCode !=
                null) {
          for (int i = 0; i < list.length; i++) {
            if (AppController.instance.organizationFieldsData!.currencyCode ==
                list[i].code) {
              currencyDropdown = list[i];
            }
          }
          if (currencyDropdown != null) {
            AppController.instance.getOrganizationFieldsData
                .invoiceCurrencyCode = currencyDropdown!.code;
          }
        }
      }
    }
    return list;
  }

  /// Service call for legalEntity

  Future<List<BusinessRelationDAO>> getLegelEntityData() async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = Constants.GETTING_BUSINESS_TYPES;
      AppController.instance.setCreateBuProgress = true;
    });

    http.Response response =
        await _service.getDropDownType("lookup/businessType");
    // "lookup/legalentityType");

    List<BusinessRelationDAO> list = [];

    setState(() {
      isLoadingProgress = false;
      AppController.instance.setCreateBuProgress = false;
    });
    if (response.statusCode == 200) {
      var data = json.decode(response.body);
      for (var object in data["data"]) {
        list.add(BusinessRelationDAO.fromJson(object));
      }
      if (_buModel != null &&
          list.length > 0 &&
          _buModel!.registration != null &&
          _buModel!.registration!.legalentityType != null) {
        for (int i = 0; i < list.length; i++) {
          if (_buModel!.registration!.legalentityType == list[i].type) {
            setState(() {
              entityDropdown = list[i];
            });
            AppController.instance.getOrganizationFieldsData.regentityType =
                entityDropdown!.type;
          }
        }
      } else {
        if (list.length > 0 &&
            AppController.instance.getOrganizationFieldsData.businessType !=
                null) {
          for (int j = 0; j < list.length; j++) {
            if (AppController.instance.getOrganizationFieldsData.businessType ==
                list[j].type) {
              setState(() {
                entityDropdown = list[j];
              });
              AppController.instance.getOrganizationFieldsData.regentityType =
                  entityDropdown!.type;
            }
          }
        }
      }
    } else {
      // await progressDialog.hide();
    }

    return list;
  }

  autoFillRegOrgDetails() {
    regOrgNameController.text =
        AppController.instance.organizationFieldsData!.businessName != null
            ? AppController.instance.organizationFieldsData!.businessName!
            : "";
    regOrgCityController.text =
        AppController.instance.organizationFieldsData!.city != null
            ? AppController.instance.organizationFieldsData!.city!
            : "";
    AppController.instance.organizationFieldsData!.regOrgName =
        regOrgNameController.text;
    AppController.instance.organizationFieldsData!.regOrgCity =
        regOrgCityController.text;
  }

  /// Updating organization details when it comes for update

  void updateOrganizationDetails() {
    _buModel = AppController.instance.getBusinessUnitData;
    if (_buModel != null) {
      if (_buModel!.registration != null) {
        regOrgNameController.text =
            _buModel!.registration!.govtregisteredName != null
                ? _buModel!.registration!.govtregisteredName!
                : "";
        regOrgCityController.text =
            _buModel!.registration!.registrationCity != null
                ? _buModel!.registration!.registrationCity!
                : "";
        registrationDate = _buModel!.registration!.registrationDate != null
            ? _buModel!.registration!.registrationDate
            : "";
        _panController.text = _buModel!.registration!.panNumber!;
        _cinController.text = _buModel!.registration!.cinNumber!;

        AppController.instance.organizationFieldsData!.regOrgName =
            regOrgNameController.text;
        AppController.instance.organizationFieldsData!.regOrgCity =
            regOrgCityController.text;
        AppController.instance.organizationFieldsData!.regOrgDate =
            registrationDate;
        AppController.instance.organizationFieldsData!.panCardNumber =
            _panController.text;
        AppController.instance.organizationFieldsData!.cinCardNumber =
            _cinController.text;
      }

      for (int i = 0; i < _buModel!.directors!.length; i++) {
        dynamicListData.add(DirectorsData(
            personName: _buModel!.directors![i].personName,
            personSchemeName:
                _buModel!.directors![i].personidentificationSchemename,
            personIdentificationNumber:
                _buModel!.directors![i].personidentificationNumber,
            digitalSignature: _buModel!.directors![i].digitalSignature));
      }

      AppController.instance.organizationFieldsData!.directorsData =
          dynamicListData;

      for (int i = 0; i < _buModel!.regulation!.length; i++) {
        _storeRegulationData.add(RegulationData(
            govtbusinessSchemeid: _buModel!.regulation![i].govtbusinessSchemeid,
            govtregistrationId: _buModel!.regulation![i].govtregistrationId));
      }

      AppController.instance.getOrganizationFieldsData.regulationArray =
          _storeRegulationData;

      for (int i = 0; i < _buModel!.exports!.length; i++) {
        _storeExportsData.add(ExportsModel(
            govtregistrationSchemeid:
                _buModel!.exports![i].govtregistrationSchemeid,
            govtregistrationSchemename:
                _buModel!.exports![i].govtregistrationSchemename));
      }

      AppController.instance.getOrganizationFieldsData.exportsArray =
          _storeExportsData;

      for (int i = 0; i < _buModel!.imports!.length; i++) {
        _storeImportsData.add(ExportsModel(
            govtregistrationSchemeid:
                _buModel!.imports![i].govtregistrationSchemeid,
            govtregistrationSchemename:
                _buModel!.imports![i].govtregistrationSchemename));
      }

      AppController.instance.getOrganizationFieldsData.importsArray =
          _storeImportsData;

      for (int i = 0; i < _buModel!.bankDetailsReceives!.length; i++) {
        dynamicListRecievesData.add(BankDetails(
            bankname: _buModel!.bankDetailsReceives![i].bankName,
            bankaccountname: _buModel!.bankDetailsReceives![i].bankAccountName,
            bankAccountNumber:
                _buModel!.bankDetailsReceives![i].bankAccountNumber,
            epayCode: _buModel!.bankDetailsReceives![i].ePayCode,
            swiftCode: _buModel!.bankDetailsReceives![i].swifTcode,
            micrCode: _buModel!.bankDetailsReceives![i].micrCode,
            ifscCode: _buModel!.bankDetailsReceives![i].ifscCode,
            isShowInvoiceView:
                _buModel!.bankDetailsReceives![i].isShowBankDataInInvoice));
      }
      AppController.instance.getOrganizationFieldsData.bankReceiveArray =
          dynamicListRecievesData;

      /**
         * update tax scheme details
         */

      for (int i = 0; i < _buModel!.taxScheme!.length; i++) {
        _storeTaxSchemeData.add(TaxSchemeData(
            govttaxscheme_name: _buModel!.taxScheme![i].schemeName,
            govttaxscheme_number: _buModel!.taxScheme![i].schemeNumber,
            taxexemption_reason: _buModel!.taxScheme![i].reason));
      }

      AppController.instance.getOrganizationFieldsData.taxSchemeArray =
          _storeTaxSchemeData;

      ///Checking payment terms values
      ///
      if (_buModel!.paymentTerms != null) {
        if (_buModel!.paymentTerms!.penaltyAmount != null &&
            _buModel!.paymentTerms!.penaltyAmount!.value != null &&
            _buModel!.paymentTerms!.penaltyAmount!.value != 0) {
          penaltyAmountPercentage =
              "${_buModel!.paymentTerms!.penaltyAmount!.value} %";

          AppController.instance.getOrganizationFieldsData
              .penaltyAmountPercentage = penaltyAmountPercentage;
        }

        _commentController.text = _buModel!.paymentTerms!.comment!;

        if (_buModel!.paymentTerms!.advancePayment != null &&
            _buModel!.paymentTerms!.advancePayment!.value != null) {
          advancePaymentYesValue =
              "${_buModel!.paymentTerms!.advancePayment!.value} %";
          _radioValue = _buModel!.paymentTerms!.advancePayment!.isActive!
              ? Constants.YES_STRING
              : Constants.NO_STRING;

          if (_radioValue == Constants.YES_STRING) {
            isPaymentVisible = true;
          }
          AppController.instance.getOrganizationFieldsData.advancePaymentValue =
              _radioValue;
          AppController.instance.getOrganizationFieldsData
              .advancePaymentPercentage = advancePaymentYesValue;
        }

        if (_buModel!.paymentTerms!.termsList!.length > 0) {
          for (int i = 0; i < _buModel!.paymentTerms!.termsList!.length; i++) {
            imageRelativePath = _buModel!.paymentTerms!.termsList![i].file!;
            _termsList.add(TermsData(
                termType: _buModel!.paymentTerms!.termsList![i].termType,
                termDescription:
                    _buModel!.paymentTerms!.termsList![i].termDescription,
                imageRelativePath: _buModel!.paymentTerms!.termsList![i].file));
          }
        }

        AppController.instance.getOrganizationFieldsData
            .termsAndConditionsList = _termsList;
        AppController.instance.getOrganizationFieldsData.paymentComments =
            _commentController.text;

        if (_buModel!.isInpersonOrderAccept!) {
          AppController
              .instance.getOrganizationFieldsData.setInpersonOrderAccept = true;
          inpersonOrderRadioValue = Constants.YES_STRING;
        } else {
          AppController.instance.getOrganizationFieldsData
              .setInpersonOrderAccept = false;
          inpersonOrderRadioValue = Constants.NO_STRING;
        }
      }

      loadDropdownValues();
    }
  }

  /// Highlite text

  // buildTextField(String _text) {
  //   return Row(
  //     children: <Widget>[
  //       Text(_text,
  //           style: TextStyle(
  //               fontSize: StyleView.FONT_SIZE_15,
  //               fontFamily: StyleView.FONT_TITLE,
  //               fontWeight: FontWeight.bold))
  //     ],
  //   );
  // }

  buildTextField(String _text) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Flexible(
          fit: FlexFit.loose,
          child: Text(
            _text,
            overflow: TextOverflow.ellipsis,
            maxLines: 2,
            softWrap: false,
            style: TextStyle(
              fontSize: StyleView.FONT_SIZE_15,
              fontFamily: StyleView.FONT_TITLE,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ],
    );
  }

  buildRegisterDateField(String textName) {
    String regDate = "";
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 53,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                            Language().getString(textName, selectedLang),
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: StyleView.FONT_TITLE))),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                color: Colors.white70,
                padding: EdgeInsets.only(left: 5),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.transparent,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(5.0)),
                    elevation: 0.0,
                  ),
                  onPressed: () async {
                    regDate = await AppUtills.getSelectedDate(context,
                        initialYear: 1923);
                    setState(() {
                      registrationDate = regDate;
                    });
                    AppController.instance.organizationFieldsData!.regOrgDate =
                        registrationDate;
                  },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Text(registrationDate!,
                          style: TextStyle(
                              fontSize: StyleView.FONT_SIZE_15,
                              fontFamily: StyleView.FONT_TITLE,
                              color: Colors.black)),
                      Image.asset(
                        'assets/images/calander.png',
                        scale: 2.3,
                      ),
                    ],
                  ),
                ),
              ),
            )
          ],
        ));
  }

  /// Dynamically creating organization fields

  buildTableContent(String textName, bool isDateRequire,
      TextEditingController _controller, String s, bool isNumberRequired) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 53,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(Language().getString(textName, selectedLang),
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_15,
                            fontFamily: StyleView.FONT_TITLE))),
              )),
        ),
        Expanded(
            flex: 2,
            child: Container(
              color: Colors.white70,
              padding: EdgeInsets.only(left: 5),
              child: isDateRequire
                  ? ElevatedButton(
                      onPressed: () async {
                        registrationDate =
                            await AppUtills.getSelectedDate(context);
                        setState(() {
                          registrationDate = registrationDate;
                        });
                        AppController.instance.organizationFieldsData!
                            .regOrgDate = registrationDate;
                      },
                      style: ElevatedButton.styleFrom(
                        elevation: 0.0,
                        backgroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(5.0)),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          buildTextField(registrationDate!),
                          Image.asset(
                            'assets/images/calander.png',
                            scale: 2.3,
                          ),
                        ],
                      ))
                  : TextFormField(
                      controller: _controller,
                      keyboardType: isNumberRequired
                          ? TextInputType.number
                          : TextInputType.text,
                      // focusNode: FocusNode(canRequestFocus: false),
                      style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                      decoration: InputDecoration(
                        hintText: Language().getString(textName, selectedLang),
                        border: InputBorder.none,
                      ),
                      onChanged: (text) => {
                        text = _controller.text,
                        updateData(textName, _controller.text)
                      },
                    ),
            ))
      ],
    );
  }

  /// Handling all flotaction buttons

  controllAllAddView(String text) {
    return InkWell(
        onTap: () {
          switch (text) {
            case Constants.DIRECTORS_NAME_STRING:
              buildDirectorFieldsTable(DirectorsData(), -1, false);
              break;
            case Constants.TAX_SCHEME_STRING:
              buildTaxSchemeData(new TaxSchemeData(), -1, false);
              break;

            case Constants.REGULATION_ID:
              onAddNewRegulationDetails(new RegulationData(), -1, false);
              break;

            case Constants.EXPORTS_ID:
              buildExportsFields(
                  Language().getString(Constants.EXPORT_DETAILS, selectedLang),
                  Language()
                      .getString(Constants.REGISTRATION_NAME, selectedLang),
                  Language().getString(Constants.REGISTRATION_ID, selectedLang),
                  _exportsRegisterNameController,
                  _exportsRegisterIdController,
                  new ExportsModel(),
                  -1,
                  false);
              break;

            case Constants.IMPORTS_ID:
              buildExportsFields(
                  Language().getString(Constants.IMPORT_DETAILS, selectedLang),
                  Language()
                      .getString(Constants.REGISTRATION_NAME, selectedLang),
                  Language().getString(Constants.REGISTRATION_ID, selectedLang),
                  _importsRegistrationNameController,
                  _importsRegistrationIdController,
                  new ExportsModel(),
                  -1,
                  false);
              break;

            case Constants.BANK_DETAILS:
              onAddReceivePayments(new BankDetails(), -1, false);
              break;
            case Constants.UPI_DETAILS:
              onAddUPID(new BankDetails(), -1, false);
              break;

            case Constants.RECEIVE_TAX:
              break;
            default:
          }
        },
        child: Container(
          margin: EdgeInsets.only(right: 5),
          decoration: BoxDecoration(shape: BoxShape.circle, boxShadow: [
            BoxShadow(
              color: Colors.grey,
              blurRadius: 5.0,
            ),
          ]),
          child: ClipOval(
            child: Material(
              color: Color(Constants.APP_COLOR),
              child: SizedBox(
                  width: 25.0,
                  height: 25.0,
                  child: Icon(
                    Icons.add,
                    size: 18.0,
                    color: Colors.white,
                  )),
            ),
          ),
        ));
  }

  /// BankReceive popup fields and update

  onAddReceivePayments(BankDetails data, int index, bool isBankReceiveUpdate) {
    if (isBankReceiveUpdate) {
      receiveBankNameController.text = data.bankname!;
      receiveAccountNameController.text = data.bankaccountname!;
      receiveAccountNumController.text = data.bankAccountNumber!;
      receiveEpayCodeController.text = data.epayCode!;
      receiveSwiftCodeController.text = data.swiftCode!;
      receiveMicrCodeController.text = data.micrCode!;
      ifscCodeController.text = data.ifscCode!;
      if (data.isShowInvoiceView!) {
        bankDetailsRadioValue = Constants.YES_STRING;
      }
    } else {
      receiveBankNameController.clear();
      receiveAccountNameController.clear();
      receiveAccountNumController.clear();
      receiveEpayCodeController.clear();
      receiveSwiftCodeController.clear();
      receiveMicrCodeController.clear();
      bankDetailsRadioValue = Constants.NO_STRING;
    }

    return showDialog(
        barrierDismissible: true,
        context: context,
        barrierColor: Colors.black54,
        builder: (BuildContext context) {
          return StatefulBuilder(builder: (context, StateSetter setState) {
            return AlertDialog(
              elevation: 100.0,
              contentPadding: EdgeInsets.fromLTRB(15.0, 0, 15.0, 0),
              backgroundColor: Colors.white, //(0XFFE0E0E0),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(7.0))),
              titlePadding: dialogTitlePadding,
              title: Text(
                Language().getString(Constants.ADD_BANK, selectedLang),
                style: TextStyle(
                    fontSize: 18.0,
                    color: Colors.black,
                    fontFamily: StyleView.FONT_TITLE),
              ),
              actions: <Widget>[
                Container(
                  padding: EdgeInsets.only(bottom: 10),
                  child: CommonButtonsView(
                    context: context,
                    b1Text: Language()
                        .getString(Constants.STR_CANCEL, selectedLang),
                    b2Text:
                        Language().getString(Constants.STR_SAVE, selectedLang),
                    onb1Action: () {
                      Navigator.of(context).pop();
                    },
                    onb2Action: () {
                      onSaveRecievePayments(index, isBankReceiveUpdate);
                    },
                  ),
                ),
              ],
              content: Container(
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      SizedBox(height: 20),
                      buildTextFormFieldsDialog(
                          Language()
                              .getString(Constants.BANK_NAME, selectedLang),
                          receiveBankNameController,
                          false),
                      SizedBox(height: 10),
                      buildTextFormFieldsDialog(
                          Language().getString(
                              Constants.BANK_ACCOUNT_NAME, selectedLang),
                          receiveAccountNameController,
                          false),
                      SizedBox(height: 10),
                      buildTextFormFieldsDialog(
                          Language().getString(
                              Constants.BANK_ACCOUNT_NUMBER, selectedLang),
                          receiveAccountNumController,
                          true),
                      // SizedBox(height: 10),
                      // buildTextFormFieldsDialog(
                      //     Language().getString(Constants.EPAY, selectedLang),
                      //     receiveEpayCodeController,
                      //     false),
                      SizedBox(height: 10),
                      buildTextFormFieldsDialog(
                          Language()
                              .getString(Constants.IFSC_CODE, selectedLang),
                          ifscCodeController,
                          false),
                      SizedBox(height: 10),
                      buildTextFormFieldsDialog(
                          Language()
                              .getString(Constants.MICR_CODE, selectedLang),
                          receiveMicrCodeController,
                          false),
                      SizedBox(height: 10),
                      buildTextFormFieldsDialog(
                          Language()
                              .getString(Constants.SWIFT_CODE, selectedLang),
                          receiveSwiftCodeController,
                          false),
                      SizedBox(height: 10),
                      if (CommonMethods.isPrivillegeExist(
                          context,
                          PrivillegesActions
                              .KEY_MY_COMPANY_BU_STEP_2_BANK_DETAILS_ON_INVOICE))
                        this.showDetailsInInvoiceView(setState)
                    ],
                  ),
                ),
              ),
            );
          });
        });
  }

  onAddUPID(BankDetails data, int index, bool isBankReceiveUpdate) {
    if (isBankReceiveUpdate) {
      receiveEpayCodeController.text = data.epayCode!;
    } else {
      receiveEpayCodeController.clear();
    }

    return showDialog(
        barrierDismissible: true,
        context: context,
        barrierColor: Colors.black54,
        builder: (BuildContext context) {
          return StatefulBuilder(builder: (context, StateSetter setState) {
            return AlertDialog(
              elevation: 100.0,
              contentPadding: EdgeInsets.fromLTRB(15.0, 0, 15.0, 0),
              backgroundColor: Colors.white, //(0XFFE0E0E0),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(7.0))),
              titlePadding: dialogTitlePadding,
              title: Text(
                Language().getString(Constants.ADD_UPID, selectedLang),
                style: TextStyle(
                    fontSize: 18.0,
                    color: Colors.black,
                    fontFamily: StyleView.FONT_TITLE),
              ),
              actions: <Widget>[
                Container(
                  padding: EdgeInsets.only(bottom: 10),
                  child: CommonButtonsView(
                    context: context,
                    b1Text: Language()
                        .getString(Constants.STR_CANCEL, selectedLang),
                    b2Text:
                        Language().getString(Constants.STR_SAVE, selectedLang),
                    onb1Action: () {
                      Navigator.of(context).pop();
                    },
                    onb2Action: () {
                      onSaveRecievePayments(index, isBankReceiveUpdate);
                    },
                  ),
                ),
              ],
              content: Container(
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      SizedBox(height: 20),
                      buildTextFormFieldsDialog(
                          Language().getString(Constants.EPAY, selectedLang),
                          receiveEpayCodeController,
                          false),
                    ],
                  ),
                ),
              ),
            );
          });
        });
  }

  /// Save bank receive details

  void onSaveRecievePayments(int index, bool isBankReceiveUpdate) {
    if (isBankReceiveUpdate) {
      dynamicListRecievesData[index] = BankDetails(
          bankname: receiveBankNameController.text,
          bankaccountname: receiveAccountNameController.text,
          bankAccountNumber: receiveAccountNumController.text,
          epayCode: receiveEpayCodeController.text,
          swiftCode: receiveSwiftCodeController.text,
          micrCode: receiveMicrCodeController.text,
          ifscCode: ifscCodeController.text,
          isShowInvoiceView:
              bankDetailsRadioValue == Constants.YES_STRING ? true : false);
    } else {
      dynamicListRecievesData.add(BankDetails(
          bankname: receiveBankNameController.text,
          bankaccountname: receiveAccountNameController.text,
          bankAccountNumber: receiveAccountNumController.text,
          epayCode: receiveEpayCodeController.text,
          swiftCode: receiveSwiftCodeController.text,
          micrCode: receiveMicrCodeController.text,
          ifscCode: ifscCodeController.text,
          isShowInvoiceView:
              bankDetailsRadioValue == Constants.YES_STRING ? true : false));
    }
    setState(() {
      dynamicListRecievesData.reversed;
      AppController.instance.getOrganizationFieldsData.bankReceiveArray =
          dynamicListRecievesData;
    });

    Navigator.of(context).pop();
  }

  /// Regulation popup fileds and update

  onAddNewRegulationDetails(
      RegulationData data, int index, bool isRegulationUpdate) {
    if (isRegulationUpdate) {
      _businessIdController.text = data.govtbusinessSchemeid!;
      _registerIdController.text = data.govtregistrationId!;
    } else {
      _businessIdController.clear();
      _registerIdController.clear();
    }

    return showDialog(
        barrierDismissible: true,
        context: context,
        barrierColor: Colors.black54,
        builder: (BuildContext context) {
          return AlertDialog(
            elevation: 100.0,
            contentPadding: EdgeInsets.fromLTRB(15.0, 0, 15.0, 0),
            backgroundColor: Colors.white, //(0XFFE0E0E0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(
                Radius.circular(
                  7.0,
                ),
              ),
            ),
            actions: <Widget>[
              Container(
                padding: EdgeInsets.only(bottom: 10),
                child: CommonButtonsView(
                  context: context,
                  b1Text:
                      Language().getString(Constants.STR_CANCEL, selectedLang),
                  b2Text:
                      Language().getString(Constants.STR_SAVE, selectedLang),
                  onb1Action: () {
                    Navigator.of(context).pop();
                  },
                  onb2Action: () {
                    // String validationText = validateRegulationData();
                    //         if (validationText.isNotEmpty) {
                    onSaveNewRegulationData(index, isRegulationUpdate);
                    // } else {
                    //   Navigator.of(context).pop();
                    // }
                  },
                ),
              )
            ],
            titlePadding: dialogTitlePadding,
            title: Text(
              Language().getString(
                  isRegulationUpdate
                      ? Constants.UPDATE_REGULATION
                      : Constants.ADD_REGULATION,
                  selectedLang),
              style: TextStyle(
                  fontSize: 18.0,
                  color: Colors.black,
                  fontFamily: StyleView.FONT_TITLE),
            ),
            content: Container(
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    SizedBox(height: 20),
                    buildTextFormFieldsDialog(
                        Language()
                            .getString(Constants.REGULATION_NAME, selectedLang),
                        _businessIdController,
                        false),
                    SizedBox(height: 10),
                    buildTextFormFieldsDialog(
                        Language().getString(Constants.REGULA_ID, selectedLang),
                        _registerIdController,
                        false),
                  ],
                ),
              ),
            ),
          );
        });
  }

  /// Save regulation details

  onSaveNewRegulationData(int index, bool isRegulationUpdate) {
    if (isRegulationUpdate) {
      _storeRegulationData[index] = RegulationData(
          govtbusinessSchemeid: _businessIdController.text,
          govtregistrationId: _registerIdController.text);
      setState(() {
        _storeRegulationData.reversed;
      });
    } else {
      _storeRegulationData.add(RegulationData(
          govtbusinessSchemeid: _businessIdController.text,
          govtregistrationId: _registerIdController.text));
      setState(() {
        _storeRegulationData.reversed;
      });
    }
    AppController.instance.getOrganizationFieldsData.regulationArray =
        _storeRegulationData;
    Navigator.of(context).pop();
  }

  /// Dynamically creating TaxInfo,Exports,Imports fields

  buildTextFormFieldsDialog(String? _labelText,
      TextEditingController controller, bool isNumberKeyboard) {
    return Container(
        height: 50,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(
            5.0,
          ),
          color: Colors.white,
        ),
        margin: EdgeInsets.symmetric(vertical: 3.0),
        child: new TextFormField(
            keyboardType: isNumberKeyboard
                ? TextInputType.numberWithOptions(signed: true)
                : TextInputType.text,
            style: TextStyle(fontFamily: StyleView.FONT_TITLE),
            textInputAction: TextInputAction.next,
            controller: controller,
            inputFormatters: isNumberKeyboard
                ? [CommonMethods.inputTextFormatter(isNumber: true)]
                : [],
            decoration: StyleView.getInputDecoration(
              helper: _labelText,
            ),
            onChanged: (text) => {}));
  }

  /// Tax scheme popup fields and update

  buildTaxSchemeData(TaxSchemeData data, int index, bool isListUpdate) {
    if (isListUpdate) {
      taxSchemeType = data.govttaxscheme_name;
      _govtTaxschemeNumberController.text = data.govttaxscheme_number!;
    } else {
      taxSchemeType = null;
      _govtTaxschemeNumberController.clear();
    }

    return showDialog(
      barrierDismissible: false,
      context: context,
      barrierColor: Colors.black54,
      builder: (BuildContext context) {
        return AlertDialog(
          elevation: 100.0,
          contentPadding: EdgeInsets.fromLTRB(15.0, 0, 15.0, 0),
          backgroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(
              Radius.circular(
                7.0,
              ),
            ),
          ),
          titlePadding: dialogTitlePadding,
          title: Text(
            Language().getString(Constants.ADD_NEW_TAX, selectedLang),
            style: TextStyle(
                fontSize: 18.0,
                color: Colors.black, //(Constants.APP_COLOR),
                fontFamily: StyleView.FONT_TITLE),
          ),
          actions: <Widget>[
            Container(
              padding: EdgeInsets.only(bottom: 10),
              child: CommonButtonsView(
                context: context,
                b1Text:
                    Language().getString(Constants.STR_CANCEL, selectedLang),
                b2Text: Language().getString(Constants.STR_SAVE, selectedLang),
                onb1Action: () {
                  Navigator.of(context).pop();
                },
                onb2Action: () {
//  String validation = validateTaxSchemeData();
//                             if (validation.isNotEmpty) {
                  onSaveTaxSchemeDetails(index, isListUpdate);
                  // } else {
                  //   Navigator.of(context).pop();
                  // }
                },
              ),
            )
          ],
          content: StatefulBuilder(
            builder: (BuildContext context, StateSetter setState) => Container(
              height: 150.0,
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    SizedBox(height: 20),
                    Container(
                        margin: EdgeInsets.symmetric(
                          vertical: 10.0,
                        ),
                        padding: EdgeInsets.all(1),
                        decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey),
                            borderRadius: BorderRadius.circular(5.0)),
                        child: Row(
                          children: <Widget>[
                            Expanded(
                              child: Container(
                                  height: 50,
                                  color: Color(Constants.GREY_COLOR_LIGHT),
                                  child: Container(
                                    padding: EdgeInsets.only(left: 10),
                                    child: Align(
                                        alignment: Alignment.centerLeft,
                                        child: Text(
                                            Language().getString(
                                                Constants.TAX, selectedLang),
                                            style: TextStyle(
                                                fontSize:
                                                    StyleView.FONT_SIZE_15,
                                                fontFamily:
                                                    StyleView.FONT_TITLE))),
                                  )),
                            ),
                            Expanded(
                              flex: 2,
                              child: Container(
                                  color: Colors.white,
                                  padding: EdgeInsets.only(left: 5, right: 5),
                                  child: DropdownButton<String>(
                                      onTap: () {
                                        return CommonMethods.hideKeyboard(
                                            context);
                                      },
                                      value: taxSchemeType,
                                      isExpanded: true,
                                      hint: Text(
                                          Language().getString(
                                              Constants.TAX_TYPE, selectedLang),
                                          style: TextStyle(
                                              fontFamily:
                                                  StyleView.FONT_TITLE)),
                                      underline: SizedBox(),
                                      onChanged: (String? data) {
                                        setState(() {
                                          taxSchemeType = data;
                                        });
                                      },
                                      items: ["VAT", "PAN", "CIN", "Other TAX"]
                                          .map((String model) {
                                        return new DropdownMenuItem<String>(
                                          child: new Text(model,
                                              style: TextStyle(
                                                  fontFamily:
                                                      StyleView.FONT_TITLE)),
                                          value: model,
                                        );
                                      }).toList())),
                            )
                          ],
                        )),
                    buildTextFormFieldsDialog(
                        Language().getString(Constants.TAX_ID, selectedLang),
                        _govtTaxschemeNumberController,
                        false),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  /// Save tax scheme details

  void onSaveTaxSchemeDetails(int index, bool isListUpdate) {
    if (isListUpdate) {
      _storeTaxSchemeData[index] = TaxSchemeData(
        govttaxscheme_name: taxSchemeType,
        govttaxscheme_number: _govtTaxschemeNumberController.text,
      );
    } else {
      _storeTaxSchemeData.add(TaxSchemeData(
        govttaxscheme_name: taxSchemeType,
        govttaxscheme_number: _govtTaxschemeNumberController.text,
      ));
    }

    setState(() {
      _storeTaxSchemeData.reversed;
    });
    AppController.instance.getOrganizationFieldsData.taxSchemeArray =
        _storeTaxSchemeData;
    Navigator.of(context).pop();
  }

  /// Dynamically create Taxscheme,Regulationfields

  buildDynamicTextView(String text, String itemName) {
    return Container(
      padding: EdgeInsets.only(left: 1, right: 1),
      child: Row(
        children: <Widget>[
          Expanded(
            flex: 1,
            child: Container(
                height: 50,
                color: Color(Constants.GREY_COLOR_LIGHT),
                child: Container(
                  padding: EdgeInsets.only(left: 10),
                  child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(text,
                          style: TextStyle(
                              fontSize: StyleView.FONT_SIZE_15,
                              fontFamily: StyleView.FONT_TITLE))),
                )),
          ),
          Expanded(
            flex: 2,
            child: Container(
                height: 50,
                color: Colors.white70,
                child: Container(
                  padding: EdgeInsets.only(left: 10),
                  child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(itemName,
                          style: TextStyle(
                              fontSize: StyleView.FONT_SIZE_15,
                              fontFamily: StyleView.FONT_TITLE))),
                )),
          ),
        ],
      ),
    );
  }

  /// Exports popup fields and update

  buildExportsFields(
      var alrtTitle,
      String? exportTextFormField1,
      String? exportTextFormField2,
      TextEditingController exportsNameController,
      TextEditingController exportsIdController,
      ExportsModel data,
      int index,
      bool isExportsUpdate) {
    if (isExportsUpdate) {
      exportsNameController.text = data.govtregistrationSchemename!;
      exportsIdController.text = data.govtregistrationSchemeid!;
    } else {
      exportsNameController.clear();
      exportsIdController.clear();
    }
    return showDialog(
        context: context,
        barrierDismissible: false,
        barrierColor: Colors.black54,
        builder: (context) {
          return AlertDialog(
            elevation: 100.0,
            contentPadding: EdgeInsets.fromLTRB(15.0, 0, 15.0, 0),
            backgroundColor: Colors.white, //(0XFFE0E0E0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(
                Radius.circular(7.0),
              ),
            ),
            titlePadding: dialogTitlePadding,
            title: Text(
              isExportsUpdate
                  ? Language()
                          .getString(Constants.UPDATE_STRING, selectedLang) +
                      " " +
                      alrtTitle
                  : alrtTitle,
              style: TextStyle(
                  fontSize: 18.0,
                  fontFamily: StyleView.FONT_TITLE,
                  color: Colors.black //(Constants.APP_COLOR),
                  ),
            ),
            actions: <Widget>[
              Container(
                padding: EdgeInsets.only(bottom: 10),
                child: CommonButtonsView(
                  context: context,
                  b1Text:
                      Language().getString(Constants.STR_CANCEL, selectedLang),
                  b2Text:
                      Language().getString(Constants.STR_SAVE, selectedLang),
                  onb1Action: () {
                    Navigator.of(context).pop();
                  },
                  onb2Action: () {
                    if (alrtTitle ==
                        Language().getString(
                            Constants.EXPORT_DETAILS, selectedLang)) {
                      // String validationText = validationExportsData();
                      // if (validationText.isNotEmpty) {
                      onSaveExportsDetails(index, isExportsUpdate);
                      // } else {
                      //   Navigator.of(context).pop();
                      // }
                    } else {
                      // String validationText = validationImportsData();
                      // if (validationText.isNotEmpty) {
                      onSaveImportsDetails(index, isExportsUpdate);
                      // } else {
                      //   Navigator.of(context).pop();
                      // }
                    }
                  },
                ),
              ),
            ],
            content: Container(
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    SizedBox(height: 20),
                    buildTextFormFieldsDialog(
                        exportTextFormField1, exportsNameController, false),
                    SizedBox(height: 10),
                    buildTextFormFieldsDialog(
                        exportTextFormField2, exportsIdController, false),
                  ],
                ),
              ),
            ),
          );
        });
  }

  /// Save imports details and update

  onSaveImportsDetails(int index, bool isImportListUpdate) {
    if (isImportListUpdate) {
      _storeImportsData[index] = ExportsModel(
          govtregistrationSchemename: _importsRegistrationNameController.text,
          govtregistrationSchemeid: _importsRegistrationIdController.text);
      setState(() {
        _storeImportsData.reversed;
      });
    } else {
      _storeImportsData.add(ExportsModel(
          govtregistrationSchemename: _importsRegistrationNameController.text,
          govtregistrationSchemeid: _importsRegistrationIdController.text));
      setState(() {
        _storeImportsData.reversed;
      });
    }
    AppController.instance.getOrganizationFieldsData.importsArray =
        _storeImportsData;
    Navigator.of(context).pop();
  }

  /// Save exports details and update

  onSaveExportsDetails(int index, bool isExportsUpdate) {
    if (isExportsUpdate) {
      _storeExportsData[index] = ExportsModel(
          govtregistrationSchemename: _exportsRegisterNameController.text,
          govtregistrationSchemeid: _exportsRegisterIdController.text);
      setState(() {
        _storeExportsData.reversed;
      });
    } else {
      _storeExportsData.add(ExportsModel(
          govtregistrationSchemename: _exportsRegisterNameController.text,
          govtregistrationSchemeid: _exportsRegisterIdController.text));
      setState(() {
        _storeExportsData.reversed;
      });
    }
    AppController.instance.getOrganizationFieldsData.exportsArray =
        _storeExportsData;
    Navigator.of(context).pop();
  }

  /// Dynamically creating text fields for all array objects

  buildText(String title, String subTitle) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(title,
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_15,
                            fontFamily: StyleView.FONT_TITLE))),
              )),
        ),
        Expanded(
          flex: 2,
          child: Container(
              color: Colors.white70,
              height: 50,
              padding: EdgeInsets.only(left: 5),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  subTitle,
                  style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                ),
              )),
        )
      ],
    );
  }

  buildCountryDropdown(String text) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(Language().getString(text, selectedLang),
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: StyleView.FONT_TITLE))),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5, right: 5),
                  child: DropdownButton<CountryDAO>(
                      onTap: () {
                        return CommonMethods.hideKeyboard(context);
                      },
                      value: countryDropdownValue,
                      isExpanded: true,
                      hint: Text(
                          Language().getString(
                              Constants.SELECT_COUNTRY, selectedLang),
                          style: TextStyle(fontFamily: StyleView.FONT_TITLE)),
                      underline: SizedBox(),
                      onChanged: (CountryDAO? data) {
                        setState(() {
                          countryDropdownValue = data;
                          serviceCallGetStates(
                              countryDropdownValue!.name, Constants.REG_CITY);
                        });
                        AppController.instance.getOrganizationFieldsData
                            .regOrgCountry = data!.name;
                      },
                      items: _countryList.map((CountryDAO model) {
                        return new DropdownMenuItem<CountryDAO>(
                          child: new Text(model.name!,
                              style:
                                  TextStyle(fontFamily: StyleView.FONT_TITLE)),
                          value: model,
                        );
                      }).toList())),
            )
          ],
        ));
  }

  /// Creating state lookup

  buildStateDropdown(String text) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(Language().getString(text, selectedLang),
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: StyleView.FONT_TITLE))),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5, right: 5),
                  child: DropdownButton<StatesDAO>(
                      onTap: () {
                        return CommonMethods.hideKeyboard(context);
                      },
                      value: statesDropdownValue,
                      isExpanded: true,
                      hint: Text(
                          Language()
                              .getString(Constants.SELECT_STATE, selectedLang),
                          style: TextStyle(fontFamily: StyleView.FONT_TITLE)),
                      underline: SizedBox(),
                      onChanged: (StatesDAO? data) {
                        setState(() {
                          statesDropdownValue = data;
                        });
                        AppController.instance.getOrganizationFieldsData
                            .regOrgState = data!.state;

                        this
                            .getCitiesList(
                                countryName: countryDropdownValue!.name,
                                stateId: statesDropdownValue!.id,
                                path: Constants.REG_CITY)
                            .then((value) {
                          if (value.length > 0) {
                            setState(() {
                              _citiesList.clear();
                              _citiesList.addAll(value[0].cities!);
                            });
                          }
                        });
                      },
                      items: _statesList.map((StatesDAO model) {
                        return new DropdownMenuItem<StatesDAO>(
                          child: new Text(model.state!,
                              style:
                                  TextStyle(fontFamily: StyleView.FONT_TITLE)),
                          value: model,
                        );
                      }).toList())),
            )
          ],
        ));
  }

  /// City Dropdown
  buildCityDropdown(String text) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(Language().getString(text, selectedLang),
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: StyleView.FONT_TITLE))),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5, right: 5),
                  child: DropdownButton<String>(
                      onTap: () {
                        return CommonMethods.hideKeyboard(context);
                      },
                      value: citiesDropDownValue,
                      isExpanded: true,
                      hint: Text(
                        Language()
                            .getString(Constants.SELECT_CITY, selectedLang),
                      ),
                      underline: SizedBox(),
                      onChanged: (String? data) {
                        setState(() {
                          citiesDropDownValue = data;
                        });

                        AppController.instance.getOrganizationFieldsData
                            .regOrgCity = data;
                      },
                      items: _citiesList.map((String model) {
                        return new DropdownMenuItem<String>(
                          child: new Text(model,
                              style:
                                  TextStyle(fontFamily: StyleView.FONT_TITLE)),
                          value: model,
                        );
                      }).toList())),
            )
          ],
        ));
  }

  /// Creating currency lookup.

  buildcurrencyDropdown(String text) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 55,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(text,
                        style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                            fontFamily: StyleView.FONT_TITLE))),
              )),
        ),
        Expanded(
          flex: 2,
          child: Row(
            children: [
              Container(
                height: 55.0,
                color: Colors.white,
                child: Center(
                  child: Text(
                    currencyDropdown != null
                        ? currencyDropdown!.htmlSymbol!
                        : "",
                  ),
                ),
              ),
              Expanded(
                child: Container(
                    height: 55.0,
                    color: Colors.white,
                    child: Padding(
                      padding: const EdgeInsets.all(5.0),
                      child: DropdownButton<CurrencyNameDAO>(
                          onTap: () {
                            return CommonMethods.hideKeyboard(context);
                          },
                          value: currencyDropdown,
                          isExpanded: true,
                          hint: Text(
                              Language().getString(
                                  Constants.SELECT_CURRENCY_CODE_STRING,
                                  selectedLang),
                              style: TextStyle(
                                  fontSize: 14,
                                  fontFamily: StyleView.FONT_TITLE)),
                          underline: SizedBox(),
                          onChanged: (CurrencyNameDAO? data) {
                            setState(() {
                              currencyDropdown = data;
                            });

                            AppController.instance.getOrganizationFieldsData
                                .invoiceCurrencyCode = currencyDropdown!.code;
                          },
                          items: _currencyList.map((CurrencyNameDAO model) {
                            return new DropdownMenuItem<CurrencyNameDAO>(
                              child: new Text(model.code!,
                                  style: TextStyle(
                                      fontSize: 14,
                                      fontFamily: StyleView.FONT_TITLE)),
                              value: model,
                            );
                          }).toList()),
                    )),
              ),
            ],
          ),
        )
      ],
    );
  }

  /// Creating number of days lookup

  buildNumberOfDaysDropdown(String text) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(Language().getString(text, selectedLang),
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: StyleView.FONT_TITLE))),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5, right: 5),
                  child: DropdownButton<String>(
                      onTap: () {
                        return CommonMethods.hideKeyboard(context);
                      },
                      value: numberofdaysDropdown,
                      isExpanded: true,
                      hint: Text(
                          Language().getString(
                              Constants.SELECT_NUMBER_OF_DAYS, selectedLang),
                          style: TextStyle(fontFamily: StyleView.FONT_TITLE)),
                      underline: SizedBox(),
                      onChanged: (String? data) {
                        setState(() {
                          numberofdaysDropdown = data;
                        });
                        AppController.instance.getOrganizationFieldsData
                            .numberOfDays = data;
                      },
                      items: Constants.NUMBEROFDAYS.map((String model) {
                        return new DropdownMenuItem<String>(
                          child: new Text(model,
                              style:
                                  TextStyle(fontFamily: StyleView.FONT_TITLE)),
                          value: model,
                        );
                      }).toList())),
            )
          ],
        ));
  }

  ///

  /// Creating legal entity lookup

  buildEntityDropdown(String text) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(Language().getString(text, selectedLang),
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: StyleView.FONT_TITLE))),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5, right: 5),
                  child: DropdownButton<BusinessRelationDAO>(
                      onTap: () {
                        return CommonMethods.hideKeyboard(context);
                      },
                      value: entityDropdown,
                      isExpanded: true,
                      hint: Text(
                          Language().getString(
                              Constants.SELECT_LEGEL_ENTITY, selectedLang),
                          style: TextStyle(fontFamily: StyleView.FONT_TITLE)),
                      underline: SizedBox(),
                      onChanged: (BusinessRelationDAO? data) {
                        setState(() {
                          entityDropdown = data;
                        });
                        AppController.instance.getOrganizationFieldsData
                            .regentityType = entityDropdown!.type;
                      },
                      items: _regEntityList.map((BusinessRelationDAO model) {
                        return new DropdownMenuItem<BusinessRelationDAO>(
                          child: new Text(model.type!,
                              style:
                                  TextStyle(fontFamily: StyleView.FONT_TITLE)),
                          value: model,
                        );
                      }).toList())),
            )
          ],
        ));
  }

  /// Save input fields data onChage()

  void updateData(String fieldName, String text) {
    switch (fieldName) {
      case Constants.BUSSINESS_INPUT_STRING:
        AppController.instance.getOrganizationFieldsData.regOrgName = text;
        break;
      case Constants.REGISTRATION_DATE_STRING:
        break;
      case Constants.REGISTRATION_CITY_STRING:
        AppController.instance.getOrganizationFieldsData.regOrgCity = text;
        break;

      case Constants.PAYMENT_PERIOD_CODE_STRING:
        AppController.instance.getOrganizationFieldsData.paymentPeriodCode =
            text;
        break;

      case Constants.INVOICE_DESCRIPTION_STRING:
        AppController.instance.getOrganizationFieldsData.invoiceDescription =
            text;
        break;

      case Constants.PENALTY_AMOUNT:
        AppController.instance.getOrganizationFieldsData.penaltyAmount = text;
        break;
      case Constants.DESCRIPTION_STRING:
        AppController.instance.getOrganizationFieldsData.description = text;
        break;
      case Constants.PENALTY_BASIC_AMOUNT_STRING:
        AppController.instance.getOrganizationFieldsData.basisAmount = text;
        break;
      case Constants.PAN:
        AppController.instance.getOrganizationFieldsData.panCardNumber = text;
        break;
      case Constants.CIN:
        AppController.instance.getOrganizationFieldsData.cinCardNumber = text;
        break;

      default:
    }
  }

  buildCommentFieldView(TextEditingController _controller) {
    return Container(
      margin: EdgeInsets.only(top: 10),
      child: TextFormField(
          controller: _controller,
          decoration: InputDecoration(
              border: OutlineInputBorder(),
              hintText: Language()
                  .getString(Constants.DESCRIPTION_STRING, selectedLang)),
          onChanged: (text) {
            AppController.instance.getOrganizationFieldsData.paymentComments =
                text;
          },
          maxLines: 7),
    );
  }

  @override
  Widget build(BuildContext context) {
    ToastContext().init(context);
    return Stack(
      children: [
        Container(
          margin: EdgeInsets.only(top: 16),
          padding: EdgeInsets.all(8.0),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(5.0),
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                    offset: Offset(0.0, 5.0),
                    blurRadius: 5.0,
                    color: Colors.grey)
              ]),
          child: SingleChildScrollView(
              padding: EdgeInsets.all(10.0),
              child: Container(
                  child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  // Container(
                  //     margin: EdgeInsets.symmetric(vertical: 5.0),
                  //     child: ClipRRect(
                  //       borderRadius: BorderRadius.circular(5.0),
                  //       child: Container(
                  //         color: Colors.white,
                  //         child: ExpansionTile(
                  //             title: Text(
                  //               Language().getString(
                  //                   Constants.REGISTRATION_HEADER_STRING,
                  //                   selectedLang),
                  //               style: TextStyle(
                  //                   color: Colors.black,
                  //                   fontWeight: FontWeight.w600),
                  //             ),
                  //             children: <Widget>[
                  //               Column(children: <Widget>[
                  //                 SizedBox(
                  //                     height: 1,
                  //                     child: Container(
                  //                         color: Color(Constants.GREY_COLOR))),
                  //                 buildTableContent(
                  //                     Constants.BUSSINESS_INPUT_STRING,
                  //                     false,
                  //                     regOrgNameController,
                  //                     "",
                  //                     false),
                  //                 SizedBox(
                  //                     height: 1,
                  //                     child: Container(
                  //                         color: Color(Constants.GREY_COLOR))),
                  //                 buildRegisterDateField(
                  //                     Constants.REGISTRATION_DATE_STRING),
                  //                 SizedBox(
                  //                     height: 1,
                  //                     child: Container(
                  //                       color: Color(Constants.GREY_COLOR),
                  //                     )),
                  //                 buildCountryDropdown(
                  //                     Constants.REGISTRATION_COUNTRY_STRING),
                  //                 SizedBox(
                  //                     height: 1,
                  //                     child: Container(
                  //                         color: Color(Constants.GREY_COLOR))),
                  //                 buildStateDropdown(
                  //                     Constants.REGISTRATION_STATE_STRING),
                  //                 SizedBox(
                  //                     height: 1,
                  //                     child: Container(
                  //                         color: Color(Constants.GREY_COLOR))),
                  //                 buildCityDropdown(
                  //                     Constants.REGISTRATION_CITY_STRING),
                  //                 SizedBox(
                  //                     height: 1,
                  //                     child: Container(
                  //                         color: Color(Constants.GREY_COLOR))),
                  //                 buildEntityDropdown(
                  //                     Constants.LEGAL_ENTITY_TYPE),
                  //               ])
                  //             ]),
                  //       ),
                  //     )),
                  // Container(
                  //   margin: EdgeInsets.symmetric(
                  //     vertical: verticalSize,
                  //   ),
                  //   child: Row(
                  //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  //     children: <Widget>[
                  //       buildTextField(Language().getString(
                  //           Constants.DIRECTORS_NAME_STRING, selectedLang)),
                  //       controllAllAddView(Constants.DIRECTORS_NAME_STRING)
                  //     ],
                  //   ),
                  // ),
                  // Container(
                  //   child: dynamicListData.length == 0
                  //       ? new Container()
                  //       : onCreateDynamicViewDirectors(),
                  // ),
                  // Container(
                  //   margin: EdgeInsets.symmetric(
                  //     vertical: verticalSize,
                  //   ),
                  //   child: Row(
                  //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  //     children: <Widget>[
                  //       buildTextField(Language().getString(
                  //           Constants.TAX_SCHEME_STRING, selectedLang)),
                  //       controllAllAddView(Constants.TAX_SCHEME_STRING)
                  //     ],
                  //   ),
                  // ),
                  // Container(
                  //   child: _storeTaxSchemeData.length == 0
                  //       ? new Container()
                  //       : createTaxSchemeDynamically(),
                  // ),
                  // if (CommonMethods.isPrivillegeExist(
                  //     context,
                  //     PrivillegesActions
                  //         .KEY_MY_COMPANY_BU_STEP_3_REGULATION_IDS))
                  //   Container(
                  //     margin: EdgeInsets.symmetric(
                  //       vertical: verticalSize,
                  //     ),
                  //     child: Row(
                  //       mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  //       children: <Widget>[
                  //         buildTextField(Language().getString(
                  //             Constants.REGULATION_ID, selectedLang)),
                  //         controllAllAddView(Constants.REGULATION_ID)
                  //       ],
                  //     ),
                  //   ),
                  // Container(
                  //     child: _storeRegulationData.length == 0
                  //         ? new Container()
                  //         : createRegulationDynamically()),
                  // if (CommonMethods.isPrivillegeExist(context,
                  //     PrivillegesActions.KEY_MY_COMPANY_BU_STEP_3_EXPORT_IDS))
                  //   Container(
                  //     margin: EdgeInsets.symmetric(vertical: verticalSize),
                  //     child: Row(
                  //       mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  //       children: <Widget>[
                  //         buildTextField(Language()
                  //             .getString(Constants.EXPORTS_ID, selectedLang)),
                  //         controllAllAddView(Constants.EXPORTS_ID),
                  //       ],
                  //     ),
                  //   ),
                  // Container(
                  //     child: _storeExportsData.length == 0
                  //         ? new Container()
                  //         : createExportsDynamically(
                  //             Language()
                  //                 .getString(Constants.EXPORTS, selectedLang),
                  //             _storeExportsData)),
                  // if (CommonMethods.isPrivillegeExist(context,
                  //     PrivillegesActions.KEY_MY_COMPANY_BU_STEP_3_IMPORT_IDS))
                  //   Container(
                  //     margin: EdgeInsets.symmetric(vertical: verticalSize),
                  //     child: Row(
                  //       mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  //       children: <Widget>[
                  //         buildTextField(Language()
                  //             .getString(Constants.IMPORTS_ID, selectedLang)),
                  //         controllAllAddView(Constants.IMPORTS_ID),
                  //       ],
                  //     ),
                  //   ),
                  // Container(
                  //     child: _storeImportsData.length == 0
                  //         ? new Container()
                  //         : createExportsDynamically(
                  //             Language()
                  //                 .getString(Constants.IMPORTS, selectedLang),
                  //             _storeImportsData)),

                  Container(
                    margin: EdgeInsets.symmetric(
                      vertical: verticalSize,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Expanded(child: buildTextField(Language()
                            .getString(Constants.BANK_DETAILS, selectedLang))),
                        controllAllAddView(Constants.BANK_DETAILS)
                      ],
                    ),
                  ),
                  Container(
                      child: dynamicListRecievesData.length == 0
                          ? new Container()
                          : createBankDetailsDynamically(
                              Constants.BANK_DETAILS, dynamicListRecievesData)),
                  SizedBox(height: 10),
                  Container(
                    margin: EdgeInsets.symmetric(
                      vertical: verticalSize,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Expanded(
                          child: buildTextField(Language()
                              .getString(Constants.UPI_DETAILS, selectedLang)),
                        ),
                        if (dynamicListRecievesData.length == 0)
                          controllAllAddView(Constants.UPI_DETAILS)
                      ],
                    ),
                  ),
                  Container(
                      child: dynamicListRecievesData.length == 0
                          ? new Container()
                          : createUPID(
                              Constants.UPI_DETAILS, dynamicListRecievesData)),
                  SizedBox(height: 10),
                  Container(
                    child: Column(
                      children: [
                        buildTextField(Language().getString(
                            Constants.PAYMENT_TERMS_STRING, selectedLang)),
                        Container(
                            margin: EdgeInsets.symmetric(vertical: 5.0),
                            decoration: BoxDecoration(
                                border: Border.all(color: Colors.black),
                                borderRadius: BorderRadius.circular(5.0)),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(5.0),
                              child: Column(
                                children: [
                                  buildcurrencyDropdown(
                                    Language().getString(
                                        Constants.INVOICE_CURRENCY_CODE_STRING,
                                        selectedLang),
                                  ),
                                  SizedBox(
                                    height: 1,
                                    child: new Container(
                                        color: Color(Constants.GREY_COLOR)),
                                  ),
                                  buildPaymentTermDropdown(
                                    Language().getString(
                                        Constants.INVOICE_PAYMENT_TERMS,
                                        selectedLang),
                                  ),
                                  SizedBox(
                                    height: 1,
                                    child: new Container(
                                        color: Color(Constants.GREY_COLOR)),
                                  ),
                                  if (penaltyAmountList.length > 0)
                                    buildPenaltyPercentageDropdown(
                                      Language().getString(
                                          Constants.PENALTY_AMOUNT,
                                          selectedLang),
                                    ),
                                ],
                              ),
                            )),

                        // buildTextField("Advance Payment"),
                        buildAdvancePaymentView(),
                        Visibility(
                            visible: isPaymentVisible,
                            child: buildYesDropdown()),
                        buildTextField(Language()
                            .getString(Constants.CUST_REMARKS, selectedLang)),
                        buildCommentFieldView(_commentController),
                        if (CommonMethods.isPrivillegeExist(
                            context,
                            PrivillegesActions
                                .KEY_MY_COMPANY_BU_STEP_2_TERMS_CONDITIONS))
                          Column(
                            children: [
                              Container(
                                  padding: EdgeInsets.only(top: 24),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      buildTextField(Language().getString(
                                          Constants.TERMS_CONDITIONS,
                                          selectedLang)),
                                      SizedBox(
                                          height: 25.0,
                                          width: 25.0,
                                          child: FloatingActionButton(
                                            onPressed: () async {
                                              if (kIsWeb) {
                                                PlatformFile? selectedFile;
                                                selectedFile =
                                                    await CommonMethods()
                                                        .getFileUpload(context,
                                                            isForMultiFile:
                                                                true);
                                                if (selectedFile != null) {
                                                  Uint8List bytes =
                                                      selectedFile.bytes!;
                                                  setState(() {
                                                    isSelectCaptureChoice =
                                                        true;
                                                  });
                                                  uploadImage(bytes,
                                                      "${AppController.instance.currentOrgName}_terms&conditions_${selectedFile.name}",
                                                      fileType: selectedFile
                                                                  .extension ==
                                                              'pdf'
                                                          ? 'application/pdf'
                                                          : 'image/${selectedFile.extension}');
                                                }
                                              } else {
                                                //
                                                openBottomSheet(context,
                                                    pdfRead: true);
                                              }
                                            },
                                            child: Icon(Icons.add, size: 18),
                                            backgroundColor:
                                                Color(Constants.APP_COLOR),
                                          ))
                                    ],
                                  )),
                              Container(child: displayImageView()),
                            ],
                          ),
                        // this.acceptInpersongOrderFunctionality()
                      ],
                    ),
                  ),
                ],
              ))),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    );
  }

  displayImageView() {
    if (imageRelativePath.isNotEmpty) {
      List<String?> path = imageRelativePath.split('/');
      return DisplayAttachedFile(
          imageRelativePath: '${Constants.IAMGE_BUCKET_URL}$imageRelativePath',
          fileType: lookupMimeType(imageRelativePath)!,
          fileName: path[1].toString(),
          onPress: () {
            if (kIsWeb) {
              AppUtills.launchURL(
                  '${Constants.IAMGE_BUCKET_URL}$imageRelativePath');
            } else {
              if (lookupMimeType(imageRelativePath) == 'application/pdf') {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => WebViewPage(
                            url:
                                '${Constants.IAMGE_BUCKET_URL}$imageRelativePath',
                            screenName: "",
                            loadS3PDF: true)));
              } else {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => ImageHeroView(
                              fileUrl:
                                  '${Constants.IAMGE_BUCKET_URL}$imageRelativePath',
                              tagName: "bu_terms_conditions",
                            )));
              }
            }
          },
          onRemove: () {
            setState(() => isLoadingProgress = true);
            Future.delayed(Duration(seconds: 1));
            setState(() {
              isLoadingProgress = false;
              imageRelativePath = "";
            });
          });
    } else {
      return SizedBox();
    }
  }

  openBottomSheet(BuildContext context, {bool pdfRead = false}) {
    return Dialogs.openBottomSheet(
        pdfRead: pdfRead,
        context: context,
        openCamera: (myPicture) async {
          this.updateProductImage(myPicture);
        },
        openGallery: (myPicture) async {
          this.updateProductImage(myPicture);
        });
  }

  updateProductImage(var fileImage) {
    Navigator.of(context).pop();
    if (fileImage != null) {
      setState(() {
        isSelectCaptureChoice = true;
        imageFile = fileImage;
        imageBlob = AppUtills.getBase64Image(fileImage, context);
      });
      List<String> fileName = imageFile!.path.split('/');
      uploadImage(imageFile,
          "${AppController.instance.getCurrentOrgName}_terms&conditions_${fileName.last}",
          fileType: lookupMimeType(imageFile!.path)!);
    }
  }

  uploadImage(dynamic imageData, String fileName,
      {String fileType = ''}) async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = "Fetching..";
    });
    Map data = {"filename": fileName, "location": "terms"};
    String body = json.encode(data);

    http.Response response = await _service
        .getPresignedUrl(body); //_service.get_file_upload_url(null);

    if (response.statusCode == 200) {
      var responseBody = json.decode(response.body);
      setState(() {
        progressMessage = "Uploading image..";
      });
      print('relative path ${responseBody['relativepath']}');

      var uploadFileRes = await _service
          .uploadToS3Signed(responseBody['url'], imageData, fileType: fileType);
      print(uploadFileRes);
      setState(() {
        imageRelativePath = responseBody['relativepath'];
        _termsList.add(TermsData(
            imageRelativePath: imageRelativePath,
            termDescription: "",
            termType: ""));
        isLoadingProgress = false;
      });
      Toast.show(
        Constants.FILE_UPLAODED,
        duration: Toast.lengthShort,
        gravity: Toast.bottom,
      );

      // this.submitInputData(relativePath: responseBody['relativepath']);
    } else {
      setState(() {
        isLoadingProgress = false;
      });
    }
  }

  /// Dynamically creating tax scheme details

  createTaxSchemeDynamically() {
    return Column(children: <Widget>[
      for (int i = 0; i < _storeTaxSchemeData.length; i++)
        Column(
          children: <Widget>[
            ClipRRect(
              borderRadius: BorderRadius.circular(5.0),
              child: Container(
                color: Colors.white,
                child: ExpansionTile(
                  title: Row(
                    children: [
                      Expanded(
                        child: buildRichText(
                            _storeTaxSchemeData[i].govttaxscheme_name),
                      ),
                      Container(
                        alignment: Alignment.centerRight,
                        margin: EdgeInsets.only(
                          left: 5.0,
                        ),
                        child: IconButton(
                          icon: Icon(Icons.edit, color: Colors.black),
                          onPressed: () {
                            buildTaxSchemeData(_storeTaxSchemeData[i], i, true);
                          },
                        ),
                      ),
                    ],
                  ),
                  children: <Widget>[
                    Column(
                      children: <Widget>[
                        SizedBox(
                            height: 1,
                            child: new Container(
                                color: Color(Constants.GREY_COLOR))),
                        TextView(
                            title: Language().getString(
                                Constants.TAX_SCHEME_STRING, selectedLang),
                            value: _storeTaxSchemeData[i].govttaxscheme_name),
                        // SizedBox(
                        //     height: 1,
                        //     child:
                        //         Container(color: Color(Constants.GREY_COLOR))),
                        TextView(
                            title: Language().getString(
                                Constants.GOVT_TAX_NUMBER_STRING, selectedLang),
                            value: _storeTaxSchemeData[i].govttaxscheme_number),
                      ],
                    )
                  ],
                ),
              ),
            ),
            SizedBox(height: 10)
          ],
        )
    ]);
  }

  /// Dynamically creating regulation details

  createRegulationDynamically() {
    return Column(
      children: <Widget>[
        for (int i = 0; i < _storeRegulationData.length; i++)
          Column(
            children: <Widget>[
              ClipRRect(
                borderRadius: BorderRadius.circular(5.0),
                child: Container(
                  color: Colors.white,
                  child: ExpansionTile(
                    title: Row(
                      children: [
                        Expanded(
                          child: buildRichText(
                              _storeRegulationData[i].govtbusinessSchemeid),
                        ),
                        Container(
                          alignment: Alignment.centerRight,
                          child: IconButton(
                            icon: Icon(Icons.edit, color: Colors.black),
                            onPressed: () {
                              onAddNewRegulationDetails(
                                  _storeRegulationData[i], i, true);
                            },
                          ),
                        ),
                      ],
                    ),
                    children: <Widget>[
                      Column(
                        children: <Widget>[
                          SizedBox(
                              height: 1,
                              child: new Container(
                                  color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language().getString(
                                  Constants.BUSINESS_SCHEME_NAME, selectedLang),
                              value:
                                  _storeRegulationData[i].govtbusinessSchemeid),
                          // SizedBox(
                          //     height: 1,
                          //     child: Container(
                          //         color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language().getString(
                                  Constants.GOVT_BUSSINESS_SCHEME_ID,
                                  selectedLang),
                              value:
                                  _storeRegulationData[i].govtregistrationId),
                        ],
                      )
                    ],
                  ),
                ),
              ),
              SizedBox(height: 10)
            ],
          )
      ],
    );
  }

  /// Dynamically creating exports and impports details

  createExportsDynamically(
      String? _title, List<ExportsModel> storeExportsData) {
    return Column(
      children: <Widget>[
        for (int i = 0; i < storeExportsData.length; i++)
          Column(
            children: <Widget>[
              ClipRRect(
                borderRadius: BorderRadius.circular(5.0),
                child: Container(
                  color: Colors.white,
                  child: ExpansionTile(
                    title: Row(
                      children: [
                        Expanded(
                          child: buildRichText(
                              storeExportsData[i].govtregistrationSchemename),
                        ),
                        Container(
                          alignment: Alignment.centerRight,
                          child: IconButton(
                            icon: Icon(Icons.edit,
                                color: Colors.black //(Constants.APP_COLOR),
                                ),
                            onPressed: () {
                              if (_title ==
                                  Language().getString(
                                      Constants.IMPORTS, selectedLang)) {
                                buildExportsFields(
                                    Language().getString(
                                        Constants.IMPORT_DETAILS, selectedLang),
                                    Language().getString(
                                        Constants.REGISTRATION_NAME,
                                        selectedLang),
                                    Language().getString(
                                        Constants.REGISTRATION_ID,
                                        selectedLang),
                                    _importsRegistrationNameController,
                                    _importsRegistrationIdController,
                                    storeExportsData[i],
                                    i,
                                    true);
                              } else {
                                buildExportsFields(
                                    Language().getString(
                                        Constants.EXPORT_DETAILS, selectedLang),
                                    Language().getString(
                                        Constants.REGISTRATION_NAME,
                                        selectedLang),
                                    Language().getString(
                                        Constants.REGISTRATION_ID,
                                        selectedLang),
                                    _exportsRegisterNameController,
                                    _exportsRegisterIdController,
                                    storeExportsData[i],
                                    i,
                                    true);
                              }
                            },
                          ),
                        ),
                      ],
                    ),
                    children: <Widget>[
                      Container(
                          child: Column(
                        children: <Widget>[
                          SizedBox(
                              height: 1,
                              child: new Container(
                                  color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language().getString(
                                  Constants.REGISTRATION_NAME, selectedLang),
                              value: storeExportsData[i]
                                  .govtregistrationSchemename),
                          // SizedBox(
                          //     height: 1,
                          //     child:
                          //         Container(color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language().getString(
                                  Constants.REGISTRATION_ID, selectedLang),
                              value:
                                  storeExportsData[i].govtregistrationSchemeid)
                        ],
                      ))
                    ],
                  ),
                ),
              ),
              SizedBox(height: 10)
            ],
          )
      ],
    );
  }

  /// Dynamically creating taxInfo details

  createTaxInfoDynamically(String text, List<TaxInfoModel> _taxList) {
    return Column(
      children: <Widget>[
        for (int i = 0; i < _taxList.length; i++)
          Column(
            children: <Widget>[
              Container(
                  decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey),
                      borderRadius: BorderRadius.circular(5)),
                  child: ExpansionTile(
                    title: Text(
                      ": ${i + 1}",
                      style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                    ),
                    children: <Widget>[
                      Container(
                          child: Column(
                        children: <Widget>[
                          buildText(
                              Language().getString(
                                  Constants.NAME_STRING, selectedLang),
                              _taxList[i].taxName!),
                          SizedBox(
                              height: 1,
                              child: Container(
                                  color: Color(Constants.GREY_COLOR))),
                          buildText(
                              Language()
                                  .getString(Constants.ADDRESS, selectedLang),
                              _taxList[i].taxReason!),
                        ],
                      ))
                    ],
                  )),
              SizedBox(height: 10)
            ],
          )
      ],
    );
  }

  /// Dynamically creating bank details

  createBankDetailsDynamically(
      String _title, List<BankDetails> _bankDetailsList) {
    return Column(
      children: <Widget>[
        for (int i = 0; i < _bankDetailsList.length; i++)
          Column(
            children: <Widget>[
              ClipRRect(
                borderRadius: BorderRadius.circular(5.0),
                child: Container(
                  decoration: BoxDecoration(
                      border: Border.all(color: Colors.black),
                      borderRadius: BorderRadius.circular(5.0)),
                  child: ExpansionTile(
                    title: Row(
                      children: [
                        Expanded(
                          child: buildRichText(
                              _bankDetailsList[i].bankname!.isEmpty
                                  ? "Bank Name"
                                  : _bankDetailsList[i].bankname!),
                        ),
                        Container(
                          alignment: Alignment.centerRight,
                          child: IconButton(
                            icon: Icon(Icons.edit, color: Colors.black),
                            onPressed: () {
                              onAddReceivePayments(
                                  _bankDetailsList[i], i, true);
                            },
                          ),
                        ),
                      ],
                    ),
                    children: <Widget>[
                      Column(
                        children: <Widget>[
                          SizedBox(
                              height: 1,
                              child: new Container(
                                  color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language()
                                  .getString(Constants.BANK_NAME, selectedLang),
                              value: _bankDetailsList[i].bankname),
                          // SizedBox(
                          //     height: 1,
                          //     child: new Container(
                          //         color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language().getString(
                                  Constants.BANK_ACCOUNT_NAME, selectedLang),
                              value: _bankDetailsList[i].bankaccountname),
                          // SizedBox(
                          //     height: 1,
                          //     child: new Container(
                          //         color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language().getString(
                                  Constants.BANK_ACCOUNT_NUMBER, selectedLang),
                              value: _bankDetailsList[i].bankAccountNumber),
                          // SizedBox(
                          //     height: 1,
                          //     child: new Container(
                          //         color: Color(Constants.GREY_COLOR))),
                          // TextView(
                          //     title: Language()
                          //         .getString(Constants.EPAY, selectedLang),
                          //     value: _bankDetailsList[i].epayCode),
                          // SizedBox(
                          //     height: 1,
                          //     child: new Container(
                          //         color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language().getString(
                                  Constants.SWIFT_CODE, selectedLang),
                              value: _bankDetailsList[i].swiftCode),
                          // SizedBox(
                          //     height: 1,
                          //     child: new Container(
                          //         color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language()
                                  .getString(Constants.MICR_CODE, selectedLang),
                              value: _bankDetailsList[i].micrCode),
                          // SizedBox(
                          //     height: 1,
                          //     child: new Container(
                          //         color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language()
                                  .getString(Constants.IFSC_CODE, selectedLang),
                              value: _bankDetailsList[i].ifscCode),
                          // SizedBox(
                          //     height: 1,
                          //     child: new Container(
                          //         color: Color(Constants.GREY_COLOR))),
                          if (CommonMethods.isPrivillegeExist(
                              context,
                              PrivillegesActions
                                  .KEY_MY_COMPANY_BU_STEP_2_BANK_DETAILS_ON_INVOICE))
                            TextView(
                                title: Language().getString(
                                    Constants.SHOW_BANK_DETAILS_IN_INVOICE,
                                    selectedLang),
                                value: _bankDetailsList[i].isShowInvoiceView!
                                    ? Constants.YES_STRING
                                    : Constants.NO_STRING)
                        ],
                      )
                    ],
                  ),
                ),
              ),
              SizedBox(height: 10)
            ],
          )
      ],
    );
  }

  createUPID(String _title, List<BankDetails> _bankDetailsList) {
    return Column(
      children: <Widget>[
        // for (int i = 0; i < _bankDetailsList.length; i++)
        Column(
          children: <Widget>[
            ClipRRect(
              borderRadius: BorderRadius.circular(5.0),
              child: Container(
                decoration: BoxDecoration(
                    border: Border.all(color: Colors.black),
                    borderRadius: BorderRadius.circular(5.0)),
                child: ExpansionTile(
                  title: Row(
                    children: [
                      Expanded(
                        child: buildRichText(_bankDetailsList[0].epayCode),
                      ),
                      Container(
                        alignment: Alignment.centerRight,
                        child: IconButton(
                          icon: Icon(Icons.edit, color: Colors.black),
                          onPressed: () {
                            onAddUPID(_bankDetailsList[0], 0, true);
                          },
                        ),
                      ),
                    ],
                  ),
                  children: <Widget>[
                    Column(
                      children: <Widget>[
                        SizedBox(
                            height: 1,
                            child: new Container(
                                color: Color(Constants.GREY_COLOR))),
                        TextView(
                            title: Language()
                                .getString(Constants.EPAY, selectedLang),
                            value: _bankDetailsList[0].epayCode),
                      ],
                    )
                  ],
                ),
              ),
            ),
            SizedBox(height: 10)
          ],
        )
      ],
    );
  }

  String validateTaxSchemeData() {
    if (taxSchemeType != null ||
        _govtTaxschemeNumberController.text.isNotEmpty) {
      return Constants.CONTAIN_DATA;
    } else {
      return "";
    }
  }

  buildRichText(String? value) {
    return RichText(
        text: TextSpan(
          children: [
            TextSpan(
              text: value,
              style: TextStyle(
                color: Colors.black,
                fontSize: 14.0,
                fontFamily: StyleView.FONT_TITLE,
              ),
            )
          ],
        ),
        overflow: TextOverflow.ellipsis,
        softWrap: false);
  }

  String validateRegulationData() {
    if (_businessIdController.text.isNotEmpty ||
        _registerIdController.text.isNotEmpty) {
      return Constants.CONTAIN_DATA;
    } else {
      return "";
    }
  }

  String validationImportsData() {
    if (_importsRegistrationIdController.text.isNotEmpty ||
        _importsRegistrationNameController.text.isNotEmpty) {
      return Constants.CONTAIN_DATA;
    } else {
      return "";
    }
  }

  String validationExportsData() {
    if (_exportsRegisterIdController.text.isNotEmpty ||
        _exportsRegisterNameController.text.isNotEmpty) {
      return Constants.CONTAIN_DATA;
    } else {
      return "";
    }
  }

  buildPaymentTermDropdown(String text) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 55,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(text,
                        style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                            fontFamily: StyleView.FONT_TITLE))),
              )),
        ),
        Expanded(
          flex: 2,
          child: Container(
              constraints: BoxConstraints(
                  maxWidth: MediaQuery.of(context).size.width - 52),
              color: Colors.white,
              padding: EdgeInsets.only(left: 5, right: 5),
              child: DropdownButton<PaymentTermsDAO>(
                  onTap: () {
                    return CommonMethods.hideKeyboard(context);
                  },
                  value: paymentTermDropdown,
                  isExpanded: true,
                  hint: Text(
                      Language().getString(
                          Constants.SELECT_PAYMNET_TERMS, selectedLang),
                      style: TextStyle(
                          fontFamily: StyleView.FONT_TITLE, fontSize: 14)),
                  underline: SizedBox(),
                  onChanged: (PaymentTermsDAO? data) {
                    setState(() {
                      paymentTermDropdown = data;
                    });

                    AppController.instance.organizationFieldsData!
                            .invoicePaymentTerms =
                        paymentTermDropdown!.paymentTerm ==
                                "Select Payment Term"
                            ? ""
                            : paymentTermDropdown!.paymentTerm;
                    AppController.instance.organizationFieldsData!
                        .paymentTermCode = paymentTermDropdown!.termCode;
                    AppController.instance.organizationFieldsData!
                        .paymentTermDays = paymentTermDropdown!.days;
                  },
                  items: paymentTermsList.map((PaymentTermsDAO model) {
                    return new DropdownMenuItem<PaymentTermsDAO>(
                      child: Container(
                        constraints: BoxConstraints(
                            maxWidth: MediaQuery.of(context).size.width - 52),
                        child: Text(
                          model.paymentTerm!,
                          style: TextStyle(
                              fontFamily: StyleView.FONT_TITLE, fontSize: 14),
                        ),
                      ),
                      value: model,
                    );
                  }).toList())),
        )
      ],
    );
  }

  buildPenaltyPercentageDropdown(String title) {
    return Row(children: <Widget>[
      Expanded(
        child: Container(
            height: 50,
            color: Color(Constants.GREY_COLOR_LIGHT),
            child: Container(
              padding: EdgeInsets.only(left: 10),
              child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    title,
                    style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                        fontFamily: StyleView.FONT_TITLE,
                        color: Colors.black),
                  )),
            )),
      ),
      Expanded(
          flex: 1,
          child: Container(
              height: 50,
              color: Colors.white,
              margin: EdgeInsets.only(
                right: 2.0,
              ),
              padding: EdgeInsets.only(left: 3),
              child: DropdownButton<PenaltyAmountDAO>(
                  onTap: () {
                    return CommonMethods.hideKeyboard(context);
                  },
                  value: penaltyAmountDropdown,
                  hint: new Text(
                    Language().getString(Constants.REASON, selectedLang),
                    style: TextStyle(
                      fontSize: 14,
                      fontFamily: StyleView.FONT_TITLE,
                    ),
                  ),
                  isExpanded: true,
                  underline: SizedBox(),
                  onChanged: (PenaltyAmountDAO? data) {
                    setState(() {
                      penaltyAmountDropdown = data;
                    });

                    AppController.instance.getOrganizationFieldsData
                        .penaltyAmountReason = penaltyAmountDropdown!.reason;
                    AppController.instance.organizationFieldsData!.penaltyCode =
                        penaltyAmountDropdown!.code;
                  },
                  items: penaltyAmountList.map((PenaltyAmountDAO model) {
                    return new DropdownMenuItem<PenaltyAmountDAO>(
                      child: new Text(
                        model.reason!,
                        style: TextStyle(
                            fontFamily: StyleView.FONT_TITLE, fontSize: 14),
                      ),
                      value: model,
                    );
                  }).toList()))),
      Expanded(
          flex: 1,
          child: Container(
              height: 50,
              color: Colors.white,
              margin: EdgeInsets.only(
                left: 1.0,
              ),
              padding: EdgeInsets.only(left: 3),
              child: DropdownButton<String>(
                  onTap: () {
                    return CommonMethods.hideKeyboard(context);
                  },
                  value: penaltyAmountPercentage,
                  hint: new Text(
                    "%",
                    style: TextStyle(
                      fontSize: 14,
                      fontFamily: StyleView.FONT_TITLE,
                    ),
                  ),
                  isExpanded: true,
                  underline: SizedBox(),
                  onChanged: (String? data) {
                    setState(() {
                      penaltyAmountPercentage = data;
                    });

                    AppController.instance.getOrganizationFieldsData
                        .penaltyAmountPercentage = penaltyAmountPercentage;
                  },
                  items: Constants.PERCENTAGELIST.map((String model) {
                    return new DropdownMenuItem<String>(
                      child: new Text(
                        model,
                        style: TextStyle(
                            fontFamily: StyleView.FONT_TITLE, fontSize: 14),
                      ),
                      value: model,
                    );
                  }).toList()))),
    ]);
  }

  buildAdvancePaymentView() {
    return Container(
      child: Row(
        children: [
          buildTextField(
              Language().getString(Constants.ADVANCE_PAYMENT, selectedLang)),
          Radio(
            value: Constants.YES_STRING,
            groupValue: _radioValue,
            onChanged: radioButtonChanges,
          ),
          Text(Language().getString(Constants.YES_STRING, selectedLang)),
          Radio(
            value: Constants.NO_STRING,
            groupValue: _radioValue,
            onChanged: radioButtonChanges,
          ),
          Text(
            Language().getString(Constants.NO_STRING, selectedLang),
          ),
        ],
      ),
    );
  }

  void radioButtonChanges(String? value) {
    setState(() {
      _radioValue = value;
      switch (value) {
        case Constants.YES_STRING:
          choice = value;
          isPaymentVisible = true;
          AppController.instance.getOrganizationFieldsData.advancePaymentValue =
              value;
          break;
        case Constants.NO_STRING:
          choice = value;
          isPaymentVisible = false;
          advancePaymentYesValue = null;
          AppController.instance.getOrganizationFieldsData.advancePaymentValue =
              value;

          break;
      }
    });
  }

  buildYesDropdown() {
    return Container(
        decoration: BoxDecoration(
          border: Border.all(
            color: Colors.grey,
          ),
          borderRadius: BorderRadius.circular(
            5.0,
          ),
          color: Colors.white70,
        ),
        padding: EdgeInsets.only(left: 5, right: 5),
        child: DropdownButton<String>(
            onTap: () {
              return CommonMethods.hideKeyboard(context);
            },
            value: advancePaymentYesValue,
            isExpanded: true,
            hint: Text(
                Language().getString(Constants.SELECT_PERCENTAGE, selectedLang),
                style: TextStyle(fontFamily: StyleView.FONT_TITLE)),
            underline: SizedBox(),
            onChanged: (String? data) {
              setState(() {
                advancePaymentYesValue = data;
              });
              AppController.instance.getOrganizationFieldsData
                  .advancePaymentPercentage = advancePaymentYesValue;
            },
            items: Constants.PERCENTAGELIST.map((String model) {
              return new DropdownMenuItem<String>(
                child: new Text(model,
                    style: TextStyle(fontFamily: StyleView.FONT_TITLE)),
                value: model,
              );
            }).toList()));
  }

  showInfoDialog(int index) {
    return showDialog(
        barrierDismissible: false,
        context: context,
        builder: (context) => AlertDialog(
              title: Text(
                Constants.INFO_MESSAGE,
                style: TextStyle(color: Color(Constants.APP_COLOR)),
              ),
              content: Container(
                child: Text(
                  Constants.ARE_YOU_SURE_DO_YOU_WANT_REMOVE,
                  style: TextStyle(
                    color: Color(Constants.APP_COLOR),
                  ),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    setState(() {
                      _addTermsFields.removeAt(index);
                    });
                  },
                  child: Text(
                    Constants.YES_STRING,
                    style: TextStyle(color: Color(Constants.APP_COLOR)),
                  ),
                ),
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: Text(
                    Constants.NO_STRING,
                    style: TextStyle(color: Color(Constants.APP_COLOR)),
                  ),
                ),
              ],
            ));
  }

  /// Creating directors ui

  addNewDirector() {
    return SizedBox(
        height: 25.0,
        width: 25.0,
        child: InkWell(
            onTap: () {
              buildDirectorFieldsTable(DirectorsData(), -1, false);
            },
            child: Container(
              margin: EdgeInsets.only(right: 5),
              decoration: BoxDecoration(shape: BoxShape.circle, boxShadow: [
                BoxShadow(
                  color: Colors.grey,
                  blurRadius: 5.0,
                ),
              ]),
              child: ClipOval(
                child: Material(
                  color: Color(Constants.APP_COLOR),
                  child: SizedBox(
                      width: 25.0,
                      height: 25.0,
                      child: Icon(Icons.add, size: 13.0, color: Colors.white)),
                ),
              ),
            )
            //   Icon(
            //     Icons.add,
            //     size: 15,
            //   ),
            //   backgroundColor: Color(0xFF083e64),
            ));
  }

  openDigialSignature() {
    return showDialog(
        context: context,
        builder: (context) => AlertDialog(
              content: Container(
                child: Signature(
                  controller: signatureController,
                  width: 300,
                  height: 300,
                  backgroundColor: Colors.lightBlueAccent,
                ),
              ),
            ));
  }

  /// Creating direcctors popup Ui
  buildDirectorFieldsTable(DirectorsData data, int index, bool isListUpdate) {
    if (isListUpdate) {
      _personNameController.text = data.personName!;
      dinDropdownValue = data.personSchemeName;
      _personIdentificationNumberController.text =
          data.personIdentificationNumber!;
      // _digitalSignatureController.text = data.personDigitalSign!;
      digitalSig = data.digitalSignature != null
          ? data.digitalSignature!
              .replaceFirst(RegExp(r'data:image/[^;]+;base64,'), '')
          : "";
    } else {
      _personNameController.clear();
      _personIdentificationNumberController.clear();

      dinDropdownValue = null;
      _digitalSignatureController.clear();
      _image = null;
      digitalSig = "";
    }

    return showDialog(
        barrierDismissible: false,
        context: context,
        barrierColor: Colors.black54,
        builder: (BuildContext context) {
          return AlertDialog(
              elevation: 100.0,
              contentPadding: EdgeInsets.fromLTRB(15.0, 0, 15.0, 0),
              backgroundColor: Colors.white, //(0XFFE0E0E0),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(
                  Radius.circular(
                    7.0,
                  ),
                ),
              ),
              title: Text(
                Language().getString(Constants.ADD_DIRECTOR, selectedLang),
                style: TextStyle(
                    fontSize: StyleView.FONT_SIZE_18,
                    fontFamily: StyleView.FONT_TITLE),
              ),
              actions: <Widget>[
                Container(
                  padding: EdgeInsets.only(bottom: 10),
                  child: CommonButtonsView(
                    context: context,
                    b1Text: Language()
                        .getString(Constants.STR_CANCEL, selectedLang),
                    b2Text:
                        Language().getString(Constants.STR_SAVE, selectedLang),
                    onb1Action: () {
                      Navigator.of(context).pop();
                    },
                    onb2Action: () {
                      onSaveDirectorDetails(isListUpdate, index);
                      // }
                    },
                  ),
                )
              ],
              content: StatefulBuilder(
                builder: (BuildContext context, StateSetter setState) =>
                    Container(
                  // height: 300.0,
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        SizedBox(height: 20),
                        buildTextFormFieldsDialog(
                            Language().getString(
                                Constants.DIRECTORS_NAME_STRING, selectedLang),
                            _personNameController,
                            false),
                        SizedBox(height: 10),
                        Container(
                          padding: EdgeInsets.all(1),
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey),
                            borderRadius: BorderRadius.circular(
                              5.0,
                            ),
                          ),
                          child: Container(
                              color: Colors.white,
                              padding: EdgeInsets.only(left: 5, right: 5),
                              child: DropdownButton<String>(
                                  onTap: () {
                                    return CommonMethods.hideKeyboard(context);
                                  },
                                  value: dinDropdownValue,
                                  isExpanded: true,
                                  hint: Text(
                                      Language().getString(
                                          Constants.SELECT_ID, selectedLang),
                                      style: TextStyle(
                                          fontFamily: StyleView.FONT_TITLE)),
                                  underline: SizedBox(),
                                  onChanged: (String? data) {
                                    setState(
                                      () {
                                        dinDropdownValue = data;
                                      },
                                    );
                                  },
                                  items: DINDROPDOWNITEMS.map((String model) {
                                    return new DropdownMenuItem<String>(
                                      child: new Text(model,
                                          style: TextStyle(
                                              fontFamily:
                                                  StyleView.FONT_TITLE)),
                                      value: model,
                                    );
                                  }).toList())),
                        ),
                        SizedBox(height: 10),
                        buildTextFormFieldsDialog(
                            Language()
                                .getString(Constants.NUMBER, selectedLang),
                            _personIdentificationNumberController,
                            false),
                        if (CommonMethods.isPrivillegeExist(
                            context,
                            PrivillegesActions
                                .KEY_MY_COMPANY_BU_STEP_3_DIRECTORS_POPUP_DIGITAL_SIGNITURE))
                          Container(
                            child: Row(
                              children: [
                                Container(
                                  child: Text(
                                    Language().getString(
                                        Constants.DIGITAL_SIGNATURE,
                                        selectedLang),
                                    style: TextStyle(
                                      fontFamily: StyleView.FONT_TITLE,
                                    ),
                                  ),
                                ),
                                Container(
                                    child: IconButton(
                                        icon: Icon(Icons.attach_file),
                                        onPressed: () async {
                                          // openDigialSignature();
                                          // var image = await ImagePicker.pickImage(
                                          //     source: ImageSource.gallery);
                                          // setState(() {
                                          //   _image = image;
                                          //   if (_image != null) {
                                          //     /// Converting image into bytes
                                          //     List<int> imageBytes =
                                          //         _image.readAsBytesSync();

                                          //     /// Converting bytes image into blob
                                          //     var imageValue =
                                          //         base64Encode(imageBytes);

                                          //     /// Storing blob image into string
                                          //     digitalSig = imageValue.replaceFirst(
                                          //         RegExp(
                                          //             r'data:image/[^;]+;base64,'),
                                          //         '');
                                          //   }
                                          // });
                                        })),
                              ],
                            ),
                          ),
                        Container(
                          child: Center(
                            child: _image == null
                                ? Container()
                                : new Image.memory(
                                    base64.decode(digitalSig),
                                    height: 60.0,
                                    width: 60.0,
                                    gaplessPlayback: true,
                                  ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ));
        });
  }

  /// Dynamically fecthing directors data

  Widget onCreateDynamicViewDirectors() {
    return Column(children: <Widget>[
      for (int i = 0; i < dynamicListData.length; i++)
        Column(
          children: <Widget>[
            ClipRRect(
              borderRadius: BorderRadius.circular(5.0),
              child: Container(
                color: Colors.white,
                child: ExpansionTile(
                  title: Row(
                    children: [
                      Expanded(
                        child: buildRichText(dynamicListData[i].personName),
                      ),
                      Container(
                        alignment: Alignment.centerRight,
                        margin: EdgeInsets.only(
                          left: 5.0,
                        ),
                        child: IconButton(
                          icon: Icon(Icons.edit, color: Colors.black),
                          onPressed: () {
                            buildDirectorFieldsTable(
                                dynamicListData[i], i, true);
                          },
                        ),
                      ),
                    ],
                  ),
                  children: <Widget>[
                    _buildDirectorListItems(dynamicListData[i], i),
                  ],
                ),
              ),
            ),
            SizedBox(
              height: 10,
            )
          ],
        )
    ]);
  }

  _buildDirectorListItems(DirectorsData director, int index) {
    return Container(
        child: Container(
            padding: EdgeInsets.all(1),
            child: Column(
              children: <Widget>[
                SizedBox(
                    height: 1,
                    child: new Container(color: Color(Constants.GREY_COLOR))),

                TextView(
                    title: Language()
                        .getString(Constants.NAME_STRING, selectedLang),
                    value: director.personName),
                // SizedBox(
                //     height: 1,
                //     child: new Container(color: Color(Constants.GREY_COLOR))),
                TextView(
                    title: Language().getString(
                        Constants.IDENTIFICATION_SCHEME_STRING, selectedLang),
                    value: director.personSchemeName),
                // SizedBox(
                //     height: 1,
                //     child: new Container(color: Color(Constants.GREY_COLOR))),
                TextView(
                    title: Language().getString(
                        Constants.IDENTIFICATION_NUMBER_STRING, selectedLang),
                    value: director.personIdentificationNumber),

                /// Digital signature
                (director.digitalSignature != null &&
                        director.digitalSignature!.isNotEmpty)
                    ? Container(
                        child: Column(
                          children: [
                            SizedBox(
                                height: 1,
                                child: new Container(
                                    color: Color(Constants.GREY_COLOR))),
                            Container(
                              alignment: Alignment.centerLeft,
                              margin: EdgeInsets.symmetric(
                                vertical: 5.0,
                                horizontal: 5.0,
                              ),
                              child: Text(
                                Language().getString(
                                    Constants.DIGITAL_SIGNATURE, selectedLang),
                                style: TextStyle(
                                  fontSize: 15.0,
                                ),
                              ),
                            ),
                            Container(
                                margin: EdgeInsets.symmetric(
                                  vertical: 5.0,
                                ),
                                child: Image.memory(
                                  base64.decode(
                                    director.digitalSignature!.replaceFirst(
                                        RegExp(r'data:image/[^;]+;base64,'),
                                        ''),
                                  ),
                                  height: 100.0,
                                  width: 100.0,
                                )),
                          ],
                        ),
                      )
                    : new Container(),
              ],
            )));
  }

  /// Save directors data

  onSaveDirectorDetails(bool isListUpdate, int index) {
    if (_image != null) {
      List<int> imageBytes = _image!.readAsBytesSync();
      digitalSig = 'data:image/jpeg;base64,' + base64Encode(imageBytes);
    }

    if (isListUpdate) {
      dynamicListData[index] = DirectorsData(
          personName: _personNameController.text,
          personSchemeName: dinDropdownValue != null ? dinDropdownValue : "",
          personIdentificationNumber:
              _personIdentificationNumberController.text,
          personDigitalSign: _digitalSignatureController.text,
          digitalSignature: digitalSig);
      setState(() {
        dynamicListData.reversed;
        AppController.instance.organizationFieldsData!.directorsData =
            dynamicListData;
      });
    } else {
      dynamicListData.add(DirectorsData(
          personName: _personNameController.text,
          personSchemeName: dinDropdownValue != null ? dinDropdownValue : "",
          personIdentificationNumber:
              _personIdentificationNumberController.text,
          personDigitalSign: _digitalSignatureController.text,
          digitalSignature: digitalSig));
      setState(() {
        dynamicListData.reversed;
        AppController.instance.organizationFieldsData!.directorsData =
            dynamicListData;
      });
    }
    Navigator.of(context).pop();
  }

  buildDinDropdown(String text) {
    return Container(
        padding: EdgeInsets.all(1),
        decoration: BoxDecoration(
          border: Border.all(
            color: Colors.grey,
          ),
          borderRadius: BorderRadius.circular(
            5.0,
          ),
        ),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: RichText(
                          text: TextSpan(children: [
                            TextSpan(
                              text: text,
                              style: TextStyle(
                                  fontSize: StyleView.FONT_SIZE_15,
                                  fontFamily: StyleView.FONT_TITLE,
                                  color: Colors.black),
                            ),
                            TextSpan(
                                text: "\*",
                                style: TextStyle(
                                    fontSize: StyleView.FONT_SIZE_15,
                                    color: Colors.red))
                          ]),
                        )),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5, right: 5),
                  child: DropdownButton<String>(
                      onTap: () {
                        return CommonMethods.hideKeyboard(context);
                      },
                      value: dinDropdownValue,
                      isExpanded: true,
                      hint: Text(
                          Language()
                              .getString(Constants.SELECT_DIN, selectedLang),
                          style: TextStyle(fontFamily: StyleView.FONT_TITLE)),
                      underline: SizedBox(),
                      onChanged: (String? data) {
                        setState(() {
                          dinDropdownValue = data;
                        });
                      },
                      items: DINDROPDOWNITEMS.map((String model) {
                        return new DropdownMenuItem<String>(
                          child: new Text(model,
                              style:
                                  TextStyle(fontFamily: StyleView.FONT_TITLE)),
                          value: model,
                        );
                      }).toList())),
            )
          ],
        ));
  }

  Future<List<CitiesDAO>> getCitiesList(
      {String? countryName, String? stateId, String? path}) async {
    setState(() {
      isLoadingProgress = true;
      AppController.instance.setCreateBuProgress = true;
      _citiesList.clear();
      citiesDropDownValue = null;
    });

    var resposne = await _service.getCities(countryName, stateId);
    List<CitiesDAO> _list = [];
    setState(() {
      isLoadingProgress = false;
      AppController.instance.setCreateBuProgress = false;
    });

    if (resposne.statusCode == 200) {
      var data = json.decode(resposne.body);

      bool isString = false;

      if (data['data'] is String) {
        isString = true;
      }

      if (!isString) {
        for (var object in data['data']) {
          _list.add(CitiesDAO.fromJson(object));
        }
        if (path == Constants.REG_CITY) {
          if (_buModel != null &&
              _list.length > 0 &&
              _buModel!.registration != null &&
              _buModel!.registration!.registrationCity != null) {
            for (int k = 0; k < _list[0].cities!.length; k++) {
              if (_buModel!.registration!.registrationCity ==
                  _list[0].cities![k]) {
                setState(() {
                  citiesDropDownValue = _list[0].cities![k];
                });

                AppController.instance.getOrganizationFieldsData.regOrgCity =
                    _list[0].cities![k];
              }
            }
          } else {
            if (_list.length > 0 &&
                AppController.instance.getOrganizationFieldsData.regOrgCity !=
                    null) {
              for (int s = 0; s < _list[0].cities!.length; s++) {
                /// Comparing step 2 state and appending to register state
                if (AppController
                        .instance.getOrganizationFieldsData.regOrgCity ==
                    _list[0].cities![s]) {
                  setState(() {
                    citiesDropDownValue = _list[0].cities![s];
                  });

                  AppController.instance.organizationFieldsData!.regOrgCity =
                      citiesDropDownValue;
                }
              }
            }
          }
        }
      }
    }

    return _list;
  }

  /// Service callfor States

  Future<List<StatesDAO>> getStates(
      String countryName, String statePath) async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = Constants.GETTING_STATES;
      AppController.instance.setCreateBuProgress = true;
    });

    _statesList.clear();
    statesDropdownValue = null;

    http.Response response = await _service
        .getStatesByCountry(countryName)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
        AppController.instance.setCreateBuProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<StatesDAO> list = [];
    setState(() {
      isLoadingProgress = false;
      AppController.instance.setCreateBuProgress = false;
    });
    if (response.statusCode == 200) {
      var data = json.decode(response.body);
      for (var object in data["data"]) {
        for (var statesObject in object["states"])
          list.add(StatesDAO.fromJson(statesObject));
      }

      //   /**
      //    * updating states and cities values for userEdit
      //    */

      if (statePath == Constants.REG_CITY) {
        if (_buModel != null &&
            _buModel!.registration != null &&
            list.length > 0 &&
            _buModel!.registration!.registrationState != null) {
          for (int i = 0; i < list.length; i++) {
            if (_buModel!.registration!.registrationState == list[i].state) {
              setState(() {
                statesDropdownValue = list[i];
              });

              AppController.instance.organizationFieldsData!.regOrgState =
                  statesDropdownValue != null ? statesDropdownValue!.state : "";
            }
          }

          if (statesDropdownValue != null) {
            this
                .getCitiesList(
                    countryName: countryName,
                    stateId: statesDropdownValue!.id,
                    path: statePath)
                .then((value) {
              if (value.length > 0) {
                setState(() {
                  _citiesList.clear();
                  _citiesList.addAll(value[0].cities!);
                });
              }
            });
          }
        } else {
          if (list.length > 0 &&
              AppController.instance.organizationFieldsData!.state != null) {
            for (int s = 0; s < list.length; s++) {
              /// Comparing step 2 state and appending to register state
              if (AppController.instance.organizationFieldsData!.state ==
                  list[s].state) {
                setState(() {
                  statesDropdownValue = list[s];
                });

                AppController.instance.organizationFieldsData!.regOrgState =
                    statesDropdownValue!.state;
              }
            }
            if (statesDropdownValue != null) {
              this
                  .getCitiesList(
                      countryName: countryName,
                      stateId: statesDropdownValue!.id,
                      path: statePath)
                  .then((value) {
                if (value.length > 0) {
                  setState(() {
                    _citiesList.clear();
                    _citiesList.addAll(value[0].cities!);
                  });
                }
              });
            }
          }
        }
      }
    } else {
      // await progressDialog.hide();
    }

    return list;
  }

  Future<List<CountryDAO>> getCountries() async {
    http.Response response = await _service.get_countries();
    List<CountryDAO> list = [];

    // await progressDialog.hide();
    if (response.statusCode == 200) {
      var data = json.decode(response.body);
      for (var object in data["data"]) {
        list.add(CountryDAO.fromJaon(object));
      }

      /**
       * updating county value for userEdit
       */

      if (_buModel != null &&
          _buModel!.registration != null &&
          list.length > 0 &&
          _buModel!.registration!.registrationCountry != null) {
        for (int i = 0; i < list.length; i++) {
          if (_buModel!.registration!.registrationCountry == list[i].name) {
            countryDropdownValue = list[i];
            AppController.instance.organizationFieldsData!.regOrgCountry =
                countryDropdownValue!.name;
          }
        }
        serviceCallGetStates(
            countryDropdownValue != null ? countryDropdownValue!.name : "",
            Constants.REG_CITY);
      } else {
        for (int i = 0; i < list.length; i++) {
          if (AppController.instance.organizationFieldsData!.country ==
              list[i].name) {
            countryDropdownValue = list[i];
            AppController.instance.organizationFieldsData!.regOrgCountry =
                countryDropdownValue!.name;
          }
        }
        serviceCallGetStates(
            countryDropdownValue != null ? countryDropdownValue!.name : "",
            Constants.REG_CITY);
      }
    } else {
      // await progressDialog.hide();
    }
    return list;
  }

  serviceCallGetStates(String? countryName, String path) async {
    if (await NetworkStatus.getInternetStatus()) {
      this.getStates(countryName!, path).then((value) {
        setState(() {
          _statesList.addAll(value);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey, Constants.NO_INTERNET,
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Widget acceptInpersongOrderFunctionality() {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 24.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
              child: Text(
            Language().getString(
                Constants.BUYER_MUST_ACCEPT_IN_PERSON_ORDER, selectedLang),
            style: TextStyle(
                fontSize: 15.0,
                fontFamily: StyleView.FONT_TITLE,
                fontWeight: FontWeight.bold),
          )),
          Container(
            child: Row(
              children: [
                Expanded(
                  child: Row(
                    children: [
                      Radio(
                          value: Constants.YES_STRING,
                          groupValue: inpersonOrderRadioValue,
                          onChanged: (dynamic value) {
                            setState(() {
                              inpersonOrderRadioValue = value;
                              AppController.instance.getOrganizationFieldsData
                                  .setInpersonOrderAccept = true;
                            });
                          }),
                      Expanded(
                          child: Text(
                        Language()
                            .getString(Constants.YES_STRING, selectedLang),
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 15.0,
                        ),
                      ))
                    ],
                  ),
                ),
                Expanded(
                  child: Row(
                    children: [
                      Radio(
                          value: Constants.NO_STRING,
                          groupValue: inpersonOrderRadioValue,
                          onChanged: (dynamic value) {
                            setState(() {
                              inpersonOrderRadioValue = value;
                              AppController.instance.getOrganizationFieldsData
                                  .setInpersonOrderAccept = false;
                            });
                          }),
                      Expanded(
                          child: Text(
                        Language().getString(Constants.NO_STRING, selectedLang),
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 15.0,
                        ),
                      ))
                    ],
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  showDetailsInInvoiceView(StateSetter setState) {
    return Container(
        margin: EdgeInsets.symmetric(vertical: 5.0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(
              child: Text(
                  Language().getString(
                      Constants.SHOW_BANK_DETAILS_IN_INVOICE, selectedLang),
                  style: TextStyle(
                      color: Colors.black, //Constants.APP_COLOR),
                      fontSize: 15.0,
                      fontFamily: StyleView.FONT_TITLE,
                      fontWeight: FontWeight.bold))),
          Container(
              child: Row(
            children: [
              Container(
                  child: Row(children: [
                Container(
                    child: Row(
                  children: [
                    Radio(
                        activeColor: Color(Constants.APP_COLOR),
                        onChanged: (dynamic value) {
                          setState(() {
                            bankDetailsRadioValue = value;
                          });
                        },
                        value: Constants.YES_STRING,
                        groupValue: bankDetailsRadioValue),
                    Container(
                        child: Text(Language()
                            .getString(Constants.YES_STRING, selectedLang)))
                  ],
                )),
              ])),
              Container(
                  child: Row(children: [
                Container(
                    child: Row(
                  children: [
                    Radio(
                        activeColor: Color(Constants.APP_COLOR),
                        onChanged: (dynamic value) {
                          setState(() {
                            bankDetailsRadioValue = value;
                          });
                        },
                        value: Constants.NO_STRING,
                        groupValue: bankDetailsRadioValue),
                    Container(
                        child: Text(Language()
                            .getString(Constants.NO_STRING, selectedLang)))
                  ],
                )),
              ]))
            ],
          ))
        ]));
  }

  Future<List<PaymentTermsDAO>> getPaymentTerms() async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = Constants.GETTING_TERMS;
      AppController.instance.setCreateBuProgress = true;
    });

    http.Response response =
        await _service.getPaymentTerms().catchError((onError) {
      setState(() {
        isLoadingProgress = false;
        AppController.instance.setCreateBuProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    setState(() {
      isLoadingProgress = false;
      AppController.instance.setCreateBuProgress = false;
    });
    List<PaymentTermsDAO> _list = [];
    if (response.statusCode == 200) {
      var data = json.decode(response.body);
      _list.add(PaymentTermsDAO(paymentTerm: "Select Payment Term"));
      for (var objects in data['data']) {
        _list.add(PaymentTermsDAO.fromJson(objects));
      }

      if (_list.length > 0) {
        if (isOrgUpdate! &&
            _buModel!.paymentTerms != null &&
            _buModel!.paymentTerms!.invoicePaymentTerms != null) {
          for (int i = 0; i < _list.length; i++) {
            if (_buModel!.paymentTerms!.invoicePaymentTerms ==
                _list[i].paymentTerm) {
              paymentTermDropdown = _list[i];
              AppController.instance.organizationFieldsData!
                  .invoicePaymentTerms = paymentTermDropdown!.paymentTerm;
              AppController.instance.organizationFieldsData!.paymentTermCode =
                  paymentTermDropdown!.termCode;
              AppController.instance.organizationFieldsData!.paymentTermDays =
                  paymentTermDropdown!.days;
            }
          }
        } else {
          paymentTermDropdown = _list[0];
          AppController.instance.organizationFieldsData!.invoicePaymentTerms =
              paymentTermDropdown!.paymentTerm;
          AppController.instance.organizationFieldsData!.paymentTermCode =
              paymentTermDropdown!.termCode;
          AppController.instance.organizationFieldsData!.paymentTermDays =
              paymentTermDropdown!.days;
        }
      }
    } else if (response.statusCode == 401) {
      return CommonMethods.handleUnauthorizedAccess(context);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          "${response.body}",
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }

    return _list;
  }

  Future<List<PenaltyAmountDAO>> getPenaltyAmountList() async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = Constants.GETTING_PENALTY_LIST;
      AppController.instance.setCreateBuProgress = true;
    });

    http.Response response =
        await _service.getPenaltyList().catchError((onError) {
      setState(() {
        isLoadingProgress = false;
        AppController.instance.setCreateBuProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    setState(() {
      isLoadingProgress = false;
      AppController.instance.setCreateBuProgress = false;
    });
    List<PenaltyAmountDAO> _list = [];
    if (response.statusCode == 200) {
      var data = json.decode(response.body);
      for (var objects in data['data']) {
        _list.add(PenaltyAmountDAO.fromJson(objects));
      }

      if (_list.length > 0) {
        if (isOrgUpdate! &&
            _buModel!.paymentTerms != null &&
            _buModel!.paymentTerms!.penaltyAmount != null &&
            _buModel!.paymentTerms!.penaltyAmount!.reason != null) {
          for (int i = 0; i < _list.length; i++) {
            if (_buModel!.paymentTerms!.penaltyAmount!.reason ==
                _list[i].reason) {
              penaltyAmountDropdown = _list[i];
              AppController.instance.organizationFieldsData!
                  .penaltyAmountReason = penaltyAmountDropdown!.reason;
              AppController.instance.organizationFieldsData!.penaltyCode =
                  penaltyAmountDropdown!.code;
            } else {
              // penaltyAmountDropdown = PenaltyAmountDAO(reason: "Select reason");
            }
          }

          if (penaltyAmountDropdown == null) {
            penaltyAmountDropdown = penaltyAmountList[0];
          }
        } else {
          penaltyAmountDropdown = _list[0];
          AppController.instance.organizationFieldsData!.penaltyAmountReason =
              penaltyAmountDropdown!.reason;
          AppController.instance.organizationFieldsData!.penaltyCode =
              penaltyAmountDropdown!.code;
        }
      }
    } else if (response.statusCode == 401) {
      return CommonMethods.handleUnauthorizedAccess(context);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          "${response.body}",
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }

    return _list;
  }
}
