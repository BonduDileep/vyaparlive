class BankDetails {
  String? bankname;
  String? bankaccountname;
  String? epayCode;
  String? penaltyAmount;
  String? swiftCode;
  String? micrCode;
  String? ifscCode;
  bool? isShowInvoiceView;
  String? bankAccountNumber;
  BankDetails(
      {this.bankname,
      this.bankaccountname,
      this.epayCode,
      this.penaltyAmount,
      this.swiftCode,
      this.micrCode,
      this.ifscCode,
      this.isShowInvoiceView = false,
      this.bankAccountNumber});
}
