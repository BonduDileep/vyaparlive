import 'package:vyaparlive/model/DirectorData.dart';
import 'package:vyaparlive/model/ExportsModel.dart';
import 'package:vyaparlive/Organization/PaymentDetailsPage.dart';
import 'package:vyaparlive/model/RegulationData.dart';
import 'package:vyaparlive/model/RolesDAO.dart';
import 'package:vyaparlive/model/StockDetailsModel.dart';
import 'package:vyaparlive/model/TaxSchemeData.dart';
import 'package:vyaparlive/model/TermsData.dart';
import 'package:vyaparlive/model/bu_model/LocationsModel.dart';

class OrganizationFieldsData {
  String? parentBuId;
  String? businessName;
  String? shortName;
  String? website;
  String? businessHob;
  String? businessLocation;
  String? buContactNumber;
  String? mobileNumber;
  String? businessType;
  String? countryCode;
  String? currencyCode;
  String? directorName;
  String? identificationScheme;
  String? identificationNumber;
  String? digitalSign;
  String? contactName;
  String? contactAddress;
  String? contactAddressFormat;
  String? houseNo;
  String? buildingNo;
  String? streetName;
  String? locality;
  String? city;
  String? taluk;
  String? landMark;
  String? state;
  String? district;
  String? postalCode;
  String? country;
  String? parentBu;
  String? parentBusinessName;
  String? parentBusinessWebsite;
  String? parentHob;
  String? parentLocation;
  String? regOrgName;
  String? regOrgDate;
  String? regOrgCity;
  String? regOrgState;
  String? regOrgCountry;
  String? regentityType;
  String? regScheme;
  String? taxSchemeName;
  String? taxSchemeNumber;
  String? taxExemption;
  String? regulationSchemeId;
  String? regulatioRegId;
  String? exportsRegName;
  String? exportsRegId;
  String? importsRegName;
  String? importsRegId;
  String? stockReceiveLocationNum;
  String? stockReceiveBusinessName;
  String? stockDispatchLocationNum;
  String? stockDispatchBusinessName;
  String? dispatchTaxName;
  String? dispatchTaxExcemptionReason;
  String? receiveTaxName;
  String? receiveTaxExcemptionReason;
  String? receiveAddressName;
  String? receiveAddress;
  String? receiveAddressNumber;
  String? sendAddressName;
  String? sendAddress;
  String? sendAddressNumber;
  String? receiveBankName;
  String? receiveAccountName;
  String? receiveAccountNumber;
  String? ePayCode;
  String? swiftCode;
  String? micrCode;

  String? payBankName;
  String? payAccountName;
  String? payAccountNumber;
  String? payEePayCode;
  String? paySwiftCode;
  String? payMicrCode;

  String? invoiceCurrencyCode;
  String? paymentPeriodCode;
  String? numberOfDays;
  String? invoiceDescription;
  String? partialPercent;
  String? penaltyAmount;
  String? percentRate;
  String? description;
  String? basisAmount;

  String? invoicePaymentTerms;
  String? penaltyAmountReason;
  String? penaltyAmountPercentage;
  String? advancePaymentValue;
  String? advancePaymentPercentage;
  String? paymentComments;
  List<TermsData>? termsAndConditionsList;

  List<RolesDAO>? rolesArray;
  List<Locations>? locationsArray;
  List<DirectorsData>? directorsData;
  List<Map<String, dynamic>>? directorsArray;
  List<TaxSchemeData>? taxSchemeArray;
  List<RegulationData>? regulationArray;
  List<ExportsModel>? exportsArray;
  List<ExportsModel>? importsArray;
  List<StockDetailsModel>? stockReceiveArray;
  List<StockDetailsModel>? stockDispatchArray;
  List<BankDetails>? bankPaymentsArray;
  List<BankDetails>? bankReceiveArray;
  List<Map<String, dynamic>>? stockDispatchTaxArray;
  List<Map<String, dynamic>>? addressSenderArray;
  List<Map<String, dynamic>>? addressReceiveArray;
  List<Map<String, dynamic>>? stockReceiveTaxArray;
  bool? isInpersonOrderAccept;
  String? gstNumber;
  String? orgCurrencySymbol;
  String? orgCountryDialCode;
  String? officeDialCode;
  String? paymentTermCode;
  String? penaltyCode;
  num? paymentTermDays;
  String? currencyName;
  String? orgPlotNo;
  String? mainOfficeLocationId;
  String? invoicePhoneNumber;
  String? invoiceEmail;
  String? panCardNumber;
  String? cinCardNumber;

  set setDirectorsListData(List<DirectorsData> list) => this.directorsData;
  List<DirectorsData>? get getDirectorsListData => this.directorsData;

  set setStockReceiveTaxData(List<Map<String, dynamic>> list) =>
      this.stockReceiveTaxArray;
  List<Map<String, dynamic>>? get getStockReceiveTaxData =>
      this.addressReceiveArray;
  set setAddressReceiveData(List<Map<String, dynamic>> list) =>
      this.addressReceiveArray;
  List<Map<String, dynamic>>? get getAddressReceiveData =>
      this.addressReceiveArray;
  set setAddressSendeData(List<Map<String, dynamic>> list) =>
      this.addressSenderArray;
  List<Map<String, dynamic>>? get getAddressSendData => this.addressSenderArray;

  set setStickDispatchTaxeData(List<Map<String, dynamic>> list) =>
      this.stockDispatchTaxArray;
  List<Map<String, dynamic>>? get getStockDispachTaxData =>
      this.stockDispatchTaxArray;

  set setBankReceiveData(List<BankDetails> list) => this.bankReceiveArray;
  List<BankDetails>? get getBankReceiveData => this.bankReceiveArray;
  set setBankPaymentsData(List<BankDetails> list) => this.bankPaymentsArray;
  List<BankDetails>? get getBankPaymentsData => this.bankPaymentsArray;
  set setStockReceiveData(List<StockDetailsModel> list) =>
      this.stockReceiveArray;
  List<StockDetailsModel>? get getStockReceiveData => this.stockReceiveArray;
  set setStockDisptchData(List<StockDetailsModel> list) =>
      this.stockDispatchArray;
  List<StockDetailsModel>? get getStockDispatchData => this.stockDispatchArray;
  set setImportsData(List<ExportsModel> list) => this.importsArray;
  List<ExportsModel>? get getImportsData => this.importsArray;
  set setExportsData(List<ExportsModel> list) => this.exportsArray;
  List<ExportsModel>? get getExportsData => this.exportsArray;
  set setRegulationData(List<RegulationData> list) => this.regulationArray;
  List<RegulationData>? get getRegulationData => this.regulationArray;
  set setTaxSchemeData(List<TaxSchemeData> list) => this.taxSchemeArray;
  List<TaxSchemeData>? get getTaxSchemeData => this.taxSchemeArray;
  set setDirectorsData(List<Map<String, dynamic>> list) => this.directorsArray;
  List<Map<String, dynamic>>? get getDirectorsData => this.directorsArray;

  set setRolesData(List<RolesDAO> list) => this.rolesArray;
  List<RolesDAO>? get getRolesData => rolesArray;
  set setLocationsData(List<Locations> list) => this.locationsArray;
  List<Locations>? get getLocationsData => locationsArray;

  String? get getBusinessName => businessName;

  set setBusinessName(String businessName) => this.businessName = businessName;

  String? get getShortName => shortName;

  set setShortName(String shortName) => this.shortName = shortName;

  String? get getWebsite => website;

  set setWebsite(String website) => this.website = website;

  String? get getBusinessType => businessType;

  set setHob(String businessHob) => this.businessHob = businessHob;

  String? get getHob => businessHob;

  set setBusinessLocation(String businessLocation) =>
      this.businessLocation = businessLocation;

  String? get getBusinessLocation => businessLocation;

  set setBuContactNumber(String contactNum) =>
      this.buContactNumber = contactNum;

  String? get getBuContactNumber => buContactNumber;

  set setBuMobileNumber(String contactNum) => this.mobileNumber = contactNum;

  String? get getBuMobileNumber => mobileNumber;

  set setBusinessType(String businessType) => this.businessType = businessType;

  String? get getCountryCode => countryCode;

  set setCountryCode(String countryCode) => this.countryCode = countryCode;

  String? get getCurrencyCode => currencyCode;

  set setCurrencyCode(String currencyCode) => this.currencyCode = currencyCode;

  String? get getDirectorName => directorName;

  set setDirectorName(String directorName) => this.directorName = directorName;

  String? get getIdentificationScheme => identificationScheme;

  set setIdentificationScheme(String identificationScheme) =>
      this.identificationScheme = identificationScheme;

  String? get getIdentificationNumber => identificationNumber;

  set setIdentificationNumber(String identificationNumber) =>
      this.identificationNumber = identificationNumber;

  String? get getDigitalSign => digitalSign;

  set setDigitalSign(String digitalSign) => this.digitalSign = digitalSign;

  String? get getContactName => contactName;

  set setContactName(String contactName) => this.contactName = contactName;

  String? get getContactAddress => contactAddress;

  set setContactAddress(String contactAddress) =>
      this.contactAddress = contactAddress;

  String? get getContactAddressFormat => contactAddressFormat;

  set setContactAddressFormat(String contactAddressFormat) =>
      this.contactAddressFormat = contactAddressFormat;

  String? get getHouseNo => houseNo;

  set setHouseNo(String houseNo) => this.houseNo = houseNo;

  String? get getBuildingNo => buildingNo;

  set setBuildingNo(String buildingNo) => this.buildingNo = buildingNo;

  String? get getStreetName => streetName;

  set setStreetName(String streetName) => this.streetName = streetName;

  String? get getLocality => locality;

  set setLocality(String locality) => this.locality = locality;

  String? get getCity => city;

  set setCity(String city) => this.city = city;

  String? get getTaluk => taluk;

  set setTaluk(String taluk) => this.taluk = taluk;

  String? get getLandMark => landMark;

  set setLandMark(String landMark) => this.landMark = landMark;

  String? get getState => state;

  set setState(String state) => this.state = state;

  String? get getDistrict => district;

  set setDistrict(String district) => this.district = district;

  String? get getPostalCode => postalCode;

  set setPostalCode(String postalCode) => this.postalCode = postalCode;

  String? get getCountry => country;

  set setCountry(String country) => this.country = country;

  String? get getParentBu => parentBu;

  set setParentBu(String parentBu) => this.parentBu = parentBu;

  String? get getParentBusinessName => parentBusinessName;

  set setParentBusinessName(String parentBusinessName) =>
      this.parentBusinessName = parentBusinessName;

  String? get getParentBusinessWebsite => parentBusinessWebsite;

  set setParentBusinessWebsite(String parentBusinessWebsite) =>
      this.parentBusinessWebsite = parentBusinessWebsite;

  String? get getParentHob => parentHob;

  set setParentHob(String parentHob) => this.parentHob = parentHob;

  String? get getParentLocation => parentLocation;

  set setParentLocation(String parentLocation) =>
      this.parentLocation = parentLocation;

  String? get getRegOrgName => regOrgName;

  set setRegOrgName(String regOrgName) => this.regOrgName = regOrgName;

  String? get getRegOrgDate => regOrgDate;

  set setRegOrgDate(String regOrgDate) => this.regOrgDate = regOrgDate;

  String? get getRegOrgCity => regOrgCity;

  set setRegOrgCity(String regOrgCity) => this.regOrgCity = regOrgCity;

  String? get getRegOrgState => regOrgState;

  set setRegOrgState(String regOrgState) => this.regOrgState = regOrgState;

  String? get getRegOrgCountry => regOrgCountry;

  set setRegOrgCountry(String regOrgCountry) =>
      this.regOrgCountry = regOrgCountry;

  String? get getRegentityType => regentityType;

  set setRegentityType(String regentityType) =>
      this.regentityType = regentityType;

  String? get getRegScheme => regScheme;

  set setRegScheme(String regScheme) => this.regScheme = regScheme;

  String? get getTaxSchemeName => taxSchemeName;

  set setTaxSchemeName(String taxSchemeName) =>
      this.taxSchemeName = taxSchemeName;

  String? get getTaxSchemeNumber => taxSchemeNumber;

  set setTaxSchemeNumber(String taxSchemeNumber) =>
      this.taxSchemeNumber = taxSchemeNumber;

  String? get getTaxExemption => taxExemption;

  set setTaxExemption(String taxExemption) => this.taxExemption = taxExemption;

  String? get getRegulationSchemeId => regulationSchemeId;

  set setRegulationSchemeId(String regulationSchemeId) =>
      this.regulationSchemeId = regulationSchemeId;

  String? get getRegulatioRegId => regulatioRegId;

  set setRegulatioRegId(String regulatioRegId) =>
      this.regulatioRegId = regulatioRegId;

  String? get getExportsRegName => exportsRegName;

  set setExportsRegName(String exportsRegName) =>
      this.exportsRegName = exportsRegName;

  String? get getExportsRegId => exportsRegId;

  set setExportsRegId(String exportsRegId) => this.exportsRegId = exportsRegId;

  String? get getImportsRegName => importsRegName;

  set setImportsRegName(String importsRegName) =>
      this.importsRegName = importsRegName;

  String? get getImportsRegId => importsRegId;

  set setImportsRegId(String importsRegId) => this.importsRegId = importsRegId;

  String? get getStockReceiveLocationNum => stockReceiveLocationNum;

  set setStockReceiveLocationNum(String stockReceiveLocationNum) =>
      this.stockReceiveLocationNum = stockReceiveLocationNum;

  String? get getStockReceiveBusinessName => stockReceiveBusinessName;

  set setStockReceiveBusinessName(String stockReceiveBusinessName) =>
      this.stockReceiveBusinessName = stockReceiveBusinessName;

  String? get getStockDispatchLocationNum => stockDispatchLocationNum;

  set setStockDispatchLocationNum(String stockDispatchLocationNum) =>
      this.stockDispatchLocationNum = stockDispatchLocationNum;

  String? get getStockDispatchBusinessName => stockDispatchBusinessName;

  set setStockDispatchBusinessName(String stockDispatchBusinessName) =>
      this.stockDispatchBusinessName = stockDispatchBusinessName;

  String? get getDispatchTaxName => dispatchTaxName;

  set setDispatchTaxName(String dispatchTaxName) =>
      this.dispatchTaxName = dispatchTaxName;

  String? get getDispatchTaxExcemptionReason => dispatchTaxExcemptionReason;

  set setDispatchTaxExcemptionReason(String dispatchTaxExcemptionReason) =>
      this.dispatchTaxExcemptionReason = dispatchTaxExcemptionReason;

  String? get getReceiveTaxName => receiveTaxName;

  set setReceiveTaxName(String receiveTaxName) =>
      this.receiveTaxName = receiveTaxName;

  String? get getReceiveTaxExcemptionReason => receiveTaxExcemptionReason;

  set setReceiveTaxExcemptionReason(String receiveTaxExcemptionReason) =>
      this.receiveTaxExcemptionReason = receiveTaxExcemptionReason;

  String? get getReceiveAddressName => receiveAddressName;

  set setReceiveAddressName(String receiveAddressName) =>
      this.receiveAddressName = receiveAddressName;

  String? get getReceiveAddress => receiveAddress;

  set setReceiveAddress(String receiveAddress) =>
      this.receiveAddress = receiveAddress;

  String? get getReceiveAddressNumber => receiveAddressNumber;

  set setReceiveAddressNumber(String receiveAddressNumber) =>
      this.receiveAddressNumber = receiveAddressNumber;

  String? get getSendAddressName => sendAddressName;

  set setSendAddressName(String sendAddressName) =>
      this.sendAddressName = sendAddressName;

  String? get getSendAddress => sendAddress;

  set setSendAddress(String sendAddress) => this.sendAddress = sendAddress;

  String? get getSendAddressNumber => sendAddressNumber;

  set setSendAddressNumber(String sendAddressNumber) =>
      this.sendAddressNumber = sendAddressNumber;

  String? get getReceiveBankName => receiveBankName;

  set setReceiveBankName(String receiveBankName) =>
      this.receiveBankName = receiveBankName;

  String? get getReceiveAccountName => receiveAccountName;

  set setReceiveAccountName(String receiveAccountName) =>
      this.receiveAccountName = receiveAccountName;

  String? get getReceiveAccountNumber => receiveAccountNumber;

  set setReceiveAccountNumber(String receiveAccountNumber) =>
      this.receiveAccountNumber = receiveAccountNumber;

  String? get getEPayCode => ePayCode;

  set setEPayCode(String ePayCode) => this.ePayCode = ePayCode;

  String? get getSwiftCode => swiftCode;

  set setSwiftCode(String swiftCode) => this.swiftCode = swiftCode;

  String? get getMicrCode => micrCode;

  set setMicrCode(String micrCode) => this.micrCode = micrCode;

  String? get getPayBankName => payBankName;

  set setPayBankName(String payBankName) => this.payBankName = payBankName;

  String? get getPayAccountName => payAccountName;

  set setPayAccountName(String payAccountName) =>
      this.payAccountName = payAccountName;

  String? get getPayAccountNumber => payAccountNumber;

  set setPayAccountNumber(String payAccountNumber) =>
      this.payAccountNumber = payAccountNumber;

  String? get getPayEePayCode => payEePayCode;

  set setPayEePayCode(String payEePayCode) => this.payEePayCode = payEePayCode;

  String? get getPaySwiftCode => paySwiftCode;

  set setPaySwiftCode(String paySwiftCode) => this.paySwiftCode = paySwiftCode;

  String? get getPayMicrCode => payMicrCode;

  set setPayMicrCode(String payMicrCode) => this.payMicrCode = payMicrCode;

  String? get getInvoiceCurrencyCode => invoiceCurrencyCode;

  set setInvoiceCurrencyCode(String invoiceCurrencyCode) =>
      this.invoiceCurrencyCode = invoiceCurrencyCode;

  String? get getInvoicePaymentTersm => invoicePaymentTerms;

  set setInvoicePaymentTersm(String paymentTerms) =>
      this.invoicePaymentTerms = paymentTerms;

  String? get getPenaltyAmountReason => penaltyAmountReason;

  set setPenaltyAmountReason(String penaltyReason) =>
      this.penaltyAmountReason = penaltyReason;
  String? get getPenaltyAmountPercentage => penaltyAmountPercentage;

  set setPenaltyAmountPercentage(String penaltyPercentage) =>
      this.penaltyAmountPercentage = penaltyPercentage;

  String? get getAdvancePaymemntValue => advancePaymentValue;

  set setAdvancePaymentValue(String paymentValue) =>
      this.advancePaymentValue = paymentValue;

  String? get getAdvancePaymentPercentage => advancePaymentPercentage;

  set setAdvancePaymentPercentage(String paymentPercentage) =>
      this.advancePaymentPercentage = paymentPercentage;

  String? get getPaymentComments => paymentComments;

  set setPaymentComments(String comments) => this.paymentComments = comments;

  List<TermsData>? get getTermsAndConditionsData => termsAndConditionsList;

  set setTermsAndConditionsData(List<TermsData> termsData) =>
      this.termsAndConditionsList = termsData;

  String? get getPaymentPeriodCode => paymentPeriodCode;

  set setPaymentPeriodCode(String paymentPeriodCode) =>
      this.paymentPeriodCode = paymentPeriodCode;

  String? get getNumberOfDays => numberOfDays;

  set setNumberOfDays(String numberOfDays) => this.numberOfDays = numberOfDays;

  String? get getInvoiceDescription => invoiceDescription;

  set setInvoiceDescription(String invoiceDescription) =>
      this.invoiceDescription = invoiceDescription;

  String? get getPartialPercent => partialPercent;

  set setPartialPercent(String partialPercent) =>
      this.partialPercent = partialPercent;

  String? get getPenaltyAmount => penaltyAmount;

  set setPenaltyAmount(String penaltyAmount) =>
      this.penaltyAmount = penaltyAmount;

  String? get getPercentRate => percentRate;

  set setPercentRate(String percentRate) => this.percentRate = percentRate;

  String? get getDescription => description;

  set setDescription(String description) => this.description = description;

  String? get getBasisAmount => basisAmount;

  set setBasisAmount(String basisAmount) => this.basisAmount = basisAmount;

  set setInpersonOrderAccept(bool value) => this.isInpersonOrderAccept = value;

  bool? get getInpersonOrderAccept => this.isInpersonOrderAccept;
  set setGSTNumber(String gst) => this.gstNumber = gst;

  String? get getGSTNumber => this.gstNumber;

  set setOrgCurrencySymbol(String currencySymbol) =>
      this.orgCurrencySymbol = currencySymbol;

  String? get getOrgCurrencySymbol => this.orgCurrencySymbol;

  set setOrgCountryDialCode(String dialCode) =>
      this.orgCountryDialCode = dialCode;

  String? get getOrgCountryDialCode => this.orgCountryDialCode;

  set setOrgOfficeDialCode(String officeCode) =>
      this.officeDialCode = officeCode;

  String? get getOrgOfficeDialCode => this.officeDialCode;

  set setPaymentTermCode(String termCode) => this.paymentTermCode = termCode;

  String? get getPaymentTermCode => this.paymentTermCode;

  set setPenaltyCode(String penaltyAmountCode) =>
      this.penaltyCode = penaltyAmountCode;

  String? get getPenaltyCode => this.penaltyCode;

  set setPaymentTermDats(num days) => this.paymentTermDays = days;

  num? get getPaymentTermDats => this.paymentTermDays;

  set setCurrencyName(String currencyName) => this.currencyName = currencyName;

  String? get getCurrencyName => this.currencyName;

  set setOrgPlotNo(String plotNo) => this.orgPlotNo = plotNo;

  String? get getOrgPlotNo => this.orgPlotNo;

  set setMainOfficeLocationId(String id) => this.mainOfficeLocationId = id;

  String? get getMainOfficeLocationId => this.mainOfficeLocationId;

  set setInvoicePhoneNumber(String phnNumner) =>
      this.invoicePhoneNumber = phnNumner;

  String? get getInvoicePhoneNumber => this.invoicePhoneNumber;

  set setInvoiceEmail(String emailId) => this.invoiceEmail = emailId;

  String? get getInvoiceEmail => this.invoiceEmail;

  set setPanCardNumber(String panNum) => this.panCardNumber = panNum;

  String? get getPanCardNumber => this.panCardNumber;

  set setCinNumber(String cinNum) => this.cinCardNumber = cinNum;

  String? get getCinNumber => this.cinCardNumber;
}
