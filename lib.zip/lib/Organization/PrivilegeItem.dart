class PrivilegeItem {
  String code;
  String label;
  bool isSelected;
  List<PrivilegeItem> children;

  PrivilegeItem({
    required this.code,
    required this.label,
    this.isSelected = false,
    this.children = const [],
  });

  // Toggle the selection for a parent item and all its children
  void toggleSelection(bool? value) {
    isSelected = value ?? false;
    for (var child in children) {
      child.toggleSelection(value);
    }
  }

  // Update parent selection state based on child selections
  void updateParentSelection() {
    if (children.isEmpty) return;

    int selectedCount = children.where((child) => child.isSelected).length;

    if (selectedCount == children.length) {
      isSelected = true;
    } else if (selectedCount == 0) {
      isSelected = false;
    } else {
      isSelected = false; // Parent remains unchecked if partially selected
    }
  }
}