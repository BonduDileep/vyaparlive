import 'package:vyaparlive/Organization/AddInvoiceTemplatePage.dart';
import 'package:vyaparlive/Product/ProductsMenuPage.dart';
import 'package:vyaparlive/Transaction/TransactionsPage.dart';
import 'package:vyaparlive/Users/UsersListPage.dart';
import 'package:vyaparlive/connections_view/ConnectionsBuDetails.dart';
import 'package:vyaparlive/locations_view/BuLocationsList.dart';
import 'package:vyaparlive/roles_view/RolesList.dart';
import 'package:flutter/material.dart';
import 'package:flutx/flutx.dart';
import 'package:vyaparlive/model/BusinessUnitModel.dart';

class OrganizationController extends FxController {
  void onUsersList(
      {required String buId,
      required String buName,
      required bool isFromBuList}) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => UsersStatusView(
          isFromBuList: isFromBuList,
          currentBuId: buId,
          currentBuName: buName,
        ),
      ),
    );
  }

  void onLocationsView({required String buId, required String buName}) {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => BuLocationsListPage(
                  buId: buId,
                  buName: buName,
                )));
  }

  void onRolesView({required String buId, required String buName}) {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => RolesListView(
                  buId: buId,
                  buName: buName,
                )));
  }

  void onProductsView({required String buId, required String buName}) {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => ProductsMenuPage(
                  isFromBuList: true,
                  currentBuId: buId,
                  currentBuName: buName,
                )));
  }

  void onTransaction({required String buId, required String buName}) {
    Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) =>
              TransactionsView(isFromBuList: true, buId: buId, buName: buName),
        ));
  }

  void onInvoiceTemPlate({required String buId, required String buName}) {
    Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) =>
              AddInvoiceTemplatePage(buId: buId, buName: buName),
        ));
  }

  void onBuDetails({required String buName, required String buId}) {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => ConnectionsBuDetailsPage(
                  buName: buName,
                  buId: buId,
                  isFromBuList: true,
                )));
  }

  static Future<Map<String, dynamic>> getOrgnizationBody(
      {required String? userId,
      required String? buId,
      required BusinessUnitModel? orgFieldsData}) async {
    List<Map<String, dynamic>> directorsArray = [];
    var directorsObject;
    List<Map<String, dynamic>> taxSchemeArray = [];
    var taxSchemeObject;
    List<Map<String, dynamic>> regulationArray = [];
    var regulationObject;
    List<Map<String, dynamic>> exportsArray = [];
    var exportsObject;
    List<Map<String, dynamic>> importsArray = [];
    var importsObject;
    var locationsObject;
    List<Map<String, dynamic>> bankReceiveArray = [];
    var bankReceiveObject;
    List<Map<String, dynamic>?> termsArray = [];
    var termsObject;

    if (orgFieldsData!.paymentTerms != null &&
        orgFieldsData.paymentTerms!.termsList!.length > 0) {
      for (int i = 0; i < orgFieldsData.paymentTerms!.termsList!.length; i++) {
        termsObject = {
          "term_type": orgFieldsData.paymentTerms!.termsList![i].termType,
          "term_description":
              orgFieldsData.paymentTerms!.termsList![i].termDescription,
          "file": orgFieldsData.paymentTerms!.termsList![i].file
        };
      }
      termsArray.add(termsObject);
    }

    if (orgFieldsData.directors != null &&
        orgFieldsData.directors!.length > 0) {
      for (int i = 0; i < orgFieldsData.directors!.length; i++) {
        directorsObject = {
          "id": "1",
          "person_name": orgFieldsData.directors![i].personName,
          "personidentification_schemename":
              orgFieldsData.directors![i].personidentificationSchemename,
          "personidentification_number":
              orgFieldsData.directors![i].personidentificationNumber,
          "digital_signature": orgFieldsData.directors![i].digitalSignature
        };
        directorsArray.add(directorsObject);
      }
    }
    List<Map<String, dynamic>> _locationsList = [];
    if (orgFieldsData.locationsList != null &&
        orgFieldsData.locationsList!.length > 0) {
      for (int i = 0; i < orgFieldsData.locationsList!.length; i++) {
        locationsObject = {
          "location_id": orgFieldsData.locationsList![i].locationId,
          "location_type": orgFieldsData.locationsList![i].locationType,
          "location_name": orgFieldsData.locationsList![i].locationName,
          "contact_person": orgFieldsData.locationsList![i].contactPerson,
          "contact_number": orgFieldsData.locationsList![i].contactNumber,
          "address": {
            "buildinghousenumber": orgFieldsData
                .locationsList![i].addressDetails!.buildinghousenumber,
            "building_no":
                orgFieldsData.locationsList![i].addressDetails!.buildingNo,
            "buildingstreetname": orgFieldsData
                .locationsList![i].addressDetails!.buildingstreetname,
            "colonysector_arealocality": orgFieldsData
                .locationsList![i].addressDetails!.colonysectorArealocality,
            "landmark":
                orgFieldsData.locationsList![i].addressDetails!.landmark,
            "country": orgFieldsData.locationsList![i].addressDetails!.country,
            "state": orgFieldsData.locationsList![i].addressDetails!.state,
            "plot_no": orgFieldsData.locationsList![i].addressDetails!.plotNo,
            "district":
                orgFieldsData.locationsList![i].addressDetails!.district,
            "villagetowncity":
                orgFieldsData.locationsList![i].addressDetails!.villagetowncity,
            "taluka": "",
            "postcode":
                orgFieldsData.locationsList![i].addressDetails!.postcode,
          }
        };
        _locationsList.add(locationsObject);
      }
    }

    if (orgFieldsData.taxScheme != null &&
        orgFieldsData.taxScheme!.length > 0) {
      for (int i = 0; i < orgFieldsData.taxScheme!.length; i++) {
        taxSchemeObject = {
          "id": "1",
          "govttaxscheme_name": orgFieldsData.taxScheme![i].schemeName,
          "govttaxscheme_number": orgFieldsData.taxScheme![i].schemeNumber,
          "taxexemption_reason": orgFieldsData.taxScheme![i].reason
        };
        taxSchemeArray.add(taxSchemeObject);
      }
    }
    if (orgFieldsData.regulation != null &&
        orgFieldsData.regulation!.length > 0) {
      for (int i = 0; i < orgFieldsData.regulation!.length; i++) {
        regulationObject = {
          "govtbusiness_schemeid":
              orgFieldsData.regulation![i].govtbusinessSchemeid,
          "govtregistration_id": orgFieldsData.regulation![i].govtregistrationId
        };
        regulationArray.add(regulationObject);
      }
    }

    if (orgFieldsData.exports != null && orgFieldsData.exports!.length > 0) {
      for (int i = 0; i < orgFieldsData.exports!.length; i++) {
        exportsObject = {
          "country": "india",
          "govtregistration_schemename":
              orgFieldsData.exports![i].govtregistrationSchemename,
          "govtregistration_schemeid":
              orgFieldsData.exports![i].govtregistrationSchemeid
        };
        exportsArray.add(exportsObject);
      }
    }

    if (orgFieldsData.imports != null && orgFieldsData.imports!.length > 0) {
      for (int i = 0; i < orgFieldsData.imports!.length; i++) {
        importsObject = {
          "country": "india",
          "govtregistration_schemename":
              orgFieldsData.imports![i].govtregistrationSchemename,
          "govtregistration_schemeid":
              orgFieldsData.imports![i].govtregistrationSchemeid
        };
        importsArray.add(importsObject);
      }
    }

    if (orgFieldsData.bankDetailsReceives != null &&
        orgFieldsData.bankDetailsReceives!.length > 0) {
      for (int i = 0; i < orgFieldsData.bankDetailsReceives!.length; i++) {
        bankReceiveObject = {
          "id": "",
          "BankName": orgFieldsData.bankDetailsReceives![i].bankName,
          "BankAccountName":
              orgFieldsData.bankDetailsReceives![i].bankAccountName,
          "BankAccountNumber":
              orgFieldsData.bankDetailsReceives![i].bankAccountNumber,
          "EPayCode": orgFieldsData.bankDetailsReceives![i].ePayCode,
          "SWIFTcode": orgFieldsData.bankDetailsReceives![i].swifTcode,
          "MICRCode": orgFieldsData.bankDetailsReceives![i].micrCode,
          "IFSC Code": orgFieldsData.bankDetailsReceives![i].ifscCode,
          "show_bank_details":
              orgFieldsData.bankDetailsReceives![i].isShowBankDataInInvoice
        };
        bankReceiveArray.add(bankReceiveObject);
      }
    }

    num? advancePaymentValue = 0;
    String advancePaymentType = "";

    if (orgFieldsData.paymentTerms!.advancePayment!.isActive == true &&
        orgFieldsData.paymentTerms!.advancePayment!.value != null) {
      advancePaymentValue = orgFieldsData.paymentTerms!.advancePayment!.value;
      advancePaymentType = "percentage";
    }

    num? penaltyAmountValue = 0;
    String penaltyAmountType = "";

    if (orgFieldsData.paymentTerms!.penaltyAmount != null) {
      penaltyAmountValue = orgFieldsData.paymentTerms!.penaltyAmount!.value;
      penaltyAmountType = "percentage";
    }

    /// Preparing bu object
    Map<String, dynamic> data = {
      "id": buId,
      "user_id": userId,
      "business_name": orgFieldsData.businessName,
      "short_name": orgFieldsData.shortName,
      "mobile_number": orgFieldsData.mobileNumber,
      "website": orgFieldsData.website,
      "head_of_business": orgFieldsData.businessHob,
      "locations": _locationsList,
      "contact_number": orgFieldsData.buContactNumber,
      "type": orgFieldsData.type,
      "country_code":
          orgFieldsData.countryCode != null ? orgFieldsData.countryCode : "",
      "currency_code":
          orgFieldsData.currencyCode != null ? orgFieldsData.currencyCode : "",
      "currency_symbol": orgFieldsData.currencySymbol,
      "location": orgFieldsData.businessLocation,
      "registration": {
        "govtregistered_name": orgFieldsData.registration!.govtregisteredName,
        "legalentity_type": orgFieldsData.registration!.legalentityType,
        "govtregistration_scheme": "",
        "registration_date": orgFieldsData.registration!.registrationDate,
        "registration_city": orgFieldsData.registration!.registrationCity,
        "registration_state": orgFieldsData.registration!.registrationState,
        "registration_country": orgFieldsData.registration!.registrationCountry,
        "pan_number": "",
        "cin_number": ""
      },
      "directors": directorsArray,
      "tax_scheme": taxSchemeArray,
      "parent_details": orgFieldsData.parentDetails,
      "contact_details": {
        "primarycontactname": orgFieldsData.contactDetails!.contactName,
        "address": {
          "businesslocationnumber":
              orgFieldsData.contactDetails!.address!.villagetowncity,
          "buildinghousenumber":
              orgFieldsData.contactDetails!.address!.buildinghousenumber,
          "building_no": orgFieldsData.contactDetails!.address!.buildingNo,
          "buildingstreetname":
              orgFieldsData.contactDetails!.address!.buildingstreetname,
          "colonysector_arealocality":
              orgFieldsData.contactDetails!.address!.colonysectorArealocality,
          "villagetowncity":
              orgFieldsData.contactDetails!.address!.villagetowncity,
          "taluk": orgFieldsData.contactDetails!.address!.taluk,
          "plot_no": orgFieldsData.contactDetails!.address!.plotNo,
          "landmark": orgFieldsData.contactDetails!.address!.landmark,
          "state": orgFieldsData.contactDetails!.address!.state,
          "district": orgFieldsData.contactDetails!.address!.district,
          "postcode": orgFieldsData.contactDetails!.address!.postcode,
          "country": orgFieldsData.contactDetails!.address!.country,
          "phone_number_on_invoice":
              orgFieldsData.contactDetails!.address!.phoneNumberOnInvoice,
          "email_on_invoice":
              orgFieldsData.contactDetails!.address!.emailOnInvoice
        }
      },
      "regulation": regulationArray,
      "exports": exportsArray,
      "imports": importsArray,
      "payment_terms": {
        "id": "",
        "invoice_currency_code":
            orgFieldsData.paymentTerms!.invoicecurrencycode,
        "invoice_payment_terms":
            orgFieldsData.paymentTerms!.invoicePaymentTerms,
        "term_code": orgFieldsData.paymentTerms!.termCode,
        "days": orgFieldsData.paymentTerms!.paymentTermsDays,
        "penalty_amount": {
          "code": orgFieldsData.paymentTerms!.penaltyAmount!.code,
          "reason": orgFieldsData.paymentTerms!.penaltyAmount!.reason,
          "value": penaltyAmountValue,
          "type": penaltyAmountType,
        },
        "comments": orgFieldsData.paymentTerms!.comment,
        "advance_payment": {
          "active": orgFieldsData.paymentTerms!.advancePayment!.isActive,
          "value": advancePaymentValue,
          "type": advancePaymentType
        },
        "terms": termsArray,
      },
      "bank_details_receives": bankReceiveArray,
      "bank_details_payments": [],
      "roles": orgFieldsData.rolesList,
      "confirm_order": orgFieldsData.isInpersonOrderAccept,
      "GST_No": orgFieldsData.orgGstNumber,
      "dial_code": orgFieldsData.dialCode,
      "office_dial_code": orgFieldsData.officeDialCode,
      "currency_name": orgFieldsData.currencyName
    };

    return data;
  }

  @override
  String getTag() {
    return 'organization_controller';
  }
}
