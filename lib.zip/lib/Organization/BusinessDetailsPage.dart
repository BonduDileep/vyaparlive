import 'package:vyaparlive/service/api_service/UserApiService.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/TextView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/model/BusinessUnitModel.dart';
import 'package:vyaparlive/model/CitiesDAO.dart';
import 'package:vyaparlive/model/CountryDAO.dart';
import 'package:vyaparlive/model/StatesDAO.dart';
import 'package:vyaparlive/model/StockDetailsModel.dart';
import 'package:vyaparlive/model/UserModel.dart';
import 'package:vyaparlive/service/Service.dart';
import 'package:vyaparlive/service/user_services.dart';

import '../service/api_service/lookup_api_service/CountryApiService.dart';

class BusinessDetailsView extends StatefulWidget {
  final String? orgId;
  BusinessDetailsView({this.orgId});

  @override
  _BusinessDetailsViewState createState() => _BusinessDetailsViewState();
}

class _BusinessDetailsViewState extends State<BusinessDetailsView> {
  BusinessUnitModel? _buModel;
  var _primaryContactNameController = TextEditingController();
  var _addressController = TextEditingController();
  var _plotNumberController = TextEditingController();

  var _buildinghouseNumberController = TextEditingController();
  final _buildingNoController = TextEditingController();
  var _buildingStreetNameController = TextEditingController();
  var _colonysectorarealocalityController = TextEditingController();
  var _villagetowncityController = TextEditingController();
  var _taluknameController = TextEditingController();
  var _landmarkController = TextEditingController();
  var _stateController = TextEditingController();
  var _districtController = TextEditingController();
  var _postcodeController = TextEditingController();
  var _countryController = TextEditingController();

  StatesDAO? statesDropdownValue;
  List<String> _districtList = [];
  List<StatesDAO> _statesList = [];
  String? districtDropdownValue;
  List<CountryDAO> _countryList = [];
  CountryDAO? countryDropdownValue;
  late Service _service;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  bool? isOrgUpdate = false;
  bool isLoading = false;
  // ProgressDialog progressDialog;
  String? creatingBuName = '';
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  List<String> _citiesList = [];
  String? citiesDropDownValue;
  final _stockReceiveLocationController = TextEditingController();
  final _stockReceiveBussinessController = TextEditingController();
  final _stockReceiveHouseNoController = TextEditingController();
  final _stockReceiveBuildingNoController = TextEditingController();
  final _stockReceivePlotNoController = TextEditingController();
  final _stockReceiveStreetNameController = TextEditingController();
  final _stockReceiveLocalityController = TextEditingController();
  final _stockReceiveLandmarkController = TextEditingController();
  final _stockReceiveCityController = TextEditingController();
  final _stockReceivePostalController = TextEditingController();
  final _addressreceivernameController = TextEditingController();
  final _addressreceiverfullController = TextEditingController();
  final _addressreceivercontactnumberController = TextEditingController();
  final List<StockDetailsModel> _storeStockReceiveData = [];
  final List<StockDetailsModel> _storeStockDispatchData = [];
  List<String> _stockReceiveDistrictList = [];
  List<StatesDAO> _stockStatesList = [];
  String? stockReceiveDistrictDropdownValue;
  StatesDAO? stockStatesDropdownValue;
  CountryDAO? stockCountryDropdownValue;
  List<String> _stockReceiveCitiesList = [];
  String? stockReceiveCitiesDropDownValue;
  List<String> _stockDispatchCitiesList = [];
  String? stockDispatchCitiesDropDownValue;
  UserModel? usersDropdownValue;
  late List<UserModel> _usersList = [];
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  late UserService _userService;
  String? buId = "";
  TextEditingController _phoneNumberController = new TextEditingController();
  TextEditingController _emailController = new TextEditingController();
  late ThemeData theme;

  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    AppController.instance.setCreateBuProgress = false;
    buId = widget.orgId;
    _userService = UserService();
    _service = Service();
    isOrgUpdate = AppController.instance.isOrganizationUpdate;
    creatingBuName =
        AppController.instance.organizationFieldsData!.businessName != null
            ? AppController.instance.organizationFieldsData!.businessName
            : "";

    if (isOrgUpdate!) {
      updateContactDetails();
    } else {
      loadDropdownValues();
    }
  }

  loadDropdownValues() async {
    if (await NetworkStatus.getInternetStatus()) {
      final countryData = await CountryApiService.instance.getCountries();
      if (countryData.isNotEmpty) {
        setState(() {
          _countryList.addAll(countryData);
          if (_countryList.length > 0) {
            for (int i = 0; i < _countryList.length; i++) {
              if (isOrgUpdate! &&
                  _buModel != null &&
                  _buModel!.contactDetails != null &&
                  _buModel!.contactDetails!.address != null) {
                if (_buModel!.contactDetails!.address!.country ==
                    _countryList[i].name) {
                  countryDropdownValue = _countryList[i];
                  break;
                }
              }
              if (_countryList[i].name == "India") {
                countryDropdownValue = _countryList[i];
                break;
              }
            }
            AppController.instance.getOrganizationFieldsData.country =
                countryDropdownValue!.name;
            if (AppController
                    .instance.getOrganizationFieldsData.regOrgCountry ==
                null) {
              AppController.instance.getOrganizationFieldsData.regOrgCountry =
                  countryDropdownValue!.name;
            }
          }
        });

        if (countryDropdownValue != null) {
          loadStatesDropDown(countryDropdownValue!.name!);
        }
      }
      _fetchUserDetails();
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  void _fetchUserDetails() async {
    isLoadingProgress = true;
    final fetchedData = await UserApiService.instance.getUsersByBuId(
        context, buId!,
        langError: Language().getString(Constants.ERROR, selectedLang),
        langOk: Language().getString(Constants.OKAY_STR, selectedLang));

    setState(() {
      _usersList.addAll(fetchedData);
      isLoadingProgress = false;
    });
  }

  loadStatesDropDown(String countryName) async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = Constants.GETTING_STATES;
      // AppController.instance.setCreateBuProgress = true;
    });
    List<StatesDAO> statesData =
        await CountryApiService.instance.getStates(countryName: countryName);
    setState(() {
      _statesList.addAll(statesData);
      if (_statesList.length > 0 &&
          isOrgUpdate! &&
          _buModel != null &&
          _buModel!.contactDetails != null &&
          _buModel!.contactDetails!.address != null) {
        for (var element in _statesList) {
          if (_buModel!.contactDetails!.address!.state == element.state) {
            _districtList.clear();
            statesDropdownValue = element;
            _districtList.addAll(element.cities!);
            AppController.instance.getOrganizationFieldsData.state =
                statesDropdownValue!.state;
            break;
          }
        }

        for (var element in _districtList) {
          if (_buModel!.contactDetails!.address!.district == element) {
            districtDropdownValue = element;
            AppController.instance.getOrganizationFieldsData.district =
                districtDropdownValue;
            break;
          }
        }
      }
    });
    if (statesDropdownValue != null) {
      _fetchCitiesData(countryName, statesDropdownValue!.state!);
    }
  }

  void _fetchCitiesData(String countryName, String stateId) async {
    List<CitiesDAO> fetchCitiesData =
        await CountryApiService.instance.getCitiesList(countryName, stateId);
    if (fetchCitiesData.length > 0) {
      setState(() {
        _citiesList.addAll(fetchCitiesData[0].cities!);
        if (isOrgUpdate! &&
            _buModel != null &&
            _buModel!.contactDetails != null &&
            _buModel!.contactDetails!.address != null) {
          for (var element in _citiesList) {
            if (_buModel!.contactDetails!.address!.villagetowncity == element) {
              citiesDropDownValue = element;
              AppController.instance.getOrganizationFieldsData.city = element;
              break;
            }
          }
        }
      });
    }
  }

  /// Creating State lookup

  buildStateDropdown(String text) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                        Language().getString(
                            Constants.STATE_NAME_STRING, selectedLang),
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_15,
                            fontWeight: FontWeight.w500,
                            fontFamily: StyleView.FONT_TITLE))),
              )),
        ),
        Expanded(
          flex: 2,
          child: Container(
              color: Colors.white70,
              padding: EdgeInsets.only(left: 5, right: 5),
              child: DropdownButton<StatesDAO>(
                  onTap: () {
                    return CommonMethods.hideKeyboard(context);
                  },
                  value: statesDropdownValue,
                  isExpanded: true,
                  hint: Text(
                      Language()
                          .getString(Constants.SELECT_STATE, selectedLang),
                      style: TextStyle(fontFamily: StyleView.FONT_TITLE)),
                  underline: SizedBox(),
                  onChanged: (StatesDAO? data) {
                    _districtList.clear();
                    districtDropdownValue = null;
                    citiesDropDownValue = null;
                    _citiesList.clear();
                    setState(() {
                      statesDropdownValue = data;
                      _districtList.addAll(data!.cities!);
                    });
                    AppController.instance.getOrganizationFieldsData.state =
                        data!.state;
                    if (AppController
                            .instance.getOrganizationFieldsData.regOrgState ==
                        null) {
                      AppController.instance.getOrganizationFieldsData
                          .regOrgState = data.state;
                    }
                    citiesDropDownValue = null;
                    _citiesList.clear();
                    _fetchCitiesData(
                        countryDropdownValue!.name!, statesDropdownValue!.id!);
                  },
                  items: _statesList.map((StatesDAO model) {
                    return new DropdownMenuItem<StatesDAO>(
                      child: new Text(model.state!,
                          style: TextStyle(fontFamily: StyleView.FONT_TITLE)),
                      value: model,
                    );
                  }).toList())),
        )
      ],
    );
  }

  /// City Dropdown
  buildCityDropdown(String text) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(Language().getString(text, selectedLang),
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_15,
                            fontWeight: FontWeight.w500,
                            fontFamily: StyleView.FONT_TITLE))),
              )),
        ),
        Expanded(
          flex: 2,
          child: Container(
              color: Colors.white70,
              padding: EdgeInsets.only(left: 5, right: 5),
              child: DropdownButton<String>(
                  onTap: () {
                    return CommonMethods.hideKeyboard(context);
                  },
                  value: citiesDropDownValue,
                  isExpanded: true,
                  hint: Text(
                    Language().getString(Constants.SELECT_CITY, selectedLang),
                    style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                  ),
                  underline: SizedBox(),
                  onChanged: (String? data) {
                    setState(() {
                      citiesDropDownValue = data;
                    });
                    AppController.instance.getOrganizationFieldsData.city =
                        data;

                    if (AppController
                            .instance.getOrganizationFieldsData.regOrgCity ==
                        null) {
                      AppController
                          .instance.getOrganizationFieldsData.regOrgCity = data;
                    }
                  },
                  items: _citiesList.map((String model) {
                    return new DropdownMenuItem<String>(
                      child: new Text(model,
                          style: TextStyle(fontFamily: StyleView.FONT_TITLE)),
                      value: model,
                    );
                  }).toList())),
        )
      ],
    );
  }

  /// Creating district lookup

  buildDistrictDropdown(String text) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                        Language()
                            .getString(Constants.DISTRICT_STRING, selectedLang),
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_15,
                            fontWeight: FontWeight.w500,
                            fontFamily: StyleView.FONT_TITLE))),
              )),
        ),
        Expanded(
          flex: 2,
          child: Container(
              color: Colors.white70,
              padding: EdgeInsets.only(left: 5, right: 5),
              child: DropdownButton<String>(
                  onTap: () {
                    return CommonMethods.hideKeyboard(context);
                  },
                  value: districtDropdownValue,
                  isExpanded: true,
                  hint: Text(
                      Language()
                          .getString(Constants.SELECT_DISTRICT, selectedLang),
                      style: TextStyle(fontFamily: StyleView.FONT_TITLE)),
                  underline: SizedBox(),
                  onChanged: (String? data) {
                    setState(() {
                      districtDropdownValue = data;
                    });
                    AppController.instance.getOrganizationFieldsData.district =
                        data;
                  },
                  items: _districtList.map((String model) {
                    return new DropdownMenuItem<String>(
                      child: new Text(model,
                          style: TextStyle(fontFamily: StyleView.FONT_TITLE)),
                      value: model,
                    );
                  }).toList())),
        )
      ],
    );
  }

  /// Creating country lookup

  buildCountryDropdown(String text) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                        Language().getString(
                            Constants.COUNTRY_NAME_STRING, selectedLang),
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_15,
                            fontWeight: FontWeight.w500,
                            fontFamily: StyleView.FONT_TITLE))),
              )),
        ),
        Expanded(
          flex: 2,
          child: Container(
              color: Colors.white70,
              padding: EdgeInsets.only(left: 5, right: 5),
              child: DropdownButton<CountryDAO>(
                  onTap: () {
                    return CommonMethods.hideKeyboard(context);
                  },
                  value: countryDropdownValue,
                  isExpanded: true,
                  hint: Text(
                      Language()
                          .getString(Constants.SELECT_COUNTRY, selectedLang),
                      style: TextStyle(fontFamily: StyleView.FONT_TITLE)),
                  underline: SizedBox(),
                  onChanged: (CountryDAO? data) {
                    setState(() {
                      countryDropdownValue = data;
                      loadStatesDropDown(countryDropdownValue!.name!);
                    });
                    AppController.instance.getOrganizationFieldsData.country =
                        data!.name;
                    if (AppController
                            .instance.getOrganizationFieldsData.regOrgCountry ==
                        null) {
                      AppController.instance.getOrganizationFieldsData
                          .regOrgCountry = data.name;
                    }
                  },
                  items: _countryList.map((CountryDAO model) {
                    return new DropdownMenuItem<CountryDAO>(
                      child: new Text(model.name!,
                          style: TextStyle(fontFamily: StyleView.FONT_TITLE)),
                      value: model,
                    );
                  }).toList())),
        )
      ],
    );
  }

  /// Fecthing contacts details when screen comes for update

  void updateContactDetails() {
    _buModel = AppController.instance.getBusinessUnitData;
    if (_buModel != null) {
      if (_buModel!.contactDetails != null &&
          _buModel!.contactDetails!.address != null) {
        _primaryContactNameController.text =
            _buModel!.contactDetails!.primarycontactname!;
        _addressController.text =
            _buModel!.contactDetails!.address!.addressformat!;
        _plotNumberController.text = _buModel!.contactDetails!.address!.plotNo!;
        _buildinghouseNumberController.text =
            _buModel!.contactDetails!.address!.buildinghousenumber!;
        _buildingNoController.text =
            _buModel!.contactDetails!.address!.buildingNo!;
        _buildingStreetNameController.text =
            _buModel!.contactDetails!.address!.buildingstreetname!;
        _colonysectorarealocalityController.text =
            _buModel!.contactDetails!.address!.businesslocationnumber!;
        _villagetowncityController.text =
            _buModel!.contactDetails!.address!.villagetowncity != null
                ? _buModel!.contactDetails!.address!.villagetowncity!
                : "";
        _taluknameController.text = _buModel!.contactDetails!.address!.taluk!;
        _landmarkController.text = _buModel!.contactDetails!.address!.landmark!;
        _stateController.text = _buModel!.contactDetails!.address!.state != null
            ? _buModel!.contactDetails!.address!.state!
            : "";
        _districtController.text =
            _buModel!.contactDetails!.address!.district != null
                ? _buModel!.contactDetails!.address!.district!
                : "";
        _postcodeController.text = _buModel!.contactDetails!.address!.postcode!;
        _countryController.text =
            _buModel!.contactDetails!.address!.country != null
                ? _buModel!.contactDetails!.address!.country!
                : "";
        _phoneNumberController.text =
            _buModel!.contactDetails!.address!.phoneNumberOnInvoice!;
        _emailController.text =
            _buModel!.contactDetails!.address!.emailOnInvoice!;

        AppController.instance.getOrganizationFieldsData.contactName =
            _primaryContactNameController.text;
        AppController.instance.getOrganizationFieldsData.contactAddress =
            _addressController.text;
        AppController.instance.getOrganizationFieldsData.orgPlotNo =
            _plotNumberController.text;
        AppController.instance.getOrganizationFieldsData.houseNo =
            _buildinghouseNumberController.text;
        AppController.instance.getOrganizationFieldsData.buildingNo =
            _buildingNoController.text;
        AppController.instance.getOrganizationFieldsData.streetName =
            _buildingStreetNameController.text;
        AppController.instance.getOrganizationFieldsData.locality =
            _colonysectorarealocalityController.text;
        AppController.instance.getOrganizationFieldsData.city =
            _villagetowncityController.text;
        AppController.instance.getOrganizationFieldsData.taluk =
            _taluknameController.text;
        AppController.instance.getOrganizationFieldsData.landMark =
            _landmarkController.text;
        AppController.instance.getOrganizationFieldsData.postalCode =
            _postcodeController.text;
        AppController.instance.getOrganizationFieldsData.invoicePhoneNumber =
            _phoneNumberController.text;
        AppController.instance.getOrganizationFieldsData.invoiceEmail =
            _emailController.text;
      }

      for (int i = 0; i < _buModel!.locationsList!.length; i++) {
        if (_buModel!.locationsList![i].locationType ==
            Constants.KEY_STOCK_RECEIVE) {
          _storeStockReceiveData.add(StockDetailsModel(
              locationId: _buModel!.locationsList![i].locationId,
              locationType: _buModel!.locationsList![i].locationType,
              stockLocationNumber: _buModel!.locationsList![i].contactNumber,
              stockLocationName: _buModel!.locationsList![i].locationName,
              userName: _buModel!.locationsList![i].contactPerson,
              houseNo: _buModel!
                  .locationsList![i].addressDetails!.buildinghousenumber,
              buildingNo:
                  _buModel!.locationsList![i].addressDetails!.buildingNo,
              streetName: _buModel!
                  .locationsList![i].addressDetails!.buildingstreetname,
              locality: _buModel!
                  .locationsList![i].addressDetails!.colonysectorArealocality,
              landmark: _buModel!.locationsList![i].addressDetails!.landmark,
              country: _buModel!.locationsList![i].addressDetails!.country,
              state: _buModel!.locationsList![i].addressDetails!.state,
              district: _buModel!.locationsList![i].addressDetails!.district,
              city: _buModel!.locationsList![i].addressDetails!.villagetowncity,
              taluka: "",
              plotNo: _buModel!.locationsList![i].addressDetails!.plotNo,
              postalCode:
                  _buModel!.locationsList![i].addressDetails!.postcode));
        } else if (_buModel!.locationsList![i].locationType ==
            Constants.KEY_MAIN_OFFICE) {
          AppController.instance.getOrganizationFieldsData
              .mainOfficeLocationId = _buModel!.locationsList![i].locationId;
        }
      }
      AppController.instance.getOrganizationFieldsData.stockReceiveArray =
          _storeStockReceiveData;
      AppController.instance.getOrganizationFieldsData.stockDispatchArray =
          _storeStockDispatchData;

      loadDropdownValues();
    }
  }

  /// Creating highlite text

  buildTextField(String _text) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 5.0),
      child: Row(
        children: <Widget>[
          Text(
            _text,
            style: TextStyle(
                fontSize: StyleView.FONT_SIZE_15,
                fontFamily: StyleView.FONT_TITLE,
                color: Colors.black, //(Constants.APP_COLOR),
                fontWeight: FontWeight.bold),
          )
        ],
      ),
    );
  }

  /// Dynamically creating contact details fields

  buildTableContent(
    String textName,
    TextEditingController _controller,
  ) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(Language().getString(textName, selectedLang),
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_15,
                            fontWeight: FontWeight.w500,
                            fontFamily: StyleView.FONT_TITLE))),
              )),
        ),
        Expanded(
            flex: 2,
            child: Container(
              color: Colors.white70,
              padding: EdgeInsets.only(left: 5),
              child: TextFormField(
                controller: _controller,
                // focusNode: FocusNode(canRequestFocus: false),
                keyboardType: (textName == Constants.PIN_CODE)
                    ? TextInputType.numberWithOptions(signed: true)
                    : TextInputType.text,
                textInputAction: TextInputAction.done,
                style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                decoration: InputDecoration(
                  hintText: Language().getString(textName, selectedLang),
                  border: InputBorder.none,
                ),
                onChanged: (text) => {
                  text = _controller.text,
                  updateData(textName, _controller.text)
                },
              ),
            ))
      ],
    );
  }

  buildPincodeView(
      String lableText, TextEditingController _controlle, num inputLength) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
            height: 50,
            color: Color(Constants.GREY_COLOR_LIGHT),
            child: Container(
              padding: EdgeInsets.only(left: 10),
              child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(Language().getString(lableText, selectedLang),
                      style: TextStyle(
                          fontSize: StyleView.FONT_SIZE_15,
                          fontWeight: FontWeight.w500,
                          fontFamily: StyleView.FONT_TITLE))),
            ),
          ),
        ),
        Expanded(
            flex: 2,
            child: Container(
              color: Colors.white70,
              padding: EdgeInsets.only(left: 5),
              child: TextFormField(
                controller: _controlle,
                keyboardType: TextInputType.numberWithOptions(signed: true),
                textInputAction: TextInputAction.next,
                style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                decoration: InputDecoration(
                  hintText: Language().getString(lableText, selectedLang),
                  border: InputBorder.none,
                ),
                inputFormatters: [
                  new LengthLimitingTextInputFormatter(inputLength as int?),
                  FilteringTextInputFormatter.digitsOnly
                ],
                onChanged: (text) {
                  updateData(lableText, _controlle.text);
                },
              ),
            ))
      ],
    );
  }

  /// Updating input fields data onChanged()

  void updateData(String fieldName, String text) {
    switch (fieldName) {
      case Constants.NAME_STRING:
        AppController.instance.organizationFieldsData!.contactName = text;
        break;

      case Constants.ADDRESS:
        AppController.instance.organizationFieldsData!.contactAddress = text;
        break;
      case Constants.PLOT_NO:
        AppController.instance.getOrganizationFieldsData.orgPlotNo = text;
        break;

      case Constants.BUILDING_HOUSE_NUMBER_STRING:
        AppController.instance.organizationFieldsData!.houseNo = text;
        break;
      case Constants.BULIDING:
        AppController.instance.organizationFieldsData!.buildingNo = text;
        break;
      case Constants.BUILDING_STREET_NAME_STRING:
        AppController.instance.organizationFieldsData!.streetName = text;
        break;
      case Constants.COLONY_SELECTOR_AREA_LOCALITY_STRING:
        AppController.instance.organizationFieldsData!.locality = text;

        break;
      case Constants.TALUK_STRING:
        AppController.instance.organizationFieldsData!.taluk = text;
        break;
      case Constants.LAND_MARK_STRING:
        AppController.instance.organizationFieldsData!.landMark = text;
        break;
      case Constants.COLONY_SELECTOR_AREA_LOCALITY_STRING:
        AppController.instance.organizationFieldsData!.landMark = text;
        break;
      case Constants.PIN_CODE:
        AppController.instance.organizationFieldsData!.postalCode = text;
        break;
      case Constants.PHONE_NUMBER:
        AppController.instance.organizationFieldsData!.invoicePhoneNumber =
            text;

        break;
      case Constants.EMAIL:
        AppController.instance.organizationFieldsData!.invoiceEmail = text;
        break;
      default:
    }
  }

  @override
  void setState(VoidCallback fn) {
    // TODO: implement setState
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          margin: EdgeInsets.only(top: 10),
          child: SingleChildScrollView(
              padding: EdgeInsets.all(10.0),
              child: Container(
                  child: isLoading
                      ? Center(child: CircularProgressIndicator())
                      : Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Container(
                                margin: EdgeInsets.symmetric(vertical: 5.0),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(5.0),
                                  child: Container(
                                    color: Colors.white,
                                    child: ExpansionTile(
                                      title: Text(
                                        Language().getString(
                                            Constants.MAIN_OFFICE,
                                            selectedLang),
                                        style: TextStyle(
                                            color: Colors.black,
                                            fontWeight: FontWeight.w600),
                                      ),
                                      children: <Widget>[
                                        Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: <Widget>[
                                              Container(
                                                  margin: EdgeInsets.symmetric(
                                                      vertical: 5.0,
                                                      horizontal: 10.0),
                                                  child: Text(
                                                      "* " +
                                                          Language().getString(
                                                              Constants
                                                                  .ADDRESS_PRINT_ON_INVOICE,
                                                              selectedLang),
                                                      style: TextStyle(
                                                        color: Colors.red,
                                                        fontSize: 13.0,
                                                      ))),
                                              SizedBox(
                                                  height: 1,
                                                  child: Container(
                                                    color: Color(
                                                        Constants.GREY_COLOR),
                                                  )),
                                              Container(
                                                  child: Row(
                                                children: <Widget>[
                                                  Expanded(
                                                    child: Container(
                                                        height: 50,
                                                        color: Color(Constants
                                                            .GREY_COLOR_LIGHT),
                                                        child: Container(
                                                          padding:
                                                              EdgeInsets.only(
                                                                  left: 10),
                                                          child: Align(
                                                              alignment: Alignment
                                                                  .centerLeft,
                                                              child: Text(
                                                                  Language().getString(
                                                                      Constants
                                                                          .BUSSINESS_INPUT_STRING,
                                                                      selectedLang),
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          StyleView
                                                                              .FONT_SIZE_15,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w500,
                                                                      fontFamily:
                                                                          'IndianRupee'))),
                                                        )),
                                                  ),
                                                  Expanded(
                                                      flex: 2,
                                                      child: Container(
                                                          height: 50.0,
                                                          color: Colors.white70,
                                                          padding:
                                                              EdgeInsets.only(
                                                                  left: 5),
                                                          child: Align(
                                                              alignment: Alignment
                                                                  .centerLeft,
                                                              child: Text(
                                                                  creatingBuName!,
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          15.0)))))
                                                ],
                                              )),
                                              SizedBox(
                                                  height: 1,
                                                  child: Container(
                                                    color: Color(
                                                        Constants.GREY_COLOR),
                                                  )),
                                              buildPincodeView(
                                                  Constants.PHONE_NUMBER,
                                                  _phoneNumberController,
                                                  10),
                                              SizedBox(
                                                  height: 1,
                                                  child: Container(
                                                    color: Color(
                                                        Constants.GREY_COLOR),
                                                  )),
                                              buildTableContent(Constants.EMAIL,
                                                  _emailController),
                                              SizedBox(
                                                  height: 1,
                                                  child: Container(
                                                    color: Color(
                                                        Constants.GREY_COLOR),
                                                  )),
                                              buildTableContent(
                                                  Constants.PLOT_NO,
                                                  _plotNumberController),
                                              SizedBox(
                                                  height: 1,
                                                  child: Container(
                                                    color: Color(
                                                        Constants.GREY_COLOR),
                                                  )),
                                              buildTableContent(
                                                  Constants
                                                      .BUILDING_HOUSE_NUMBER_STRING,
                                                  _buildinghouseNumberController),
                                              SizedBox(
                                                  height: 1,
                                                  child: Container(
                                                    color: Color(
                                                        Constants.GREY_COLOR),
                                                  )),
                                              buildTableContent(
                                                  Constants.BULIDING,
                                                  _buildingNoController),
                                              SizedBox(
                                                  height: 1,
                                                  child: Container(
                                                    color: Color(
                                                        Constants.GREY_COLOR),
                                                  )),
                                              buildTableContent(
                                                  Constants
                                                      .BUILDING_STREET_NAME_STRING,
                                                  _buildingStreetNameController),
                                              SizedBox(
                                                  height: 1,
                                                  child: Container(
                                                    color: Color(
                                                        Constants.GREY_COLOR),
                                                  )),
                                              buildTableContent(
                                                  Constants
                                                      .COLONY_SELECTOR_AREA_LOCALITY_STRING,
                                                  _colonysectorarealocalityController),
                                              SizedBox(
                                                  height: 1,
                                                  child: Container(
                                                    color: Color(
                                                        Constants.GREY_COLOR),
                                                  )),
                                              buildTableContent(
                                                  Constants.LAND_MARK_STRING,
                                                  _landmarkController),
                                              SizedBox(
                                                  height: 1,
                                                  child: Container(
                                                    color: Color(
                                                        Constants.GREY_COLOR),
                                                  )),
                                              buildCountryDropdown(Constants
                                                  .COUNTRY_NAME_STRING),
                                              SizedBox(
                                                  height: 1,
                                                  child: Container(
                                                    color: Color(
                                                        Constants.GREY_COLOR),
                                                  )),
                                              buildStateDropdown(
                                                  Constants.STATE_NAME_STRING),
                                              SizedBox(
                                                  height: 1,
                                                  child: Container(
                                                    color: Color(
                                                        Constants.GREY_COLOR),
                                                  )),
                                              buildDistrictDropdown(
                                                  Constants.DISTRICT_STRING),
                                              SizedBox(
                                                  height: 1,
                                                  child: Container(
                                                    color: Color(
                                                        Constants.GREY_COLOR),
                                                  )),
                                              buildCityDropdown(
                                                  Constants.CITY_NAME_STRING),
                                              SizedBox(
                                                  height: 1,
                                                  child: Container(
                                                    color: Color(
                                                        Constants.GREY_COLOR),
                                                  )),
                                              buildPincodeView(
                                                  Constants.PIN_CODE,
                                                  _postcodeController,
                                                  6)
                                            ])
                                      ],
                                    ),
                                  ),
                                )),
                            Container(
                              margin: EdgeInsets.symmetric(
                                vertical: 10.0,
                              ),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: <Widget>[
                                  buildTextField(Language().getString(
                                      Constants.STOCK_RECIVERS_LOCATIONS,
                                      selectedLang)),
                                  controllAllAddView(
                                      Constants.STOCK_RECIVERS_LOCATIONS)
                                ],
                              ),
                            ),
                            Container(
                                child: _storeStockReceiveData.length == 0
                                    ? new Container()
                                    : createStockReceiveLocationDynamically(
                                        Language().getString(
                                            Constants.STOCK_RECEIVE,
                                            selectedLang),
                                        _storeStockReceiveData)),
                          ],
                        ))),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    );
  }

  createStockReceiveLocationDynamically(
      String? _title, List<StockDetailsModel> _stockLocationsData) {
    return Column(
      children: <Widget>[
        for (int i = 0; i < _stockLocationsData.length; i++)
          Column(
            children: <Widget>[
              ClipRRect(
                borderRadius: BorderRadius.circular(5.0),
                child: Container(
                  color: Colors.white,
                  child: ExpansionTile(
                    title: Row(
                      children: [
                        Expanded(
                            child: buildRichText(
                                _stockLocationsData[i].stockLocationName)),
                        Container(
                          alignment: Alignment.centerRight,
                          child: IconButton(
                            icon: Icon(Icons.edit,
                                color: Colors.black //(Constants.APP_COLOR),
                                ),
                            onPressed: () {
                              if (_title ==
                                  Language().getString(
                                      Constants.STOCK_RECEIVE, selectedLang)) {
                                buildStockReceiveFields(
                                    Language().getString(_title, selectedLang),
                                    _stockReceiveLocationController,
                                    _stockReceiveBussinessController,
                                    _stockReceiveHouseNoController,
                                    _stockReceiveStreetNameController,
                                    _stockReceiveLocalityController,
                                    _stockReceiveLandmarkController,
                                    _stockReceiveCityController,
                                    _stockReceivePostalController,
                                    _stockReceiveBuildingNoController,
                                    _stockReceivePlotNoController,
                                    _stockLocationsData[i],
                                    i,
                                    true);
                              }
                            },
                          ),
                        ),
                      ],
                    ),
                    children: <Widget>[
                      Container(
                          child: Column(
                        children: <Widget>[
                          SizedBox(
                              height: 1,
                              child: new Container(
                                  color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language().getString(
                                  Constants.LOCATION_PHONE_NUMBER,
                                  selectedLang),
                              value:
                                  _stockLocationsData[i].stockLocationNumber),
                          // SizedBox(
                          //     height: 1,
                          //     child: Container(
                          //         color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language().getString(
                                  Constants.LOCATION_NAME, selectedLang),
                              value: _stockLocationsData[i].stockLocationName),
                          // SizedBox(
                          //     height: 1,
                          //     child: Container(
                          //         color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language()
                                  .getString(Constants.PLOT_NO, selectedLang),
                              value: _stockLocationsData[i].plotNo),
                          // SizedBox(
                          //     height: 1,
                          //     child: Container(
                          //         color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language()
                                  .getString(Constants.BULIDING, selectedLang),
                              value: _stockLocationsData[i].buildingNo),
                          // SizedBox(
                          //     height: 1,
                          //     child: Container(
                          //         color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language().getString(
                                  Constants.BUILDING_HOUSE_NUMBER_STRING,
                                  selectedLang),
                              value: _stockLocationsData[i].houseNo),
                          // SizedBox(
                          //     height: 1,
                          //     child: Container(
                          //         color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language().getString(
                                  Constants.BUILDING_STREET_NAME_STRING,
                                  selectedLang),
                              value: _stockLocationsData[i].streetName),
                          // SizedBox(
                          //     height: 1,
                          //     child: Container(
                          //         color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language().getString(
                                  Constants
                                      .COLONY_SELECTOR_AREA_LOCALITY_STRING,
                                  selectedLang),
                              value: _stockLocationsData[i].locality),
                          // SizedBox(
                          //     height: 1,
                          //     child: Container(
                          //         color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language().getString(
                                  Constants.LAND_MARK_STRING, selectedLang),
                              value: _stockLocationsData[i].landmark),
                          // SizedBox(
                          //     height: 1,
                          //     child: Container(
                          //         color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language().getString(
                                  Constants.COUNTRY_NAME_STRING, selectedLang),
                              value: _stockLocationsData[i].country != null
                                  ? _stockLocationsData[i].country
                                  : ""),
                          // SizedBox(
                          //     height: 1,
                          //     child: Container(
                          //         color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language().getString(
                                  Constants.STATE_NAME_STRING, selectedLang),
                              value: _stockLocationsData[i].state != null
                                  ? _stockLocationsData[i].state
                                  : ""),
                          // SizedBox(
                          //     height: 1,
                          //     child: Container(
                          //         color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language().getString(
                                  Constants.DISTRICT_STRING, selectedLang),
                              value: _stockLocationsData[i].district != null
                                  ? _stockLocationsData[i].district
                                  : ""),
                          // SizedBox(
                          //     height: 1,
                          //     child: Container(
                          //         color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language().getString(
                                  Constants.CITY_NAME_STRING, selectedLang),
                              value: _stockLocationsData[i].city),
                          // SizedBox(
                          //     height: 1,
                          //     child: Container(
                          //         color: Color(Constants.GREY_COLOR))),
                          TextView(
                              title: Language()
                                  .getString(Constants.PIN_CODE, selectedLang),
                              value: _stockLocationsData[i].postalCode),
                        ],
                      ))
                    ],
                  ),
                ),
              ),
              SizedBox(height: 10)
            ],
          )
      ],
    );
  }

  buildRichText(String? value) {
    return RichText(
        text: TextSpan(
          children: [
            TextSpan(
              text: value,
              style: TextStyle(
                color: Colors.black,
                fontSize: 14.0,
                fontFamily: StyleView.FONT_TITLE,
              ),
            )
          ],
        ),
        overflow: TextOverflow.ellipsis,
        softWrap: false);
  }

  controllAllAddView(String text) {
    return InkWell(
        onTap: () async {
          switch (text) {
            case Constants.STOCK_RECIVERS_LOCATIONS:
              if (_storeStockReceiveData.length > 0) {
                this.showStockReceiveLocationPopup();
              } else {
                final action = await Dialogs.yesCancelDialog(
                    context,
                    Language().getString(Constants.CONFIRMATION, selectedLang),
                    Language().getString(
                            Constants.DO_YOU_WANT_ADD, selectedLang) +
                        " \"${Language().getString(Constants.MAIN_ADDRESS, selectedLang)}\" " +
                        Language().getString(
                            Constants.AS_STOCK_RECEIVE_ADDRESS, selectedLang),
                    Language().getString(Constants.YES_STRING, selectedLang),
                    Language().getString(Constants.NO_STRING, selectedLang),
                    true);

                if (action == DialogAction.yes) {
                  _addMainAddressAsStock();
                } else {
                  this.showStockReceiveLocationPopup();
                }
              }

              break;
            default:
          }
        },
        child: Container(
          margin: EdgeInsets.only(right: 5),
          decoration: BoxDecoration(shape: BoxShape.circle, boxShadow: [
            BoxShadow(
              color: Colors.grey,
              blurRadius: 5.0,
            ),
          ]),
          child: ClipOval(
            child: Material(
              color: Color(Constants.APP_COLOR),
              child: SizedBox(
                  width: 25.0,
                  height: 25.0,
                  child: Icon(
                    Icons.add,
                    size: 18.0,
                    color: Colors.white,
                  )),
            ),
          ),
        ));
  }

  void _addMainAddressAsStock() {
    _storeStockReceiveData.add(StockDetailsModel(
        locationId: "",
        locationType: Constants.KEY_STOCK_RECEIVE,
        stockLocationName: Language()
            .getString(Constants.STOCK_RECIVERS_LOCATIONS, selectedLang),
        stockLocationNumber: _usersList.length > 0 ? _usersList[0].contact : "",
        country: countryDropdownValue != null ? countryDropdownValue!.name : "",
        state: statesDropdownValue != null ? statesDropdownValue!.state : "",
        city: citiesDropDownValue != null ? citiesDropDownValue : "",
        district: districtDropdownValue != null ? districtDropdownValue : "",
        postalCode: _postcodeController.text,
        landmark: _landmarkController.text,
        locality: _colonysectorarealocalityController.text,
        streetName: _buildingStreetNameController.text,
        houseNo: _buildinghouseNumberController.text,
        userName: _usersList.length > 0 ? _usersList[0].name : "",
        plotNo: _plotNumberController.text,
        buildingNo: _buildingNoController.text));
    setState(() {
      _storeStockReceiveData.reversed;
      AppController.instance.getOrganizationFieldsData.stockReceiveArray =
          _storeStockReceiveData;
    });
  }

  Future<bool> updateStockReceiveValues(
      String? alrtTitle,
      TextEditingController _stkRecLocationNo,
      TextEditingController _stkRecLocationName,
      TextEditingController _stkRecHouseNo,
      TextEditingController _stkRecStreetName,
      TextEditingController _stkRecLocality,
      TextEditingController _stkRecLandmark,
      TextEditingController _stkRecCity,
      TextEditingController _stkRecPostalCode,
      TextEditingController _stkRecBuildingNo,
      TextEditingController _stkRecPlotNo,
      StockDetailsModel data,
      int index,
      bool isStockListUpdate) async {
    if (isStockListUpdate) {
      _stockStatesList.clear();
      _stockReceiveDistrictList.clear();
      stockStatesDropdownValue = null;
      stockCountryDropdownValue = null;
      stockReceiveDistrictDropdownValue = null;
      _stkRecLocationName.text = data.stockLocationName!;
      _stkRecHouseNo.text = data.houseNo!;
      _stkRecStreetName.text = data.streetName!;
      _stkRecLocality.text = data.locality!;
      _stkRecLandmark.text = data.landmark!;
      _stkRecCity.text = data.city!;
      _stkRecPostalCode.text = data.postalCode!;
      _stkRecBuildingNo.text = data.buildingNo!;
      _stkRecPlotNo.text = data.plotNo!;

      if (_countryList.length > 0) {
        for (int i = 0; i < _countryList.length; i++) {
          if (data.country == _countryList[i].name) {
            setState(() {
              stockCountryDropdownValue = _countryList[i];
            });
          }
        }

        if (stockCountryDropdownValue != null) {
          isLoadingProgress = true;
          List<StatesDAO> fetchStockStatesData = await CountryApiService
              .instance
              .getStates(countryName: data.country!);
          setState(() {
            isLoadingProgress = false;
            stockStatesDropdownValue = null;
            _stockStatesList.clear();
            _stockStatesList.addAll(fetchStockStatesData);
            for (var element in _stockStatesList) {
              if (data.state == element.state) {
                stockStatesDropdownValue = element;
                _stockReceiveDistrictList
                    .addAll(stockStatesDropdownValue!.cities!);
                break;
              }
            }

            for (var element in _stockReceiveDistrictList) {
              if (data.district == element) {
                stockReceiveDistrictDropdownValue = element;
                break;
              }
            }
          });
        }

        if (stockStatesDropdownValue != null) {
          isLoadingProgress = true;
          progressMessage = Constants.GETTING_DATA;
          // AppController.instance.setCreateBuProgress = true;

          List<CitiesDAO> fetchStockCitiesData =
              await CountryApiService.instance.getCitiesList(
                  stockCountryDropdownValue!.name,
                  stockStatesDropdownValue!.id);
          setState(() {
            isLoadingProgress = false;
            stockReceiveCitiesDropDownValue = null;
            _stockReceiveCitiesList.clear();
            if (fetchStockCitiesData.length > 0 &&
                fetchStockCitiesData[0].cities!.length > 0) {
              _stockReceiveCitiesList.addAll(fetchStockCitiesData[0].cities!);
              for (var element in _stockReceiveCitiesList) {
                if (data.city == element) {
                  stockReceiveCitiesDropDownValue = element;
                }
              }
            }
          });
        }

        for (var element in _usersList) {
          if (data.userName == element.name) {
            setState(() {
              usersDropdownValue = element;
              _stkRecLocationNo.text =
                  element.dialerCode! + " " + element.contact!;
            });
            break;
          }
        }
      }

      return true;
    } else {
      _stockStatesList.clear();
      _stockReceiveDistrictList.clear();
      _stkRecLocationNo.clear();
      _stkRecLocationName.clear();
      _stkRecHouseNo.clear();
      _stkRecStreetName.clear();
      _stkRecLocality.clear();
      _stkRecLandmark.clear();
      _stkRecCity.clear();
      _stkRecPostalCode.clear();
      _stkRecBuildingNo.clear();
      _stkRecPlotNo.clear();
      stockCountryDropdownValue = setCountryDefault();
      stockReceiveDistrictDropdownValue = null;
      stockStatesDropdownValue = null;
      usersDropdownValue = null;
      return true;
    }
  }

  CountryDAO? setCountryDefault() {
    for (var element in _countryList) {
      if (element.name == "India") {
        return element;
      }
    }
    return null;
  }

  buildStockReceiveFields(
      String? alrtTitle,
      TextEditingController _stkRecLocationNo,
      TextEditingController _stkRecLocationName,
      TextEditingController _stkRecHouseNo,
      TextEditingController _stkRecStreetName,
      TextEditingController _stkRecLocality,
      TextEditingController _stkRecLandmark,
      TextEditingController _stkRecCity,
      TextEditingController _stkRecPostalCode,
      TextEditingController _stkRecBuildingNo,
      TextEditingController _stkRecPlotNo,
      StockDetailsModel data,
      int index,
      bool isStockListUpdate) async {
    await updateStockReceiveValues(
        alrtTitle,
        _stkRecLocationNo,
        _stkRecLocationName,
        _stkRecHouseNo,
        _stkRecStreetName,
        _stkRecLocality,
        _stkRecLandmark,
        _stkRecCity,
        _stkRecPostalCode,
        _stkRecBuildingNo,
        _stkRecPlotNo,
        data,
        index,
        isStockListUpdate);

    return showDialog(
        context: context,
        barrierDismissible: false,
        barrierColor: Colors.black54,
        builder: (context) {
          return Container(
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10.0),
                  color: Colors.white),
              margin: EdgeInsets.symmetric(horizontal: 10.0, vertical: 20.0),
              child: Scaffold(
                  backgroundColor: Colors.transparent,
                  bottomNavigationBar: Container(
                    margin: EdgeInsets.symmetric(horizontal: 10),
                    padding: EdgeInsets.only(bottom: 10),
                    child: CommonButtonsView(
                      context: context,
                      b1Text: Language()
                          .getString(Constants.STR_CANCEL, selectedLang),
                      b2Text: Language()
                          .getString(Constants.STR_SAVE, selectedLang),
                      onb1Action: () {
                        Navigator.of(context).pop();
                      },
                      onb2Action: () {
                        String? validationText = '';
                        if (_stkRecLocationName.text.isEmpty) {
                          validationText = Language().getString(
                              Constants.PLEASE_ENTER_LOCATION_NAME,
                              selectedLang);
                        } else if (stockCountryDropdownValue == null) {
                          validationText = Language().getString(
                              Constants.PLEASE_SELECT_COUNTRY, selectedLang);
                        } else if (stockStatesDropdownValue == null) {
                          validationText = Language().getString(
                              Constants.PLEASE_SELECT_STATE, selectedLang);
                        } else if (stockReceiveDistrictDropdownValue == null) {
                          validationText = Language().getString(
                              Constants.PLEASE_SELECT_DISTRICT, selectedLang);
                        } else if (stockReceiveCitiesDropDownValue == null) {
                          validationText = Language().getString(
                              Constants.PLEASE_SELECT_CITY, selectedLang);
                        } else if (usersDropdownValue == null) {
                          validationText =
                              Constants.PLEASE_SELECT_CONTACT_PERSON;
                        }
                        // String validationText =
                        //               validationStockReceiveData();
                        if (validationText!.isEmpty) {
                          onSaveStockReceiveDetails(index, isStockListUpdate);
                        } else {
                          // Navigator.of(context).pop();
                          Dialogs.yesCancelDialog(
                              context,
                              Language()
                                  .getString(Constants.ERROR, selectedLang),
                              Language()
                                  .getString(validationText, selectedLang),
                              Language()
                                  .getString(Constants.OKAY_STR, selectedLang),
                              "",
                              false);
                        }
                      },
                    ),
                  ),
                  body: StatefulBuilder(
                      builder: (BuildContext context, StateSetter setState) {
                    return Container(
                      padding: EdgeInsets.all(10.0),
                      child: SingleChildScrollView(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Container(
                              margin: EdgeInsets.symmetric(vertical: 10.0),
                              child: Text(
                                alrtTitle!,
                                style: TextStyle(
                                    fontSize: 18.0,
                                    fontFamily: StyleView.FONT_TITLE,
                                    color: Colors.black //(Constants.APP_COLOR),
                                    ),
                              ),
                            ),
                            buildTextFormFieldsDialog(
                                Language().getString(
                                    Constants.LOCATION_NAME, selectedLang),
                                _stkRecLocationName,
                                false),

                            // SizedBox(height: 20.0),
                            Container(
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: <Widget>[
                                  buildTextField(Language().getString(
                                      Constants.ADDRESS, selectedLang)),
                                ],
                              ),
                            ),
                            SizedBox(height: 5.0),
                            buildTextFormFieldsDialog(
                                Language()
                                    .getString(Constants.PLOT_NO, selectedLang),
                                _stkRecPlotNo,
                                false),
                            buildTextFormFieldsDialog(
                                Language().getString(
                                    Constants.BUILDING_HOUSE_NUMBER_STRING,
                                    selectedLang),
                                _stkRecHouseNo,
                                false),
                            buildTextFormFieldsDialog(
                                Language().getString(
                                    Constants.BULIDING, selectedLang),
                                _stkRecBuildingNo,
                                false),
                            buildTextFormFieldsDialog(
                                Language().getString(
                                    Constants.BUILDING_STREET_NAME_STRING,
                                    selectedLang),
                                _stkRecStreetName,
                                false),
                            buildTextFormFieldsDialog(
                                Language().getString(
                                    Constants
                                        .COLONY_SELECTOR_AREA_LOCALITY_STRING,
                                    selectedLang),
                                _stkRecLocality,
                                false),
                            buildTextFormFieldsDialog(
                                Language().getString(
                                    Constants.LAND_MARK_STRING, selectedLang),
                                _stkRecLandmark,
                                false),
                            Container(
                                // color: Colors.white70,
                                padding: EdgeInsets.only(
                                  left: 5,
                                ),
                                margin: EdgeInsets.symmetric(vertical: 3.0),
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    border: Border.all(color: Colors.grey),
                                    borderRadius: BorderRadius.circular(5.0)),
                                child: DropdownButton<CountryDAO>(
                                    onTap: () {
                                      return CommonMethods.hideKeyboard(
                                          context);
                                    },
                                    value: stockCountryDropdownValue,
                                    isExpanded: true,
                                    hint: Text(
                                        Language().getString(
                                            Constants.SELECT_COUNTRY,
                                            selectedLang),
                                        style: TextStyle(
                                            fontFamily: StyleView.FONT_TITLE)),
                                    underline: SizedBox(),
                                    onChanged: (CountryDAO? data) async {
                                      List<StatesDAO> fetchStockStatesData =
                                          await CountryApiService.instance
                                              .getStates(
                                                  countryName:
                                                      stockCountryDropdownValue!
                                                          .name!);
                                      setState(() {
                                        stockCountryDropdownValue = data;
                                        _stockStatesList.clear();
                                        _stockReceiveDistrictList.clear();
                                        stockStatesDropdownValue = null;
                                        stockReceiveDistrictDropdownValue =
                                            null;
                                        _stockStatesList
                                            .addAll(fetchStockStatesData);
                                      });
                                    },
                                    items: _countryList.map((CountryDAO model) {
                                      return new DropdownMenuItem<CountryDAO>(
                                        child: new Text(model.name!,
                                            style: TextStyle(
                                                fontFamily:
                                                    StyleView.FONT_TITLE)),
                                        value: model,
                                      );
                                    }).toList())),

                            Container(
                                // color: Colors.white70,
                                padding: EdgeInsets.only(
                                  left: 5,
                                ),
                                margin: EdgeInsets.symmetric(vertical: 3.0),
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    border: Border.all(color: Colors.grey),
                                    borderRadius: BorderRadius.circular(5.0)),
                                child: DropdownButton<StatesDAO>(
                                    onTap: () {
                                      return CommonMethods.hideKeyboard(
                                          context);
                                    },
                                    value: stockStatesDropdownValue,
                                    isExpanded: true,
                                    hint: Text(
                                        Language().getString(
                                            Constants.SELECT_STATE,
                                            selectedLang),
                                        style: TextStyle(
                                            fontFamily: StyleView.FONT_TITLE)),
                                    underline: SizedBox(),
                                    onChanged: (StatesDAO? data) async {
                                      List<CitiesDAO> fetchCitiesData =
                                          await CountryApiService.instance
                                              .getCitiesList(
                                                  stockCountryDropdownValue!
                                                      .name,
                                                  stockStatesDropdownValue!.id);

                                      setState(() {
                                        _stockReceiveDistrictList.clear();
                                        stockReceiveDistrictDropdownValue =
                                            null;
                                        _stockReceiveCitiesList.clear();
                                        stockReceiveCitiesDropDownValue = null;
                                        stockStatesDropdownValue = data;
                                        _stockReceiveDistrictList.addAll(
                                            stockStatesDropdownValue!.cities!);

                                        if (fetchCitiesData.length > 0 &&
                                            fetchCitiesData[0].cities!.length >
                                                0) {
                                          _stockReceiveCitiesList.addAll(
                                              fetchCitiesData[0].cities!);
                                        }
                                      });
                                    },
                                    items:
                                        _stockStatesList.map((StatesDAO model) {
                                      return new DropdownMenuItem<StatesDAO>(
                                        child: new Text(model.state!,
                                            style: TextStyle(
                                                fontFamily:
                                                    StyleView.FONT_TITLE)),
                                        value: model,
                                      );
                                    }).toList())),
                            Container(
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    border: Border.all(color: Colors.grey),
                                    borderRadius: BorderRadius.circular(5.0)),
                                padding: EdgeInsets.only(
                                  left: 5,
                                ),
                                child: DropdownButton<String>(
                                    onTap: () {
                                      return CommonMethods.hideKeyboard(
                                          context);
                                    },
                                    value: stockReceiveDistrictDropdownValue,
                                    isExpanded: true,
                                    hint: Text(
                                        Language().getString(
                                            Constants.SELECT_DISTRICT,
                                            selectedLang),
                                        style: TextStyle(
                                            fontFamily: StyleView.FONT_TITLE)),
                                    underline: SizedBox(),
                                    onChanged: (String? data) {
                                      setState(() {
                                        stockReceiveDistrictDropdownValue =
                                            data;
                                      });
                                    },
                                    items: _stockReceiveDistrictList
                                        .map((String model) {
                                      return new DropdownMenuItem<String>(
                                        child: new Text(model,
                                            style: TextStyle(
                                                fontFamily:
                                                    StyleView.FONT_TITLE)),
                                        value: model,
                                      );
                                    }).toList())),
                            Container(
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    border: Border.all(color: Colors.grey),
                                    borderRadius: BorderRadius.circular(5.0)),
                                padding: EdgeInsets.all(1),
                                margin: EdgeInsets.symmetric(
                                  vertical: 5.0,
                                ),
                                child: Row(
                                  children: <Widget>[
                                    Expanded(
                                      child: Container(
                                          height: 50,
                                          color:
                                              Color(Constants.GREY_COLOR_LIGHT),
                                          child: Container(
                                            padding: EdgeInsets.only(left: 10),
                                            child: Align(
                                                alignment: Alignment.centerLeft,
                                                child: Text(
                                                    Language().getString(
                                                        Constants
                                                            .CITY_NAME_STRING,
                                                        selectedLang),
                                                    style: TextStyle(
                                                        fontSize: StyleView
                                                            .FONT_SIZE_15,
                                                        fontFamily: StyleView
                                                            .FONT_TITLE))),
                                          )),
                                    ),
                                    Expanded(
                                      flex: 2,
                                      child: Container(
                                          color: Colors.white70,
                                          padding: EdgeInsets.only(
                                              left: 5, right: 5),
                                          child: DropdownButton<String>(
                                              onTap: () {
                                                return CommonMethods
                                                    .hideKeyboard(context);
                                              },
                                              value:
                                                  stockReceiveCitiesDropDownValue,
                                              isExpanded: true,
                                              hint: Text(
                                                Language().getString(
                                                    Constants.SELECT_CITY,
                                                    selectedLang),
                                              ),
                                              underline: SizedBox(),
                                              onChanged: (String? data) {
                                                setState(() {
                                                  stockReceiveCitiesDropDownValue =
                                                      data;
                                                });
                                              },
                                              items: _stockReceiveCitiesList
                                                  .map((String model) {
                                                return new DropdownMenuItem<
                                                    String>(
                                                  child: new Text(model,
                                                      style: TextStyle(
                                                          fontFamily: StyleView
                                                              .FONT_TITLE)),
                                                  value: model,
                                                );
                                              }).toList())),
                                    )
                                  ],
                                )),

                            // buildTextFormFieldsDialog("City", _stkRecCity, false),

                            buildTextFormFieldsDialog(
                                Language().getString(
                                    Constants.PIN_CODE, selectedLang),
                                _stkRecPostalCode,
                                true),

                            Container(
                                padding: EdgeInsets.all(1),
                                margin: EdgeInsets.symmetric(vertical: 5.0),
                                decoration: BoxDecoration(
                                    border: Border.all(color: Colors.grey),
                                    borderRadius: BorderRadius.circular(5.0)),
                                child: Row(
                                  children: <Widget>[
                                    Expanded(
                                      child: Container(
                                          height: 50,
                                          color:
                                              Color(Constants.GREY_COLOR_LIGHT),
                                          child: Container(
                                            padding: EdgeInsets.only(left: 10),
                                            child: Align(
                                                alignment: Alignment.centerLeft,
                                                child: Text(
                                                    Language().getString(
                                                        Constants
                                                            .CONTACT_PERSON,
                                                        selectedLang),
                                                    style: TextStyle(
                                                        fontSize: StyleView
                                                            .FONT_SIZE_15,
                                                        fontFamily: StyleView
                                                            .FONT_TITLE))),
                                          )),
                                    ),
                                    Expanded(
                                      flex: 2,
                                      child: Container(
                                          color: Colors.white70,
                                          padding: EdgeInsets.only(
                                              left: 5, right: 5),
                                          child: DropdownButton<UserModel>(
                                              onTap: () {
                                                return CommonMethods
                                                    .hideKeyboard(context);
                                              },
                                              value: usersDropdownValue,
                                              isExpanded: true,
                                              hint: Text(
                                                  Language().getString(
                                                      Constants.SELECT_USER,
                                                      selectedLang),
                                                  style: TextStyle(
                                                      fontFamily: StyleView
                                                          .FONT_TITLE)),
                                              underline: SizedBox(),
                                              onChanged: (UserModel? data) {
                                                setState(() {
                                                  usersDropdownValue = data;
                                                  _stkRecLocationNo.text =
                                                      data!.dialerCode! +
                                                          " " +
                                                          data.contact!;
                                                });
                                              },
                                              items: _usersList
                                                  .map((UserModel model) {
                                                return new DropdownMenuItem<
                                                    UserModel>(
                                                  child: new Text(model.name!,
                                                      style: TextStyle(
                                                          fontFamily: StyleView
                                                              .FONT_TITLE)),
                                                  value: model,
                                                );
                                              }).toList())),
                                    )
                                  ],
                                )),
                            buildTextFormFieldsDialog(
                                Language().getString(
                                    Constants.LOCATION_PHONE_NUMBER,
                                    selectedLang),
                                _stkRecLocationNo,
                                false),
                          ],
                        ),
                      ),
                    );
                  })));
        });
  }

  buildTextFormFieldsDialog(String? _labelText,
      TextEditingController controller, bool isNumberKeyboard) {
    return Container(
        height: 50,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(
            5.0,
          ),
          color: Colors.white,
        ),
        margin: EdgeInsets.symmetric(vertical: 3.0),
        child: new TextFormField(
            keyboardType: isNumberKeyboard
                ? TextInputType.numberWithOptions(signed: true)
                : TextInputType.text,
            style: TextStyle(fontFamily: StyleView.FONT_TITLE),
            controller: controller,
            textInputAction: TextInputAction.done,
            inputFormatters: this.inputFormatters(_labelText),
            decoration: StyleView.getInputDecoration(
              helper: _labelText,
            ),
            onChanged: (text) => {}));
  }

  String validationStockReceiveData() {
    if (_stockReceiveLocationController.text.isNotEmpty ||
        _stockReceiveBussinessController.text.isNotEmpty ||
        _addressreceivernameController.text.isNotEmpty ||
        _addressreceiverfullController.text.isNotEmpty ||
        _addressreceivercontactnumberController.text.isNotEmpty ||
        _stockReceiveHouseNoController.text.isNotEmpty ||
        _stockReceiveStreetNameController.text.isNotEmpty ||
        _stockReceiveLocalityController.text.isNotEmpty ||
        _stockReceiveLandmarkController.text.isNotEmpty ||
        _stockReceivePostalController.text.isNotEmpty) {
      return "contain data";
    } else {
      return "";
    }
  }

  onSaveStockReceiveDetails(int index, bool isStockListUpdate) {
    if (isStockListUpdate) {
      _storeStockReceiveData[index] = StockDetailsModel(
          locationId: _storeStockReceiveData[index].locationId,
          locationType: Constants.KEY_STOCK_RECEIVE,
          stockLocationNumber: _stockReceiveLocationController.text,
          stockLocationName: _stockReceiveBussinessController.text,
          houseNo: _stockReceiveHouseNoController.text,
          buildingNo: _stockReceiveBuildingNoController.text,
          plotNo: _stockReceivePlotNoController.text,
          streetName: _stockReceiveStreetNameController.text,
          locality: _stockReceiveLocalityController.text,
          landmark: _stockReceiveLandmarkController.text,
          city: stockReceiveCitiesDropDownValue != null
              ? stockReceiveCitiesDropDownValue
              : "",
          postalCode: _stockReceivePostalController.text,
          country: stockCountryDropdownValue != null
              ? stockCountryDropdownValue!.name
              : "",
          state: stockStatesDropdownValue != null
              ? stockStatesDropdownValue!.state
              : "",
          district: stockReceiveDistrictDropdownValue,
          userName: usersDropdownValue != null ? usersDropdownValue!.name : "");

      setState(() {
        _storeStockReceiveData.reversed;
      });
    } else {
      _storeStockReceiveData.add(StockDetailsModel(
          locationId: "",
          locationType: Constants.KEY_STOCK_RECEIVE,
          stockLocationNumber: _stockReceiveLocationController.text,
          stockLocationName: _stockReceiveBussinessController.text,
          houseNo: _stockReceiveHouseNoController.text,
          buildingNo: _stockReceiveBuildingNoController.text,
          plotNo: _stockReceivePlotNoController.text,
          streetName: _stockReceiveStreetNameController.text,
          locality: _stockReceiveLocalityController.text,
          landmark: _stockReceiveLandmarkController.text,
          city: stockReceiveCitiesDropDownValue != null
              ? stockReceiveCitiesDropDownValue
              : "",
          postalCode: _stockReceivePostalController.text,
          country: stockCountryDropdownValue != null
              ? stockCountryDropdownValue!.name
              : "",
          state: stockStatesDropdownValue != null
              ? stockStatesDropdownValue!.state
              : "",
          district: stockReceiveDistrictDropdownValue,
          userName:
              usersDropdownValue != null ? usersDropdownValue!.name : ""));

      setState(() {
        _storeStockReceiveData.reversed;
      });
    }
    AppController.instance.getOrganizationFieldsData.stockReceiveArray =
        _storeStockReceiveData;
    Navigator.of(context).pop();
  }

  showStockReceiveLocationPopup() {
    buildStockReceiveFields(
        Language().getString(Constants.STOCK_RECEIVE, selectedLang),
        _stockReceiveLocationController,
        _stockReceiveBussinessController,
        _stockReceiveHouseNoController,
        _stockReceiveStreetNameController,
        _stockReceiveLocalityController,
        _stockReceiveLandmarkController,
        _stockReceiveCityController,
        _stockReceivePostalController,
        _stockReceiveBuildingNoController,
        _stockReceivePlotNoController,
        new StockDetailsModel(),
        -1,
        false);
  }

  inputFormatters(String? validationText) {
    List<TextInputFormatter> formatter = [];
    if (validationText ==
        Language().getString(Constants.POST_CODE_STRING, selectedLang)) {
      formatter = [
        new LengthLimitingTextInputFormatter(6),
        FilteringTextInputFormatter.digitsOnly
      ];
    } else if (validationText ==
        Language().getString(Constants.LOCATION_PHONE_NUMBER, selectedLang)) {
      formatter = [
        new LengthLimitingTextInputFormatter(14),
        FilteringTextInputFormatter.allow(RegExp("[0-9 +]"))
      ];
    } else {
      formatter = [];
    }
    return formatter;
  }
}
