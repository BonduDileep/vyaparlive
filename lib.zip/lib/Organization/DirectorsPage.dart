import 'dart:io';
import 'package:url_launcher/url_launcher.dart';
import 'package:vyaparlive/components/display_attached_file/DisplayAttachedFile.dart';
import 'package:vyaparlive/locations_view/card_view/location_card_view.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:vyaparlive/Organization/PaymentDetailsPage.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/model/DirectorData.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/model/BusinessRelationDAO.dart';
import 'package:vyaparlive/model/BusinessUnitModel.dart';
import 'package:vyaparlive/model/CountryDAO.dart';
import 'package:vyaparlive/model/CurrecyNameDAO.dart';
import 'package:vyaparlive/model/ExportsModel.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/RegulationData.dart';
import 'package:vyaparlive/model/RolesDAO.dart';
import 'package:vyaparlive/model/TaxSchemeData.dart';
import 'package:vyaparlive/model/TermsData.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:mime/mime.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:vyaparlive/model/BuBasicDataModel.dart';
import 'package:vyaparlive/model/bu_model/LocationsModel.dart';
import 'package:vyaparlive/service/organization_service.dart';
import 'package:vyaparlive/utills/SharePref.dart';
import 'package:vyaparlive/service/Service.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:toast/toast.dart';
// import 'package:vyaparlive/Organization/component/SelectLocation.dart';
import '../image_hero/ImageHeroView.dart';
import '../service/api_service/UploadImageApiService.dart';
import '../theme/app_theme.dart';
import '../utills/webview_page.dart';

import 'component/select_location_interface.dart';
// import 'component/SelectLocationWeb.dart';

class DirectorsView extends StatefulWidget {
  final String? orgId;
  DirectorsView({this.orgId = ""});

  @override
  _DirectorsViewState createState() => _DirectorsViewState();
}

class _DirectorsViewState extends State<DirectorsView> {
  List<BuBasicDataModel> _bubasicdatamodel = [];
  BusinessUnitModel? _buModel;

  final _businessName = TextEditingController();

  final _businessShortName = TextEditingController();
  final _mobileNumberController = TextEditingController();
  final _officeNumberController = TextEditingController();
  final _businesswebsite = TextEditingController();

// = 'Select Country Code';
// = 'Select Currency Code';

  final _bussinessnameController = TextEditingController();
  final _headofbussinessController = TextEditingController();
  final _bussinessLocationNumberController = TextEditingController();
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  BuBasicDataModel? dropdownValue;
  String parentId = "";
  bool isLoading = false;

  late Service _service;
  bool? isOrgUpdate = false;
  List<RolesDAO>? _rolesData = [];
  List<Locations>? _locationsData = [];
  List<BusinessRelationDAO> _businessTypeList = [];
  BusinessRelationDAO? businessTypeDropdown;
  String? parentHob = "";
  String? parentWebsite = "";
  String? parentLocation = "";
  List<CountryDAO> _countryList = [];
  CountryDAO? countryDropdownValue;
  List<CurrencyNameDAO> _currencyList = [];
  late CurrencyNameDAO currencyDropdown;
  String? currencyValue = "";

  List<TaxSchemeData> _taxData = [];
  List<RegulationData> _regulationData = [];
  List<ExportsModel> _exportsData = [];
  List<ExportsModel> _importsData = [];
  List<BankDetails> _bankDetails = [];

  List<DirectorsData> _directorsList = [];
  List<TermsData> _termsList = [];
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  late OrganizationService _organizationService;
  final _gstNumberController = TextEditingController();
  final _dialCodeController = TextEditingController(text: "+91");
  bool isShowParentDetailsView = false;
  final _officeDialCodeController = TextEditingController(text: "+91");
  String? userId = "";
  bool isEnableGstLoader = false;
  bool isGstVerified = false;
  bool isGstNotVerified = false;
  late ThemeData theme;
  List<Locations> locationsList = [];
  TextEditingController emailController = new TextEditingController();
  TextEditingController panController = new TextEditingController();
  File? imageFile;
  String imageRelativePath = '';
  List<Map> _namesData = [];

  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _organizationService = OrganizationService();
    AppController.instance.setCreateBuProgress = false;
    isOrgUpdate = AppController.instance.isOrganizationUpdate;
    _service = Service();
    _buModel = BusinessUnitModel();
    SharePref().getUserName().then((value) {
      _headofbussinessController.text = value!;
      AppController.instance.getOrganizationFieldsData.businessHob =
          _headofbussinessController.text;
    });
    SharePref().getPhoneNumber().then((value) {
      _mobileNumberController.text = value!;
      _officeNumberController.text = value;
      AppController.instance.getOrganizationFieldsData.buContactNumber =
          _officeNumberController.text;
      AppController.instance.getOrganizationFieldsData.mobileNumber =
          _mobileNumberController.text;
    });

    getLoadLanguage();

    this.getBuList();
  }

  getLoadLanguage() async {
    setState(() {
      _namesData = [
        {"name": Language().getString(Constants.CALL, selectedLang)},
        {"name": Language().getString(Constants.EDIT, selectedLang)}
      ];
    });
  }

  getBuList() async {
    SharePref().getUserId().then((onValue) {
      setState(() {
        userId = onValue;
      });
      getUserBuList().then((value) => setState(() {
            _bubasicdatamodel.addAll(value);
            for (var i = 0; i < _bubasicdatamodel.length; i++) {
              if (AppController.instance.getMyBuId == _bubasicdatamodel[i].id) {
                isShowParentDetailsView = true;
              }
            }
          }));
    });

    // AppController.instance.getBuList);

    if (isOrgUpdate!) {
      if (await NetworkStatus.getInternetStatus()) {
        this.getBuData().then((value) {
          print("Bu List Directors Page:${value.length}");
        });
      } else {
        AppUtills.showSnackBar(_scaffoldkey,
            Language().getString(Constants.NO_INTERNET, selectedLang),
            snackBarBgColor: Colors.black,
            messageColor: Colors.white,
            buttonColor: Colors.white);
      }
    } else {
      for (int i = 0; i < _bubasicdatamodel.length; i++) {
        if (AppController.instance.getMyBuId == _bubasicdatamodel[i].id) {
          setState(() {
            isShowParentDetailsView = true;
            dropdownValue = _bubasicdatamodel[i];
            _bussinessnameController.text =
                dropdownValue != null ? dropdownValue!.businessName! : "";

            parentWebsite = dropdownValue != null ? dropdownValue!.website : "";
            parentHob =
                dropdownValue != null ? dropdownValue!.headOfBusiness : "";
            parentLocation =
                dropdownValue != null ? dropdownValue!.location : "";

            AppController.instance.organizationFieldsData!.parentBuId =
                dropdownValue!.id;
          });
        }
      }
      getDropdownData();
    }
  }

  /// Service call for get bu details

  Future<List<BusinessUnitModel>> getBuData() async {
    setState(() {
      isLoadingProgress = true;
      AppController.instance.setCreateBuProgress = true;
    });
    String body = json.encode({"id": widget.orgId});
    var response = await _organizationService
        .getOrganizationDataById(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
        AppController.instance.setCreateBuProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
      AppController.instance.setCreateBuProgress = false;
    });
    List<BusinessUnitModel> _list = [];

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      _list.add(BusinessUnitModel.fromJson(resObj[0]));
      AppController.instance.setBusinessUnitData = _list[0];
      updateOrganizationDataDefault(_list[0]);
      _buModel = AppController.instance.getBusinessUnitData;
      if (_buModel != null) {
        setState(() {
          if (_buModel!.rolesList != null &&
              _buModel!.rolesList!.length > 0) {
            _rolesData = _buModel!.rolesList;
            AppController.instance.getOrganizationFieldsData.rolesArray =
                _rolesData;
          }
          if (_buModel!.locationsList != null) {
            _locationsData = _buModel!.locationsList;
            AppController.instance.getOrganizationFieldsData.locationsArray =
                _locationsData;
          }
          if (_list[0].parentDetails != null) {
            isShowParentDetailsView = true;
            for (int i = 0; i < _bubasicdatamodel.length; i++) {
              if (_bubasicdatamodel[i].id == _list[0].parentDetails!.id) {
                setState(() {
                  dropdownValue = _bubasicdatamodel[i];
                  _bussinessnameController.text = dropdownValue != null
                      ? dropdownValue!.businessName!
                      : "";
                  parentWebsite =
                      dropdownValue != null ? dropdownValue!.website : "";
                  parentHob = dropdownValue != null
                      ? dropdownValue!.headOfBusiness
                      : "";
                  parentLocation =
                      dropdownValue != null ? dropdownValue!.location : "";
                  _headofbussinessController.text =
                      dropdownValue!.headOfBusiness;

                  AppController.instance.organizationFieldsData!.parentBuId =
                      dropdownValue != null ? dropdownValue!.id : "";
                });
              }
            }
          } else {
            setState(() {
              isShowParentDetailsView = false;
              AppController.instance.organizationFieldsData!.parentBuId =
                  null;
            });
          }

          _businessName.text =
              _buModel!.businessName != null ? _buModel!.businessName! : "";
          _businessShortName.text =
              _buModel!.shortName != null ? _buModel!.shortName! : "";
          _businesswebsite.text =
              _buModel!.website != null ? _buModel!.website! : "";
          _headofbussinessController.text =
              _buModel!.businessHob != null ? _buModel!.businessHob! : "";
          _bussinessLocationNumberController.text =
              _buModel!.businessLocation != null
                  ? _buModel!.businessLocation!
                  : "";
          _officeNumberController.text = _buModel!.buContactNumber != null
              ? _buModel!.buContactNumber!
              : "";
          _mobileNumberController.text =
              _buModel!.mobileNumber != null ? _buModel!.mobileNumber! : "";

          AppController.instance.getOrganizationFieldsData.businessName =
              _businessName.text;
          AppController.instance.getOrganizationFieldsData.shortName =
              _businessShortName.text;
          AppController.instance.getOrganizationFieldsData.website =
              _businesswebsite.text;
          AppController.instance.getOrganizationFieldsData.businessHob =
              _headofbussinessController.text;
          AppController.instance.getOrganizationFieldsData.buContactNumber =
              _officeNumberController.text;
          AppController.instance.getOrganizationFieldsData.mobileNumber =
              _mobileNumberController.text;
          _gstNumberController.text = _buModel!.orgGstNumber!;
          AppController.instance.getOrganizationFieldsData.gstNumber =
              _gstNumberController.text;
          _dialCodeController.text =
              (_buModel!.dialCode != null && _buModel!.dialCode!.isNotEmpty)
                  ? _buModel!.dialCode!
                  : "+91";
          AppController.instance.getOrganizationFieldsData
              .orgCountryDialCode = _dialCodeController.text;
          _officeDialCodeController.text = _buModel!.officeDialCode != null
              ? _buModel!.officeDialCode!
              : "+91";
          AppController.instance.getOrganizationFieldsData.officeDialCode =
              _officeDialCodeController.text;
          emailController.text = _buModel!.emailAddress!;
          panController.text = _buModel!.panNumber!;
          AppController.instance.organizationFieldsData!.invoiceEmail =
              emailController.text;

          AppController.instance.organizationFieldsData!.panCardNumber =
              panController.text;
        });
      }

      this.getDropdownData();
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
      return _list;
  }

  getDropdownData() async {
    this.getBusinessType().then((value) {
      setState(() {
        _businessTypeList.addAll(value);
      });
    });

    getCurrency().then((value) {
      setState(() {
        _currencyList.addAll(value);
      });
    });

    if (await NetworkStatus.getInternetStatus()) {
      getCountries().then((value) {
        setState(() {
          _countryList.addAll(value);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey, Constants.NO_INTERNET,
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  /// Service call for countries

  Future<List<CountryDAO>> getCountries() async {
    http.Response response =
        await _service.get_countries().catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
        AppController.instance.setCreateBuProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<CountryDAO> list = [];
    setState(() {
      isLoadingProgress = false;
      AppController.instance.setCreateBuProgress = false;
    });
    if (response.statusCode == 200) {
      var data = json.decode(response.body);
      for (var object in data["data"]) {
        list.add(CountryDAO.fromJaon(object));
      }
      if (isOrgUpdate! && _buModel!.countryCode != null && list.length > 0) {
        for (int i = 0; i < list.length; i++) {
          if (_buModel!.countryCode == list[i].code) {
            countryDropdownValue = list[i];
            currencyValue = countryDropdownValue!.currencyCode;
            AppController.instance.getOrganizationFieldsData.countryCode =
                countryDropdownValue!.code;
            AppController.instance.organizationFieldsData!.currencyCode =
                currencyValue;

            AppController.instance.organizationFieldsData!.orgCurrencySymbol =
                countryDropdownValue!.currencySymbol;
            AppController.instance.organizationFieldsData!.orgCountryDialCode =
                countryDropdownValue!.countryCode;
            AppController.instance.organizationFieldsData!.currencyName =
                countryDropdownValue!.currencyName;
          }
        }
      } else {
        if (list.length > 0) {
          for (int i = 0; i < list.length; i++) {
            if (list[i].name == 'India') {
              countryDropdownValue = list[i];
              currencyValue = countryDropdownValue!.currencyCode;
              AppController.instance.getOrganizationFieldsData.countryCode =
                  countryDropdownValue!.code;
              AppController.instance.organizationFieldsData!.currencyCode =
                  currencyValue;
              AppController.instance.organizationFieldsData!.orgCurrencySymbol =
                  countryDropdownValue!.currencySymbol;
              if (AppController
                      .instance.getOrganizationFieldsData.invoiceCurrencyCode ==
                  null) {
                AppController.instance.getOrganizationFieldsData
                    .invoiceCurrencyCode = currencyValue;
                AppController.instance.setBuCountryCode =
                    countryDropdownValue!.code;
                AppController.instance.organizationFieldsData!
                    .orgCountryDialCode = countryDropdownValue!.countryCode;
                _dialCodeController.text =
                    "+91"; //countryDropdownValue!.countryCode!;
                _officeDialCodeController.text = "+91";
                //countryDropdownValue!.countryCode!;

                AppController.instance.organizationFieldsData!.officeDialCode =
                    _officeDialCodeController.text;
                AppController.instance.organizationFieldsData!.currencyName =
                    countryDropdownValue!.currencyName;
              }
            }
          }
        }
      }
    }
    return list;
  }

  /// Service call for currency

  Future<List<CurrencyNameDAO>> getCurrency() async {
    http.Response response = await _service.getDropDownType("lookup/currency");
    List<CurrencyNameDAO> list = [];
    if (response.statusCode == 200) {
      var data = json.decode(response.body);
      for (var objects in data["data"])
        list.add(CurrencyNameDAO.fromJson(objects));

      if (isOrgUpdate! && _buModel!.currencyCode != null) {
        for (int i = 0; i < list.length; i++) {
          if (_buModel!.currencyCode == list[i].code) {
            currencyDropdown = list[i];
            AppController.instance.getOrganizationFieldsData.currencyCode =
                currencyDropdown.code;
          }
        }
      }
    }
    return list;
  }

  /// Service call for businessType

  Future<List<BusinessRelationDAO>> getBusinessType() async {
    http.Response response =
        await _service.getDropDownType("lookup/businessType");
    List<BusinessRelationDAO> list = [];
    if (response.statusCode == 200) {
      var data = json.decode(response.body);
      for (var objects in data["data"]) {
        list.add(BusinessRelationDAO.fromJson(objects));
      }

      /// assign bu type values
      if (isOrgUpdate! && _buModel!.type != null) {
        for (int i = 0; i < list.length; i++) {
          if (_buModel!.type == list[i].type) {
            setState(() {
              businessTypeDropdown = list[i];
            });
            if (businessTypeDropdown != null)
              AppController.instance.getOrganizationFieldsData.businessType =
                  businessTypeDropdown!.type;
          }
        }
      }
    }
    return list;
  }

  /// Creating businessType lookup

  buildBusinessTypeDropdown(String text) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: RichText(
                      text: TextSpan(children: [
                        TextSpan(
                          text: Language().getString(text, selectedLang),
                          style: TextStyle(
                              fontSize: StyleView.FONT_SIZE_15,
                              fontFamily: StyleView.FONT_TITLE,
                              fontWeight: FontWeight.w500,
                              color: Colors.black),
                        ),
                        // TextSpan(
                        //     text: "\*",
                        //     style: TextStyle(
                        //         fontSize: StyleView.FONT_SIZE_15,
                        //         color: Colors.red))
                      ]),
                    )),
              )),
        ),
        Expanded(
          flex: 2,
          child: Container(
              color: Colors.white70,
              padding: EdgeInsets.only(left: 5, right: 5),
              child: DropdownButton<BusinessRelationDAO>(
                  onTap: () {
                    return CommonMethods.hideKeyboard(context);
                  },
                  value: businessTypeDropdown,
                  isExpanded: true,
                  hint: Text(
                      Language().getString(
                          Constants.SELECT_BUSINESS_TYPE, selectedLang),
                      style: TextStyle(fontFamily: StyleView.FONT_TITLE)),
                  underline: SizedBox(),
                  onChanged: (BusinessRelationDAO? data) {
                    setState(() {
                      businessTypeDropdown = data;
                    });
                    AppController.instance.getOrganizationFieldsData
                        .businessType = data!.type;

                    AppController.instance.getOrganizationFieldsData
                        .regentityType = data.type;
                  },
                  items: _businessTypeList.map((BusinessRelationDAO model) {
                    return new DropdownMenuItem<BusinessRelationDAO>(
                      child: new Text(model.type!,
                          style: TextStyle(fontFamily: StyleView.FONT_TITLE)),
                      value: model,
                    );
                  }).toList())),
        )
      ],
    );
  }

  /// Dynamically creating directors fields

  buildTextFormFieldsDialog(String _labelText, TextEditingController controller,
      bool isKeyPadNumber) {
    return Container(
        margin: EdgeInsets.symmetric(vertical: 7.0),
        height: 50,
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(
              5.0,
            )),
        child: new TextFormField(
            keyboardType: isKeyPadNumber ? TextInputType.number : null,
            style: TextStyle(fontFamily: StyleView.FONT_TITLE),
            controller: controller,
            decoration: StyleView.getInputDecoration(
              helper: _labelText,
            ),
            onChanged: (text) => {}));
  }

  /// Highlite text

  buildTextField(String _text) {
    return Row(
      children: <Widget>[
        Align(
            child: Text(_text,
                style: TextStyle(
                    fontFamily: StyleView.FONT_TITLE,
                    fontWeight: FontWeight.bold,
                    fontSize: StyleView.FONT_SIZE_15)))
      ],
    );
  }

  /// Fecthing directors data to text

  buildText(String title, String subTitle) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(title,
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_15,
                            fontFamily: StyleView.FONT_TITLE))),
              )),
        ),
        Expanded(
          flex: 2,
          child: Container(
              color: Colors.white70,
              height: 50,
              padding: EdgeInsets.only(left: 5),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  subTitle,
                  style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                ),
              )),
        )
      ],
    );
  }

  /// Creating parent lookup

  buildParentDetailsDropDown(
      String textName, TextEditingController _controller) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(textName,
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: StyleView.FONT_TITLE))),
                  )),
            ),
            Expanded(
                flex: 2,
                child: Container(
                    height: 50,
                    padding: EdgeInsets.all(5),
                    decoration: BoxDecoration(color: Colors.white),
                    child: (isOrgUpdate! && dropdownValue != null)
                        ? Align(
                            alignment: Alignment.centerLeft,
                            child: Text(dropdownValue!.businessName!,
                                style: TextStyle(
                                    fontFamily: StyleView.FONT_TITLE)))
                        : DropdownButton<BuBasicDataModel>(
                            value: dropdownValue,
                            isExpanded: true,
                            underline: SizedBox(),
                            onChanged: (BuBasicDataModel? data) {
                              setState(() {
                                dropdownValue = data;
                                _bussinessnameController.text =
                                    data!.businessName!;
                                parentWebsite = dropdownValue!.website != null
                                    ? dropdownValue!.website
                                    : "";
                                parentHob =
                                    dropdownValue!.headOfBusiness != null
                                        ? dropdownValue!.headOfBusiness
                                        : "";
                                parentLocation = dropdownValue!.location != null
                                    ? dropdownValue!.location
                                    : "";
                              });

                              AppController.instance.organizationFieldsData!
                                      .parentBuId =
                                  dropdownValue != null
                                      ? dropdownValue!.id
                                      : "";
                            },
                            items:
                                _bubasicdatamodel.map((BuBasicDataModel model) {
                              return new DropdownMenuItem<BuBasicDataModel>(
                                child: new Text(model.businessName!,
                                    style: TextStyle(
                                        fontFamily: StyleView.FONT_TITLE)),
                                value: model,
                              );
                            }).toList())))
          ],
        ));
  }

  /// Dynamically creating business basic fields

  buildTableContent(
      String textName, TextEditingController _controller, bool isMandatory) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: isMandatory
                        ? RichText(
                            text: TextSpan(children: [
                              TextSpan(
                                text: Language()
                                    .getString(textName, selectedLang),
                                style: TextStyle(
                                    fontSize: StyleView.FONT_SIZE_15,
                                    fontFamily: StyleView.FONT_TITLE,
                                    fontWeight: FontWeight.w500,
                                    color: Colors.black),
                              ),
                              TextSpan(
                                  text: "\*",
                                  style: TextStyle(
                                      fontSize: StyleView.FONT_SIZE_15,
                                      color: Colors.red))
                            ]),
                          )
                        : Text(Language().getString(textName, selectedLang),
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontWeight: FontWeight.w500,
                                fontFamily: StyleView.FONT_TITLE))),
              )),
        ),
        Expanded(
            flex: 2,
            child: Container(
              color: Colors.white70,
              padding: EdgeInsets.only(left: 5),
              child: TextFormField(
                controller: _controller,
                keyboardType: (textName == Constants.OFFICE_NUMBER)
                    ? TextInputType.numberWithOptions(signed: true)
                    : TextInputType.text,
                textInputAction: TextInputAction.next,
                style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                decoration: InputDecoration(
                  hintText: Language().getString(textName, selectedLang),
                  border: InputBorder.none,
                ),
                onChanged: (text) => {
                  text = _controller.text,
                  updateData(textName, _controller.text)
                },
              ),
            ))
      ],
    );
  }

  buildGSTInputField() {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                        Language().getString(Constants.GST_NO, selectedLang),
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_15,
                            fontWeight: FontWeight.w500,
                            fontFamily: StyleView.FONT_TITLE))),
              )),
        ),
        Expanded(
            flex: 2,
            child: Container(
              color: Colors.white70,
              padding: EdgeInsets.only(left: 5),
              child: Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _gstNumberController,
                      keyboardType: TextInputType.text,
                      textInputAction: TextInputAction.next,
                      style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                      decoration: InputDecoration(
                        hintText: Language()
                            .getString(Constants.GST_NO, selectedLang),
                        border: InputBorder.none,
                      ),
                      inputFormatters: [
                        new LengthLimitingTextInputFormatter(15),
                      ],
                      onChanged: (text) async {
                        setState(() {
                          isGstVerified = false;
                          _gstNumberController.value = _gstNumberController
                              .value
                              .copyWith(text: text.toUpperCase());
                        });
                        updateData(Constants.GST_NO, _gstNumberController.text);
                      },
                    ),
                  ),
                  showGstVerifiedStatus()
                ],
              ),
            )),
      ],
    );
  }

  Future<void> validateGSTNumber(String value) async {
    http.Response response = await _service.getVerifyGSTNumber(value);
    setState(() => isEnableGstLoader = false);
    if (response.statusCode == 200) {
      var data = json.decode(response.body);
      bool isExist = data['flag'];
      final action = await Dialogs.yesCancelDialog(
          context,
          (isExist)
              ? Language().getString(Constants.SUCCESS, selectedLang)
              : Language().getString(Constants.ERROR, selectedLang),
          data['message'],
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
      if (action == DialogAction.yes) {
        if (isExist) {
          setState(() {
            isGstNotVerified = false;
            isGstVerified = true;
          });
        } else {
          setState(() {
            isGstNotVerified = true;
            isGstVerified = false;
          });
        }
      }
    }
  }

  Widget showGstVerifiedStatus() {
    if (isEnableGstLoader) {
      return Container(
        width: 15,
        height: 15,
        margin: EdgeInsets.only(right: 5),
        child: CircularProgressIndicator(
          color: Colors.red,
          strokeWidth: 2,
        ),
      );
    }
    if (isGstVerified) {
      return Container(
          width: 15,
          height: 15,
          margin: EdgeInsets.only(right: 5),
          child: Icon(
            Icons.verified,
            color: Colors.green,
            size: 18,
          )
          //  CircularProgressIndicator(
          //   color: Colors.red,
          //   strokeWidth: 2,
          // ),
          );
    }

    // if (_gstNumberController.text.length > 0 && !isGstVerified) {
    //   return TextButton(
    //       onPressed: () {
    //         CommonMethods.hideKeyboard(context);
    //         setState(() {
    //           isEnableGstLoader = true;
    //           isGstVerified = false;
    //         });
    //         validateGSTNumber(_gstNumberController.text);
    //       },
    //       child: Text("Verify"));
    // }

    return SizedBox();
  }

  /// Save business basic data onChage()

  void updateData(String fieldName, String text) {
    switch (fieldName) {
      case Constants.BUSSINESS_INPUT_STRING:
        AppController.instance.organizationFieldsData!.businessName = text;
        AppController.instance.getOrganizationFieldsData.regOrgName = text;
        break;

      case Constants.SHORT_NAME_STRING:
        AppController.instance.organizationFieldsData!.shortName = text;
        break;
      case Constants.WEBSITE_STRING:
        AppController.instance.organizationFieldsData!.website = text;
        break;

      case Constants.BUSSINESS_UNIT_WEBSITE_NAME_STRING:
        AppController.instance.organizationFieldsData!.parentBusinessWebsite =
            text;
        break;
      case Constants.STR_OWNER:
        AppController.instance.organizationFieldsData!.businessHob = text;
        break;
      case Constants.BUSINESS_LOCATION_NUMBER_STRING:
        AppController.instance.organizationFieldsData!.businessLocation = text;
        break;

      case Constants.OFFICE_NUMBER:
        AppController.instance.organizationFieldsData!.buContactNumber = text;
        break;
      case Constants.MOBILE_NUMBER:
        AppController.instance.organizationFieldsData!.mobileNumber = text;
        break;
      case Constants.GST_NO:
        AppController.instance.organizationFieldsData!.gstNumber = text;
        break;
      case Constants.EMAIL:
        AppController.instance.organizationFieldsData!.invoiceEmail = text;
        break;
      case Constants.PAN:
        AppController.instance.organizationFieldsData!.panCardNumber = text;
        break;
      default:
    }
  }

  /// Creating country lookup

  buildCountryDropdown(String text) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                        Language().getString(
                            Constants.COUNTRY_NAME_STRING, selectedLang),
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_15,
                            fontWeight: FontWeight.w500,
                            color: Colors.black,
                            fontFamily: StyleView.FONT_TITLE))),
              )),
        ),
        Expanded(
          flex: 2,
          child: Container(
              color: Colors.white70,
              padding: EdgeInsets.only(left: 5, right: 5),
              child: DropdownButton<CountryDAO>(
                  onTap: () {
                    return CommonMethods.hideKeyboard(context);
                  },
                  value: countryDropdownValue,
                  isExpanded: true,
                  hint: Text(
                      Language()
                          .getString(Constants.SELECT_COUNTRY, selectedLang),
                      style: TextStyle(fontFamily: StyleView.FONT_TITLE)),
                  underline: SizedBox(),
                  onChanged: (CountryDAO? data) {
                    setState(() {
                      countryDropdownValue = data;
                      currencyValue = countryDropdownValue!.currencyCode;
                      AppController.instance.getOrganizationFieldsData
                          .countryCode = countryDropdownValue!.code;
                      AppController.instance.organizationFieldsData!
                          .currencyCode = currencyValue;

                      AppController.instance.organizationFieldsData!
                              .orgCurrencySymbol =
                          countryDropdownValue!.currencySymbol;
                      AppController.instance.setBuCountryCode =
                          countryDropdownValue!.code;
                      AppController.instance.organizationFieldsData!
                          .currencyName = countryDropdownValue!.currencyName;
                      // _dialCodeController.text =
                      //     countryDropdownValue.countryCode;
                      // AppController.instance.organizationFieldsData
                      //     .orgCountryDialCode = _dialCodeController.text;
                    });
                  },
                  items: _countryList.map((CountryDAO model) {
                    return new DropdownMenuItem<CountryDAO>(
                      child: new Text(model.name!,
                          style: TextStyle(fontFamily: StyleView.FONT_TITLE)),
                      value: model,
                    );
                  }).toList())),
        )
      ],
    );
  }

  Widget addLocationButtonView() {
    return Container(
        padding: EdgeInsets.only(bottom: 16),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            RichText(
              text: TextSpan(children: [
                TextSpan(
                  text: Language().getString("Add Location", selectedLang),
                  style: TextStyle(
                      fontSize: StyleView.FONT_SIZE_15,
                      fontFamily: StyleView.FONT_TITLE,
                      fontWeight: StyleView.fontSemiBold,
                      color: Colors.black),
                ),
                TextSpan(
                    text: "\*",
                    style: TextStyle(
                        fontSize: StyleView.FONT_SIZE_15, color: Colors.red))
              ]),
            ),
            // Text(
            //   "Add Location",
            //   style: TextStyle(
            //       fontWeight: StyleView.fontSemiBold, color: Colors.black),
            // ),
            SizedBox(
                height: 25.0,
                width: 25.0,
                child: FloatingActionButton(
                  heroTag: null,
                  onPressed: () async {
                    CommonMethods.hideKeyboard(context);

                    Locations? data;
                    if (kIsWeb) {
                      data = await Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => SelectLocation(
                                  buId: widget.orgId,
                                  isFromLocationTab: false,
                                  isLocationUpdate: false,
                                  locationData: null,
                                  locationType: locationsList.length == 0
                                      ? Constants.KEY_MAIN_OFFICE
                                      : Constants.KEY_STOCK_RECEIVE)));
                    } else {
                      data = await Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => SelectLocation(
                                  buId: widget.orgId,
                                  isFromLocationTab: false,
                                  isLocationUpdate: false,
                                  locationData: null,
                                  locationType: locationsList.length == 0
                                      ? Constants.KEY_MAIN_OFFICE
                                      : Constants.KEY_STOCK_RECEIVE)));
                    }
                    if (data != null) {
                      setState(() {
                        locationsList.add(data!);
                        AppController.instance.setLocations = locationsList;
                      });
                    }
                  },
                  child: Icon(Icons.add, size: 18),
                  backgroundColor: Color(Constants.APP_COLOR),
                ))
          ],
        ));
  }

  Widget showAvailableLocations() {
    return Column(
      children: [
        for (int i = 0; i < locationsList.length; i++)
          LocationCard(
              converssionNames: _namesData,
              contactName: locationsList[i].contactPerson ?? "",
              locationName: locationsList[i].locationName ?? '',
              phoneNumber: locationsList[i].contactNumber ?? "",
              onPressEdit: () async {
                final Locations? data;
                if (kIsWeb) {
                  data = await Navigator.push(
                      context,
                      new MaterialPageRoute(
                          builder: (context) => SelectLocation(
                                buId: widget.orgId,
                                isFromLocationTab: false,
                                isLocationUpdate: true,
                                locationData: locationsList[i],
                                locationType: locationsList[i].locationType,
                              )));
                } else {
                  data = await Navigator.push(
                      context,
                      new MaterialPageRoute(
                          builder: (context) => SelectLocation(
                                buId: widget.orgId,
                                isFromLocationTab: false,
                                isLocationUpdate: true,
                                locationData: locationsList[i],
                                locationType: locationsList[i].locationType,
                              )));
                }

                if (data != null) {
                  setState(() {
                    locationsList[i] = data!;
                    AppController.instance.setLocations = locationsList;
                  });
                }
              },
              onPressCall: () {
                if (kIsWeb) {
                  return;
                }
                Uri uri = Uri.parse("tel:" + locationsList[i].contactNumber!);
                launchUrl(uri);
              },
              address: locationsList[i].addressDetails!)
      ],
    );
  }

  @override
  void setState(VoidCallback fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  Widget build(BuildContext context) {
    ToastContext().init(context);
    return Stack(
      children: [
        Container(
          margin: EdgeInsets.only(top: 16),
          padding: EdgeInsets.all(8.0),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(5.0),
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                    offset: Offset(0.0, 5.0),
                    blurRadius: 5.0,
                    color: Colors.grey)
              ]),
          child: SingleChildScrollView(
              child: Container(
                  child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Container(
                  margin: EdgeInsets.symmetric(vertical: 5.0),
                  child: Container(
                    decoration: BoxDecoration(
                        border: Border.all(color: Colors.black),
                        borderRadius: BorderRadius.circular(5.0)),
                    child: ExpansionTile(
                        initiallyExpanded: true,
                        title: Text(
                          Language().getString(
                              Constants.BASIC_DETAILS_STRING, selectedLang),
                          style: TextStyle(
                              color: Colors.black,
                              fontWeight: StyleView.fontMedium),
                        ),
                        children: <Widget>[
                          Column(children: <Widget>[
                            SizedBox(
                                height: 1,
                                child: Container(
                                    color: Color(Constants.GREY_COLOR))),
                            buildTableContent(Constants.BUSSINESS_INPUT_STRING,
                                _businessName, true),
                            SizedBox(
                                height: 1,
                                child: Container(
                                    color: Color(Constants.GREY_COLOR))),
                            buildTableContent(
                                Constants.STR_OWNER,
                                _headofbussinessController,
                                true),
                            SizedBox(
                                height: 1,
                                child: Container(
                                    color: Color(Constants.GREY_COLOR))),
                            buildMobileNumberTextFormField(
                                Constants.MOBILE_NUMBER,
                                _mobileNumberController,
                                isOrgUpdate! ? false : true,
                                _dialCodeController),
                            SizedBox(
                                height: 1,
                                child: Container(
                                    color: Color(Constants.GREY_COLOR))),
                            buildMobileNumberTextFormField(
                                Constants.OFFICE_NUMBER,
                                _officeNumberController,
                                true,
                                _officeDialCodeController),
                            SizedBox(
                                height: 1,
                                child: Container(
                                    color: Color(Constants.GREY_COLOR))),
                            buildBusinessTypeDropdown(Constants.BUSINESS_TYPE),
                            SizedBox(
                                height: 1,
                                child: Container(
                                    color: Color(Constants.GREY_COLOR))),
                            buildTableContent(Constants.WEBSITE_STRING,
                                _businesswebsite, false),
                            SizedBox(
                                height: 1,
                                child: Container(
                                    color: Color(Constants.GREY_COLOR))),
                            buildGSTInputField(),
                            SizedBox(
                                height: 1,
                                child: Container(
                                    color: Color(Constants.GREY_COLOR))),
                            // buildTableContent(Constants.GST_NO,
                            //     _gstNumberController, false),
                            buildTableContent(
                                Constants.EMAIL, emailController, false),
                            SizedBox(
                                height: 1,
                                child: Container(
                                    color: Color(Constants.GREY_COLOR))),
                            buildTableContent(
                                Constants.PAN, panController, false),
                          ])
                        ]),
                  )),
              new SizedBox(height: 8),
              fileAttachment(),
              addLocationButtonView(),
              locationsList.length > 0 ? showAvailableLocations() : Container(),
              // Container(
              //     margin: EdgeInsets.symmetric(
              //       vertical: 5.0,
              //     ),
              //     child: ClipRRect(
              //       borderRadius: BorderRadius.circular(5.0),
              //       child: Container(
              //         color: Colors.white,
              //         child: ExpansionTile(
              //             title: Text(
              //               Language().getString(
              //                   Constants.STR_COUNTRY_DETAILS, selectedLang),
              //               style: TextStyle(
              //                   color: Colors.black,
              //                   fontWeight: FontWeight.w600),
              //             ),
              //             children: <Widget>[
              //               Column(children: <Widget>[
              //                 SizedBox(
              //                     height: 0.5,
              //                     child: Container(
              //                         color: Color(Constants.GREY_COLOR))),
              //                 buildCountryDropdown(
              //                     Constants.COUNTRY_CODE_STRING),
              //                 SizedBox(
              //                     height: 0.5,
              //                     child: Container(
              //                         color: Color(Constants.GREY_COLOR))),
              //                 TextView(
              //                     title: Language().getString(
              //                         Constants.CURRENCY_CODE_STRING,
              //                         selectedLang),
              //                     value: currencyValue != null
              //                         ? currencyValue
              //                         : ""),
              //                 // buildText(
              //                 //     Language().getString(
              //                 //         Constants.CURRENCY_CODE_STRING,
              //                 //         selectedLang),
              //                 //     currencyValue != null ? currencyValue : ""),
              //                 SizedBox(
              //                     height: 0.5,
              //                     child: Container(
              //                         color: Color(Constants.GREY_COLOR))),
              //                 TextView(
              //                     title: Language().getString(
              //                         Constants.CURRENCY_NAME, selectedLang),
              //                     value: countryDropdownValue != null
              //                         ? countryDropdownValue!.currencyName
              //                         : ""),
              //                 SizedBox(
              //                     height: 0.5,
              //                     child: Container(
              //                         color: Color(Constants.GREY_COLOR))),
              //                 TextView(
              //                     title: Language().getString(
              //                         Constants.CURRENCY_SYMBOL, selectedLang),
              //                     value: countryDropdownValue != null
              //                         ? countryDropdownValue!.currencySymbol
              //                         : "")
              //               ])
              //             ]),
              //       ),
              //     )),
              // SizedBox(
              //   height: StyleView.HEIGHT_20,
              // ),
              this.showParentDetails(),
            ],
          ))
              // ]
              ),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    );
  }

  updateOrganizationDataDefault(BusinessUnitModel orgDetails) {
    AppController.instance.setBuLogoImagePath = orgDetails.buLogoImagePath!;
    imageRelativePath = orgDetails.buLogoImagePath!;
    if (orgDetails.contactDetails != null) {
      AppController.instance.organizationFieldsData!.contactName =
          orgDetails.contactDetails!.primarycontactname;
      AppController.instance.organizationFieldsData!.contactAddress =
          orgDetails.contactDetails!.address!.addressformat;
      AppController.instance.organizationFieldsData!.contactAddressFormat =
          orgDetails.contactDetails!.address!.addressformat;
      AppController.instance.organizationFieldsData!.buildingNo =
          orgDetails.contactDetails!.address!.buildingNo;
      AppController.instance.organizationFieldsData!.houseNo =
          orgDetails.contactDetails!.address!.buildinghousenumber;
      AppController.instance.organizationFieldsData!.streetName =
          orgDetails.contactDetails!.address!.buildingstreetname;
      AppController.instance.organizationFieldsData!.locality =
          orgDetails.contactDetails!.address!.colonysectorArealocality;
      AppController.instance.organizationFieldsData!.city =
          orgDetails.contactDetails!.address!.villagetowncity;
      AppController.instance.organizationFieldsData!.taluk =
          orgDetails.contactDetails!.address!.taluk;
      AppController.instance.organizationFieldsData!.landMark =
          orgDetails.contactDetails!.address!.landmark;
      AppController.instance.organizationFieldsData!.state =
          orgDetails.contactDetails!.address!.state;
      AppController.instance.organizationFieldsData!.district =
          orgDetails.contactDetails!.address!.district;
      AppController.instance.organizationFieldsData!.postalCode =
          orgDetails.contactDetails!.address!.postcode;
      AppController.instance.organizationFieldsData!.country =
          orgDetails.contactDetails!.address!.country;
      AppController.instance.organizationFieldsData!.orgPlotNo =
          orgDetails.contactDetails!.address!.plotNo;
      AppController.instance.organizationFieldsData!.invoicePhoneNumber =
          orgDetails.contactDetails!.address!.phoneNumberOnInvoice;
      AppController.instance.organizationFieldsData!.invoiceEmail =
          orgDetails.contactDetails!.address!.emailOnInvoice;
    }

    if (orgDetails.registration != null) {
      AppController.instance.organizationFieldsData!.regOrgName =
          orgDetails.registration!.govtregisteredName;
      AppController.instance.organizationFieldsData!.regOrgDate =
          orgDetails.registration!.registrationDate;
      AppController.instance.organizationFieldsData!.regOrgCity =
          orgDetails.registration!.registrationCity;
      AppController.instance.organizationFieldsData!.regOrgState =
          orgDetails.registration!.registrationState;
      AppController.instance.organizationFieldsData!.regOrgCountry =
          orgDetails.registration!.registrationCountry;
      AppController.instance.organizationFieldsData!.regentityType =
          orgDetails.registration!.legalentityType;
      AppController.instance.organizationFieldsData!.panCardNumber =
          orgDetails.registration!.panNumber;
      AppController.instance.organizationFieldsData!.cinCardNumber =
          orgDetails.registration!.cinNumber;
    }

    for (int i = 0; i < orgDetails.directors!.length; i++) {
      _directorsList.add(DirectorsData(
          personName: orgDetails.directors![i].personName,
          personSchemeName:
              orgDetails.directors![i].personidentificationSchemename,
          personIdentificationNumber:
              orgDetails.directors![i].personidentificationNumber,
          digitalSignature: orgDetails.directors![i].digitalSignature));
    }
    AppController.instance.organizationFieldsData!.directorsData =
        _directorsList;

    for (int i = 0; i < orgDetails.taxScheme!.length; i++) {
      _taxData.add(TaxSchemeData(
          govttaxscheme_name: orgDetails.taxScheme![i].schemeName,
          govttaxscheme_number: orgDetails.taxScheme![i].schemeNumber,
          taxexemption_reason: orgDetails.taxScheme![i].reason));
    }

    AppController.instance.getOrganizationFieldsData.taxSchemeArray = _taxData;

    for (int i = 0; i < orgDetails.regulation!.length; i++) {
      _regulationData.add(RegulationData(
          govtbusinessSchemeid: orgDetails.regulation![i].govtbusinessSchemeid,
          govtregistrationId: orgDetails.regulation![i].govtregistrationId));
    }

    AppController.instance.getOrganizationFieldsData.regulationArray =
        _regulationData;

    for (int i = 0; i < orgDetails.exports!.length; i++) {
      _exportsData.add(ExportsModel(
          govtregistrationSchemeid:
              orgDetails.exports![i].govtregistrationSchemeid,
          govtregistrationSchemename:
              orgDetails.exports![i].govtregistrationSchemename));
    }

    AppController.instance.getOrganizationFieldsData.exportsArray =
        _exportsData;

    for (int i = 0; i < orgDetails.imports!.length; i++) {
      _importsData.add(ExportsModel(
          govtregistrationSchemeid:
              orgDetails.imports![i].govtregistrationSchemeid,
          govtregistrationSchemename:
              orgDetails.imports![i].govtregistrationSchemename));
    }

    AppController.instance.getOrganizationFieldsData.importsArray =
        _importsData;

//       /**
//          * updating stockreceive details
//          */

    locationsList.addAll(orgDetails.locationsList!);
    AppController.instance.setLocations = orgDetails.locationsList!;
    // for (int i = 0; i < orgDetails.locationsList!.length; i++) {
    //   if (orgDetails.locationsList![i].locationType ==
    //       Constants.KEY_STOCK_RECEIVE) {
    //     _stockReceiveData.add(StockDetailsModel(
    //         locationId: orgDetails.locationsList![i].locationId,
    //         locationType: orgDetails.locationsList![i].locationType,
    //         stockLocationNumber: orgDetails.locationsList![i].contactNumber,
    //         stockLocationName: orgDetails.locationsList![i].locationName,
    //         userName: orgDetails.locationsList![i].contactPerson,
    //         buildingNo: orgDetails.locationsList![i].addressDetails!.buildingNo,
    //         houseNo: orgDetails
    //             .locationsList![i].addressDetails!.buildinghousenumber,
    //         streetName:
    //             orgDetails.locationsList![i].addressDetails!.buildingstreetname,
    //         locality: orgDetails
    //             .locationsList![i].addressDetails!.colonysectorArealocality,
    //         landmark: orgDetails.locationsList![i].addressDetails!.landmark,
    //         country: orgDetails.locationsList![i].addressDetails!.country,
    //         state: orgDetails.locationsList![i].addressDetails!.state,
    //         district: orgDetails.locationsList![i].addressDetails!.district,
    //         city: orgDetails.locationsList![i].addressDetails!.villagetowncity,
    //         taluka: "",
    //         plotNo: orgDetails.locationsList![i].addressDetails!.plotNo,
    //         postalCode: orgDetails.locationsList![i].addressDetails!.postcode));
    //   } else if (orgDetails.locationsList![i].locationType ==
    //       Constants.KEY_STOCK_DISPATCH) {
    //     _stockDispatchData.add(StockDetailsModel(
    //         locationId: orgDetails.locationsList![i].locationId,
    //         locationType: orgDetails.locationsList![i].locationType,
    //         stockLocationNumber: orgDetails.locationsList![i].contactNumber,
    //         stockLocationName: orgDetails.locationsList![i].locationName,
    //         userName: orgDetails.locationsList![i].contactPerson,
    //         buildingNo: orgDetails.locationsList![i].addressDetails!.buildingNo,
    //         houseNo: orgDetails
    //             .locationsList![i].addressDetails!.buildinghousenumber,
    //         streetName:
    //             orgDetails.locationsList![i].addressDetails!.buildingstreetname,
    //         locality: orgDetails
    //             .locationsList![i].addressDetails!.colonysectorArealocality,
    //         landmark: orgDetails.locationsList![i].addressDetails!.landmark,
    //         country: orgDetails.locationsList![i].addressDetails!.country,
    //         state: orgDetails.locationsList![i].addressDetails!.state,
    //         district: orgDetails.locationsList![i].addressDetails!.district,
    //         city: orgDetails.locationsList![i].addressDetails!.villagetowncity,
    //         taluka: "",
    //         plotNo: orgDetails.locationsList![i].addressDetails!.plotNo,
    //         postalCode: orgDetails.locationsList![i].addressDetails!.postcode));
    //   } else if (orgDetails.locationsList![i].locationType ==
    //       Constants.KEY_MAIN_OFFICE) {
    //     AppController.instance.getOrganizationFieldsData.mainOfficeLocationId =
    //         orgDetails.locationsList![i].locationId;
    //   } else {
    //     print("ORG STEP-1:  location type not getting");
    //   }
    // }
    // AppController.instance.getOrganizationFieldsData.stockReceiveArray =
    //     _stockReceiveData;
    // AppController.instance.getOrganizationFieldsData.stockDispatchArray =
    //     _stockDispatchData;

    for (int i = 0; i < orgDetails.bankDetailsReceives!.length; i++) {
      _bankDetails.add(BankDetails(
          bankname: orgDetails.bankDetailsReceives![i].bankName,
          bankaccountname: orgDetails.bankDetailsReceives![i].bankAccountName,
          bankAccountNumber:
              orgDetails.bankDetailsReceives![i].bankAccountNumber,
          epayCode: orgDetails.bankDetailsReceives![i].ePayCode,
          swiftCode: orgDetails.bankDetailsReceives![i].swifTcode,
          micrCode: orgDetails.bankDetailsReceives![i].micrCode,
          ifscCode: orgDetails.bankDetailsReceives![i].ifscCode,
          isShowInvoiceView:
              orgDetails.bankDetailsReceives![i].isShowBankDataInInvoice));
    }
    AppController.instance.getOrganizationFieldsData.bankReceiveArray =
        _bankDetails;

    if (orgDetails.paymentTerms != null) {
      AppController.instance.getOrganizationFieldsData.invoiceCurrencyCode =
          orgDetails.paymentTerms!.invoicecurrencycode;

      AppController.instance.getOrganizationFieldsData.invoicePaymentTerms =
          orgDetails.paymentTerms!.invoicePaymentTerms;

      AppController.instance.organizationFieldsData!.paymentTermCode =
          orgDetails.paymentTerms!.termCode;
      AppController.instance.organizationFieldsData!.paymentTermDays =
          orgDetails.paymentTerms!.paymentTermsDays;

      if (orgDetails.paymentTerms!.penaltyAmount != null &&
          orgDetails.paymentTerms!.penaltyAmount!.value != null) {
        AppController.instance.getOrganizationFieldsData.penaltyAmountReason =
            orgDetails.paymentTerms!.penaltyAmount!.reason;

        AppController.instance.organizationFieldsData!.penaltyCode =
            orgDetails.paymentTerms!.penaltyAmount!.code;
        AppController
                .instance.getOrganizationFieldsData.penaltyAmountPercentage =
            "${orgDetails.paymentTerms!.penaltyAmount!.value} %";
      }

      if (orgDetails.paymentTerms!.advancePayment != null &&
          orgDetails.paymentTerms!.advancePayment!.value != null) {
        AppController.instance.getOrganizationFieldsData.advancePaymentValue =
            orgDetails.paymentTerms!.advancePayment!.isActive!
                ? Constants.YES_STRING
                : Constants.NO_STRING;

        AppController
                .instance.getOrganizationFieldsData.advancePaymentPercentage =
            "${orgDetails.paymentTerms!.advancePayment!.value} %";
      }
      if (orgDetails.paymentTerms!.termsList != null &&
          orgDetails.paymentTerms!.termsList!.length > 0) {
        for (int i = 0; i < orgDetails.paymentTerms!.termsList!.length; i++) {
          _termsList.add(TermsData(
              termType: orgDetails.paymentTerms!.termsList![i].termType,
              termDescription:
                  orgDetails.paymentTerms!.termsList![i].termDescription,
              imageRelativePath: orgDetails.paymentTerms!.termsList![i].file));
        }

        AppController.instance.getOrganizationFieldsData
            .termsAndConditionsList = _termsList;
      }

      AppController.instance.getOrganizationFieldsData.paymentComments =
          orgDetails.paymentTerms!.comment;

      if (orgDetails.isInpersonOrderAccept!) {
        AppController
            .instance.getOrganizationFieldsData.setInpersonOrderAccept = true;
      } else {
        AppController
            .instance.getOrganizationFieldsData.setInpersonOrderAccept = false;
      }
    }
  }

  buildMobileNumberTextFormField(
      String textName,
      TextEditingController _controller,
      bool isEnable,
      TextEditingController _countryCodeController) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: RichText(
                      text: TextSpan(children: [
                        TextSpan(
                          text: Language().getString(textName, selectedLang),
                          style: TextStyle(
                              fontSize: 14.0,
                              fontFamily: StyleView.FONT_TITLE,
                              fontWeight: FontWeight.w500,
                              color: Colors.black),
                        ),
                        if (textName == Constants.MOBILE_NUMBER)
                          TextSpan(
                              text: "\*",
                              style:
                                  TextStyle(fontSize: 14.0, color: Colors.red)),
                      ]),
                    )),
              )),
        ),
        Expanded(
            flex: 2,
            child: Row(
              children: [
                Expanded(
                  child: Container(
                      color: Colors.white70,
                      padding: EdgeInsets.only(left: 5),
                      child: TextFormField(
                          controller: _countryCodeController,
                          inputFormatters: [
                            new LengthLimitingTextInputFormatter(6),
                            CommonMethods.inputTextFormatter(isNumber: true)
                          ],
                          keyboardType:
                              TextInputType.numberWithOptions(signed: true),
                          textInputAction: TextInputAction.next,
                          onChanged: (value) {
                            if (textName == Constants.MOBILE_NUMBER) {
                              _dialCodeController.text =
                                  "+" + _countryCodeController.text;
                              _countryCodeController.selection =
                                  TextSelection.fromPosition(TextPosition(
                                      offset:
                                          _countryCodeController.text.length));
                              AppController.instance.organizationFieldsData!
                                      .orgCountryDialCode =
                                  _countryCodeController.text;
                            } else {
                              _officeDialCodeController.text =
                                  "+" + _countryCodeController.text;
                              _countryCodeController.selection =
                                  TextSelection.fromPosition(TextPosition(
                                      offset:
                                          _countryCodeController.text.length));
                              AppController.instance.organizationFieldsData!
                                  .officeDialCode = _countryCodeController.text;
                            }
                          },
                          decoration: InputDecoration(
                              border: InputBorder.none,
                              hintText: Language()
                                  .getString(Constants.CODE, selectedLang),
                              hintStyle: TextStyle(
                                  fontSize: 11.0, color: Colors.black)))),
                ),
                Expanded(
                  flex: 2,
                  child: Container(
                    color: Colors.white70,
                    child: TextFormField(
                      controller: _controller,
                      enabled: isEnable,
                      keyboardType:
                          TextInputType.numberWithOptions(signed: true),
                      textInputAction: TextInputAction.next,
                      style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                      decoration: InputDecoration(
                        hintText: textName,
                        border: InputBorder.none,
                      ),
                      inputFormatters: [
                        new LengthLimitingTextInputFormatter(10),
                        CommonMethods.inputTextFormatter(isNumber: true)
                      ],
                      onChanged: (text) => {
                        text = _controller.text,
                        updateData(textName, _controller.text)
                      },
                    ),
                  ),
                ),
              ],
            ))
      ],
    );
  }

  showParentDetails() {
    if (_bubasicdatamodel.length > 0) {
      if (isShowParentDetailsView) {
        return Container(
          child: Column(
            children: <Widget>[
              buildTextField(Language()
                  .getString(Constants.BUSSINESS_DETAILS_STRING, selectedLang)),
              SizedBox(height: StyleView.HEIGHT_5),
              Container(
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      border: Border.all(color: Colors.grey)),
                  child: ExpansionTile(
                      title: Text((isOrgUpdate! && dropdownValue != null)
                          ? dropdownValue!.businessName
                          : Language().getString(
                              Constants.BUSSINESS_DETAILS_STRING,
                              selectedLang)),
                      children: <Widget>[
                        Column(children: <Widget>[
                          buildParentDetailsDropDown(
                              Language().getString(
                                  Constants.BUSINESS_UNIT_STRING, selectedLang),
                              _bussinessnameController),
                          SizedBox(
                              height: 1,
                              child: Container(
                                color: Color(Constants.GREY_COLOR),
                              )),
                          buildText(
                              Language().getString(
                                  Constants.BUSSINESS_UNIT_WEBSITE_NAME_STRING,
                                  selectedLang),
                              parentWebsite != null ? parentWebsite! : ""),
                          SizedBox(
                              height: 1,
                              child: Container(
                                color: Color(Constants.GREY_COLOR),
                              )),
                          buildText(
                              Language().getString(
                                  Constants.STR_OWNER,
                                  selectedLang),
                              parentHob!),
                        ])
                      ])),
            ],
          ),
        );
      } else {
        return Container();
      }
    } else {
      return Container();
    }
  }

  Future<List<BuBasicDataModel>> getUserBuList() async {
    String body = json.encode({"id": userId});
    var response = await _organizationService
        .getBulistByUserId(body: body, token: "")
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<BuBasicDataModel> _list = [];
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var responseBody = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(responseBody)) {
        for (var obj in responseBody) {
          _list.add(BuBasicDataModel.fromJson(obj));
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
      return _list;
  }

  Widget fileAttachment() {
    return Column(
      children: [
        Container(
            child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              "Upload Logo",
              style: TextStyle(
                  fontWeight: StyleView.fontSemiBold, color: Colors.black),
            ),
            SizedBox(
                height: 25.0,
                width: 25.0,
                child: FloatingActionButton(
                  onPressed: () async {
                    CommonMethods.hideKeyboard(context);
                    if (kIsWeb) {
                      uploadWebAttachment();
                    } else {
                      openBottomSheet(context, pdfRead: true);
                    }
                  },
                  child: Icon(Icons.add, size: 18),
                  backgroundColor: Color(Constants.APP_COLOR),
                ))
          ],
        )),
        Container(
            child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: displayImageView(),
        )),
      ],
    );
  }

  Future<void> uploadWebAttachment() async {
    PlatformFile? selectedFile;
    selectedFile =
        await CommonMethods().getFileUpload(context, isForMultiFile: true);
    if (selectedFile != null) {
      Uint8List bytes = selectedFile.bytes!;
      setState(() => isLoadingProgress = true);
      uploadBuLogo(
          fileImage: bytes,
          fileName: "bu_logo_${selectedFile.name}",
          fileType: selectedFile.extension == 'pdf'
              ? 'application/pdf'
              : 'image/${selectedFile.extension}',
          locationName: "bu_logo");
    }
  }

  openBottomSheet(BuildContext context, {bool pdfRead = false}) {
    return Dialogs.openBottomSheet(
        pdfRead: pdfRead,
        context: context,
        openCamera: (myPicture) async {
          setState(() => imageFile = myPicture);
          List<String> fileName = imageFile!.path.split('/');
          uploadBuLogo(
              fileImage: myPicture,
              fileName: "bu_logo_${fileName.last}",
              fileType: lookupMimeType(imageFile!.path)!,
              locationName: (isOrgUpdate!) ? widget.orgId! : "bu_logo");
        },
        openGallery: (myPicture) async {
          setState(() => imageFile = myPicture);
          List<String> fileName = imageFile!.path.split('/');
          uploadBuLogo(
              fileImage: myPicture,
              fileName: "bu_logo_${fileName.last}",
              fileType: lookupMimeType(imageFile!.path)!,
              locationName: widget.orgId != null ? widget.orgId! : "bu_logo");
        });
  }

  Future<void> uploadBuLogo(
      {required var fileImage,
      required String fileName,
      required String fileType,
      required String locationName}) async {
    if (!kIsWeb) {
      Navigator.of(context).pop();
    }
    if (fileImage != null) {
      setState(() {
        // imageFile = fileImage;
        isLoadingProgress = true;
      });
      // List<String> fileName = imageFile!.path.split('/');
      final String fetchRelativeImagePath = await UploadImageApiService.instance
          .fileUpload(
              imageData: fileImage,
              fileName: fileName,
              fileType: fileType,
              location: locationName);
      setState(() => isLoadingProgress = false);
      if (fetchRelativeImagePath.isNotEmpty) {
        imageRelativePath = fetchRelativeImagePath;
        setState(() {
          AppController.instance.setBuLogoImagePath = fetchRelativeImagePath;
        });
        Toast.show(
          Constants.FILE_UPLAODED,
          duration: Toast.lengthShort,
          gravity: Toast.bottom,
        );
      }
    }
  }

  Widget displayImageView() {
    if (imageRelativePath.isNotEmpty) {
      List<String?> path = imageRelativePath.split('/');

      return DisplayAttachedFile(
          imageRelativePath: '${Constants.IAMGE_BUCKET_URL}$imageRelativePath',
          fileType: lookupMimeType(imageRelativePath)!,
          fileName: path[1].toString(),
          onPress: () {
            if (kIsWeb) {
              AppUtills.launchURL(
                  '${Constants.IAMGE_BUCKET_URL}$imageRelativePath');
              return;
            }
            if (imageRelativePath.isNotEmpty) {
              if (lookupMimeType(imageRelativePath) == 'application/pdf') {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => WebViewPage(
                            url:
                                '${Constants.IAMGE_BUCKET_URL}$imageRelativePath',
                            screenName: "",
                            loadS3PDF: true)));
              } else {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => ImageHeroView(
                              fileUrl:
                                  '${Constants.IAMGE_BUCKET_URL}$imageRelativePath',
                              tagName: "bu_logo",
                            )));
              }
            }
          },
          onRemove: () {
            setState(() => isLoadingProgress = true);
            Future.delayed(Duration(seconds: 1));
            setState(() {
              isLoadingProgress = false;
              imageRelativePath = "";
              AppController.instance.buLogoImagePath = "";
            });
          });
    } else {
      return SizedBox();
    }
  }
}
