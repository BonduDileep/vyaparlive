import 'dart:math';
import 'package:vyaparlive/Organization/controller/organization_controller.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/core/enums/privilleges_enum.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'package:flutx/flutx.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:vyaparlive/Organization/CreateBUPage.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/MyDrawer.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/model/BuBasicDataModel.dart';
import 'package:vyaparlive/model/BuTreeStructureModel.dart';
import 'dart:convert';
import 'package:vyaparlive/service/organization_service.dart';
import 'package:vyaparlive/utills/SharePref.dart';
import 'package:vyaparlive/utills/bu_tree_view.dart';

class AllBUListView extends StatefulWidget {
  AllBUListView({this.title, this.supplerData});
  final String? title;
  final supplerData;

  @override
  _AllBUListViewState createState() => _AllBUListViewState();
}

class _AllBUListViewState extends State<AllBUListView> {
  List<int> buListItems = [];
  List<BuTreeStructureModel> _orgModelList = [];
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  int currentItem = 0;
  bool isShowChildFields = false;
  bool isSecondChildField = false;
  bool isThreeChildField = false;
  bool isLoading = false;
  bool isTreeDefaultOpen = false;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  String? userId;
  int selectedItem = -1;
  late List<Map> buTreeData = [];
  BuBasicDataModel? dropdownValue;

  final List<Color> borderColors = <Color>[
    Colors.black,
    Colors.blue,
    Colors.yellow,
    Colors.greenAccent,
    Colors.redAccent,
    Colors.tealAccent,
    Colors.deepOrangeAccent,
    Colors.deepPurpleAccent
  ];
  int count = -1;
  String? myCurrentBuId = "";
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  bool isShowChildrens = true;
  late OrganizationService _organizationService;
  late ThemeData theme;
  late OrganizationController _organizationController;

  // List featureMenuList = [];
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _organizationController =
        FxControllerStore.putOrFind(OrganizationController());
    _organizationService = OrganizationService();
    myCurrentBuId = AppController.instance.getMyBuId;
    SharePref().getUserId().then((onValue) {
      setState(() {
        userId = onValue;
      });
      // loadChildrensBuData();

      loadAllBuList();
    });
  }

  List<BuBasicDataModel> allBuList = [];

  loadAllBuList() async {
    setState(() {
      allBuList.clear();
    });
    await getUserBuList().then((value) async {
      for (var i = 0; i < value.length; i++) {
        if(value[i].rootValue==null || value[i].rootValue == 0){
          allBuList.add(value[i]);  
        }
      }
      // if (value.length > 0) {
      //   allBuList.addAll(value);
      // }
      if(!this.mounted)
        return [];
      setState(() {
        buTreeData.clear();
      });

      for (var i = 0; i < allBuList.length; i++) {
        await loadChildrensBuData(allBuList[i].id!);
      }
    });
  }

  Future<List<BuBasicDataModel>> getUserBuList() async {
    String body = json.encode({"id": userId});
    var response = await _organizationService
        .getBulistByUserId(body: body, token: "")
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    if(!this.mounted)
      return [];
    setState(() {
      isLoadingProgress = false;
    });
    List<BuBasicDataModel> _list = [];
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var responseBody = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(responseBody)) {
        for (var obj in responseBody) {
          _list.add(BuBasicDataModel.fromJson(obj));
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message!,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
      return _list;
  }

  loadChildrensBuData(String reqBuId) async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
      });
      this.getBuChilds(reqBuId).then((onValue) {
        setState(() {
          _orgModelList.addAll(onValue);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  /// Getting all childrens for that bu

  Future<List<BuTreeStructureModel>> getBuChilds(String? buId) async {
    String body = json.encode({"id": buId});
    // http.Response
    //
    var response = await _organizationService
        .getAllChildrens(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<BuTreeStructureModel> _list = [];
    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;

    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      // if (!CommonMethods.checkResponseType(resObj)) {
      //   for (var element in resObj) {
      _list.add(BuTreeStructureModel.fromJson(resObj));
      setState(() {
        buTreeData.add(resObj);
      });

      // }
      // }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return _list;
  }

  Widget _buildBody() {
    return AppBackgroundView(
      body: WillPopScope(
        onWillPop: () {
          return CommonMethods.onBackPress(context).then((value) => value);
        },
        child: Stack(
          children: [
            SafeArea(
              child: Scaffold(
                key: _scaffoldkey,
                backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                appBar: AppBar(
                  elevation: 0,
                  iconTheme: IconThemeData(color: theme.colorScheme.primary),
                  backgroundColor: Colors.transparent,
                  title: FxText.displayMedium(
                    Language().getString(
                        Constants.BUSINESS_UNIT_LIST_STRING, selectedLang),
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      color: theme.colorScheme.primary,
                    ),
                  ),
                  centerTitle: true,
                  actions: [
                    if (CommonMethods.isPrivillegeExist(
                        context, PrivillegesActions.KEY_MY_COMPANY_ADDBU))
                      IconButton(
                          icon: Icon(Icons.add),
                          onPressed: () {
                            Navigator.push(
                                context,
                                new MaterialPageRoute(
                                    builder: (context) => CreateBUView(
                                          title: Constants.CREATE_BUSINESS_UNIT,
                                          orgId: myCurrentBuId,
                                          isOrgUpdate: false,
                                        ))).then((value) {
                              loadAllBuList();
                            });
                          }),
                    if (CommonMethods.isPrivillegeExist(
                        context, PrivillegesActions.KEY_MY_COMPANY_HOME))
                      AppUtills.homeButton(context),
                  ],
                ),
                drawer: MyDrawer(),
                body: SingleChildScrollView(
                  child: Container(
                      margin: EdgeInsets.symmetric(horizontal: 10),
                      child: Column(
                        children: [
                          if (_orgModelList.length == 0)
                            Container(
                              child: Center(
                                child: Text(
                                  Language().getString(
                                      Constants.NO_DATA_FOUND, selectedLang),
                                ),
                              ),
                            ),
                          for (var i = 0; i < buTreeData.length; i++)
                            printGroupTree(buTreeData[i], context),
                        ],
                      )),
                ),
              ),
            ),
            AppUtills.showLoadingView(
                context: context,
                message: Language().getString(progressMessage, selectedLang),
                isLoading: isLoadingProgress),
          ],
        ),
      ),
    );
  }

  renderBuList() {}

  @override
  void dispose() {
    _organizationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FxBuilder(
        controller: _organizationController,
        builder: (_organizationController) => _buildBody());
  }

  Color getColor() {
    Random random = new Random();
    return Color.fromARGB(
        255, random.nextInt(255), random.nextInt(255), random.nextInt(255));
  }

  /// Preparing bu tree structure
  ///

  bool isAutoSelect(bool isValue) {
    return isValue;
  }

  Widget printGroupTree(Map group, BuildContext context, {double level = 0}) {
    if (group['children'] != null) {
      // isShowChildrens = true;
      List<Widget> subGroups = [];
      for (Map subGroup in group['children']) {
        subGroups.add(
          printGroupTree(
            subGroup,
            context,
            level: level + 1,
          ),
        );
      }

      return Card(
          elevation: 5.0,
          shadowColor: theme.colorScheme.primaryContainer,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8.0),
              side: BorderSide(
                  color: theme.colorScheme.primaryContainer, strokeAlign: 1)),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Parent(
              parent: Container(
                color: Colors.transparent,
                child: _card(group, level * 20, context),
              ),
              childList: ChildList(children: subGroups),
              isAutoShowChildren: isShowChildrens,
            ),
          ));
    } else {
      return Container(
          child: Text(
              Language().getString(Constants.NO_DATA_FOUND, selectedLang)));
    }
  }

  /// Preparing parent and child bu Tree structrue

  String getBuLocationData(Map buData) {
    String locationAddress = '';
    if (buData["contact_details"] != null) {
      String locality = buData["contact_details"]["address"]
                  ["colonysector_arealocality"] !=
              null
          ? buData["contact_details"]["address"]["colonysector_arealocality"]
          : "";
      String? city =
          buData["contact_details"]["address"]["villagetowncity"] != null
              ? buData["contact_details"]["address"]["villagetowncity"]
              : "";

      if (locality != '') {
        locationAddress = locality;
      }
      if (city != null && city != '') {
        locationAddress = locationAddress + ',$city';
      }
    }
    if (locationAddress.startsWith(',')) {
      locationAddress = locationAddress.substring(1);
    }
    return locationAddress;
  }

  Widget _card(Map buData, double leftPadding, BuildContext context) {
    String buName =
        buData["business_name"] != null ? buData["business_name"] : "";

    String buContactLocation = getBuLocationData(buData);
    String buContactPhone =
        (buData.containsKey("dial_code") && buData["dial_code"] != null
                ? buData["dial_code"] + " "
                : "") +
            (buData.containsKey("contact_number") &&
                    buData["contact_number"] != null
                ? buData["contact_number"]
                : "");
    String buHeadOfBusiness = buData.containsKey("head_of_business") &&
            buData["head_of_business"] != null
        ? buData["head_of_business"]
        : "";
    return Container(
        margin: EdgeInsets.only(
          left: 5.0,
          right: 5.0,
        ),
        child: Column(
          children: <Widget>[
            Container(
                child: Column(children: <Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Expanded(
                    child: Container(
                      child: Row(
                        children: [
                          Icon(FeatherIcons.home, size: 18),
                          FxSpacing.width(5),
                          Expanded(
                              child: FxText.bodySmall(
                            buName,
                            style: TextStyle(
                              fontSize: 15,
                              color: Colors.black87,
                              fontWeight: StyleView.fontBold,
                            ),
                          ))
                        ],
                      ),
                    ),
                  ),
                  if (CommonMethods.isPrivillegeExist(
                      context, PrivillegesActions.KEY_MY_COMPANY_OPTIONS_MENU))
                    popupView(buData),
                ],
              ),
              Row(
                children: <Widget>[
                  Icon(FeatherIcons.user, size: 18),
                  FxSpacing.width(10),
                  Expanded(
                      child: FxText.bodySmall(
                    buHeadOfBusiness,
                    style: TextStyle(
                        color: Colors.black,
                        fontWeight: StyleView.fontMedium,
                        fontSize: 13),
                  ))
                ],
              ),
              Container(
                margin: EdgeInsets.only(
                  top: 7.0,
                ),
                child: Row(
                  children: <Widget>[
                    Icon(FeatherIcons.mapPin, size: 18),
                    FxSpacing.width(10),
                    Expanded(
                        child: FxText.bodySmall(
                      buContactLocation,
                      style: TextStyle(
                          color: Colors.black,
                          fontWeight: StyleView.fontMedium,
                          fontSize: 13),
                    ))
                  ],
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Container(
                    margin: EdgeInsets.symmetric(vertical: 10.0),
                    child: Row(
                      children: <Widget>[
                        Icon(FeatherIcons.phoneCall, size: 18),
                        FxSpacing.width(10),
                        InkWell(
                            onTap: () {
                              if (kIsWeb) {
                                return;
                              }
                              if (CommonMethods.isPrivillegeExist(
                                  context,
                                  PrivillegesActions
                                      .KEY_MY_COMPANY_CLICK_PHONE_NUMBER)) {
                                Uri uri = Uri.parse("tel:" + buContactPhone);
                                launchUrl(uri);
                              }
                            },
                            child: FxText.bodySmall(
                              buContactPhone,
                              style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: StyleView.fontMedium,
                                  decoration: TextDecoration.underline,
                                  fontSize: 13),
                            ))
                      ],
                    ),
                  ),
                  if (CommonMethods.isPrivillegeExist(
                      context, PrivillegesActions.KEY_MY_COMPANY_EDIT_BU))
                    Container(
                      margin: EdgeInsets.only(right: 10),
                      child: InkWell(
                        onTap: () {
                          AppController.instance.saveCurrentOrgId =
                              buData["bu_id"];
                          AppController.instance.saveCurrentOrgName =
                              buData["business_name"];
                          Navigator.push(
                              context,
                              new MaterialPageRoute(
                                  builder: (context) => CreateBUView(
                                        title: Constants.EDIT_BUSINESS_UNIT,
                                        orgId: buData["bu_id"],
                                        buName: buData["business_name"],
                                        isOrgUpdate: true,
                                      ))).then((value) => {loadAllBuList()});
                        },
                        child: Row(
                          children: [
                            Icon(
                              FeatherIcons.edit,
                              size: 18,
                              color: theme.colorScheme.primary,
                            ),
                            Text(
                                Language()
                                    .getString(Constants.EDIT, selectedLang),
                                maxLines: 1,
                                style: TextStyle(
                                    fontWeight: StyleView.fontSemiBold,
                                    color: theme.colorScheme.primary)),
                          ],
                        ),
                      ),
                    )
                ],
              ),
            ]))
          ],
        ));
  }

  Widget popupView(Map buData) {
    return Container(
      child: PopupMenuButton(
        elevation: 10.0,
        shadowColor: theme.colorScheme.primary,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(10.0))),
        onSelected: (dynamic result) {
          switch (result) {
            case 1:
              _organizationController.onLocationsView(
                  buId: buData["bu_id"], buName: buData["business_name"]);

              break;
            case 2:
              _organizationController.onRolesView(
                  buId: buData["bu_id"], buName: buData["business_name"]);

              break;
            case 3:
              AppController.instance.saveCurrentOrgId = buData["bu_id"];
              _organizationController.onUsersList(
                  buId: buData['bu_id'],
                  buName: buData['business_name'],
                  isFromBuList: true);

              break;
            case 4:
              _organizationController.onProductsView(
                  buId: buData['bu_id'], buName: buData['business_name']);

              break;
            case 5:
              _organizationController.onTransaction(
                  buId: buData['bu_id'], buName: buData['business_name']);

              break;
            case 6:
              _organizationController.onInvoiceTemPlate(
                  buId: buData['bu_id'], buName: buData['business_name']);

              break;
            case 7:
              _organizationController.onBuDetails(
                  buName: buData['business_name'], buId: buData['bu_id']);

              break;
            default:
          }
        },
        icon: Icon(Icons.more_vert, color: theme.colorScheme.primary),
        itemBuilder: (context) => [
          if (CommonMethods.isPrivillegeExist(
              context, PrivillegesActions.KEY_MY_COMPANY_BU_DETAILS))
            PopupMenuItem(
                child: Row(
                  children: [
                    Icon(Icons.list_alt_outlined, color: Colors.black),
                    FxSpacing.width(8.0),
                    Text(
                        Language()
                            .getString(Constants.VIEW_BU_DETAILS, selectedLang),
                        maxLines: 1,
                        style: TextStyle(
                          fontWeight: StyleView.fontMedium,
                        )),
                  ],
                ),
                value: 7),
          if (CommonMethods.isPrivillegeExist(
              context, PrivillegesActions.KEY_MY_COMPANY_BU_LOCATIONS))
            PopupMenuItem(
                child: Row(
                  children: [
                    Icon(Icons.location_on, color: Colors.black),
                    FxSpacing.width(8.0),
                    Text(
                      Language().getString(Constants.LOCATIONS, selectedLang),
                      maxLines: 1,
                      style: TextStyle(fontWeight: StyleView.fontMedium),
                    ),
                  ],
                ),
                value: 1),
          if (CommonMethods.isPrivillegeExist(
              context, PrivillegesActions.KEY_MY_COMPANY_ROLES))
            PopupMenuItem(
                child: Row(
                  children: [
                    Icon(Icons.people, color: Colors.black),
                    FxSpacing.width(8.0),
                    Text(
                      Language().getString(Constants.ROLES, selectedLang),
                      maxLines: 1,
                      style: TextStyle(fontWeight: StyleView.fontMedium),
                    ),
                  ],
                ),
                value: 2),
          if (CommonMethods.isPrivillegeExist(
              context, PrivillegesActions.KEY_MY_COMPANY_USERS))
            PopupMenuItem(
                child: Row(
                  children: [
                    Icon(Icons.supervised_user_circle, color: Colors.black),
                    FxSpacing.width(8.0),
                    Text(
                      Language().getString(Constants.USERS_STR, selectedLang),
                      maxLines: 1,
                      style: TextStyle(fontWeight: StyleView.fontMedium),
                    ),
                  ],
                ),
                value: 3),
          if (CommonMethods.isPrivillegeExist(
              context, PrivillegesActions.KEY_MY_COMPANY_PRODUCTS))
            PopupMenuItem(
                child: Row(
                  children: [
                    Icon(Icons.shopping_cart, color: Colors.black),
                    FxSpacing.width(8.0),
                    Text(
                      Language()
                          .getString(Constants.PRODUCTS_STR, selectedLang),
                      maxLines: 1,
                      style: TextStyle(fontWeight: StyleView.fontMedium),
                    ),
                  ],
                ),
                value: 4),
          if (CommonMethods.isPrivillegeExist(
              context, PrivillegesActions.KEY_MY_COMPANY_TRANSACTIONS))
            PopupMenuItem(
                child: Row(
                  children: [
                    Icon(Icons.access_time, color: Colors.black),
                    FxSpacing.width(8.0),
                    Text(
                      Language()
                          .getString(Constants.TRANSACTIONS_STR, selectedLang),
                      maxLines: 1,
                      style: TextStyle(fontWeight: StyleView.fontMedium),
                    ),
                  ],
                ),
                value: 5),
          if (CommonMethods.isPrivillegeExist(
              context, PrivillegesActions.KEY_MY_COMPANY_ADD_INVOICE_TEMPLATE))
            PopupMenuItem(
                child: Row(
                  children: [
                    Icon(Icons.inventory_outlined, color: Colors.black),
                    FxSpacing.width(8.0),
                    Text(
                      Language().getString(
                          Constants.ADD_INVOICE_TEMPLATE, selectedLang),
                      maxLines: 1,
                      style: TextStyle(fontWeight: StyleView.fontMedium),
                    ),
                  ],
                ),
                value: 6),
        ],
      ),
    );
  }

  // bool isPrivillegeExist(String key) {
  //   bool isExist = false;
  //   isExist = featureMenuList.any((element) => element == key);
  //   return isExist;
  // }
}
