import 'dart:convert';
import 'dart:io';
import 'package:vyaparlive/Organization/controller/organization_controller.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:vyaparlive/utills/SharePref.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:http/http.dart' as http;
import 'package:vyaparlive/model/AvailableTemplatesDAO.dart';
import 'package:vyaparlive/model/BusinessUnitModel.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/service/Service.dart';
import 'package:vyaparlive/service/organization_service.dart';
import 'package:toast/toast.dart';

class AddInvoiceTemplatePage extends StatefulWidget {
  final String? buId;
  final String? buName;

  AddInvoiceTemplatePage({this.buId, this.buName});
  @override
  _AddInvoiceTemplatePageState createState() => _AddInvoiceTemplatePageState();
}

class _AddInvoiceTemplatePageState extends State<AddInvoiceTemplatePage> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  File? imageFile;
  String imageBlob = '';
  bool isSelectCaptureChoice = false;
  double finalAngle = 0.0;
  bool isLoadingProgress = true;
  String progressMessage = Constants.GETTING_DATA;
  late Service _service;
  AvailableTemplatesDAO? templateDropdownValue;
  List<AvailableTemplatesDAO> templateList = [];
  late OrganizationService _organizationService;
  BusinessUnitModel? _bubasicdatamodel;
  bool isLoadServerImage = false;
  Uint8List? _webImage;
  String? relativePath = "";
  final String imageName = Constants.ORGANIZE_IMAGE;
  late ThemeData theme;
  late String? userId = '';
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _service = Service();
    _organizationService = OrganizationService();
    SharePref().getUserId().then((onValue) {
      setState(() {
        userId = onValue;
      });
    });
    this.serviceCalls();
  }

  serviceCalls() async {
    await this.getBuData().then((value) {
      setState(() {
        _bubasicdatamodel = null;
        if (value != null) {
          _bubasicdatamodel = value;
        }
      });
    });
    this.loadAvailableInvoiceTemplates().then((value) {
      setState(() {
        templateList.clear();
        templateList.addAll(value);

        if (templateList.length > 0 &&
            _bubasicdatamodel != null &&
            _bubasicdatamodel!.invoiceTemplate != null) {
          for (int i = 0; i < templateList.length; i++) {
            if (_bubasicdatamodel!.invoiceTemplate!.tempId ==
                templateList[i].tempId) {
              templateDropdownValue = templateList[i];
            }
          }
        }
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    ToastContext().init(context);
    return AppBackgroundView(
      body: Stack(
        children: [
          SafeArea(
            child: Scaffold(
              key: _scaffoldkey,
              backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
              appBar: AppBar(
                  backgroundColor: Colors.transparent, //(Constants.APP_COLOR),
                  centerTitle: true,
                  elevation: 0,
                  iconTheme: IconThemeData(color: theme.colorScheme.primary),
                  title: AppbarName(
                      title: Language().getString(
                          Constants.ADD_INVOICE_TEMPLATE, selectedLang),
                      buName: widget.buName)),
              bottomNavigationBar: Container(
                  padding: EdgeInsets.symmetric(horizontal: 10.0, vertical: 20),
                  child: CommonButtonsView(
                    context: context,
                    b1Text: "",
                    b2Text: Language().getString(Constants.CONFIRM, selectedLang),
                    onb2Action: () {
                      String errorMessage = validatingMandatoryFields();
                      if (errorMessage.isNotEmpty) {
                        Dialogs.yesCancelDialog(
                            context,
                            Language().getString(Constants.ERROR, selectedLang),
                            errorMessage,
                            Language()
                                .getString(Constants.OKAY_STR, selectedLang),
                            "",
                            false);
                      } else {
                        // this.serviceCallUploadTemplateImage();
                        serviceCallAddInvoiceTemplate();
                      }
                    },
                  )),
              body: Container(
                margin: EdgeInsets.symmetric(vertical: 5.0, horizontal: 10.0),
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      Container(
                        margin: EdgeInsets.symmetric(
                          vertical: 5.0,
                        ),
                        decoration: AppUtills.boxDecoration(),
                        child: Column(children: <Widget>[
                          getImageOptions(Language().getString(
                              Constants.PRODUCT_PHOTO_STRING, selectedLang)),
                          SizedBox(
                            height: 1,
                            child:
                                new Container(color: Color(Constants.GREY_COLOR)),
                          ),
                          showSelectedImage(),
                        ]),
                      ),
                      (templateList.length > 0)
                          ? this.showAvailableInvoiceTemplates()
                          : Container()
                    ],
                  ),
                ),
              ),
            ),
          ),
          AppUtills.showLoadingView(
              context: context,
              message: Language().getString(progressMessage, selectedLang),
              isLoading: isLoadingProgress),
        ],
      ),
    );
  }

  getImageOptions(String? textName) {
    return Container(
        decoration:
            BoxDecoration(borderRadius: BorderRadius.all(Radius.circular(5.0))),
        child: Container(
            padding: EdgeInsets.symmetric(vertical: 10),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(5.0))),
            child: Container(
              padding: EdgeInsets.only(left: 10),
              child: InkWell(
                onTap: () async {
                  if (kIsWeb) {
                    final _file = await Dialogs.getWebImage();
                    if (_file != null) {
                      _webImage = await _file.readAsBytes();
                      setState(() {
                        isSelectCaptureChoice = true;
                        isLoadServerImage = false;
                      });
                      uploadImage(_webImage, imageName);
                    }
                  } else {
                    this.openBottomSheet(context);
                  }
                },
                child: Column(
                  children: [
                    Icon(
                      Icons.camera_alt,
                      color: Color(0xFF083e64),
                    ),
                    Text(Language().getString(Constants.ADD_LOGO, selectedLang))
                  ],
                ),
              ),
            )));
  }

  uploadImage(dynamic imageData, String fileName) async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = "Getting url...";
    });
    // print("image data $imageData");
    Map data = {
      "filename": (kIsWeb) ? fileName : imageData.path.split("/").last,
      "location": "organization_invoice_template"
    };
    String body = json.encode(data);
    http.Response response = await _service.getPresignedUrl(body);
    if (response.statusCode == 200) {
      var responseBody = json.decode(response.body);
      setState(() {
        isLoadingProgress = true;
        progressMessage = "Uploading image..";
      });
      var uploadFileRes =
          await _service.uploadToS3Signed(responseBody['url'], imageData);

      setState(() {
        relativePath = responseBody['relativepath'];
        isLoadingProgress = false;
      });
      if (kIsWeb) {
        print("uploadFileRes,$uploadFileRes");
      } else {
        Toast.show(
          "File uploaded!",
          duration: Toast.lengthShort,
          gravity: Toast.bottom,
        );
      }
    } else {
      setState(() {
        isLoadingProgress = false;
      });
      if (kIsWeb) {
        print("Getting signed url failed!");
      } else {
        Toast.show(
          "Getting signed url failed!",
          duration: Toast.lengthShort,
          gravity: Toast.bottom,
        );
      }
    }
  }

  openBottomSheet(BuildContext context) {
    return Dialogs.openBottomSheet(
        context: context,
        openCamera: (myPicture) async {
          this.updateProductImage(myPicture);
        },
        openGallery: (myPicture) async {
          this.updateProductImage(myPicture);
        });
  }

  updateProductImage(File fileImage) {
    Navigator.of(context).pop();
    setState(() {
      imageFile = fileImage;
      isSelectCaptureChoice = true;
      isLoadServerImage = false;
      imageBlob = AppUtills.getBase64Image(fileImage, context);
    });
    uploadImage(imageFile, "");
  }

  showSelectedImage() {
    return Container(
        padding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(5.0)),
        child: Container(
          child: Align(alignment: Alignment.center, child: displayImageView()),
        ));
  }

  _aspectRatio() {
    if (kIsWeb) {
      return MediaQuery.of(context).size.width /
          MediaQuery.of(context).size.height *
          2;
    } else {
      return MediaQuery.of(context).size.width /
          MediaQuery.of(context).size.height *
          2.5;
    }
  }

  displayImageView() {
    if (isSelectCaptureChoice) {
      return AspectRatio(
          aspectRatio: _aspectRatio(),
          child: ClipRRect(
            child: (kIsWeb)
                ? Image.memory(_webImage!, fit: BoxFit.contain)
                : Image.file(
                    imageFile!,
                    fit: BoxFit.contain,
                    gaplessPlayback: true,
                  ),
          ));
    } else {
      if (_bubasicdatamodel != null &&
          _bubasicdatamodel!.invoiceTemplate != null) {
        isLoadServerImage = true;
        return AppUtills.imageAspectRatio(
            _bubasicdatamodel!.invoiceTemplate!.tempLogo,
            aspectRatio: _aspectRatio(),
            context: context);
      } else {
        return AspectRatio(
            aspectRatio: _aspectRatio(),
            child: ClipRRect(
                borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(10),
                    bottomRight: Radius.circular(10)),
                child: Image.asset(
                  'assets/images/no_image.jpg',
                  gaplessPlayback: true,
                  fit: BoxFit.contain,
                )));
      }
    }
  }

  Future<List<AvailableTemplatesDAO>> loadAvailableInvoiceTemplates() async {
    http.Response response =
        await _service.availableInvoiceTemplates().catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });

      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    List<AvailableTemplatesDAO> list = [];
    if (response.statusCode == 200) {
      var resBody = json.decode(response.body);
      for (var obj in resBody['data']) {
        list.add(AvailableTemplatesDAO.fromJson(obj));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          response.body,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }

    return list;
  }

  showAvailableInvoiceTemplates() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          margin: EdgeInsets.symmetric(vertical: 10.0),
          child: Text(
            Language()
                .getString(Constants.SELECT_INVOICE_TEMPLATE, selectedLang),
            style: TextStyle(
                color: Color(Constants.APP_COLOR),
                fontSize: 15.0,
                fontWeight: FontWeight.bold),
          ),
        ),
        Container(
            decoration: BoxDecoration(
                color: Colors.white,
                border: Border.all(
                  color: Colors.grey,
                ),
                borderRadius: BorderRadius.circular(
                  5.0,
                )),
            padding: EdgeInsets.only(left: 5, right: 5),
            child: DropdownButton<AvailableTemplatesDAO>(
                value: templateDropdownValue,
                hint: new Text(Language().getString(
                    Constants.SELECT_INVOICE_TEMPLATE, selectedLang)),
                isExpanded: true,
                underline: SizedBox(),
                onChanged: (AvailableTemplatesDAO? data) {
                  setState(() {
                    templateDropdownValue = data;
                  });
                },
                items: templateList.map((AvailableTemplatesDAO model) {
                  return new DropdownMenuItem<AvailableTemplatesDAO>(
                    child: new Text(model.tempName!),
                    value: model,
                  );
                }).toList())),
      ],
    );
  }

  String validatingMandatoryFields() {
    if (templateDropdownValue == null) {
      return Constants.PLEASE_SELECT_INVOICE_TEMPLATE;
    }
    // else if ((imageFile == null || _webImage == null) && !isLoadServerImage) {
    //   return "Please Select Invoice Image";
    // }
    else {
      return "";
    }
  }

  serviceCallUploadTemplateImage() async {
    setState(() {
      isLoadingProgress = true;
    });

    Map data = {"id": widget.buId};

    if (!isLoadServerImage) {
      data["image"] = relativePath; //imageBlob;
    }

    String body = json.encode(data);

    http.Response response =
        await _service.uploadInvoiceTemplateImage(body).catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    if (response.statusCode == 200) {
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          Constants.SUCCESS,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);

      if (action == DialogAction.yes) {
        Navigator.pop(context);
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          response.body,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  serviceCallAddInvoiceTemplate() async {
    setState(() {
      isLoadingProgress = true;
    });
    Map<String, dynamic> data = await OrganizationController.getOrgnizationBody(
        userId: userId, buId: widget.buId, orgFieldsData: _bubasicdatamodel);
    Map<String, dynamic> invoiceTemplate = {
      'template_id': templateDropdownValue!.tempId,
      'logo': relativePath
    };
    data['invoice_template'] = invoiceTemplate;
    String body = json.encode(data);
    var response = await _organizationService
        .updateOrganization(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      // this.serviceCallUploadTemplateImage();
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          Constants.INVOICE_TEMPLATE_UPDATED,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
      if (action == DialogAction.yes) {
        Navigator.of(context).pop();
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  Future<BusinessUnitModel?> getBuData() async {
    setState(() {
      isLoadingProgress = true;
    });
    String body = json.encode({"id": widget.buId});
    var response = await _organizationService
        .getOrganizationDataById(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    BusinessUnitModel? data;

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);

      data = BusinessUnitModel.fromJson(resObj[0]);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
      return data;
  }
}
