import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/model/InventoryManagmentModel.dart';
import 'package:vyaparlive/model/product_model/InventoryDetailsDAO.dart';
import 'package:vyaparlive/model/product_model/QuantityAdjustmentDAO.dart';

class InventoryListDataTable extends StatelessWidget {
  final List<InventoryDetailsDAO>? locationsList;
  final List<InventoryManagementModel>? batchList;
  final String? batchNumber;
  final String? locationName;
  final List<QuantityAdjustmentDAO>? quantityAdjustmentList;
  final String? adjustmentReason;
  final bool isShowAdjustmentReason;
  final String? updatedBy;
  final String? updateDate;
  final String? strBatchNumber;
  final String? strQuantity;
  const InventoryListDataTable({
    this.batchList,
    this.locationsList,
    this.batchNumber,
    this.locationName,
    this.quantityAdjustmentList,
    this.adjustmentReason,
    this.isShowAdjustmentReason = false,
    this.updateDate,
    this.updatedBy,
    required this.strBatchNumber,
    required this.strQuantity,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.vertical,
      child: Container(
        child: Padding(
            padding: const EdgeInsets.all(5.0),
            child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Table(
                      border: TableBorder.all(
                        color: Colors.black,
                      ),
                      defaultColumnWidth: FixedColumnWidth(110),
                      children: [
                        this.showBatchHeaderView(),
                        for (int i = 0; i < batchList!.length; i++)
                          for (int j = 0;
                              j < batchList![i].locationBatchList!.length;
                              j++)
                            TableRow(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Container(
                                    child: Text("${batchList![i].locationName}",
                                        textAlign: TextAlign.start,
                                        style: TextStyle(
                                            fontSize: 13.0,
                                            color: Color(Constants.APP_COLOR))),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Container(
                                    child: Text(
                                        "${batchList![i].locationBatchList![j].quantity} ${batchList![i].locationBatchList![j].quantityIn}",
                                        textAlign: TextAlign.start,
                                        style: TextStyle(
                                            fontSize: 13.0,
                                            color: Color(Constants.APP_COLOR))),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Container(
                                    child: Text(
                                        "${batchList![i].locationBatchList![j].batchNumber}",
                                        textAlign: TextAlign.start,
                                        style: TextStyle(
                                            fontSize: 13.0,
                                            color: Color(Constants.APP_COLOR))),
                                  ),
                                ),
                              ],
                            )
                      ],
                    ),
                  )),
      ),
    );
  }

  TableRow showBatchHeaderView() {
    return TableRow(children: [
      Center(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
            child: Text(
              Constants.LOCATION_NAME,
              style: TextStyle(
                  color: AppTheme.vyaparTheme.colorScheme.primary,
                  fontWeight: StyleView.fontSemiBold,
                  fontSize: 13.0),
            ),
          ),
        ),
      ),
      Center(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
            child: Text(
              Constants.QUANTITY,
              style: TextStyle(
                  color: AppTheme.vyaparTheme.colorScheme.primary,
                  fontWeight: StyleView.fontSemiBold,
                  fontSize: 13.0),
            ),
          ),
        ),
      ),
      Center(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
            child: Text(
              strBatchNumber!,
              style: TextStyle(
                  color: AppTheme.vyaparTheme.colorScheme.primary,
                  fontWeight: StyleView.fontSemiBold,
                  fontSize: 13.0),
            ),
          ),
        ),
      ),
    ]);
  }
}
