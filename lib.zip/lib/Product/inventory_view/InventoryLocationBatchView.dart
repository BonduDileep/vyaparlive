import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/model/InventoryManagmentModel.dart';
import 'package:vyaparlive/model/product_model/InventoryDetailsDAO.dart';
import 'package:vyaparlive/model/product_model/QuantityAdjustmentDAO.dart';

class InventoryLocationBatchView extends StatelessWidget {
  final List<InventoryDetailsDAO>? locationsList;
  final List<InventoryManagementModel>? batchList;
  final bool isShowLocationDetails;
  final String? batchNumber;
  final String? locationName;
  final bool isFromQuantityAdjustment;
  final List<QuantityAdjustmentDAO>? quantityAdjustmentList;
  final String? adjustmentReason;
  final bool isShowAdjustmentReason;
  final String? updatedBy;
  final String? updateDate;
  final String? strBatchNumber;
  final String? strQuantity;
  final String? strUpdatedBy;
  final String? strUpdatedDate;
  final String? strReason;
  final String? strAdjustedQuantity;
  const InventoryLocationBatchView({
    this.batchList,
    this.locationsList,
    this.isShowLocationDetails = false,
    this.batchNumber,
    this.locationName,
    this.isFromQuantityAdjustment = false,
    this.quantityAdjustmentList,
    this.adjustmentReason,
    this.isShowAdjustmentReason = false,
    this.updateDate,
    this.updatedBy,
    required this.strBatchNumber,
    required this.strQuantity,
    required this.strUpdatedBy,
    required this.strUpdatedDate,
    required this.strAdjustedQuantity,
    required this.strReason,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.vertical,
      child: Container(
        child: Padding(
            padding: const EdgeInsets.all(5.0),
            child: (isFromQuantityAdjustment)
                ? this.showQuantityAdjustmentInventory()
                : SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Table(
                      border: TableBorder.all(
                        color: Colors.black,
                      ),
                      defaultColumnWidth: FixedColumnWidth(110),
                      children: [
                        (isShowLocationDetails)
                            ? this.showLocationHeaderView()
                            : this.showBatchHeaderView(),
                        if (isShowLocationDetails)
                          for (int i = 0; i < locationsList!.length; i++)
                            TableRow(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Container(
                                    child: Text(
                                        "${locationsList![i].batchNumber}",
                                        textAlign: TextAlign.start,
                                        style: TextStyle(
                                            fontSize: 13.0,
                                            color: Color(Constants.APP_COLOR))),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Container(
                                    child: Text(
                                        "${locationsList![i].quantity} ${locationsList![i].quantityIn}",
                                        textAlign: TextAlign.start,
                                        style: TextStyle(
                                            fontSize: 13.0,
                                            color: Color(Constants.APP_COLOR))),
                                  ),
                                ),
                                if (isShowAdjustmentReason)
                                  Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Container(
                                      child: Text("$adjustmentReason",
                                          textAlign: TextAlign.start,
                                          style: TextStyle(
                                              fontSize: 13.0,
                                              color:
                                                  Color(Constants.APP_COLOR))),
                                    ),
                                  ),
                                (isShowAdjustmentReason)
                                    ? Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Container(
                                          child: Text("$updatedBy",
                                              textAlign: TextAlign.start,
                                              style: TextStyle(
                                                  fontSize: 13.0,
                                                  color: Color(
                                                      Constants.APP_COLOR))),
                                        ),
                                      )
                                    : Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Container(
                                          child: Text(
                                              "${locationsList![i].updatedUser}",
                                              textAlign: TextAlign.start,
                                              style: TextStyle(
                                                  fontSize: 13.0,
                                                  color: Color(
                                                      Constants.APP_COLOR))),
                                        ),
                                      ),
                                (isShowAdjustmentReason)
                                    ? Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Container(
                                          child: Text("$updateDate",
                                              textAlign: TextAlign.start,
                                              style: TextStyle(
                                                  fontSize: 13.0,
                                                  color: Color(
                                                      Constants.APP_COLOR))),
                                        ),
                                      )
                                    : Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Container(
                                          child: Text(
                                              "${locationsList![i].updatedDate}",
                                              textAlign: TextAlign.start,
                                              style: TextStyle(
                                                  fontSize: 13.0,
                                                  color: Color(
                                                      Constants.APP_COLOR))),
                                        ),
                                      ),
                              ],
                            )
                        else
                          for (int i = 0; i < batchList!.length; i++)
                            for (int j = 0;
                                j < batchList![i].locationBatchList!.length;
                                j++)
                              if (batchNumber ==
                                  batchList![i]
                                      .locationBatchList![j]
                                      .batchNumber)
                                TableRow(
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Container(
                                        child: Text(
                                            "${batchList![i].locationName}",
                                            textAlign: TextAlign.start,
                                            style: TextStyle(
                                                fontSize: 13.0,
                                                color: Color(
                                                    Constants.APP_COLOR))),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Container(
                                        child: Text(
                                            "${batchList![i].locationBatchList![j].quantity} ${batchList![i].locationBatchList![j].quantityIn}",
                                            textAlign: TextAlign.start,
                                            style: TextStyle(
                                                fontSize: 13.0,
                                                color: Color(
                                                    Constants.APP_COLOR))),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Container(
                                        child: Text(
                                            "${batchList![i].locationBatchList![j].updatedUser}",
                                            textAlign: TextAlign.start,
                                            style: TextStyle(
                                                fontSize: 13.0,
                                                color: Color(
                                                    Constants.APP_COLOR))),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Container(
                                        child: Text(
                                            "${batchList![i].locationBatchList![j].updatedDate}",
                                            textAlign: TextAlign.start,
                                            style: TextStyle(
                                                fontSize: 13.0,
                                                color: Color(
                                                    Constants.APP_COLOR))),
                                      ),
                                    ),
                                  ],
                                )
                      ],
                    ),
                  )),
      ),
    );
  }

  TableRow showBatchHeaderView() {
    return TableRow(children: [
      Center(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
            child: Text(
              Constants.LOCATION_NAME,
              style: TextStyle(
                  color: AppTheme.vyaparTheme.colorScheme.primary,
                  fontWeight: StyleView.fontSemiBold,
                  fontSize: 13.0),
            ),
          ),
        ),
      ),
      Center(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
            child: Text(
              Constants.QUANTITY,
              style: TextStyle(
                  color: AppTheme.vyaparTheme.colorScheme.primary,
                  fontWeight: StyleView.fontSemiBold,
                  fontSize: 13.0),
            ),
          ),
        ),
      ),
      Center(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
            child: Text(
              Constants.UPDATED_BY,
              style: TextStyle(
                  color: AppTheme.vyaparTheme.colorScheme.primary,
                  fontWeight: StyleView.fontSemiBold,
                  fontSize: 13.0),
            ),
          ),
        ),
      ),
      Center(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
            child: Text(
              Constants.UPDATED_DATE,
              style: TextStyle(
                  color: AppTheme.vyaparTheme.colorScheme.primary,
                  fontWeight: StyleView.fontSemiBold,
                  fontSize: 13.0),
            ),
          ),
        ),
      )
    ]);
  }

  TableRow showLocationHeaderView() {
    return TableRow(children: [
      Center(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
            child: Text(
              strBatchNumber!,
              style: TextStyle(
                  color: AppTheme.vyaparTheme.colorScheme.primary,
                  fontWeight: StyleView.fontSemiBold,
                  fontSize: 13.0),
            ),
          ),
        ),
      ),
      Center(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
            child: Text(
              (isShowAdjustmentReason) ? strAdjustedQuantity! : strQuantity!,
              style: TextStyle(
                  color: AppTheme.vyaparTheme.colorScheme.primary,
                  fontWeight: StyleView.fontSemiBold,
                  fontSize: 13.0),
            ),
          ),
        ),
      ),
      if (isShowAdjustmentReason)
        Center(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              child: Text(
                strReason!,
                style: TextStyle(
                    color: AppTheme.vyaparTheme.colorScheme.primary,
                    fontWeight: StyleView.fontSemiBold,
                    fontSize: 13.0),
              ),
            ),
          ),
        ),
      if (isShowAdjustmentReason || isShowLocationDetails)
        Center(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              child: Text(
                strUpdatedBy!,
                style: TextStyle(
                    color: AppTheme.vyaparTheme.colorScheme.primary,
                    fontWeight: StyleView.fontSemiBold,
                    fontSize: 13.0),
              ),
            ),
          ),
        ),
      if (isShowAdjustmentReason || isShowLocationDetails)
        Center(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              child: Text(
                strUpdatedDate!,
                style: TextStyle(
                    color: AppTheme.vyaparTheme.colorScheme.primary,
                    fontWeight: StyleView.fontSemiBold,
                    fontSize: 13.0),
              ),
            ),
          ),
        )
    ]);
  }

  showQuantityAdjustmentInventory() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Table(
        border: TableBorder.all(
          color: Colors.black,
        ),
        defaultColumnWidth: FixedColumnWidth(110),
        children: [
          this.showBatchHeaderView(),
          for (int i = 0; i < quantityAdjustmentList!.length; i++)
            for (int j = 0;
                j <
                    quantityAdjustmentList![i]
                        .quantityAdjustLocationsList!
                        .length;
                j++)
              if (batchNumber ==
                  quantityAdjustmentList![i]
                      .quantityAdjustLocationsList![j]
                      .batchNumber)
                TableRow(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        child: Text(
                            "${quantityAdjustmentList![i].locationName}",
                            textAlign: TextAlign.start,
                            style: TextStyle(
                                fontSize: 13.0,
                                color: Color(Constants.APP_COLOR))),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        child: Text(
                            "${quantityAdjustmentList![i].quantityAdjustLocationsList![j].quantity} ${quantityAdjustmentList![i].quantityAdjustLocationsList![j].quantityIn}",
                            textAlign: TextAlign.start,
                            style: TextStyle(
                                fontSize: 13.0,
                                color: Color(Constants.APP_COLOR))),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        child: Text(
                            "${quantityAdjustmentList![i].quantityAdjustLocationsList![j].quantity} ${quantityAdjustmentList![i].quantityAdjustLocationsList![j].quantityIn}",
                            textAlign: TextAlign.start,
                            style: TextStyle(
                                fontSize: 13.0,
                                color: Color(Constants.APP_COLOR))),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        child: Text(
                            "${quantityAdjustmentList![i].quantityAdjustLocationsList![j].quantity} ${quantityAdjustmentList![i].quantityAdjustLocationsList![j].quantityIn}",
                            textAlign: TextAlign.start,
                            style: TextStyle(
                                fontSize: 13.0,
                                color: Color(Constants.APP_COLOR))),
                      ),
                    )
                  ],
                ),
        ],
      ),
    );
  }
}
