import 'package:flutter/material.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/privileges/product_privileges.dart';
import 'package:vyaparlive/model/InventoryManagmentModel.dart';
import 'package:vyaparlive/model/product_model/InventoryDetailsDAO.dart';
import 'package:vyaparlive/model/product_model/QuantityAdjustmentDAO.dart';

class InventoryExpandedPage extends StatelessWidget {
  final String? title;
  final VoidCallback? editPage;
  final VoidCallback? removeItem;
  final InventoryManagementModel? managementModel;
  final bool isFromAssetsPage;
  final bool forQuantityAdjustment;
  final List<InventoryDetailsDAO>? quantityAdjustmentList;
  final QuantityAdjustmentDAO? quantityAdjustmentDAOModel;
  final String? strLocation;
  final String? strTotalAtLocation;
  final String? strBatchNumber;

  InventoryExpandedPage(
      {this.editPage,
      this.managementModel,
      this.removeItem,
      this.title,
      this.isFromAssetsPage = false,
      this.forQuantityAdjustment = false,
      this.quantityAdjustmentDAOModel,
      this.quantityAdjustmentList,
      required this.strBatchNumber,
      required this.strLocation,
      required this.strTotalAtLocation});
  final ProductPrivileges? _productPrivileges =
      AppController.instance.getProductPrivileges;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          flex: 10,
          child: Container(
            padding: EdgeInsets.all(5.0),
            decoration: AppUtills.boxDecoration(
                customBorderColor:
                    forQuantityAdjustment ? Colors.transparent : Colors.grey),
            child: Column(
              children: [
                Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  this.showMainCardView(),
                  Expanded(
                    child: Container(
                        child: (_productPrivileges!.product_location_edit)
                            ? InkWell(
                                child: Icon(Icons.edit,
                                    color: Color(Constants.APP_COLOR)),
                                onTap: () => editPage!())
                            : Container()),
                  ),
                ]),
                this.showMoreBatchesView(context)
              ],
            ),
          ),
        ),
        // Expanded(
        //     child: IconButton(
        //         icon: Icon(
        //           Icons.remove_circle_outline,
        //           color: Colors.red,
        //         ),
        //         onPressed: () => removeItem()))
      ],
    );
  }

  showTotalBatchQuantity() {
    num totalQuantity = 0;
    String? quantityIn = "";
    if (forQuantityAdjustment) {
      for (int i = 0;
          i < quantityAdjustmentDAOModel!.quantityAdjustLocationsList!.length;
          i++) {
        totalQuantity = totalQuantity +
            quantityAdjustmentDAOModel!
                .quantityAdjustLocationsList![i].quantity!;
        quantityIn = quantityAdjustmentDAOModel!
            .quantityAdjustLocationsList![i].quantityIn;
      }
    } else {
      for (int i = 0; i < managementModel!.locationBatchList!.length; i++) {
        totalQuantity =
            totalQuantity + managementModel!.locationBatchList![i].quantity!;
        quantityIn = managementModel!.locationBatchList![i].quantityIn;
      }
    }

    return showTitleView(strTotalAtLocation!, "$totalQuantity  $quantityIn");
  }

  showTitleView(String title, String? value) {
    return Container(
        margin: EdgeInsets.symmetric(vertical: 2.0),
        child: Row(
          children: [
            Expanded(
                child: Text("$title",
                    style: TextStyle(
                        fontSize: 14.0,
                        fontFamily: StyleView.FONT_TITLE,
                        color: Colors.black,
                        fontWeight: FontWeight.w700))),
            Expanded(
                flex: 2,
                child: Text(
                  " : $value",
                  style: TextStyle(
                    fontSize: 13.0,
                    fontFamily: StyleView.FONT_TITLE,
                    color: Colors.black,
                  ),
                ))
          ],
        ));
  }

  showBatchesView(String title) {
    int index = 0;
    for (var i = 0; i < managementModel!.locationBatchList!.length; i++) {
      if (managementModel!.locationBatchList![i].quantity != 0) {
        index = i;
        break;
      }
    }
    return Container(
        margin: EdgeInsets.symmetric(vertical: 2.0),
        child: Row(
          children: [
            Expanded(
                child: Text("$title",
                    style: TextStyle(
                        fontSize: 14.0,
                        fontFamily: StyleView.FONT_TITLE,
                        color: Colors.black,
                        fontWeight: FontWeight.w700))),
            Expanded(
                flex: 2,
                child: Text(
                  " : ${managementModel!.locationBatchList![index].batchNumber} ( ${managementModel!.locationBatchList![index].quantity} ${managementModel!.locationBatchList![index].quantityIn}  )",
                  style: TextStyle(
                    fontSize: 13.0,
                    fontFamily: StyleView.FONT_TITLE,
                    color: Colors.black,
                  ),
                ))
          ],
        ));
  }

  showAllLocationBatches(BuildContext mContext) {
    return showDialog(
        context: mContext,
        barrierDismissible: false,
        builder: (mContext) => AlertDialog(
              title: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          child: Text(
                            Constants.INVENTORY_BATCHES,
                            style: TextStyle(
                                color: Color(Constants.APP_COLOR),
                                fontWeight: FontWeight.bold,
                                fontSize: 15.0),
                          ),
                        ),
                        Container(
                          child: Row(
                            children: [
                              Container(
                                child: Text(
                                  Constants.LOCATION_NAME,
                                  style: TextStyle(
                                      color: Color(Constants.APP_COLOR),
                                      fontWeight: FontWeight.bold,
                                      fontSize: 15.0),
                                ),
                              ),
                              Text("  : "),
                              Expanded(
                                child: Container(
                                    child: Text(
                                  managementModel!.locationName!,
                                  style: TextStyle(
                                      color: Color(Constants.APP_COLOR),
                                      fontWeight: FontWeight.w300,
                                      fontSize: 13.0),
                                )),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                  IconButton(
                      onPressed: () {
                        Navigator.of(mContext).pop();
                      },
                      icon: Icon(
                        Icons.close,
                        color: Colors.red,
                      ))
                ],
              ),
              titlePadding: EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 5.0),
              contentPadding: EdgeInsets.fromLTRB(5.0, 5.0, 5.0, 5.0),
              content: Container(
                width: double.maxFinite,
                child: Container(
                  child: Padding(
                    padding: const EdgeInsets.all(5.0),
                    child: SingleChildScrollView(
                      child: Table(
                        border: TableBorder.all(
                          color: Colors.black,
                        ),
                        defaultColumnWidth: FixedColumnWidth(110),
                        children: [
                          TableRow(children: [
                            Center(
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Container(
                                  child: Text(
                                    Constants.BATCH_NO,
                                    style: TextStyle(
                                        color: Color(Constants.APP_COLOR),
                                        fontWeight: FontWeight.bold,
                                        fontSize: 13.0),
                                  ),
                                ),
                              ),
                            ),
                            Center(
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Container(
                                  child: Text(
                                    Constants.QUANTITY,
                                    style: TextStyle(
                                        color: Color(Constants.APP_COLOR),
                                        fontWeight: FontWeight.bold,
                                        fontSize: 13.0),
                                  ),
                                ),
                              ),
                            )
                          ]),
                          for (int i = 0;
                              i < managementModel!.locationBatchList!.length;
                              i++)
                            TableRow(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Container(
                                    child: Text(
                                        managementModel!
                                            .locationBatchList![i].batchNumber!,
                                        textAlign: TextAlign.start,
                                        style: TextStyle(
                                            fontSize: 13.0,
                                            color: Color(Constants.APP_COLOR))),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Container(
                                    child: Text(
                                        managementModel!
                                                .locationBatchList![i].quantity
                                                .toString() +
                                            " ${managementModel!.locationBatchList![i].quantityIn}",
                                        textAlign: TextAlign.start,
                                        style: TextStyle(
                                            fontSize: 13.0,
                                            color: Color(Constants.APP_COLOR))),
                                  ),
                                )
                              ],
                            )
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ));
  }

  Widget showMainCardView() {
    if (forQuantityAdjustment) {
      if (quantityAdjustmentDAOModel != null) {
        return Expanded(
          flex: 5,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              this.showTitleView(
                  strLocation!, quantityAdjustmentDAOModel!.locationName),
              if (quantityAdjustmentDAOModel!
                      .quantityAdjustLocationsList!.length >
                  0)
                this.showTotalBatchQuantity(),
              if (quantityAdjustmentDAOModel!
                      .quantityAdjustLocationsList!.length >
                  0)
                this.showQuantityAdjustmentBatchesView(strBatchNumber!),
              this.showTitleView(
                  Constants.REASON, quantityAdjustmentDAOModel!.reason),
            ],
          ),
        );
      } else {
        return Container();
      }
    } else {
      if (managementModel != null) {
        return Expanded(
          flex: 5,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              this.showTitleView(strLocation!, managementModel!.locationName),
              if (managementModel!.locationBatchList!.length > 0)
                this.showTotalBatchQuantity(),
              if (managementModel!.locationBatchList!.length > 0)
                this.showBatchesView(strBatchNumber!)
            ],
          ),
        );
      } else {
        return Container();
      }
    }
  }

  Widget showMoreBatchesView(BuildContext mContext) {
    if (forQuantityAdjustment) {
      if (quantityAdjustmentDAOModel!.quantityAdjustLocationsList!.length > 1) {
        return Container(
          alignment: Alignment.centerRight,
          child: InkWell(
            onTap: () {
              this.showAllLocationBatchesQuantityAdjustment(mContext);
            },
            child: Text(
              Constants.VIEW_MORE_BATCHES,
              style: TextStyle(
                  color: Color(Constants.APP_COLOR),
                  decoration: TextDecoration.underline),
            ),
          ),
        );
      } else {
        return Container();
      }
    } else {
      if (managementModel!.locationBatchList!.length > 1) {
        return Container(
          alignment: Alignment.centerRight,
          child: InkWell(
            onTap: () {
              this.showAllLocationBatches(mContext);
            },
            child: Text(
              Constants.VIEW_MORE_BATCHES,
              style: TextStyle(
                  color: Color(Constants.APP_COLOR),
                  decoration: TextDecoration.underline),
            ),
          ),
        );
      } else {
        return Container();
      }
    }
  }

  showAllLocationBatchesQuantityAdjustment(BuildContext mContext) {
    return showDialog(
        context: mContext,
        barrierDismissible: false,
        builder: (mContext) => AlertDialog(
              title: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          child: Text(
                            Constants.INVENTORY_BATCHES,
                            style: TextStyle(
                                color: Color(Constants.APP_COLOR),
                                fontWeight: FontWeight.bold,
                                fontSize: 15.0),
                          ),
                        ),
                        Container(
                          child: Row(
                            children: [
                              Container(
                                child: Text(
                                  Constants.LOCATION_NAME,
                                  style: TextStyle(
                                      color: Color(Constants.APP_COLOR),
                                      fontWeight: FontWeight.bold,
                                      fontSize: 15.0),
                                ),
                              ),
                              Text("  : "),
                              Expanded(
                                child: Container(
                                    child: Text(
                                  quantityAdjustmentDAOModel!.locationName!,
                                  style: TextStyle(
                                      color: Color(Constants.APP_COLOR),
                                      fontWeight: FontWeight.w300,
                                      fontSize: 13.0),
                                )),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                  IconButton(
                      onPressed: () {
                        Navigator.of(mContext).pop();
                      },
                      icon: Icon(
                        Icons.close,
                        color: Colors.red,
                      ))
                ],
              ),
              titlePadding: EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 5.0),
              contentPadding: EdgeInsets.fromLTRB(5.0, 5.0, 5.0, 5.0),
              content: Container(
                width: double.maxFinite,
                child: Container(
                  child: Padding(
                    padding: const EdgeInsets.all(5.0),
                    child: SingleChildScrollView(
                      child: Table(
                        border: TableBorder.all(
                          color: Colors.black,
                        ),
                        defaultColumnWidth: FixedColumnWidth(110),
                        children: [
                          TableRow(children: [
                            Center(
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Container(
                                  child: Text(
                                    Constants.BATCH_NO,
                                    style: TextStyle(
                                        color: Color(Constants.APP_COLOR),
                                        fontWeight: FontWeight.bold,
                                        fontSize: 13.0),
                                  ),
                                ),
                              ),
                            ),
                            Center(
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Container(
                                  child: Text(
                                    Constants.QUANTITY,
                                    style: TextStyle(
                                        color: Color(Constants.APP_COLOR),
                                        fontWeight: FontWeight.bold,
                                        fontSize: 13.0),
                                  ),
                                ),
                              ),
                            )
                          ]),
                          for (int i = 0;
                              i <
                                  quantityAdjustmentDAOModel!
                                      .quantityAdjustLocationsList!.length;
                              i++)
                            TableRow(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Container(
                                    child: Text(
                                        quantityAdjustmentDAOModel!
                                            .quantityAdjustLocationsList![i]
                                            .batchNumber!,
                                        textAlign: TextAlign.start,
                                        style: TextStyle(
                                            fontSize: 13.0,
                                            color: Color(Constants.APP_COLOR))),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Container(
                                    child: Text(
                                        "${quantityAdjustmentDAOModel!.quantityAdjustLocationsList![i].quantity} ${quantityAdjustmentDAOModel!.quantityAdjustLocationsList![i].quantityIn}",
                                        textAlign: TextAlign.start,
                                        style: TextStyle(
                                            fontSize: 13.0,
                                            color: Color(Constants.APP_COLOR))),
                                  ),
                                )
                              ],
                            )
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ));
  }

  showQuantityAdjustmentBatchesView(String title) {
    int index = 0;
    for (var i = 0;
        i < quantityAdjustmentDAOModel!.quantityAdjustLocationsList!.length;
        i++) {
      if (quantityAdjustmentDAOModel!
              .quantityAdjustLocationsList![i].quantity !=
          0) {
        index = i;
      }
    }

    return Container(
        margin: EdgeInsets.symmetric(vertical: 2.0),
        child: Row(
          children: [
            Expanded(
                child: Text("$title",
                    style: TextStyle(
                        fontSize: 14.0,
                        fontFamily: StyleView.FONT_TITLE,
                        color: Colors.black,
                        fontWeight: FontWeight.w700))),
            Expanded(
                flex: 2,
                child: Text(
                  " : ${quantityAdjustmentDAOModel!.quantityAdjustLocationsList![index].batchNumber} ( ${quantityAdjustmentDAOModel!.quantityAdjustLocationsList![index].quantity} ${quantityAdjustmentDAOModel!.quantityAdjustLocationsList![index].quantityIn}  )",
                  style: TextStyle(
                    fontSize: 13.0,
                    fontFamily: StyleView.FONT_TITLE,
                    color: Colors.black,
                  ),
                ))
          ],
        ));
  }
}
