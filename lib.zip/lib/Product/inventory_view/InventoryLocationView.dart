import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/TextView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/InventoryManagmentModel.dart';
import 'package:vyaparlive/model/PriceModel.dart';
import 'package:vyaparlive/model/bu_model/LocationsModel.dart';
import 'package:vyaparlive/model/product_model/InventoryDetailsDAO.dart';
import 'package:vyaparlive/service/organization_service.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';

class InventoryLocationView extends StatefulWidget {
  final List<InventoryManagementModel> inventoryList;
  final String buName;
  final String locationName;
  final bool isLocationUpdate;
  final int locationIndex;
  final List<PriceModel> totalPriceList;
  final String buId;
  InventoryLocationView(
      {required this.inventoryList,
      required this.buName,
      required this.locationName,
      required this.isLocationUpdate,
      required this.locationIndex,
      required this.totalPriceList,
      required this.buId});

  @override
  _InventoryLocationViewState createState() => _InventoryLocationViewState();
}

class _InventoryLocationViewState extends State<InventoryLocationView> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  Locations? locationDropdownValue;
  List<Locations> locationsList = [];
  PriceModel? inventoryQuantityDropdown;
  List<InventoryManagementModel> inventoryList = [];
  final _locationQuantityController = new TextEditingController();
  String? inventoryQuntityInDropdown = Constants.UNIT_PRICE[0];
  String? remainingBatchQuantity = "0";
  List<PriceModel> _priceList = [];
  late OrganizationService _organizationService;
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;

  @override
  void initState() {
    super.initState();
    _organizationService = OrganizationService();
    inventoryList.addAll(widget.inventoryList);
    _priceList.addAll(widget.totalPriceList);
    this.loadingLocationData();
    this.updateInventoryData();
  }

  updateInventoryData() {
    setState(() {
      if (widget.isLocationUpdate) {
        inventoryQuntityInDropdown = Constants.UNIT_PRICE[0];

        for (int i = 0; i < widget.inventoryList.length; i++) {
          if (widget.locationName == widget.inventoryList[i].locationName) {
            inventoryQuntityInDropdown =
                widget.inventoryList[i].locationBatchList![0].quantityIn;
            for (int i = 0; i < _priceList.length; i++) {
              if (widget.inventoryList[i].locationBatchList![0].batchNumber ==
                  _priceList[i].batchNumber) {
                inventoryQuantityDropdown = _priceList[i];
              }
            }
          }
        }
      }
    });
  }

  loadingLocationData() async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
      });

      this.getLocationData().then((value) {
        locationsList.addAll(value);
        for (int j = 0; j < locationsList.length; j++) {
          if (widget.locationName == locationsList[j].locationName) {
            locationDropdownValue = locationsList[j];
          }
        }
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        SafeArea(
          child: Scaffold(
            backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
            appBar: AppBar(
              backgroundColor: Color(Constants.APP_COLOR),
              centerTitle: true,
              title: Column(
                children: [
                  Text(Language()
                      .getString(Constants.INVENTORY_LOCATION, selectedLang)),
                  Text(
                    "${widget.buName}",
                    style: TextStyle(fontSize: 13.0),
                  )
                ],
              ),
            ),
            bottomNavigationBar: Container(
              child: CommonButtonsView(
                context: context,
                b1Text: Language().getString(Constants.BACK, selectedLang),
                b2Text: (widget.isLocationUpdate)
                    ? Language().getString(Constants.UPDATE_STRING, selectedLang)
                    : Language().getString(Constants.STR_SAVE, selectedLang),
                onb1Action: () {
                  Navigator.of(context).pop();
                },
                onb2Action: () {
                  this.onSaveInventoryDetails(
                      widget.isLocationUpdate, widget.locationIndex);
                },
              ),
            ),
            body: Container(
              padding: EdgeInsets.all(10.0),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    new Text(
                        Language().getString(Constants.LOCATION, selectedLang),
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_15,
                            fontWeight: FontWeight.bold,
                            color: Color(Constants.APP_COLOR))),
                    SizedBox(height: 5.0),
                    (widget.isLocationUpdate)
                        ? Container(
                            decoration: AppUtills.boxDecoration(),
                            margin: EdgeInsets.symmetric(vertical: 5.0),
                            child: TextView(
                              title: Language().getString(
                                  Constants.LOCATION_NAME, selectedLang),
                              value: locationDropdownValue != null
                                  ? locationDropdownValue!.locationName
                                  : "",
                            ))
                        : this.inventoryLocations(),
                    Container(
                        child: Row(
                      children: <Widget>[
                        new Text(
                            Language()
                                .getString(Constants.BATCH_NO, selectedLang),
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontWeight: FontWeight.bold,
                                color: Color(Constants.APP_COLOR))),
                        SizedBox(
                          width: 3.0,
                        ),
                        (inventoryQuantityDropdown != null &&
                                inventoryList.length == 0)
                            ? this.showTotoalInventotyQuantity()
                            : this.showRemainingInventoryQuantity(
                                inventoryQuantityDropdown,
                                widget.locationIndex,
                                widget.isLocationUpdate)
                      ],
                    )),
                    this.inventoryBatchQuantity(),
                    (inventoryQuantityDropdown != null &&
                            inventoryList.length > 0)
                        ? Container(
                            child: Text(
                            Language().getString(Constants.TOTAL_QUANTITY_STRING,
                                    selectedLang) +
                                " : ${inventoryQuantityDropdown!.quantity}",
                            style: TextStyle(
                                fontSize: 13.0,
                                color: Colors.deepOrange[300],
                                fontWeight: FontWeight.bold),
                          ))
                        : Container(),
                    if (inventoryQuantityDropdown != null)
                      this.showBatchPricingDetails(inventoryQuantityDropdown,
                          widget.locationIndex, widget.isLocationUpdate),
                    new Text(
                        Language().getString(Constants.QUANTITY, selectedLang),
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_15,
                            fontWeight: FontWeight.bold,
                            color: Color(Constants.APP_COLOR))),
                    SizedBox(height: 5.0),
                    this.buildInventiryUnitPriceDropdown()
                  ],
                ),
              ),
            ),
          ),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    );
  }

  buildInventiryUnitPriceDropdown() {
    return Container(
      decoration: AppUtills.boxDecoration(customContainerColor: Colors.white),
      child: Row(
        children: <Widget>[
          Expanded(
            flex: 2,
            child: Padding(
              padding: const EdgeInsets.all(5.0),
              child: TextFormField(
                keyboardType: TextInputType.number,
                style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                controller: _locationQuantityController,
                decoration: InputDecoration(
                  hintText: Language()
                      .getString(Constants.QUANTITY_AT_LOCATION, selectedLang),
                  border: InputBorder.none,
                ),
                inputFormatters: [
                  CommonMethods.inputTextFormatter(isDouble: true)
                ],
              ),
            ),
          ),
          Expanded(
              child: Container(
                  padding: EdgeInsets.only(left: 5),
                  child: DropdownButton<String>(
                      onTap: () {
                        CommonMethods.hideKeyboard(context);
                      },
                      value: inventoryQuntityInDropdown,
                      hint: new Text(
                        Language().getString(Constants.SELECT, selectedLang),
                      ),
                      isExpanded: true,
                      underline: SizedBox(),
                      onChanged: (String? data) {
                        setState(() {
                          inventoryQuntityInDropdown = data;
                        });
                      },
                      items: Constants.UNIT_PRICE.map((String model) {
                        return new DropdownMenuItem<String>(
                          child: new Text(model),
                          value: model,
                        );
                      }).toList()))),
        ],
      ),
    );
  }

  Widget showBatchPricingDetails(PriceModel? inventoryDropdownQuantity,
      int index, bool isUpdateInventory) {
    if (inventoryList.length > 0 &&
        inventoryDropdownQuantity != null &&
        isUpdateInventory) {
      return Column(
        children: [
          for (int i = 0; i < inventoryList.length; i++)
            for (int j = 0; j < inventoryList[i].locationBatchList!.length; j++)
              if (inventoryDropdownQuantity.batchNumber ==
                  inventoryList[i].locationBatchList![j].batchNumber)
                this.showAllocatedLocation(
                    i,
                    inventoryDropdownQuantity.batchNumber,
                    inventoryList[i].locationBatchList![j].batchNumber,
                    j)
        ],
      );
      // return Container(
      //     child: ListView.builder(
      //         shrinkWrap: true,
      //         physics: NeverScrollableScrollPhysics(),
      //         itemBuilder: (context, i) {
      //           return this.showAllocatedLocation(
      //               index,
      //               inventoryDropdownQuantity.batchNumber,
      //               inventoryList[index].locationBatchList[i].batchNumber,
      //               i);
      //         },
      //         itemCount: inventoryList[index].locationBatchList.length));
    } else {
      return Column(
        children: [
          for (int i = 0; i < inventoryList.length; i++)
            for (int j = 0; j < inventoryList[i].locationBatchList!.length; j++)
              if (inventoryDropdownQuantity!.batchNumber ==
                  inventoryList[i].locationBatchList![j].batchNumber)
                this.showAllocatedLocation(
                    i,
                    inventoryDropdownQuantity.batchNumber,
                    inventoryList[i].locationBatchList![j].batchNumber,
                    j)
        ],
      );
    }
  }

  Widget showAllocatedLocation(
      int index, String? batchNuber, String? compareBatchNumber, int index2) {
    if (batchNuber == compareBatchNumber) {
      return Container(
          child: Card(
        child: Container(
          child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: this.showBatchPriceData(
                  Constants.LOCATION,
                  "${inventoryList[index].locationName}" +
                      "  ${[
                        inventoryList[index].locationBatchList![index2].quantity
                      ]}")),
        ),
      ));
    } else {
      return Container();
    }
  }

  showBatchPriceData(String title, String value) {
    return Container(
        margin: EdgeInsets.symmetric(vertical: 2.0),
        child: Row(children: [
          Expanded(
            child: Text(title,
                style: TextStyle(
                    fontSize: 14.0,
                    fontFamily: StyleView.FONT_TITLE,
                    color: Color(Constants.APP_COLOR),
                    fontWeight: FontWeight.bold)),
          ),
          Expanded(
              child: Text(
            " : $value",
            style: TextStyle(
              fontSize: 13.0,
              fontFamily: StyleView.FONT_TITLE,
              color: Colors.black,
            ),
          )),
        ]));
  }

  Widget showRemainingInventoryQuantity(PriceModel? inventoryDropdownQuantity,
      int index, bool isUpdateInventory) {
    num inventoryTotalQuantity = 0;
    if (inventoryList.length > 0 && inventoryDropdownQuantity != null) {
      // for (int i = 0; i < inventoryList.length; i++) {
      if (isUpdateInventory) {
        for (int j = 0; j < inventoryList.length; j++) {
          for (int i = 0; i < inventoryList[j].locationBatchList!.length; i++) {
            if (inventoryDropdownQuantity.batchNumber ==
                inventoryList[j].locationBatchList![i].batchNumber) {
              inventoryTotalQuantity = inventoryTotalQuantity +
                  inventoryList[j].locationBatchList![i].quantity!;
            }
          }
        }

        // if (inventoryDropdownQuantity.batchNumber ==
        //     inventoryList[index].locationBatchList[0].batchNumber) {
        //   inventoryTotalQuantity = inventoryTotalQuantity +
        //       inventoryList[index].locationBatchList[0].quantity;
        // }
      } else {
        for (int j = 0; j < inventoryList.length; j++) {
          for (int i = 0; i < inventoryList[j].locationBatchList!.length; i++) {
            if (inventoryDropdownQuantity.batchNumber ==
                inventoryList[j].locationBatchList![i].batchNumber) {
              inventoryTotalQuantity = inventoryTotalQuantity +
                  inventoryList[j].locationBatchList![i].quantity!;
            }
          }
        }
      }

      // }

      remainingBatchQuantity =
          (double.parse(inventoryDropdownQuantity.quantity!) -
                  inventoryTotalQuantity)
              .toString();

      _locationQuantityController.text = remainingBatchQuantity!;
      return Container(
          child: Expanded(
        child: Text(
          Language().getString(Constants.REMAINING_QUANTITY, selectedLang) +
              " : $remainingBatchQuantity",
          style: TextStyle(
              fontSize: 13.0,
              color: Colors.deepOrange[300],
              fontWeight: FontWeight.bold),
        ),
      ));
    } else {
      return Container();
    }
  }

  Widget showTotoalInventotyQuantity() {
    remainingBatchQuantity = inventoryQuantityDropdown!.quantity;
    return Container(
      child: Text(
          Language().getString(
                  Constants.BATCH_NO + " " + Constants.TOTAL_QUANTITY_STRING,
                  selectedLang) +
              " : " +
              inventoryQuantityDropdown!.quantity,
          style: TextStyle(fontSize: 10.0, color: Colors.deepOrange[300])),
    );
  }

  Widget inventoryLocations() {
    return Container(
        margin: EdgeInsets.symmetric(
          vertical: 5.0,
        ),
        decoration: AppUtills.boxDecoration(),
        padding: EdgeInsets.all(1),
        child: Container(
            color: Colors.white70,
            padding: EdgeInsets.only(left: 5, right: 5),
            child: DropdownButton<Locations>(
                onTap: () {
                  CommonMethods.hideKeyboard(context);
                },
                isExpanded: true,
                hint: Text(
                    Language().getString(Constants.LOCATION, selectedLang)),
                underline: SizedBox(),
                items: locationsList.map((Locations locationData) {
                  return DropdownMenuItem<Locations>(
                    value: locationData,
                    child: new Text(
                      locationData.locationName!,
                      style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                    ),
                  );
                }).toList(),
                value: locationDropdownValue,
                onChanged: (Locations? location) {
                  setState(() {
                    locationDropdownValue = location;
                  });
                })));
  }

  Widget inventoryBatchQuantity({bool isFromQuantityAdjustment = false}) {
    return Container(
      margin: EdgeInsets.symmetric(
        vertical: 5.0,
      ),
      decoration: AppUtills.boxDecoration(),
      padding: EdgeInsets.all(1),
      child: Container(
        color: Colors.white70,
        padding: EdgeInsets.only(left: 5, right: 5),
        child: DropdownButton<PriceModel>(
          onTap: () {
            CommonMethods.hideKeyboard(context);
          },
          isExpanded: true,
          hint: Text(Language().getString(Constants.BATCH_NO, selectedLang)),
          underline: SizedBox(),
          items: _priceList.map((PriceModel batchPrice) {
            return DropdownMenuItem<PriceModel>(
              value: batchPrice,
              child: new Text(
                batchPrice.batchNumber!,
                style: TextStyle(fontFamily: StyleView.FONT_TITLE),
              ),
            );
          }).toList(),
          value: inventoryQuantityDropdown,
          onChanged: (PriceModel? model) {
            setState(() {
              inventoryQuantityDropdown = model;
              // _locationQuantityController.text =
              //     inventoryQuantityDropdown.quantity;
              if (isFromQuantityAdjustment) {
                // remainingAdjustmentQuantity = int.parse(model.quantity);
              }
            });
          },
        ),
      ),
    );
  }

  Future<List<Locations>> getLocationData() async {
    locationsList.clear();

    String body = json.encode({"id": widget.buId});
    var response = await _organizationService
        .getOrganizationDataById(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    List<Locations> _list = [];
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(resObj)) {
        for (var obj in resObj[0]['locations'])
          _list.add(Locations.fromJson(obj));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
      return _list;
  }

  onSaveInventoryDetails(bool isUpdateInventory, int index) {
    if (isUpdateInventory) {
      if (locationDropdownValue != null && inventoryQuantityDropdown != null) {
        bool isBatchNumberExist = false;
        int existIndex = -1;
        for (int i = 0;
            i < inventoryList[index].locationBatchList!.length;
            i++) {
          /**
               * Inventory Batch Number Search
               */
          if (inventoryQuantityDropdown!.batchNumber ==
              inventoryList[index].locationBatchList![i].batchNumber) {
            existIndex = i;
            isBatchNumberExist = true;
          }
        }

        if (isBatchNumberExist) {
          if (inventoryList[index].locationBatchList![existIndex].quantity !=
              double.parse(_locationQuantityController.text)) {
            inventoryList[index].locationBatchList![existIndex].quantity =
                inventoryList[index].locationBatchList![existIndex].quantity! +
                    double.parse(_locationQuantityController.text);
            inventoryList[index] = InventoryManagementModel(
                locationName: locationDropdownValue!.locationName,
                locationBatchList: inventoryList[index].locationBatchList);
          } else {
            print("INVENTORY QUANTITY NOT CHANGED");
          }
        } else {
          List<InventoryDetailsDAO> locationBatchData = [];
          locationBatchData.addAll(inventoryList[index].locationBatchList!);
          locationBatchData.add(InventoryDetailsDAO(
              batchNumber: inventoryQuantityDropdown!.batchNumber,
              quantityIn: inventoryQuntityInDropdown,
              quantity: double.parse(_locationQuantityController.text)));

          inventoryList[index] = InventoryManagementModel(
              locationName: locationDropdownValue!.locationName,
              locationBatchList: locationBatchData);
        }

        setState(() {
          inventoryList.reversed;
        });
        Navigator.pop(context, inventoryList);
      } else {
        Navigator.of(context).pop();
      }
    } else {
      if (locationDropdownValue != null && inventoryQuantityDropdown != null) {
        bool isExistLocationName = false;
        int existIndex = -1;

        for (int i = 0; i < inventoryList.length; i++) {
          if (locationDropdownValue!.locationName ==
              inventoryList[i].locationName) {
            isExistLocationName = true;
            existIndex = i;
          }
        }

        if (isExistLocationName) {
          bool isBatchNumberExist = false;
          num existBatchIndex = -1;
          for (int i = 0;
              i < inventoryList[existIndex].locationBatchList!.length;
              i++) {
            if (inventoryList[existIndex].locationBatchList![i].batchNumber ==
                inventoryQuantityDropdown!.batchNumber) {
              isBatchNumberExist = true;
              existBatchIndex = i;
            }
          }

          if (isBatchNumberExist) {
            num updateQuantity = inventoryList[existIndex]
                    .locationBatchList![existBatchIndex as int]
                    .quantity! +
                double.parse(_locationQuantityController.text);
            inventoryList[existIndex]
                .locationBatchList![existBatchIndex]
                .quantity = updateQuantity;
          } else {
            List<InventoryDetailsDAO> locationBatchData = [];
            locationBatchData
                .addAll(inventoryList[existIndex].locationBatchList!);
            locationBatchData.add(InventoryDetailsDAO(
                batchNumber: inventoryQuantityDropdown!.batchNumber,
                quantityIn: inventoryQuntityInDropdown,
                quantity: double.parse(_locationQuantityController.text)));
            inventoryList[existIndex] = InventoryManagementModel(
                locationName: locationDropdownValue!.locationName,
                locationBatchList: locationBatchData);
          }
        } else {
          List<InventoryDetailsDAO> locationBatchData = [];
          locationBatchData.add(InventoryDetailsDAO(
              batchNumber: inventoryQuantityDropdown!.batchNumber,
              quantityIn: inventoryQuntityInDropdown,
              quantity: double.parse(_locationQuantityController.text)));
          inventoryList.add(InventoryManagementModel(
              locationName: locationDropdownValue!.locationName,
              locationBatchList: locationBatchData));
        }

        setState(() {
          inventoryList.reversed;
        });
        Navigator.pop(context, inventoryList);
      } else {
        Navigator.of(context).pop();
      }
    }
  }
}
