import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutx/styles/app_theme.dart';
import 'package:vyaparlive/service/api_service/ProductsApiService.dart';
import 'package:vyaparlive/model/product_model/ProductModel.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/barcode/BarcodeWidget.dart';
import 'dart:math' as math;
import 'dart:async';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf/pdf.dart';
import 'package:printing/printing.dart';
import 'package:barcode/barcode.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/components/AppUtills.dart';

class DownloadBarcodesPage extends StatefulWidget {
  final String? buId;
  const DownloadBarcodesPage({Key? key, this.buId}) : super(key: key);

  @override
  _DownloadBarcodesPageState createState() => _DownloadBarcodesPageState();
}

class _DownloadBarcodesPageState extends State<DownloadBarcodesPage> {
  List<BuProductModal> _products = [];
  bool isLoading = true;
  bool isExporting = false;
  String progressMessage = Constants.LOADING;
  String? selectedLang = AppController.instance.getSelectedlanguage;
  late ThemeData theme;

  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _loadProducts();
  }

  Future<void> _loadProducts() async {
    setState(() {
      isLoading = true;
    });

    final products = await ProductsApiService.instance.getBuProducts(
        context: context,
        buId: widget.buId,
        mapFilter: {"from": 1, "count": 9999},
        langError: Language().getString(Constants.ERROR, selectedLang),
        langOk: Language().getString(Constants.OKAY_STR, selectedLang));

    setState(() {
      _products = products;
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
      body: SafeArea(
        child: Scaffold(
          appBar: AppBar(
            iconTheme: IconThemeData(color: theme.colorScheme.primary),
            title: AppbarName(
              title: Language().getString("Download Barcodes", selectedLang),
              buName: AppController.instance.getBuName,
            ),
            backgroundColor: Colors.transparent,
            elevation: 0,
            centerTitle: true,
            actions: [
              // IconButton(
              //     tooltip:
              //         Language().getString("Generate Barcodes", selectedLang),
              //     onPressed: _generateMissingBarcodes,
              //     icon: Icon(Icons.qr_code_2,
              //         color: theme.colorScheme.primary)),
              IconButton(
                  tooltip: Language().getString("Export PDF", selectedLang),
                  onPressed: _exportPdf,
                  icon: Icon(Icons.picture_as_pdf,
                      color: theme.colorScheme.primary))
            ],
          ),
          backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
          body: isLoading
              ? Center(child: CircularProgressIndicator())
              : _products.isEmpty
                  ? Center(
                      child: Text(Language()
                          .getString(Constants.NO_DATA_FOUND, selectedLang)))
                  : Stack(
                      children: [
                        Column(
                          children: [
                            // Padding(
                            //   padding: const EdgeInsets.symmetric(horizontal: 12.0,vertical: 8.0),
                            //   child: SizedBox(
                            //     width: double.infinity,
                            //     child: ElevatedButton.icon(
                            //       style: ElevatedButton.styleFrom(
                            //           backgroundColor:
                            //               theme.colorScheme.primary,
                            //           padding: EdgeInsets.all(5)),
                            //       icon: Icon(Icons.qr_code_2),
                            //       label: Text('Generate Barcodes'),
                            //       onPressed: _generateMissingBarcodes,
                            //     ),
                            //   ),
                            // ),
                            Expanded(
                              child: ListView.separated(
                                padding: EdgeInsets.all(12),
                                itemCount: _products.length,
                                separatorBuilder: (_, __) =>
                                    SizedBox(height: 5),
                                itemBuilder: (context, index) {
                                  final p = _products[index];
                                  return Card(
                                    elevation: 4,
                                    child: Padding(
                                      padding: const EdgeInsets.all(12.0),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            p.name ?? "",
                                            style: TextStyle(
                                                fontWeight: StyleView.fontBold,
                                                fontSize: 16),
                                          ),
                                          SizedBox(height: 8),
                                          if (p.batchPrice != null &&
                                              p.batchPrice!.isNotEmpty)
                                            Column(
                                              children: p.batchPrice!
                                                  .where((batch) =>
                                                      batch.batchNumber !=
                                                          null &&
                                                      batch.batchNumber!
                                                          .isNotEmpty)
                                                  .map((batch) {
                                                final barcodeValue =
                                                    (batch.barcode != null &&
                                                            batch.barcode!
                                                                .isNotEmpty)
                                                        ? batch.barcode!
                                                        : (p.barcode ?? "");

                                                return Padding(
                                                  padding: const EdgeInsets
                                                      .symmetric(vertical: 6.0),
                                                  child: Row(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      Expanded(
                                                        flex: 2,
                                                        child: Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            Text(
                                                              "${Language().getString(Constants.BATCH_NO, selectedLang)}: ${batch.batchNumber ?? ""}",
                                                              style: TextStyle(
                                                                  fontWeight:
                                                                      StyleView
                                                                          .fontSemiBold),
                                                            ),
                                                            SizedBox(height: 6),
                                                            Text(
                                                                "${Language().getString(Constants.QUANTITY, selectedLang)}: ${batch.quantity ?? 0} ${batch.quantityIn ?? ""}"),
                                                          ],
                                                        ),
                                                      ),
                                                      SizedBox(width: 12),
                                                      Expanded(
                                                        flex: 3,
                                                        child:
                                                            barcodeValue
                                                                    .isNotEmpty
                                                                ? Column(
                                                                    children: [
                                                                      barcodeWidget(
                                                                          barcodeValue),
                                                                      // SizedBox(
                                                                      //     height:
                                                                      //         8),
                                                                      // ElevatedButton
                                                                      //     .icon(
                                                                      //   icon: Icon(
                                                                      //       Icons
                                                                      //           .edit,
                                                                      //       size:
                                                                      //           16),
                                                                      //   label: Text(
                                                                      //       'Edit'),
                                                                      //   onPressed:
                                                                      //       () =>
                                                                      //           _editBarcode(batch),
                                                                      // )
                                                                    ],
                                                                  )
                                                                : Container(
                                                                    padding:
                                                                        EdgeInsets.all(
                                                                            12),
                                                                    child: Text(Language().getString(
                                                                        "No Barcode",
                                                                        selectedLang)),
                                                                  ),
                                                      ),
                                                    ],
                                                  ),
                                                );
                                              }).toList(),
                                            )
                                          else
                                            Padding(
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                      vertical: 8.0),
                                              child: Text(Language().getString(
                                                  Constants.NO_DATA_FOUND,
                                                  selectedLang)),
                                            )
                                        ],
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ),
                          ],
                        ),
                        AppUtills.showLoadingView(
                            context: context,
                            message: Language()
                                .getString(progressMessage, selectedLang),
                            isLoading: isExporting)
                      ],
                    ),
        ),
      ),
    );
  }

  Future<void> _exportPdf() async {
    setState(() {
      isExporting = true;
      progressMessage = "Generating PDF";
    });

    try {
      // Collect only entries that have an actual barcode value and a valid batch number
      final entries = <Map<String, String>>[];
      for (final p in _products) {
        if (p.batchPrice == null) continue;
        for (final batch in p.batchPrice!) {
          final data = (batch.barcode != null && batch.barcode!.isNotEmpty)
              ? batch.barcode!
              : ((p.barcode != null && p.barcode!.isNotEmpty)
                  ? p.barcode!
                  : "");

          if (data.isEmpty) continue;

          // Skip if batch number is empty or null
          if (batch.batchNumber == null || batch.batchNumber!.isEmpty) continue;

          entries.add({
            'barcode': data,
            'label': 'Batch No. ${batch.batchNumber!}',
          });
        }
      }

      if (entries.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(
                Language().getString(Constants.NO_DATA_FOUND, selectedLang))));
        setState(() {
          isExporting = false;
        });
        return;
      }

      final pdf = pw.Document();
      final code = Barcode.code128();
      final pageFormat = PdfPageFormat.a4;
      final margin = 8.0; // reduced margin to use more area

      final availableWidth = pageFormat.width - margin * 2;
      final availableHeight = pageFormat.height - margin * 2;

      // Approx label size - smaller to maximize labels per page
      final approxLabelW = 140.0;
      final approxLabelH = 90.0;

      final columns = math.max(1, (availableWidth / approxLabelW).floor());
      final rows = math.max(1, (availableHeight / approxLabelH).floor());
      final labelsPerPage = columns * rows;

      final labelW = availableWidth / columns;
      final labelH = availableHeight / rows;

      for (var i = 0; i < entries.length; i += labelsPerPage) {
        final chunk =
            entries.sublist(i, math.min(i + labelsPerPage, entries.length));

        pdf.addPage(pw.Page(
          pageFormat: pageFormat,
          build: (pw.Context ctx) {
            return pw.Padding(
              padding: pw.EdgeInsets.all(margin),
              child: pw.Wrap(
                spacing: 6,
                runSpacing: 6,
                children: chunk.map((e) {
                  return pw.Container(
                    width: labelW,
                    height: labelH,
                    padding: pw.EdgeInsets.all(6),
                    child: pw.Column(
                      mainAxisAlignment: pw.MainAxisAlignment.center,
                      children: [
                        pw.Text(e['label'] ?? '',
                            style: pw.TextStyle(fontSize: 10)),
                        pw.SizedBox(height: 6),
                        pw.BarcodeWidget(
                          barcode: code,
                          data: e['barcode'] ?? '',
                          width: labelW * 0.9,
                          height: labelH * 0.5,
                        ),
                      ],
                    ),
                  );
                }).toList(),
              ),
            );
          },
        ));
      }

      final bytes = await pdf.save();
      await Printing.sharePdf(bytes: bytes, filename: 'barcodes.pdf');

      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('PDF exported successfully'),
        duration: Duration(seconds: 2),
      ));
    } finally {
      setState(() {
        isExporting = false;
      });
    }
  }

  void _generateMissingBarcodes() {
    int generatedCount = 0;
    final random = math.Random();

    for (final product in _products) {
      if (product.batchPrice == null) continue;

      for (final batch in product.batchPrice!) {
        // Check if batch has no barcode
        if (batch.barcode == null || batch.barcode!.isEmpty) {
          // Generate a 13-digit unique barcode
          final barcode = _generate13DigitBarcode(random);
          batch.barcode = barcode;
          generatedCount++;
        }
      }
    }

    setState(() {
      // Rebuild the UI with generated barcodes
    });

    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('Generated $generatedCount barcodes'),
      duration: Duration(seconds: 2),
    ));
  }

  String _generate13DigitBarcode(math.Random random) {
    // Generate 13 random digits
    String barcode = '';
    for (int i = 0; i < 13; i++) {
      barcode += random.nextInt(10).toString();
    }
    return barcode;
  }

  void _editBarcode(dynamic batch) {
    final controller = TextEditingController(text: batch.barcode ?? '');

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Edit Barcode'),
          content: TextField(
            controller: controller,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              labelText: 'Barcode',
              hintText: 'Enter 13-digit barcode',
              border: OutlineInputBorder(),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                if (controller.text.isNotEmpty) {
                  setState(() {
                    batch.barcode = controller.text;
                  });
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Barcode updated')),
                  );
                }
              },
              child: Text('Save'),
            ),
          ],
        );
      },
    );
  }
}
