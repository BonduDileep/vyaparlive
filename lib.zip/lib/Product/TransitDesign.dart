import 'package:vyaparlive/theme/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/StyleView.dart';

class TransitCardDesign extends StatelessWidget {
  final String? invoiceNo;
  final String? quantity;
  final VoidCallback? onPress;
  TransitCardDesign(
      {required this.invoiceNo, required this.quantity, required this.onPress});
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Card(
        shape: RoundedRectangleBorder(
            side: new BorderSide(
                color: AppTheme.vyaparTheme.colorScheme.primary, width: 1.0),
            borderRadius: BorderRadius.circular(5.0)),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Text("Transit",
                        style: TextStyle(
                            color: AppTheme.vyaparTheme.colorScheme.primary,
                            fontWeight: FontWeight.bold))),
                SizedBox(
                  height: 5.0,
                ),
                Container(
                  child: Row(
                    children: <Widget>[
                      Expanded(
                        flex: 1,
                        child: Container(
                            child: Container(
                          padding: EdgeInsets.only(left: 10),
                          child: Text("Invoice",
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: StyleView.FONT_SIZE_15,
                                  fontFamily: StyleView.FONT_TITLE)),
                        )),
                      ),
                      Text(": "),
                      Expanded(
                        flex: 2,
                        child: InkWell(
                          onTap: onPress,
                          child: Container(
                            padding: EdgeInsets.only(left: 5),
                            child: Text(
                              "${Constants.INVOICE} #$invoiceNo",
                              style: TextStyle(
                                  decoration: TextDecoration.underline,
                                  color: Colors.black,
                                  fontFamily: StyleView.FONT_TITLE),
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
                SizedBox(
                  height: 5.0,
                ),
                Container(
                  child: Row(
                    children: <Widget>[
                      Expanded(
                        flex: 1,
                        child: Container(
                            child: Container(
                          padding: EdgeInsets.only(left: 10),
                          child: Text(Constants.QUANTITY,
                              style: TextStyle(
                                  fontSize: StyleView.FONT_SIZE_15,
                                  color: Colors.black,
                                  fontFamily: StyleView.FONT_TITLE)),
                        )),
                      ),
                      Text(": "),
                      Expanded(
                        flex: 2,
                        child: Container(
                            padding: EdgeInsets.only(left: 5),
                            child: Container(
                              child: Text(
                                "$quantity",
                                style: TextStyle(
                                    color: Colors.black,
                                    fontFamily: StyleView.FONT_TITLE),
                              ),
                            )),
                      )
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
