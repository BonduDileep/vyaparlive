import 'package:vyaparlive/Product/EditMyProduct.dart';
import 'package:vyaparlive/Product/ProductDetailsPage.dart';
import 'package:vyaparlive/Product/product_transaction_view/ProductTransactionPage.dart';
import 'package:vyaparlive/Product/offers_view/OffersPage.dart';
import 'package:vyaparlive/Product/quantity_adjust_view/QuantityAdjustmentView.dart';
import 'package:vyaparlive/Product/suppliers_view/SupplierPage.dart';
import 'package:vyaparlive/model/product_model/ProductModel.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:flutter/material.dart';
import 'package:flutx/flutx.dart';

import '../../components/common_methods.dart';
import '../../core/enums/privilleges_enum.dart';
import '../../ondc_menu/ondc_edit_product/OndcEditProduct.dart';

class ProductController extends FxController {
  navigateCardDetails({required String? productId, required String? buId}) {
    Navigator.push(
        context,
        PageTransition(
          context: context,
          page: ProductDetailsPage(
            productId: productId,
            currentBuId: buId,
          ),
        ));
  }

  navigateOfferDetails(
      {required String? productName,
      required String? productImage,
      required String? buId,
      required String? productId}) {
    Navigator.push(
        context,
        PageTransition(
            context: context,
            page: OffersPage(
              productName: productName,
              productImage: productImage,
              buId: buId,
              productId: productId,
            )));
  }

  navigateSuppliers(
      {required String? productName,
      required String? productImage,
      required String? buId,
      required String? productId}) {
    Navigator.push(
        context,
        PageTransition(
            context: context,
            page: SupplierPage(
              productName: productName,
              productImage: productImage,
              buId: buId,
              productId: productId,
            )));
  }

  navigateProductTransaction({required BuProductModal? productItem}) {
    Navigator.push(
        context,
        PageTransition(
            context: context,
            page: ProductTransactionPage(productDetails: productItem)));
  }

  navigateEditProduct(
      {required String? title,
      required String? buId,
      required String? productId}) {
    if (CommonMethods.isPrivillegeExist(
        context, PrivillegesActions.KEY_MENU_ONDC_TAB)) {
      Navigator.push(
          context,
          PageTransition(
            context: context,
            page: OndcEditMyProductPage(
                title: title, buId: buId, productId: productId),
          ));
    } else {
      Navigator.push(
          context,
          PageTransition(
            context: context,
            page: EditMyProductPage(
                title: title, buId: buId, productId: productId),
          ));
    }
  }

  navigateQuantityAdjustment(
      {required String? productName,
      required String? buName,
      required String? buId,
      required String? productId}) {
    Navigator.push(
        context,
        PageTransition(
          context: context,
          page: QuantityAdjustmentView(
              productName: productName,
              buName: buName,
              buId: buId,
              productId: productId),
        ));
  }

  @override
  String getTag() {
    return "product_controller";
  }
}
