import 'package:vyaparlive/components/BasicProductDetails.dart';
import 'package:vyaparlive/model/ModelProduct.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:flutter/material.dart';
import 'package:flutx/flutx.dart';

class NonSelectableController extends FxController {
  void onProductDetails({required String productId, required String buId}) {
    Navigator.push(
        context,
        PageTransition(
            context: context,
            page: BasicProductDetails(
              productId: productId,
              currentBuId: buId,
              isShowBasicDetails: true,
            )));
  }

  void onBack(
      {required BuildContext rootContext,
      required List<ModelProduct> productsList}) {
    Navigator.pop(rootContext, productsList);
  }

  @override
  String getTag() {
    return 'non_select_products_controller';
  }
}
