import 'package:vyaparlive/Product/ProductsMenuPage.dart';
import 'package:vyaparlive/model/product_model/BatchPriceDAO.dart';
import 'package:vyaparlive/model/product_model/ProductModel.dart';
import 'package:vyaparlive/product_consumption_view/raw_material_view/RawProductsList.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutx/utils/utils.dart';
import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Product/inventory_view/InventoryLocationBatchView.dart';
import 'package:vyaparlive/Product/quantity_adjust_view/QuantityAdjustExpanded.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/TextView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/InventoryManagmentModel.dart';
import 'package:vyaparlive/model/product_model/InventoryDetailsDAO.dart';
import 'package:vyaparlive/model/product_model/QuantityAdjustmentDAO.dart';
import 'package:vyaparlive/service/product_services.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:vyaparlive/utills/SharePref.dart';

class QuantityAdjustmentView extends StatefulWidget {
  final String? buId;
  final String? buName;
  final String? productName;
  final String? productId;
  final bool? isFromRawMaterial;
  const QuantityAdjustmentView(
      {this.buId,
      this.buName,
      this.productId,
      this.productName,
      this.isFromRawMaterial = false});

  @override
  _QuantityAdjustmentViewState createState() => _QuantityAdjustmentViewState();
}

class _QuantityAdjustmentViewState extends State<QuantityAdjustmentView> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  String remainingBatchQuantity = "0";
  num totalCurrentBatchQuantity = 0;
  num remainingCurrentBatchQuantity = 0;
  List<InventoryDetailsDAO> _locationBatchesInQuantityAdjustment = [];
  InventoryManagementModel? quantityAdjustmentLocationDropdown;
  InventoryDetailsDAO? quantityAdjustmentBatchDropdown;
  TextEditingController _quantityAdjutmentController =
      new TextEditingController();
  List<QuantityAdjustmentDAO> quantityAdjustmentList = [];
  String? adjustmentReasonDropdownValue;
  List<InventoryManagementModel> inventoryList = [];
  num? remainingAdjustmentQuantity = 0;
  String? updatedCurrentDateTime = "";
  DateFormat _currentDateTimeFormat = DateFormat("yyyy-MM-dd hh:mm aa");
  String? userName = "";
  String? userId = "";
  late ProductService _productService;
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  List<InventoryDetailsDAO> responseInventoryData = [];

  ScrollController? _scrollController;
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _scrollController = new ScrollController();
    _productService = ProductService();
    SharePref().getUserId().then((value) => userId = value);
    SharePref().getUserName().then((value) => userName = value);
    updatedCurrentDateTime = _currentDateTimeFormat.format(DateTime.now());
    this.loadServiceCall();
  }

  loadServiceCall() async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
      });
      // await getQuantityAdjustmentData().then((value) {
      //   setState(() {
      //     responseAdjustmentList.clear();
      //     responseAdjustmentList.addAll(value);
      //   });
      // });
      await getProuctById_v1().then((value) {
        List<BuProductModal> productDetails = [];
        productDetails.addAll(value);
        if (productDetails.isEmpty) return;

        for (var i in productDetails[0].inventoryData!) {
          responseInventoryData.add(i);
        }
        // print(responseAdjustmentList);
        // responseInventoryData.addAll(value);
        List<Map<String, dynamic>> batchNumbers = [];
        for (int k = 0; k < responseInventoryData.length; k++) {
          List<InventoryDetailsDAO> _locationBatchList = [];
          for (int m = 0;
              m < responseInventoryData[k].locationBatchList!.length;
              m++) {
            _locationBatchList.add(InventoryDetailsDAO(
                batchNumber:
                    responseInventoryData[k].locationBatchList![m].batchNumber,
                quantity:
                    responseInventoryData[k].locationBatchList![m].quantity,
                quantityIn:
                    responseInventoryData[k].locationBatchList![m].quantityIn));

            batchNumbers.add({
              "batch_number":
                  responseInventoryData[k].locationBatchList![m].batchNumber!,
              "quantity":
                  responseInventoryData[k].locationBatchList![m].quantity
            });
          }

          inventoryList.add(InventoryManagementModel(
              locationName: responseInventoryData[k].locationName,
              locationId: responseInventoryData[k].locationId,
              locationBatchList: _locationBatchList));
        }

        List<InventoryDetailsDAO> _locationBatchListForOthers = [];
        for (var i = 0; i < productDetails[0].batchPrice!.length; i++) {
          BatchPriceDAO batchPriceDAO = productDetails[0].batchPrice![i];
          bool isExist = false;
          bool canAdd = false;
          num quantity = batchPriceDAO.quantity??0;
          for (var j = 0; j < batchNumbers.length; j++) {
            if (batchNumbers[j]["batch_number"] == batchPriceDAO.batchNumber) {
              if (batchNumbers[j]["quantity"] < batchPriceDAO.quantity) {
                quantity = quantity - batchNumbers[j]["quantity"];
              } else {
                isExist = true;
              }
            }
          }
          if (!isExist) {
            _locationBatchListForOthers.add(InventoryDetailsDAO(
                batchNumber: batchPriceDAO.batchNumber,
                quantity: quantity,
                quantityIn: batchPriceDAO.quantityIn));
          }
        }
        inventoryList.add(InventoryManagementModel(
            locationName: "Others",
            locationId: "",
            locationBatchList: _locationBatchListForOthers));
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
        body: Stack(
      children: [
        SafeArea(
          child: Scaffold(
              backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
              appBar: AppBar(
                backgroundColor: Colors.transparent, //(Constants.APP_COLOR),
                centerTitle: true,
                elevation: 0,
                iconTheme: IconThemeData(color: theme.colorScheme.primary),
                title: AppbarName(
                    title: Language()
                        .getString(Constants.QUANTITY_ADJUSTMENT, selectedLang),
                    buName: "${widget.buName}"),
              ),
              bottomNavigationBar: Container(
                padding: EdgeInsets.symmetric(vertical: 20, horizontal: 10),
                child: CommonButtonsView(
                  context: context,
                  b1Text: (quantityAdjustmentList.length > 0)
                      ? Language().getString(Constants.STR_CANCEL, selectedLang)
                      : Language().getString(Constants.BACK, selectedLang),
                  b2Text: (quantityAdjustmentList.length > 0)
                      ? Language().getString(Constants.CONFIRM, selectedLang)
                      : "",
                  onb1Action: () {
                    Navigator.of(context).pop();
                  },
                  onb2Action: () async {
                    // Navigator.of(context).pop();
                    if (await NetworkStatus.getInternetStatus()) {
                      this.serviceCallQuantityAdjustment();
                    } else {
                      AppUtills.showSnackBar(
                          _scaffoldkey,
                          Language()
                              .getString(Constants.NO_INTERNET, selectedLang),
                          snackBarBgColor: Colors.black,
                          messageColor: Colors.white,
                          buttonColor: Colors.white);
                    }
                  },
                ),
              ),
              body: Container(
                padding: EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    showProductName(),
                    FxSpacing.height(10),
                    Container(
                      margin: EdgeInsets.symmetric(vertical: 10.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          buildTextField(Language().getString(
                              Constants.QUANTITY_ADJUSTMENT_C, selectedLang)),
                          addNewQuantityAdjustment()
                        ],
                      ),
                    ),
                    Expanded(
                      child: onCreateDynamicQuantityAdjustment(),
                    ),
                  ],
                ),
              )),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    ));
  }

  Widget onCreateDynamicQuantityAdjustment() {
    if (quantityAdjustmentList.length > 0) {
      return ListView.separated(
        shrinkWrap: true,
        controller: _scrollController,
        physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
        itemBuilder: (context, i) => Card(
            elevation: 2.5,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(5),
            ),
            child: QuantityAdjustExpanded(
                list: quantityAdjustmentList[i].quantityAdjustLocationsList,
                locationName: quantityAdjustmentList[i].locationName,
                strLocationName:
                    Language().getString(Constants.LOCATION_NAME, selectedLang),
                strBatchNumber:
                    Language().getString(Constants.BATCH_NO, selectedLang),
                strAdjustedQuantity: Language()
                    .getString(Constants.ADJUSTED_QUANTITY, selectedLang),
                strReason:
                    Language().getString(Constants.REASON, selectedLang))),
        itemCount: quantityAdjustmentList.length,
        separatorBuilder: (context, i) => Divider(
          height: 0.0,
          color: Colors.transparent,
        ),
      );
    } else {
      return Container();
    }
  }

  addNewQuantityAdjustment() {
    return SizedBox(
        height: 25.0,
        width: 25.0,
        child: FloatingActionButton(
          heroTag: "quantity_adjustment",
          onPressed: () {
            if (inventoryList.length > 0) {
              CommonMethods.hideKeyboard(context);
              buildQuantityAdjustmentFields(-1, false, QuantityAdjustmentDAO());
            } else {
              Dialogs.yesCancelDialog(
                  context,
                  Language().getString(Constants.ERROR, selectedLang),
                  Constants.YOU_HAVE_NO_INVENTIORY_LOCATIONS,
                  Language().getString(Constants.OKAY_STR, selectedLang),
                  "",
                  false);
            }
          },
          child: Icon(
            Icons.add,
            size: 15,
            color: Colors.white,
          ),
          backgroundColor: Color(0xFF083e64),
        ));
  }

  buildQuantityAdjustmentFields(
      int index, bool isUpdate, QuantityAdjustmentDAO quantityModel) {
    if (isUpdate) {
      quantityAdjustmentBatchDropdown = null;
      quantityAdjustmentLocationDropdown = null;
      _locationBatchesInQuantityAdjustment.clear();
      for (int i = 0; i < inventoryList.length; i++) {
        for (int k = 0; k < inventoryList[i].locationBatchList!.length; k++) {
          if (quantityModel.quantityAdjustLocationsList![0].batchNumber ==
              inventoryList[i].locationBatchList![k].batchNumber) {
            _locationBatchesInQuantityAdjustment
                .addAll(inventoryList[i].locationBatchList!);
            quantityAdjustmentBatchDropdown =
                inventoryList[i].locationBatchList![k];
            remainingAdjustmentQuantity =
                inventoryList[i].locationBatchList![k].quantity;
          }
        }
      }

      for (int j = 0; j < inventoryList.length; j++) {
        // for (var q = 0; q < inventoryList[j].locationBatchList.length; q++) {
        if (quantityModel.locationName == inventoryList[j].locationName) {
          quantityAdjustmentLocationDropdown = inventoryList[j];
        }
        // }
      }
      adjustmentReasonDropdownValue = quantityModel.reason;
      updatedCurrentDateTime = quantityModel.updatedDate;
      // _locationQuantityController.text = quantityModel.quantity.toString();
    } else {
      this.clearQuantityAdjustData();
    }

    return showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => Container(
            decoration: BoxDecoration(
                borderRadius: BorderRadius.all(
                  Radius.circular(10.0),
                ),
                color: Colors.white),
            margin: EdgeInsets.symmetric(horizontal: 10.0, vertical: 20.0),
            child: StatefulBuilder(
                builder: (context, StateSetter setState) => Scaffold(
                    backgroundColor: Colors.transparent,
                    bottomNavigationBar: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 20),
                      child: CommonButtonsView(
                        context: context,
                        b1Text: Language()
                            .getString(Constants.STR_CANCEL, selectedLang),
                        b2Text: (isUpdate)
                            ? Language().getString(
                                Constants.UPDATE_STRING, selectedLang)
                            : Language()
                                .getString(Constants.CONTINUE, selectedLang),
                        onb1Action: () {
                          this.clearQuantityAdjustData();
                          Navigator.of(context).pop();
                        },
                        onb2Action: () async {
                          String errorMessage = validateAdjustmentFields();

                          if (errorMessage.isNotEmpty) {
                            Dialogs.yesCancelDialog(
                                context,
                                Language()
                                    .getString(Constants.ERROR, selectedLang),
                                Language()
                                    .getString(errorMessage, selectedLang),
                                Language().getString(
                                    Constants.OKAY_STR, selectedLang),
                                "",
                                false);
                          } else {
                            final action = await Dialogs.yesCancelDialog(
                                context,
                                Language()
                                    .getString(Constants.INFO, selectedLang),
                                Language().getString(
                                        Constants.QUANTITY_ADJUSTMENT_INFO,
                                        selectedLang) +
                                    "\"${quantityAdjustmentLocationDropdown!.locationName}\"",
                                Language().getString(
                                    Constants.YES_STRING, selectedLang),
                                Language().getString(
                                    Constants.NO_STRING, selectedLang),
                                true);

                            if (action == DialogAction.yes) {
                              this.saveQuantityAdjustmentValues(
                                  isUpdate, index, setState);
                            }
                          }
                        },
                      ),
                    ),
                    body: SingleChildScrollView(
                      child: Container(
                        margin: EdgeInsets.symmetric(
                            vertical: 10.0, horizontal: 10.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            new Text(
                                Language().getString(
                                    Constants.QUANTITY_ADJUSTMENT,
                                    selectedLang),
                                style: TextStyle(
                                    fontSize: StyleView.FONT_SIZE_15,
                                    fontWeight: StyleView.fontSemiBold,
                                    color: theme.colorScheme.primary)),
                            SizedBox(height: 5.0),
                            Padding(
                              padding: const EdgeInsets.only(top: 20),
                              child: new Text(
                                  Language().getString(
                                      Constants.LOCATION, selectedLang),
                                  style: TextStyle(
                                      fontSize: StyleView.FONT_SIZE_15,
                                      fontWeight: StyleView.fontSemiBold,
                                      color: theme.colorScheme.primary)),
                            ),
                            SizedBox(height: 5.0),
                            (isUpdate)
                                ? Container(
                                    decoration: AppUtills.boxDecoration(),
                                    child: TextView(
                                        title: Language().getString(
                                            Constants.LOCATION_NAME,
                                            selectedLang),
                                        value: quantityModel.locationName),
                                  )
                                : this.inventoryLocationsInQuantityAdjustment(
                                    setState), //this.inventoryLocations(setState),

                            if (quantityAdjustmentLocationDropdown != null)
                              Container(
                                margin: EdgeInsets.symmetric(vertical: 5.0),
                                child:
                                    showQuantityAdjustmentLocationBatchNumbers(
                                        quantityModel.locationName),
                              ),

                            Container(
                                child: Padding(
                              padding: const EdgeInsets.only(top: 20),
                              child: Row(
                                children: <Widget>[
                                  new Text(
                                      Language().getString(
                                          Constants.BATCH_NO, selectedLang),
                                      style: TextStyle(
                                          fontSize: StyleView.FONT_SIZE_15,
                                          fontWeight: StyleView.fontSemiBold,
                                          color: theme.colorScheme.primary)),
                                  SizedBox(width: 3.0),
                                  (quantityAdjustmentBatchDropdown != null)
                                      ? Container(
                                          padding: EdgeInsets.only(left: 20),
                                          child: Text(
                                              Language().getString(
                                                      Constants
                                                          .TOTAL_QUANTITY_STRING,
                                                      selectedLang) +
                                                  " : $remainingAdjustmentQuantity",
                                              style: TextStyle(
                                                  fontSize: 12.0,
                                                  fontWeight:
                                                      StyleView.fontSemiBold,
                                                  color: Colors.green)),
                                        )
                                      : Container()
                                ],
                              ),
                            )),

                            this.showLocationBatchesInQuantityAdjustment(
                                setState),
                            // this.inventoryBatchQuantity(setState,
                            //     isFromQuantityAdjustment: true),
                            if (quantityAdjustmentBatchDropdown != null)
                              Container(
                                  margin: EdgeInsets.only(top: 5.0),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        flex: 2,
                                        child: Text(
                                          Language().getString(
                                              Constants
                                                  .TOTAL_AVALABILE_QUANTITY_FOR_BATCH,
                                              selectedLang),
                                          style: TextStyle(
                                              fontSize: 12.0,
                                              fontWeight:
                                                  StyleView.fontSemiBold,
                                              color: theme.colorScheme.primary),
                                        ),
                                      ),
                                      // Expanded(
                                      //   child: Text("  : ",
                                      //       style: TextStyle(
                                      //           fontSize: 13.0,
                                      //           color:
                                      //               Color(Constants.APP_COLOR),
                                      //           fontWeight: FontWeight.w600)),
                                      // ),
                                      Expanded(
                                        child: Text(
                                          " :   ${quantityAdjustmentBatchDropdown!.quantity} ${quantityAdjustmentBatchDropdown!.quantityIn}",
                                          style: TextStyle(
                                              fontSize: 12.0,
                                              fontWeight:
                                                  StyleView.fontSemiBold,
                                              color: theme.colorScheme.primary),
                                        ),
                                      ),
                                    ],
                                  )),
                            // (quantityAdjustmentBatchDropdown != null)
                            //     ? this.showRemainingInventoryAdjustQuantity(
                            //         quantityModel, index, isUpdate)
                            //     : Container(),
                            if (quantityAdjustmentBatchDropdown != null)
                              showQuantityAdjustmentBatchPricingDetails(
                                  quantityModel, index, isUpdate),

                            Container(
                              padding: EdgeInsets.only(top: 20.0),
                              child: new Text(
                                  Language().getString(
                                      Constants.REASON, selectedLang),
                                  style: TextStyle(
                                      fontSize: StyleView.FONT_SIZE_15,
                                      fontWeight: StyleView.fontSemiBold,
                                      color: theme.colorScheme.primary)),
                            ),
                            SizedBox(height: 5.0),
                            adjustmentQuantityReasonDropdown(setState),
                            Padding(
                              padding: const EdgeInsets.only(top: 10),
                              child: new Text(
                                  Language().getString(
                                      Constants.QUANTITY, selectedLang),
                                  style: TextStyle(
                                      fontSize: StyleView.FONT_SIZE_15,
                                      fontWeight: StyleView.fontSemiBold,
                                      color: theme.colorScheme.primary)),
                            ),
                            SizedBox(height: 10.0),
                            SizedBox(
                                height: 70,
                                child: new TextFormField(
                                  keyboardType: (defaultTargetPlatform ==
                                          TargetPlatform.iOS)
                                      ? TextInputType.numberWithOptions(
                                          signed: true)
                                      : TextInputType.number,
                                  textInputAction: TextInputAction.done,
                                  style: TextStyle(
                                      fontFamily: StyleView.FONT_TITLE),
                                  controller: _quantityAdjutmentController,
                                  decoration: StyleView.getInputDecoration(
                                      helper: Language().getString(
                                          Constants.ENTER_QUANTITY,
                                          selectedLang)),
                                  inputFormatters: [
                                    new LengthLimitingTextInputFormatter(6),
                                    CommonMethods.inputTextFormatter(
                                        isNumber: true)
                                  ],
                                  onChanged: (value) {
                                    if (value.isNotEmpty) {
                                      if (isUpdate &&
                                          double.parse(
                                                  remainingBatchQuantity) !=
                                              0) {
                                        if (double.parse(remainingBatchQuantity
                                                .toString()) <
                                            double.parse(
                                                _quantityAdjutmentController
                                                    .text)) {
                                          _quantityAdjutmentController.clear();
                                          Dialogs.yesCancelDialog(
                                              context,
                                              Language().getString(
                                                  Constants.WARNING,
                                                  selectedLang),
                                              Constants
                                                  .QUANTITY_SHOULD_NOT_MORETHAN_AVAIL_,
                                              Language().getString(
                                                  Constants.OKAY_STR,
                                                  selectedLang),
                                              "",
                                              false);
                                        }
                                      } else {
                                        if (double.parse(
                                                _quantityAdjutmentController
                                                    .text) >
                                            quantityAdjustmentBatchDropdown!
                                                .quantity!) {
                                          _quantityAdjutmentController.clear();
                                          Dialogs.yesCancelDialog(
                                              context,
                                              Language().getString(
                                                  Constants.WARNING,
                                                  selectedLang),
                                              Constants
                                                  .QUANTITY_SHOULD_NOT_MORETHAN_AVAIL_,
                                              Language().getString(
                                                  Constants.OKAY_STR,
                                                  selectedLang),
                                              "",
                                              false);
                                        }
                                      }
                                    }
                                  },
                                )),
                          ],
                        ),
                      ),
                    )))));
  }

  Widget adjustmentQuantityReasonDropdown(StateSetter setState) {
    return Container(
      margin: EdgeInsets.symmetric(
        vertical: 5.0,
      ),
      decoration: AppUtills.boxDecoration(),
      padding: EdgeInsets.all(1),
      child: Container(
        color: Colors.white70,
        padding: EdgeInsets.only(left: 5, right: 5),
        child: DropdownButton<String>(
          onTap: () {
            FocusScope.of(context).requestFocus(
                new FocusNode()); //CommonMethods.hideKeyboard(context);
          },
          isExpanded: true,
          hint: Text(Language().getString(Constants.REASON, selectedLang)),
          underline: SizedBox(),
          items: Constants.adjustmentReasonList.map((String reason) {
            return DropdownMenuItem<String>(
              value: reason,
              child: new Text(
                reason,
                style: TextStyle(fontFamily: StyleView.FONT_TITLE),
              ),
            );
          }).toList(),
          value: adjustmentReasonDropdownValue,
          onChanged: (String? model) {
            setState(() {
              adjustmentReasonDropdownValue = model;
            });
          },
        ),
      ),
    );
  }

  buildTextField(String _text) {
    return Row(
      children: <Widget>[
        Align(
            child: Text(_text,
                style: TextStyle(
                    fontFamily: StyleView.FONT_TITLE,
                    fontWeight: FontWeight.bold,
                    color: Color(Constants.APP_COLOR),
                    fontSize: StyleView.FONT_SIZE_15)))
      ],
    );
  }

  Widget showLocationBatchesInQuantityAdjustment(StateSetter setState) {
    return Container(
      margin: EdgeInsets.symmetric(
        vertical: 5.0,
      ),
      decoration: AppUtills.boxDecoration(),
      padding: EdgeInsets.all(1),
      child: Container(
        color: Colors.white70,
        padding: EdgeInsets.only(left: 5, right: 5),
        child: DropdownButton<InventoryDetailsDAO>(
          onTap: () {
            CommonMethods.hideKeyboard(context);
          },
          isExpanded: true,
          hint: Text(Language().getString(Constants.BATCH_NO, selectedLang)),
          underline: SizedBox(),
          items: _locationBatchesInQuantityAdjustment
              .map((InventoryDetailsDAO batchPrice) {
            return DropdownMenuItem<InventoryDetailsDAO>(
              value: batchPrice,
              child: new Text(
                batchPrice.batchNumber!,
                style: TextStyle(fontFamily: StyleView.FONT_TITLE),
              ),
            );
          }).toList(),
          value: quantityAdjustmentBatchDropdown,
          onChanged: (InventoryDetailsDAO? model) {
            setState(() {
              quantityAdjustmentBatchDropdown = model;
              remainingAdjustmentQuantity = model!.quantity;
            });
          },
        ),
      ),
    );
  }

  Widget inventoryLocationsInQuantityAdjustment(StateSetter setState) {
    return Container(
        margin: EdgeInsets.symmetric(
          vertical: 5.0,
        ),
        decoration: AppUtills.boxDecoration(),
        padding: EdgeInsets.all(1),
        child: Container(
            color: Colors.white70,
            padding: EdgeInsets.only(left: 5, right: 5),
            child: DropdownButton<InventoryManagementModel>(
                onTap: () {
                  FocusScope.of(context).requestFocus(
                      new FocusNode()); //CommonMethods.hideKeyboard(context);
                },
                isExpanded: true,
                hint: Text(
                    Language().getString(Constants.LOCATION, selectedLang)),
                underline: SizedBox(),
                items:
                    inventoryList.map((InventoryManagementModel locationData) {
                  return DropdownMenuItem<InventoryManagementModel>(
                    value: locationData,
                    child: new Text(
                      locationData.locationName!,
                      style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                    ),
                  );
                }).toList(),
                value: quantityAdjustmentLocationDropdown,
                onChanged: (InventoryManagementModel? location) {
                  setState(() {
                    _locationBatchesInQuantityAdjustment.clear();
                    quantityAdjustmentBatchDropdown = null;
                    quantityAdjustmentLocationDropdown = location;
                    _locationBatchesInQuantityAdjustment.addAll(
                        quantityAdjustmentLocationDropdown!.locationBatchList!);
                  });
                })));
  }

  showQuantityAdjustmentBatchPricingDetails(
      QuantityAdjustmentDAO _adjustmentModel,
      int index,
      bool isUpdateInventory) {
    if (quantityAdjustmentList.length > 0 &&
        quantityAdjustmentBatchDropdown != null) {
      bool isExist = false;

      for (int i = 0; i < quantityAdjustmentList.length; i++) {
        for (int j = 0;
            j < quantityAdjustmentList[i].quantityAdjustLocationsList!.length;
            j++) {
          if (quantityAdjustmentBatchDropdown!.batchNumber ==
              quantityAdjustmentList[i]
                  .quantityAdjustLocationsList![j]
                  .batchNumber) {
            isExist = true;
          }
        }
      }
      if (isExist) {
        return Container(
          margin: EdgeInsets.only(top: 10.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                child: Text(
                  Constants.BATCH_DETAILS_AT_DIFF_LOCATIONS,
                  style: TextStyle(
                      fontWeight: FontWeight.w600,
                      color: theme.colorScheme.primary),
                ),
              ),
              InventoryLocationBatchView(
                isFromQuantityAdjustment: true,
                quantityAdjustmentList: quantityAdjustmentList,
                batchNumber: quantityAdjustmentBatchDropdown!.batchNumber,
                batchList: [],
                locationsList: [],
                strBatchNumber:
                    Language().getString(Constants.BATCH_NO, selectedLang),
                strQuantity:
                    Language().getString(Constants.QUANTITY, selectedLang),
                strUpdatedBy:
                    Language().getString(Constants.UPDATED_BY, selectedLang),
                strUpdatedDate:
                    Language().getString(Constants.UPDATED_DATE, selectedLang),
                strAdjustedQuantity: Language()
                    .getString(Constants.ADJUSTED_QUANTITY, selectedLang),
                strReason: Language().getString(Constants.REASON, selectedLang),
              )
            ],
          ),
        );
      } else {
        return SizedBox();
      }
    } else {
      return Container();
    }
  }

  showQuantityAdjustmentLocationBatchNumbers(String? locationName) {
    for (int i = 0; i < quantityAdjustmentList.length; i++) {
      if (locationName == quantityAdjustmentList[i].locationName) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              child: Text(
                  Language()
                      .getString(Constants.BATCHES_IN_LOCATIONS, selectedLang),
                  style: TextStyle(
                      color: Color(Constants.APP_COLOR),
                      fontWeight: FontWeight.w600)),
            ),
            InventoryLocationBatchView(
              isShowLocationDetails: true,
              locationsList:
                  quantityAdjustmentList[i].quantityAdjustLocationsList,
              strBatchNumber:
                  Language().getString(Constants.BATCH_NO, selectedLang),
              strQuantity:
                  Language().getString(Constants.QUANTITY, selectedLang),
              strUpdatedBy:
                  Language().getString(Constants.UPDATED_BY, selectedLang),
              strUpdatedDate:
                  Language().getString(Constants.UPDATED_DATE, selectedLang),
              strAdjustedQuantity: Language()
                  .getString(Constants.ADJUSTED_QUANTITY, selectedLang),
              strReason: Language().getString(Constants.REASON, selectedLang),
            )
          ],
        );
      }
    }
  }

  Widget showRemainingInventoryAdjustQuantity(
      QuantityAdjustmentDAO inventoryDropdownQuantity,
      int index,
      bool isUpdateInventory) {
    num inventoryTotalQuantity = 0;
    if (quantityAdjustmentBatchDropdown != null) {
      if (isUpdateInventory) {
        for (int j = 0; j < quantityAdjustmentList.length; j++) {
          for (int i = 0;
              i < quantityAdjustmentList[j].quantityAdjustLocationsList!.length;
              i++) {
            if (quantityAdjustmentBatchDropdown!.batchNumber ==
                quantityAdjustmentList[j]
                    .quantityAdjustLocationsList![i]
                    .batchNumber) {
              inventoryTotalQuantity = inventoryTotalQuantity +
                  quantityAdjustmentList[j]
                      .quantityAdjustLocationsList![i]
                      .quantity!;
            }
          }
        }
      } else {
        for (int j = 0; j < quantityAdjustmentList.length; j++) {
          for (int i = 0;
              i < quantityAdjustmentList[j].quantityAdjustLocationsList!.length;
              i++) {
            if (quantityAdjustmentBatchDropdown!.batchNumber ==
                quantityAdjustmentList[j]
                    .quantityAdjustLocationsList![i]
                    .batchNumber) {
              inventoryTotalQuantity = inventoryTotalQuantity +
                  quantityAdjustmentList[j]
                      .quantityAdjustLocationsList![i]
                      .quantity!;
            }
          }
        }
      }

      remainingBatchQuantity =
          quantityAdjustmentBatchDropdown!.quantity.toString();
      // (quantityAdjustmentBatchDropdown.quantity - inventoryTotalQuantity)
      //     .toString();

      // _quantityAdjutmentController.text = remainingBatchQuantity;
      return Container(
          margin: EdgeInsets.only(top: 5.0),
          child: Row(
            children: [
              Container(
                child: Text(
                  Language().getString(
                      Constants.QUANTITY_NOT_ASSIGNED_TO_LOCATION,
                      selectedLang),
                  style: TextStyle(
                      fontSize: 12.0,
                      color: Color(Constants.APP_COLOR),
                      fontWeight: FontWeight.bold),
                ),
              ),
              Text(
                "  : ",
                style: TextStyle(
                  fontSize: 13.0,
                  color: Color(Constants.APP_COLOR),
                ),
              ),
              Container(
                child: Text(
                  "$remainingBatchQuantity",
                  style: TextStyle(
                    fontSize: 12.0,
                    color: Color(Constants.APP_COLOR),
                  ),
                ),
              ),
            ],
          ));
    } else {
      return Container();
    }
  }

  String validateAdjustmentFields() {
    if (quantityAdjustmentLocationDropdown == null) {
      return Constants.PLEASE_SELECT_LOCATION;
    } else if (quantityAdjustmentBatchDropdown == null) {
      return Constants.PLEASE_SELECT_BATCH_NO;
    } else if (_quantityAdjutmentController.text.isEmpty) {
      return Constants.PLEASE_ENTER_QUANTITY;
    } else {
      return "";
    }
  }

  clearQuantityAdjustData() {
    setState(() {
      adjustmentReasonDropdownValue = null;
      _quantityAdjutmentController.clear();
      remainingAdjustmentQuantity = 0;
      quantityAdjustmentBatchDropdown = null;
      quantityAdjustmentLocationDropdown = null;
      _locationBatchesInQuantityAdjustment.clear();
    });
  }

  saveQuantityAdjustmentValues(bool isUpdate, int index, StateSetter setter) {
    if (isUpdate) {
      /**
       * If requested quantity is more than exist quantity
       */
      num enteredQuantity = double.parse(_quantityAdjutmentController.text);
      bool isLocationExist = false;
      if (quantityAdjustmentLocationDropdown!.locationName ==
          quantityAdjustmentList[index].locationName) {
        isLocationExist = true;
        if (quantityAdjustmentList[index].locationId == null ||
            quantityAdjustmentList[index].locationId!.isEmpty) {
          quantityAdjustmentList[index].locationId =
              quantityAdjustmentLocationDropdown!.locationId;
        }
      }

      if (isLocationExist) {
        bool isBatchExist = false;
        int existIndex = -1;
        for (var i = 0;
            i <
                quantityAdjustmentList[index]
                    .quantityAdjustLocationsList!
                    .length;
            i++) {
          if (quantityAdjustmentBatchDropdown!.batchNumber ==
              quantityAdjustmentList[index]
                  .quantityAdjustLocationsList![i]
                  .batchNumber) {
            isBatchExist = true;
            existIndex = i;
          }
        }

        if (isBatchExist) {
          num? existBatchQuantity = 0;
          existBatchQuantity = quantityAdjustmentList[index]
              .quantityAdjustLocationsList![existIndex]
              .quantity;

          quantityAdjustmentList[index]
              .quantityAdjustLocationsList![existIndex]
              .quantity = existBatchQuantity! + enteredQuantity;
          this.validatingSelectedBatchQuantity(setState);
          setter(() {
            quantityAdjustmentList.reversed;
            Navigator.of(context).pop();
          });
        } else {
          List<InventoryDetailsDAO> _addNewBatch =
              quantityAdjustmentList[index].quantityAdjustLocationsList!;

          _addNewBatch.add(InventoryDetailsDAO(
              batchNumber: quantityAdjustmentBatchDropdown!.batchNumber,
              quantity: enteredQuantity,
              quantityIn: quantityAdjustmentBatchDropdown!.quantityIn,
              quantityAdjustmentReason: adjustmentReasonDropdownValue != null
                  ? adjustmentReasonDropdownValue
                  : ""));

          quantityAdjustmentList[index] = QuantityAdjustmentDAO(
              locationName: quantityAdjustmentLocationDropdown!.locationName,
              locationId: quantityAdjustmentLocationDropdown!.locationId,
              batchNumber: quantityAdjustmentBatchDropdown!.batchNumber,
              reason: adjustmentReasonDropdownValue != null
                  ? adjustmentReasonDropdownValue
                  : "",
              updatedBy: userName,
              updatedDate: updatedCurrentDateTime,
              quantity: enteredQuantity,
              quantityAdjustLocationsList: _addNewBatch);
          this.validatingSelectedBatchQuantity(setState);
          setter(() {
            quantityAdjustmentList.reversed;
            Navigator.of(context).pop();
          });
        }
      } else {
        List<InventoryDetailsDAO> _addNewBatch = [];

        _addNewBatch.add(InventoryDetailsDAO(
            batchNumber: quantityAdjustmentBatchDropdown!.batchNumber,
            quantity: enteredQuantity,
            quantityIn: quantityAdjustmentBatchDropdown!.quantityIn,
            quantityAdjustmentReason: adjustmentReasonDropdownValue != null
                ? adjustmentReasonDropdownValue
                : ""));

        quantityAdjustmentList[index] = QuantityAdjustmentDAO(
            locationName: quantityAdjustmentLocationDropdown!.locationName,
            locationId: quantityAdjustmentLocationDropdown!.locationId,
            batchNumber: quantityAdjustmentBatchDropdown!.batchNumber,
            reason: adjustmentReasonDropdownValue != null
                ? adjustmentReasonDropdownValue
                : "",
            updatedBy: userName,
            updatedDate: updatedCurrentDateTime,
            quantity: enteredQuantity + quantityAdjustmentList[index].quantity!,
            quantityAdjustLocationsList: _addNewBatch);
        this.validatingSelectedBatchQuantity(setState);
        setter(() {
          quantityAdjustmentList.reversed;
          Navigator.of(context).pop();
        });
      }
    } else {
      // this.validatingSelectedBatchQuantity(setState);
      num enteredQuantity = double.parse(_quantityAdjutmentController.text);
      bool isLocationExist = false;
      int existIndex = -1;

      for (int i = 0; i < quantityAdjustmentList.length; i++) {
        for (int j = 0;
            j < quantityAdjustmentList[i].quantityAdjustLocationsList!.length;
            j++) {
          if (quantityAdjustmentLocationDropdown!.locationName ==
              quantityAdjustmentList[i].locationName) {
            isLocationExist = true;
            existIndex = i;
            if (quantityAdjustmentList[i].locationId == null ||
                quantityAdjustmentList[i].locationId!.isEmpty) {
              quantityAdjustmentList[i].locationId =
                  quantityAdjustmentLocationDropdown!.locationId;
            }
          }
        }
      }

      if (isLocationExist) {
        bool isBatchExist = false;
        int index = -1;
        for (var i = 0;
            i <
                quantityAdjustmentList[existIndex]
                    .quantityAdjustLocationsList!
                    .length;
            i++) {
          if (quantityAdjustmentBatchDropdown!.batchNumber ==
              quantityAdjustmentList[existIndex]
                  .quantityAdjustLocationsList![i]
                  .batchNumber) {
            isBatchExist = true;
            index = i;
          }
        }

        if (isBatchExist) {
          num? existBatchQuantity = 0;
          existBatchQuantity = quantityAdjustmentList[existIndex]
              .quantityAdjustLocationsList![index]
              .quantity;

          quantityAdjustmentList[existIndex]
              .quantityAdjustLocationsList![index]
              .quantity = existBatchQuantity! + enteredQuantity;
          this.validatingSelectedBatchQuantity(setState);
          setter(() {
            quantityAdjustmentList.reversed;
            Navigator.of(context).pop();
          });
        } else {
          List<InventoryDetailsDAO> _addNewBatch =
              quantityAdjustmentList[existIndex].quantityAdjustLocationsList!;

          _addNewBatch.add(InventoryDetailsDAO(
              batchNumber: quantityAdjustmentBatchDropdown!.batchNumber,
              quantity: enteredQuantity,
              quantityIn: quantityAdjustmentBatchDropdown!.quantityIn,
              quantityAdjustmentReason: adjustmentReasonDropdownValue != null
                  ? adjustmentReasonDropdownValue
                  : ""));

          quantityAdjustmentList[existIndex] = QuantityAdjustmentDAO(
              locationName: quantityAdjustmentLocationDropdown!.locationName,
              locationId: quantityAdjustmentLocationDropdown!.locationId,
              batchNumber: quantityAdjustmentBatchDropdown!.batchNumber,
              reason: adjustmentReasonDropdownValue != null
                  ? adjustmentReasonDropdownValue
                  : "",
              updatedBy: userName,
              updatedDate: updatedCurrentDateTime,
              quantity: enteredQuantity,
              quantityAdjustLocationsList: _addNewBatch);
          this.validatingSelectedBatchQuantity(setState);
          setter(() {
            quantityAdjustmentList.reversed;
            Navigator.of(context).pop();
          });
        }
      } else {
        List<InventoryDetailsDAO> _addNewBatch = [];

        _addNewBatch.add(InventoryDetailsDAO(
            batchNumber: quantityAdjustmentBatchDropdown!.batchNumber,
            quantity: double.parse(_quantityAdjutmentController.text),
            quantityIn: quantityAdjustmentBatchDropdown!.quantityIn,
            quantityAdjustmentReason: adjustmentReasonDropdownValue != null
                ? adjustmentReasonDropdownValue
                : ""));
        quantityAdjustmentList.add(
          QuantityAdjustmentDAO(
              locationName: quantityAdjustmentLocationDropdown!.locationName,
              locationId: quantityAdjustmentLocationDropdown!.locationId,
              batchNumber: quantityAdjustmentBatchDropdown!.batchNumber,
              reason: adjustmentReasonDropdownValue != null
                  ? adjustmentReasonDropdownValue
                  : "",
              updatedBy: userName,
              updatedDate: updatedCurrentDateTime,
              quantity: double.parse(_quantityAdjutmentController.text),
              quantityAdjustLocationsList: _addNewBatch),
        );
        this.validatingSelectedBatchQuantity(setState);
        setter(() {
          quantityAdjustmentList.reversed;
          Navigator.of(context).pop();
        });
      }
    }
  }

  validatingSelectedBatchQuantity(setState) {
    num enteredQuantity = double.parse(_quantityAdjutmentController.text);

    for (int j = 0; j < inventoryList.length; j++) {
      if (quantityAdjustmentLocationDropdown!.locationName ==
          inventoryList[j].locationName) {
        for (int k = 0; k < inventoryList[j].locationBatchList!.length; k++) {
          if (quantityAdjustmentBatchDropdown!.batchNumber ==
              inventoryList[j].locationBatchList![k].batchNumber) {
            setState(() {
              inventoryList[j].locationBatchList![k].quantity =
                  (inventoryList[j].locationBatchList![k].quantity! -
                      enteredQuantity);
            });
          }
        }
      }
    }
  }

  Widget showProductName() {
    return Row(
      children: [
        Container(
          child: Text(
            Language().getString(Constants.PRODUCT_NAME, selectedLang),
            style: TextStyle(
                fontSize: 15.0,
                fontWeight: FontWeight.bold,
                color: Color(Constants.APP_COLOR)),
          ),
        ),
        Text("  : "),
        Expanded(
          child: Container(
            child: Text(
              "${widget.productName}",
              style: TextStyle(color: Color(Constants.APP_COLOR)),
            ),
          ),
        ),
      ],
    );
  }

  Future<List<InventoryDetailsDAO>> getProuctById() async {
    responseInventoryData.clear();
    inventoryList.clear();

    String body = json.encode({"id": widget.productId, "buId": widget.buId});

    var response = await _productService
        .getProductDetailsByProductId_grpc(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          "$onError",
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<InventoryDetailsDAO> data = [];

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(resObj)) {
        for (var i in resObj[0]['inventory_management']) {
          data.add(InventoryDetailsDAO.fromJson(i));
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    return data;
  }

  Future<List<BuProductModal>> getProuctById_v1() async {
    responseInventoryData.clear();
    inventoryList.clear();

    String body = json.encode({"id": widget.productId, "buId": widget.buId});

    var response = await _productService
        .getProductDetailsByProductId_grpc(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          "$onError",
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    // List<InventoryDetailsDAO> data = [];
    List<BuProductModal> product_details = [];

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(resObj)) {
        product_details.add(BuProductModal.fromJson(resObj[0]));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    return product_details;
  }

  serviceCallQuantityAdjustment() async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = Constants.UPDATING;
    });

    for (int i = 0; i < quantityAdjustmentList.length; i++) {
      Map data = {
        "bu": widget.buId,
        "product_id": widget.productId,
        "location_id": quantityAdjustmentList[i].locationId,
        "reason": quantityAdjustmentList[i].reason,
        "updated_by": quantityAdjustmentList[i].updatedBy,
        "updated_date": quantityAdjustmentList[i].updatedDate,
      };

      List<Map<String, dynamic>> inventoryBatchListQuantityAdjust = [];
      var inventoryBatchObjectQuantityAdjust;
      for (int j = 0;
          j < quantityAdjustmentList[i].quantityAdjustLocationsList!.length;
          j++) {
        inventoryBatchObjectQuantityAdjust = {
          "batch_number": quantityAdjustmentList[i]
              .quantityAdjustLocationsList![j]
              .batchNumber,
          "quantity": quantityAdjustmentList[i]
              .quantityAdjustLocationsList![j]
              .quantity,
          "quantity_in": quantityAdjustmentList[i]
              .quantityAdjustLocationsList![j]
              .quantityIn
        };
        inventoryBatchListQuantityAdjust
            .add(inventoryBatchObjectQuantityAdjust);
      }
      data['location_batch_list'] = inventoryBatchListQuantityAdjust;

      String body = json.encode(data);
      var response = await _productService
          .grpcProductQuantityAdjustment(
              body: body, token: AppController.instance.getAuthorizationKey)
          .catchError((onError) async {
        await Dialogs.yesCancelDialog(
            context,
            Language().getString(Constants.ERROR, selectedLang),
            onError.toString(),
            Language().getString(Constants.OKAY_STR, selectedLang),
            "",
            false);
      });

      setState(() {
        isLoadingProgress = false;
      });
      GRPCResponse _grpcResponse = response;
      if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
        if (i == quantityAdjustmentList.length - 1) {
          final action = await Dialogs.yesCancelDialog(
              context,
              Language().getString(Constants.SUCCESS, selectedLang),
              Language().getString(
                  Constants.QUANTITY_ADJUSTED_SUCCESSFULLY, selectedLang),
              Language().getString(Constants.OKAY_STR, selectedLang),
              "",
              false);

          if (action == DialogAction.yes) {
            // Navigator.of(context).pop();
            if (widget.isFromRawMaterial!) {
              Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                      builder: (context) => RawProductsListPage()),
                  (route) => false);
            } else {
              Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (context) => ProductsMenuPage()),
                  (route) => false);
            }
          }
        }
      } else {
        Dialogs.yesCancelDialog(
            context,
            Language().getString(Constants.ERROR, selectedLang),
            _grpcResponse.message,
            Language().getString(Constants.OKAY_STR, selectedLang),
            "",
            false);
      }
    }
  }
}
