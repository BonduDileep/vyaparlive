import 'package:vyaparlive/theme/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/model/product_model/InventoryDetailsDAO.dart';

import 'package:vyaparlive/model/product_model/QuantityAdjustmentDAO.dart';

class QuantityAdjustExpanded extends StatelessWidget {
  final bool isEdit;
  final QuantityAdjustmentDAO? quantityModel;
  final VoidCallback? editPage;
  final VoidCallback? removeItem;
  final List<InventoryDetailsDAO>? list;
  final String? locationName;
  final String? strLocationName;
  final String? strBatchNumber;
  final String? strAdjustedQuantity;
  final String? strReason;

  QuantityAdjustExpanded({
    this.editPage,
    this.isEdit = false,
    this.quantityModel,
    this.removeItem,
    this.list,
    this.locationName,
    required this.strAdjustedQuantity,
    required this.strBatchNumber,
    required this.strLocationName,
    required this.strReason,
  });
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              margin: EdgeInsets.symmetric(vertical: 10.0),
              child: Row(
                children: [
                  Container(
                    child: Text(
                      strLocationName!,
                      style: TextStyle(
                          color: AppTheme.vyaparTheme.colorScheme.primary,
                          fontSize: 15.0,
                          fontWeight: StyleView.fontSemiBold),
                    ),
                  ),
                  Text(" : "),
                  Expanded(
                      child: Container(
                    child: Text(
                      "$locationName",
                      style: TextStyle(
                          color: Color(Constants.APP_COLOR),
                          fontSize: 15.0,
                          fontWeight: FontWeight.w300),
                    ),
                  ))
                ],
              ),
            ),
            Table(
              border: TableBorder.all(color: Colors.black),
              // defaultColumnWidth: FixedColumnWidth(110),
              children: [
                TableRow(children: [
                  Center(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        child: Text(
                          strBatchNumber!,
                          style: TextStyle(
                              color: AppTheme.vyaparTheme.colorScheme.primary,
                              fontWeight: StyleView.fontSemiBold,
                              fontSize: 13.0),
                        ),
                      ),
                    ),
                  ),
                  Center(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        child: Text(
                          strAdjustedQuantity!,
                          style: TextStyle(
                              color: AppTheme.vyaparTheme.colorScheme.primary,
                              fontWeight: StyleView.fontSemiBold,
                              fontSize: 13.0),
                        ),
                      ),
                    ),
                  ),
                  Center(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        child: Text(
                          strReason!,
                          style: TextStyle(
                              color: AppTheme.vyaparTheme.colorScheme.primary,
                              fontWeight: StyleView.fontSemiBold,
                              fontSize: 13.0),
                        ),
                      ),
                    ),
                  )
                ]),
                for (int i = 0; i < list!.length; i++)
                  TableRow(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                          child: Text("${list![i].batchNumber}",
                              textAlign: TextAlign.start,
                              style: TextStyle(
                                  fontSize: 13.0,
                                  color: Color(Constants.APP_COLOR))),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                          child: Text(
                              "${list![i].quantity} ${list![i].quantityIn}",
                              textAlign: TextAlign.start,
                              style: TextStyle(
                                  fontSize: 13.0,
                                  color: Color(Constants.APP_COLOR))),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                          child: Text("${list![i].quantityAdjustmentReason}",
                              textAlign: TextAlign.start,
                              style: TextStyle(
                                  fontSize: 13.0,
                                  color: Color(Constants.APP_COLOR))),
                        ),
                      )
                    ],
                  )
              ],
            ),
          ],
        ),
      ),
    );
  }

  showTitleView(
    String title,
    String value,
  ) {
    return Container(
        child: RichText(
      text: TextSpan(
        children: <TextSpan>[
          TextSpan(
              text: title,
              style: TextStyle(
                  fontSize: 15.0,
                  fontFamily: StyleView.FONT_TITLE,
                  color: Colors.black,
                  fontWeight: FontWeight.bold)),
          TextSpan(
            text: " : $value",
            style: TextStyle(
              fontSize: 13.0,
              fontFamily: StyleView.FONT_TITLE,
              color: Colors.black,
            ),
          )
        ],
      ),
    ));
  }
}
