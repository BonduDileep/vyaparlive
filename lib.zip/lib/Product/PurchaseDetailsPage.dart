import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
// import 'package:date_p'
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/utills/CustomAlertDialog.dart';

import '../components/AppController.dart';

class PurchaseDetailsPage extends StatefulWidget {
  final purchaseDetails;
  PurchaseDetailsPage({this.purchaseDetails});
  @override
  _PurchaseDetailsPageState createState() => _PurchaseDetailsPageState();
}

class _PurchaseDetailsPageState extends State<PurchaseDetailsPage>
    with SingleTickerProviderStateMixin {
  final format = DateFormat("yyyy-MM-dd HH:mm");
  DateTime fromdate1 = DateTime.now();
  DateTime todate2 = DateTime.now();

  late AnimationController _animationController;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;

  @override
  void initState() {
    print("purchase Details widget");
    print(widget.purchaseDetails.id);
    print(widget.purchaseDetails.offers.offerName);
    super.initState();
    _animationController =
        AnimationController(vsync: this, duration: Duration(seconds: 2));

    Tween(begin: 50.0, end: 200.0).animate(_animationController)
      ..addStatusListener((state) {
        if (state == AnimationStatus.completed) {
        } else if (state == AnimationStatus.dismissed) {}
      })
      ..addListener(() {
        setState(() {});
      });
    _animationController.forward();
  }

  displayAlertMessage(alertmessage) {
    return showDialog(
        barrierDismissible: false,
        context: context,
        builder: (context) {
          return CustomAlertDialog(
            title: 'Error!',
            content: alertmessage,
            buttonText: Constants.OKAY_STR,
          );
        });
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  buildTableContent(String textName, textFormName) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 30,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(textName,
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: 'IndianRupee'))),
                  )),
            ),
            Expanded(
                child: Container(
                    height: 30,
                    color: Colors.white70,
                    padding: EdgeInsets.only(left: 5),
                    child: Container(
                      padding: EdgeInsets.only(left: 10),
                      child: Align(
                          alignment: Alignment.centerLeft,
                          child: Text(textFormName,
                              style: TextStyle(
                                  fontSize: StyleView.FONT_SIZE_15,
                                  fontFamily: 'IndianRupee',
                                  color: Colors.grey))),
                    ))),
          ],
        ));
  }

  buildTableListRowContent(String textName, textFormName) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Expanded(
              flex: 3,
              child: Container(
                  child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(textName,
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_15,
                            fontFamily: 'IndianRupee'))),
              )),
            ),
            Container(
              child: Text(':'),
            ),
            Expanded(
                flex: 5,
                child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5),
                  child: Text(
                    textFormName,
                  ),
                ))
          ],
        ));
  }

  @override
  Widget build(BuildContext context) {
    String imageData = widget.purchaseDetails.images
        .replaceFirst(RegExp(r'data:image/[^;]+;base64,'), '');
    return SafeArea(
      child: Scaffold(
          appBar: AppBar(
            title: Text(
              Language().getString(Constants.PURCHASE_DETAILS_STR, selectedLang),
            ),
            backgroundColor: Color(0xFF083e64),
          ),
          backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
          body: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 5.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Container(
                      width: MediaQuery.of(context).size.width,
                      padding: EdgeInsets.all(10.5),
                      margin: EdgeInsets.symmetric(vertical: 10.5),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(5),
                        boxShadow: [
                          new BoxShadow(
                            blurRadius: 5.0,
                          ),
                        ],
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Image.memory(
                            base64.decode(imageData),
                            width: 200,
                            height: 200,
                          ),
                          Text(
                            widget.purchaseDetails.name,
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: StyleView.FONT_TITLE,
                                fontWeight: FontWeight.bold),
                            textAlign: TextAlign.start,
                          ),
                        ],
                      )),
                  Container(
                      width: MediaQuery.of(context).size.width,
                      padding: EdgeInsets.all(10.5),
                      margin: EdgeInsets.symmetric(vertical: 10.5),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(5),
                        boxShadow: [
                          new BoxShadow(
                            blurRadius: 5.0,
                          ),
                        ],
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            Language().getString(
                                Constants.OFFER_DETAILS_STR, selectedLang),
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_20,
                                fontFamily: StyleView.FONT_TITLE,
                                fontWeight: FontWeight.bold),
                            textAlign: TextAlign.start,
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Row(
                            children: <Widget>[
                              Expanded(
                                child: Text(
                                  'Model Number',
                                  style: TextStyle(
                                      fontSize: StyleView.FONT_SIZE_15,
                                      fontFamily: StyleView.FONT_TITLE,
                                      fontWeight: FontWeight.bold),
                                  textAlign: TextAlign.start,
                                ),
                              ),
                              Expanded(
                                child: Text(
                                  ': ' +
                                      widget.purchaseDetails.manufactureDetails
                                          .modelNumber,
                                  style: TextStyle(
                                      fontSize: StyleView.FONT_SIZE_15,
                                      fontFamily: StyleView.FONT_TITLE,
                                      fontWeight: FontWeight.bold),
                                  textAlign: TextAlign.start,
                                ),
                              )
                            ],
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Row(
                            children: <Widget>[
                              Expanded(
                                child: Text(
                                  'Release Date',
                                  style: TextStyle(
                                      fontSize: StyleView.FONT_SIZE_15,
                                      fontFamily: StyleView.FONT_TITLE,
                                      fontWeight: FontWeight.bold),
                                  textAlign: TextAlign.start,
                                ),
                              ),
                              Expanded(
                                child: Text(
                                  ': ' +
                                      widget.purchaseDetails.manufactureDetails
                                          .releaseDate
                                          .toString(),
                                  style: TextStyle(
                                      fontSize: StyleView.FONT_SIZE_15,
                                      fontFamily: StyleView.FONT_TITLE,
                                      fontWeight: FontWeight.bold),
                                  textAlign: TextAlign.start,
                                ),
                              )
                            ],
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Row(
                            children: <Widget>[
                              Expanded(
                                child: Text(
                                  'Name',
                                  style: TextStyle(
                                      fontSize: StyleView.FONT_SIZE_15,
                                      fontFamily: StyleView.FONT_TITLE,
                                      fontWeight: FontWeight.bold),
                                  textAlign: TextAlign.start,
                                ),
                              ),
                              Expanded(
                                child: Text(
                                  ': ' +
                                      widget.purchaseDetails.manufactureDetails
                                          .name,
                                  style: TextStyle(
                                      fontSize: StyleView.FONT_SIZE_15,
                                      fontFamily: StyleView.FONT_TITLE,
                                      fontWeight: FontWeight.bold),
                                  textAlign: TextAlign.start,
                                ),
                              )
                            ],
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Row(
                            children: <Widget>[
                              Expanded(
                                child: Text(
                                  'Manufacturer Address',
                                  style: TextStyle(
                                      fontSize: StyleView.FONT_SIZE_15,
                                      fontFamily: StyleView.FONT_TITLE,
                                      fontWeight: FontWeight.bold),
                                  textAlign: TextAlign.start,
                                ),
                              ),
                              Expanded(
                                child: Text(
                                  ': ' +
                                      widget.purchaseDetails.manufactureDetails
                                          .manufacturerAddress,
                                  style: TextStyle(
                                      fontSize: StyleView.FONT_SIZE_15,
                                      fontFamily: StyleView.FONT_TITLE,
                                      fontWeight: FontWeight.bold),
                                  textAlign: TextAlign.start,
                                ),
                              )
                            ],
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Row(
                            children: <Widget>[
                              Expanded(
                                child: Text(
                                  'Start Date',
                                  style: TextStyle(
                                      fontSize: StyleView.FONT_SIZE_15,
                                      fontFamily: StyleView.FONT_TITLE,
                                      fontWeight: FontWeight.bold),
                                  textAlign: TextAlign.start,
                                ),
                              ),
                              Expanded(
                                child: Text(
                                  ': ' + widget.purchaseDetails.offers.startDate,
                                  style: TextStyle(
                                      fontSize: StyleView.FONT_SIZE_15,
                                      fontFamily: StyleView.FONT_TITLE,
                                      fontWeight: FontWeight.bold),
                                  textAlign: TextAlign.start,
                                ),
                              )
                            ],
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Row(
                            children: <Widget>[
                              Expanded(
                                child: Text(
                                  'End Date',
                                  style: TextStyle(
                                      fontSize: StyleView.FONT_SIZE_15,
                                      fontFamily: StyleView.FONT_TITLE,
                                      fontWeight: FontWeight.bold),
                                  textAlign: TextAlign.start,
                                ),
                              ),
                              Expanded(
                                child: Text(
                                  ': ' + widget.purchaseDetails.offers.endDate,
                                  style: TextStyle(
                                      fontSize: StyleView.FONT_SIZE_15,
                                      fontFamily: StyleView.FONT_TITLE,
                                      fontWeight: FontWeight.bold),
                                  textAlign: TextAlign.start,
                                ),
                              )
                            ],
                          )
                        ],
                      )),
                ],
              ))),
    );
  }
}
