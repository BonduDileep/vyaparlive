import 'package:flutter/material.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/TextView.dart';
import 'package:vyaparlive/model/RawInventory.dart';

class RawInventoryExpandedPage extends StatelessWidget {
  final String? title;
  final RawInventory? managementModel;

  RawInventoryExpandedPage({
    this.managementModel,
    this.title,
  });
  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          flex: 10,
          child: Container(
              decoration: AppUtills.boxDecoration(),
              child: ExpansionTile(
                title: Row(children: [
                  Expanded(
                    child: Text(
                      title!,
                      style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                    ),
                  ),
                ]),
                children: <Widget>[
                  _buildInventoryItem(managementModel!),
                ],
              )),
        ),
      ],
    );
  }

  _buildInventoryItem(RawInventory inventoryModel) {
    int? quantity = inventoryModel.quantity as int?;
    return Container(
        child: Container(
            padding: EdgeInsets.all(1),
            child: Column(
              children: <Widget>[
                SizedBox(
                    height: 1,
                    child: new Container(color: Color(Constants.GREY_COLOR))),
                TextView(
                  title: Constants.QUANTITY,
                  value: quantity.toString(),
                ),
                SizedBox(
                    height: 1,
                    child: new Container(color: Color(Constants.GREY_COLOR))),
                TextView(
                  title: Constants.BATCH_NO,
                  value:
                      '${inventoryModel.batchNumber != null ? inventoryModel.batchNumber : ""}',
                ),
              ],
            )));
  }
}
