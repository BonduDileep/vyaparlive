import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:custom_searchable_dropdown/custom_searchable_dropdown.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/ProductCategoryDAO.dart';
import 'package:vyaparlive/model/ProductSegmentDAO.dart';
import 'package:vyaparlive/model/ProductSubCategoryDAO.dart';
import 'package:http/http.dart' as http;
import 'package:vyaparlive/model/product_model/ProductSectorDAO.dart';
import 'dart:convert';
import 'package:vyaparlive/service/Service.dart';

import '../components/AppController.dart';

class CategorySearchPage extends StatefulWidget {
  final String? buName;
  CategorySearchPage({this.buName});

  @override
  _CategorySearchPageState createState() => _CategorySearchPageState();
}

class _CategorySearchPageState extends State<CategorySearchPage> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String buId = "";

  List<ProductSegmentDAO> segmentList = [];
  ProductSegmentDAO? segmentDropdownValue;
  List<ProductCategoryDAO> categoryList = [];
  ProductCategoryDAO? categoryDropdownValue;
  List<ProductSubCategoryDAO> subCategoryList = [];
  ProductSubCategoryDAO? subCategoryDropdownValue;
  late Service _service;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;

  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  List<ProductSectorDAO> productSectorList = [];
  ProductSectorDAO? productSectorDropdown;
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _service = Service();
    this.loadProductSectorData();
  }

  loadProductSectorData() async {
    if (await NetworkStatus.getInternetStatus()) {
      this.getProductSector().then((value) {
        setState(() {
          productSectorList.clear();
          productSectorList.addAll(value);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  loadPoductSegmentData(num? parentCode) async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
      });
      getProductSegments(parentCode: parentCode).then((value) {
        setState(() {
          segmentList.clear();
          segmentList.addAll(value);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
        body: Stack(
      children: [
        SafeArea(
          child: Scaffold(
            key: _scaffoldkey,
            backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
            appBar: AppBar(
              centerTitle: true,
              backgroundColor: Colors.transparent,
              elevation: 0, //Color(Constants.APP_COLOR),
              iconTheme: IconThemeData(color: theme.colorScheme.primary),
              title: AppbarName(
                  title: Language()
                      .getString(Constants.SEARCH_BY_CATEGORY, selectedLang),
                  buName: "${widget.buName}"),
              actions: [
                // AppUtills.homeButton(context),
              ],
            ),
            bottomNavigationBar: (productSectorList.length > 0)
                ? Container(
                    padding: EdgeInsets.symmetric(horizontal: 10.0, vertical: 20),
                    child: CommonButtonsView(
                      context: context,
                      b1Text: Language()
                          .getString(Constants.STR_CANCEL, selectedLang),
                      b2Text: Language()
                          .getString(Constants.SUBMIT_STRING, selectedLang),
                      onb1Action: () {
                        Navigator.pop(context);
                      },
                      onb2Action: () {
                        if (productSectorDropdown == null) {
                          Dialogs.yesCancelDialog(
                              context,
                              Language().getString(Constants.ERROR, selectedLang),
                              Language().getString(
                                  Constants.PLEASE_SELECT_PRODUCT_SECTOR,
                                  selectedLang),
                              Language()
                                  .getString(Constants.OKAY_STR, selectedLang),
                              "",
                              false);
                        } else {
                          Map<String, String?> parm = {
                            "product_sector": productSectorDropdown != null
                                ? productSectorDropdown!.sectorName
                                : "",
                            "product_segment": segmentDropdownValue != null
                                ? segmentDropdownValue!.type
                                : "",
                            "product_category": categoryDropdownValue != null
                                ? categoryDropdownValue!.type
                                : "",
                            "product_sub_category":
                                subCategoryDropdownValue != null
                                    ? subCategoryDropdownValue!.type
                                    : ""
                          };
          
                          Navigator.pop(context, parm);
                        }
                      },
                    ))
                : null,
            body: (productSectorList.length > 0)
                ? Container(
                    margin:
                        EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        this.productSectorView(),
                        // this.productSegmentView(),
                        this.productCategoryView(),
                        this.productSubCategoryView(),
                      ],
                    ),
                  )
                : Container(
                    child: Text(
                      Language().getString(Constants.NO_DATA_FOUND, selectedLang),
                    ),
                  ),
          ),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    ));
  }

  Widget productSegmentSearchView() {
    return Container(
        margin: EdgeInsets.symmetric(horizontal: 5.0, vertical: 10.0),
        decoration: AppUtills.boxDecoration(),
        child: CustomSearchableDropDown(
          items: segmentList.toList(),
          hint: Language().getString(Constants.SEARCH, selectedLang),
          dropdownHintText:
              Language().getString(Constants.SEARCH, selectedLang),
          label: Language().getString(Constants.SELECT_SEGMENT,
              selectedLang), //segmentDropdownValue!.type,
          labelStyle: TextStyle(
              fontWeight: StyleView.fontMedium,
              color: Colors.black,
              fontSize: 14.0),
          suffixIcon: Padding(
              padding: const EdgeInsets.all(0.0),
              child: Icon(
                Icons.keyboard_arrow_down_outlined,
                color: Colors.black,
              )),
          dropDownMenuItems: segmentList.map((item) {
            return item.type;
          }).toList(),
          onChanged: (value) {
            setState(() {
              // Navigator.pop(context);
              segmentDropdownValue = value;
            });
            loadProductCategories(segmentDropdownValue!.code);
          },
        ));
  }

  Widget productCategorySearchView() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 5.0, vertical: 10.0),
      decoration: AppUtills.boxDecoration(),
      child: CustomSearchableDropDown(
        items: categoryList.toList(),
        dropDownMenuItems: categoryList.map((item) {
          return item.type;
        }).toList(),
        labelStyle: TextStyle(
            fontWeight: StyleView.fontMedium,
            color: Colors.black,
            fontSize: 14.0),
        suffixIcon: Padding(
            padding: const EdgeInsets.all(0.0),
            child: Icon(Icons.keyboard_arrow_down_outlined)),
        label: Language().getString(Constants.SELECT_CATEGORY,
            selectedLang), //categoryDropdownValue!.type,
        hint: Language().getString(Constants.SEARCH, selectedLang),
        dropdownHintText: Language().getString(Constants.SEARCH, selectedLang),
        onChanged: (value) {
          setState(() {
            categoryDropdownValue = value;
          });
          loadProductSubCategory(categoryDropdownValue!.code);
        },
      ),
    );
  }

  Widget productSubCategorySearchView() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 5.0, vertical: 10.0),
      decoration: AppUtills.boxDecoration(),
      child: CustomSearchableDropDown(
        items: subCategoryList.toList(),
        dropDownMenuItems: subCategoryList.map((item) => item.type).toList(),
        labelStyle: TextStyle(
            fontWeight: StyleView.fontMedium,
            color: Colors.black,
            fontSize: 14.0),
        suffixIcon: Padding(
            padding: const EdgeInsets.all(0.0),
            child: Icon(Icons.keyboard_arrow_down_outlined)),
        label: Language().getString(Constants.SELECT_SUB_CATEGORY,
            selectedLang), // subCategoryDropdownValue!.type,
        hint: Language().getString(Constants.SEARCH, selectedLang),
        dropdownHintText: Language().getString(Constants.SEARCH, selectedLang),
        onChanged: (value) {
          setState(() {
            subCategoryDropdownValue = value;
          });
        },
      ),
    );
  }

  loadProductCategories(num? parentCode) async {
    if (await NetworkStatus.getInternetStatus()) {
      /// Service call get product category
      this.getProductCategories(parentCode!).then((value) {
        setState(() {
          categoryList.addAll(value);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  loadProductSubCategory(num? parentCode) async {
    if (await NetworkStatus.getInternetStatus()) {
      /// Service call get product sub
      this.getProductSubCategories(parentCode!).then((value) {
        setState(() {
          subCategoryList.addAll(value);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<ProductCategoryDAO>> getProductCategories(num? parentCode) async {
    categoryList.clear();
    categoryDropdownValue = null;
    setState(() {
      isLoadingProgress = true;
    });
    http.Response response = await _service
        .getDropDownType("lookup/productCategory/parent/$parentCode");
    List<ProductCategoryDAO> _list = [];
    setState(() {
      isLoadingProgress = false;
    });
    if (response.statusCode == 200) {
      var responseBody = json.decode(response.body);
      for (var data in responseBody['data']) {
        _list.add(ProductCategoryDAO.fromJson(data));
      }
    } else {
      print("Product category: ${response.body}");
    }

    return _list;
  }

  Future<List<ProductSubCategoryDAO>> getProductSubCategories(
      num? parentCode) async {
    subCategoryList.clear();
    subCategoryDropdownValue = null;
    setState(() {
      isLoadingProgress = true;
    });

    http.Response response = await _service
        .getDropDownType("lookup/productSubCategory/parent/$parentCode");
    List<ProductSubCategoryDAO> _list = [];
    setState(() {
      isLoadingProgress = false;
    });
    if (response.statusCode == 200) {
      var responseBody = json.decode(response.body);
      for (var data in responseBody['data']) {
        _list.add(ProductSubCategoryDAO.fromJson(data));
      }
    } else {
      print("Product sub-category: ${response.body}");
    }

    return _list;
  }

  Future<List<ProductSegmentDAO>> getProductSegments({num? parentCode}) async {
    segmentList.clear();
    segmentDropdownValue = null;

    http.Response response = await _service
        .getDropDownType("lookup/productSegment/parent/$parentCode");
    List<ProductSegmentDAO> _list = [];
    setState(() {
      isLoadingProgress = false;
    });
    if (response.statusCode == 200) {
      var responseBody = json.decode(response.body);

      for (var data in responseBody['data']) {
        _list.add(ProductSegmentDAO.fromJson(data));
      }
    } else {
      print("Product segment: ${response.body}");
    }

    return _list;
  }

  String getParams(
      String segment, String category, String subCategory, String sector) {
    segment = (segment == null) ? "" : segment;
    category = (category == null) ? "" : category;
    subCategory = (subCategory == null) ? "" : subCategory;
    sector = (sector == null) ? "" : sector;
    String requiredUrl = "?" +
        (segment.isEmpty ? "" : "product_segment=$segment") +
        (segment.isNotEmpty && category.isNotEmpty ? "&" : "") +
        (category.isEmpty ? "" : "product_category=$category") +
        ((category.isNotEmpty || segment.isNotEmpty) && (subCategory.isNotEmpty)
            ? "&"
            : "") +
        (subCategory.isEmpty ? "" : "product_sub_category=$subCategory") +
        ((category.isNotEmpty ||
                    segment.isNotEmpty ||
                    subCategory.isNotEmpty) &&
                (sector.isNotEmpty)
            ? "&"
            : "") +
        (sector.isEmpty ? "" : "product_sector=$sector");

    return requiredUrl;
  }

  Future<List<ProductSectorDAO>> getProductSector() async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = Constants.GETTING_DATA;
    });
    http.Response response =
        await _service.getDropDownType("lookup/productSector");
    List<ProductSectorDAO> _list = [];
    setState(() {
      isLoadingProgress = false;
    });
    if (response.statusCode == 200) {
      var responseBody = json.decode(response.body);

      for (var data in responseBody['data']) {
        _list.add(ProductSectorDAO.fromJson(data));
      }
    } else if (response.statusCode == 401) {
      return CommonMethods.handleUnauthorizedAccess(context);
    }

    return _list;
  }

  productSectorView() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          margin: EdgeInsets.only(top: 30, left: 5),
          child: Text(
            Language().getString(Constants.PRODUCT_SECTOR, selectedLang),
            style: TextStyle(
              fontWeight: StyleView.fontSemiBold,
              color: theme.colorScheme.primary,
            ),
          ),
        ),
        productSectorSearchView(),
      ],
    );
  }

  Widget productSectorSearchView() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 5.0, vertical: 10.0),
      decoration: AppUtills.boxDecoration(),
      child: CustomSearchableDropDown(
        items: productSectorList.toList(),
        dropDownMenuItems:
            productSectorList.map((item) => item.sectorName).toList(),
        label: Language().getString(Constants.SELECT_PRODUCT_SECTOR,
            selectedLang), // productSectorDropdown!.sectorName,
        labelStyle: TextStyle(
            fontWeight: StyleView.fontMedium,
            color: Colors.black,
            fontSize: 14.0),
        suffixIcon: Padding(
            padding: const EdgeInsets.all(0.0),
            child: Icon(
              Icons.keyboard_arrow_down_outlined,
              color: Colors.black,
            )),
        hint: Language().getString(Constants.PRODUCT_SECTOR, selectedLang),
        dropdownHintText:
            Language().getString(Constants.PRODUCT_SECTOR, selectedLang),
        onChanged: (value) {
          setState(() {
            productSectorDropdown = value;
          });
          loadProductCategories(productSectorDropdown!.parentId);
        },
      ),
    );
  }

  productSegmentView() {
    if (segmentList.length > 0) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: EdgeInsets.only(top: 30, left: 5),
            child: Text(
              Language().getString(Constants.PRODUCT_SEGMENT, selectedLang),
              style: TextStyle(
                fontWeight: StyleView.fontSemiBold,
                color: theme.colorScheme.primary,
              ),
            ),
          ),
          productSegmentSearchView()
        ],
      );
    } else {
      return Container(child: Text(""));
    }
  }

  productCategoryView() {
    if (categoryList.length > 0) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: EdgeInsets.only(top: 30, left: 5),
            child: Text(
              Language().getString(Constants.PRODUCT_CATEGORY, selectedLang),
              style: TextStyle(
                fontWeight: StyleView.fontSemiBold,
                color: theme.colorScheme.primary,
              ),
            ),
          ),
          productCategorySearchView()
        ],
      );
    } else {
      return Container(child: Text(""));
    }
  }

  productSubCategoryView() {
    if (subCategoryList.length > 0) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: EdgeInsets.only(top: 30, left: 5),
            child: Text(
              Language()
                  .getString(Constants.PRODUCT_SUB_CATEGORY, selectedLang),
              style: TextStyle(
                fontWeight: StyleView.fontSemiBold,
                color: theme.colorScheme.primary,
              ),
            ),
          ),
          productSubCategorySearchView()
        ],
      );
    } else {
      return Container(child: Text(""));
    }
  }
}
