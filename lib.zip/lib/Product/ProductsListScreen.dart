import 'dart:io';

import 'package:vyaparlive/retailer_view/component/CreateNewRetailer.dart';
import 'package:vyaparlive/retailer_view/card_view/ProductsCardView.dart';
import 'package:vyaparlive/service/api_service/ProductsApiService.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutx/flutx.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../components/AppController.dart';
import '../components/AppUtills.dart';
import '../components/Constants.dart';
import '../components/Dialog.dart';
import '../components/NetworkStatus.dart';
import '../components/StyleView.dart';
import '../components/common_methods.dart';
import '../config/Language.dart';
import '../invoice_view/BatchPriceDropdownView.dart';
import '../model/ModelProduct.dart';
import '../model/product_model/BatchPriceDAO.dart';
import '../model/product_model/ProductModel.dart';
import '../page_transition/PageTransition.dart';
import '../retailer_view/card_view/ProductsCardView_v2.dart';
import '../theme/app_theme.dart';
import '../utills/AppBackgroundView.dart';
import '../utills/AppBarName.dart';
import '../utills/CommonButtonsView.dart';

class ProductsListSelection extends StatefulWidget {
  const ProductsListSelection({super.key});

  @override
  State<ProductsListSelection> createState() => _ProductsListSelectionState();
}

class _ProductsListSelectionState extends State<ProductsListSelection> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  String? buId = "";
  String? buName = "";
  TextEditingController retailNumberController = TextEditingController();
  bool isSearchedRetailExist = false;
  num? retailCustomerDiscount = 0;
  String? retailCustomerDiscountType = "";
  bool isLoadingProgress = true;
  String progressMessage = Constants.GETTING_DATA;
  List<ModelProduct> selectedProductsList = [];
  List<BatchPriceDAO?> batchPricingDropdownList = [];
  late ThemeData theme;
  List<TextEditingController> _enterProductCount = [];
  String? orgCurrencySymbol = "";
  String retailCustomerErrorMessage = "";
  final TextEditingController productNameController = TextEditingController();
  final TextEditingController quantityController = TextEditingController();
  final TextEditingController priceController = TextEditingController();
  final TextEditingController totalPriceController = TextEditingController();
  bool isSearchingForProducts = false;
  String showProductText = "";
  List<ModelProduct> _productsList = [];
  List<String?> productsName = [];
  final TextEditingController retailerSearchController =
      TextEditingController();
  bool isProductListEmpty = false;
  String? offerInPercentage;
  num totalInvoicePrice = 0.0;
  num finalInvoiceAmount = 0.0;
  num calculatedDiscountValue = 0.0;
  List<String> discountSplitValue = [];
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    buId = AppController.instance.getMyBuId;
    buName = AppController.instance.getBuName;
    // orgCurrencySymbol = AppController.instance.getBuCurrencySymbol;
    String? symbol = AppController.instance.getBuCurrencySymbol;
    orgCurrencySymbol = (symbol != null && symbol.isNotEmpty && symbol!="-") ? symbol : "\u20B9";
    loadProductData();
  }

  @override
  void dispose() {
    productNameController.dispose();
    super.dispose();
  }

  Widget buildOfferPercentageDropdown() {
    return Container(
      margin: EdgeInsets.only(left: 8),
      child: DropdownButton<String>(
        onTap: () {
          FocusScope.of(context).unfocus();
        },
        value: offerInPercentage,
        hint: Text(
            Language().getString(Constants.DISCOUNT_IN, selectedLang) + " (%)",
            style: TextStyle(
                color: Color(Constants.APP_COLOR),
                fontWeight: StyleView.fontRegular)),
        isExpanded: true,
        underline: SizedBox(),
        onChanged: (String? data) {
          setState(() => offerInPercentage = data);
          calculatePercentage();
        },
        style: TextStyle(
            color: Color(Constants.APP_COLOR),
            fontWeight: StyleView.fontRegular),
        items: Constants.PERCENTAGELIST.map((String model) {
          return new DropdownMenuItem<String>(
            child: new Text(model),
            value: model,
          );
        }).toList(),
      ),
    );
  }

  Widget renderTableRowHeading(String? hederText, TextAlign _textAlign) {
    return Container(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Text(
          Language().getString(hederText, selectedLang),
          textAlign: _textAlign,
          style: TextStyle(
              color: Color(Constants.APP_COLOR),
              fontWeight: FontWeight.bold,
              fontSize: 13.0),
        ),
      ),
    );
  }

  TableRow renderPaymentDetails(Widget titleWidget, Widget valueWidget) {
    return TableRow(children: [titleWidget, valueWidget]);
  }

  Widget renderTableRowValue(String value) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        child: Text(value,
            style: TextStyle(fontSize: 13, color: Color(Constants.APP_COLOR))),
      ),
    );
  }

  Widget invoiceTableView() {
    return Container(
        width: MediaQuery.of(context).size.width,
        alignment: Alignment.centerRight,
        child: Table(
          border: TableBorder.all(
            color: Colors.black,
          ),
          children: [
            renderPaymentDetails(
                renderTableRowHeading(
                    Constants.TOTAL_PRICE + " ( $orgCurrencySymbol )",
                    TextAlign.start),
                renderTableRowValue(
                    CommonMethods.getCurrencyValues(totalInvoicePrice))),
            renderPaymentDetails(
                renderTableRowHeading(
                    Language().getString(
                        Constants.ADDITIONAL_DISCOUNT + " ( % )", selectedLang),
                    TextAlign.start),
                buildOfferPercentageDropdown()),
            renderPaymentDetails(
                renderTableRowHeading(
                    Language().getString(
                        Constants.INVOICE_AMOUNT + " ( $orgCurrencySymbol )",
                        selectedLang),
                    TextAlign.start),
                renderTableRowValue(
                    CommonMethods.getCurrencyValues(finalInvoiceAmount))),
          ],
        ));
  }

  Widget bottomNavigation() {
    if (selectedProductsList.length > 0) {
      return Container(
          margin: EdgeInsets.symmetric(horizontal: 10.0),
          padding: EdgeInsets.symmetric(vertical: 10),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              invoiceTableView(),
              SizedBox(height: 16),
              CommonButtonsView(
                  context: context,
                  b1Text:
                      Language().getString(Constants.STR_CANCEL, selectedLang),
                  b2Text:
                      Language().getString(Constants.CONTINUE, selectedLang),
                  onb1Action: () => Navigator.of(context).pop(),
                  onb2Action: () {
                    Navigator.push(
                        context,
                        PageTransition(
                            context: context,
                            page: CreateNewRetailer(
                                productsList: selectedProductsList,
                                batchList: batchPricingDropdownList,
                                additionalDiscount:
                                    (discountSplitValue.length > 0)
                                        ? int.parse(discountSplitValue[0])
                                        : 0)));
                  }),
            ],
          ));
    } else {
      return SizedBox();
    }
  }

  Widget showProductSearchView() {
    return Container(
      decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(color: Colors.black45),
          borderRadius: BorderRadius.circular(8)),
      margin: EdgeInsets.only(top: 10.0),
      padding: EdgeInsets.only(left: 5, right: 5),
      height: 45.0,
      alignment: Alignment.centerLeft,
      child: Container(
        alignment: Alignment.centerLeft,
        child: Row(
          children: [
            Expanded(
              flex: 2,
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(5.0),
                      bottomLeft: Radius.circular(5.0)),
                  color: Color(Constants.APP_BACKGROUND_COLOR),
                ),
                margin: EdgeInsets.only(right: 1.0),
                padding: EdgeInsets.only(left: 3.0),
                child: Center(
                  child: TextField(
                      controller: productNameController,
                      keyboardType: TextInputType.text,
                      decoration: InputDecoration(
                        hintText: Language().getString(
                            Constants.SEARCH_BY_PRODUCT, selectedLang),
                        hintStyle: TextStyle(fontSize: 12.0),
                        border: InputBorder.none,
                      ),
                      onChanged: (text) {
                        if (text.isEmpty) {
                          setState(() => isLoadingProgress = true);
                        }
                        loadProductData();
                      },
                      style: TextStyle(
                          fontSize: 12.0, decoration: TextDecoration.none),
                      maxLines: 2),
                ),
              ),
            ),
            if (productNameController.text.isEmpty)
              SizedBox()
            else
              Container(
                child: IconButton(
                    icon: Icon(Icons.close, color: Colors.red, size: 20.0),
                    onPressed: () {
                      CommonMethods.hideKeyboard(context);
                      productNameController.clear();
                      setState(() => isLoadingProgress = true);
                      loadProductData();
                    }),
              )
          ],
        ),
      ),
    );
  }

  Widget productsGridView() {
    return Expanded(
        child: Container(
      margin: EdgeInsets.only(top: 16, bottom: 16),
      decoration: AppUtills.boxDecoration(),
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.all(5.0),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    Language().getString(Constants.PRODUCT_NAME, selectedLang),
                    style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                        fontWeight: FontWeight.bold),
                  ),
                ),
                Expanded(
                  child: Text(
                    Language().getString(Constants.QUANTITY, selectedLang),
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                        fontWeight: FontWeight.bold),
                  ),
                ),
                Expanded(
                  child: Text(
                    Language().getString(Constants.TOTAL_PRICE, selectedLang) +
                        " ( $orgCurrencySymbol )",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                        fontWeight: FontWeight.bold),
                  ),
                )
              ],
            ),
          ),
          Divider(color: Color(Constants.APP_COLOR)),
          Expanded(
            child: ListView.separated(
                shrinkWrap: true,
                separatorBuilder: (context, index) => new Divider(
                      color: Colors.transparent,
                      height: 0.0,
                    ),
                itemCount: _productsList.length,
                itemBuilder: (context, index) {
                  return Card(
                    child: Column(
                      children: [
                        ProductsCardView(
                          onRemoveProductQuantit: () {
                            if (selectedProductsList.length > 0)
                              removeProductsQuantity(index);
                          },
                          onAddProductQuantity: () {
                            addProductsQuantity(index);
                          },
                          desingQuntityField: Container(
                            width: 50.0,
                            height: 30.0,
                            alignment: Alignment.bottomCenter,
                            decoration: AppUtills.boxDecoration(),
                            child: designQuantityInputField(index),
                          ),
                          productName: _productsList[index].name,
                          removeProduct: () async {
                            final action = await Dialogs.yesCancelDialog(
                                context,
                                Language()
                                    .getString(Constants.WARNING, selectedLang),
                                Language().getString(
                                    Constants.WARNING_TEXT, selectedLang),
                                Language().getString(
                                    Constants.OKAY_STR, selectedLang),
                                "",
                                false);

                            if (action == DialogAction.yes) {
                              setState(() {
                                _productsList.removeAt(index);
                                batchPricingDropdownList.removeAt(index);
                              });
                            }
                          },
                          productTotalPrice: _productsList[index].price,
                        ),
                        batchPricingDropdown(
                            _productsList[index].batchPriceList!, index)
                      ],
                    ),
                  );
                }),
          )
        ],
      ),
    ));
  }

  int onAlignGridItems(BoxConstraints boxConstrainst) {
    if (kIsWeb || Platform.isWindows) {
      if (boxConstrainst.maxWidth > 800) {
        return 7;
      }

      if (boxConstrainst.maxWidth < 500 ||
          boxConstrainst.maxWidth < 600 ||
          boxConstrainst.maxWidth < 700) {
        return 2;
      }
      return 3;
    } else {
      return 2;
    }
  }

  double findAspectRatio(double width, BoxConstraints boxConstraints) {
    if (kIsWeb || Platform.isWindows) {
      if (boxConstraints.maxWidth < 500 ||
          boxConstraints.maxWidth < 600 ||
          boxConstraints.maxWidth < 700) {
        if (boxConstraints.maxHeight < 500) {
          return MediaQuery.of(context).size.width /
              (MediaQuery.of(context).size.height / 1);
        } else {
          return MediaQuery.of(context).size.width /
              (MediaQuery.of(context).size.height / 1.4);
        }
      } else {
        return (width / 2 - 24) /
            ((width / 2 - 20) + MediaQuery.of(context).size.height * 0.10);
      }
    } else {
      return (width / 2 - 24) /
          ((width / 2 - 20) + MediaQuery.of(context).size.height * 0.10);
    }
  }

  Widget productsGridViewV2(BoxConstraints boxConstrainst) {
    return Expanded(
      child: Container(
        margin: EdgeInsets.only(top: 10),
        child: GridView.builder(
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: onAlignGridItems(boxConstrainst),
              childAspectRatio: findAspectRatio(
                  MediaQuery.of(context).size.width, boxConstrainst),
            ),
            shrinkWrap: true,
            padding: FxSpacing.nTop(5),
            physics: new AlwaysScrollableScrollPhysics(
                parent: BouncingScrollPhysics()),
            itemBuilder: (context, index) {
              return Card(
                elevation: 5,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(5))),
                // margin: EdgeInsets.all(0),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      child: ProductsCardViewv2(
                        onRemoveProductQuantit: () {
                          if (selectedProductsList.length > 0)
                            removeProductsQuantity(index);
                        },
                        onAddProductQuantity: () {
                          addProductsQuantity(index);
                        },
                        desingQuntityField: Container(
                          width: 50.0,
                          height: 30.0,
                          alignment: Alignment.bottomCenter,
                          decoration: AppUtills.boxDecoration(),
                          child: designQuantityInputField(index),
                        ),
                        productName: _productsList[index].name,
                        removeProduct: () async {
                          final action = await Dialogs.yesCancelDialog(
                              context,
                              Language()
                                  .getString(Constants.WARNING, selectedLang),
                              Language().getString(
                                  Constants.WARNING_TEXT, selectedLang),
                              Language()
                                  .getString(Constants.OKAY_STR, selectedLang),
                              "",
                              false);

                          if (action == DialogAction.yes) {
                            setState(() {
                              _productsList.removeAt(index);
                              batchPricingDropdownList.removeAt(index);
                            });
                          }
                        },
                        productTotalPrice: _productsList[index].price,
                        textEditingController: _enterProductCount[index],
                      ),
                    ),
                    // batchPricingDropdown(
                    //     _productsList[index].batchPriceList!, index)
                  ],
                ),
              );
            },
            itemCount: _productsList.length),
      ),
    );
  }

  Widget productsListView() {
    return LayoutBuilder(builder: (context, constraint) {
      return Container(
        margin: EdgeInsets.only(top: 20.0, left: 16, right: 16.0),
        child: Column(
          children: [
            showProductSearchView(),
            if (isProductListEmpty)
              Container(
                  alignment: Alignment.center,
                  margin: EdgeInsets.symmetric(vertical: 50),
                  child: Text(
                    Language()
                        .getString(Constants.NO_DATAFOUND_STRING, selectedLang),
                    style: TextStyle(
                        fontWeight: StyleView.fontRegular, color: Colors.black),
                  )),
            productsGridView()
          ],
        ),
      );
    });
  }

  void removeProductsQuantity(int index) {
    int? countDecrement = _productsList[index].counter;
    countDecrement = countDecrement! - 1;
    if (countDecrement == 0) {
      final findIndex = selectedProductsList
          .indexWhere((element) => _productsList[index].id == element.id);
      if (findIndex != -1) {
        setState(() {
          _productsList[index].counter = countDecrement;
          totalInvoicePrice = totalInvoicePrice - _productsList[index].price!;
          _productsList[index].price = 0;
          selectedProductsList.removeAt(findIndex);
          _enterProductCount[index].text = "0";
        });
        calculatePercentage();
      }
      return;
    }

    if (countDecrement > 0) {
      final findIndex = selectedProductsList
          .indexWhere((element) => _productsList[index].id == element.id);
      if (findIndex != -1) {
        setState(() {
          _productsList[index].counter = countDecrement;
          selectedProductsList[findIndex].counter = countDecrement;
          selectedProductsList[findIndex].price =
              batchPricingDropdownList[index]!.mrp! *
                  _productsList[index].counter!;
          totalInvoicePrice =
              totalInvoicePrice - batchPricingDropdownList[index]!.mrp!;
          _enterProductCount[index] = TextEditingController(
              text: _productsList[index].counter.toString());
          _enterProductCount[index].selection = TextSelection.fromPosition(
              TextPosition(offset: _enterProductCount[index].text.length));
        });
        calculatePercentage();
        // calculateProductTotalPrice(
        //     findIndex, selectedProductsList[findIndex].counter);
      }
    }
  }

  void addProductsQuantity(int index) async {
    int countIncrement = _productsList[index].counter!;
    if (countIncrement == 0) {
      countIncrement = countIncrement + 1;
      setState(() {
        _productsList[index].counter = countIncrement;
        _productsList[index].price = batchPricingDropdownList[index]!.mrp! *
            _productsList[index].counter!;
        totalInvoicePrice = totalInvoicePrice + _productsList[index].price!;
        _enterProductCount[index] = TextEditingController(
            text: _productsList[index].counter.toString());
        _enterProductCount[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _enterProductCount[index].text.length));
        selectedProductsList.add(_productsList[index]);
      });
      calculatePercentage();
      return;
    }

    countIncrement = countIncrement + 1;
    final findIndex = selectedProductsList
        .indexWhere((element) => _productsList[index].id == element.id);
    if (countIncrement > batchPricingDropdownList[index]!.quantity!) {
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          Language().getString(Constants.QUANTITY_NOT_AVAILABLE, selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
      if (action == DialogAction.yes) {
        // setState(() {
        //   _productsList[index].counter = 0;
        //   selectedProductsList[findIndex].counter = 0;
        //   selectedProductsList[findIndex].price = 0;
        //   _enterProductCount[index] = TextEditingController(text: "");
        //   _enterProductCount[index].selection = TextSelection.fromPosition(
        //       TextPosition(offset: _enterProductCount[index].text.length));
        // });
        return;
      }
    }

    if (findIndex != -1) {
      setState(() {
        _productsList[index].counter = countIncrement;
        _productsList[index].price =
            batchPricingDropdownList[index]!.mrp! * countIncrement;
        selectedProductsList[findIndex].counter = countIncrement;
        selectedProductsList[findIndex].price =
            batchPricingDropdownList[index]!.mrp! * countIncrement;
        totalInvoicePrice =
            totalInvoicePrice + batchPricingDropdownList[index]!.mrp!;
        _enterProductCount[index] = TextEditingController(
            text: _productsList[index].counter.toString());
        _enterProductCount[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _enterProductCount[index].text.length));
      });
      calculatePercentage();
    }
  }

  Widget designQuantityInputField(int index) {
    return Container(
      height: 60.0,
      width: 60.0,
      child: TextFormField(
        textAlign: TextAlign.center,
        enableInteractiveSelection: false,
        controller: _enterProductCount[index],
        decoration: InputDecoration(
          hintText: "0",
          border: InputBorder.none,
        ),
        keyboardType: TextInputType.numberWithOptions(signed: true),
        style: TextStyle(fontSize: 12.0),
        inputFormatters: [
          new LengthLimitingTextInputFormatter(5),
          FilteringTextInputFormatter.digitsOnly
        ],
        onFieldSubmitted: (value) {
          // if (value == "0" || value.isEmpty) {
          //   if (selectedProductsList.length > 0) {
          //     final findIndex = selectedProductsList.indexWhere(
          //         (element) => _productsList[index].id == element.id);
          //     if (findIndex != -1) {
          //       setState(() {
          //         selectedProductsList[index].counter = 0;
          //         selectedProductsList[index].price = 0;
          //       });
          //     }
          //   }
          // }
        },
        onChanged: (value) async {
          if (value.isNotEmpty) {
            int countValue = int.parse(value);
            if (countValue > batchPricingDropdownList[index]!.quantity!) {
              final action = await Dialogs.yesCancelDialog(
                  context,
                  Language().getString(Constants.ERROR, selectedLang),
                  Language().getString(
                      Constants.QUANTITY_NOT_AVAILABLE, selectedLang),
                  Language().getString(Constants.OKAY_STR, selectedLang),
                  "",
                  false);
              if (action == DialogAction.yes) {
                return;
              }
            }

            if (selectedProductsList.length > 0) {
              final findIndex = selectedProductsList.indexWhere(
                  (element) => _productsList[index].id == element.id);
              if (findIndex != -1) {
                setState(() {
                  selectedProductsList[findIndex].counter = countValue;
                  selectedProductsList[findIndex].price =
                      batchPricingDropdownList[index]!.mrp! * countValue;
                  _productsList[index].price =
                      batchPricingDropdownList[index]!.mrp! * countValue;
                  totalInvoicePrice =
                      totalInvoicePrice + _productsList[index].price!;
                });
                calculatePercentage();
              } else {
                setState(() {
                  _productsList[index].counter = countValue;
                  _productsList[index].price =
                      batchPricingDropdownList[index]!.mrp! *
                          _productsList[index].counter!;
                  totalInvoicePrice =
                      totalInvoicePrice + _productsList[index].price!;
                  _enterProductCount[index] = TextEditingController(
                      text: _productsList[index].counter.toString());
                  _enterProductCount[index].selection =
                      TextSelection.fromPosition(TextPosition(
                          offset: _enterProductCount[index].text.length));
                  selectedProductsList.add(_productsList[index]);
                });
                calculatePercentage();
              }
            } else {
              setState(() {
                _productsList[index].counter = countValue;
                _productsList[index].price =
                    batchPricingDropdownList[index]!.mrp! *
                        _productsList[index].counter!;
                totalInvoicePrice =
                    totalInvoicePrice + _productsList[index].price!;
                _enterProductCount[index] = TextEditingController(
                    text: _productsList[index].counter.toString());
                _enterProductCount[index].selection =
                    TextSelection.fromPosition(TextPosition(
                        offset: _enterProductCount[index].text.length));
                selectedProductsList.add(_productsList[index]);
              });
              calculatePercentage();
            }
          } else {
            final findIndex = selectedProductsList
                .indexWhere((element) => _productsList[index].id == element.id);
            if (findIndex != -1) {
              selectedProductsList.removeAt(findIndex);
            }
            setState(() {
              selectedProductsList = selectedProductsList;
              totalInvoicePrice =
                  totalInvoicePrice - _productsList[index].price!;
              _productsList[index].price = 0;
              _productsList[index].counter = 0;
              _enterProductCount[index].clear();
            });
            calculatePercentage();
          }
        },
      ),
    );
  }

  Widget batchPricingDropdown(List<BatchPriceDAO> batchNumberList, int index) {
    if (batchNumberList.length > 0 && batchPricingDropdownList.length > 0) {
      if (batchPricingDropdownList[index] == null) {
        batchPricingDropdownList[index] = batchNumberList[0];
        batchPricingDropdownList[index]?.isBatchChecked = true;
      }

      return BatchPriceDropDownView(
          canShowPrice: false,
          canShowDynamicPricing: false,
          isFromRetailPage: true,
          currentDropdownIndex: index,
          batchPricingList: batchNumberList,
          batchDropdown: batchPricingDropdownList,
          selectedDropdownValue: (data) {
            for (var findIndex = 0;
                findIndex < selectedProductsList.length;
                findIndex++) {
              if (_productsList[index].id ==
                  selectedProductsList[findIndex].id) {
                setState(() {
                  num totalPriceValue =
                      (data!.mrp! * selectedProductsList[findIndex].counter!);
                  batchPricingDropdownList[index] = data;
                  selectedProductsList[findIndex].price = totalPriceValue;
                  batchPricingDropdownList[findIndex]?.isBatchChecked = true;
                });
              } else {
                setState(() => batchPricingDropdownList[findIndex]
                    ?.isBatchChecked = false);
              }
            }
          },
          strBatchPricing: Language().getString("Batch", selectedLang),
          strAvailableQuantity: Language().getString("Quantity", selectedLang));
    } else {
      return SizedBox();
    }
  }

  void calculateProductTotalPrice(int index, int? quantity) {
    setState(() {
      selectedProductsList[index].price =
          batchPricingDropdownList[index]!.mrp! * quantity!;
    });
  }

  @override
  void setState(VoidCallback fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        AppBackgroundView(
            body: SafeArea(
              child: Scaffold(
                  backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                  appBar: AppBar(
                    backgroundColor: Colors.transparent,
                    centerTitle: true,
                    elevation: 0,
                    iconTheme: IconThemeData(color: theme.colorScheme.primary),
                    title: AppbarName(
                        title: Language()
                            .getString(Constants.PRODUCTS_LIST, selectedLang),
                        buName: "$buName"),
                  ),
                  bottomNavigationBar: bottomNavigation(),
                  body: productsListView()),
            )),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    );
  }

  Future<void> loadProductData({String parms = ""}) async {
    if (await NetworkStatus.getInternetStatus()) {
      Map<String, dynamic> mapData = {
        "name": productNameController.text,
        "for_sale": true,
        "isDesc": true
      };
      List<BuProductModal> fetchProductsData = await ProductsApiService.instance
          .getBuProducts(
              context: context,
              buId: buId!,
              mapFilter: mapData,
              langError: Language().getString(Constants.ERROR, selectedLang),
              langOk: Language().getString(Constants.OKAY_STR, selectedLang));
      setState(() {
        isLoadingProgress = false;
        _productsList.clear();
        batchPricingDropdownList.clear();
        isProductListEmpty = true;
        _enterProductCount.clear();
      });
      if (fetchProductsData.length > 0) {
        for (var itemData in fetchProductsData) {
          if (itemData.name!.isNotEmpty) {
            itemData.batchPrice?.removeWhere((element) =>
                element.quantity == 0 || element.batchNumber!.isEmpty);
            if (itemData.batchPrice!.length > 0) {
              _productsList.add(ModelProduct(
                  id: itemData.id,
                  name: itemData.name,
                  counter: 0,
                  batchPriceList: itemData.batchPrice,
                  price: 0,
                  unitPrice: itemData.batchPrice![0].mrp));
              _enterProductCount.add(new TextEditingController(text: ""));
              batchPricingDropdownList.add(null);
            }
          }
        }
        updateProductsList(_productsList);
      } else {
        setState(() => isProductListEmpty = false);
      }
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  void updateProductsList(List<ModelProduct> productsList) {
    for (var i = 0; i < productsList.length; i++) {
      ModelProduct itemData = productsList[i];
      final findIndex = selectedProductsList
          .indexWhere((element) => element.id == itemData.id);
      if (findIndex != -1) {
        _productsList[i] = ModelProduct(
            id: selectedProductsList[findIndex].id,
            name: selectedProductsList[findIndex].name,
            counter: selectedProductsList[findIndex].counter,
            batchPriceList: selectedProductsList[findIndex].batchPriceList,
            price: selectedProductsList[findIndex].price,
            unitPrice: selectedProductsList[findIndex].batchPriceList![0].mrp);

        _enterProductCount[i] = TextEditingController(
            text: selectedProductsList[findIndex].counter.toString());
        _enterProductCount[i].selection = TextSelection.fromPosition(
            TextPosition(offset: _enterProductCount[i].text.length));
      }
    }
    setState(() {
      isProductListEmpty = false;
      _productsList = _productsList;
    });
  }

  void calculatePercentage() {
    if (offerInPercentage != null) {
      discountSplitValue = offerInPercentage!.split(" %");
      calculatedDiscountValue =
          (totalInvoicePrice * int.parse(discountSplitValue[0])) / 100;
      setState(() =>
          finalInvoiceAmount = totalInvoicePrice - calculatedDiscountValue);
    } else {
      setState(() => finalInvoiceAmount = totalInvoicePrice);
    }
  }
}
