import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Transaction/card_view/ProductCardDesign.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/TransactionDetailsView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/TransactionsModel.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'package:vyaparlive/service/Service.dart';

class RoughOrderPage extends StatefulWidget {
  final String? transactionId;
  final String? transactionName;
  RoughOrderPage({this.transactionId, this.transactionName});
  @override
  _RoughOrderPageState createState() => _RoughOrderPageState();
}

class _RoughOrderPageState extends State<RoughOrderPage> {
  String? buName = "";
  String? buId = "";
  TransactionsModel? transactionDetails;
  List<TransactionsModel> _transactionData = [];
  List<Product> _productsData = [];
  late Service _service;
  List<Map> _namesData = [];
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;

  @override
  void initState() {
    super.initState();
    this.getLoadLanguage();
    _service = Service();
    buId = AppController.instance.getMyBuId;
    buName = AppController.instance.getBuName;
    transactionDetails = AppController.instance.getTransactionData;
    new Future.delayed(Duration.zero, () {
      getAllDiscussionData().then((value) {
        _transactionData.addAll(value);
        if (_transactionData.length > 0 &&
            _transactionData[0].roughOrderDetails != null) {
          setState(() {
            _productsData
                .addAll(_transactionData[0].roughOrderDetails!.products!);
          });
        }
      });
    });
  }

  getLoadLanguage() async {
    _namesData = [
      {"name": Language().getString(Constants.NAME_STRING, selectedLang)},
      {"name": Language().getString(Constants.TXN_ID, selectedLang)},
      {"name": Language().getString(Constants.TXN_INITIATED_DATE, selectedLang)}
    ];
  }

  Future<List<TransactionsModel>> getAllDiscussionData() async {
    http.Response response = await _service
        .getDiscussioins(transactionDetails!.id!)
        .catchError((value) {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<TransactionsModel> _discussionsData = [];
    if (response.statusCode == 200) {
      final object = json.decode(response.body);
      for (var data in object['data']) {
        _discussionsData.add(TransactionsModel.fromJson(data));
      }
    } else if (response.statusCode == 401) {
      CommonMethods.handleUnauthorizedAccess(context);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          response.body,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }

    return _discussionsData;
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
        appBar: AppBar(
          centerTitle: true,
          backgroundColor: Color(Constants.APP_COLOR),
          title: Column(
            children: [
              Text(Language().getString(Constants.PRODUCTS_STR, selectedLang)),
              Text(
                buName!,
                style: TextStyle(
                  fontSize: 13.0,
                ),
              )
            ],
          ),
        ),
        body: Container(
          margin: EdgeInsets.symmetric(
            vertical: 5.0,
            horizontal: 10.0,
          ),
          child: Column(
            children: [
              TransactionDetailsViewPage(
                  transactionName: widget.transactionName,
                  transactionId: transactionDetails!.id,
                  transactionDate: transactionDetails!.transactionDate.toString(),
                  namesData: _namesData),
              SizedBox(height: 5.0),
              Container(
                height: MediaQuery.of(context).size.height * 0.72,
                child: ListView.separated(
                    shrinkWrap: true,
                    itemBuilder: (context, index) => ProductCardDesignView(
                          strTotalAmount: Language()
                              .getString(Constants.TOTAL_AMOUNT, selectedLang),
                          strUnitPrice: Language()
                              .getString(Constants.PRICE_UNIT, selectedLang),
                          strQuantity: Language()
                              .getString(Constants.QUANTITY, selectedLang),
                          strOfferApplied: Language()
                              .getString(Constants.OFFER_APPLIED, selectedLang),
                          productImage:
                              _productsData[index].productImage!.length > 0
                                  ? _productsData[index].productImage![0]
                                  : null,
                          productName: _productsData[index].productName,
                          productPrice: _productsData[index].total,
                          productQnty: _productsData[index].quantity,
                        ),
                    separatorBuilder: (context, index) => new Divider(
                          height: 1.0,
                          color: Colors.transparent,
                        ),
                    itemCount: _productsData.length),
              )
            ],
          ),
        ),
      ),
    );
  }
}
