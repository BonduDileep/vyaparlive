import 'dart:io';
import 'package:vyaparlive/Product/controller/product_controller.dart';
import 'package:vyaparlive/core/enums/privilleges_enum.dart';
import 'package:vyaparlive/service/api_service/ProductsApiService.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:vyaparlive/utills/vyapar_info.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/foundation.dart';
import 'dart:convert';
import 'dart:async';
import 'package:vyaparlive/service/organization_service.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:flutx/flutx.dart';
import 'package:intl/intl.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Product/EditMyProduct.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/connections_view/PlaceConnectionOrder.dart';
import 'package:vyaparlive/Product/products_widget/PopupMenuItemDesign.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/MyDrawer.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/BuBasicDataModel.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/OffersModel.dart';
import 'package:vyaparlive/model/product_model/OffersDAO.dart';
import 'package:vyaparlive/model/product_model/ProductModel.dart';
import 'package:vyaparlive/model/SupplierModel.dart';
import 'package:vyaparlive/service/product_services.dart';
import 'package:vyaparlive/utills/SharePref.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';

import '../ondc_menu/ondc_edit_product/OndcEditProduct.dart';
import 'DownloadBarcodesPage.dart';

class ProductsMenuPage extends StatefulWidget {
  final bool isFromBuList;
  final String? currentBuId;
  final String? currentBuName;
  ProductsMenuPage(
      {this.isFromBuList = false, this.currentBuId, this.currentBuName});
  @override
  _ProductsMenuPageState createState() => _ProductsMenuPageState();
}

class _ProductsMenuPageState extends State<ProductsMenuPage>
    with TickerProviderStateMixin {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();

  final _productNameController = TextEditingController();
  final _batchoneQuantityController = TextEditingController();
  final _batchtwoQuantityController = TextEditingController();
  final _batchthreeQuantityController = TextEditingController();
  final _batchonePriceController = TextEditingController();
  final _batchtwoPriceController = TextEditingController();
  final _batchthreePriceController = TextEditingController();
  List<BuBasicDataModel> _buList = [];
  BuBasicDataModel? connectionsDropdownValue;

  bool isCameraReady = false;
  bool showCapturedPhoto = false;
  var imagePath;
  bool cameraPriviewShow = false;
  File? imageFile;
  bool isSelectCaptureChoice = false;
  int selectedIndex = -1;
  bool isUpdateRow = false;
  // List<Products> selectedList = List<Products>();
  final String selectedBussinessUnit = '';
  var selectedItem;
  int? capturedIndex;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;

  List<BuBasicDataModel> buList = [];
  bool isLoading = false;
  List<BuProductModal> _productsList = [];
  List<SupplierModel> _supplierList = [];
  List<OffersModel> _offersList = [];
  DateFormat formatter = DateFormat("yyyy-MM-dd");
  String? userId = "";
  BuBasicDataModel? dropdownValue;
  TextEditingController _searchController = TextEditingController();
  bool isShowFloatButton = false;

  List<Map<String, Object>> filteroptions = [
    {'id': 0, 'name': Constants.OFFER, 'isFilterValue': false},
    {'id': 1, 'name': Constants.NOT_IN_STOCK, 'isFilterValue': false},
    {'id': 2, 'name': Constants.NOT_FOR_SALE, 'isFilterValue': false},
  ];

  String? buId = "";
  String? currentBuName = "";
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  String params = "";
  static String showLoaderText = Constants.NO_DATA_FOUND;
  late ProductService _productService;
  bool isSearchForParams = false;
  num totalBatchQuantity = 0;
  List<num> batchQuantityList = [];
  String? orgCurrencySymbol = "";
  ScrollController? _scrollController;
  num _pageCount = 0;
  num _pageLimitCount = 10;
  bool _hasNextPage = true;
  bool isLoadMore = false;
  late OrganizationService _organizationService;
  late ThemeData theme;
  late ProductController _productController;
  late AnimationController _animationController;
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    initBottomSheetAnimation();
    _productController = FxControllerStore.putOrFind(ProductController());
    _organizationService = new OrganizationService();
    // orgCurrencySymbol = AppController.instance.getBuCurrencySymbol;
    String? symbol = AppController.instance.getBuCurrencySymbol;
    orgCurrencySymbol = (symbol != null && symbol.isNotEmpty && symbol != "-")
        ? symbol
        : "\u20B9";
    _productService = ProductService();
    if (widget.isFromBuList) {
      buId = widget.currentBuId;
      currentBuName = widget.currentBuName;
    } else {
      buId = AppController.instance.getMyBuId;
      currentBuName = AppController.instance.getBuName;
    }

    SharePref().getUserId().then((onValue) {
      setState(() {
        userId = onValue;
      });
    });
    // _scrollController = new ScrollController()..addListener(_loadMoreProducts);
    loadProductData();
  }

  initBottomSheetAnimation() {
    _animationController = BottomSheet.createAnimationController(this);
    _animationController.duration = const Duration(milliseconds: 800);
    _animationController.reverseDuration = const Duration(milliseconds: 400);
    _animationController.drive(CurveTween(curve: Curves.easeIn));
  }

  void loadProductData() async {
    if (await NetworkStatus.getInternetStatus()) {
      if (!isSearchForParams) {
        _pageCount = _pageCount + 1;
        isLoadingProgress = true;
      }

      Map<String, dynamic> filterObject = {
        "name": _searchController.text,
        "from": _pageCount,
        "count": _pageLimitCount,
        "isDesc": true
      };
      if (filteroptions[0]['isFilterValue'] == true) {
        filterObject['is_offer'] = true;
      } else if (filteroptions[1]['isFilterValue'] == true) {
        filterObject['in_stock'] = false;
      } else if (filteroptions[2]['isFilterValue'] == true) {
        filterObject['for_sale'] = false;
      } else {
        isShowFloatButton = false;
        this.renderClearFilterData();
      }

      final fetchProductsData = await ProductsApiService.instance.getProductsListV5(
          context: context,
          buId: buId,
          mapFilter: filterObject,
          langError: Language().getString(Constants.ERROR, selectedLang),
          langOk: Language().getString(Constants.OKAY_STR, selectedLang));
      if (fetchProductsData.length > 0) {
        setState(() {
          _productsList.clear();
          batchQuantityList.clear();
          isLoadingProgress = false;
          _productsList.addAll(fetchProductsData);
          _productsList.sort(
              (a, b) => a.name!.toLowerCase().compareTo(b.name!.toLowerCase()));
          for (int i = 0; i < _productsList.length; i++) {
            /// initiating quantity for all batches
            if (_productsList[i].batchPrice!.length > 0) {
              totalBatchQuantity = 0;
              for (int j = 0; j < _productsList[i].batchPrice!.length; j++) {
                totalBatchQuantity = totalBatchQuantity +
                    _productsList[i].batchPrice![j].quantity!;
              }
              batchQuantityList.add(totalBatchQuantity);
            } else {
              batchQuantityList.add(0);
            }
          }
        });
      } else {
        setState(() {
          _productsList.clear();
          isLoadingProgress = false;
          showLoaderText = Constants.NO_DATA_FOUND;
        });
      }
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  @override
  void dispose() {
    _productController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  buildBussinessLeveltype() {
    return showModalBottomSheet(
        transitionAnimationController: _animationController,
        showDragHandle: true,
        isScrollControlled: true,
        barrierColor: Colors.black54,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20.0),
                topRight: Radius.circular(20.0))),
        context: context,
        builder: (BuildContext context) => Padding(
              padding: EdgeInsets.all(8.0),
              child: ListView(
                shrinkWrap: true,
                children: [
                  if (CommonMethods.isPrivillegeExist(
                      context, PrivillegesActions.KEY_PRODUCT_LIST_ADD_FOR_BU))
                    Container(
                        margin: EdgeInsets.symmetric(vertical: 5.0),
                        child: CommonButtonsView(
                          context: context,
                          b1Text: Language()
                              .getString(Constants.ADD_PRODUCT, selectedLang),
                          b2Text: "",
                          onb1Action: () {
                            Navigator.of(context).pop();
                            if (CommonMethods.isPrivillegeExist(context,
                                PrivillegesActions.KEY_MENU_ONDC_TAB)) {
                              Navigator.push(
                                  context,
                                  PageTransition(
                                    context: context,
                                    page: OndcEditMyProductPage(
                                      title: Language().getString(
                                          Constants.ADD_PRODUCT, selectedLang),
                                      buId:
                                          buId, // AppController.instance.getMyBuId,
                                    ),
                                  )).then((value) => loadProductData());
                            } else {
                              Navigator.push(
                                  context,
                                  PageTransition(
                                    context: context,
                                    page: EditMyProductPage(
                                      title: Language().getString(
                                          Constants.ADD_PRODUCT, selectedLang),
                                      buId:
                                          buId, //AppController.instance.getMyBuId,
                                      productId: '',
                                      rawMaterialTitle: '',
                                    ),
                                  )).then((value) => loadProductData());
                            }
                          },
                        )),
                  if (CommonMethods.isPrivillegeExist(context,
                      PrivillegesActions.KEY_PRODUCT_LIST_COPY_FROM_BU))
                    Container(
                      child: CommonButtonsView(
                          context: context,
                          b1Text: Language().getString(
                              Constants.CREATE_FROM_ORG, selectedLang),
                          b2Text: "",
                          onb1Action: () => {
                                Navigator.of(context).pop(),
                                copyAnotherBuProducts()
                              }),
                    ),
                  if (CommonMethods.isPrivillegeExist(context,
                      PrivillegesActions.KEY_PRODUCT_LIST_BY_BULK_UPLOAD))
                    Container(
                        margin: EdgeInsets.symmetric(vertical: 5.0),
                        child: CommonButtonsView(
                          context: context,
                          b1Text: Language().getString(
                              Constants.PRODUCTS_IN_BUILK, selectedLang),
                          b2Text: "",
                          onb1Action: () {
                            var data = VyaparInfo.encryptData(
                                json.encode({"id": buId}));
                            AppUtills.launchURL(
                                '${Constants.URL_BULK_PRODUCTS_UPLOAD}products/bulkupload/$data');
                          },
                        )),
                  Container(
                      margin:
                          EdgeInsets.symmetric(horizontal: 5.0, vertical: 20.0),
                      child: Text(
                        Language().getString(
                            Constants.BULK_PRODUCTS_INFO, selectedLang),
                        style: TextStyle(
                            fontWeight: StyleView.fontRegular,
                            color: Colors.grey),
                      ))
                ],
              ),
            ));
  }

  buildProductFilterDialog() {
    showModalBottomSheet(
        transitionAnimationController: _animationController,
        showDragHandle: true,
        isScrollControlled: true,
        barrierColor: Colors.black54,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20.0),
                topRight: Radius.circular(20.0))),
        context: context,
        builder: (BuildContext context) {
          return StatefulBuilder(builder: (context, StateSetter setState) {
            return ListView(
              shrinkWrap: true,
              children: [
                if (CommonMethods.isPrivillegeExist(context,
                    PrivillegesActions.KEY_PRODUCT_LIST_FILTERS_OFFERS))
                  renderFilterOptionsList(0, setState),
                if (CommonMethods.isPrivillegeExist(context,
                    PrivillegesActions.KEY_PRODUCT_LIST_FILTERS_NOT_IN_STOCK))
                  renderFilterOptionsList(1, setState),
                if (CommonMethods.isPrivillegeExist(context,
                    PrivillegesActions.KEY_PRODUCT_LIST_FILTERS_NOT_FOR_SALE))
                  renderFilterOptionsList(2, setState),
                FxSpacing.height(10),
                Container(
                  margin: EdgeInsets.symmetric(horizontal: 5),
                  padding: EdgeInsets.only(bottom: 10),
                  child: CommonButtonsView(
                    context: context,
                    b1Text: Language()
                        .getString(Constants.STR_CANCEL, selectedLang),
                    b2Text: Language()
                        .getString(Constants.APPLY_FILTER, selectedLang),
                    onb1Action: () => Navigator.of(context).pop(),
                    onb2Action: () {
                      setState(() {
                        isLoadingProgress = true;
                        isShowFloatButton = true;
                      });

                      Navigator.of(context).pop();
                      isLoading = false;
                      loadProductData();
                    },
                  ),
                )
              ],
            );
          });
        });
  }

  Widget renderFilterOptionsList(int index, StateSetter setState) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 5),
      child: Row(
        children: [
          SizedBox(
            height: 40,
            width: 40,
            child: Checkbox(
                activeColor: theme.colorScheme.primary,
                value: filteroptions[index]['isFilterValue'] as bool,
                onChanged: (bool? value) {
                  for (var i = 0; i < filteroptions.length; i++) {
                    if (i == index) {
                      filteroptions[i]['isFilterValue'] = value!;
                    } else {
                      filteroptions[i]['isFilterValue'] = false;
                    }
                  }
                  setState(() => filteroptions);
                }),
          ),
          Text(
            Language().getString(filteroptions[index]['name'], selectedLang),
            style: TextStyle(
                fontWeight: StyleView.fontSemiBold,
                color: (filteroptions[index]['isFilterValue'] == true)
                    ? Colors.grey
                    : Colors.black),
          ),
        ],
      ),
    );
  }

  String getParams(bool offer, bool inStock, bool forSale) {
    String offerValue = (!offer) ? "" : "offers=";
    String inStockValue = (!inStock) ? "" : "in_stock=false";
    String forSaleVale = (!forSale) ? "" : "for_sale=false";

    String requiredUrl = "?" +
        (offerValue.isEmpty ? "" : "$offerValue") +
        (offerValue.isNotEmpty && inStockValue.isNotEmpty ? "&" : "") +
        (inStockValue.isEmpty ? "" : "$inStockValue") +
        ((offerValue.isNotEmpty || inStockValue.isNotEmpty) &&
                (forSaleVale.isNotEmpty)
            ? "&"
            : "") +
        (forSaleVale.isEmpty ? "" : "$forSaleVale");

    return requiredUrl;
  }

  Future<bool> onBackPress() async {
    if (widget.isFromBuList) {
      return Navigator.canPop(context);
    } else {
      return CommonMethods.onBackPress(context);
    }
  }

  onSearchTextChanged(String text) async {
    showLoaderText = Constants.LOADING;
    if (text.isEmpty) {
      isSearchForParams = false;
      loadProductData();
    } else {
      isSearchForParams = true;
      loadProductData();
    }
  }

  buildSearchController() {
    return Container(
      height: 50,
      margin: EdgeInsets.symmetric(horizontal: 5, vertical: 10),
      child: Card(
        elevation: 2.0,
        shadowColor: theme.colorScheme.primary,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20.0),
            side: BorderSide(
                color: theme.colorScheme.primary, strokeAlign: 0.01)),
        child: Row(
          children: <Widget>[
            Expanded(
                flex: 5,
                child: Row(
                  children: <Widget>[
                    Expanded(
                      flex: 5,
                      child: Container(
                        padding: EdgeInsets.only(left: 15),
                        child: TextFormField(
                          controller: _searchController,
                          onChanged: onSearchTextChanged,
                          textInputAction: TextInputAction.done,
                          style: TextStyle(fontWeight: StyleView.fontSemiBold),
                          decoration: InputDecoration(
                              contentPadding: EdgeInsets.only(bottom: 10),
                              border: InputBorder.none,
                              hintText: Language().getString(
                                  Constants.SEARCH_BY_PRODUCT, selectedLang),
                              hintStyle: TextStyle(
                                  fontSize: 13.0,
                                  fontWeight: StyleView.fontMedium)),
                        ),
                      ),
                    ),
                    if (_searchController.text.isNotEmpty)
                      Container(
                          color: Colors.white,
                          child: IconButton(
                              icon: Icon(
                                Icons.close,
                                color: Colors.red,
                                size: 20.0,
                              ),
                              onPressed: () {
                                setState(() {
                                  CommonMethods.hideKeyboard(context);
                                  _searchController.clear();
                                  onSearchTextChanged(_searchController.text);
                                });
                              }))
                  ],
                )),
          ],
        ),
      ),
    );
  }

  onAlignGridItems(BoxConstraints boxConstrainst) {
    if (kIsWeb || Platform.isWindows) {
      if (boxConstrainst.maxWidth > 800) {
        return 7;
      }

      if (boxConstrainst.maxWidth < 500 ||
          boxConstrainst.maxWidth < 600 ||
          boxConstrainst.maxWidth < 700) {
        return 2;
      }
      return 3;
    } else {
      return 2;
    }
  }

  Widget _buildBody() {
    return AppBackgroundView(
      body: Stack(
        children: [
          WillPopScope(
            onWillPop: onBackPress,
            child: SafeArea(
              child: Scaffold(
                key: _scaffoldkey,
                backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                drawer: widget.isFromBuList
                    ? null
                    : MyDrawer(
                        buList: buList,
                      ),
                appBar: new AppBar(
                  iconTheme: IconThemeData(color: theme.colorScheme.primary),
                  title: AppbarName(
                    title: Language()
                        .getString(Constants.PRODUCT_LIST_STR, selectedLang),
                    buName: currentBuName,
                  ),
                  centerTitle: true,
                  elevation: 0,
                  backgroundColor: Colors.transparent,
                  actions: <Widget>[
                    if (CommonMethods.isPrivillegeExist(
                        context, PrivillegesActions.KEY_PRODUCT_LIST_FILTERS))
                      IconButton(
                          onPressed: () {
                            CommonMethods.hideKeyboard(context);
                            buildProductFilterDialog();
                          },
                          icon: Image.asset('assets/images/filter.png',
                              height: 20,
                              color: theme.colorScheme.primary //Colors.white,
                              )),

                    if (kIsWeb) showCreateProductOptions(),
                    if (!kIsWeb &&
                        CommonMethods.isPrivillegeExist(
                            context, PrivillegesActions.KEY_PRODUCT_LIST_ADD))
                      IconButton(
                          onPressed: () {
                            CommonMethods.hideKeyboard(context);
                            buildBussinessLeveltype();
                          },
                          icon: Icon(Icons.add)),
                    // : new Container(),
                    if (!kIsWeb)
                      PopupMenuButton<String>(
                        icon: Icon(Icons.more_vert,
                            color: theme.colorScheme.primary),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(Radius.circular(10.0)),
                        ),
                        onSelected: (String value) {
                          if (value == 'download_barcodes') {
                            Navigator.push(
                                context,
                                PageTransition(
                                  context: context,
                                  page: DownloadBarcodesPage(buId: buId),
                                ));
                          }
                        },
                        itemBuilder: (BuildContext context) => [
                          PopupMenuItem<String>(
                            value: 'download_barcodes',
                            child: Row(
                              children: [
                                Icon(Icons.qr_code,
                                    color: theme.colorScheme.primary),
                                SizedBox(width: 8),
                                Text('Barcodes'),
                              ],
                            ),
                          ),
                        ],
                      ),
                  ],
                ),
                floatingActionButton: (isShowFloatButton)
                    ? FloatingActionButton(
                        backgroundColor: theme.colorScheme.primary,
                        onPressed: () {
                          this.renderClearFilterData();
                          isShowFloatButton = false;
                          isLoading = false;
                          isLoadingProgress = true;

                          loadProductData();
                        },
                        child: Text(
                          Language()
                              .getString(Constants.CLEAR_FILTERS, selectedLang),
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 10.0, color: Colors.white),
                        ),
                      )
                    : null,
                body: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    buildSearchController(),
                    Expanded(
                      child: _productsList.length == 0
                          ? Center(child: Text(showLoaderText))
                          : LayoutBuilder(builder: (context, boxConstrainst) {
                              return GridView.builder(
                                controller: _scrollController,
                                padding: FxSpacing.nTop(5),
                                shrinkWrap: true,
                                physics: new AlwaysScrollableScrollPhysics(
                                    parent: BouncingScrollPhysics()),
                                gridDelegate:
                                    SliverGridDelegateWithFixedCrossAxisCount(
                                  crossAxisCount:
                                      onAlignGridItems(boxConstrainst),
                                  childAspectRatio: findAspectRatio(
                                      MediaQuery.of(context).size.width,
                                      boxConstrainst),
                                ),
                                itemBuilder: (BuildContext context, int index) {
                                  if (index < _productsList.length) {
                                    return AnimationLimiter(
                                        child: AnimationConfiguration
                                            .staggeredGrid(
                                                position: index,
                                                columnCount: 2,
                                                child: SlideAnimation(
                                                  child: FadeInAnimation(
                                                      child: listRowEditUpdate(
                                                          _productsList[index],
                                                          index)),
                                                )));
                                  } else {
                                    return Padding(
                                      padding: EdgeInsets.only(bottom: 100),
                                      child: SizedBox(
                                          height: 20,
                                          width: 20,
                                          child: CircularProgressIndicator()),
                                    );
                                  }
                                },
                                itemCount: (isLoadMore)
                                    ? _productsList.length + 1
                                    : _productsList.length,
                              );
                            }),
                    ),
                  ],
                ),
              ),
            ),
          ),
          AppUtills.showLoadingView(
              context: context,
              message: Language().getString(progressMessage, selectedLang),
              isLoading: isLoadingProgress)
        ],
      ),
    );
  }

  @override
  void setState(VoidCallback fn) {
    // TODO: implement setState
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  Widget build(BuildContext context) {
    return FxBuilder(
        controller: _productController,
        builder: (_productController) => _buildBody());
  }

  renderClearFilterData() {
    filteroptions[0]['isFilterValue'] = false;
    filteroptions[1]['isFilterValue'] = false;
    filteroptions[2]['isFilterValue'] = false;
  }

  double findAspectRatio(double width, BoxConstraints boxConstraints) {
    final screenHeight = MediaQuery.of(context).size.height;
    if (kIsWeb || Platform.isWindows) {
      if (boxConstraints.maxWidth < 500 ||
          boxConstraints.maxWidth < 600 ||
          boxConstraints.maxWidth < 700) {
        if (boxConstraints.maxHeight < 500) {
          return MediaQuery.of(context).size.width /
              (MediaQuery.of(context).size.height / 1);
        } else {
          return MediaQuery.of(context).size.width /
              (MediaQuery.of(context).size.height / 1.4);
        }
      } else {
        // Each item width (for 3 columns)
        double itemWidth = (width / 3) - 24;

        // Define item height relative to width (e.g., 1.2x taller than width)
        double itemHeight = itemWidth * 1.2 + screenHeight * 0.1;

        return itemWidth / itemHeight;
        // return (width / 3 - 24) /
        //     ((width / 3 - 20) + MediaQuery.of(context).size.height * 0.10);
      }
    } else {
      return (width / 2 - 24) /
          ((width / 2 - 20) + MediaQuery.of(context).size.height * 0.10);
    }
  }

  Widget listRowEditUpdate(item, int index) {
    return Card(
      elevation: 10,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(10),
              topRight: Radius.circular(10),
              bottomLeft: Radius.circular(10),
              bottomRight: Radius.circular(10))),
      child: Container(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            ClipRRect(
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(5.0),
                    topRight: Radius.circular(5.0)),
                child: (item.images != null && item.images != '')
                    ? CachedNetworkImage(
                        imageUrl: '${Constants.IAMGE_BUCKET_URL}${item.images}',
                        width: MediaQuery.of(context).size.width,
                        height: MediaQuery.of(context).size.height / 6,
                        fit: BoxFit.cover,
                        errorWidget: (context, url, error) => Image.asset(
                          'assets/images/no_image.jpg',
                          width: MediaQuery.of(context).size.width,
                          height: MediaQuery.of(context).size.height / 6,
                          fit: BoxFit.cover,
                        ),
                      )
                    : Image.asset(
                        'assets/images/no_image.jpg',
                        width: MediaQuery.of(context).size.width,
                        height: MediaQuery.of(context).size.height / 6,
                        fit: BoxFit.cover,
                      )),
            Container(
              padding: FxSpacing.nBottom(8),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Expanded(
                        flex: 5,
                        child: Text(
                          "${_productsList[index].name}",
                          style: TextStyle(
                            color: Colors.black,
                            overflow: TextOverflow.ellipsis,
                            fontWeight: StyleView.fontBold,
                          ),
                        ),
                      ),
                      if (CommonMethods.isPrivillegeExist(
                          context, PrivillegesActions.KEY_PRODUCT_LIST_ITEM))
                        _popupMenuItems(index)
                    ],
                  ),
                  // FxSpacing.height(4),
                  Row(
                    children: [
                      Text(
                        Language().getString(Constants.PRICE, selectedLang),
                        style: TextStyle(
                            color: Colors.black,
                            fontWeight: StyleView.fontMedium),
                      ),
                      Text("  : "),
                      Expanded(
                        child: Text(
                          "$orgCurrencySymbol ${CommonMethods.getAvailablePrice(_productsList[index].batchPrice!)}",
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 12,
                              fontWeight: StyleView.fontRegular),
                        ),
                      )
                    ],
                  ),
                  Row(
                    children: [
                      Text(
                        Language().getString(Constants.QUANTITY, selectedLang),
                        style: TextStyle(
                            color: Colors.black,
                            fontWeight: StyleView.fontMedium),
                      ),
                      Text("  : "),
                      Expanded(
                        child: Text(
                          ("${batchQuantityList[index]} ${_productsList[index].batchPrice!.length > 0 ? _productsList[index].batchPrice![0].quantityIn : "unit"}"),
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 12,
                              fontWeight: StyleView.fontRegular),
                        ),
                      )
                    ],
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _popupMenuItems(int index) {
    return Expanded(
      child: Container(
        alignment: Alignment.topRight,
        child: PopupMenuButton(
            elevation: 5,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(10.0)),
            ),
            onSelected: (dynamic value) {
              CommonMethods.hideKeyboard(context);
              switch (value) {
                case Constants.VIEW:
                  _productController.navigateCardDetails(
                      productId: _productsList[index].id, buId: buId);
                  break;
                case Constants.OFFERS:
                  _productController.navigateOfferDetails(
                      productName: _productsList[index].name,
                      productImage: _productsList[index].images,
                      buId: buId,
                      productId: _productsList[index].id);

                  break;
                case Constants.SUPPLIERS:
                  _productController.navigateSuppliers(
                      productName: _productsList[index].name,
                      productImage: _productsList[index].images,
                      buId: buId,
                      productId: _productsList[index].id);
                  break;
                case Constants.TRANSACTIONS_STR:
                  _productController.navigateProductTransaction(
                      productItem: _productsList[index]);

                  break;
                case Constants.EDIT:
                  _productController.navigateEditProduct(
                      title: Constants.UPDATE_PRODUCT,
                      buId: buId,
                      productId: _productsList[index].id);

                  break;
                case Constants.MOVE_TO_RAW_PRODUCT:
                  this.moveProductToRawmaterial(_productsList[index].id);

                  break;
                case Constants.QUANTITY_ADJUSTMENT:
                  _productController.navigateQuantityAdjustment(
                      productName: _productsList[index].name,
                      buName: currentBuName,
                      buId: _productsList[index].buId,
                      productId: _productsList[index].id);

                  break;
                case Constants.DELETE_STRING:
                  this.deleteProduct(_productsList[index].id);

                  break;
                default:
              }
            },
            icon: Icon(Icons.more_vert),
            itemBuilder: _buildMenuItems),
      ),
    );
  }

  List<PopupMenuEntry<String>> _buildMenuItems(BuildContext context) {
    return [
      if (CommonMethods.isPrivillegeExist(
          context, PrivillegesActions.KEY_PRODUCT_LIST_ITEM_OFFERS))
        PopupMenuItem(
          child: PopupMenuItemDesingView(
            assetPath: "assets/images/offer_icon.png",
            itemName: Language().getString(Constants.OFFERS, selectedLang),
          ),
          value: Constants.OFFERS,
        ),
      if (CommonMethods.isPrivillegeExist(
          context, PrivillegesActions.KEY_PRODUCT_LIST_ITEM_SUPPLIERS))
        PopupMenuItem(
          child: PopupMenuItemDesingView(
            assetPath: "assets/images/supplier_icon.png",
            itemName: Language().getString(Constants.SUPPLIERS, selectedLang),
          ),
          value: Constants.SUPPLIERS,
        ),
      if (CommonMethods.isPrivillegeExist(
          context, PrivillegesActions.KEY_PRODUCT_LIST_ITEM_TRANSACTIONS))
        PopupMenuItem(
          child: PopupMenuItemDesingView(
            assetPath: "assets/images/transaction_icon_product.png",
            itemName:
                Language().getString(Constants.TRANSACTIONS_STR, selectedLang),
          ),
          value: Constants.TRANSACTIONS_STR,
        ),
      if (CommonMethods.isPrivillegeExist(
          context, PrivillegesActions.KEY_PRODUCT_LIST_ITEM_VIEW))
        PopupMenuItem(
          child: PopupMenuItemDesingView(
            assetPath: "assets/images/product_details_icon.png",
            itemName: Language().getString(Constants.VIEW, selectedLang),
          ),
          value: Constants.VIEW,
        ),
      if (CommonMethods.isPrivillegeExist(
          context, PrivillegesActions.KEY_PRODUCT_LIST_ITEM_EDIT))
        PopupMenuItem(
            child: PopupMenuItemDesingView(
              assetPath: "assets/images/edit_image.png",
              itemName: Language().getString(Constants.EDIT, selectedLang),
            ),
            value: Constants.EDIT),
      if (CommonMethods.isPrivillegeExist(context,
          PrivillegesActions.KEY_PRODUCT_LIST_ITEM_MOVE_TO_RAW_MATERIAL))
        PopupMenuItem(
            child: PopupMenuItemDesingView(
              assetPath: "assets/images/move_icon.png",
              itemName: Language()
                  .getString(Constants.MOVE_TO_RAW_PRODUCT, selectedLang),
            ),
            value: Constants.MOVE_TO_RAW_PRODUCT),
      PopupMenuItem(
        child: PopupMenuItemDesingView(
          assetPath: "assets/images/product_details_icon.png",
          itemName:
              Language().getString(Constants.QUANTITY_ADJUSTMENT, selectedLang),
        ),
        value: Constants.QUANTITY_ADJUSTMENT,
      ),
      PopupMenuItem(
        child: PopupMenuItemDesingView(
          assetPath: "assets/images/product_details_icon.png",
          itemName: Language().getString(Constants.DELETE_STRING, selectedLang),
        ),
        value: Constants.DELETE_STRING,
      ),
    ];
  }

  onUpdateDetails(item, index) {
    setState(() {
      selectedIndex = index;
      isUpdateRow = true;
      item.productname = _productNameController.text;
      item.batch_one_quantity = int.parse(_batchoneQuantityController.text);
      item.batch_two_quantity = int.parse(_batchtwoQuantityController.text);
      item.batch_three_quantity = int.parse(_batchthreeQuantityController.text);
      item.batch_one_price = int.parse(_batchonePriceController.text);
      item.batch_two_price = int.parse(_batchtwoPriceController.text);
      item.batch_three_price = int.parse(_batchthreePriceController.text);
    });

    if (isUpdateRow == true && selectedIndex == index) {
      Navigator.of(context).pop();
    }
  }

  showAllInternalConnections() {
    return showDialog(
      barrierColor: Colors.black54,
      barrierDismissible: false,
      context: context,
      builder: (context) => AlertDialog(
        elevation: 100.0,
        contentPadding: EdgeInsets.fromLTRB(15.0, 0, 15.0, 0),
        backgroundColor: Color(0XFFE0E0E0),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(
            Radius.circular(
              7.0,
            ),
          ),
        ),
        actions: [
          Container(
            width: MediaQuery.of(context).size.width,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    child: Text(
                      Language().getString(Constants.STR_CANCEL, selectedLang),
                      style: TextStyle(
                        fontSize: 18.0,
                        color: Color(Constants.APP_COLOR),
                      ),
                    )),
                TextButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                      Navigator.push(
                          context,
                          PageTransition(
                            context: context,
                            page: PlaceConnectionOrderPage(
                              buName: connectionsDropdownValue!.businessName,
                              buId: connectionsDropdownValue!.id,
                              isFromProductList: true,
                            ),
                          )).then((value) => loadProductData());
                      connectionsDropdownValue = null;
                    },
                    child: Text(
                      Language().getString(Constants.OKAY_STR, selectedLang),
                      style: TextStyle(
                        fontSize: 18.0,
                        color: Color(Constants.APP_COLOR),
                      ),
                    ))
              ],
            ),
          )
        ],
        title: Text(
          Language().getString(Constants.INTERNAL_BUSINESS_UNIT, selectedLang),
          style: TextStyle(
            color: Color(Constants.APP_COLOR),
          ),
        ),
        titlePadding: EdgeInsets.fromLTRB(17.0, 24.0, 0.0, 10.0),
        content: StatefulBuilder(
            builder: (BuildContext context, StateSetter setState) {
          return Container(
              height: 50.0,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5.0),
                  border: Border.all(color: Colors.grey)),
              width: MediaQuery.of(context).size.width,
              padding: EdgeInsets.all(5.0),
              child: DropdownButton<BuBasicDataModel>(
                isExpanded: true,
                value: connectionsDropdownValue,
                underline: SizedBox(),
                hint: Text(
                  Language().getString(Constants.SELECT_BU, selectedLang),
                ),
                onChanged: (BuBasicDataModel? newValue) {
                  setState(() {
                    connectionsDropdownValue = newValue;
                  });
                },
                items: _buList.map((BuBasicDataModel value) {
                  return DropdownMenuItem<BuBasicDataModel>(
                    value: value,
                    child: Container(
                        padding: EdgeInsets.all(7.0),
                        child: Text(value.businessName!)),
                  );
                }).toList(),
              ));
        }),
      ),
    );
  }

  Future<List<BuBasicDataModel>> getAllBuBusinessData(String? userId) async {
    _buList.clear();

    String body = json.encode({"id": userId});
    var response = await _organizationService
        .getBulistByUserId(body: body, token: "")
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<BuBasicDataModel> _model = [];
    List<BuBasicDataModel> buList = [];
    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var responseBody = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(responseBody)) {
        for (var noteJson in responseBody) {
          _model.add(BuBasicDataModel.fromJson(noteJson));
        }
        if (_model.length > 0) {
          for (int i = 0; i < _model.length; i++) {
            if (buId != _model[i].id) {
              buList.add(_model[i]);
            }
          }
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }

    return _model;
  }

  deleteProduct(String? productId) async {
    final action = await Dialogs.yesCancelDialog(
        context,
        Language().getString(Constants.INFO, selectedLang),
        Language().getString(Constants.DELETE_PRODUCT_STRING, selectedLang),
        Language().getString(Constants.YES_STRING, selectedLang),
        Language().getString(Constants.STR_CANCEL, selectedLang),
        true);

    if (action == DialogAction.yes) {
      if (await NetworkStatus.getInternetStatus()) {
        setState(() {
          isLoadingProgress = true;
          progressMessage = Constants.LOADING;
        });
        this.serviceCallDeleteProduct(productId);
      } else {
        AppUtills.showSnackBar(_scaffoldkey,
            Language().getString(Constants.NO_INTERNET, selectedLang),
            snackBarBgColor: Colors.black,
            messageColor: Colors.white,
            buttonColor: Colors.white);
      }
    }
  }

  serviceCallDeleteProduct(String? productId) async {
    String body = json.encode({"bu": buId, "id": productId});

    var response = await _productService
        .deleteProduct(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          Language()
              .getString(Constants.PRODUCT_DELETED_SUCCESSFULY, selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);

      if (action == DialogAction.yes) {
        this.loadProductData();
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  moveProductToRawmaterial(String? productId) async {
    final action = await Dialogs.yesCancelDialog(
        context,
        Language().getString(Constants.INFO, selectedLang),
        Language().getString(
            Constants.ARE_YOU_SURE_ADD_PRODUCT_TO_RAW_MATERIAL, selectedLang),
        Language().getString(Constants.OKAY_STR, selectedLang),
        Language().getString(Constants.STR_CANCEL, selectedLang),
        true);

    if (action == DialogAction.yes) {
      if (await NetworkStatus.getInternetStatus()) {
        setState(() {
          isLoadingProgress = true;
          progressMessage = Constants.SENDING_PRODUCTS;
        });
        this.serviceCallMoveProductsToRaw(productId);
      } else {
        AppUtills.showSnackBar(_scaffoldkey,
            Language().getString(Constants.NO_INTERNET, selectedLang),
            snackBarBgColor: Colors.black,
            messageColor: Colors.white,
            buttonColor: Colors.white);
      }
    }
  }

  serviceCallMoveProductsToRaw(String? productId) async {
    String body = json.encode({"bu": buId, "id": productId, "type": 2});

    var response = await _productService
        .productConvert(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          Language().getString(
              Constants.PRODUCT_ADDED_SUCCESSFULY_TO_RAW_MATERIAL,
              selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);

      if (action == DialogAction.yes) {
        this.loadProductData();
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  showProductOffersView(int index) {
    List<OffersDAO> isOfferExist = _productsList[index]
        .offers!
        .where((element) => !element.isOfferExpired!)
        .toList();
    if (isOfferExist.length > 0) {
      return Container(
          child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: InkWell(
            onTap: () {
              _productController.navigateOfferDetails(
                  productName: _productsList[index].name,
                  productImage:
                      (_productsList[index].imageThumbnail!.length > 0)
                          ? _productsList[index].imageThumbnail![0].image
                          : null,
                  buId: buId,
                  productId: _productsList[index].id);
            },
            child: Text(Language().getString(Constants.OFFERS, selectedLang),
                style: TextStyle(
                    color: StyleView.offerColor,
                    decoration: TextDecoration.underline))),
      ));
    } else {
      return Container();
    }
  }

  showCreateProductOptions() {
    if (CommonMethods.isPrivillegeExist(
        context, PrivillegesActions.KEY_PRODUCT_LIST_ADD)) {
      return Container(
        child: PopupMenuButton(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(10.0))),
            onSelected: (dynamic value) async {
              CommonMethods.hideKeyboard(context);
              switch (value) {
                case Constants.CREATE_FROM_ORG:
                  copyAnotherBuProducts();
                  break;
                case Constants.CREATE_FOR:
                  if (CommonMethods.isPrivillegeExist(
                      context, PrivillegesActions.KEY_MENU_ONDC_TAB)) {
                    Navigator.push(
                        context,
                        PageTransition(
                          context: context,
                          page: OndcEditMyProductPage(
                            title: Language()
                                .getString(Constants.ADD_PRODUCT, selectedLang),
                            buId: buId, // AppController.instance.getMyBuId,
                          ),
                        )).then((value) => loadProductData());
                  } else {
                    Navigator.push(
                        context,
                        PageTransition(
                          context: context,
                          page: EditMyProductPage(
                            title: Language()
                                .getString(Constants.ADD_PRODUCT, selectedLang),
                            buId: buId, //AppController.instance.getMyBuId,
                          ),
                        )).then((value) => loadProductData());
                  }
                  break;
                case Constants.PRODUCTS_IN_BUILK:
                  var data = VyaparInfo.encryptData(json.encode({"id": buId}));
                  AppUtills.launchURL(
                      '${Constants.URL_BULK_PRODUCTS_UPLOAD}products/bulkupload/$data');
                  break;

                default:
              }
            },
            icon: Icon(Icons.add),
            itemBuilder: _buildOptions),
      );
    } else {
      return SizedBox();
    }
  }

  List<PopupMenuEntry<String>> _buildOptions(BuildContext context) {
    return [
      if (CommonMethods.isPrivillegeExist(
          context, PrivillegesActions.KEY_PRODUCT_LIST_ADD_FOR_BU))
        PopupMenuItem(
          child: Row(
            children: [
              Icon(
                Icons.add,
                color: Color(
                  Constants.APP_COLOR,
                ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: Text(
                    Language().getString(Constants.CREATE_FOR, selectedLang) +
                        " ${AppController.instance.getBuName}",
                    style: TextStyle(
                        fontSize: 14.0, color: Color(Constants.APP_COLOR)),
                  ),
                ),
              ),
            ],
          ),
          value: Constants.CREATE_FOR,
        ),
      if (CommonMethods.isPrivillegeExist(
          context, PrivillegesActions.KEY_PRODUCT_LIST_COPY_FROM_BU))
        PopupMenuItem(
          child: Row(
            children: [
              Icon(
                Icons.copy,
                color: Color(
                  Constants.APP_COLOR,
                ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: Text(
                    Language()
                        .getString(Constants.CREATE_FROM_ORG, selectedLang),
                    style: TextStyle(
                        fontSize: 14.0, color: Color(Constants.APP_COLOR)),
                  ),
                ),
              ),
            ],
          ),
          value: Constants.CREATE_FROM_ORG,
        ),
      if (CommonMethods.isPrivillegeExist(
          context, PrivillegesActions.KEY_PRODUCT_LIST_BY_BULK_UPLOAD))
        PopupMenuItem(
          child: Row(
            children: [
              Icon(
                Icons.import_export,
                color: Color(
                  Constants.APP_COLOR,
                ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: Text(
                    Language()
                        .getString(Constants.PRODUCTS_IN_BUILK, selectedLang),
                    style: TextStyle(
                        fontSize: 14.0, color: Color(Constants.APP_COLOR)),
                  ),
                ),
              ),
            ],
          ),
          value: Constants.PRODUCTS_IN_BUILK,
        ),
    ];
  }

  void copyAnotherBuProducts() {
    setState(() => isLoadingProgress = true);
    getAllBuBusinessData(userId).then((value) {
      for (int i = 0; i < value.length; i++) {
        if (value[i].id != AppController.instance.getMyBuId) {
          setState(() {
            _buList.add(value[i]);
          });
        }
      }

      if (_buList.length > 0) {
        showAllInternalConnections();
      } else {
        Dialogs.yesCancelDialog(
            context,
            Language().getString(Constants.INFO, selectedLang),
            Language().getString(Constants.NO_BUSINESS_UNITS, selectedLang),
            Language().getString(Constants.OKAY_STR, selectedLang),
            "",
            false);
      }
    });
  }
}
