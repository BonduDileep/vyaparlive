import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/TextView.dart';
import 'package:vyaparlive/model/PriceModel.dart';
import 'package:flutter/material.dart';

class PriceDetailsExpandPage extends StatelessWidget {
  final String? strManufactureDate;
  final String? strExpireDate;
  final String? strBatchNumber;
  final String? strPrice;
  final String? strNetRate;
  final String? strMrp;
  final String? strUnitPrice;
  final String? strCurrencyName;
  final String? strQuantity;
  final String? strQuantityIn;
  final bool isEdit;
  final String? title;
  final PriceModel? priceModel;
  final VoidCallback? editPage;
  final VoidCallback? removeItem;
  final bool? rawMaterial;
  final bool? actualProduct;
  final String? issuedTo;
  final bool isFromProdutPage;
  final String? strRawMaterialIssueNoteId;
  final String? strPurchasedProducts;
  final String? strManufacturerHouse;

  PriceDetailsExpandPage(
      {this.editPage,
      this.removeItem,
      this.strBatchNumber,
      this.strExpireDate,
      this.strManufactureDate,
      this.strPrice,
      this.strCurrencyName,
      this.strMrp,
      this.strNetRate,
      this.strUnitPrice,
      this.isEdit = false,
      this.priceModel,
      this.title,
      this.strQuantity,
      this.strQuantityIn,
      this.actualProduct,
      this.issuedTo,
      this.rawMaterial,
      this.isFromProdutPage = false,
      this.strRawMaterialIssueNoteId,
      this.strManufacturerHouse,
      this.strPurchasedProducts});
  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
            flex: 10,
            child: (isFromProdutPage)
                ? this.showExpansionTileView()
                : this.showContainerView()),
        // (isEdit)
        //     ? Expanded(
        //         flex: 1,
        //         child: Container(
        //           child: IconButton(
        //               icon: Icon(
        //                 Icons.remove_circle_outline,
        //                 color: Colors.red,
        //               ),
        //               onPressed: () => removeItem()),
        //         ),
        //       )
        //     : Container(),
      ],
    );
  }

  showTitleView(
    String? title,
    String? value,
  ) {
    return Container(
        child: RichText(
      text: TextSpan(
        children: <TextSpan>[
          TextSpan(
              text: title,
              style: TextStyle(
                  fontSize: 15.0,
                  fontFamily: StyleView.FONT_TITLE,
                  color: Colors.black,
                  fontWeight: FontWeight.bold)),
          TextSpan(
            text: " : $value",
            style: TextStyle(
              fontSize: 13.0,
              fontFamily: StyleView.FONT_TITLE,
              color: Colors.black,
            ),
          )
        ],
      ),
    ));
  }

  _buildSupplierListItem(PriceModel priceModel) {
    return Container(
      child: Container(
        padding: EdgeInsets.all(1),
        child: Column(
          children: <Widget>[
            Visibility(
                visible: isFromProdutPage,
                child: Column(
                  children: [
                    TextView(
                        title: strNetRate! +
                            "  " +
                            AppController.instance.getBuCurrencySymbol,
                        value: priceModel.netRate),
                    TextView(
                        title: strMrp! +
                            "  " +
                            AppController.instance.getBuCurrencySymbol,
                        value: priceModel.mrp),
                    TextView(
                        title: strManufactureDate,
                        value: priceModel.manufacturDate),
                    TextView(
                      title: strExpireDate,
                      value: priceModel.expireDate,
                    ),
                    priceModel.isRawMaterial!
                        ? TextView(
                            title: strManufacturerHouse,
                            value: Constants.YES_STRING,
                          )
                        : Container(),
                    priceModel.isActualProduct!
                        ? TextView(
                            title: strPurchasedProducts,
                            value: Constants.YES_STRING,
                          )
                        : Container(),
                    (priceModel.issueNumber != null)
                        ? showRawMaterialIssueNoteId(
                            "${priceModel.issueNumber}")
                        : Container(),
                  ],
                ))
          ],
        ),
      ),
    );
  }

  Widget showRawMaterialIssueNoteId(String id) {
    return TextView(
      title: strRawMaterialIssueNoteId,
      value: id,
    );
  }

  showExpansionTileView() {
    return Container(
        decoration: AppUtills.boxDecoration(),
        child: ExpansionTile(
          title: Row(children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  this.showTitleView(strBatchNumber, title),
                  this.showTitleView(
                      strPrice,
                      AppController.instance.getBuCurrencySymbol +
                          " ${priceModel!.price}"),
                  this.showTitleView(strQuantity,
                      priceModel!.quantity! + " " + priceModel!.quantityIn!)
                ],
              ),
            ),
            (isEdit)
                ? new Container(
                    child: InkWell(
                        child:
                            Icon(Icons.edit, color: Color(Constants.APP_COLOR)),
                        onTap: () => editPage!()))
                : Container(),
          ]),
          children: <Widget>[
            _buildSupplierListItem(priceModel!),
          ],
        ));
  }

  showContainerView() {
    return Container(
      decoration: AppUtills.boxDecoration(),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Row(children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                this.showTitleView(strBatchNumber, title),
                this.showTitleView(
                    strPrice,
                    AppController.instance.getBuCurrencySymbol +
                        " ${priceModel!.price}"),
                this.showTitleView(strQuantity,
                    priceModel!.quantity! + " " + priceModel!.quantityIn!)
              ],
            ),
          ),
          (isEdit)
              ? new Container(
                  child: InkWell(
                      child:
                          Icon(Icons.edit, color: Color(Constants.APP_COLOR)),
                      onTap: () => editPage!()))
              : Container(),
        ]),
      ),
    );
  }
}
