import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:toast/toast.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/Dialog.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/service/Service.dart';
import 'package:vyaparlive/service/product_services.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:vyaparlive/utills/barcode/BarcodePopup.dart';
import 'package:vyaparlive/utills/barcode/BarcodeScanPage.dart';
import 'package:vyaparlive/utills/barcode/PrintBarcode.dart';

Future<Map<String, dynamic>?> showAddProductPopup(BuildContext context) async {
  return showDialog<Map<String, dynamic>>(
    context: context,
    builder: (BuildContext context) {
      return AddProductPopup();
    },
  );
}

class AddProductPopup extends StatefulWidget {
  @override
  _AddProductPopupState createState() => _AddProductPopupState();
}

class _AddProductPopupState extends State<AddProductPopup> {
  String? selectedLang = AppController.instance.getSelectedlanguage;

  final TextEditingController _productNameController = TextEditingController();
  final TextEditingController _quantityController = TextEditingController();
  final TextEditingController _netRateController = TextEditingController();
  final TextEditingController _salePriceController = TextEditingController();
  final TextEditingController _mrpController = TextEditingController();
  final TextEditingController _gstController = TextEditingController();
  final TextEditingController _batchNumberController = TextEditingController();
  final TextEditingController _hsnCodeController = TextEditingController();
  final TextEditingController _barcodeController = TextEditingController();

  String? unitDropdownValue;
  String? taxDropdownValue;
  String? rateDropdownValue;

  File? imageFile;
  Uint8List? _webImage;
  bool isImageUpdated = false;
  String? imageBlob = '';
  late Service _service;
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  String imageRelativePath = '';
  late ProductService _productService;

  @override
  void initState() {
    super.initState();
    _service = Service();
    _productService = ProductService();
    _batchNumberController.text = DateFormat('yyyy/MM').format(DateTime.now());
  }

  @override
  void dispose() {
    _productNameController.dispose();
    _quantityController.dispose();
    _netRateController.dispose();
    _salePriceController.dispose();
    _mrpController.dispose();
    _gstController.dispose();
    _batchNumberController.dispose();
    _hsnCodeController.dispose();
    _barcodeController.dispose();
    super.dispose();
  }

  void _pickImage() async {
    if (kIsWeb) {
      final _file = await Dialogs.getWebImage();
      if (_file != null) {
        final bytes = await _file.readAsBytes();
        setState(() {
          _webImage = bytes;
          isImageUpdated = true;
        });
        uploadImage(_webImage, "web_product_image.png");
      }
    } else {
      Dialogs.openBottomSheet(
        context: context,
        openCamera: (myPicture) {
          Navigator.of(context).pop();
          if (myPicture != null) {
            setState(() {
              imageFile = myPicture;
              isImageUpdated = true;
            });
            uploadImage(imageFile, "");
          }
        },
        openGallery: (myPicture) {
          Navigator.of(context).pop();
          if (myPicture != null) {
            setState(() {
              imageFile = myPicture;
              isImageUpdated = true;
            });
            uploadImage(imageFile, "");
          }
        },
      );
    }
  }

  updateProductImage(var fileImage) {
    Navigator.of(context).pop();
    if (fileImage != null) {
      setState(() {
        imageFile = fileImage;
        isImageUpdated = true;
        imageBlob = AppUtills.getBase64Image(fileImage, context);
      });
      uploadImage(imageFile, "");
    }
  }

  uploadImage(dynamic imageData, String fileName) async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = "Fetching..";
    });
    Map data = {
      "filename": (kIsWeb) ? fileName : imageData.path.split("/").last,
      "location": "product"
    };
    String body = json.encode(data);

    http.Response response = await _service
        .getPresignedUrl(body); //_service.get_file_upload_url(null);

    if (response.statusCode == 200) {
      var responseBody = json.decode(response.body);
      setState(() {
        progressMessage = "Uploading image..";
      });
      print('relative path ${responseBody['relativepath']}');

      var uploadFileRes =
          await _service.uploadToS3Signed(responseBody['url'], imageData);
      print(uploadFileRes);
      setState(() {
        imageRelativePath = responseBody['relativepath'];
        isLoadingProgress = false;
      });
      Toast.show(
        "File uploaded!",
        duration: Toast.lengthShort,
        gravity: Toast.bottom,
      );

      // this.submitInputData(relativePath: responseBody['relativepath']);
    } else {
      setState(() {
        isLoadingProgress = false;
      });
    }
  }

  void addProduct() async {
    List<String> tax = [];
    if (rateDropdownValue != null) {
      tax = rateDropdownValue!.split(" %");
    } else {
      tax.add("0");
    }

    List<Map<String, dynamic>> batchPriceArray = [];

    var batchPriceObject = {
      "price": double.parse(_salePriceController.text),
      "unit": unitDropdownValue,
      "currency_code": "",
      "currency_name": "",
      "batch_number": DateFormat('yyyy/MM').format(DateTime.now()),
      "quantity": num.parse(_quantityController.text),
      "quantity_in": unitDropdownValue,
      "net_rate": double.parse(_netRateController.text),
      "mrp": double.parse(_mrpController.text),
      "barcode": _barcodeController.text
    };

    batchPriceArray.add(batchPriceObject);

    var data = {
      "bu_id": AppController.instance.myBuId,
      "name": _productNameController.text,
      "type": "product",
      "in_stock": true,
      "for_sale": true,
      "batch_pricing": batchPriceArray,
      "tax": {
        "type": taxDropdownValue != null ? taxDropdownValue : "GST",
        "value": int.parse(tax[0]),
        "hsn_code": _hsnCodeController.text
      },
      "images": imageRelativePath
    };

    String body = "";
    body = json.encode(data);
    var response = await _productService.createQuickProduct_grpc(
        body: body, token: AppController.instance.authorizationKey!);

    setState(() {
      isLoadingProgress = false;
    });

    if (response != null) {
      isImageUpdated = false;
      GRPCResponse _grpcResponse = response;
      if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
        var responseBody = json.decode(_grpcResponse.message!);
        final action = await Dialogs.yesCancelDialog(
            context,
            Language().getString(Constants.SUCCESS, selectedLang),
            Language().getString(
                (Language().getString(
                    Constants.PRODUCT_ADDED_SUCCESS_FULLY_ALERT_STRING,
                    selectedLang)),
                selectedLang),
            Language().getString(Constants.OKAY_STR, selectedLang),
            "",
            false);
        if (action == DialogAction.yes) {
          Navigator.of(context).pop(responseBody);
        }
      } else {
        Dialogs.yesCancelDialog(
            context,
            Language().getString(Constants.ERROR, selectedLang),
            _grpcResponse.message,
            Language().getString(Constants.OKAY_STR, selectedLang),
            "",
            false);
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          "$response",
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  Widget _buildTextField(String label, TextEditingController controller,
      {bool isNumber = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextField(
        controller: controller,
        keyboardType: isNumber
            ? TextInputType.numberWithOptions(decimal: true)
            : TextInputType.text,
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(),
          isDense: true,
        ),
      ),
    );
  }

  Widget _buildDropdown(String label, List<String> items, String? value,
      ValueChanged<String?> onChanged) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: DropdownButtonFormField<String>(
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(),
          isDense: true,
        ),
        value: value,
        items: items.map((String item) {
          return DropdownMenuItem<String>(
            value: item,
            child: Text(item),
          );
        }).toList(),
        onChanged: onChanged,
      ),
    );
  }

  Widget _buildImagePicker() {
    return GestureDetector(
      onTap: _pickImage,
      child: Container(
        height: 120,
        width: 120,
        decoration: BoxDecoration(
          color: Colors.grey[200],
          border: Border.all(color: Colors.grey),
          borderRadius: BorderRadius.circular(8),
        ),
        child: _webImage != null
            ? Image.memory(_webImage!, fit: BoxFit.cover)
            : imageFile != null
                ? Image.file(imageFile!, fit: BoxFit.cover)
                : Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.camera_alt, color: Colors.grey, size: 40),
                      SizedBox(height: 5),
                      Text("Add Image",
                          style: TextStyle(color: Colors.grey, fontSize: 12)),
                    ],
                  ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    bool isMobile = width < 600;

    return AlertDialog(
      title: Text("Add Product", style: TextStyle(fontWeight: FontWeight.bold)),
      content: Container(
        width: isMobile ? width * 0.9 : 600,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildImagePicker(),
              SizedBox(height: 16),
              _buildTextField("Product Name *", _productNameController),
              Row(
                children: [
                  Expanded(
                      child: _buildTextField("Quantity *", _quantityController,
                          isNumber: true)),
                  SizedBox(width: 8),
                  Expanded(
                      child: _buildDropdown(
                          "Unit *",
                          Constants.UNIT_PRICE,
                          unitDropdownValue,
                          (val) => setState(() => unitDropdownValue = val))),
                ],
              ),
              Row(
                children: [
                  Expanded(
                      child: _buildTextField("Net Rate *", _netRateController,
                          isNumber: true)),
                  SizedBox(width: 8),
                  Expanded(
                      child: _buildTextField(
                          "Sale Price *", _salePriceController,
                          isNumber: true)),
                ],
              ),
              Row(
                children: [
                  Expanded(
                      child: _buildTextField("MRP *", _mrpController,
                          isNumber: true)),
                  SizedBox(width: 8),
                  Expanded(
                    child: _buildTextField("HSN Code", _hsnCodeController),
                  ), //  _buildTextField("Batch Number",
                  // _batchNumberController)),
                ],
              ),
              Row(
                children: [
                  Expanded(
                      child: _buildDropdown(
                          "Tax",
                          Constants.taxTypes,
                          taxDropdownValue,
                          (val) => setState(() => taxDropdownValue = val))),
                  SizedBox(width: 8),
                  Expanded(
                      child: _buildDropdown(
                          "Rate",
                          Constants.taxRateValues,
                          rateDropdownValue,
                          (val) => setState(() => rateDropdownValue = val))),
                ],
              ),
              // _buildTextField("Batch Number", _batchNumberController),
              // _buildTextField("HSN Code", _hsnCodeController),
              Row(
                children: [
                  Expanded(
                    child: _buildTextField("Barcode", _barcodeController),
                  ),
                  IconButton(
                    icon: Icon(Icons.qr_code,
                        color: Theme.of(context).primaryColor),
                    onPressed: showBarcodePopup,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
      actions: [
        CommonButtonsView(
          context: context,
          b1Text: Language().getString(Constants.STR_CANCEL, selectedLang) ??
              "Cancel",
          b2Text: Language().getString(Constants.ADD, selectedLang) ?? "Add",
          onb1Action: () => Navigator.of(context).pop(),
          onb2Action: () async {
            // Validation can go here
            if (_productNameController.text.isEmpty) {
              // Show error
              showError(Constants.PLEASE_ENTER_PRODUCT_NAME);
              return;
            }
            if (_quantityController.text.isEmpty) {
              showError(Constants.PLEASE_ENTER_QUANTITY);
              return;
            }
            if (unitDropdownValue == null) {
              showError("Please Select Unit");
              return;
            }

            if (_netRateController.text.isEmpty) {
              showError(Constants.PLEASE_ENTER_NET_RATE);
              return;
            }
            if (_salePriceController.text.isEmpty) {
              showError(Constants.PLEASE_ENTER_PRICE);
              return;
            }
            if (_mrpController.text.isEmpty) {
              showError(Constants.PLEASE_ENTER_MRP);
              return;
            }
            // Map<String, dynamic> productData = {
            //   "productName": _productNameController.text,
            //   "quantity": _quantityController.text,
            //   "netRate": _netRateController.text,
            //   "salePrice": _salePriceController.text,
            //   "mrp": _mrpController.text,
            //   "unit": unitDropdownValue,
            //   "gst": _gstController.text,
            //   "tax": taxDropdownValue,
            //   "rate": rateDropdownValue,
            //   "batchNumber": _batchNumberController.text,
            //   "hsnCode": _hsnCodeController.text,
            //   "barcode": _barcodeController.text,
            //   "imageFile": imageFile,
            //   "webImage": _webImage,
            // };
            // Navigator.of(context).pop(productData);
            if (await NetworkStatus.getInternetStatus()) {
              setState(() {
                isLoadingProgress = true;
                progressMessage =
                    Language().getString(Constants.ADD_PRODUCT, selectedLang);
              });

              addProduct();
            } else {
              Toast.show(
                Language().getString(Constants.NO_INTERNET, selectedLang) ??
                    "No Internet",
                duration: Toast.lengthShort,
                gravity: Toast.bottom,
                backgroundColor: Colors.red,
              );
            }
          },
        ),
      ],
    );
  }

  void showError(String message) {
    // Toast.show(
    //   message,
    //   duration: Toast.lengthShort,
    //   gravity: Toast.bottom,
    //   backgroundColor: Colors.red,
    // );

    Dialogs.yesCancelDialog(
        context,
        Language().getString(Constants.ERROR, selectedLang),
        message,
        Language().getString(Constants.OKAY_STR, selectedLang),
        "",
        false);
  }

  void showBarcodePopup() {
    showDialog(
      context: context,
      builder: (_) {
        return BarcodePopup(
          barcode: _barcodeController.text,
          productName: _productNameController.text,
          price: _salePriceController.text,
          onScan: () => scanAndAssign(context),
          onGenerate: () => generateAndAssign(),
        );
      },
    );
  }

  void generateAndAssign() {
    String barcode = DateTime.now().millisecondsSinceEpoch.toString();
    setState(() {
      _barcodeController.text = barcode;
    });
  }

  void scanAndAssign(BuildContext context) async {
    final scannedCode = await Navigator.push<String>(
      context,
      MaterialPageRoute(builder: (_) => BarcodeScanPage()),
    );

    if (scannedCode != null && scannedCode.isNotEmpty) {
      setState(() {
        _barcodeController.text = scannedCode;
      });
    }
  }
}
