import 'dart:convert';
import 'dart:io';

import 'package:vyaparlive/core/enums/privilleges_enum.dart';
import 'package:vyaparlive/service/organization_service.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutx/utils/utils.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Product/NonSelectableProducts.dart';
import 'package:vyaparlive/Product/suppliers_view/SupplierExpandedPage.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/connections_view/ConnectionsBuDetails.dart';
import 'package:vyaparlive/model/ConnectionsBuDAO.dart';
import 'package:vyaparlive/model/Contacts.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/product_model/ProductModel.dart';
import 'package:vyaparlive/model/SupplierModel.dart';
import 'package:vyaparlive/service/invitation_services.dart';
import 'package:vyaparlive/service/product_services.dart';

import '../../model/BuListModel.dart';
import '../../service/api_service/InvitationApiService.dart';

class SupplierPage extends StatefulWidget {
  final String? productImage;
  final String? productName;
  final String? buId;
  final String? productId;
  SupplierPage(
      {this.productImage, this.productName, this.buId, this.productId});
  @override
  _SupplierPageState createState() => _SupplierPageState();
}

class _SupplierPageState extends State<SupplierPage> {
  final _supCityController = new TextEditingController();
  final _supDistrictController = new TextEditingController();

  final _supLocalityController = new TextEditingController();
  final _supPnhController = new TextEditingController();
  List<SupplierModel> _supplierList = [];
  List<Contacts> _connectionsList = [];
  List<ConnectionsBuDAO> _connectionDetails = [];
  Contacts? connectionDropdownValue;
  EdgeInsetsGeometry dialogTitlePadding =
      EdgeInsets.fromLTRB(17.0, 24.0, 24.0, 5.0);
  late ProductService _productService;

  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  late InvitationService _invitationService;
  late OrganizationService _organizationService;
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    _invitationService = InvitationService();
    _productService = ProductService();
    _organizationService = new OrganizationService();
    theme = AppTheme.vyaparTheme;
    loadProductData();
    loadConnectionData();
  }

  loadConnectionData() async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
      });
      this.getContacts(widget.buId).then((value) {
        _connectionsList.clear();
        _connectionsList.addAll(value);
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  loadProductData() async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
      });
      this.getProuctById().then((suppllierList) {
        if (suppllierList.length > 0) {
          for (int i = 0; i < suppllierList[0].suppliers!.length; i++) {
            setState(() {
              _supplierList.add(SupplierModel(
                  id: suppllierList[0].suppliers![i].id,
                  name: suppllierList[0].suppliers![i].name,
                  city: suppllierList[0].suppliers![i].city,
                  district: suppllierList[0].suppliers![i].district,
                  locality: suppllierList[0].suppliers![i].locality,
                  contact: suppllierList[0].suppliers![i].phoneNo));
            });
          }
        }
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  loadUpdateSupplier() async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
        progressMessage =
            Language().getString(Constants.SUPPLIER_DATA, selectedLang);
      });
      this.serviceCallUpdateSupplier();
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  _aspectRatio() {
    if (kIsWeb || Platform.isWindows) {
      return MediaQuery.of(context).size.width /
          MediaQuery.of(context).size.height *
          2;
    } else {
      return MediaQuery.of(context).size.width /
          MediaQuery.of(context).size.height *
          2;
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
      body: Stack(
        children: [
          SafeArea(
            child: Scaffold(
              key: _scaffoldkey,
              backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
              appBar: AppBar(
                backgroundColor: Colors.transparent, //(Constants.APP_COLOR),
                centerTitle: true,
                elevation: 0,
                iconTheme: IconThemeData(color: theme.colorScheme.primary),
                title: AppbarName(
                    title: Language()
                        .getString(Constants.PRODUCT_SUPPLIER, selectedLang),
                    buName: "${widget.productName}"),
                actions: [
                  AppUtills.homeButton(context),
                ],
              ),
              bottomNavigationBar: (_supplierList.length > 0)
                  ? Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: CommonButtonsView(
                        context: context,
                        b1TextColor: Colors.white,
                        iconColor: Colors.white,
                        b2Text: "",
                        b1Text: Language()
                            .getString(Constants.UPDATE_STRING, selectedLang),
                        onb1Action: () {
                          this.loadUpdateSupplier();
                        },
                      ),
                    )
                  : null,
              body: Container(
                margin: EdgeInsets.symmetric(vertical: 5.0, horizontal: 10.0),
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      Card(
                        elevation: 5.0,
                        child: Container(
                            width: MediaQuery.of(context).size.width,
                            // padding: EdgeInsets.all(10.5),
                            // margin: EdgeInsets.symmetric(vertical: 10.5),
                            child: (widget.productImage == null)
                                ? AspectRatio(
                                    aspectRatio: _aspectRatio(),
                                    child: ClipRRect(
                                        borderRadius: BorderRadius.only(
                                            bottomLeft: Radius.circular(10),
                                            bottomRight: Radius.circular(10)),
                                        child: Image.asset(
                                          'assets/images/no_image.jpg',
                                          gaplessPlayback: true,
                                          fit: BoxFit.contain,
                                        )))
                                : AppUtills.imageAspectRatio(widget.productImage,
                                    aspectRatio: _aspectRatio(),
                                    context: context)),
                      ),
                      Container(
                        margin: EdgeInsets.symmetric(
                          vertical: 20.0,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            mainText(
                              Language()
                                  .getString(Constants.SUPPLIERS_C, selectedLang),
                            ),
                            if (CommonMethods.isPrivillegeExist(
                                context,
                                PrivillegesActions
                                    .KEY_PRODUCT_LIST_ITEM_SUPPLIERS_ADD))
                              InkWell(
                                onTap: () {
                                  this.promptSupplierFields(
                                      false, SupplierModel(), -1);
                                },
                                child: Container(
                                  margin: EdgeInsets.only(right: 5),
                                  decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.grey,
                                          blurRadius: 5.0,
                                        ),
                                      ]),
                                  child: ClipOval(
                                    child: Material(
                                      color: Color(Constants.APP_COLOR),
                                      child: SizedBox(
                                          width: 25.0,
                                          height: 25.0,
                                          child: Icon(Icons.add,
                                              size: 13.0, color: Colors.white)),
                                    ),
                                  ),
                                ),
                              )
                          ],
                        ),
                      ),
                      SizedBox(height: StyleView.HEIGHT_10),
                      Container(
                        child: _supplierList.length == 0
                            ? new Container(
                                child: Center(
                                  child: Text(
                                    Language().getString(
                                        Constants.HAVE_NO_SUPPLIERS,
                                        selectedLang),
                                    style: TextStyle(
                                        fontWeight: StyleView.fontSemiBold),
                                  ),
                                ),
                              )
                            : _createDynamicSupplierTable(),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          AppUtills.showLoadingView(
              context: context,
              message: Language().getString(progressMessage, selectedLang),
              isLoading: isLoadingProgress),
        ],
      ),
    );
  }

  promptSupplierFields(
      bool isSupplierUpdate, SupplierModel _suppliersData, int index) {
    if (isSupplierUpdate) {
      if (_connectionsList.length > 0) {
        for (int i = 0; i < _connectionsList.length; i++) {
          if (_suppliersData.name == _connectionsList[i].buName) {
            connectionDropdownValue = _connectionsList[i];
          }
        }
      }

      _supCityController.text = _suppliersData.city!;
      _supDistrictController.text = _suppliersData.district!;
      _supLocalityController.text = _suppliersData.locality!;
      _supPnhController.text = _suppliersData.contact!;
    } else {
      connectionDropdownValue = null;
      _supLocalityController.clear();
      _supCityController.clear();
      _supDistrictController.clear();
      _supPnhController.clear();
    }
    return showDialog(
      barrierDismissible: false,
      context: context,
      barrierColor: Colors.black54,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (context, StateSetter setState) {
            return AlertDialog(
              elevation: 100.0,
              contentPadding: EdgeInsets.fromLTRB(15.0, 0, 15.0, 0),
              backgroundColor: Colors.white, //(0XFFE0E0E0),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(
                  Radius.circular(
                    7.0,
                  ),
                ),
              ),
              titlePadding: dialogTitlePadding,
              title: Text(
                isSupplierUpdate
                    ? Language()
                        .getString(Constants.UPDATE_SUPPLIER, selectedLang)
                    : Language()
                        .getString(Constants.ADD_SUPPLIER, selectedLang),
                style: TextStyle(
                    color: theme.colorScheme.primary,
                    fontSize: StyleView.FONT_SIZE_18,
                    fontFamily: StyleView.FONT_TITLE),
              ),
              actions: [
                Container(
                    width: MediaQuery.of(context).size.width,
                    padding: EdgeInsets.symmetric(vertical: 10),
                    child: CommonButtonsView(
                      context: context,
                      b1Text: Language()
                          .getString(Constants.STR_CANCEL, selectedLang),
                      b2Text: (isSupplierUpdate)
                          ? Language()
                              .getString(Constants.UPDATE_STRING, selectedLang)
                          : Language()
                              .getString(Constants.STR_SAVE, selectedLang),
                      onb1Action: () {
                        Navigator.of(context).pop();
                      },
                      onb2Action: () {
                        String errorMessage = validatingMandatoryFields();
                        if (errorMessage.isNotEmpty) {
                          Dialogs.yesCancelDialog(
                              context,
                              Language()
                                  .getString(Constants.ERROR, selectedLang),
                              errorMessage,
                              Language()
                                  .getString(Constants.OKAY_STR, selectedLang),
                              "",
                              false);
                        } else {
                          this.saveSupplierDataList(isSupplierUpdate, index);
                        }
                      },
                    )),
              ],
              content: Container(
                margin: EdgeInsets.symmetric(
                  vertical: 5.0,
                ),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Container(
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey),
                            borderRadius: BorderRadius.circular(
                              5.0,
                            ),
                            color: Colors.white70,
                          ),
                          padding: EdgeInsets.only(left: 5, right: 5),
                          child: DropdownButton<Contacts>(
                              onTap: () {
                                FocusScope.of(context).unfocus();
                              },
                              isExpanded: true,
                              hint: Text(
                                Language().getString(
                                    Constants.SELECT_CONNECTION, selectedLang),
                              ),
                              underline: SizedBox(),
                              items: _connectionsList.map((Contacts contact) {
                                return DropdownMenuItem<Contacts>(
                                  value: contact,
                                  child: new Text(
                                    contact.isOnline
                                        ? contact.buName!
                                        : "${contact.buName!} (Offline)",
                                    style: TextStyle(
                                        fontFamily: StyleView.FONT_TITLE),
                                  ),
                                );
                              }).toList(),
                              value: connectionDropdownValue,
                              onChanged: (Contacts? contacts) {
                                setState(() {
                                  connectionDropdownValue = contacts;
                                  this.renderConnectionData(setState);
                                });
                              })),
                      FxSpacing.height(10),
                      buildOffersInputFields(
                          Language()
                              .getString(Constants.CONTACT_NAME, selectedLang),
                          false,
                          _supPnhController,
                          false),
                      FxSpacing.height(10),
                      buildOffersInputFields(
                          Language().getString(
                              Constants.COLONY_SELECTOR_AREA_LOCALITY_STRING,
                              selectedLang),
                          false,
                          _supLocalityController,
                          false),
                      FxSpacing.height(10),
                      buildOffersInputFields(
                          Language().getString(
                              Constants.DISTRICT_STRING, selectedLang),
                          false,
                          _supDistrictController,
                          false),
                      FxSpacing.height(10),
                      buildOffersInputFields(
                          Language().getString(
                              Constants.CITY_NAME_STRING, selectedLang),
                          false,
                          _supCityController,
                          false),
                      FxSpacing.height(10),
                      this.renderSupplierDetails(),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  String validatingMandatoryFields() {
    if (connectionDropdownValue == null) {
      return Language()
          .getString(Constants.PLEASE_SELECT_CONNECTION, selectedLang);
    } else {
      return "";
    }
  }

  renderConnectionData(StateSetter setState) async {
    if (await NetworkStatus.getInternetStatus()) {
      if (connectionDropdownValue!.isOnline) {
        this.getBuDetails(connectionDropdownValue!.buId).then((value) {
          setState(() {
            _connectionDetails.addAll(value);
            if (_connectionDetails.length > 0 &&
                _connectionDetails[0].contactDetails != null &&
                _connectionDetails[0].contactDetails!.address != null) {
              _supPnhController.text = _connectionDetails[0].contactNumber!;

              _supLocalityController.text = _connectionDetails[0]
                  .contactDetails!
                  .address!
                  .colonysectorArealocality!;
              _supDistrictController.text =
                  _connectionDetails[0].contactDetails!.address!.district!;

              _supCityController.text = _connectionDetails[0]
                  .contactDetails!
                  .address!
                  .villagetowncity!;
            }
          });
        });
      } else {
        _supPnhController.text = connectionDropdownValue!.contactNumber!;

        _supLocalityController.text = connectionDropdownValue!
            .address!
            .colonysectorArealocality!;
        _supDistrictController.text =
            connectionDropdownValue!.address!.district!;

        _supCityController.text = connectionDropdownValue!
                  .address!
                  .villagetowncity!;
      }
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  renderSupplierDetails() {
    if (connectionDropdownValue != null) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          InkWell(
            onTap: () {
              Navigator.push(
                  context,
                  new MaterialPageRoute(
                      builder: (context) => NonSelectableProducts(
                            buId: connectionDropdownValue!.buId,
                            buName: connectionDropdownValue!.buName,
                          )));
            },
            child: Container(
              child: Text(
                Language()
                    .getString(Constants.SUPPLIER_PRODUCTS_STR, selectedLang),
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: StyleView.fontMedium,
                  color: theme.colorScheme.primary,
                  decoration: TextDecoration.underline,
                ),
              ),
            ),
          ),
          SizedBox(height: 10),
          InkWell(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ConnectionsBuDetailsPage(
                      connectionId: connectionDropdownValue!.id,
                      buName: connectionDropdownValue!.buName,
                      buId: connectionDropdownValue!.buId),
                ),
              );
            },
            child: Container(
              child: Text(
                Language().getString(Constants.SUPPLIER_DETAILS, selectedLang),
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: StyleView.fontMedium,
                  color: theme.colorScheme.primary,
                  decoration: TextDecoration.underline,
                ),
              ),
            ),
          ),
        ],
      );
    } else {
      return Container();
    }
  }

  saveSupplierDataList(bool isUpdateSupplier, int updateSupplierIndex) {
    if (isUpdateSupplier) {
      _supplierList[updateSupplierIndex] = SupplierModel(
          id: connectionDropdownValue != null
              ? connectionDropdownValue!.buId
              : "",
          name: connectionDropdownValue != null
              ? connectionDropdownValue!.buName
              : "",
          city: _supCityController.text,
          district: _supDistrictController.text,
          locality: _supLocalityController.text,
          contact: _supPnhController.text);
      setState(() {
        _supplierList.reversed;
      });
    } else {
      _supplierList.add(SupplierModel(
          id: connectionDropdownValue != null
              ? connectionDropdownValue!.buId
              : "",
          name: connectionDropdownValue != null
              ? connectionDropdownValue!.buName
              : "",
          city: _supCityController.text,
          district: _supDistrictController.text,
          locality: _supLocalityController.text,
          contact: _supPnhController.text));
      setState(() {
        _supplierList.reversed;
      });
    }

    Navigator.of(context).pop();
  }

  Future<List<ConnectionsBuDAO>> getBuDetails(String? connectionId) async {
    _connectionDetails.clear();
    String body = json.encode({"id": connectionId});
    var response = await _organizationService
        .getOrganizationDataById(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
        AppController.instance.setCreateBuProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
      AppController.instance.setCreateBuProgress = false;
    });
    List<ConnectionsBuDAO> _list = [];

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(resObj)) {
        _list.add(ConnectionsBuDAO.fromJson(resObj[0]));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
      return _list;
  }

  buildOffersInputFields(String? _labelText, bool isKeyboard,
      TextEditingController controller, bool isEnabled) {
    return Container(
      margin: EdgeInsets.symmetric(
        vertical: 5.0,
      ),
      color: Colors.white,
      child: TextField(
        enabled: isEnabled,
        keyboardType: isKeyboard ? TextInputType.number : TextInputType.text,
        style: TextStyle(fontFamily: StyleView.FONT_TITLE),
        controller: controller,
        decoration: StyleView.getInputDecoration(
          helper: _labelText,
        ),
        // focusNode: FocusNode(canRequestFocus: false),
      ),
    );
  }

  _createDynamicSupplierTable() {
    return Column(children: <Widget>[
      for (int i = 0; i < _supplierList.length; i++)
        Container(
          margin: EdgeInsets.symmetric(
            vertical: 5.0,
          ),
          child: Column(children: [
            SupplierExpandedPage(
              strCity: Language()
                  .getString(Constants.CITY_NAME_STRING, selectedLang),
              strDistrict:
                  Language().getString(Constants.DISTRICT_STRING, selectedLang),
              strLocality: Language().getString(
                  Constants.COLONY_SELECTOR_AREA_LOCALITY_STRING, selectedLang),
              strContactNum:
                  Language().getString(Constants.CONTACT_NUMBER, selectedLang),
              title: Language().getString(Constants.SUPPLIER, selectedLang) +
                  " : ${_supplierList[i].name}",
              supplierModel: _supplierList[i],
              editPage: () {
                this.promptSupplierFields(true, _supplierList[i], i);
              },
              removeItem: () async {
                final action = await Dialogs.removeItem(
                  context,
                  _supplierList[i].name,
                  Language().getString(Constants.WARNING, selectedLang),
                  Language().getString(Constants.WARNING_TEXT, selectedLang),
                  cancel:
                      Language().getString(Constants.STR_CANCEL, selectedLang),
                  yes: Language().getString(Constants.YES_STRING, selectedLang),
                );

                if (action == DialogAction.yes) {
                  setState(() {
                    _supplierList.removeAt(i);
                  });
                  loadUpdateSupplier();
                }
              },
              isItemEdit: true,
            )
          ]),
        )
    ]);
  }

  mainText(String text) {
    return Container(
        child: Text(
      text,
      style: TextStyle(
          fontSize: 15.0,
          letterSpacing: 2.0,
          fontFamily: StyleView.FONT_TITLE,
          color: Colors.grey[800],
          fontWeight: FontWeight.bold),
    ));
  }

  Future<List<BuProductModal>> getProuctById() async {
    setState(() {
      _supplierList.clear();
    });

    String body = json.encode({"id": widget.productId, "buId": widget.buId});

    var response = await _productService
        .getProductDetailsByProductId_grpc(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<BuProductModal> data = [];

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      data.add(BuProductModal.fromJson(resObj[0]));
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
      return data;
  }

  serviceCallUpdateSupplier() async {
    List<Map<String, dynamic>> supplierArray = [];
    var supplierObject;

    if (_supplierList.length > 0) {
      for (int i = 0; i < _supplierList.length; i++) {
        supplierObject = {
          "name": _supplierList[i].name,
          "id": _supplierList[i].id,
          "city": _supplierList[i].city,
          "district": _supplierList[i].district,
          "colonysector_arealocality": _supplierList[i].locality,
          "contact_number": _supplierList[i].contact
        };
        supplierArray.add(supplierObject);
      }
    }
    Map data = {
      "id": widget.productId,
      "buId": widget.buId,
      "suppliers": supplierArray
    };
    String body = json.encode(data);

    var response = await _productService
        .updateProductSuppliers_grpc(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      loadProductData();
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  Future<List<Contacts>> getContacts(String? buId) async {
    setState(() {
      _connectionsList.clear();
    });
    String body = json.encode({"buId": buId, "filters": {}});

    List<Contacts> _model = [];
    Map<String, dynamic> mapData = {"name": ""};
    List<BuListModel> fetchOfflineUsers = await InvitationApiService.instance
        .getOfflineUsersByBuId(
            context: context,
            buId: buId!,
            mapData: mapData,
            langError: Language().getString(Constants.ERROR, selectedLang),
            langOk: Language().getString(Constants.OKAY_STR, selectedLang));

    for (var i = 0; i < fetchOfflineUsers.length; i++) {
      var element = fetchOfflineUsers[i];
      Contacts contacts = new Contacts();
      contacts.buId = element.recordId;
      contacts.buName = element.name;
      contacts.contactNumber = element.contact;
      contacts.city =
          element.address != null && element.address!.villagetowncity != null
              ? element.address!.villagetowncity
              : "";
      contacts.isOnline = false;
      contacts.address = element.address!;
      _model.add(contacts);
    }

    var response = await _invitationService
        .findAllConnections_grpc(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      if (resObj is String) {
        print("No Online connections found");
      } else {
        for (var noteJson in resObj['results']) {
          _model.add(Contacts.fromJson(noteJson));
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
      return _model;
  }
}
