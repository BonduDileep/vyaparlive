import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/TextView.dart';
import 'package:vyaparlive/model/SupplierModel.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';

class SupplierExpandedPage extends StatelessWidget {
  final String? title;
  final String? strContactNum;
  final String? strLocality;
  final String? strCity;
  final String? strDistrict;
  final SupplierModel? supplierModel;
  final VoidCallback? editPage;
  final VoidCallback? removeItem;
  final bool isItemEdit;
  SupplierExpandedPage(
      {this.editPage,
      this.removeItem,
      this.strDistrict,
      this.strCity,
      this.strLocality,
      this.strContactNum,
      this.supplierModel,
      this.title,
      this.isItemEdit = false});
  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          flex: 10,
          child: Container(
              decoration: AppUtills.boxDecoration(
                  customContainerColor: Colors.white,
                  customBorderColor:
                      AppTheme.theme.colorScheme.primaryContainer),
              child: ExpansionTile(
                title: Row(children: [
                  Expanded(
                    child: Text(
                      "$title",
                      style: TextStyle(fontWeight: StyleView.fontSemiBold),
                    ),
                  ),
                  if (isItemEdit)
                    new Container(
                        child: InkWell(
                            child: Icon(FeatherIcons.edit,
                                size: 18,
                                color: AppTheme.theme.colorScheme.primary),
                            onTap: () => editPage!()))
                ]),
                children: <Widget>[
                  _buildSupplierListItem(supplierModel!),
                ],
              )),
        ),
        (isItemEdit)
            ? Expanded(
                flex: 1,
                child: Container(
                  child: IconButton(
                      icon: Icon(
                        Icons.remove_circle_outline,
                        color: Colors.red,
                      ),
                      onPressed: () => removeItem!()),
                ),
              )
            : Container(),
      ],
    );
  }

  _buildSupplierListItem(SupplierModel _supplierModel) {
    return Container(
        child: Container(
            padding: EdgeInsets.all(1),
            child: Column(
              children: <Widget>[
                TextView(
                  title: "$strContactNum",
                  value: _supplierModel.contact,
                ),
                TextView(
                  title: "$strLocality",
                  value: _supplierModel.locality,
                ),
                TextView(
                  title: "$strDistrict",
                  value: _supplierModel.district,
                ),
                TextView(
                  title: "$strCity",
                  value: _supplierModel.city,
                )
              ],
            )));
  }
}
