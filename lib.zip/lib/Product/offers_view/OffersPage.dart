import 'dart:convert';
import 'dart:io';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Product/offers_view/OfferExpandedPage.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/OffersModel.dart';
import 'package:vyaparlive/model/product_model/ProductModel.dart';
import 'package:vyaparlive/service/product_services.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';

class OffersPage extends StatefulWidget {
  final String? productName;
  final String? productImage;

  final String? buId;
  final String? productId;

  OffersPage({this.productImage, this.productName, this.buId, this.productId});
  @override
  _OffersPageState createState() => _OffersPageState();
}

class _OffersPageState extends State<OffersPage> {
  final _offerNameController = new TextEditingController();
  final _offerQtyController = new TextEditingController();
  final _detailsController = new TextEditingController();
  DateTime offerStartDate = DateTime.now();
  DateTime offerEndDate = DateTime.now();
  DateTime offerSupplyTime = DateTime.now();
  DateTime releaseDate = DateTime.now();
  DateFormat formatter = DateFormat("yyyy-MM-dd");
  String? formatttedOfferStartDate = "";
  String? formattedOfferEndDate = "";
  bool isOfferActive = false;
  String? offerRadioValue;
  String? offerChooice;
  String? maxOrderDropdownValue;
  String? minOrderDropdownValue;
  String? offerInPercentage;
  EdgeInsetsGeometry dialogTitlePadding =
      EdgeInsets.fromLTRB(17.0, 24.0, 24.0, 5.0);
  List<OffersModel> _offersList = [];
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  bool isOfferAvailable = false;
  late ProductService _productService;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    _productService = ProductService();
    theme = AppTheme.vyaparTheme;
    loadProductData();
  }

  loadProductData() async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
      });
      this.getProuctById().then((productList) {
        if (productList.length > 0) {
          if (productList[0].offers!.length > 0) {
            for (int i = 0; i < productList[0].offers!.length; i++) {
              setState(() {
                isOfferAvailable = true;
                _offersList.add(OffersModel(
                    offerName: productList[0].offers![i].offerName ?? "",
                    offerQuantity: productList[0].offers![i].offerQuantity ?? 0,
                    minOrder: productList[0].offers![i].minOrder ?? 0,
                    maxOrder: productList[0].offers![i].maxOrder ?? 0,
                    startDate: productList[0].offers![i].startDate ?? "",
                    endDate: productList[0].offers![i].endDate ?? "",
                    details: productList[0].offers![i].details ?? "",
                    offerDiscount: productList[0].offers![i].offerType ?? "",
                    isOfferActive:
                        productList[0].offers![i].isOfferActive ?? false,
                    isOfferExpired:
                        productList[0].offers![i].isOfferExpired ?? false));
              });
            }
          } else {
            setState(() {
              isOfferAvailable = false;
            });
          }
        }
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  _aspectRatio() {
    if (kIsWeb || Platform.isWindows) {
      return MediaQuery.of(context).size.width /
          MediaQuery.of(context).size.height *
          2;
    } else {
      return MediaQuery.of(context).size.width /
          MediaQuery.of(context).size.height *
          2;
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
      body: Stack(
        children: [
          SafeArea(
            child: Scaffold(
                key: _scaffoldkey,
                backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                appBar: AppBar(
                  iconTheme: IconThemeData(color: theme.colorScheme.primary),
                  elevation: 0,
                  backgroundColor: Colors.transparent, //(Constants.APP_COLOR),
                  centerTitle: true,
                  title: AppbarName(
                      title: Language()
                          .getString(Constants.PRODUCT_OFFERS, selectedLang),
                      buName: widget.productName),
                  actions: [
                    AppUtills.homeButton(context),
                  ],
                ),
                bottomNavigationBar: (isOfferAvailable)
                    ? Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: CommonButtonsView(
                          context: context,
                          b1TextColor: Colors.white,
                          iconColor: Colors.white,
                          b1Text: Language()
                              .getString(Constants.SAVE_CHANGES, selectedLang),
                          b2Text: "",
                          onb1Action: () async {
                            if (await NetworkStatus.getInternetStatus()) {
                              setState(() {
                                isLoadingProgress = true;
                                progressMessage = Language().getString(
                                    Constants.OFFER_DATA, selectedLang);
                              });
                              this.serviceCallOfferUpdate();
                            } else {
                              AppUtills.showSnackBar(
                                  _scaffoldkey,
                                  Language().getString(
                                      Constants.NO_INTERNET, selectedLang),
                                  snackBarBgColor: Colors.black,
                                  messageColor: Colors.white,
                                  buttonColor: Colors.white);
                            }
                          },
                        ),
                      )
                    : null,
                body: LayoutBuilder(
                    builder: (BuildContext context, BoxConstraints constraints) {
                  return Container(
                    margin: EdgeInsets.symmetric(
                      vertical: 5.0,
                      horizontal: 10.0,
                    ),
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          Card(
                            elevation: 5.0,
                            child: Container(
                                width: MediaQuery.of(context).size.width,
                                // padding: EdgeInsets.all(10.5),
                                // margin: EdgeInsets.symmetric(vertical: 10.5),
                                child: (widget.productImage == null)
                                    ? AspectRatio(
                                        aspectRatio: _aspectRatio(),
                                        child: ClipRRect(
                                            borderRadius: BorderRadius.only(
                                                bottomLeft: Radius.circular(10),
                                                bottomRight: Radius.circular(10)),
                                            child: Image.asset(
                                              'assets/images/no_image.jpg',
                                              gaplessPlayback: true,
                                              fit: BoxFit.contain,
                                            )))
                                    : AppUtills.imageAspectRatio(
                                        widget.productImage,
                                        aspectRatio: _aspectRatio(),
                                        context: context)),
                          ),
                          Container(
                            margin: EdgeInsets.symmetric(
                              vertical: 20.0,
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                mainText(Language()
                                    .getString(Constants.OFFERS_C, selectedLang)),
                                InkWell(
                                  onTap: () {
                                    promptOffersFields(false, OffersModel(), -1);
                                  },
                                  child: Container(
                                    margin: EdgeInsets.only(right: 5),
                                    decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        boxShadow: [
                                          BoxShadow(
                                            color: Colors.grey,
                                            blurRadius: 5.0,
                                          ),
                                        ]),
                                    child: ClipOval(
                                      child: Material(
                                        color:
                                            Colors.black, //(Constants.APP_COLOR),
                                        child: SizedBox(
                                            width: 25.0,
                                            height: 25.0,
                                            child: Icon(Icons.add,
                                                size: 18.0, color: Colors.white)),
                                      ),
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                          SizedBox(
                            height: StyleView.HEIGHT_10,
                          ),
                          Container(
                            child: _offersList.length == 0
                                ? new Container(
                                    child: Center(
                                      child: Text(
                                        Language().getString(
                                            Constants.HAVE_NO_OFFERS,
                                            selectedLang),
                                        style: TextStyle(
                                            fontWeight: StyleView.fontSemiBold),
                                      ),
                                    ),
                                  )
                                : _createDynamicOfferTable(),
                          )
                        ],
                      ),
                    ),
                  );
                })),
          ),
          AppUtills.showLoadingView(
              context: context,
              message: Language().getString(progressMessage, selectedLang),
              isLoading: isLoadingProgress),
        ],
      ),
    );
  }

  _createDynamicOfferTable() {
    return Column(children: <Widget>[
      for (int i = 0; i < _offersList.length; i++)
        Container(
            margin: EdgeInsets.symmetric(
              vertical: 5.0,
            ),
            child: Column(
              children: [
                OfferExpandedPage(
                  strOfferExpired: Language()
                      .getString(Constants.OFFER_EXPIRED, selectedLang),
                  title: Language().getString(Constants.OFFER, selectedLang) +
                      " : ${_offersList[i].offerName}",
                  offersModel: _offersList[i],
                  editPage: () {
                    promptOffersFields(true, _offersList[i], i);
                  },
                  removeItem: () async {
                    final action = await Dialogs.yesCancelDialog(
                        context,
                        Language().getString(Constants.WARNING, selectedLang),
                        Language().getString(
                            '${Constants.WARNING_TEXT} ${_offersList[i].offerName}?',
                            selectedLang),
                        Language()
                            .getString(Constants.YES_STRING, selectedLang),
                        Language()
                            .getString(Constants.STR_CANCEL, selectedLang),
                        true);

                    if (action == DialogAction.yes) {
                      setState(() {
                        _offersList.removeAt(i);
                        this.serviceCallOfferUpdate();
                      });
                    }
                  },
                  isItemEdit: true,
                  strActive: Language()
                      .getString(Constants.ACTIVE_STRING, selectedLang),
                  strDetails:
                      Language().getString(Constants.DETAILS, selectedLang),
                  strEndDate:
                      Language().getString(Constants.END_DATE, selectedLang),
                  strStartDate:
                      Language().getString(Constants.START_DATE, selectedLang),
                  strMaximumOrder:
                      Language().getString(Constants.MAX_ORDER, selectedLang),
                  strMinimumOrder:
                      Language().getString(Constants.MIN_ORDER, selectedLang),
                  strOfferInAmount: Language()
                      .getString(Constants.OFFER_IN_AMOUNT, selectedLang),
                  strOfferInPercentage: Language()
                      .getString(Constants.OFFER_IN_PERCENTAGE, selectedLang),
                  strOfferName:
                      Language().getString(Constants.OFFER_NAME, selectedLang),
                  strOfferQuantity:
                      Language().getString(Constants.OFFER_QTY, selectedLang),
                ),
              ],
            ))
    ]);
  }

  mainText(String text) {
    return Container(
        child: Text(
      text,
      style: TextStyle(
          fontSize: 15.0,
          letterSpacing: 2.0,
          color: Colors.grey[800],
          fontWeight: StyleView.fontBold),
    ));
  }

  promptOffersFields(bool isUpdateOffers, OffersModel _offersData, int index) {
    if (isUpdateOffers) {
      _offerNameController.text = _offersData.offerName!;

      formatttedOfferStartDate = _offersData.startDate;
      formattedOfferEndDate = _offersData.endDate;

      _detailsController.text = _offersData.details!;

      if (_offersData.isOfferActive!) {
        isOfferActive = true;
      }
      if (_offersData.offerDiscount == Constants.OFFER_IN_PERCENTAGE) {
        String offerQuantity = "${_offersData.offerQuantity}" + " %";
        offerRadioValue = Constants.OFFER_IN_PERCENTAGE;
        for (int i = 0; i < Constants.PERCENTAGELIST.length; i++) {
          if (offerQuantity == Constants.PERCENTAGELIST[i]) {
            offerInPercentage = Constants.PERCENTAGELIST[i];
          }
        }
      } else if (_offersData.offerDiscount == Constants.OFFER_IN_AMOUNT) {
        offerRadioValue = Constants.OFFER_IN_AMOUNT;
        _offerQtyController.text = _offersData.offerQuantity.toString();
      } else {
        offerRadioValue = null;
      }
      for (int i = 0; i < Constants.NUMBEROFDAYS.length; i++) {
        if (_offersData.minOrder.toString() == Constants.NUMBEROFDAYS[i]) {
          minOrderDropdownValue = Constants.NUMBEROFDAYS[i];
        }
      }

      for (int i = 0; i < Constants.NUMBEROFDAYS.length; i++) {
        if (_offersData.maxOrder.toString() == Constants.NUMBEROFDAYS[i]) {
          maxOrderDropdownValue = Constants.NUMBEROFDAYS[i];
        }
      }
    } else {
      _offerNameController.clear();
      _offerQtyController.clear();
      isOfferActive = false;
      offerRadioValue = Constants.OFFER_IN_AMOUNT;
      offerInPercentage = null;
      minOrderDropdownValue = null;
      maxOrderDropdownValue = null;
      formatttedOfferStartDate = formatter.format(offerStartDate);
      formattedOfferEndDate = formatter.format(offerStartDate);

      _detailsController.clear();
    }
    return showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (context, StateSetter setState) {
            return AlertDialog(
              elevation: 100.0,
              contentPadding: EdgeInsets.fromLTRB(15.0, 0, 15.0, 0),
              backgroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(7.0))),
              titlePadding: dialogTitlePadding,
              title: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    isUpdateOffers
                        ? Language()
                            .getString(Constants.UPDATE_OFFER, selectedLang)
                        : Language()
                            .getString(Constants.ADD_OFFER, selectedLang),
                    style: TextStyle(
                        color: theme.colorScheme.primary,
                        fontSize: 20.0,
                        fontFamily: StyleView.FONT_TITLE),
                  ),
                  Container(
                    child: Column(
                      children: [
                        Switch(
                            activeThumbColor: Colors.green,
                            value: isOfferActive,
                            onChanged: (value) {
                              setState(() {
                                isOfferActive = value;
                              });
                            }),
                        Container(
                          child: Text(
                            isOfferActive
                                ? Language().getString(
                                    Constants.ACTIVE_STRING, selectedLang)
                                : Language().getString(
                                    Constants.IN_ACTIVE, selectedLang),
                            style: TextStyle(
                              fontSize: 13.0,
                            ),
                          ),
                        )
                      ],
                    ),
                  )
                ],
              ),
              actions: [
                Container(
                    margin: EdgeInsets.all(10.0),
                    padding: EdgeInsets.symmetric(vertical: 10),
                    width: MediaQuery.of(context).size.width,
                    child: CommonButtonsView(
                      context: context,
                      b1Text: Language()
                          .getString(Constants.STR_CANCEL, selectedLang),
                      b2Text: Language()
                          .getString(Constants.CONTINUE, selectedLang),
                      onb1Action: () {
                        Navigator.of(context).pop();
                      },
                      onb2Action: () {
                        String _errorMessage = validateOfferFields();
                        if (_errorMessage.isNotEmpty) {
                          Dialogs.yesCancelDialog(
                              context,
                              Language()
                                  .getString(Constants.ERROR, selectedLang),
                              Language().getString(_errorMessage, selectedLang),
                              Language()
                                  .getString(Constants.OKAY_STR, selectedLang),
                              "",
                              false);
                        } else {
                          saveOffersDataList(isUpdateOffers, index);
                        }
                      },
                    )),
              ],
              content: Container(
                margin: EdgeInsets.symmetric(vertical: 5.0),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Column(
                        children: [
                          Row(
                            children: [
                              Radio(
                                value: Constants.OFFER_IN_PERCENTAGE,
                                activeColor: Color(Constants.APP_COLOR),
                                groupValue: offerRadioValue,
                                onChanged: (dynamic value) {
                                  setState(() {
                                    offerRadioValue = value;
                                    _offerQtyController.clear();
                                  });
                                },
                              ),
                              Text(Language().getString(
                                  Constants.OFFER_IN_PERCENTAGE, selectedLang)),
                            ],
                          ),
                          Row(
                            children: [
                              Radio(
                                value: Constants.OFFER_IN_AMOUNT,
                                activeColor: Color(Constants.APP_COLOR),
                                groupValue: offerRadioValue,
                                onChanged: (dynamic value) {
                                  setState(() {
                                    offerRadioValue = value;
                                    offerInPercentage = null;
                                  });
                                },
                              ),
                              Text(Language().getString(
                                  Constants.OFFER_IN_AMOUNT, selectedLang)),
                            ],
                          )
                        ],
                      ),
                      buildOffersInputFields(
                          Language()
                              .getString(Constants.OFFER_NAME, selectedLang),
                          false,
                          _offerNameController,
                          true),
                      (offerRadioValue == Constants.OFFER_IN_PERCENTAGE)
                          ? Padding(
                              padding: const EdgeInsets.only(top: 10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    child: Text(
                                      Language().getString(
                                          Constants.PERCENTAGE, selectedLang),
                                      style: TextStyle(
                                        color: Colors.blue,
                                      ),
                                    ),
                                  ),
                                  Container(
                                      margin:
                                          EdgeInsets.symmetric(vertical: 5.0),
                                      height: 50.0,
                                      decoration: BoxDecoration(
                                          color: Colors.white,
                                          border: Border.all(
                                            color: Colors.grey,
                                          ),
                                          borderRadius:
                                              BorderRadius.circular(5.0)),
                                      padding: EdgeInsets.all(5),
                                      child: DropdownButton<String>(
                                          onTap: () {
                                            FocusScope.of(context).unfocus();
                                          },
                                          value: offerInPercentage,
                                          hint: new Text("%"),
                                          isExpanded: true,
                                          underline: SizedBox(),
                                          onChanged: (String? data) {
                                            setState(() {
                                              offerInPercentage = data;
                                            });
                                          },
                                          items: Constants.PERCENTAGELIST
                                              .map((String model) {
                                            return new DropdownMenuItem<String>(
                                              child: new Text(model),
                                              value: model,
                                            );
                                          }).toList())),
                                ],
                              ),
                            )
                          : buildOffersInputFields(
                              Language().getString(
                                  Constants.OFFER_VALUE, selectedLang),
                              true,
                              _offerQtyController,
                              true),
                      Container(
                          padding: EdgeInsets.only(top: 10, bottom: 5),
                          child: Text(
                            Language()
                                .getString(Constants.MIN_ORDER, selectedLang),
                            style: TextStyle(
                              color: Colors.blue,
                            ),
                          )),
                      Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            border: Border.all(
                              color: Colors.grey,
                            ),
                            borderRadius: BorderRadius.circular(5.0),
                          ),
                          padding: EdgeInsets.all(5),
                          child: DropdownButton<String>(
                              onTap: () {
                                FocusScope.of(context).unfocus();
                              },
                              value: minOrderDropdownValue,
                              hint: new Text(
                                Language().getString(
                                    Constants.MIN_ORDER, selectedLang),
                              ),
                              isExpanded: true,
                              underline: SizedBox(),
                              onChanged: (String? data) {
                                setState(() {
                                  minOrderDropdownValue = data;
                                });
                              },
                              items: Constants.NUMBEROFDAYS.map((String model) {
                                return new DropdownMenuItem<String>(
                                  child: new Text(model),
                                  value: model,
                                );
                              }).toList())),
                      Container(
                        padding: EdgeInsets.only(top: 10, bottom: 5),
                        child: Text(
                          Language()
                              .getString(Constants.MAX_ORDER, selectedLang),
                          style: TextStyle(
                            color: Colors.blue,
                          ),
                        ),
                      ),
                      Container(
                          margin: EdgeInsets.symmetric(vertical: 5.0),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            border: Border.all(
                              color: Colors.grey,
                            ),
                            borderRadius: BorderRadius.circular(5.0),
                          ),
                          padding: EdgeInsets.all(5),
                          child: DropdownButton<String>(
                              onTap: () {
                                FocusScope.of(context).unfocus();
                              },
                              value: maxOrderDropdownValue,
                              hint: new Text(
                                Language().getString(
                                    Constants.MAX_ORDER, selectedLang),
                              ),
                              isExpanded: true,
                              underline: SizedBox(),
                              onChanged: (String? data) {
                                setState(() {
                                  maxOrderDropdownValue = data;
                                });
                              },
                              items: Constants.NUMBEROFDAYS.map((String model) {
                                return new DropdownMenuItem<String>(
                                  child: new Text(model),
                                  value: model,
                                );
                              }).toList())),
                      Container(
                          margin: EdgeInsets.symmetric(vertical: 10),
                          decoration: AppUtills.boxDecoration(),
                          child: Container(
                              padding: EdgeInsets.all(1),
                              child: Row(
                                children: <Widget>[
                                  Expanded(
                                    child: Container(
                                        height: 50,
                                        color:
                                            Color(Constants.GREY_COLOR_LIGHT),
                                        child: Container(
                                          padding: EdgeInsets.only(left: 10),
                                          child: Align(
                                              alignment: Alignment.centerLeft,
                                              child: Text(
                                                  Language().getString(
                                                      Constants.START_DATE,
                                                      selectedLang),
                                                  style: TextStyle(
                                                      fontSize: StyleView
                                                          .FONT_SIZE_15,
                                                      fontFamily: StyleView
                                                          .FONT_TITLE))),
                                        )),
                                  ),
                                  Expanded(
                                      flex: 2,
                                      child: Container(
                                        color: Colors.white70,
                                        padding: EdgeInsets.only(left: 5),
                                        alignment: Alignment.topLeft,
                                        child: ElevatedButton(
                                            onPressed: () async {
                                              String value = await AppUtills
                                                  .getSelectedDate(context,
                                                      isShowIntialDate: true);
                                              setState(() {
                                                formatttedOfferStartDate =
                                                    value;
                                              });
                                            },
                                            style: ElevatedButton.styleFrom(
                                              backgroundColor: Colors.white,
                                              elevation: 0.0,
                                            ),
                                            child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: <Widget>[
                                                Text(
                                                  formatttedOfferStartDate!,
                                                  style: TextStyle(
                                                      color: Colors.black),
                                                ),
                                                Image.asset(
                                                  'assets/images/calander.png',
                                                  height: 30,
                                                )
                                              ],
                                            )),
                                      )),
                                ],
                              ))),
                      Container(
                          margin: EdgeInsets.symmetric(vertical: 10.0),
                          decoration: AppUtills.boxDecoration(),
                          child: Container(
                              padding: EdgeInsets.all(1),
                              child: Row(
                                children: <Widget>[
                                  Expanded(
                                    child: Container(
                                        height: 50,
                                        color:
                                            Color(Constants.GREY_COLOR_LIGHT),
                                        child: Container(
                                          padding: EdgeInsets.only(left: 10),
                                          child: Align(
                                              alignment: Alignment.centerLeft,
                                              child: Text(
                                                  Language().getString(
                                                      Constants.END_DATE,
                                                      selectedLang),
                                                  style: TextStyle(
                                                      fontSize: StyleView
                                                          .FONT_SIZE_15,
                                                      fontFamily: StyleView
                                                          .FONT_TITLE))),
                                        )),
                                  ),
                                  Expanded(
                                      flex: 2,
                                      child: Container(
                                        color: Colors.white70,
                                        padding: EdgeInsets.only(left: 5),
                                        alignment: Alignment.topLeft,
                                        child: ElevatedButton(
                                            onPressed: () async {
                                              String value = await AppUtills
                                                  .getSelectedDate(context,
                                                      isShowIntialDate: true);
                                              setState(() {
                                                formattedOfferEndDate = value;
                                              });
                                            },
                                            style: ElevatedButton.styleFrom(
                                              backgroundColor: Colors.white,
                                              elevation: 0.0,
                                            ),
                                            child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: <Widget>[
                                                Text(
                                                  formattedOfferEndDate!,
                                                  style: TextStyle(
                                                      color: Colors.black),
                                                ),
                                                Image.asset(
                                                  'assets/images/calander.png',
                                                  height: 30,
                                                )
                                              ],
                                            )),
                                      )),
                                ],
                              ))),
                      buildOffersInputFields(
                          Language()
                              .getString(Constants.OFFER_DETAILS, selectedLang),
                          false,
                          _detailsController,
                          true),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  buildOffersInputFields(String? _labelText, bool isKeyboard,
      TextEditingController controller, bool isEnabled) {
    return Container(
      margin: EdgeInsets.symmetric(
        vertical: 5.0,
      ),
      color: Colors.white,
      child: TextField(
          enabled: isEnabled,
          keyboardType: isKeyboard
              ? TextInputType.numberWithOptions(signed: true, decimal: false)
              : TextInputType.text,
          style: TextStyle(fontFamily: StyleView.FONT_TITLE),
          controller: controller,
          textInputAction: TextInputAction.next,
          decoration: StyleView.getInputDecoration(
            helper: _labelText,
          ),
          inputFormatters: (isKeyboard)
              ? [CommonMethods.inputTextFormatter(isNumber: true)]
              : []
          // focusNode: FocusNode(canRequestFocus: false),
          ),
    );
  }

  saveOffersDataList(bool isUpdateOffers, int updateOfferIndex) {
    if (isUpdateOffers) {
      if (isOfferActive) {
        this.updateOfferStatus(updateOfferIndex);
      }
      List<String> splitPercentage = [];
      if (offerRadioValue == Constants.OFFER_IN_PERCENTAGE &&
          offerInPercentage != null) {
        splitPercentage = offerInPercentage!.split(" %");
      } else {
        splitPercentage.add(_offerQtyController.text);
      }
      _offersList[updateOfferIndex] = OffersModel(
          offerName: _offerNameController.text,
          offerQuantity: double.parse(splitPercentage[0]),
          minOrder: int.parse(
              minOrderDropdownValue != null ? minOrderDropdownValue! : "1"),
          maxOrder: int.parse(
              maxOrderDropdownValue != null ? maxOrderDropdownValue! : "1"),
          startDate: formatttedOfferStartDate,
          endDate: formattedOfferEndDate,
          isOfferActive: isOfferActive,
          offerDiscount: offerRadioValue,
          details: _detailsController.text,
          isOfferExpired: _offersList[updateOfferIndex].isOfferExpired);
      setState(() {
        _offersList.reversed;
        isOfferAvailable = true;
      });
    } else {
      formatttedOfferStartDate = formatter.format(offerStartDate);
      // formattedOfferEndDate = formatter.format(offerEndDate);
      List<String> splitPercentage = [];
      if (offerRadioValue == Constants.OFFER_IN_PERCENTAGE &&
          offerInPercentage != null) {
        splitPercentage = offerInPercentage!.split(" %");
      } else {
        splitPercentage.add(_offerQtyController.text);
      }
      _offersList.add(OffersModel(
          offerName: _offerNameController.text,
          offerQuantity: double.parse(splitPercentage[0]),
          minOrder: int.parse(
              minOrderDropdownValue != null ? minOrderDropdownValue! : "1"),
          maxOrder: int.parse(
              maxOrderDropdownValue != null ? maxOrderDropdownValue! : "1"),
          startDate: formatttedOfferStartDate,
          endDate: formattedOfferEndDate,
          isOfferActive: isOfferActive,
          offerDiscount: offerRadioValue,
          details: _detailsController.text));
      setState(() {
        _offersList.reversed;
        isOfferAvailable = true;
        if (isOfferActive) {
          this.updateOfferStatus(_offersList.length - 1);
        }
      });
    }
    Navigator.of(context).pop();
  }

  Future<List<BuProductModal>> getProuctById() async {
    _offersList.clear();

    String body = json.encode({"id": widget.productId, "buId": widget.buId});

    var response = await _productService
        .getProductDetailsByProductId_grpc(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<BuProductModal> data = [];

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      data.add(BuProductModal.fromJson(resObj[0]));
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
      return data;
  }

  serviceCallOfferUpdate() async {
    List<Map<String, dynamic>> offerArray = [];
    var offerObject;
    if (_offersList.length > 0) {
      List<String> splitOffer = [];
      for (int i = 0; i < _offersList.length; i++) {
        if (_offersList[i].offerDiscount == Constants.OFFER_IN_PERCENTAGE) {
          splitOffer = _offersList[i].offerQuantity.toString().split(" %");
        } else {
          splitOffer.add(_offersList[i].offerQuantity.toString());
        }
        offerObject = {
          "offer_name": _offersList[i].offerName,
          "offer_quantity": _offersList[i].offerQuantity,
          "min_order": _offersList[i].minOrder,
          "max_order": _offersList[i].maxOrder,
          "start_date": _offersList[i].startDate,
          "end_date": _offersList[i].endDate,
          "details": _offersList[i].details,
          "is_offer_active": _offersList[i].isOfferActive,
          "offer_type": _offersList[i].offerDiscount
        };
        offerArray.add(offerObject);
      }
    }
    Map data = {
      "id": widget.productId,
      "buId": widget.buId,
      "offers": offerArray
    };
    String body = json.encode(data);

    // http.Response
    var response = await
        // _service.updateOffer(body, widget.buId);
        _productService
            .updateProductOffers_grpc(
                body: body, token: AppController.instance.getAuthorizationKey)
            .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      loadProductData();
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  /// Cheking offers active or in-active
  updateOfferStatus(int index) {
    for (int i = 0; i < _offersList.length; i++) {
      if (i == index) {
        setState(() {
          _offersList[i].isOfferActive = true;
        });
      } else {
        setState(() {
          _offersList[i].isOfferActive = false;
        });
      }
    }
  }

  String validateOfferFields() {
    if (_offerNameController.text.isEmpty) {
      return Constants.PLEASE_ENTER_VALID_OFFER_NAME;
    } else if (offerRadioValue == Constants.OFFER_IN_AMOUNT &&
        _offerQtyController.text.isEmpty) {
      return Constants.PLEASE_ENTER_OFFER_VALUE;
    } else if (offerRadioValue == Constants.OFFER_IN_PERCENTAGE &&
        offerInPercentage == null) {
      return Constants.PLEASE_SELECT_OFFER_PERCENTAGE;
    } else {
      return "";
    }
  }
}
