import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/TextView.dart';
import 'package:vyaparlive/model/OffersModel.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';

class OfferExpandedPage extends StatelessWidget {
  final String? title;
  final VoidCallback? editPage;
  final VoidCallback? removeItem;
  final OffersModel? offersModel;
  final bool isItemEdit;
  final String? strActive;
  final String? strOfferName;
  final String? strOfferQuantity;
  final String? strMinimumOrder;
  final String? strMaximumOrder;
  final String? strStartDate;
  final String? strEndDate;
  final String? strDetails;
  final String? strOfferInPercentage;
  final String? strOfferInAmount;
  final String? strOfferExpired;
  final bool? isSSFOffer;
  OfferExpandedPage(
      {this.title,
      this.editPage,
      this.removeItem,
      this.offersModel,
      this.isItemEdit = false,
      required this.strActive,
      required this.strDetails,
      required this.strEndDate,
      required this.strMaximumOrder,
      required this.strMinimumOrder,
      required this.strOfferName,
      required this.strOfferQuantity,
      required this.strStartDate,
      required this.strOfferExpired,
      required this.strOfferInPercentage,
      required this.strOfferInAmount,
      this.isSSFOffer=false});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          flex: 10,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(5.0),
            child: Container(
              decoration: AppUtills.boxDecoration(
                  customContainerColor: Colors.white,
                  customBorderColor:
                      AppTheme.theme.colorScheme.primaryContainer),
              child: ExpansionTile(
                title: Row(children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "$title",
                          style: TextStyle(
                              color: Colors.black,
                              fontWeight: StyleView.fontSemiBold),
                        ),
                        offersModel!.isOfferExpired!
                            ? Text(
                                "$strOfferExpired",
                                style: TextStyle(
                                    color: Colors.red, fontSize: 12.0),
                              )
                            : Container(
                                child: Text(
                                offersModel!.isOfferActive!
                                    ? Constants.ACTIVE_STRING
                                    : Constants.IN_ACTIVE,
                                style: TextStyle(
                                    color: offersModel!.isOfferActive!
                                        ? Colors.green
                                        : Colors.orange,
                                    fontSize: 13.0,
                                    fontWeight: StyleView.fontMedium),
                              )),
                      ],
                    ),
                  ),
                  (isItemEdit)
                      ? new Container(
                          child: InkWell(
                            child: Icon(FeatherIcons.edit,
                                size: 18,
                                color: AppTheme.theme.colorScheme.primary),
                            onTap: () => editPage!(),
                          ),
                        )
                      : Container(),
                ]),
                children: <Widget>[
                  _buildListItem(offersModel!),
                ],
              ),
            ),
          ),
        ),
        (isItemEdit)
            ? Expanded(
                flex: 1,
                child: Container(
                  child: IconButton(
                      icon: Icon(Icons.delete, color: Colors.red),
                      onPressed: () => removeItem!()),
                ),
              )
            : Container()
      ],
    );
  }

  _buildListItem(OffersModel _offerModel) {
    String offerText = "";
    String offerValue = "";
    if (offersModel!.offerDiscount == Constants.OFFER_IN_PERCENTAGE) {
      offerText = strOfferInPercentage!;
      offerValue = "${_offerModel.offerQuantity}" + " %";
    } else {
      offerText = strOfferInAmount!;
      offerValue = "200";
    }
    return Container(
        child: Column(
      children: <Widget>[
        TextView(
          title: strActive,
          value: _offerModel.isOfferActive!
              ? Constants.YES_STRING
              : Constants.NO_STRING,
        ),
        TextView(title: strOfferName, value: _offerModel.offerName),
        TextView(title: offerText, value: "$offerValue"),
        if(isSSFOffer == false) TextView(title: strMinimumOrder, value: "${_offerModel.minOrder}"),
        if(isSSFOffer == false) TextView(title: strMaximumOrder, value: "${_offerModel.maxOrder}"),
        TextView(title: strStartDate, value: _offerModel.startDate),
        TextView(title: strEndDate, value: _offerModel.endDate),
        TextView(title: strDetails, value: _offerModel.details),
      ],
    ));
  }
}
