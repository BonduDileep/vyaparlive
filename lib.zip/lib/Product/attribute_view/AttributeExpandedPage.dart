import 'package:flutter/material.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/StyleView.dart';

class AttributeExpandedPage extends StatelessWidget {
  final String? attributeKey;
  final String? attributeValue;
  final VoidCallback? editPage;
  final VoidCallback? removeItem;

  AttributeExpandedPage(
      {this.attributeKey, this.attributeValue, this.editPage, this.removeItem});
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          flex: 9,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(5.0),
            child: Container(
              decoration: AppUtills.boxDecoration(),
              child: Row(
                children: <Widget>[
                  Expanded(
                    flex: 2,
                    child: Container(
                        height: 50,
                        decoration: BoxDecoration(
                            color: Color(Constants.GREY_COLOR_LIGHT),
                            borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(4.0),
                              bottomLeft: Radius.circular(4.0),
                            )),
                        child: Container(
                          padding: EdgeInsets.only(left: 10),
                          child: Align(
                              alignment: Alignment.centerLeft,
                              child: Text(attributeKey!,
                                  style: TextStyle(
                                      fontSize: StyleView.FONT_SIZE_15,
                                      fontFamily: StyleView.FONT_TITLE))),
                        )),
                  ),
                  Expanded(
                    flex: 5,
                    child: Container(
                        decoration: BoxDecoration(
                            color: Colors.white70,
                            borderRadius: BorderRadius.only(
                              topRight: Radius.circular(4.0),
                              bottomRight: Radius.circular(4.0),
                            )),
                        height: 50,
                        padding: EdgeInsets.only(left: 5),
                        child: Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            attributeValue!,
                            style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                          ),
                        )),
                  ),
                  Expanded(
                    flex: 1,
                    child: Container(
                      alignment: Alignment.centerRight,
                      child: IconButton(
                          icon: Icon(
                            Icons.edit,
                            color: Colors.black, //(Constants.APP_COLOR),
                          ),
                          onPressed: () => editPage!()),
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
        Expanded(
          child: IconButton(
            icon: Icon(
              Icons.delete,
              color: Colors.black,
            ),
            onPressed: () => removeItem!(),
          ),
        )
      ],
    );
  }
}
