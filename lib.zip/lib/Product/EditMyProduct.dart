import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'package:vyaparlive/Product/ProductsMenuPage.dart';
import 'package:vyaparlive/core/enums/privilleges_enum.dart';
import 'package:vyaparlive/product_consumption_view/raw_material_view/RawProductsList.dart';
import 'package:vyaparlive/service/api_service/ProductsApiService.dart';
import 'package:vyaparlive/service/organization_service.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutx/flutx.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Product/NonSelectableProducts.dart';
import 'package:vyaparlive/Product/inventory_view/InventoryLocationBatchView.dart';
import 'package:vyaparlive/Product/price_view/PriceDetailsExpandPage.dart';
import 'package:vyaparlive/Product/attribute_view/AttributeExpandedPage.dart';
import 'package:vyaparlive/Product/inventory_view/InventoryExpandedPage.dart';
import 'package:vyaparlive/Product/offers_view/OfferExpandedPage.dart';
import 'package:vyaparlive/Product/raw_inventory_view/RawInventoryExpandedPage.dart';
import 'package:vyaparlive/Product/suppliers_view/SupplierExpandedPage.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/TextView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/model/CitiesDAO.dart';
import 'package:vyaparlive/model/ConnectionsBuDAO.dart';
import 'package:vyaparlive/model/Contacts.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/BusinessUnitModel.dart';
import 'package:vyaparlive/model/CountryDAO.dart';
import 'package:vyaparlive/model/CurrecyNameDAO.dart';
import 'package:vyaparlive/model/InventoryManagmentModel.dart';
import 'package:vyaparlive/model/PriceModel.dart';
import 'package:vyaparlive/model/ProductCategoryDAO.dart';
import 'package:vyaparlive/model/ProductSegmentDAO.dart';
import 'package:vyaparlive/model/ProductSubCategoryDAO.dart';
import 'package:vyaparlive/model/RawInventory.dart';
import 'package:vyaparlive/model/RawProductsIssueDAO.dart';
import 'package:vyaparlive/model/StatesDAO.dart';
import 'package:vyaparlive/model/OffersModel.dart';
import 'package:vyaparlive/model/ProductAttributeModel.dart';
import 'package:vyaparlive/model/ProductConditionModel.dart';
import 'package:vyaparlive/model/product_model/BatchPriceDAO.dart';
import 'package:vyaparlive/model/product_model/InventoryDetailsDAO.dart';
import 'package:vyaparlive/model/product_model/ProductModel.dart';
import 'package:vyaparlive/model/ProductSubType.dart';
import 'package:vyaparlive/model/SupplierModel.dart';
import 'package:vyaparlive/model/bu_model/LocationsModel.dart';
import 'package:vyaparlive/model/product_model/ProductSectorDAO.dart';
import 'package:vyaparlive/model/product_model/QuantityAdjustmentDAO.dart';
import 'package:vyaparlive/service/Service.dart';
import 'package:vyaparlive/connections_view/ConnectionsBuDetails.dart';
import 'package:vyaparlive/service/invitation_services.dart';
import 'package:vyaparlive/service/product_services.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:vyaparlive/utills/SharePref.dart';
import 'package:toast/toast.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/barcode/BarcodePopup.dart';
import 'package:vyaparlive/utills/barcode/BarcodeScanPage.dart';
import 'package:vyaparlive/utills/barcode/BarcodeWidget.dart';
import 'package:vyaparlive/utills/barcode/PrintBarcode.dart';
import '../product_consumption_view/consumable_goods_view/ConsumableProductsList.dart';
import 'dialog/CategoryDialog.dart';
import 'dialog/ProductSectorDialog.dart';
import 'dialog/SubCategoryDialog.dart';
import 'inventory_view/InventoryListDataTable.dart';

class EditMyProductPage extends StatefulWidget {
  final String? title;
  final String? buId;
  final String? productId;
  final bool isFromRawMaterialPage;
  final String? rawMaterialTitle;
  final bool isFromConsumablePage;
  final bool isFromBuList;
  final bool canSelectInventory;

  EditMyProductPage(
      {this.title,
      this.buId,
      this.productId,
      this.isFromRawMaterialPage = false,
      this.rawMaterialTitle,
      this.isFromConsumablePage = false,
      this.isFromBuList = false,
      this.canSelectInventory = false});

  @override
  _EditMyProductPageState createState() => _EditMyProductPageState();
}

class _EditMyProductPageState extends State<EditMyProductPage> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? priceUnitDropdownValue;
  String? quantityDropdownValue;
  String? taxDropdownValue;
  String? taxValueDropdownValue;
  String connectionBuName = "";
  String connectionBuId = "";
  List<Contacts> _connectionsList = [];
  Contacts? connectionDropdownValue;
  bool isCameraReady = false;
  bool showCapturedPhoto = false;
  String? currencySymbol = "";
  var imagePath;
  bool cameraPriviewShow = false;
  EdgeInsetsGeometry dialogTitlePadding =
      EdgeInsets.fromLTRB(17.0, 24.0, 24.0, 5.0);
  bool isSelectCaptureChoice = false;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  DateTime selectedDate = DateTime.now();
  String? prefixValue;
  List<OffersModel> _offersList = [];
  List<SupplierModel> _supplierList = [];
  File? imageFile;
  String? imageBlob = '';
  String? buId = "";
  late Service _service;
  bool isLoading = false;
  String? inStockRadioValue = Constants.YES_STRING;
  String? inStockChoice = Constants.YES_STRING;
  String? forSaleRadioValue = Constants.YES_STRING;
  String? forSaleChoice = Constants.YES_STRING;
  String strHeight = "";
  String strVolume = "";
  String strWeight = "";
  String strWidth = "";
  String strDepth = "";
  String? maxOrderDropdownValue;
  String? minOrderDropdownValue;
  bool isOfferActive = false;
  String? offerRadioValue = Constants.OFFER_IN_AMOUNT;
  String? offerChooice;
  List<String> _citiesList = [];
  String? citiesDropDownValue;

  /// Product Details Fiellds
  final _productNameController = TextEditingController();
  final _skuController = new TextEditingController();
  final _brandController = new TextEditingController();
  final _descriptionController = new TextEditingController();
  final _batchNumController = new TextEditingController();
  ProductSubType? _productType;
  ProductSubType? _productSubType;
  ProductSegmentDAO? _productSegment;
  ProductCategoryDAO? _productCategory;
  ProductSubCategoryDAO? _productSubCategory;
  CountryDAO? _countryName;
  StatesDAO? _stateName;
  CurrencyNameDAO? currencyNameDropdown;
  List<CurrencyNameDAO> _currencyNameList = [];

  /// Manufacture Fields
  final _modelNumberController = new TextEditingController();
  final _manufactureNameController = new TextEditingController();
  final _manufactureAddressController = new TextEditingController();
  final _buildingNumController = new TextEditingController();
  final _areaController = new TextEditingController();
  final _cityController = new TextEditingController();
  final _talukController = new TextEditingController();
  final _landMarkController = new TextEditingController();
  final _districtController = new TextEditingController();
  final _pinController = new TextEditingController();

  /// Shipping Details
  final _weightController = new TextEditingController();
  final _widthController = new TextEditingController();
  final _heightController = new TextEditingController();
  final _depthController = new TextEditingController();
  final _qntyController = new TextEditingController();

  /// Price Details
  final _priceController = new TextEditingController();
  final _netRateController = new TextEditingController();
  final _mrpController = new TextEditingController();
  final _barcodeController = new TextEditingController();

  /// Offers Input fields
  final _offerNameController = new TextEditingController();
  final _offerQtyController = new TextEditingController();
  final _detailsController = new TextEditingController();

  /// Supplier Input fields
  final _supCityController = new TextEditingController();
  final _supDistrictController = new TextEditingController();
  final _supLocalityController = new TextEditingController();
  final _supPnhController = new TextEditingController();
  List<ProductSubType> productSubTypes = [];
  List<ProductSegmentDAO> productsSegments = [];
  List<ProductCategoryDAO> productCategories = [];
  List<ProductSubCategoryDAO> productSubCategories = [];
  List<ProductSubType> productTypeList = [];
  List<ProductConditionModel> productConditions = [];
  List<CountryDAO> countryList = [];
  List<StatesDAO> stateList = [];
  List<String> _districtList = [];
  String? districtDropdownValue;
  final _attributeKeyController = new TextEditingController();
  final _attributeValueController = new TextEditingController();
  final _locationQuantityController = new TextEditingController();
  final hsnCodeController = TextEditingController();
  List<ProductAttributeModel> attributesList = [];
  List<InventoryManagementModel> inventoryList = [];
  List<BuProductModal> _productsList = [];
  DateTime manifactureDate = DateTime.now();
  DateTime expireDate = DateTime.now();
  DateTime offerStartDate = DateTime.now();
  DateTime offerEndDate = DateTime.now();
  DateTime offerSupplyTime = DateTime.now();
  DateTime releaseDate = DateTime.now();
  DateFormat formatter = DateFormat("yyyy-MM-dd");
  String? formattedOfferStartDate = Constants.OFFER_START_DATE;
  String? formattedOfferEndDate = Constants.OFFER_END_DATE;
  String? formattedManufactureDate = "";
  String formattedOfferSupplyDate = "";
  String? formattedExpireDate = "";
  String formattedReleaseDate = "";
  List<BusinessUnitModel> _buList = [];
  List<Locations> locationsList = [];
  Locations? locationDropdownValue;
  num productTotalQuantity = 0;
  num inventoryQuantity = 0;
  String? heightDropdownValue;
  String? weightDropdownValue;
  String? widthDropdownValue;
  String? volumeDropdownValue;
  String? depthDropdownValue;
  final volumeController = TextEditingController();
  String? offerInPercentage;
  List<ConnectionsBuDAO> _connectionDetails = [];
  bool isImageUpdated = false;
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  double finalAngle = 0.0;
  late ProductService _productService;
  List<PriceModel> _priceList = [];
  num batchPricingTotalQuantity = 0;
  PriceModel? inventoryQuantityDropdown;
  String? remainingBatchQuantity = "0";
  num? quantityForUpdate = 0;
  late InvitationService _invitationService;
  List<RawProductsIssueDAO> _rawIssuesList = [];
  RawProductsIssueDAO? rawIssuedListDropDown;
  String? rawMaterialProductRadioValue;
  String? actualProductRadioValue;
  List<RawInventory> rawInventoryList = [];
  List<QuantityAdjustmentDAO> quantityAdjustmentList = [];
  String? adjustmentReasonDropdownValue;
  String? userName = "";
  String? updatedCurrentDateTime = "";
  num? remainingAdjustmentQuantity = 0;
  final _dialCodeController = TextEditingController();
  List<ProductSectorDAO> productSectorList = [];
  ProductSectorDAO? productSectorDropdown;
  final _batchPricingDescription = new TextEditingController();
  String? inventoryQuntityInDropdown;
  DateFormat _currentDateTimeFormat = DateFormat("yyyy-MM-dd hh:mm aa");
  num _selectedLocationQuantity = 0;
  num totalCurrentBatchQuantity = 0;
  num remainingCurrentBatchQuantity = 0;
  List<InventoryDetailsDAO> _locationBatchesInQuantityAdjustment = [];
  InventoryManagementModel? quantityAdjustmentLocationDropdown;
  InventoryDetailsDAO? quantityAdjustmentBatchDropdown;
  TextEditingController _quantityAdjutmentController =
      new TextEditingController();
  late OrganizationService _organizationService;
  List<Map<String, dynamic>> tempListItems = [
    {"name": Constants.PRODUCT_DETAILS_STR, "isChecked": true},
    {"name": Constants.PRICE_DETAILS, "isChecked": false},
    {"name": Constants.ITEM_DETAILS, "isChecked": false},
    {"name": Constants.MANUFACTURER_DETAILS, "isChecked": false},
    {"name": Constants.OFFERS_C, "isChecked": false},
    {"name": Constants.SUPPLIERS_C, "isChecked": false},
  ];
  String? selectedText = Constants.PRODUCT_DETAILS_STR;
  Uint8List? _webImage;
  ScrollController? _scrollController = ScrollController();
  late ThemeData theme;
  String imageRelativePath = '';
  NumberFormat format = NumberFormat('#,###,###.00');
  DateTime mnthStartDate =
      DateTime.utc(DateTime.now().year, DateTime.now().month, 1);
  String startDate = "";
  String endDate = "";
  num nTabs = 8;
  int tabIndex = 0;
  @override
  void initState() {
    super.initState();
    _invitationService = InvitationService();
    theme = AppTheme.vyaparTheme;
    _service = Service();
    _updateMenuItemsList();
    _productService = ProductService();
    _organizationService = new OrganizationService();
    buId = widget.buId;
    formattedManufactureDate = formatter.format(mnthStartDate);
    formattedExpireDate = formatter.format(mnthStartDate);
    formattedReleaseDate = formatter.format(mnthStartDate);
    if (widget.title ==
        Language().getString(Constants.UPDATE_PRODUCT, selectedLang)) {
      loadProductData();
    } else {
      loadDropdowns();
    }
    SharePref().getUserName().then((value) {
      userName = value;
    });

    actualProductRadioValue =
        Language().getString(Constants.PURCHASED_PRODUCTS, selectedLang);
    updatedCurrentDateTime = _currentDateTimeFormat.format(DateTime.now());

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (widget.canSelectInventory) {
        _scrollToCenter(tempListItems.length - 1);
        setState(() {
          selectedText = tempListItems[tempListItems.length - 1]['name'];
        });
      }
    });
  }

  // Future<void> getOndcFormView({bool isUpdateValues = false}) async {
  //   for (var element in ondcCategoryList) {
  //     if (element['sub_category'] == _productSubCategory!.name!) {
  //       element.forEach((key, value) {
  //         ondcFormTitles.add(key);
  //       });
  //       break;
  //     }
  //   }
  //   if (ondcFormTitles.length > 0) {
  //     for (int i = 1; i < ondcFormTitles.length; i++) {
  //       ondcTextEditingController.add(new TextEditingController());
  //     }
  //     if (isUpdateValues) {
  //       updateText();
  //     }
  //   }
  // }

  // updateText() {
  //   if (_productsList.length == 0) {
  //     return;
  //   }
  //   if (_productsList[0].ondcFeatures!.length == 0) {
  //     return;
  //   }
  //   for (int i = 0; i < _productsList[0].ondcFeatures!.length; i++) {
  //     print(_productsList[0].ondcFeatures![i].entries.toList()[0].key);
  //     print(_productsList[0].ondcFeatures![i].entries.toList()[0].value);
  //     ondcTextEditingController[i].text =
  //         _productsList[0].ondcFeatures![i].entries.toList()[0].value;
  //   }
  // }

  List<Map<String, dynamic>> _updateMenuItemsList() {
    if (CommonMethods.isPrivillegeExist(
        context, PrivillegesActions.KEY_PRODUCT_LIST_ITEM_EDIT_TAX_DETAILS)) {
      tempListItems.add({"name": Constants.TAX_DETAILS, "isChecked": false});
    }
    if (CommonMethods.isPrivillegeExist(context,
        PrivillegesActions.KEY_PRODUCT_LIST_ITEM_EDIT_INVENTORY_LOCATION)) {
      int index = tempListItems.indexWhere(
          (element) => element["name"] == Constants.PRODUCT_DETAILS_STR);
      tempListItems[index]["isChecked"] =
          widget.canSelectInventory ? false : true;
      tempListItems.add({
        "name": Constants.INVENTORY_LOCATION_C,
        "isChecked": widget.canSelectInventory ? true : false
      });
    }

    tempListItems.add({"name": "BARCODE", "isChecked": false});

    int oldIndex = tempListItems
        .indexWhere((item) => item["name"] == Constants.TAX_DETAILS);
    int newIndex = 2;
    if (oldIndex != -1 && newIndex >= 0 && newIndex < tempListItems.length) {
      final item = tempListItems.removeAt(oldIndex);
      tempListItems.insert(newIndex, item);
    }
    return tempListItems;
  }

  Widget itemDetailsView() {
    return Card(
      elevation: 2.5,
      child: Column(children: <Widget>[
        buildHeightView(Constants.HEIGHT, ""),
        SizedBox(
            height: 1.0, child: Container(color: Color(Constants.GREY_COLOR))),
        buildWidthView(Constants.WIDTH, ""),
        SizedBox(
            height: 1.0, child: Container(color: Color(Constants.GREY_COLOR))),
        buildDepthView(Constants.DEPTH, ""),
        SizedBox(
            height: 1.0, child: Container(color: Color(Constants.GREY_COLOR))),
        buildVolumeView(Constants.VOLUME, ""),
        SizedBox(
            height: 1.0, child: Container(color: Color(Constants.GREY_COLOR))),
        buildWeightView(Constants.WEIGHT, ""),
      ]),
    );
  }

  Widget productBasicDetailsView() {
    return Container(
      child: Column(
        children: <Widget>[
          Card(
            elevation: 2.5,
            child: Column(
              children: [
                buildTableContent(
                    Constants.NAME_STRING, _productNameController, false, true,
                    enable: true),
                SizedBox(
                  height: 1,
                  child: new Container(color: Color(Constants.GREY_COLOR)),
                ),
                // buildTableContent(
                //     Constants.BRAND, _brandController, false, false),
                // SizedBox(
                //   height: 1,
                //   child: new Container(color: Color(Constants.GREY_COLOR)),
                // ),
                buildTableDescriptionContent(Constants.DESCRIPTION_STRING,
                    _descriptionController, false, false),
                SizedBox(
                  height: 1,
                  child: new Container(color: Color(Constants.GREY_COLOR)),
                ),
                if (CommonMethods.isPrivillegeExist(context,
                    PrivillegesActions.KEY_PRODUCT_LIST_ITEM_EDIT_IN_STOCK))
                  Container(
                    child: Row(
                      children: [
                        Expanded(
                          child: Container(
                              padding: EdgeInsets.only(
                                left: 10.0,
                              ),
                              height: 50,
                              alignment: Alignment.centerLeft,
                              color: Color(Constants.GREY_COLOR_LIGHT),
                              child: Text(
                                Language().getString(
                                    Constants.IN_STOCK, selectedLang),
                                style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 15.0,
                                ),
                              )),
                        ),
                        Expanded(
                          flex: 2,
                          child: Container(
                            color: Colors.white,
                            height: 50,
                            child: inStockRadioGroup(),
                          ),
                        )
                      ],
                    ),
                  ),
                SizedBox(
                    height: 1,
                    child: new Container(color: Color(Constants.GREY_COLOR))),
                if (CommonMethods.isPrivillegeExist(context,
                    PrivillegesActions.KEY_PRODUCT_LIST_ITEM_EDIT_FOR_SALE))
                  Visibility(
                      visible: (widget.isFromRawMaterialPage ||
                              widget.isFromConsumablePage)
                          ? false
                          : true,
                      child: Container(
                        child: Row(
                          children: [
                            Expanded(
                              child: Container(
                                  padding: EdgeInsets.only(
                                    left: 10.0,
                                  ),
                                  height: 50,
                                  alignment: Alignment.centerLeft,
                                  color: Color(Constants.GREY_COLOR_LIGHT),
                                  child: Text(
                                    Language().getString(
                                        Constants.FOR_SALE, selectedLang),
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 15.0,
                                    ),
                                  )),
                            ),
                            Expanded(
                              flex: 2,
                              child: Container(
                                color: Colors.white,
                                height: 50,
                                child: forSaleRadioGroup(),
                              ),
                            )
                          ],
                        ),
                      )),
                SizedBox(
                    height: 1,
                    child: new Container(color: Color(Constants.GREY_COLOR))),
                Column(
                  children: <Widget>[
                    buildDropdownSector(Constants.PRODUCT_SECTOR),
                    SizedBox(
                      height: 1,
                      child: new Container(
                        color: Color(Constants.GREY_COLOR),
                      ),
                    ),
                    showCaterogyDropdown(Constants.PRODUCT_CATEGORY),
                    SizedBox(
                      height: 1,
                      child: new Container(color: Color(Constants.GREY_COLOR)),
                    ),
                    showSubCategoryDropdown(Constants.PRODUCT_SUB_CATEGORY),
                  ],
                ),
              ],
            ),
          ),
          Card(
            elevation: 2.5,
            margin: EdgeInsets.only(top: 10),
            child: Container(
              padding: EdgeInsets.all(10.0),
              child: Column(
                children: [
                  Container(
                    margin: EdgeInsets.symmetric(
                      vertical: 5.0,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        buildTextField(Language()
                            .getString(Constants.FEATURES, selectedLang)),
                        addNewAttribute()
                      ],
                    ),
                  ),
                  Container(
                    child: attributesList.length == 0
                        ? Container(margin: EdgeInsets.symmetric(vertical: 5.0))
                        : onCreateDynamicAttributes(),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget featureAttributesView() {
    return Card(
      elevation: 2.5,
      child: Container(
        padding: EdgeInsets.all(10.0),
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.symmetric(
                vertical: 5.0,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  buildTextField(
                      Language().getString(Constants.FEATURES, selectedLang)),
                  addNewAttribute()
                ],
              ),
            ),
            Container(
              child: attributesList.length == 0
                  ? Container(margin: EdgeInsets.symmetric(vertical: 5.0))
                  : onCreateDynamicAttributes(),
            ),
          ],
        ),
      ),
    );
  }

  Widget addPriceDetailsView() {
    return Card(
        elevation: 2.5,
        child: Container(
          padding: EdgeInsets.all(10),
          child: Column(children: [
            priceDetailsView(),
            (_priceList.length > 0)
                ? createPriceDetailsDynamic()
                : Container(margin: EdgeInsets.symmetric(vertical: 5.0)),
          ]),
        ));
  }

  Widget manufacturerDetailsView() {
    return Card(
      elevation: 2,
      child: Column(children: <Widget>[
        buildMobileNumberTextFormField(
            Constants.MOBILE_NUMBER, _modelNumberController),
        SizedBox(
          height: 1,
          child: new Container(color: Color(Constants.GREY_COLOR)),
        ),
        buildDateFieldRelease(Constants.RELEASE_DATE),
        SizedBox(
          height: 1,
          child: new Container(color: Color(Constants.GREY_COLOR)),
        ),
        buildTableContent(
            Constants.NAME_STRING, _manufactureNameController, false, false),
        SizedBox(
          height: 1,
          child: new Container(color: Color(Constants.GREY_COLOR)),
        ),
        buildTableContent(Constants.PLOT_NO, _areaController, false, false),
        SizedBox(
          height: 1,
          child: new Container(color: Color(Constants.GREY_COLOR)),
        ),
        buildTableContent(
            Constants.BULIDING, _buildingNumController, false, false),
        SizedBox(
          height: 1,
          child: new Container(color: Color(Constants.GREY_COLOR)),
        ),
        buildDropDownCountry(Constants.COUNTRY_NAME_STRING),
        SizedBox(
          height: 1,
          child: new Container(color: Color(Constants.GREY_COLOR)),
        ),
        buildDropDownState(Constants.STATE_NAME_STRING),
        SizedBox(
          height: 1,
          child: new Container(color: Color(Constants.GREY_COLOR)),
        ),
        buildDropDownDistrict(Constants.DISTRICT_STRING),
        SizedBox(
          height: 1,
          child: new Container(color: Color(Constants.GREY_COLOR)),
        ),
        buildCityDropdown(Constants.CITY_NAME_STRING),
        SizedBox(
          height: 1,
          child: new Container(color: Color(Constants.GREY_COLOR)),
        ),
        buildPincodeView()
      ]),
    );
  }

  Widget taxDetailsView() {
    return Card(
      child: Column(children: <Widget>[
        buildDropDownTax(Constants.TAX),
        SizedBox(
          height: 1,
          child: new Container(color: Color(Constants.GREY_COLOR)),
        ),
        buildTableContent(Constants.HSN_CODE, hsnCodeController, true, false),
        SizedBox(
          height: 1,
          child: new Container(color: Color(Constants.GREY_COLOR)),
        ),
        buildDropdownTaxValue(Constants.RATE)
      ]),
    );
  }

  Widget offerDetailsView() {
    return Visibility(
        visible: (widget.isFromRawMaterialPage || widget.isFromConsumablePage)
            ? false
            : true,
        child: Card(
          elevation: 2.5,
          child: Container(
            padding: EdgeInsets.all(10.0),
            child: Column(
              children: [
                Container(
                  margin: EdgeInsets.symmetric(
                    vertical: 10.0,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      buildTextField(Language()
                          .getString(Constants.OFFERS_C, selectedLang)),
                      // (_productPrivileges.product_offer_create)
                      //     ?
                      addOffersList()
                      // : Container()
                    ],
                  ),
                ),
                Container(
                  child: (_offersList.length == 0)
                      ? null
                      : _createDynamicOfferTable(),
                ),
              ],
            ),
          ),
        ));
  }

  Widget suppliersDetailsView() {
    return Card(
      elevation: 2.5,
      child: Container(
        padding: EdgeInsets.all(10),
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.symmetric(
                vertical: 10.0,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  buildTextField(Language()
                      .getString(Constants.SUPPLIERS_C, selectedLang)),
                  addSupplierList()
                ],
              ),
            ),
            Container(
                child: (_supplierList.length == 0)
                    ? Container()
                    : _createDynamicSupplierTable()),
          ],
        ),
      ),
    );
  }

  Widget inventoryLocationDetailsView() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(children: [
          Container(
            margin: EdgeInsets.symmetric(
              vertical: 10.0,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                buildTextField(Language()
                    .getString(Constants.INVENTORY_LOCATION_C, selectedLang)),
                addNewInventory()
              ],
            ),
          ),
          Container(
            child:
                (inventoryList.length == 0) ? null : onCreateDynamicInventory(),
          )
        ]),
      ),
    );
  }

  void _scrollToCenter(int index) {
    double screenWidth = MediaQuery.of(context).size.width;
    double totalTabsWidth = tempListItems.length * 150.0;
    double offset = (index * 150.0) - (screenWidth / 2) + (150.0 / 2);

    if (offset < 0) {
      offset = 0;
    } else if (offset > totalTabsWidth - screenWidth) {
      offset = totalTabsWidth - screenWidth;
    }

    _scrollController!.animateTo(
      offset,
      duration: Duration(milliseconds: 500),
      curve: Curves.easeInOut,
    );
  }

  showTempListView() {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 10.0),
      child: SingleChildScrollView(
        controller: _scrollController,
        scrollDirection: Axis.horizontal,
        child: Row(
          children: <Widget>[
            for (int i = 0; i < tempListItems.length; i++)
              InkWell(
                onTap: () async {
                  if (tempListItems[i]['name'] == Constants.ONDC_FORM) {
                    bool isupdated = await checkSubCategoryUpdated();
                    if (!isupdated) {
                      return;
                    }
                  }

                  _scrollToCenter(i);
                  setState(() {
                    for (int j = 0; j < tempListItems.length; j++) {
                      if (i == j) {
                        selectedText = tempListItems[j]['name'];
                        tempListItems[j]['isChecked'] = true;
                      } else {
                        tempListItems[j]['isChecked'] = false;
                      }
                    }
                  });
                },
                child: Container(
                    margin: EdgeInsets.symmetric(horizontal: 5.0),
                    child: Container(
                      decoration: BoxDecoration(
                          color: (tempListItems[i]['isChecked'])
                              ? Colors.black
                              : Color(0xff9C9C9C),
                          borderRadius: BorderRadius.circular(5)),
                      padding: EdgeInsets.all(8.0),
                      child: Text(
                        Language()
                            .getString(tempListItems[i]['name'], selectedLang),
                        style: TextStyle(
                            fontSize: 12.0,
                            color: Colors.white,
                            fontWeight: StyleView.fontMedium),
                      ),
                    )),
              )
          ],
        ),
      ),
    );
  }

  Color circleContainerColor(index) {
    Color _customColor;
    if (index < tabIndex) {
      _customColor = Colors.black;
    } else if (index == tabIndex) {
      _customColor = Colors.black;
    } else {
      _customColor = Colors.grey;
    }
    return _customColor;
  }

  Color circleContainerBorder(index) {
    Color _customBorder;
    if (index < tabIndex) {
      _customBorder = Colors.black;
    } else if (index == tabIndex) {
      _customBorder = Colors.black;
    } else {
      _customBorder = Colors.grey;
    }
    return _customBorder;
  }

  Widget completeSterView(index) {
    if (index < tabIndex) {
      return Icon(
        Icons.check,
        size: 20,
        color: Colors.white,
      );
    } else if (index == tabIndex) {
      return Text(
        "${index + 1}",
        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
      );
    } else {
      return Text("${index + 1}");
    }
  }

  Color? lineColor(index) {
    Color? _customLineColor;
    if (index < tabIndex) {
      _customLineColor = Colors.green;
    } else if (index == tabIndex) {
      _customLineColor = Colors.grey;
    }

    return _customLineColor;
  }

  List<Widget> stepperView() {
    List<Widget> _list = [];

    for (int i = 0; i < nTabs; i++) {
      _list.add(Container(
        height: 30,
        width: 30,
        alignment: Alignment.center,
        decoration: BoxDecoration(
            color: circleContainerColor(i),
            borderRadius: BorderRadius.all(Radius.circular(30 / 2)),
            border: Border.all(color: circleContainerBorder(i))),
        child: completeSterView(i),
      ));
      if (i != nTabs - 1) {
        _list.add(
          Expanded(
            child: Container(
              height: 3.5,
              color: Colors.grey,
            ),
          ),
        );
      }
    }
    return _list;
  }

  @override
  void setState(VoidCallback fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  String getHeaderText() {
    if (widget.isFromRawMaterialPage) {
      return Constants.RAW_MATERIAL_DETAILS_C;
    }
    if (widget.isFromConsumablePage) {
      return Constants.CONSUMABLE_MATERIAL_DETAILS_C;
    }
    return Constants.PRODUCTDETAILS;
  }

  @override
  Widget build(BuildContext context) {
    ToastContext().init(context);
    return AppBackgroundView(
      body: WillPopScope(
        onWillPop: () async {
          return Navigator.canPop(context);
        },
        child: Stack(
          children: [
            SafeArea(
              child: Scaffold(
                key: _scaffoldkey,
                backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                appBar: AppBar(
                  iconTheme: IconThemeData(color: theme.colorScheme.primary),
                  leading:
                      // (widget.title ==
                      //         Language()
                      //             .getString(Constants.UPDATE_PRODUCT, selectedLang))
                      //     ?
                      IconButton(
                          icon: Icon(Icons.arrow_back),
                          onPressed: () async {
                            final action = await Dialogs.yesCancelDialog(
                                context,
                                Language()
                                    .getString(Constants.INFO, selectedLang),
                                Language().getString(
                                    Constants.BACK_BUTTION_MESSAGE,
                                    selectedLang),
                                Language().getString(
                                    Constants.YES_STRING, selectedLang),
                                Language().getString(
                                    Constants.NO_STRING, selectedLang),
                                true);
                            if (action == DialogAction.yes) {
                              Navigator.pop(context);
                            }
                          }),
                  // : null,
                  centerTitle: true,
                  elevation: 0,
                  title: FxText.displayMedium(
                    Language().getString(widget.title, selectedLang),
                    style: TextStyle(
                      fontSize: 18.0,
                      overflow: TextOverflow.ellipsis,
                      fontWeight: StyleView.fontBold,
                      color: theme.colorScheme.primary,
                    ),
                  ),
                  backgroundColor: Colors.transparent,
                  actions: [
                    AppUtills.homeButton(context),
                  ],
                ),
                bottomNavigationBar: Container(
                  padding: EdgeInsets.symmetric(horizontal: 10, vertical: 20),
                  child: CommonButtonsView(
                    context: context,
                    b1TextColor: Colors.white,
                    b1Text: (widget.isFromRawMaterialPage ||
                            widget.isFromConsumablePage)
                        ? Language()
                            .getString(widget.rawMaterialTitle, selectedLang)
                        : Language().getString(widget.title, selectedLang),
                    onb1Action: () {
                      submitInputData();
                    },
                    b2Text: "",
                  ),
                ),
                body: Container(
                    child: Column(
                  children: [
                    // Container(
                    //     padding: EdgeInsets.all(16),
                    //     child: Row(children: stepperView())),
                    Expanded(
                        child: SingleChildScrollView(
                      child: Container(
                        margin: EdgeInsets.symmetric(
                          horizontal: 10.0,
                          vertical: 5.0,
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Container(
                              margin: EdgeInsets.symmetric(
                                vertical: 5.0,
                              ),
                              child: Text(
                                Language()
                                    .getString(getHeaderText(), selectedLang),
                                style: TextStyle(
                                    color: Colors.black,
                                    fontSize: StyleView.FONT_SIZE_15,
                                    fontFamily: StyleView.FONT_TITLE,
                                    fontWeight: FontWeight.w900),
                              ),
                            ),
                            Container(
                              decoration: BoxDecoration(
                                // borderRadius: BorderRadius.circular(10),
                                color: Colors.white,
                              ),
                              // color: Colors.white,
                              child: Column(children: <Widget>[
                                onCamera(Language().getString(
                                    Constants.PRODUCT_PHOTO_STRING,
                                    selectedLang)),
                                Divider(),
                                displayImageView()
                              ]),
                            ),
                            showTempListView(),
                            Column(
                              children: [
                                if (selectedText == Constants.PRODUCTDETAILS)
                                  productBasicDetailsView(),
                                if (selectedText == Constants.PRICE_DETAILS)
                                  addPriceDetailsView(),
                                if (selectedText ==
                                    Constants.MANUFACTURER_DETAILS)
                                  manufacturerDetailsView(),
                                if (selectedText == Constants.ITEM_DETAILS)
                                  itemDetailsView(),
                                if (selectedText == Constants.TAX_DETAILS)
                                  taxDetailsView(),
                                if (selectedText == Constants.OFFERS_C)
                                  offerDetailsView(),
                                if (selectedText == Constants.SUPPLIERS_C)
                                  suppliersDetailsView(),
                                if (selectedText ==
                                    Constants.INVENTORY_LOCATION_C)
                                  inventoryLocationDetailsView(),
                                if (selectedText == "BARCODE") barcodeSection()
                                // if (selectedText == Constants.ONDC_FORM)
                                //   ondcFormDynamicView()
                              ],
                            )
                          ],
                        ),
                      ),
                    ))
                  ],
                )),
              ),
            ),
            AppUtills.showLoadingView(
                context: context,
                message: Language().getString(progressMessage, selectedLang),
                isLoading: isLoadingProgress),
          ],
        ),
      ),
    );
  }

  void _editBarcode(dynamic batch) {
    final controller = TextEditingController(text: batch.barcode ?? '');

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Edit Barcode'),
          content: TextField(
            controller: controller,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              labelText: 'Barcode',
              hintText: 'Enter 13-digit barcode',
              border: OutlineInputBorder(),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                if (controller.text.isNotEmpty) {
                  setState(() {
                    batch.barcode = controller.text;
                  });
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Barcode updated')),
                  );
                }
              },
              child: Text('Save'),
            ),
          ],
        );
      },
    );
  }

  void _generateMissingBarcodes() {
    int generatedCount = 0;
    final random = math.Random();

    if (_productsList[0].batchPrice == null) return;

    for (final batch in _productsList[0].batchPrice!) {
      // Check if batch has no barcode
      if (batch.barcode == null || batch.barcode!.isEmpty) {
        // Generate a 13-digit unique barcode
        final barcode = _generate13DigitBarcode(random);
        batch.barcode = barcode;
        generatedCount++;
      }
    }

    setState(() {
      // Rebuild the UI with generated barcodes
    });

    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('Generated $generatedCount barcodes'),
      duration: Duration(seconds: 2),
    ));
  }

  String _generate13DigitBarcode(math.Random random) {
    // Generate 13 random digits
    String barcode = '';
    for (int i = 0; i < 13; i++) {
      barcode += random.nextInt(10).toString();
    }
    return barcode;
  }

  Widget barcodeSection() {
    return ListView.separated(
      shrinkWrap: true, // ⭐ REQUIRED
      physics: NeverScrollableScrollPhysics(), // ⭐ REQUIRED
      padding: EdgeInsets.all(5),
      itemCount: _productsList.length,
      separatorBuilder: (_, __) => SizedBox(height: 5),
      itemBuilder: (context, index) {
        // final p = _productsList[index];
        return Card(
          elevation: 4,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (_priceList.isNotEmpty)
                  Column(
                    children: _priceList
                        .where((batch) =>
                            batch.batchNumber != null &&
                            batch.batchNumber!.isNotEmpty)
                        .toList()
                        .asMap()
                        .entries
                        .map((entry) {
                      final index = entry.key;
                      final batch = entry.value;
                      final barcodeValue =
                          (batch.barcode != null && batch.barcode!.isNotEmpty)
                              ? batch.barcode!
                              : "";

                      return Padding(
                        padding: const EdgeInsets.symmetric(vertical: 6.0),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              flex: 3,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "${Language().getString(Constants.BATCH_NO, selectedLang)}: ${batch.batchNumber ?? ""}",
                                    style: TextStyle(
                                        fontWeight: StyleView.fontSemiBold),
                                  ),
                                  SizedBox(height: 6),
                                  Text(
                                      "${Language().getString(Constants.QUANTITY, selectedLang)}: ${batch.quantity ?? 0} ${batch.quantityIn ?? ""}"),
                                  SizedBox(height: 6),
                                  Text(
                                      "${Language().getString(Constants.BARCODE, selectedLang)}: ${batch.barcode}"),
                                ],
                              ),
                            ),
                            // SizedBox(width: 12),
                            Spacer(),
                            Expanded(
                                // flex: 3,
                                child:
                                    // barcodeValue.isNotEmpty
                                    // ?
                                    Column(
                              children: [
                                // barcodeWidget(barcodeValue),

                                Row(
                                  children: [
                                    // Text(barcodeValue),
                                    IconButton(
                                        tooltip: Language().getString(
                                            "Generate Barcodes", selectedLang),
                                        onPressed: () => showBarcodePopup(
                                            canAddMultiple: true, index: index),
                                        icon: Icon(Icons.qr_code_2,
                                            color: theme.colorScheme.primary)),
                                  ],
                                ),
                                // SizedBox(height: 8),
                                // ElevatedButton.icon(
                                //   icon: Icon(Icons.edit, size: 16),
                                //   label: Text('Edit'),
                                //   onPressed: () => _editBarcode(batch),
                                // )
                              ],
                            )
                                // : Row(
                                //     children: [
                                //       Container(
                                //         padding: EdgeInsets.all(12),
                                //         child: Text(Language().getString(
                                //             "No Barcode", selectedLang)),
                                //       ),
                                //       SizedBox(
                                //         width: 5.0,
                                //       ),
                                //       IconButton(
                                //           tooltip: Language().getString(
                                //               "Generate Barcodes",
                                //               selectedLang),
                                //           onPressed: () => showBarcodePopup(
                                //               canAddMultiple: true,
                                //               index: index),
                                //           icon: Icon(Icons.qr_code_2,
                                //               color:
                                //                   theme.colorScheme.primary)),
                                //     ],
                                //   ),
                                ),
                          ],
                        ),
                      );
                    }).toList(),
                  )
                else
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8.0),
                    child: Text(Language()
                        .getString(Constants.NO_DATA_FOUND, selectedLang)),
                  )
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _barcodeSection() {
    if (_productsList[0].barcode != null &&
        _productsList[0].barcode!.isNotEmpty) {
      // Barcode exists
      return Column(
        children: [
          const SizedBox(height: 20),

          barcodeWidget(_productsList[0].barcode!), // your existing widget

          const SizedBox(height: 20),

          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton.icon(
                icon: const Icon(Icons.print),
                label: const Text("Print"),
                onPressed: () => printBarcode(
                  _productsList[0].barcode!,
                  _priceList[0].price.toString() ?? "",
                  productName: _productsList[0].name,
                ),
              ),
              const SizedBox(width: 12),
              OutlinedButton.icon(
                icon: const Icon(Icons.qr_code_scanner),
                label: const Text("Change"),
                onPressed: () => scanAndAssign(context),
              ),
            ],
          ),
        ],
      );
    }

    // No barcode
    return Column(
      children: [
        const SizedBox(height: 40),
        const Icon(Icons.qr_code, size: 80, color: Colors.grey),
        const SizedBox(height: 16),
        const Text(
          "No barcode assigned",
          style: TextStyle(fontSize: 16, color: Colors.grey),
        ),
        const SizedBox(height: 30),
        ElevatedButton.icon(
          icon: const Icon(Icons.qr_code_scanner),
          label: const Text("Scan Barcode"),
          onPressed: () => scanAndAssign(context),
        ),
        const SizedBox(height: 12),
        OutlinedButton.icon(
          icon: const Icon(Icons.auto_fix_high),
          label: const Text("Generate Barcode"),
          onPressed: () {
            generateAndAssign();
            // refresh UI
          },
        ),
      ],
    );
  }

  void generateAndAssign({bool canAddMultiple = false, int batchIndex = 0}) {
    String barcode = DateTime.now().millisecondsSinceEpoch.toString();
    setState(() {
      // product.barcode = barcode;
      if (canAddMultiple) {
        _priceList[batchIndex].barcode = barcode;
      } else {
        _barcodeController.text = barcode;
      }
    });
    // Save to DB
  }

  void scanAndAssign(BuildContext context,
      {bool canAddMultiple = false, int batchIndex = 0}) async {
    final scannedCode = await Navigator.push<String>(
      context,
      MaterialPageRoute(
          builder: (_) => BarcodeScanPage(
              // onScanned: (code) => {},
              )),
    );

    if (scannedCode != null && scannedCode.isNotEmpty) {
      setState(() {
        // product.barcode = scannedCode;
        if (canAddMultiple) {
          _priceList[batchIndex].barcode = scannedCode;
        } else {
          _barcodeController.text = scannedCode;
        }
      });

      // Save to DB here
    }
  }

  checkSubCategoryUpdated() async {
    if (_productSubCategory == null) {
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          Language().getString(
              Constants.PLEASE_SELECT_PRODUCT_SUB_CATEGORY, selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
      if (action == DialogAction.yes) {
        return false;
      }
    }
    return true;
  }

  // ondcFormDynamicView() {
  //   return Card(
  //     child: Column(
  //       children: [
  //         for (int i = 0; i < ondcTextEditingController.length; i++)
  //           Container(child: dynamicOndcTextFormView(i))
  //       ],
  //     ),
  //   );
  // }

  // dynamicOndcTextFormView(int index) {
  //   return Column(
  //     children: [
  //       buildTableContent(ondcFormTitles[index + 1].capitalize,
  //           ondcTextEditingController[index], false, false),
  //       SizedBox(
  //           height: 1,
  //           child: new Container(color: Color(Constants.GREY_COLOR))),
  //     ],
  //   );
  // }

  showTotalQuantity() {
    if (_priceList.length > 0) {
      batchPricingTotalQuantity = 0;
      productTotalQuantity = 0;
      for (int i = 0; i < _priceList.length; i++) {
        setState(() {
          batchPricingTotalQuantity =
              batchPricingTotalQuantity + int.parse(_priceList[i].quantity!);
          productTotalQuantity = batchPricingTotalQuantity;
        });
      }

      return Container(
          margin: EdgeInsets.symmetric(vertical: 10.0),
          child: Row(
            children: [
              Container(
                  child: Text(
                Language().getString(Constants.TOTAL_QUANTITY_C, selectedLang),
                style: TextStyle(
                  fontSize: 15.0,
                  fontWeight: FontWeight.bold,
                ),
              )),
              Expanded(
                  child: Container(
                child: Text(" : $batchPricingTotalQuantity",
                    style: TextStyle(
                      fontSize: 15.0,
                      fontWeight: FontWeight.bold,
                    )),
              ))
            ],
          ));
    } else {
      return Container();
    }
  }

  Future<List<BusinessUnitModel>> getBuData() async {
    _buList.clear();
    locationsList.clear();
    if (!isLoadingProgress) {
      setState(() {
        isLoadingProgress = true;
      });
    }
    String body = json.encode({"id": buId});
    var response = await _organizationService
        .getOrganizationDataById(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
        AppController.instance.setCreateBuProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
      AppController.instance.setCreateBuProgress = false;
    });
    List<BusinessUnitModel> _list = [];

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      for (var data in resObj) {
        _list.add(BusinessUnitModel.fromJson(data));
      }

      if (_list.length > 0 &&
          widget.title ==
              Language().getString(Constants.UPDATE_PRODUCT, selectedLang)) {
        /// inventory functionality
        num totalInventoryCount = 0;
        for (int i = 0; i < _productsList[0].inventoryData!.length; i++) {
          List<InventoryDetailsDAO> _locationBatchesData = [];
          for (int j = 0;
              j < _productsList[0].inventoryData![i].locationBatchList!.length;
              j++) {
            BatchPriceDAO indexData =
                _productsList[0].inventoryData![i].locationBatchList![j];
            totalInventoryCount = totalInventoryCount + indexData.quantity!;
            _locationBatchesData.add(InventoryDetailsDAO(
                quantity: indexData.quantity,
                quantityIn: indexData.quantityIn,
                batchNumber: indexData.batchNumber,
                updatedDate: indexData.updatedDate,
                updatedUser: indexData.updatedUser));
          }

          inventoryList.add(InventoryManagementModel(
              locationName: _productsList[0].inventoryData![i].locationName,
              locationId: _productsList[0].inventoryData![i].locationId,
              locationBatchList: _locationBatchesData));
        }

        // productTotalQuantity = productTotalQuantity - totalInventoryCount;
        // print(productTotalQuantity);
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    return _list;
  }

  Future<List<CurrencyNameDAO>> getCurrencyNames() async {
    http.Response response = await _service.getCurrencyName();
    List<CurrencyNameDAO> list = [];
    if (response.statusCode == 200) {
      var data = json.decode(response.body);
      for (var objectData in data["data"]) {
        list.add(CurrencyNameDAO.fromJson(objectData));
      }
    } else {}
    return list;
  }

  Future<List<CountryDAO>> getCountryTypes() async {
    http.Response response = await _service.getDropDownType("lookup/country");
    List<CountryDAO> _list = [];

    if (response.statusCode == 200) {
      var responseBody = json.decode(response.body);
      for (var data in responseBody['data']) {
        _list.add(CountryDAO.fromJaon(data));
      }
      if (_list.length > 0 &&
          widget.title ==
              Language().getString(Constants.UPDATE_PRODUCT, selectedLang)) {
        for (int i = 0; i < _list.length; i++) {
          if (_productsList[0].manufactureDetails != null &&
              _productsList[0].manufactureDetails!.country == _list[i].name) {
            setState(() {
              _countryName = _list[i];
            });

            getStates(_countryName!.name!).then((value) {
              setState(() {
                stateList.addAll(value);
              });
            });
          }
        }
      }
    } else {}

    return _list;
  }

  Future<List<CitiesDAO>> getCitiesList(
      String? countryName, String? stateId) async {
    setState(() {
      _citiesList.clear();
      isLoadingProgress = true;
      progressMessage = "Getting Cities..";
    });

    var resposne = await _service.getCities(countryName, stateId);
    List<CitiesDAO> _list = [];
    setState(() {
      isLoadingProgress = false;
    });

    if (resposne.statusCode == 200) {
      var data = json.decode(resposne.body);

      bool isString = false;

      if (data['data'] is String) {
        isString = true;
      }

      if (!isString) {
        for (var object in data['data']) {
          _list.add(CitiesDAO.fromJson(object));
        }
      }
    }

    return _list;
  }

  Future<List<StatesDAO>> getStates(String countryName) async {
    stateList.clear();
    http.Response response = await _service.getStatesByCountry(countryName);
    List<StatesDAO> _list = [];
    if (response.statusCode == 200) {
      var responseBody = json.decode(response.body);
      for (var data in responseBody['data']) {
        for (var statesObject in data["states"])
          _list.add(StatesDAO.fromJson(statesObject));
      }
      if (_list.length > 0 &&
          widget.title ==
              Language().getString(Constants.UPDATE_PRODUCT, selectedLang) &&
          _productsList[0].manufactureDetails != null) {
        if (_productsList[0].manufactureDetails!.state != null) {
          for (int i = 0; i < _list.length; i++) {
            if (_productsList[0].manufactureDetails!.state == _list[i].state) {
              setState(() {
                _districtList.clear();
                _stateName = _list[i];
                _districtList.addAll(_stateName!.cities!);
              });
              if (_productsList[0].manufactureDetails!.district != null) {
                if (_districtList.length > 0) {
                  for (int j = 0; j < _districtList.length; j++) {
                    if (_productsList[0].manufactureDetails!.district ==
                        _districtList[j]) {
                      setState(() {
                        districtDropdownValue = _districtList[j];
                      });
                    }
                  }
                }
              }
            }
          }

          if (_stateName != null) {
            this.getCitiesList(countryName, _stateName!.id).then((value) {
              if (value.length > 0) {
                setState(() {
                  _citiesList.clear();
                  _citiesList.addAll(value[0].cities!);
                });

                if (_productsList[0].manufactureDetails!.city != null) {
                  for (int k = 0; k < _citiesList.length; k++) {
                    if (_productsList[0].manufactureDetails!.city ==
                        _citiesList[k]) {
                      setState(() {
                        citiesDropDownValue = _citiesList[k];
                      });
                    }
                  }
                }
              }
            });
          }
        }
      }
    } else {}

    return _list;
  }

  submitInputData({String relativePath = ""}) async {
    String validationError = onValuesValidation();
    // String itemDetailsError = validatingItemDetails();

    /// Validating product basic details
    if (validationError.isNotEmpty) {
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          Language().getString(validationError, selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    } else {
      if (await NetworkStatus.getInternetStatus()) {
        setState(() {
          isLoadingProgress = true;
          progressMessage = (widget.title ==
                  Language().getString(Constants.ADD_PRODUCT, selectedLang))
              ? Language().getString(Constants.CREATING, selectedLang)
              : Language().getString(Constants.UPDATING, selectedLang);
        });

        updateProduct(
            isUpdateProduct: (widget.title ==
                    Language().getString(Constants.ADD_PRODUCT, selectedLang))
                ? false
                : true,
            relativePath: relativePath);
      } else {
        AppUtills.showSnackBar(_scaffoldkey,
            Language().getString(Constants.NO_INTERNET, selectedLang),
            snackBarBgColor: Colors.black,
            messageColor: Colors.white,
            buttonColor: Colors.white);
      }
      // }
    }
  }

  buildTableContent(String textName, TextEditingController _controller,
      bool _isKeyboard, bool isMandatory,
      {bool enable = true}) {
    return Container(
        color: Color(Constants.GREY_COLOR_LIGHT),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  child: Container(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: EdgeInsets.all(8.0),
                  child: isMandatory
                      ? RichText(
                          text: TextSpan(children: [
                            TextSpan(
                              text:
                                  Language().getString(textName, selectedLang),
                              style: TextStyle(
                                  fontSize: StyleView.FONT_SIZE_15,
                                  fontFamily: StyleView.FONT_TITLE,
                                  color: Colors.black),
                            ),
                            TextSpan(
                                text: "\*",
                                style: TextStyle(
                                    fontSize: StyleView.FONT_SIZE_15,
                                    color: Colors.red))
                          ]),
                        )
                      : Text(
                          Language().getString(textName, selectedLang),
                          style: TextStyle(
                              fontSize: StyleView.FONT_SIZE_15,
                              fontWeight: StyleView.fontMedium),
                        ),
                ),
              )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                color: Colors.white,
                alignment: Alignment.centerLeft,
                padding: EdgeInsets.only(left: 5.0),
                child: TextField(
                    controller: _controller,
                    keyboardType: _isKeyboard
                        ? TextInputType.numberWithOptions(signed: true)
                        : TextInputType.text,
                    textInputAction: TextInputAction.next,
                    enabled: enable,
                    style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: Language().getString(textName, selectedLang),
                    ),
                    inputFormatters: (_isKeyboard)
                        ? [CommonMethods.inputTextFormatter(isDouble: true)]
                        : []),
              ),
            )
          ],
        ));
  }

  buildTableDescriptionContent(String textName,
      TextEditingController _controller, bool _isKeyboard, bool isMandatory,
      {bool enable = true}) {
    return Container(
        color: Color(Constants.GREY_COLOR_LIGHT),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  child: Container(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: EdgeInsets.all(8.0),
                  child: Text(
                    Language().getString(textName, selectedLang),
                    style: TextStyle(
                        fontSize: StyleView.FONT_SIZE_15,
                        fontWeight: StyleView.fontMedium),
                  ),
                ),
              )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                color: Colors.white,
                alignment: Alignment.centerLeft,
                padding: EdgeInsets.only(left: 5.0),
                child: TextField(
                    controller: _controller,
                    keyboardType: _isKeyboard
                        ? TextInputType.numberWithOptions(signed: true)
                        : TextInputType.text,
                    textInputAction: TextInputAction.next,
                    enabled: enable,
                    minLines: 1,
                    maxLines: 2,
                    style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: Language().getString(textName, selectedLang),
                    ),
                    inputFormatters: (_isKeyboard)
                        ? [CommonMethods.inputTextFormatter(isDouble: true)]
                        : []),
              ),
            )
          ],
        ));
  }

  disableFields(String text) {
    if (text == "Currency Code") {
      return false;
    } else if (text == "Value") {
      return false;
    } else {
      return true;
    }
  }

  String onValuesValidation() {
    if (_productNameController.text.isEmpty) {
      return Constants.PLEASE_ENTER_PRODUCT_NAME;
    } else if (_priceList.length == 0) {
      return Constants.PLEASE_ADD_PRICE_DETAILS;
    } else {
      return "";
    }
  }

  onCamera(String? textName) {
    return Container(
        padding: EdgeInsets.all(8.0),
        decoration: BoxDecoration(
          color: Colors.white70,
        ),
        child: Container(
          padding: EdgeInsets.only(left: 10),
          child: Align(
              alignment: Alignment.center,
              child: InkWell(
                onTap: () async {
                  if (kIsWeb) {
                    final _file = await Dialogs.getWebImage();
                    if (_file != null) {
                      _webImage = await _file.readAsBytes();
                      setState(() {
                        isSelectCaptureChoice = true;
                      });

                      uploadImage(_webImage, "web_product_image.png");
                    }
                  } else {
                    this.openBottomSheet(context);
                    // await AppUtills.openPDF('assets/sample.pdf', context);
                  }
                },
                child: Icon(
                  Icons.camera_alt,
                  color: Color(Constants.APP_COLOR),
                  size: 30.0,
                ),
              )),
        ));
  }

  openBottomSheet(BuildContext context) {
    return Dialogs.openBottomSheet(
        context: context,
        openCamera: (myPicture) async {
          this.updateProductImage(myPicture);
        },
        openGallery: (myPicture) async {
          this.updateProductImage(myPicture);
        });
  }

  updateProductImage(var fileImage) {
    Navigator.of(context).pop();
    if (fileImage != null) {
      setState(() {
        imageFile = fileImage;
        isSelectCaptureChoice = true;
        isImageUpdated = true;
        imageBlob = AppUtills.getBase64Image(fileImage, context);
      });
      uploadImage(imageFile, "");
    }
  }

  uploadImage(dynamic imageData, String fileName) async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = "Fetching..";
    });
    Map data = {
      "filename": (kIsWeb) ? fileName : imageData.path.split("/").last,
      "location": "product"
    };
    String body = json.encode(data);

    http.Response response = await _service
        .getPresignedUrl(body); //_service.get_file_upload_url(null);

    if (response.statusCode == 200) {
      var responseBody = json.decode(response.body);
      setState(() {
        progressMessage = "Uploading image..";
      });
      print('relative path ${responseBody['relativepath']}');

      var uploadFileRes =
          await _service.uploadToS3Signed(responseBody['url'], imageData);
      print(uploadFileRes);
      setState(() {
        imageRelativePath = responseBody['relativepath'];
        isLoadingProgress = false;
      });
      Toast.show(
        "File uploaded!",
        duration: Toast.lengthShort,
        gravity: Toast.bottom,
      );

      // this.submitInputData(relativePath: responseBody['relativepath']);
    } else {
      setState(() {
        isLoadingProgress = false;
      });
    }
  }

  buildQuantityView(
    String? _title,
    StateSetter setState,
    bool isPriceUpdate,
  ) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              decoration: BoxDecoration(
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(5.0),
                  )),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: RichText(
                    text: TextSpan(children: [
                      TextSpan(
                        text: Language().getString(_title, selectedLang),
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_15,
                            fontFamily: StyleView.FONT_TITLE,
                            color: Colors.black),
                      ),
                      TextSpan(
                          text: "\*",
                          style: TextStyle(
                              fontSize: StyleView.FONT_SIZE_15,
                              color: Colors.red))
                    ]),
                  ),
                ),
              )),
        ),
        Expanded(
            flex: 2,
            child: Container(
              decoration: BoxDecoration(
                  color: Colors.grey,
                  borderRadius:
                      BorderRadius.only(topRight: Radius.circular(5.0))),
              alignment: Alignment.centerLeft,
              child: Row(children: <Widget>[
                Expanded(
                    child: Container(
                  padding: EdgeInsets.only(left: 5),
                  margin: EdgeInsets.only(right: 1),
                  color: Colors.white,
                  child: TextFormField(
                    keyboardType: (defaultTargetPlatform == TargetPlatform.iOS)
                        ? TextInputType.numberWithOptions(
                            signed: true, decimal: false)
                        : TextInputType.number,
                    textInputAction: TextInputAction.next,
                    // enabled: isPriceUpdate ? false : true,
                    controller: _qntyController,
                    style: TextStyle(fontFamily: Constants.INDIAN_RUPEE),
                    decoration: InputDecoration(
                        border: InputBorder.none, hintText: _title),
                    inputFormatters: [
                      new LengthLimitingTextInputFormatter(6),
                      CommonMethods.inputTextFormatter(isNumber: true)
                    ],
                    onChanged: (value) {
                      if (value.isNotEmpty) {
                        productTotalQuantity = int.parse(value);
                      }
                    },
                  ),
                )),
                Expanded(
                    child: Container(
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.only(
                                topRight: Radius.circular(5.0))),
                        padding: EdgeInsets.only(left: 5),
                        child: DropdownButton<String>(
                            onTap: () {
                              CommonMethods.hideKeyboard(context);
                            },
                            value: quantityDropdownValue,
                            hint: new Text(
                              Language()
                                  .getString(Constants.SELECT, selectedLang),
                            ),
                            isExpanded: true,
                            underline: SizedBox(),
                            onChanged: (String? data) {
                              setState(() {
                                quantityDropdownValue = data;
                                priceUnitDropdownValue = data;
                                inventoryQuntityInDropdown = data;
                              });
                            },
                            items: Constants.UNIT_PRICE.map((String model) {
                              return new DropdownMenuItem<String>(
                                child: new Text(model),
                                value: model,
                              );
                            }).toList()))),
              ]),
            ))
      ],
    );
  }

  _aspectRatio() {
    if (kIsWeb) {
      return MediaQuery.of(context).size.width /
          MediaQuery.of(context).size.height *
          2;
    } else {
      return MediaQuery.of(context).size.width /
          MediaQuery.of(context).size.height *
          3;
    }
  }

  Widget displayImageView() {
    if (isSelectCaptureChoice) {
      return AspectRatio(
          aspectRatio: _aspectRatio(),
          child: ClipRRect(
            borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(10),
                bottomRight: Radius.circular(10)),
            child: (kIsWeb)
                ? Image.memory(_webImage!)
                : Image.file(
                    imageFile!,
                    fit: BoxFit.fitWidth,
                    gaplessPlayback: true,
                  ),
          ));
    } else {
      if (_productsList.length > 0 && _productsList[0].images != null) {
        return AppUtills.imageAspectRatio(_productsList[0].images,
            aspectRatio: _aspectRatio(), context: context);
      } else {
        return AspectRatio(
            aspectRatio: _aspectRatio(),
            child: ClipRRect(
                borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(10),
                    bottomRight: Radius.circular(10)),
                child: Image.asset(
                  'assets/images/no_image.jpg',
                  gaplessPlayback: true,
                  fit: BoxFit.contain,
                )));
      }
    }
  }

  buildDropDownCurrencyName(String _title, StateSetter setState) {
    return Column(children: <Widget>[
      Row(
        children: <Widget>[
          Expanded(
            child: Container(
                height: 50,
                decoration: BoxDecoration(
                    color: Color(Constants.GREY_COLOR_LIGHT),
                    borderRadius:
                        BorderRadius.only(bottomLeft: Radius.circular(5.0))),
                child: Container(
                  padding: EdgeInsets.only(left: 10),
                  child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(Language().getString(_title, selectedLang),
                          style: TextStyle(
                              fontSize: StyleView.FONT_SIZE_15,
                              fontFamily: StyleView.FONT_TITLE))),
                )),
          ),
          Expanded(
            flex: 2,
            child: Container(
                decoration: BoxDecoration(
                    color: Colors.white70,
                    borderRadius:
                        BorderRadius.only(bottomRight: Radius.circular(5.0))),
                padding: EdgeInsets.only(left: 5, right: 5),
                child: DropdownButton<CurrencyNameDAO>(
                    onTap: () {
                      CommonMethods.hideKeyboard(context);
                    },
                    isExpanded: true,
                    hint: Text(Language().getString(_title, selectedLang)),
                    underline: SizedBox(),
                    items: _currencyNameList
                        .map((CurrencyNameDAO _currencyNameValue) {
                      return DropdownMenuItem<CurrencyNameDAO>(
                        value: _currencyNameValue,
                        child: new Text(
                          _currencyNameValue.name!,
                          style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                        ),
                      );
                    }).toList(),
                    value: currencyNameDropdown,
                    onChanged: (CurrencyNameDAO? _currency) {
                      setState(() {
                        currencyNameDropdown = _currency;
                        currencySymbol = currencyNameDropdown!.htmlSymbol;
                      });
                    })),
          )
        ],
      )
    ]);
  }

  buildUnitDropdown(String _title, StateSetter setState) {
    return Container(
        child: Column(children: <Widget>[
      Container(
          color: Colors.white,
          // padding: EdgeInsets.all(1),
          child: Row(
            children: <Widget>[
              Expanded(
                child: Container(
                    height: 50,
                    color: Color(Constants.GREY_COLOR_LIGHT),
                    child: Container(
                      padding: EdgeInsets.only(left: 10),
                      child: Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                              Language().getString(_title, selectedLang),
                              style: TextStyle(
                                  fontSize: StyleView.FONT_SIZE_15,
                                  fontFamily: StyleView.FONT_TITLE))),
                    )),
              ),
              Expanded(
                flex: 2,
                child: Row(
                  children: [
                    (priceUnitDropdownValue != null)
                        ? Expanded(
                            child: Container(
                                padding: EdgeInsets.only(
                                  left: 5,
                                ),
                                child: Text(
                                  "per : $priceUnitDropdownValue",
                                  style: TextStyle(fontSize: 15.0),
                                )),
                          )
                        : Container(),
                  ],
                ),
              )
            ],
          ))
    ]));
  }

  buildText(String title, String _offerValue) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(title,
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_15,
                            fontFamily: StyleView.FONT_TITLE))),
              )),
        ),
        Expanded(
          flex: 2,
          child: Container(
              color: Colors.white70,
              height: 50,
              padding: EdgeInsets.only(left: 5),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  _offerValue,
                  style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                ),
              )),
        )
      ],
    );
  }

  buildDropDownState(String _title) {
    return Container(
        child: Column(children: <Widget>[
      Container(
          // padding: EdgeInsets.all(1),
          child: Row(
        children: <Widget>[
          Expanded(
            child: Container(
                height: 50,
                color: Color(Constants.GREY_COLOR_LIGHT),
                child: Container(
                  padding: EdgeInsets.only(left: 10),
                  child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(Language().getString(_title, selectedLang),
                          style: TextStyle(
                              fontSize: StyleView.FONT_SIZE_15,
                              fontFamily: StyleView.FONT_TITLE))),
                )),
          ),
          Expanded(
            flex: 2,
            child: Container(
                color: Colors.white,
                padding: EdgeInsets.only(left: 5, right: 5),
                child: DropdownButton<StatesDAO>(
                    onTap: () {
                      CommonMethods.hideKeyboard(context);
                    },
                    value: _stateName,
                    hint: new Text(Language()
                        .getString(Constants.SELECT_STATE, selectedLang)),
                    isExpanded: true,
                    underline: SizedBox(),
                    onChanged: (StatesDAO? data) {
                      _districtList.clear();
                      districtDropdownValue = null;
                      citiesDropDownValue = null;
                      _citiesList.clear();
                      setState(() {
                        _stateName = data;
                        _districtList.addAll(_stateName!.cities!);
                      });

                      this
                          .getCitiesList(_countryName!.name, _stateName!.id)
                          .then((value) {
                        if (value.length > 0) {
                          setState(() {
                            _citiesList.clear();
                            _citiesList.addAll(value[0].cities!);
                          });
                        }
                      });
                    },
                    items: stateList.map((StatesDAO model) {
                      return new DropdownMenuItem<StatesDAO>(
                        child: new Text(model.state!),
                        value: model,
                      );
                    }).toList())),
          )
        ],
      ))
    ]));
  }

  /// City Dropdown
  buildCityDropdown(String text) {
    return Container(
        // padding: EdgeInsets.all(1),
        child: Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(Language().getString(text, selectedLang),
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_15,
                            fontFamily: StyleView.FONT_TITLE))),
              )),
        ),
        Expanded(
          flex: 2,
          child: Container(
              color: Colors.white70,
              padding: EdgeInsets.only(left: 5, right: 5),
              child: DropdownButton<String>(
                  value: citiesDropDownValue,
                  isExpanded: true,
                  hint: Text(Language()
                      .getString(Constants.SELECT_CITY, selectedLang)),
                  underline: SizedBox(),
                  onChanged: (String? data) {
                    setState(() {
                      citiesDropDownValue = data;
                    });
                  },
                  onTap: () {
                    CommonMethods.hideKeyboard(context);
                  },
                  items: _citiesList.map((String model) {
                    return new DropdownMenuItem<String>(
                      child: new Text(model),
                      value: model,
                    );
                  }).toList())),
        )
      ],
    ));
  }

  buildDropDownDistrict(String _title) {
    return Container(
        child: Column(children: <Widget>[
      Container(
          // padding: EdgeInsets.all(1),
          child: Row(
        children: <Widget>[
          Expanded(
            child: Container(
                height: 50,
                color: Color(Constants.GREY_COLOR_LIGHT),
                child: Container(
                  padding: EdgeInsets.only(left: 10),
                  child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(Language().getString(_title, selectedLang),
                          style: TextStyle(
                              fontSize: StyleView.FONT_SIZE_15,
                              fontFamily: StyleView.FONT_TITLE))),
                )),
          ),
          Expanded(
            flex: 2,
            child: Container(
                color: Colors.white,
                padding: EdgeInsets.only(left: 5, right: 5),
                child: DropdownButton<String>(
                    onTap: () {
                      CommonMethods.hideKeyboard(context);
                    },
                    value: districtDropdownValue,
                    hint: new Text(Language()
                        .getString(Constants.SELECT_DISTRICT, selectedLang)),
                    isExpanded: true,
                    underline: SizedBox(),
                    onChanged: (String? data) {
                      setState(() {
                        districtDropdownValue = data;
                      });
                    },
                    items: _districtList.map((String model) {
                      return new DropdownMenuItem<String>(
                        child: new Text(model),
                        value: model,
                      );
                    }).toList())),
          )
        ],
      ))
    ]));
  }

  buildDropDownCountry(String _title) {
    return Container(
        child: Column(children: <Widget>[
      Container(
          // padding: EdgeInsets.all(1),
          child: Row(
        children: <Widget>[
          Expanded(
            child: Container(
                height: 50,
                color: Color(Constants.GREY_COLOR_LIGHT),
                child: Container(
                  padding: EdgeInsets.only(left: 10),
                  child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(Language().getString(_title, selectedLang),
                          style: TextStyle(
                              fontSize: StyleView.FONT_SIZE_15,
                              fontFamily: StyleView.FONT_TITLE))),
                )),
          ),
          Expanded(
            flex: 2,
            child: Container(
                color: Colors.white,
                padding: EdgeInsets.only(left: 5, right: 5),
                child: DropdownButton<CountryDAO>(
                    onTap: () {
                      CommonMethods.hideKeyboard(context);
                    },
                    value: _countryName,
                    hint: new Text(Language()
                        .getString(Constants.SELECT_COUNTRY, selectedLang)),
                    isExpanded: true,
                    underline: SizedBox(),
                    onChanged: (CountryDAO? data) {
                      _countryName = data;
                      getStates(_countryName!.name!).then((onValue) {
                        setState(() {
                          stateList.addAll(onValue);
                        });
                      });
                    },
                    items: countryList.map((CountryDAO model) {
                      return new DropdownMenuItem<CountryDAO>(
                        child: new Text(model.name!),
                        value: model,
                      );
                    }).toList())
                // CustomSearchableDropDown(
                //     // initialIndex: 10,
                //     items: countryList.toList(),
                //     label: Language()
                //         .getString(Constants.SELECT_COUNTRY, selectedLang),
                //     onChanged: (value) {
                //       CommonMethods.hideKeyboard(context);
                //       if (value != null) {
                //         _countryName = value;
                //         getStates(_countryName!.name!).then((onValue) {
                //           // setState(() {
                //           stateList.addAll(onValue);
                //           // });
                //         });
                //       }
                //     },
                //     dropDownMenuItems: countryList.map((e) => e.name).toList())

                //  ,
                ),
          )
        ],
      ))
    ]));
  }

  buildPincodeView() {
    return Container(
        // padding: EdgeInsets.all(1),
        child: Row(
      children: <Widget>[
        Expanded(
          child: Container(
            height: 50,
            color: Color(Constants.GREY_COLOR_LIGHT),
            child: Container(
              padding: EdgeInsets.only(left: 10),
              child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                      Language().getString(Constants.PIN_CODE, selectedLang),
                      style: TextStyle(
                          fontSize: StyleView.FONT_SIZE_15,
                          fontFamily: StyleView.FONT_TITLE))),
            ),
          ),
        ),
        Expanded(
            flex: 2,
            child: Container(
              color: Colors.white70,
              padding: EdgeInsets.only(left: 5),
              child: TextFormField(
                controller: _pinController,
                keyboardType: (defaultTargetPlatform == TargetPlatform.iOS)
                    ? TextInputType.numberWithOptions(signed: true)
                    : TextInputType.number,
                textInputAction: TextInputAction.done,
                style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                decoration: InputDecoration(
                  hintText:
                      Language().getString(Constants.PIN_CODE, selectedLang),
                  border: InputBorder.none,
                ),
                inputFormatters: [
                  new LengthLimitingTextInputFormatter(6),
                  FilteringTextInputFormatter.digitsOnly
                ],
              ),
            ))
      ],
    ));
  }

  updateProduct(
      {bool isUpdateProduct = false, String relativePath = ""}) async {
    if (isUpdateProduct && imagePath == null && !isSelectCaptureChoice) {
      setState(() {
        imageBlob = _productsList[0].images;
      });
    }
    this.renderItemDetails();
    List<Map<String, dynamic>> locationsArray = [];
    var locationObject;

    for (int i = 0; i < inventoryList.length; i++) {
      locationObject = {
        "location_name": inventoryList[i].locationName,
        "location_id": inventoryList[i].locationId,
        "quantity": inventoryList[i].quantity,
        "batch_no": inventoryList[i].batchNumber,
        "quantity_in": inventoryList[i].quantityIn
      };
      List<Map<String, dynamic>> inventoryBatchList = [];
      var inventoryBatchObject;
      for (int j = 0; j < inventoryList[i].locationBatchList!.length; j++) {
        inventoryBatchObject = {
          "batch_number": inventoryList[i].locationBatchList![j].batchNumber,
          "quantity": inventoryList[i].locationBatchList![j].quantity,
          "quantity_in": inventoryList[i].locationBatchList![j].quantityIn,
          "updated_user": inventoryList[i].locationBatchList![j].updatedUser,
          "updated_date": inventoryList[i].locationBatchList![j].updatedDate
        };
        inventoryBatchList.add(inventoryBatchObject);
      }
      locationObject['location_batch_list'] = inventoryBatchList;

      locationsArray.add(locationObject);
    }
    // List<Map<String, dynamic>> ondcFeaturesArray = [];
    // var ondcFeatureObject;
    // if (ondcFormTitles.length > 0 && ondcTextEditingController.length > 0) {
    //   for (int i = 0; i < ondcTextEditingController.length; i++) {
    //     ondcFeatureObject = {
    //       "${ondcFormTitles[i + 1]}":
    //           "${ondcTextEditingController[i].text.trim()}"
    //     };
    //     ondcFeaturesArray.add(ondcFeatureObject);
    //   }
    // }
    List<Map<String, dynamic>> attributesArray = [];
    var attributesObject;
    for (int i = 0; i < attributesList.length; i++) {
      attributesObject = {
        "${attributesList[i].attributeKey}":
            "${attributesList[i].attributeValue}"
      };
      attributesArray.add(attributesObject);
    }

    List<Map<String, dynamic>> offerArray = [];
    var offerObject;
    List<String> splitOffer = [];
    for (int i = 0; i < _offersList.length; i++) {
      if (_offersList[i].offerDiscount == Constants.OFFER_IN_PERCENTAGE) {
        splitOffer = _offersList[i].offerQuantity.toString().split(" %");
      } else {
        splitOffer.add(_offersList[i].offerQuantity.toString());
      }
      offerObject = {
        "offer_name": _offersList[i].offerName,
        "offer_quantity": double.parse(splitOffer[0]),
        "min_order": _offersList[i].minOrder,
        "max_order": _offersList[i].maxOrder,
        "start_date": _offersList[i].startDate,
        "end_date": _offersList[i].endDate,
        "details": _offersList[i].details,
        "is_offer_active": _offersList[i].isOfferActive,
        "offer_type": _offersList[i].offerDiscount
      };
      offerArray.add(offerObject);
    }

    List<Map<String, dynamic>> supplierArray = [];
    var supplierObject;
    for (int i = 0; i < _supplierList.length; i++) {
      supplierObject = {
        "name": _supplierList[i].name,
        "id": _supplierList[i].id,
        "city": _supplierList[i].city,
        "district": _supplierList[i].district,
        "colonysector_arealocality": _supplierList[i].locality,
        "contact_number": _supplierList[i].contact
      };
      supplierArray.add(supplierObject);
    }
    List<String> tax = [];
    if (taxValueDropdownValue != null) {
      tax = taxValueDropdownValue!.split(" %");
    } else {
      tax.add("0");
    }

    List<Map<String, dynamic>> batchPriceArray = [];
    var batchPriceObject;

    for (int p = 0; p < _priceList.length; p++) {
      batchPriceObject = {
        "price": double.parse(_priceList[p].price!),
        "unit": _priceList[p].priceIn,
        "currency_code": "",
        "currency_name": _priceList[p].currencyName,
        "batch_number": _priceList[p].batchNumber,
        "quantity": num.parse(_priceList[p].quantity!),
        "quantity_in": _priceList[p].quantityIn,
        "net_rate": double.parse(_priceList[p].netRate!),
        "mrp": double.parse(_priceList[p].mrp!),
        "manufacture_date_time": _priceList[p].manufacturDate,
        "expiry_date": _priceList[p].expireDate,
        "issue_id": _priceList[p].issuedId,
        "issued_to": _priceList[p].issuedTo,
        "is_raw_material": _priceList[p].isRawMaterial,
        "is_actual_product": _priceList[p].isActualProduct,
        "price_description": _priceList[p].description,
        "issue_number": _priceList[p].issueNumber,
        "barcode": _priceList[p].barcode
      };

      batchPriceArray.add(batchPriceObject);
    }

    List<Map<String, dynamic>> rawInventoryArray = [];
    var rawInventoryObject;

    for (int i = 0; i < rawInventoryList.length; i++) {
      rawInventoryObject = {
        "issued_to": rawInventoryList[i].issuedTo,
        "quantity": rawInventoryList[i].quantity,
        "batch_no": rawInventoryList[i].batchNumber
      };
      rawInventoryArray.add(rawInventoryObject);
    }

    var data = {
      "bu_id": buId,
      "sku": _skuController.text,
      "name": _productNameController.text,
      "type": "product",
      "brand": _brandController.text,
      "description": _descriptionController.text,
      "product_segment": _productSegment != null ? _productSegment!.type : "",
      "product_category":
          _productCategory != null ? _productCategory!.type : "",
      "product_sub_category":
          _productSubCategory != null ? _productSubCategory!.type : "",
      "product_type": _productType != null ? _productType!.type : "",
      "product_sub_type": _productSubType != null ? _productSubType!.type : "",
      "in_stock": inStockRadioValue == "Yes" ? true : false,
      "for_sale": forSaleRadioValue == "Yes" ? true : false,
      "special_characteristics": {},
      "attributes": attributesArray,
      "unit_sizes": {},
      "manufacture_details": {
        "model_number": _modelNumberController.text,
        "release_date": formattedReleaseDate,
        "name": _manufactureNameController.text,
        "manufacturer_Address": _manufactureAddressController.text,
        "building_name": _buildingNumController.text,
        "area": _areaController.text,
        "city": citiesDropDownValue != null ? citiesDropDownValue : "",
        "taluka": _talukController.text,
        "landmark": _landMarkController.text,
        "state": _stateName != null ? _stateName!.state : "",
        "district": districtDropdownValue != null ? districtDropdownValue : "",
        "pin": _pinController.text,
        "country": _countryName != null ? _countryName!.name : "",
        "dial_code": _dialCodeController.text
      },
      "suppliers": supplierArray,
      "shipping_details": {
        "weight": strWeight,
        "width": strWidth,
        "height": strHeight,
        "depth": strDepth,
        "volume": strVolume,
      },
      "batch_pricing": batchPriceArray,
      "tax": {
        "type": taxDropdownValue != null ? taxDropdownValue : "GST",
        "value": int.parse(tax[0]),
        "hsn_code": hsnCodeController.text
      },
      "offers": offerArray,
      "inventory_management": locationsArray,
      "raw_material": widget.isFromRawMaterialPage,
      "from_raw_material": rawMaterialProductRadioValue != null ? true : false,
      "raw_inventory_management": rawInventoryArray,
      "quantity_adjustments": [],
      "product_sector": productSectorDropdown != null
          ? productSectorDropdown!.sectorName
          : "",
      "images": imageRelativePath,
      "is_consumable": widget.isFromConsumablePage
      // "ondc_features": ondcFeaturesArray
    };

    String body = "";
    if (isUpdateProduct) {
      data['id'] = widget.productId;
    }
    body = json.encode(data);
    var response;
    if (isUpdateProduct) {
      response = await _productService.updateProduct_grpc(
          body: body, token: AppController.instance.authorizationKey!);
    } else {
      response = await _productService.createProduct_grpc(
          body: body, token: AppController.instance.authorizationKey!);
    }

    setState(() {
      isLoadingProgress = false;
    });

    if (response != null) {
      isImageUpdated = false;
      GRPCResponse _grpcResponse = response;
      if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
        final action = await Dialogs.yesCancelDialog(
            context,
            Language().getString(Constants.SUCCESS, selectedLang),
            Language().getString(
                (isUpdateProduct
                    ? Language()
                        .getString(Constants.PRODUCT_UPDATED, selectedLang)
                    : Language()
                        .getString(Constants.PRODUCT_CREATED, selectedLang)),
                selectedLang),
            Language().getString(Constants.OKAY_STR, selectedLang),
            "",
            false);
        if (action == DialogAction.yes) {
          Navigator.pop(context);
          if (widget.isFromRawMaterialPage) {
            Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (context) => RawProductsListPage()),
                (route) => false);
          } else if (widget.isFromConsumablePage) {
            Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(
                    builder: (context) => ConsumableProductsListPage()),
                (route) => false);
          } else if (widget.isFromBuList) {
            Navigator.of(context).pop();
          } else {
            Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (context) => ProductsMenuPage()),
                (route) => false);
          }
        }
      } else {
        Dialogs.yesCancelDialog(
            context,
            Language().getString(Constants.ERROR, selectedLang),
            _grpcResponse.message,
            Language().getString(Constants.OKAY_STR, selectedLang),
            "",
            false);
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          "$response",
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  renderItemDetails() {
    strHeight = _heightController.text +
        " " +
        (heightDropdownValue != null ? heightDropdownValue! : "");
    strWeight = _weightController.text +
        " " +
        (weightDropdownValue != null ? weightDropdownValue! : "");
    strWidth = _widthController.text +
        " " +
        (widthDropdownValue != null ? widthDropdownValue! : "");
    strVolume = volumeController.text +
        " " +
        (volumeDropdownValue != null ? volumeDropdownValue! : "");
    strDepth = _depthController.text +
        " " +
        (depthDropdownValue != null ? depthDropdownValue! : "");
  }

  buildTextField(String _text) {
    return Row(
      children: <Widget>[
        Align(
            child: Text(_text,
                style: TextStyle(
                    fontFamily: StyleView.FONT_TITLE,
                    fontWeight: FontWeight.bold,
                    fontSize: StyleView.FONT_SIZE_15,
                    color: Colors.black)))
      ],
    );
  }

  buildDropDownTax(String _title) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(Language().getString(_title, selectedLang),
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_15,
                            fontFamily: StyleView.FONT_TITLE))),
              )),
        ),
        Expanded(
          flex: 2,
          child: Container(
              color: Colors.white70,
              padding: EdgeInsets.only(left: 5, right: 5),
              child: DropdownButton<String>(
                  onTap: () {
                    CommonMethods.hideKeyboard(context);
                  },
                  value: taxDropdownValue,
                  hint: new Text(
                    Language().getString(Constants.SELECT, selectedLang),
                  ),
                  isExpanded: true,
                  underline: SizedBox(),
                  onChanged: (String? data) {
                    setState(() {
                      taxDropdownValue = data;
                    });
                  },
                  items: Constants.taxTypes.map((String model) {
                    return new DropdownMenuItem<String>(
                      child: new Text(model),
                      value: model,
                    );
                  }).toList())),
        )
      ],
    );
  }

  buildDropdownTaxValue(String _title) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(Language().getString(_title, selectedLang),
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_15,
                            fontFamily: StyleView.FONT_TITLE))),
              )),
        ),
        Expanded(
          flex: 2,
          child: Container(
              color: Colors.white70,
              padding: EdgeInsets.only(left: 5, right: 5),
              child: DropdownButton<String>(
                  onTap: () {
                    CommonMethods.hideKeyboard(context);
                  },
                  value: taxValueDropdownValue,
                  hint: new Text("%"),
                  isExpanded: true,
                  underline: SizedBox(),
                  onChanged: (String? data) {
                    // onChangeProductTax(data);
                    setState(() {
                      taxValueDropdownValue = data;
                      // _valueControllr.text = data.value;
                    });
                  },
                  items: Constants.taxRateValues.map((String model) {
                    return new DropdownMenuItem<String>(
                      child: new Text(model),
                      value: model,
                    );
                  }).toList())),
        )
      ],
    );
  }

  buildDateFieldRelease(String _title) {
    return Container(
        // padding: EdgeInsets.all(1),
        child: Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: RichText(
                      text: TextSpan(children: [
                        TextSpan(
                          text: Language().getString(_title, selectedLang),
                          style: TextStyle(
                              fontSize: StyleView.FONT_SIZE_15,
                              fontFamily: StyleView.FONT_TITLE,
                              color: Colors.black),
                        ),
                      ]),
                    )),
              )),
        ),
        Expanded(
            flex: 2,
            child: Container(
              color: Colors.white70,
              padding: EdgeInsets.only(left: 5),
              alignment: Alignment.topLeft,
              child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white, elevation: 0.0),
                  onPressed: () async {
                    CommonMethods.hideKeyboard(context);
                    // pickCustomDate(context, _title);
                    String value = await AppUtills.getSelectedDate(context);
                    setState(() {
                      formattedReleaseDate = value;
                    });
                  },
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Text(
                        formattedReleaseDate,
                        style: TextStyle(color: Colors.black),
                      ),
                      Image.asset(
                        'assets/images/calander.png',
                        height: 30,
                      )
                    ],
                  )),
            )),
      ],
    ));
  }

  buildDateFieldManufacture(String _title, StateSetter setState) {
    return Container(
        // padding: EdgeInsets.all(1),
        child: Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: RichText(
                      text: TextSpan(children: [
                        TextSpan(
                          text: Language().getString(_title, selectedLang),
                          style: TextStyle(
                              fontSize: StyleView.FONT_SIZE_15,
                              fontFamily: StyleView.FONT_TITLE,
                              color: Colors.black),
                        ),
                      ]),
                    )),
              )),
        ),
        Expanded(
            flex: 2,
            child: Container(
              color: Colors.white,
              padding: EdgeInsets.only(left: 5),
              alignment: Alignment.topLeft,
              child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white, elevation: 0.0),
                  onPressed: () async {
                    FocusScope.of(context).requestFocus(
                        new FocusNode()); // CommonMethods.hideKeyboard(context);
                    String value = await AppUtills.getSelectedDate(context);
                    setState(() {
                      formattedManufactureDate = value;
                    });
                  },
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Text(
                        formattedManufactureDate!,
                        style: TextStyle(color: Colors.black),
                      ),
                      Image.asset(
                        'assets/images/calander.png',
                        height: 30,
                      )
                    ],
                  )),
            )),
      ],
    ));
  }

  buildDateFieldExpaire(String _title, StateSetter setState) {
    return Container(
        // padding: EdgeInsets.all(1),
        child: Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: RichText(
                      text: TextSpan(children: [
                        TextSpan(
                          text: Language().getString(_title, selectedLang),
                          style: TextStyle(
                              fontSize: StyleView.FONT_SIZE_15,
                              fontFamily: StyleView.FONT_TITLE,
                              color: Colors.black),
                        ),
                      ]),
                    )),
              )),
        ),
        Expanded(
            flex: 2,
            child: Container(
              color: Colors.white,
              padding: EdgeInsets.only(left: 5),
              alignment: Alignment.topLeft,
              child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    elevation: 0.0,
                  ),
                  onPressed: () async {
                    FocusScope.of(context).requestFocus(
                        new FocusNode()); //CommonMethods.hideKeyboard(context);

                    String value = await AppUtills.getSelectedDate(context,
                        isShowIntialDate: true);
                    setState(() {
                      formattedExpireDate = value;
                    });
                  },
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Text(
                        formattedExpireDate!,
                        style: TextStyle(color: Colors.black),
                      ),
                      Image.asset(
                        'assets/images/calander.png',
                        height: 30,
                      )
                    ],
                  )),
            )),
      ],
    ));
  }

  showSubCategoryDropdown(String _title) {
    return Container(
        child: Column(children: <Widget>[
      Container(
          // padding: EdgeInsets.all(1),
          child: Row(
        children: <Widget>[
          Expanded(
            child: Container(
                height: 50,
                color: Color(Constants.GREY_COLOR_LIGHT),
                child: Container(
                  padding: EdgeInsets.only(left: 10),
                  child: Align(
                      alignment: Alignment.centerLeft,
                      child: RichText(
                        text: TextSpan(children: [
                          TextSpan(
                            text: Language().getString(_title, selectedLang),
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: StyleView.FONT_TITLE,
                                color: Colors.black),
                          ),
                        ]),
                      )),
                )),
          ),
          Expanded(
              flex: 2,
              child: Container(
                  height: 50.0,
                  color: Colors.white70,
                  alignment: Alignment.centerLeft,
                  padding: EdgeInsets.only(left: 5, right: 5),
                  child: TextButton(
                      onPressed: () async {
                        if (_productCategory == null) {
                          Dialogs.yesCancelDialog(
                              context,
                              Language()
                                  .getString(Constants.ERROR, selectedLang),
                              Language().getString(
                                  Constants.PLEASE_SELECT_PRODUCT_SUB_CATEGORY,
                                  selectedLang),
                              Language()
                                  .getString(Constants.OKAY_STR, selectedLang),
                              "",
                              false);
                          return;
                        }
                        Future.delayed(Duration(milliseconds: 500));
                        await SubCategoryDialog.showSubCategoryDialog(
                            context: context,
                            categoryList: productSubCategories,
                            onYesPress: (ProductSubCategoryDAO? data) {
                              CommonMethods.hideKeyboard(context);
                              if (data != null) {
                                setState(() => _productSubCategory = data);
                              }
                              Navigator.of(context).pop();
                            },
                            onCacelPress: () => Navigator.of(context).pop());
                      },
                      child: renderProductType(_productSubCategory != null
                          ? _productSubCategory!.type!
                          : Language().getString(
                              Constants.SELECT_SUB_CATEGORY, selectedLang)))))
        ],
      ))
    ]));
  }

  buildDropdownSector(String _title) {
    return Container(
      child: Column(
        children: <Widget>[
          Container(
              // padding: EdgeInsets.all(1),
              child: Row(
            children: <Widget>[
              Expanded(
                child: Container(
                    height: 50,
                    color: Color(Constants.GREY_COLOR_LIGHT),
                    child: Container(
                      padding: EdgeInsets.only(left: 10),
                      child: Align(
                          alignment: Alignment.centerLeft,
                          child: RichText(
                            text: TextSpan(children: [
                              TextSpan(
                                text:
                                    Language().getString(_title, selectedLang),
                                style: TextStyle(
                                    fontSize: StyleView.FONT_SIZE_15,
                                    fontFamily: StyleView.FONT_TITLE,
                                    color: Colors.black),
                              ),
                            ]),
                          )),
                    )),
              ),
              Expanded(
                  flex: 2,
                  child: Container(
                      height: 50.0,
                      color: Colors.white70,
                      alignment: Alignment.centerLeft,
                      padding: EdgeInsets.only(left: 5, right: 5),
                      child: TextButton(
                          onPressed: () async {
                            Future.delayed(Duration(milliseconds: 500));
                            await ProductSectorDialog.showProductSectorDialog(
                                context: context,
                                categoryList: productSectorList,
                                onYesPress: (ProductSectorDAO? data) {
                                  CommonMethods.hideKeyboard(context);
                                  if (data != null) {
                                    setState(() {
                                      _productCategory = null;
                                      productCategories.clear();
                                      productSubCategories.clear();
                                      _productSubCategory = null;
                                      productSectorDropdown = data;
                                    });

                                    loadProductCategories(
                                        parentCode:
                                            productSectorDropdown!.parentId!);
                                  }

                                  Navigator.of(context).pop();
                                },
                                onCacelPress: () =>
                                    Navigator.of(context).pop());
                          },
                          child: renderProductType(productSectorDropdown != null
                              ? productSectorDropdown!.sectorName!
                              : "Select sector"))))
            ],
          ))
        ],
      ),
    );
  }

  Widget showCaterogyDropdown(String _title) {
    return Container(
        child: Column(children: <Widget>[
      Container(
          child: Row(
        children: <Widget>[
          Expanded(
            child: Container(
                height: 50,
                color: Color(Constants.GREY_COLOR_LIGHT),
                child: Container(
                  padding: EdgeInsets.only(left: 10),
                  child: Align(
                      alignment: Alignment.centerLeft,
                      child: RichText(
                        text: TextSpan(children: [
                          TextSpan(
                            text: Language().getString(_title, selectedLang),
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: StyleView.FONT_TITLE,
                                color: Colors.black),
                          ),
                        ]),
                      )),
                )),
          ),
          Expanded(
            flex: 2,
            child: Container(
                height: 50.0,
                color: Colors.white70,
                alignment: Alignment.centerLeft,
                padding: EdgeInsets.only(left: 5, right: 5),
                child: TextButton(
                    onPressed: () async {
                      Future.delayed(Duration(milliseconds: 500));
                      await CategoryDialog.showProductCategoryDialog(
                          context: context,
                          categoryList: productCategories,
                          onYesPress: (ProductCategoryDAO? data) {
                            CommonMethods.hideKeyboard(context);
                            if (data != null) {
                              setState(() {
                                _productCategory = data;
                                _productSubCategory = null;
                                productSubCategories.clear();
                              });
                              loadProductSubCategory(
                                  parentCode: _productCategory!.code!);
                            }

                            Navigator.of(context).pop();
                          },
                          onCacelPress: () => Navigator.of(context).pop());
                    },
                    child: renderProductType(_productCategory != null
                        ? _productCategory!.type!
                        : Language().getString(
                            Constants.SELECT_CATEGORY, selectedLang)))),
          )
        ],
      ))
    ]));
  }

  // updateOndcCategoryList(ProductCategoryDAO data) {
  //   if (data.name == "Grocery") {
  //     // ondcCategoryList.add(value)
  //   }

  //   if (data.name == "Fashion") {
  //     ondcCategoryList.addAll(Fashion.fashion);
  //   }
  //   if (data.name == "BPC") {
  //     ondcCategoryList.addAll(BPS.bpc);
  //   }
  //   if (data.name == "Electronics") {
  //     ondcCategoryList.addAll(Electronics.electronics);
  //   }
  //   if (data.name == "Appliances") {
  //     ondcCategoryList.addAll(Appliances.appliances);
  //   }
  //   if (data.name == "Home & Kitchen") {
  //     ondcCategoryList.addAll(HomeAndKitchen.home_kitchen);
  //   }
  //   if (data.name == "Health & Wellness") {
  //     ondcCategoryList.addAll(HealthAndWellness.health_wellness);
  //   }
  // }

  Widget renderProductType(String name) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
          child: Text(
            name,
            style: TextStyle(
                overflow: TextOverflow.ellipsis,
                fontWeight: StyleView.fontMedium,
                color: Colors.black,
                fontSize: 15.0),
          ),
        ),
        SizedBox(width: 8),
        Icon(
          Icons.keyboard_arrow_down_outlined,
          color: Colors.black,
        )
      ],
    );
  }

  buildOffersInputFields(String? _labelText, bool isKeyboard,
      TextEditingController controller, bool isEnabled) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 5.0),
      child: TextField(
          enabled: isEnabled,
          keyboardType: isKeyboard
              ? TextInputType.numberWithOptions(signed: true)
              : TextInputType.text,
          style: TextStyle(fontFamily: StyleView.FONT_TITLE),
          controller: controller,
          textInputAction: TextInputAction.next,
          decoration: InputDecoration(
              hintText: _labelText,
              border: OutlineInputBorder(),
              focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Color(Constants.BORDER_GREY)))),
          inputFormatters: (isKeyboard)
              ? [CommonMethods.inputTextFormatter(isNumber: true)]
              : []),
    );
  }

  saveOffersDataList(bool isUpdateOffers, int updateOfferIndex) {
    List<String> splitPercentage = [];
    if (offerRadioValue == Constants.OFFER_IN_PERCENTAGE &&
        offerInPercentage != null) {
      splitPercentage = offerInPercentage!.split(" %");
    } else {
      splitPercentage.add(_offerQtyController.text);
    }
    if (isUpdateOffers) {
      if (isOfferActive) {
        this.updateOfferStatus(updateOfferIndex);
      }

      _offersList[updateOfferIndex] = OffersModel(
          offerName: _offerNameController.text,
          offerQuantity: double.parse(splitPercentage[0]),
          minOrder: int.parse(
              minOrderDropdownValue != null ? minOrderDropdownValue! : "1"),
          maxOrder: int.parse(
              maxOrderDropdownValue != null ? maxOrderDropdownValue! : "1"),
          startDate: formattedOfferStartDate,
          endDate: formattedOfferEndDate,
          isOfferActive: isOfferActive,
          offerDiscount: offerRadioValue,
          details: _detailsController.text,
          isOfferExpired: _offersList[updateOfferIndex].isOfferExpired);
      setState(() {
        _offersList.reversed;
      });
    } else {
      formattedOfferStartDate = formatter.format(offerStartDate);
      // formattedOfferEndDate = formatter.format(offerEndDate);

      _offersList.add(OffersModel(
          offerName: _offerNameController.text,
          offerQuantity: double.parse(splitPercentage[0]),
          minOrder: int.parse(
              minOrderDropdownValue != null ? minOrderDropdownValue! : "1"),
          maxOrder: int.parse(
              maxOrderDropdownValue != null ? maxOrderDropdownValue! : "1"),
          startDate: formattedOfferStartDate,
          endDate: formattedOfferEndDate,
          isOfferActive: isOfferActive,
          offerDiscount: offerRadioValue,
          details: _detailsController.text));
      setState(() {
        _offersList.reversed;
        if (isOfferActive) {
          this.updateOfferStatus(_offersList.length - 1);
        }
      });
    }
    Navigator.of(context).pop();
  }

  addOffersList() {
    return SizedBox(
        height: 25.0,
        width: 25.0,
        child: FloatingActionButton(
          heroTag: null,
          onPressed: () {
            CommonMethods.hideKeyboard(context);
            promptOffersFields(false, new OffersModel(), -1);
          },
          child: Icon(
            Icons.add,
            size: 18,
            color: Colors.white,
          ),
          backgroundColor: Color(Constants.APP_COLOR),
        ));
  }

  promptOffersFields(bool isUpdateOffers, OffersModel _offersData, int index) {
    if (isUpdateOffers) {
      _offerNameController.text = _offersData.offerName!;
      formattedOfferStartDate = _offersData.startDate;
      formattedOfferEndDate = _offersData.endDate;

      _detailsController.text = _offersData.details!;

      if (_offersData.isOfferActive!) {
        isOfferActive = true;
      } else {
        isOfferActive = false;
      }
      if (_offersData.offerDiscount == Constants.OFFER_IN_PERCENTAGE) {
        String offerQuantity = "${_offersData.offerQuantity}" + " %";
        offerRadioValue = Constants.OFFER_IN_PERCENTAGE;
        for (int i = 0; i < Constants.PERCENTAGELIST.length; i++) {
          if (offerQuantity == Constants.PERCENTAGELIST[i]) {
            offerInPercentage = Constants.PERCENTAGELIST[i];
          }
        }
      } else {
        offerRadioValue = Constants.OFFER_IN_AMOUNT;
        _offerQtyController.text = _offersData.offerQuantity.toString();
      }
      for (int i = 0; i < Constants.NUMBEROFDAYS.length; i++) {
        if (_offersData.minOrder.toString() == Constants.NUMBEROFDAYS[i]) {
          minOrderDropdownValue = Constants.NUMBEROFDAYS[i];
        }
      }

      for (int i = 0; i < Constants.NUMBEROFDAYS.length; i++) {
        if (_offersData.maxOrder.toString() == Constants.NUMBEROFDAYS[i]) {
          maxOrderDropdownValue = Constants.NUMBEROFDAYS[i];
        }
      }
    } else {
      _offerNameController.clear();
      _offerQtyController.clear();
      isOfferActive = false;
      offerRadioValue = Constants.OFFER_IN_AMOUNT;
      offerInPercentage = null;
      minOrderDropdownValue = null;
      maxOrderDropdownValue = null;
      formattedOfferStartDate = formatter.format(new DateTime.now());
      formattedOfferEndDate = formatter.format(new DateTime.now());
      _detailsController.clear();
    }
    return showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (context, StateSetter setState) {
            return AlertDialog(
              elevation: 100.0,
              contentPadding: EdgeInsets.fromLTRB(15.0, 0, 15.0, 0),
              backgroundColor: Color(Constants.BG_GREY),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(7.0))),
              titlePadding: dialogTitlePadding,
              title: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    Language().getString(
                        isUpdateOffers
                            ? Language()
                                .getString(Constants.UPDATE_OFFER, selectedLang)
                            : Language()
                                .getString(Constants.ADD_OFFER, selectedLang),
                        selectedLang),
                    style: TextStyle(
                        color: Colors.black, //(Constants.APP_COLOR),
                        fontSize: 20.0,
                        fontFamily: StyleView.FONT_TITLE),
                  ),
                  Container(
                    child: Column(
                      children: [
                        Switch(
                            activeThumbColor: Colors.green,
                            value: isOfferActive,
                            onChanged: (value) {
                              setState(() {
                                isOfferActive = value;
                              });
                            }),
                        Container(
                          child: Text(
                            Language().getString(
                                isOfferActive
                                    ? Language().getString(
                                        Constants.ACTIVE_STRING, selectedLang)
                                    : Language().getString(
                                        Constants.IN_ACTIVE, selectedLang),
                                selectedLang),
                            style: TextStyle(
                              fontSize: 13.0,
                            ),
                          ),
                        )
                      ],
                    ),
                  )
                ],
              ),
              actions: [
                CommonButtonsView(
                  context: context,
                  b1Text:
                      Language().getString(Constants.STR_CANCEL, selectedLang),
                  b2Text: Language().getString(
                      isUpdateOffers
                          ? Language()
                              .getString(Constants.UPDATE_OFFER, selectedLang)
                          : Language()
                              .getString(Constants.CONTINUE, selectedLang),
                      selectedLang),
                  onb1Action: () {
                    Navigator.of(context).pop();
                  },
                  onb2Action: () {
                    String _errorMessage = validateOfferFields();
                    if (_errorMessage.isNotEmpty) {
                      Dialogs.yesCancelDialog(
                          context,
                          Language().getString(Constants.ERROR, selectedLang),
                          Language().getString(_errorMessage, selectedLang),
                          Language()
                              .getString(Constants.OKAY_STR, selectedLang),
                          "",
                          false);
                    } else {
                      saveOffersDataList(isUpdateOffers, index);
                    }
                  },
                ),
              ],
              content: Container(
                margin: EdgeInsets.symmetric(
                  vertical: 5.0,
                ),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Column(
                        children: [
                          Row(
                            children: [
                              Radio(
                                value: Constants.OFFER_IN_PERCENTAGE,
                                activeColor: Color(Constants.APP_COLOR),
                                groupValue: offerRadioValue,
                                onChanged: (dynamic value) {
                                  setState(() {
                                    offerRadioValue = value;
                                    _offerQtyController.clear();
                                  });
                                },
                              ),
                              Text(
                                Language().getString(
                                    Constants.OFFER_IN_PERCENTAGE,
                                    selectedLang),
                              ),
                            ],
                          ),
                          Row(
                            children: [
                              Radio(
                                value: Constants.OFFER_IN_AMOUNT,
                                activeColor: Color(Constants.APP_COLOR),
                                groupValue: offerRadioValue,
                                onChanged: (dynamic value) {
                                  setState(() {
                                    offerRadioValue = value;
                                    offerInPercentage = null;
                                  });
                                },
                              ),
                              Text(
                                Language().getString(
                                    Constants.OFFER_IN_AMOUNT, selectedLang),
                              ),
                            ],
                          )
                        ],
                      ),
                      offerHeaderText(Constants.OFFER_NAME),
                      buildOffersInputFields(
                          Language()
                              .getString(Constants.OFFER_NAME, selectedLang),
                          false,
                          _offerNameController,
                          true),
                      offerHeaderText(
                          offerRadioValue == Constants.OFFER_IN_PERCENTAGE
                              ? Constants.OFFER_IN_PERCENTAGE
                              : Constants.OFFER_VALUE),
                      (offerRadioValue == Constants.OFFER_IN_PERCENTAGE)
                          ? Container(
                              margin: EdgeInsets.symmetric(
                                vertical: 5.0,
                              ),
                              height: 50.0,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                border: Border.all(
                                  color: Colors.grey,
                                ),
                                borderRadius: BorderRadius.circular(5.0),
                              ),
                              padding: EdgeInsets.all(5),
                              child: DropdownButton<String>(
                                  onTap: () {
                                    CommonMethods.hideKeyboard(context);
                                  },
                                  value: offerInPercentage,
                                  hint: new Text("%"),
                                  isExpanded: true,
                                  underline: SizedBox(),
                                  onChanged: (String? data) {
                                    setState(() {
                                      offerInPercentage = data;
                                    });
                                  },
                                  items: Constants.PERCENTAGELIST
                                      .map((String model) {
                                    return new DropdownMenuItem<String>(
                                      child: new Text(model),
                                      value: model,
                                    );
                                  }).toList()))
                          : buildOffersInputFields(
                              Language().getString(
                                  Constants.OFFER_VALUE, selectedLang),
                              true,
                              _offerQtyController,
                              true),
                      offerHeaderText(Constants.MIN_ORDER),
                      Container(
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey),
                            borderRadius: BorderRadius.circular(5.0),
                          ),
                          padding: EdgeInsets.all(5),
                          child: DropdownButton<String>(
                              onTap: () {
                                CommonMethods.hideKeyboard(context);
                              },
                              value: minOrderDropdownValue,
                              hint: new Text(Language().getString(
                                  Constants.MIN_ORDER, selectedLang)),
                              isExpanded: true,
                              underline: SizedBox(),
                              onChanged: (String? data) {
                                setState(() {
                                  minOrderDropdownValue = data;
                                });
                              },
                              items: Constants.NUMBEROFDAYS.map((String model) {
                                return new DropdownMenuItem<String>(
                                  child: new Text(model),
                                  value: model,
                                );
                              }).toList())),
                      this.offerHeaderText(Constants.MAX_ORDER),
                      Container(
                          margin: EdgeInsets.symmetric(vertical: 5.0),
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: Colors.grey,
                            ),
                            borderRadius: BorderRadius.circular(5.0),
                          ),
                          padding: EdgeInsets.all(5),
                          child: DropdownButton<String>(
                              onTap: () {
                                CommonMethods.hideKeyboard(context);
                              },
                              value: maxOrderDropdownValue,
                              hint: new Text(Language().getString(
                                  Constants.MAX_ORDER, selectedLang)),
                              isExpanded: true,
                              underline: SizedBox(),
                              onChanged: (String? data) {
                                setState(() {
                                  maxOrderDropdownValue = data;
                                });
                              },
                              items: Constants.NUMBEROFDAYS.map((String model) {
                                return new DropdownMenuItem<String>(
                                  child: new Text(model),
                                  value: model,
                                );
                              }).toList())),
                      Container(
                          decoration: AppUtills.boxDecoration(),
                          child: Container(
                              padding: EdgeInsets.all(1),
                              child: Row(
                                children: <Widget>[
                                  Expanded(
                                    child: Container(
                                        height: 50,
                                        color:
                                            Color(Constants.GREY_COLOR_LIGHT),
                                        child: Container(
                                          padding: EdgeInsets.only(left: 10),
                                          child: Align(
                                              alignment: Alignment.centerLeft,
                                              child: Text(
                                                  Language().getString(
                                                      Constants.START_DATE,
                                                      selectedLang),
                                                  style: TextStyle(
                                                      fontSize: StyleView
                                                          .FONT_SIZE_15,
                                                      fontFamily: StyleView
                                                          .FONT_TITLE))),
                                        )),
                                  ),
                                  Expanded(
                                      flex: 2,
                                      child: Container(
                                        height: 50,
                                        // color: Colors.white,
                                        padding: EdgeInsets.only(left: 5),
                                        alignment: Alignment.topLeft,
                                        child: ElevatedButton(
                                            style: ElevatedButton.styleFrom(
                                              backgroundColor:
                                                  Colors.transparent,
                                              elevation: 0.0,
                                            ),
                                            onPressed: () async {
                                              formattedOfferStartDate =
                                                  await AppUtills
                                                      .getSelectedDate(context,
                                                          isShowIntialDate:
                                                              true);

                                              setState(() {
                                                formattedOfferStartDate =
                                                    formattedOfferStartDate;
                                              });
                                            },
                                            child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: <Widget>[
                                                Text(
                                                  formattedOfferStartDate!,
                                                  style: TextStyle(
                                                      color: Colors.black),
                                                ),
                                                Image.asset(
                                                  'assets/images/calander.png',
                                                  height: 30,
                                                )
                                              ],
                                            )),
                                      )),
                                ],
                              ))),
                      Container(
                          margin: EdgeInsets.symmetric(
                            vertical: 5.0,
                          ),
                          decoration: AppUtills.boxDecoration(),
                          child: Container(
                              padding: EdgeInsets.all(1),
                              child: Row(
                                children: <Widget>[
                                  Expanded(
                                    child: Container(
                                        height: 50,
                                        color:
                                            Color(Constants.GREY_COLOR_LIGHT),
                                        child: Container(
                                          padding: EdgeInsets.only(left: 10),
                                          child: Align(
                                              alignment: Alignment.centerLeft,
                                              child: Text(
                                                  Language().getString(
                                                      Constants.END_DATE,
                                                      selectedLang),
                                                  style: TextStyle(
                                                      fontSize: StyleView
                                                          .FONT_SIZE_15,
                                                      fontFamily: StyleView
                                                          .FONT_TITLE))),
                                        )),
                                  ),
                                  Expanded(
                                      flex: 2,
                                      child: Container(
                                        // color: Colors.white,
                                        padding: EdgeInsets.only(left: 5),
                                        alignment: Alignment.topLeft,
                                        child: ElevatedButton(
                                            style: ElevatedButton.styleFrom(
                                              backgroundColor:
                                                  Colors.transparent,
                                              elevation: 0.0,
                                            ),
                                            onPressed: () async {
                                              formattedOfferEndDate =
                                                  await AppUtills
                                                      .getSelectedDate(context,
                                                          isShowIntialDate:
                                                              true);

                                              setState(() {
                                                formattedOfferEndDate =
                                                    formattedOfferEndDate;
                                              });
                                            },
                                            child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: <Widget>[
                                                Text(
                                                  formattedOfferEndDate!,
                                                  style: TextStyle(
                                                      color: Colors.black),
                                                ),
                                                Image.asset(
                                                  'assets/images/calander.png',
                                                  height: 30,
                                                )
                                              ],
                                            )),
                                      )),
                                ],
                              ))),
                      this.offerHeaderText(Constants.OFFER_DETAILS),
                      buildOffersInputFields(
                          Language()
                              .getString(Constants.OFFER_DETAILS, selectedLang),
                          false,
                          _detailsController,
                          true),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  _createDynamicOfferTable() {
    return Column(children: <Widget>[
      for (int i = 0; i < _offersList.length; i++)
        Column(
          children: [
            SizedBox(height: 5.0),
            OfferExpandedPage(
              strOfferExpired:
                  Language().getString(Constants.OFFER_EXPIRED, selectedLang),
              title: Language().getString(Constants.OFFER, selectedLang) +
                  ": ${_offersList[i].offerName}",
              offersModel: _offersList[i],
              editPage: () {
                promptOffersFields(
                  true,
                  _offersList[i],
                  i,
                );
              },
              removeItem: () async {
                final action = await Dialogs.removeItem(
                  context,
                  _offersList[i].offerName,
                  Language().getString(Constants.WARNING, selectedLang),
                  Language().getString(Constants.WARNING_TEXT, selectedLang),
                  cancel:
                      Language().getString(Constants.STR_CANCEL, selectedLang),
                  yes: Language().getString(Constants.YES_STRING, selectedLang),
                );
                if (action == DialogAction.yes) {
                  setState(() {
                    _offersList.removeAt(i);
                  });
                }
              },
              isItemEdit: true,
              strActive:
                  Language().getString(Constants.ACTIVE_STRING, selectedLang),
              strDetails: Language().getString(Constants.DETAILS, selectedLang),
              strEndDate:
                  Language().getString(Constants.END_DATE, selectedLang),
              strStartDate:
                  Language().getString(Constants.START_DATE, selectedLang),
              strMaximumOrder:
                  Language().getString(Constants.MAX_ORDER, selectedLang),
              strMinimumOrder:
                  Language().getString(Constants.MIN_ORDER, selectedLang),
              strOfferInAmount:
                  Language().getString(Constants.OFFER_IN_AMOUNT, selectedLang),
              strOfferInPercentage: Language()
                  .getString(Constants.OFFER_IN_PERCENTAGE, selectedLang),
              strOfferName:
                  Language().getString(Constants.OFFER_NAME, selectedLang),
              strOfferQuantity:
                  Language().getString(Constants.OFFER_QTY, selectedLang),
              // (_productPrivileges.product_offer_edit) ? true : false,
            ),
          ],
        )
    ]);
  }

  /// Cheking offers active or in-active
  updateOfferStatus(int index) {
    for (int i = 0; i < _offersList.length; i++) {
      if (i == index) {
        setState(() {
          _offersList[i].isOfferActive = true;
        });
      } else {
        setState(() {
          _offersList[i].isOfferActive = false;
        });
      }
    }
  }

  addSupplierList() {
    return SizedBox(
        height: 25.0,
        width: 25.0,
        child: FloatingActionButton(
          heroTag: null,
          onPressed: () {
            CommonMethods.hideKeyboard(context);
            promptSupplierFields(false, new SupplierModel(), -1);
          },
          child: Icon(
            Icons.add,
            size: 18,
          ),
          backgroundColor: Color(Constants.APP_COLOR),
        ));
  }

  promptSupplierFields(
      bool isSupplierUpdate, SupplierModel _suppliersData, int index) {
    if (isSupplierUpdate) {
      if (_connectionsList.length > 0) {
        for (int i = 0; i < _connectionsList.length; i++) {
          if (_suppliersData.name == _connectionsList[i].buName) {
            connectionDropdownValue = _connectionsList[i];
          }
        }
      }

      _supCityController.text = _suppliersData.city!;
      _supDistrictController.text = _suppliersData.district!;
      _supLocalityController.text = _suppliersData.locality!;
      _supPnhController.text = _suppliersData.contact!;
    } else {
      connectionDropdownValue = null;
      _supLocalityController.clear();
      _supCityController.clear();
      _supDistrictController.clear();
      _supPnhController.clear();
    }
    return showDialog(
      barrierDismissible: false,
      context: context,
      barrierColor: Colors.black54,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (context, StateSetter setState) {
            return AlertDialog(
              elevation: 100.0,
              contentPadding: EdgeInsets.fromLTRB(15.0, 0, 15.0, 0),
              backgroundColor: Color(0XFFE0E0E0),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(
                  Radius.circular(
                    7.0,
                  ),
                ),
              ),
              titlePadding: dialogTitlePadding,
              title: Text(
                Language().getString(
                    isSupplierUpdate
                        ? Constants.UPDATE_SUPPLIER
                        : Constants.ADD_SUPPLIER,
                    selectedLang),
                style: TextStyle(
                    color: Colors.black, //(Constants.APP_COLOR),
                    fontSize: StyleView.FONT_SIZE_18,
                    fontFamily: StyleView.FONT_TITLE),
              ),
              actions: [
                CommonButtonsView(
                  context: context,
                  b1Text:
                      Language().getString(Constants.STR_CANCEL, selectedLang),
                  b2Text:
                      Language().getString(Constants.STR_SAVE, selectedLang),
                  onb1Action: () {
                    Navigator.of(context).pop();
                  },
                  onb2Action: () {
                    String errorMessage = validatingSupplierFields();
                    if (errorMessage.isNotEmpty) {
                      Dialogs.yesCancelDialog(
                          context,
                          Language().getString(Constants.ERROR, selectedLang),
                          errorMessage,
                          Language()
                              .getString(Constants.OKAY_STR, selectedLang),
                          "",
                          false);
                    } else {
                      this.saveSupplierDataList(isSupplierUpdate, index);
                    }
                  },
                ),
              ],
              content: Container(
                margin: EdgeInsets.symmetric(
                  vertical: 5.0,
                ),
                child: SingleChildScrollView(
                  child: Column(
                    children: <Widget>[
                      Container(
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey),
                            borderRadius: BorderRadius.circular(
                              5.0,
                            ),
                            // color: Colors.white70,
                          ),
                          padding: EdgeInsets.only(left: 5, right: 5),
                          child: DropdownButton<Contacts>(
                              onTap: () {
                                CommonMethods.hideKeyboard(context);
                              },
                              isExpanded: true,
                              hint: Text(Language().getString(
                                  Constants.SELECT_CONNECTION, selectedLang)),
                              underline: SizedBox(),
                              items: _connectionsList.map((Contacts contact) {
                                return DropdownMenuItem<Contacts>(
                                  value: contact,
                                  child: new Text(
                                    contact.buName!,
                                    style: TextStyle(
                                        fontFamily: StyleView.FONT_TITLE),
                                  ),
                                );
                              }).toList(),
                              value: connectionDropdownValue,
                              onChanged: (Contacts? contacts) {
                                setState(() {
                                  connectionDropdownValue = contacts;
                                  isLoadingProgress = true;

                                  this.renderConnectionData(setState);
                                });
                              })),
                      buildOffersInputFields(
                          Language().getString(
                              Constants.CONTACT_NUMBER, selectedLang),
                          false,
                          _supPnhController,
                          false),
                      buildOffersInputFields(
                          Language().getString(
                              Constants.COLONY_SELECTOR_AREA_LOCALITY_STRING,
                              selectedLang),
                          false,
                          _supLocalityController,
                          false),
                      buildOffersInputFields(
                          Language().getString(
                              Constants.DISTRICT_STRING, selectedLang),
                          false,
                          _supDistrictController,
                          false),
                      buildOffersInputFields(
                          Language().getString(
                              Constants.CITY_NAME_STRING, selectedLang),
                          false,
                          _supCityController,
                          false),
                      this.renderSupplierDetails()
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  renderSupplierDetails() {
    if (connectionDropdownValue != null) {
      return Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          InkWell(
            onTap: () {
              Navigator.push(
                  context,
                  new MaterialPageRoute(
                      builder: (context) => NonSelectableProducts(
                            buId: connectionDropdownValue!.buId,
                            buName: connectionDropdownValue!.buName,
                          )));
            },
            child: Container(
              child: Text(
                Language().getString(Constants.PRODUCTS_STR, selectedLang),
                style: TextStyle(
                  color: Colors.blue,
                  decoration: TextDecoration.underline,
                ),
              ),
            ),
          ),
          InkWell(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ConnectionsBuDetailsPage(
                      connectionId: connectionDropdownValue!.id,
                      buName: connectionDropdownValue!.buName,
                      buId: connectionDropdownValue!.buId),
                ),
              );
            },
            child: Container(
              child: Text(
                Language().getString(Constants.DETAILS, selectedLang),
                style: TextStyle(
                  color: Colors.blue,
                  decoration: TextDecoration.underline,
                ),
              ),
            ),
          ),
        ],
      );
    } else {
      return Container();
    }
  }

  renderConnectionData(StateSetter setState) {
    Future.delayed(Duration.zero, () {
      getBuDetails(connectionDropdownValue!.buId).then((value) {
        setState(() {
          _connectionDetails.addAll(value);
          if (_connectionDetails.length > 0 &&
              _connectionDetails[0].contactDetails != null &&
              _connectionDetails[0].contactDetails!.address != null) {
            _supPnhController.text = _connectionDetails[0].contactNumber!;

            _supLocalityController.text = _connectionDetails[0]
                .contactDetails!
                .address!
                .colonysectorArealocality!;
            _supDistrictController.text =
                _connectionDetails[0].contactDetails!.address!.district!;

            _supCityController.text =
                _connectionDetails[0].contactDetails!.address!.villagetowncity!;
          }
        });
      });
    });
  }

  _createDynamicSupplierTable() {
    return Column(children: <Widget>[
      for (int i = 0; i < _supplierList.length; i++)
        Column(
          children: [
            SizedBox(
              height: 5.0,
            ),
            SupplierExpandedPage(
              strCity: Language()
                  .getString(Constants.CITY_NAME_STRING, selectedLang),
              strDistrict:
                  Language().getString(Constants.DISTRICT_STRING, selectedLang),
              strLocality: Language().getString(
                  Constants.COLONY_SELECTOR_AREA_LOCALITY_STRING, selectedLang),
              strContactNum:
                  Language().getString(Constants.CONTACT_NUMBER, selectedLang),
              title: Language().getString(Constants.SUPPLIER, selectedLang) +
                  " : ${_supplierList[i].name}",
              supplierModel: _supplierList[i],
              editPage: () {
                this.promptSupplierFields(true, _supplierList[i], i);
              },
              removeItem: () async {
                final action = await Dialogs.removeItem(
                  context,
                  _supplierList[i].name,
                  Language().getString(Constants.WARNING, selectedLang),
                  Language().getString(Constants.WARNING_TEXT, selectedLang),
                  cancel:
                      Language().getString(Constants.STR_CANCEL, selectedLang),
                  yes: Language().getString(Constants.YES_STRING, selectedLang),
                );

                if (action == DialogAction.yes) {
                  setState(() {
                    _supplierList.removeAt(i);
                  });
                }
              },
              isItemEdit: true,
            )
          ],
        )
    ]);
  }

  String validatingSupplierFields() {
    if (connectionDropdownValue == null) {
      return Constants.PLEASE_SELECT_CONNECTION;
    } else {
      return "";
    }
  }

  saveSupplierDataList(bool isUpdateSupplier, int updateSupplierIndex) {
    if (isUpdateSupplier) {
      _supplierList[updateSupplierIndex] = SupplierModel(
          id: connectionDropdownValue!.id,
          name: connectionDropdownValue!.buName,
          city: _supCityController.text,
          district: _supDistrictController.text,
          locality: _supLocalityController.text,
          contact: _supPnhController.text);
      setState(() {
        _supplierList.reversed;
      });
    } else {
      _supplierList.add(SupplierModel(
          id: connectionDropdownValue!.buId,
          name: connectionDropdownValue!.buName,
          city: _supCityController.text,
          district: _supDistrictController.text,
          locality: _supLocalityController.text,
          contact: _supPnhController.text));
      setState(() {
        _supplierList.reversed;
      });
    }

    Navigator.of(context).pop();
  }

  addNewAttribute() {
    return SizedBox(
        height: 25.0,
        width: 25.0,
        child: FloatingActionButton(
          elevation: 0,
          onPressed: () {
            CommonMethods.hideKeyboard(context);
            buildAttributeFieldsTable(new ProductAttributeModel(), -1, false);
          },
          child: Icon(Icons.add, size: 15, color: Colors.white),
          backgroundColor: Color(Constants.APP_COLOR),
        ));
  }

  addNewInventory() {
    return SizedBox(
        height: 25.0,
        width: 25.0,
        child: FloatingActionButton(
          heroTag: "bt1",
          onPressed: () async {
            if (_priceList.length > 0) {
              buildInventoryFieldsTable(
                  new InventoryManagementModel(), -1, false);
            } else {
              Dialogs.yesCancelDialog(
                  context,
                  Language().getString(Constants.INFO, selectedLang),
                  Language().getString(
                      Constants.PLEASE_ENTER_QUANTITY_AND_PRICE, selectedLang),
                  Language().getString(Constants.OKAY_STR, selectedLang),
                  "",
                  false);
            }
          },
          child: Icon(
            Icons.add,
            size: 18,
          ),
          backgroundColor: Color(Constants.APP_COLOR),
        ));
  }

  buildInventoryFieldsTable(
    InventoryManagementModel _inventoryData,
    int index,
    bool isUpdateInventory,
  ) {
    if (isUpdateInventory) {
      inventoryQuntityInDropdown = Constants.UNIT_PRICE[0];
      for (int j = 0; j < locationsList.length; j++) {
        if (_inventoryData.locationName == locationsList[j].locationName) {
          locationDropdownValue = locationsList[j];
        }
      }
      inventoryQuntityInDropdown =
          _inventoryData.locationBatchList![0].quantityIn;
      for (int i = 0; i < _priceList.length; i++) {
        if (_inventoryData.locationBatchList![0].batchNumber ==
            _priceList[i].batchNumber) {
          inventoryQuantityDropdown = _priceList[i];
        }
      }
    } else {
      locationDropdownValue = null;
      _locationQuantityController.clear();
      inventoryQuantityDropdown = null;
      inventoryQuntityInDropdown = Constants.UNIT_PRICE[0];
    }

    return showDialog(
        barrierDismissible: false,
        context: context,
        barrierColor: Colors.black54,
        builder: (BuildContext context) {
          return StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
            return Container(
              margin: EdgeInsets.symmetric(vertical: 30.0, horizontal: 20.0),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5.0),
                  color: Colors.white),
              child: Scaffold(
                backgroundColor: Colors.transparent,
                bottomNavigationBar:
                    this.inventoryBottomView(index, isUpdateInventory),
                body: Container(
                  padding: EdgeInsets.all(10.0),
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Container(
                          margin: EdgeInsets.symmetric(
                            vertical: 10.0,
                          ),
                          child: Text(
                            Language().getString(
                                Constants.INVENTORY_LOCATION, selectedLang),
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_18,
                                fontFamily: StyleView.FONT_TITLE,
                                fontWeight: FontWeight.bold,
                                color: Colors.black),
                          ),
                        ),
                        showAllocatedBatchesWithLocationDetails(),
                        new Text(
                            Language()
                                .getString(Constants.LOCATION, selectedLang),
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontWeight: FontWeight.bold,
                                color: Colors.black)),
                        SizedBox(height: 5.0),
                        (isUpdateInventory)
                            ? Container(
                                decoration: AppUtills.boxDecoration(),
                                margin: EdgeInsets.symmetric(vertical: 5.0),
                                child: TextView(
                                  title: Language().getString(
                                      Constants.LOCATION_NAME, selectedLang),
                                  value: locationDropdownValue != null
                                      ? locationDropdownValue!.locationName
                                      : "",
                                ))
                            : this.inventoryLocations(setState),
                        // if (locationDropdownValue != null)
                        //   Container(
                        //     margin: EdgeInsets.symmetric(vertical: 5.0),
                        //     child: this.showLocationBatchNumbers(
                        //         locationDropdownValue!.locationName),
                        //   ),
                        Container(
                          margin: EdgeInsets.only(
                            top: 10.0,
                          ),
                          child: Text(
                            Language().getString(
                                Constants.BATCH_DETAILS, selectedLang),
                            style: TextStyle(
                                fontSize: 15.0,
                                fontFamily: StyleView.FONT_TITLE,
                                fontWeight: FontWeight.bold,
                                color: Colors.black),
                          ),
                        ),
                        this.inventoryBatchQuantity(setState),
                        if (inventoryQuantityDropdown != null)
                          Container(
                              margin: EdgeInsets.only(top: 5.0),
                              child: Row(
                                children: [
                                  Container(
                                    child: Text(
                                      Language().getString(
                                          Constants
                                              .TOTAAL_AVAILABLITY_QUANTITY_BATCH,
                                          selectedLang),
                                      style: TextStyle(
                                          fontSize: 12.0,
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                  Text("  : ",
                                      style: TextStyle(
                                          fontSize: 13.0,
                                          color: Colors.black,
                                          fontWeight: FontWeight.w600)),
                                  Container(
                                    child: Text(
                                      "${inventoryQuantityDropdown!.quantity} ${inventoryQuantityDropdown!.quantityIn}",
                                      style: TextStyle(
                                        fontSize: 12.0,
                                        color: Color(Constants.APP_COLOR),
                                      ),
                                    ),
                                  ),
                                ],
                              )),
                        if (inventoryQuantityDropdown != null)
                          this.showRemainingInventoryQuantity(
                              inventoryQuantityDropdown,
                              index,
                              isUpdateInventory),
                        // if (inventoryQuantityDropdown != null)
                        //   this.showBatchPricingDetails(
                        //       inventoryQuantityDropdown,
                        //       index,
                        //       isUpdateInventory),
                        Container(
                          margin: EdgeInsets.only(top: 10.0),
                          child: Text(
                              Language().getString("Assign to", selectedLang) +
                                  '${locationDropdownValue != null ? locationDropdownValue!.locationName : ""}',
                              style: TextStyle(
                                  fontSize: StyleView.FONT_SIZE_15,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black)),
                        ),
                        SizedBox(height: 5.0),
                        this.buildInventiryUnitPriceDropdown(setState, false)
                      ],
                    ),
                  ),
                ),
              ),
            );
          });
        });
  }

  validatingSelectedBatchQuantity(setState) {
    num enteredQuantity = double.parse(_quantityAdjutmentController.text);
    // for (int i = 0; i < _priceList.length; i++) {
    //   if (quantityAdjustmentBatchDropdown.batchNumber ==
    //       _priceList[i].batchNumber) {
    //     setState(() {
    //       priceQuanity = int.parse(_priceList[i].quantity);
    //       _priceList[i].quantity = (priceQuanity - enteredQuantity).toString();
    //       // isLoadingProgress = false;
    //     });
    //   }
    // }

    for (int j = 0; j < inventoryList.length; j++) {
      if (quantityAdjustmentLocationDropdown!.locationName ==
          inventoryList[j].locationName) {
        for (int k = 0; k < inventoryList[j].locationBatchList!.length; k++) {
          if (quantityAdjustmentBatchDropdown!.batchNumber ==
              inventoryList[j].locationBatchList![k].batchNumber) {
            setState(() {
              inventoryList[j].locationBatchList![k].quantity =
                  (inventoryList[j].locationBatchList![k].quantity! -
                      enteredQuantity);
              isLoadingProgress = false;
            });
          }
        }
      }
    }
  }

  updatingBatchQuantity(
      int index, bool isUpdateInventory, StateSetter setState) {
    this.onSaveInventoryDetails(isUpdateInventory, index);
  }

  Widget inventoryLocations(StateSetter setState) {
    return Container(
        margin: EdgeInsets.symmetric(
          vertical: 5.0,
        ),
        decoration: AppUtills.boxDecoration(),
        padding: EdgeInsets.all(1),
        child: Container(
            color: Colors.white70,
            padding: EdgeInsets.only(left: 5, right: 5),
            child: DropdownButton<Locations>(
                onTap: () {
                  FocusScope.of(context).requestFocus(
                      new FocusNode()); //CommonMethods.hideKeyboard(context);
                },
                isExpanded: true,
                hint: Text(
                    Language().getString(Constants.LOCATION, selectedLang)),
                underline: SizedBox(),
                items: locationsList.map((Locations locationData) {
                  return DropdownMenuItem<Locations>(
                    value: locationData,
                    child: new Text(
                      locationData.locationName!,
                      style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                    ),
                  );
                }).toList(),
                value: locationDropdownValue,
                onChanged: (Locations? location) {
                  setState(() {
                    locationDropdownValue = location;
                  });
                })));
  }

  Widget inventoryBatchQuantity(StateSetter setState,
      {bool isFromQuantityAdjustment = false}) {
    return Container(
      margin: EdgeInsets.symmetric(
        vertical: 5.0,
      ),
      decoration: AppUtills.boxDecoration(),
      padding: EdgeInsets.all(1),
      child: Container(
        color: Colors.white70,
        padding: EdgeInsets.only(left: 5, right: 5),
        child: DropdownButton<PriceModel>(
          onTap: () {
            CommonMethods.hideKeyboard(context);
          },
          isExpanded: true,
          hint: Text(Language().getString(Constants.BATCH_NO, selectedLang)),
          underline: SizedBox(),
          items: _priceList.map((PriceModel batchPrice) {
            return DropdownMenuItem<PriceModel>(
              value: batchPrice,
              child: new Text(
                batchPrice.batchNumber!,
                style: TextStyle(fontFamily: StyleView.FONT_TITLE),
              ),
            );
          }).toList(),
          value: inventoryQuantityDropdown,
          onChanged: (PriceModel? model) {
            setState(() {
              inventoryQuntityInDropdown = null;
              inventoryQuntityInDropdown = model!.quantityIn;
              inventoryQuantityDropdown = model;
              _locationQuantityController.text =
                  inventoryQuantityDropdown!.quantity!;
              if (isFromQuantityAdjustment) {
                remainingAdjustmentQuantity = int.parse(model.quantity!);
              }
            });
          },
        ),
      ),
    );
  }

  String validateInventoryFields() {
    if (locationDropdownValue == null) {
      return Constants.PLEASE_SELECT_LOCATION;
    } else if (inventoryQuantityDropdown == null) {
      return Constants.PLEASE_SELECT_BATCH_NO;
    } else if (_locationQuantityController.text.isEmpty) {
      return Constants.PLEASE_ENTER_QUANTITY;
    } else {
      return "";
    }
  }

  buildAttributeFieldsTable(
    ProductAttributeModel _attributesData,
    int index,
    bool isUpdateAttribute,
  ) {
    if (isUpdateAttribute) {
      _attributeKeyController.text = _attributesData.attributeKey!;
      _attributeValueController.text = _attributesData.attributeValue!;
    } else {
      _attributeKeyController.clear();
      _attributeValueController.clear();
    }

    return showDialog(
        barrierDismissible: false,
        context: context,
        barrierColor: Colors.black54,
        builder: (BuildContext context) {
          return AlertDialog(
            elevation: 100.0,
            contentPadding: EdgeInsets.fromLTRB(15.0, 0, 15.0, 0),
            backgroundColor: Color(Constants.BG_GREY), //Color(0XFFE0E0E0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(
                Radius.circular(
                  7.0,
                ),
              ),
            ),
            title: Text(
              Language().getString(Constants.ADD_NEW_FEATURE, selectedLang),
              style: TextStyle(
                  fontSize: StyleView.FONT_SIZE_18,
                  fontFamily: StyleView.FONT_TITLE,
                  color: Colors.black //(Constants.APP_COLOR),
                  ),
            ),
            titlePadding: dialogTitlePadding,
            content: Container(
              margin: EdgeInsets.symmetric(
                vertical: 5.0,
              ),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    new Text(Language()
                        .getString(Constants.FEATURE_NAME, selectedLang)),
                    SizedBox(height: 5.0),
                    buildTextFormFieldsDialog(
                      Language()
                          .getString(Constants.FEATURE_NAME, selectedLang),
                      _attributeKeyController,
                      Language()
                          .getString(Constants.FEATURE_NAME, selectedLang),
                    ),
                    new Text(Language()
                        .getString(Constants.FEATURE_DETAILS, selectedLang)),
                    SizedBox(height: 5.0),
                    buildTextFormFieldsDialog(
                      Language()
                          .getString(Constants.FEATURE_DETAILS, selectedLang),
                      _attributeValueController,
                      Language()
                          .getString(Constants.FEATURE_DETAILS, selectedLang),
                    ),
                    CommonButtonsView(
                        context: context,
                        b1Text: Language()
                            .getString(Constants.STR_CANCEL, selectedLang),
                        b2Text: Language()
                            .getString(Constants.STR_SAVE, selectedLang),
                        onb1Action: () {
                          Navigator.of(context).pop();
                        },
                        onb2Action: () {
                          if (_attributeKeyController.text.isEmpty &&
                              _attributeValueController.text.isEmpty) {
                            Navigator.of(context).pop();
                            return;
                          }
                          onSaveAttributeDetails(isUpdateAttribute, index);
                        }),
                  ],
                ),
              ),
            ),
          );
        });
  }

  buildTextFormFieldsDialog(
      String? _labelText, TextEditingController controller, String hint) {
    return SizedBox(
        height: 70,
        child: new TextFormField(
            style: TextStyle(fontFamily: StyleView.FONT_TITLE),
            controller: controller,
            decoration: InputDecoration(
              hintText: hint,
              isDense: true,
              labelText: _labelText,
              labelStyle: TextStyle(color: Colors.grey),
              focusColor: StyleView.secondaryColor,
              border: OutlineInputBorder(),
              // enabledBorder: OutlineInputBorder(
              //     borderSide: BorderSide(color: Color(Constants.BORDER_GREY))),
              focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Color(Constants.BORDER_GREY))),
            )));
  }

  onSaveAttributeDetails(bool isUpdateAttribute, int index) {
    if (isUpdateAttribute) {
      attributesList[index] = ProductAttributeModel(
          attributeValue: _attributeValueController.text,
          attributeKey: _attributeKeyController.text);
      setState(() {
        attributesList.reversed;
      });
      Navigator.of(context).pop();
    } else {
      attributesList.add(ProductAttributeModel(
          attributeValue: _attributeValueController.text,
          attributeKey: _attributeKeyController.text));
      setState(() {
        attributesList.reversed;
      });
      Navigator.of(context).pop();
    }
  }

  onSaveInventoryDetails(bool isUpdateInventory, int index) {
    if (isUpdateInventory) {
      if (locationDropdownValue != null && inventoryQuantityDropdown != null) {
        bool isBatchNumberExist = false;
        int existIndex = -1;

        for (int i = 0;
            i < inventoryList[index].locationBatchList!.length;
            i++) {
          /**
               * Batch Number validating in Inventory Locations
               */
          if (inventoryQuantityDropdown!.batchNumber ==
              inventoryList[index].locationBatchList![i].batchNumber) {
            existIndex = i;
            isBatchNumberExist = true;
          }
        }

        /**
         * Updating Batch Quantity in Inventory Locations if Batch Exist
         */
        if (isBatchNumberExist) {
          inventoryList[index].locationBatchList![existIndex].updatedUser =
              userName;
          inventoryList[index].locationBatchList![existIndex].updatedDate =
              updatedCurrentDateTime;
          inventoryList[index].locationBatchList![existIndex].quantity =
              inventoryList[index].locationBatchList![existIndex].quantity! +
                  double.parse(_locationQuantityController.text);
          inventoryList[index].locationBatchList![existIndex].quantityIn =
              inventoryQuntityInDropdown != null
                  ? inventoryQuntityInDropdown
                  : Constants.UNIT_PRICE[0];
          inventoryList[index] = InventoryManagementModel(
              locationName: locationDropdownValue!.locationName,
              locationBatchList: inventoryList[index].locationBatchList);

          inventoryList[index].locationId = locationDropdownValue!.locationId;
        } else {
          List<InventoryDetailsDAO> locationBatchData = [];
          locationBatchData.addAll(inventoryList[index].locationBatchList!);
          locationBatchData.add(InventoryDetailsDAO(
              batchNumber: inventoryQuantityDropdown!.batchNumber,
              quantityIn: inventoryQuntityInDropdown != null
                  ? inventoryQuntityInDropdown
                  : Constants.UNIT_PRICE[0],
              quantity: double.parse(_locationQuantityController.text),
              updatedUser: userName,
              updatedDate: updatedCurrentDateTime));

          inventoryList[index] = InventoryManagementModel(
            locationName: locationDropdownValue!.locationName,
            locationBatchList: locationBatchData,
          );
          // if (inventoryList[index].locationId == null ||
          //     inventoryList[index].locationId.isEmpty) {
          inventoryList[index].locationId = locationDropdownValue!.locationId;
          // }
        }

        setState(() {
          inventoryList.reversed;
        });
        Navigator.of(context).pop();
      } else {
        Navigator.of(context).pop();
      }
    } else {
      if (locationDropdownValue != null && inventoryQuantityDropdown != null) {
        bool isExistLocationName = false;
        int existIndex = -1;

        for (int i = 0; i < inventoryList.length; i++) {
          if (locationDropdownValue!.locationName ==
              inventoryList[i].locationName) {
            isExistLocationName = true;
            existIndex = i;
            // if (inventoryList[i].locationId == null ||
            //     inventoryList[i].locationId.isEmpty) {
            inventoryList[i].locationId = locationDropdownValue!.locationId;
            // }
          }
        }

        if (isExistLocationName) {
          bool isBatchNumberExist = false;
          num existBatchIndex = -1;
          for (int i = 0;
              i < inventoryList[existIndex].locationBatchList!.length;
              i++) {
            if (inventoryList[existIndex].locationBatchList![i].batchNumber ==
                inventoryQuantityDropdown!.batchNumber) {
              isBatchNumberExist = true;
              existBatchIndex = i;
            }
          }

          if (isBatchNumberExist) {
            num updateQuantity = inventoryList[existIndex]
                    .locationBatchList![existBatchIndex as int]
                    .quantity! +
                double.parse(_locationQuantityController.text);
            inventoryList[existIndex]
                .locationBatchList![existBatchIndex]
                .updatedUser = userName;
            inventoryList[existIndex]
                .locationBatchList![existBatchIndex]
                .updatedDate = updatedCurrentDateTime;
            inventoryList[existIndex]
                .locationBatchList![existBatchIndex]
                .quantity = updateQuantity;
            inventoryList[existIndex]
                    .locationBatchList![existBatchIndex]
                    .quantityIn =
                inventoryQuntityInDropdown != null
                    ? inventoryQuntityInDropdown
                    : Constants.UNIT_PRICE[0];
          } else {
            List<InventoryDetailsDAO> locationBatchData = [];
            locationBatchData
                .addAll(inventoryList[existIndex].locationBatchList!);
            locationBatchData.add(InventoryDetailsDAO(
                batchNumber: inventoryQuantityDropdown!.batchNumber,
                quantityIn: inventoryQuntityInDropdown != null
                    ? inventoryQuntityInDropdown
                    : Constants.UNIT_PRICE[0],
                quantity: double.parse(_locationQuantityController.text),
                updatedUser: userName,
                updatedDate: updatedCurrentDateTime));
            inventoryList[existIndex] = InventoryManagementModel(
                locationName: locationDropdownValue!.locationName,
                locationId: locationDropdownValue!.locationId,
                quantityIn: inventoryQuntityInDropdown,
                locationBatchList: locationBatchData);
          }
        } else {
          List<InventoryDetailsDAO> locationBatchData = [];
          locationBatchData.add(InventoryDetailsDAO(
              batchNumber: inventoryQuantityDropdown!.batchNumber,
              quantityIn: inventoryQuntityInDropdown != null
                  ? inventoryQuntityInDropdown
                  : Constants.UNIT_PRICE[0],
              quantity: double.parse(_locationQuantityController.text),
              updatedUser: userName,
              updatedDate: updatedCurrentDateTime));
          inventoryList.add(InventoryManagementModel(
              locationName: locationDropdownValue!.locationName,
              locationId: locationDropdownValue!.locationId,
              locationBatchList: locationBatchData));
        }

        setState(() {
          inventoryList.reversed;
        });
        Navigator.of(context).pop();
      } else {
        Navigator.of(context).pop();
      }
    }
  }

  Widget onCreateDynamicAttributes() {
    return Column(children: <Widget>[
      for (int i = 0; i < attributesList.length; i++)
        Container(
          margin: EdgeInsets.symmetric(vertical: 5.0),
          child: Column(
            children: <Widget>[
              AttributeExpandedPage(
                attributeKey: attributesList[i].attributeKey,
                attributeValue: attributesList[i].attributeValue,
                editPage: () {
                  buildAttributeFieldsTable(attributesList[i], i, true);
                },
                removeItem: () async {
                  final action = await Dialogs.removeItem(
                    context,
                    attributesList[i].attributeKey,
                    Language().getString(Constants.WARNING, selectedLang),
                    Language().getString(Constants.WARNING_TEXT, selectedLang),
                    cancel: Language()
                        .getString(Constants.STR_CANCEL, selectedLang),
                    yes: Language()
                        .getString(Constants.YES_STRING, selectedLang),
                  );

                  if (action == DialogAction.yes) {
                    setState(() {
                      attributesList.removeAt(i);
                    });
                  }
                },
              ),
            ],
          ),
        )
    ]);
  }

  Widget createPriceDetailsDynamic() {
    return Column(children: <Widget>[
      for (int i = 0; i < _priceList.length; i++) this.showPriceExpandView(i)
    ]);
  }

  Widget showPriceExpandView(int index) {
    return Container(
      margin: EdgeInsets.symmetric(
        vertical: 10.0,
      ),
      child: Column(
        children: <Widget>[
          PriceDetailsExpandPage(
            priceModel: _priceList[index],
            strQuantity: Language().getString(Constants.QUANTITY, selectedLang),
            strQuantityIn:
                Language().getString(Constants.QUANTITY_IN, selectedLang),
            strBatchNumber:
                Language().getString(Constants.BATCH_NO, selectedLang),
            strCurrencyName:
                Language().getString(Constants.CURRENCY_NAME, selectedLang),
            strExpireDate:
                Language().getString(Constants.EXPIRE_DATE_STR, selectedLang),
            strManufactureDate:
                Language().getString(Constants.MANUFACTURE_DATE, selectedLang),
            strMrp: Language().getString(Constants.MRP, selectedLang),
            strNetRate: Language().getString(Constants.NET_RATE, selectedLang),
            strPrice: Language().getString(Constants.PRICE, selectedLang),
            strUnitPrice:
                Language().getString(Constants.PRICE_UNIT, selectedLang),
            strRawMaterialIssueNoteId: Language()
                .getString(Constants.RAW_MATERIAL_ISSUE_NOTE_ID, selectedLang),
            strManufacturerHouse: Language()
                .getString(Constants.MANUFACTURED_INHOUSE, selectedLang),
            strPurchasedProducts: Language()
                .getString(Constants.PURCHASED_PRODUCTS, selectedLang),
            title: _priceList[index].batchNumber,
            isEdit: true,
            editPage: () {
              isLoadingProgress = true;
              Future.delayed(Duration(seconds: 2));
              priceFieldsPopup(_priceList[index], index, true);
            },
            removeItem: () async {
              final action = await Dialogs.removeItem(
                context,
                " ${_priceList[index].batchNumber}",
                Language().getString(Constants.WARNING, selectedLang),
                Language().getString(Constants.WARNING_TEXT, selectedLang),
                cancel:
                    Language().getString(Constants.STR_CANCEL, selectedLang),
                yes: Language().getString(Constants.YES_STRING, selectedLang),
              );

              if (action == DialogAction.yes) {
                setState(() {
                  _priceList.removeAt(index);
                });
              }
            },
            isFromProdutPage:
                (widget.isFromRawMaterialPage || widget.isFromConsumablePage)
                    ? false
                    : true,
          ),
        ],
      ),
    );
  }

  Widget onCreateDynamicInventory() {
    return Column(children: <Widget>[
      for (int i = 0; i < inventoryList.length; i++)
        Container(
          margin: EdgeInsets.symmetric(
            vertical: 5.0,
          ),
          child: Column(children: <Widget>[
            InventoryExpandedPage(
              managementModel: inventoryList[i],
              editPage: () async {
                buildInventoryFieldsTable(inventoryList[i], i, true);
              },
              removeItem: () async {
                final action = await Dialogs.removeItem(
                  context,
                  inventoryList[i].locationName,
                  Language().getString(Constants.WARNING, selectedLang),
                  Language().getString(Constants.WARNING_TEXT, selectedLang),
                  cancel:
                      Language().getString(Constants.STR_CANCEL, selectedLang),
                  yes: Language().getString(Constants.YES_STRING, selectedLang),
                );

                if (action == DialogAction.yes) {
                  setState(() {
                    inventoryList.removeAt(i);
                  });
                }
              },
              strBatchNumber:
                  Language().getString(Constants.BATCH_NO, selectedLang),
              strLocation:
                  Language().getString(Constants.LOCATION, selectedLang),
              strTotalAtLocation: Language()
                  .getString(Constants.TOTAL_AT_LOCATION, selectedLang),
            )
          ]),
        ),
    ]);
  }

  buildHeightView(String title, String value) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      Language().getString(title, selectedLang),
                      style: TextStyle(
                          fontSize: StyleView.FONT_SIZE_15,
                          fontFamily: StyleView.FONT_TITLE,
                          color: Colors.black),
                    )),
              )),
        ),
        Expanded(
            flex: 2,
            child: Container(
              color: Colors.grey,
              child: Row(children: <Widget>[
                Expanded(
                    child: Container(
                  padding: EdgeInsets.only(left: 5),
                  margin: EdgeInsets.only(right: 1),
                  color: Colors.white,
                  child: TextField(
                    keyboardType: (defaultTargetPlatform == TargetPlatform.iOS)
                        ? TextInputType.numberWithOptions(signed: true)
                        : TextInputType.number,
                    controller: _heightController,
                    style: TextStyle(fontFamily: Constants.INDIAN_RUPEE),
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: Language().getString(title, selectedLang),
                    ),
                  ),
                )),
                Expanded(
                    child: Container(
                        color: Colors.white,
                        padding: EdgeInsets.only(left: 5),
                        child: DropdownButton<String>(
                            onTap: () {
                              CommonMethods.hideKeyboard(context);
                            },
                            value: heightDropdownValue,
                            hint: new Text(
                              Language()
                                  .getString(Constants.SELECT, selectedLang),
                            ),
                            isExpanded: true,
                            underline: SizedBox(),
                            onChanged: (String? data) {
                              setState(() {
                                heightDropdownValue = data;
                              });
                            },
                            items:
                                Constants.measurementsList.map((String model) {
                              return new DropdownMenuItem<String>(
                                child: new Text(model),
                                value: model,
                              );
                            }).toList()))),
              ]),
            ))
      ],
    );
  }

  buildDepthView(String title, String value) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      Language().getString(title, selectedLang),
                      style: TextStyle(
                          fontSize: StyleView.FONT_SIZE_15,
                          fontFamily: StyleView.FONT_TITLE,
                          color: Colors.black),
                    )),
              )),
        ),
        Expanded(
            flex: 2,
            child: Container(
              color: Colors.grey,
              child: Row(children: <Widget>[
                Expanded(
                    child: Container(
                  padding: EdgeInsets.only(left: 5),
                  margin: EdgeInsets.only(right: 1),
                  color: Colors.white,
                  child: TextField(
                    keyboardType: (defaultTargetPlatform == TargetPlatform.iOS)
                        ? TextInputType.numberWithOptions(signed: true)
                        : TextInputType.number,
                    controller: _depthController,
                    style: TextStyle(fontFamily: Constants.INDIAN_RUPEE),
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: Language().getString(title, selectedLang),
                    ),
                  ),
                )),
                Expanded(
                    child: Container(
                        color: Colors.white,
                        padding: EdgeInsets.only(left: 5),
                        child: DropdownButton<String>(
                            onTap: () {
                              CommonMethods.hideKeyboard(context);
                            },
                            value: depthDropdownValue,
                            hint: new Text(
                              Language()
                                  .getString(Constants.SELECT, selectedLang),
                            ),
                            isExpanded: true,
                            underline: SizedBox(),
                            onChanged: (String? data) {
                              setState(() {
                                depthDropdownValue = data;
                              });
                            },
                            items:
                                Constants.measurementsList.map((String model) {
                              return new DropdownMenuItem<String>(
                                child: new Text(model),
                                value: model,
                              );
                            }).toList()))),
              ]),
            ))
      ],
    );
  }

  buildVolumeView(String title, String value) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      Language().getString(title, selectedLang),
                      style: TextStyle(
                          fontSize: StyleView.FONT_SIZE_15,
                          fontFamily: StyleView.FONT_TITLE,
                          color: Colors.black),
                    )),
              )),
        ),
        Expanded(
            flex: 2,
            child: Container(
              color: Colors.grey,
              child: Row(children: <Widget>[
                Expanded(
                    child: Container(
                  padding: EdgeInsets.only(left: 5),
                  margin: EdgeInsets.only(right: 1),
                  color: Colors.white,
                  child: TextField(
                    keyboardType: (defaultTargetPlatform == TargetPlatform.iOS)
                        ? TextInputType.numberWithOptions(signed: true)
                        : TextInputType.number,
                    controller: volumeController,
                    style: TextStyle(fontFamily: Constants.INDIAN_RUPEE),
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: Language().getString(title, selectedLang),
                    ),
                  ),
                )),
                Expanded(
                    child: Container(
                        color: Colors.white,
                        padding: EdgeInsets.only(left: 5),
                        child: DropdownButton<String>(
                            onTap: () {
                              CommonMethods.hideKeyboard(context);
                            },
                            value: volumeDropdownValue,
                            hint: new Text(
                              Language()
                                  .getString(Constants.SELECT, selectedLang),
                            ),
                            isExpanded: true,
                            underline: SizedBox(),
                            onChanged: (String? data) {
                              setState(() {
                                volumeDropdownValue = data;
                              });
                            },
                            items: Constants.volumeMeasurementsList
                                .map((String model) {
                              return new DropdownMenuItem<String>(
                                child: new Text(model),
                                value: model,
                              );
                            }).toList()))),
              ]),
            ))
      ],
    );
  }

  buildWeightView(String title, String value) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      Language().getString(title, selectedLang),
                      style: TextStyle(
                          fontSize: StyleView.FONT_SIZE_15,
                          fontFamily: StyleView.FONT_TITLE,
                          color: Colors.black),
                    )),
              )),
        ),
        Expanded(
            flex: 2,
            child: Container(
              color: Colors.grey,
              child: Row(children: <Widget>[
                Expanded(
                    child: Container(
                  padding: EdgeInsets.only(left: 5),
                  margin: EdgeInsets.only(right: 1),
                  color: Colors.white,
                  child: TextField(
                    keyboardType: (defaultTargetPlatform == TargetPlatform.iOS)
                        ? TextInputType.numberWithOptions(signed: true)
                        : TextInputType.number,
                    controller: _weightController,
                    style: TextStyle(fontFamily: Constants.INDIAN_RUPEE),
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: Language().getString(title, selectedLang),
                    ),
                  ),
                )),
                Expanded(
                    child: Container(
                        color: Colors.white,
                        padding: EdgeInsets.only(left: 5),
                        child: DropdownButton<String>(
                            onTap: () {
                              CommonMethods.hideKeyboard(context);
                            },
                            value: weightDropdownValue,
                            hint: new Text(
                              Language()
                                  .getString(Constants.SELECT, selectedLang),
                            ),
                            isExpanded: true,
                            underline: SizedBox(),
                            onChanged: (String? data) {
                              setState(() {
                                weightDropdownValue = data;
                              });
                            },
                            items: Constants.weightMeasurementsList
                                .map((String model) {
                              return new DropdownMenuItem<String>(
                                child: new Text(model),
                                value: model,
                              );
                            }).toList()))),
              ]),
            ))
      ],
    );
  }

  buildWidthView(String title, String value) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      Language().getString(title, selectedLang),
                      style: TextStyle(
                          fontSize: StyleView.FONT_SIZE_15,
                          fontFamily: StyleView.FONT_TITLE,
                          color: Colors.black),
                    )),
              )),
        ),
        Expanded(
            flex: 2,
            child: Container(
              color: Colors.grey,
              child: Row(children: <Widget>[
                Expanded(
                    child: Container(
                  padding: EdgeInsets.only(left: 5),
                  margin: EdgeInsets.only(right: 1),
                  color: Colors.white,
                  child: TextField(
                    keyboardType: (defaultTargetPlatform == TargetPlatform.iOS)
                        ? TextInputType.numberWithOptions(signed: true)
                        : TextInputType.number,
                    controller: _widthController,
                    style: TextStyle(fontFamily: Constants.INDIAN_RUPEE),
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: Language().getString(title, selectedLang),
                    ),
                  ),
                )),
                Expanded(
                    child: Container(
                        color: Colors.white,
                        padding: EdgeInsets.only(left: 5),
                        child: DropdownButton<String>(
                            onTap: () {
                              CommonMethods.hideKeyboard(context);
                            },
                            value: widthDropdownValue,
                            hint: new Text(
                              Language()
                                  .getString(Constants.SELECT, selectedLang),
                            ),
                            isExpanded: true,
                            underline: SizedBox(),
                            onChanged: (String? data) {
                              setState(() {
                                widthDropdownValue = data;
                              });
                            },
                            items:
                                Constants.measurementsList.map((String model) {
                              return new DropdownMenuItem<String>(
                                child: new Text(model),
                                value: model,
                              );
                            }).toList()))),
              ]),
            ))
      ],
    );
  }

  Future<List<Contacts>> getContacts(String? buId) async {
    setState(() {
      _connectionsList.clear();
    });
    String body = json.encode({"buId": buId, "filters": {}});

    var response = await _invitationService
        .findAllConnections_grpc(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<Contacts> _model = [];
    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(resObj)) {
        for (var noteJson in resObj['results']) {
          _model.add(Contacts.fromJson(noteJson));
        }
      } else {
        // Dialogs.yesCancelDialog(
        //     context,
        //     Language().getString(Constants.ERROR, selectedLang),
        //     _grpcResponse.message,
        //     Language().getString(Constants.OKAY_STR, selectedLang),
        //     "",
        //     false);
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          "$response",
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }

    return _model;
  }

  Future<List<ConnectionsBuDAO>> getBuDetails(String? connectionId) async {
    _connectionDetails.clear();
    String body = json.encode({"id": connectionId});
    var response = await _organizationService
        .getOrganizationDataById(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
        AppController.instance.setCreateBuProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
      AppController.instance.setCreateBuProgress = false;
    });
    List<ConnectionsBuDAO> _list = [];

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(resObj)) {
        _list.add(ConnectionsBuDAO.fromJson(resObj[0]));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    return _list;
  }

  inStockRadioGroup() {
    return Row(
      children: [
        Radio(
          value: Constants.YES_STRING,
          activeColor: Color(Constants.APP_COLOR),
          groupValue: inStockRadioValue,
          onChanged: inStockRadioButtonChanges,
        ),
        Text(Language().getString(Constants.YES_STRING, selectedLang)),
        Radio(
          value: Constants.NO_STRING,
          activeColor: Color(Constants.APP_COLOR),
          groupValue: inStockRadioValue,
          onChanged: inStockRadioButtonChanges,
        ),
        Text(
          Language().getString(Constants.NO_STRING, selectedLang),
        ),
      ],
    );
  }

  forSaleRadioGroup() {
    return Row(
      children: [
        Radio(
          value: Constants.YES_STRING,
          activeColor: Color(Constants.APP_COLOR),
          groupValue: forSaleRadioValue,
          onChanged: forSaleRadioButtonChanges,
        ),
        Text(Language().getString(Constants.YES_STRING, selectedLang)),
        Radio(
          value: Constants.NO_STRING,
          activeColor: Color(Constants.APP_COLOR),
          groupValue: forSaleRadioValue,
          onChanged: forSaleRadioButtonChanges,
        ),
        Text(Language().getString(Constants.NO_STRING, selectedLang)),
      ],
    );
  }

  forOfferRadioGroup() {
    return Column(
      children: [
        Row(
          children: [
            Radio(
              value: Constants.DISCOUNT_IN_PERCENTAGE,
              activeColor: Color(Constants.APP_COLOR),
              groupValue: offerRadioValue,
              onChanged: forSaleRadioButtonChanges,
            ),
            Text(Language()
                .getString(Constants.DISCOUNT_IN_PERCENTAGE, selectedLang)),
          ],
        ),
        Row(
          children: [
            Radio(
              value: Constants.DISCOUNT_AMOUNT,
              activeColor: Color(Constants.APP_COLOR),
              groupValue: offerRadioValue,
              onChanged: forSaleRadioButtonChanges,
            ),
            Text(
              Language().getString(Constants.DISCOUNT_AMOUNT, selectedLang),
            ),
          ],
        )
      ],
    );
  }

  void forOfferRadioButtonChanges(String value) {
    setState(() {
      offerRadioValue = value;
      switch (value) {
        case Constants.DISCOUNT_IN_PERCENTAGE:
          forSaleChoice = value;

          break;
        case Constants.DISCOUNT_AMOUNT:
          forSaleChoice = value;

          break;
      }
    });
  }

  void forSaleRadioButtonChanges(String? value) {
    setState(() {
      forSaleRadioValue = value;
      switch (value) {
        case Constants.YES_STRING:
          forSaleChoice = value;

          break;
        case Constants.NO_STRING:
          forSaleChoice = value;

          break;
      }
    });
  }

  void inStockRadioButtonChanges(String? value) {
    setState(() {
      inStockRadioValue = value;
      switch (value) {
        case Constants.YES_STRING:
          inStockChoice = value;

          break;
        case Constants.NO_STRING:
          inStockChoice = value;

          break;
      }
    });
  }

  validatingItemDetails() {
    if (_heightController.text.isNotEmpty && heightDropdownValue == null) {
      return Constants.PLEASE_SELECT_HEIGHT;
    } else if (heightDropdownValue != null && _heightController.text.isEmpty) {
      return Constants.PLEASE_ENTER_HEIGHT;
    } else if (volumeController.text.isEmpty && volumeDropdownValue != null) {
      return Constants.PLEASE_ENTER_VOLUM;
    } else if (volumeController.text.isNotEmpty &&
        volumeDropdownValue == null) {
      return Constants.PLEASE_SELECT_VOLUM;
    } else if (_weightController.text.isEmpty && weightDropdownValue != null) {
      return Constants.PLEASE_ENTER_WEIGHT;
    } else if (_weightController.text.isNotEmpty &&
        weightDropdownValue == null) {
      return Constants.PLEASE_SELECT_WEIGHT;
    } else if (_widthController.text.isEmpty && widthDropdownValue != null) {
      return Constants.PLEASE_ENTER_WIDTH;
    } else if (_widthController.text.isNotEmpty && widthDropdownValue == null) {
      return Constants.PLEASE_SELECT_WIDTH;
    } else if (_depthController.text.isEmpty && depthDropdownValue != null) {
      return Constants.PLEASE_ENTER_DEPTH;
    } else if (_depthController.text.isNotEmpty && depthDropdownValue == null) {
      return Constants.PLEASE_SELECT_DEPTH;
    } else {
      return "";
    }
  }

  Widget priceDetailsView() {
    return Container(
      margin: EdgeInsets.only(top: 10.0),
      child: Column(
        children: [
          Container(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                this.buildTextField(Language()
                    .getString(Constants.PRICE_DETAILS, selectedLang)),
                SizedBox(
                    height: 25.0,
                    width: 25.0,
                    child: FloatingActionButton(
                      heroTag: null,
                      onPressed: () {
                        CommonMethods.hideKeyboard(context);
                        isLoadingProgress = true;
                        Future.delayed(Duration(milliseconds: 800));
                        priceFieldsPopup(new PriceModel(), -1, false);
                      },
                      child: Icon(
                        Icons.add,
                        size: 15,
                        color: Colors.white,
                      ),
                      backgroundColor: Colors.black, //(0xFF083e64),
                    ))
              ],
            ),
          )
        ],
      ),
    );
  }

  priceFieldsPopup(
      PriceModel priceModel, int index, bool isPriceDetailsUpdate) {
    if (isPriceDetailsUpdate) {
      this.updatePriceDetialsData(priceModel);
    } else {
      this.clearPriceData();
    }

    Future.delayed(Duration(seconds: 1)).then((value) => setState(() {
          isLoadingProgress = false;
        }));
    return showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) =>
            StatefulBuilder(builder: (context, StateSetter setState) {
              return Container(
                  margin:
                      EdgeInsets.symmetric(horizontal: 20.0, vertical: 20.0),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(10.0),
                    child: AppBackgroundView(
                      body: Scaffold(
                        backgroundColor: Colors.transparent,
                        bottomNavigationBar: Container(
                          margin: EdgeInsets.symmetric(horizontal: 5.0),
                          padding: EdgeInsets.only(bottom: 20, top: 10),
                          child: CommonButtonsView(
                              context: context,
                              b1Text: Language().getString(
                                  Constants.STR_CANCEL, selectedLang),
                              b2Text: Language()
                                  .getString(Constants.CONTINUE, selectedLang),
                              onb1Action: () {
                                Navigator.of(context).pop();
                              },
                              onb2Action: () async {
                                String errorMessage =
                                    validatePriceMandatoryFields();
                                if (errorMessage.isNotEmpty) {
                                  Dialogs.yesCancelDialog(
                                      context,
                                      Language().getString(
                                          Constants.ERROR, selectedLang),
                                      Language().getString(
                                          errorMessage, selectedLang),
                                      Language().getString(
                                          Constants.OKAY_STR, selectedLang),
                                      "",
                                      false);
                                } else {
                                  String errorMessageInventory = "";
                                  if (locationDropdownValue != null &&
                                      _locationQuantityController
                                          .text.isNotEmpty) {
                                    errorMessageInventory =
                                        validateAddInstantsInventotyFields(
                                            isPriceDetailsUpdate);
                                  }

                                  if (errorMessageInventory.isNotEmpty) {
                                    Dialogs.yesCancelDialog(
                                        context,
                                        Language().getString(
                                            Constants.ERROR, selectedLang),
                                        Language().getString(
                                            errorMessageInventory,
                                            selectedLang),
                                        Language().getString(
                                            Constants.OKAY_STR, selectedLang),
                                        "",
                                        false);
                                  } else {
                                    await this.onSavePriceDetails(
                                        index, isPriceDetailsUpdate);
                                    this.onSaveInstantInventoryData(
                                        isPriceDetailsUpdate, index);
                                  }
                                }
                              }),
                        ),
                        body: SingleChildScrollView(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                  margin: EdgeInsets.symmetric(
                                      vertical: 20.0, horizontal: 10.0),
                                  child: Text(
                                      Language().getString(
                                          Constants.PRICE_DETAILS,
                                          selectedLang),
                                      style: TextStyle(
                                          color: Colors
                                              .black, //(Constants.APP_COLOR),
                                          fontSize: 15.0,
                                          fontWeight: FontWeight.bold))),
                              (widget.title ==
                                      Language().getString(
                                          Constants.UPDATE_PRODUCT,
                                          selectedLang))
                                  ? Container(
                                      margin: EdgeInsets.symmetric(
                                          vertical: 10.0, horizontal: 10.0),
                                      child: Row(
                                        children: [
                                          Container(
                                            child: Text(
                                                Language().getString(
                                                    Constants.PRODUCT_NAME,
                                                    selectedLang),
                                                style: TextStyle(
                                                    color: Colors
                                                        .black, //(Constants.APP_COLOR),
                                                    fontSize: 15.0,
                                                    fontWeight:
                                                        FontWeight.bold)),
                                          ),
                                          Text("  :  "),
                                          Expanded(
                                              child: Container(
                                            child: Text(
                                                _productNameController.text,
                                                style: TextStyle(
                                                    color: Color(
                                                        Constants.APP_COLOR),
                                                    fontSize: 13.0,
                                                    fontWeight:
                                                        FontWeight.w300)),
                                          ))
                                        ],
                                      ))
                                  : Container(),
                              Container(
                                margin: EdgeInsets.symmetric(
                                  vertical: 10,
                                  horizontal: 10.0,
                                ),
                                child: Column(
                                  children: [
                                    // (widget.isFromRawMaterialPage)
                                    //     ?
                                    if (CommonMethods.isPrivillegeExist(
                                        context,
                                        PrivillegesActions
                                            .KEY_RAW_MATERIAL_TAB))
                                      showProductTypeView(setState),
                                    // : Container(),

                                    (rawMaterialProductRadioValue != null)
                                        ? this.buildDropDownIssuedRawList(
                                            setState)
                                        : Container(),

                                    this.buildQuantityView(
                                        Language().getString(
                                            Constants.QUANTITY, selectedLang),
                                        setState,
                                        isPriceDetailsUpdate),
                                    SizedBox(
                                      height: 1,
                                      child: new Container(
                                          color: Color(Constants.GREY_COLOR)),
                                    ),
                                    // this.buildTableContent(Constants.BATCH_NO,
                                    //     _batchNumController, false, false),

                                    this.buildPriceBatchNumberTextField(
                                        isPriceDetailsUpdate),
                                    Visibility(
                                        visible:
                                            (widget.isFromRawMaterialPage ||
                                                    widget.isFromConsumablePage)
                                                ? false
                                                : true,
                                        child: Container(
                                          child: Column(
                                            children: [
                                              SizedBox(
                                                height: 1,
                                                child: new Container(
                                                    color: Color(
                                                        Constants.GREY_COLOR)),
                                              ),
                                              this.buildDateFieldManufacture(
                                                  Constants.MANUFACTURE_DATE,
                                                  setState),
                                              SizedBox(
                                                height: 1,
                                                child: new Container(
                                                    color: Color(
                                                        Constants.GREY_COLOR)),
                                              ),
                                              this.buildDateFieldExpaire(
                                                  Constants.EXPIRE_DATE_STR,
                                                  setState),
                                            ],
                                          ),
                                        )),

                                    SizedBox(
                                      height: 1,
                                      child: new Container(
                                          color: Color(Constants.GREY_COLOR)),
                                    ),
                                    this.buildUnitDropdown(
                                        Constants.UNIT, setState),
                                    Visibility(
                                        visible: widget.isFromRawMaterialPage
                                            ? true
                                            : true,
                                        child: Container(
                                          child: Column(
                                            children: [
                                              SizedBox(
                                                height: 1,
                                                child: new Container(
                                                    color: Color(
                                                        Constants.GREY_COLOR)),
                                              ),
                                              this.buildTableContent(
                                                  Constants.NET_RATE,
                                                  _netRateController,
                                                  true,
                                                  true),
                                              SizedBox(
                                                height: 1,
                                                child: new Container(
                                                    color: Color(
                                                        Constants.GREY_COLOR)),
                                              ),
                                              this.priceInputFieldView(),
                                              SizedBox(
                                                height: 1,
                                                child: new Container(
                                                    color: Color(
                                                        Constants.GREY_COLOR)),
                                              ),
                                              this.buildTableContent(
                                                  Constants.MRP,
                                                  _mrpController,
                                                  true,
                                                  true),
                                              SizedBox(
                                                height: 1,
                                                child: new Container(
                                                    color: Color(
                                                        Constants.GREY_COLOR)),
                                              ),
                                              this.buildBarcodeField(
                                                  "Barcode",
                                                  _barcodeController,
                                                  true,
                                                  false),
                                              SizedBox(
                                                height: 1,
                                                child: new Container(
                                                    color: Color(
                                                        Constants.GREY_COLOR)),
                                              ),
                                              this.buildDropDownCurrencyName(
                                                  Constants.CURRENCY_NAME,
                                                  setState),
                                            ],
                                          ),
                                        )),
                                    // SizedBox(
                                    //   height: 1,
                                    //   child: new Container(
                                    //       color: Color(Constants.GREY_COLOR)),
                                    // ),
                                    // this.buildTableContent(
                                    //     Constants.DESCRIPTION_STRING,
                                    //     _batchPricingDescription,
                                    //     false,
                                    //     false),
                                  ],
                                ),
                              ),
                              if (isPriceDetailsUpdate)
                                this.showAllocatedLocations(priceModel, index),
                              this.addInventoryQuantityInPriceDetails(
                                  setState, isPriceDetailsUpdate)
                            ],
                          ),
                        ),
                      ),
                    ),
                  ));
            }));
  }

  String validatePriceMandatoryFields() {
    if (widget.isFromRawMaterialPage || widget.isFromConsumablePage) {
      if (_qntyController.text.isEmpty) {
        return Constants.PLEASE_ENTER_QUANTITY;
      } else if (_priceController.text.isEmpty) {
        return Constants.PLEASE_ENTER_PRICE;
      }
      // else if (_batchNumController.text.isEmpty) {
      //   return Constants.PLEASE_ENTER_BATCH_NO;
      // }
      else {
        return "";
      }
    } else {
      if (_qntyController.text.isEmpty) {
        return Constants.PLEASE_ENTER_QUANTITY;
      }
      // else if (_batchNumController.text.isEmpty) {
      //   return Constants.PLEASE_ENTER_BATCH_NO;
      // }
      else if (_priceController.text.isEmpty) {
        return Constants.PLEASE_ENTER_PRICE;
      } else if (_netRateController.text.isEmpty) {
        return Constants.PLEASE_ENTER_NET_RATE;
      } else if (_mrpController.text.isEmpty) {
        return Constants.PLEASE_ENTER_MRP;
      }
      // else if (_barcodeController.text.isEmpty) {
      //   return "Please enter barcode";
      // }
      else {
        return "";
      }
    }
  }

  onSavePriceDetails(int index, bool isPriceDetailsUpdate) {
    if (isPriceDetailsUpdate) {
      _priceList[index] = PriceModel(
          batchNumber: _batchNumController.text,
          manufacturDate: formattedManufactureDate,
          expireDate: formattedExpireDate,
          price: _priceController.text,
          priceIn: priceUnitDropdownValue != null ? priceUnitDropdownValue : "",
          quantity: _qntyController.text,
          quantityIn: quantityDropdownValue != null
              ? quantityDropdownValue
              : Constants.UNIT_PRICE[0],
          netRate: _netRateController.text.isNotEmpty
              ? _netRateController.text
              : "0.0",
          mrp: _mrpController.text.isNotEmpty ? _mrpController.text : "0.0",
          barcode: _barcodeController.text,
          currencyName:
              currencyNameDropdown != null ? currencyNameDropdown!.name : "",
          isActualProduct: actualProductRadioValue != null ? true : false,
          isRawMaterial: rawMaterialProductRadioValue != null ? true : false,
          issuedId:
              rawIssuedListDropDown != null ? rawIssuedListDropDown!.id : "",
          issuedTo: rawIssuedListDropDown != null
              ? rawIssuedListDropDown!.issuedTo!.userName
              : "",
          description: _batchPricingDescription.text,
          issueNumber: rawIssuedListDropDown != null
              ? rawIssuedListDropDown!.issueNumber
              : 0);
    } else {
      _priceList.add(PriceModel(
          batchNumber: _batchNumController.text,
          manufacturDate: formattedManufactureDate,
          expireDate: formattedExpireDate,
          price: _priceController.text,
          priceIn: priceUnitDropdownValue != null ? priceUnitDropdownValue : "",
          quantity: _qntyController.text,
          quantityIn: quantityDropdownValue != null
              ? quantityDropdownValue
              : Constants.UNIT_PRICE[0],
          netRate: _netRateController.text.isNotEmpty
              ? _netRateController.text
              : "0.0",
          mrp: _mrpController.text.isNotEmpty ? _mrpController.text : "0.0",
          barcode: _barcodeController.text,
          currencyName:
              currencyNameDropdown != null ? currencyNameDropdown!.name : "",
          isActualProduct: actualProductRadioValue != null ? true : false,
          isRawMaterial: rawMaterialProductRadioValue != null ? true : false,
          issuedId:
              rawIssuedListDropDown != null ? rawIssuedListDropDown!.id : "",
          issuedTo: rawIssuedListDropDown != null
              ? rawIssuedListDropDown!.issuedTo!.userName
              : "",
          description: _batchPricingDescription.text,
          issueNumber: rawIssuedListDropDown != null
              ? rawIssuedListDropDown!.issueNumber
              : 0));
    }

    setState(() {
      _priceList.reversed;
    });
  }

  Widget priceInputFieldView() {
    return Container(
        // padding: EdgeInsets.all(1),
        child: Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 55.0,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Row(
                      children: [
                        Expanded(
                          flex: 2,
                          child: RichText(
                            text: TextSpan(children: [
                              TextSpan(
                                text: Language().getString(
                                    Constants.B2B_SALES_PRICE, selectedLang),
                                style: TextStyle(
                                    fontSize: StyleView.FONT_SIZE_15,
                                    fontFamily: StyleView.FONT_TITLE,
                                    color: Colors.black),
                              ),
                              TextSpan(
                                  text: "\*",
                                  style: TextStyle(
                                      fontSize: 13.0, color: Colors.red))
                            ]),
                          ),
                        ),
                        Expanded(
                          child: Container(
                            height: 55.0,
                            color: Color(Constants.GREY_COLOR_LIGHT),
                            alignment: Alignment.center,
                            child: Text(
                              "$currencySymbol",
                              style: TextStyle(
                                fontSize: 13.0,
                              ),
                            ),
                          ),
                        ),
                      ],
                    )),
              )),
        ),
        Expanded(
          flex: 2,
          child: Container(
            color: Colors.white,
            height: 55,
            padding: EdgeInsets.only(left: 5.0),
            child: TextField(
                keyboardType: (defaultTargetPlatform == TargetPlatform.iOS)
                    ? TextInputType.numberWithOptions(
                        signed: true, decimal: false)
                    : TextInputType.number,
                textInputAction: TextInputAction.next,
                controller: _priceController,
                style: TextStyle(fontFamily: Constants.INDIAN_RUPEE),
                decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: Language()
                        .getString(Constants.B2B_SALES_PRICE, selectedLang)),
                inputFormatters: [
                  CommonMethods.inputTextFormatter(isDouble: true)
                ]),
          ),
        )
      ],
    ));
  }

  updatePriceDetialsData(PriceModel priceModel) {
    setState(() {
      locationDropdownValue = null;
      _locationQuantityController.clear();
      inventoryQuntityInDropdown = Constants.UNIT_PRICE[0];

      _barcodeController.text = priceModel.barcode ?? "";

      _qntyController.text = priceModel.quantity!;
      for (int i = 0; i < Constants.UNIT_PRICE.length; i++) {
        if (Constants.UNIT_PRICE[i] == priceModel.quantityIn) {
          quantityDropdownValue = Constants.UNIT_PRICE[i];
          inventoryQuntityInDropdown = Constants.UNIT_PRICE[i];
        }
      }

      formattedExpireDate = priceModel.expireDate;
      formattedManufactureDate = priceModel.manufacturDate;
      _batchNumController.text = priceModel.batchNumber!;
      _mrpController.text = priceModel.mrp!;
      _netRateController.text = priceModel.netRate!;
      for (int i = 0; i < Constants.UNIT_PRICE.length; i++) {
        if (Constants.UNIT_PRICE[i] == priceModel.priceIn) {
          priceUnitDropdownValue = Constants.UNIT_PRICE[i];
        }
      }
      _priceController.text = priceModel.price!;
      if (_currencyNameList.length > 0) {
        for (int i = 0; i < _currencyNameList.length; i++) {
          if (_currencyNameList[i].name == priceModel.currencyName) {
            currencyNameDropdown = _currencyNameList[i];
          }
        }
      }

      if (priceModel.isRawMaterial!) {
        rawMaterialProductRadioValue = Constants.MANUFACTURED_INHOUSE;
        actualProductRadioValue = null;
      }

      if (priceModel.isActualProduct!) {
        actualProductRadioValue = Constants.PURCHASED_PRODUCTS;
        rawMaterialProductRadioValue = null;
      }

      for (int u = 0; u < _rawIssuesList.length; u++) {
        if (priceModel.issuedId == _rawIssuesList[u].id) {
          rawIssuedListDropDown = _rawIssuesList[u];
        }
      }

      _batchPricingDescription.text = priceModel.description!;
    });

    // if (inventoryList.length > 0 && locationsList.length > 0) {
    //   bool isBatchExist = false;
    //   int locationPosition = -1;
    //   int inventoryPosition = -1;
    //   for (int p = 0; p < inventoryList.length; p++) {
    //     for (int q = 0; q < inventoryList[p].locationBatchList.length; q++) {
    //       if (priceModel.batchNumber ==
    //           inventoryList[p].locationBatchList[q].batchNumber) {
    //         isBatchExist = true;
    //         locationPosition = p;
    //         inventoryPosition = q;
    //       }
    //     }
    //   }

    //   if (isBatchExist) {
    //     for (int locationIndex = 0;
    //         locationIndex < locationsList.length;
    //         locationIndex++) {
    //       if (inventoryList[locationPosition].locationName ==
    //           locationsList[locationIndex].locationName) {
    //         locationDropdownValue = locationsList[locationIndex];
    //       }
    //     }

    //     _locationQuantityController.text = inventoryList[locationPosition]
    //         .locationBatchList[inventoryPosition]
    //         .quantity
    //         .toString();
    //     if (inventoryList[locationPosition]
    //                 .locationBatchList[inventoryPosition]
    //                 .quantityIn ==
    //             null ||
    //         inventoryList[locationPosition]
    //             .locationBatchList[inventoryPosition]
    //             .quantityIn
    //             .isEmpty) {
    //       inventoryQuntityInDropdown = Constants.UNIT_PRICE[0];
    //     } else {
    //       inventoryQuntityInDropdown = inventoryList[locationPosition]
    //           .locationBatchList[inventoryPosition]
    //           .quantityIn;
    //     }
    //   }
    // }
  }

  clearPriceData() {
    final String today = DateFormat('yyyy/MM/dd').format(DateTime.now());
    setState(() {
      _qntyController.clear();
      quantityDropdownValue = null;
      if (_priceList.length > 0) {
        String batchNumber = _priceList[_priceList.length - 1].batchNumber!;
        if (batchNumber.isNotEmpty) {
          _batchNumController.text = batchNumber;
        } else {
          _batchNumController.text = today;
        }
        _priceController.text = _priceList[_priceList.length - 1].price!;
        _mrpController.text = _priceList[_priceList.length - 1].mrp!;
        _netRateController.text = _priceList[_priceList.length - 1].netRate!;
        _barcodeController.text =
            _priceList[_priceList.length - 1].barcode ?? "";
      } else {
        _batchNumController.text = today;
      }

      formattedExpireDate = formatter.format(mnthStartDate);
      formattedManufactureDate = formatter.format(mnthStartDate);
      // _batchNumController.clear();
      // _mrpController.clear();
      // _netRateController.clear();
      locationDropdownValue = null;
      _locationQuantityController.clear();
      // _priceController.clear();
      inventoryQuntityInDropdown = null;
      for (int i = 0; i < _currencyNameList.length; i++) {
        /// Comparing currency name
        if (_currencyNameList[i].name == "Indian Rupee") {
          currencyNameDropdown = _currencyNameList[i];
          currencySymbol = currencyNameDropdown!.htmlSymbol;
          break;
        }
      }
      for (int i = 0; i < Constants.UNIT_PRICE.length; i++) {
        if (Constants.UNIT_PRICE[i] == Constants.UNIT_STRING) {
          quantityDropdownValue = Constants.UNIT_PRICE[i];
          priceUnitDropdownValue = Constants.UNIT_PRICE[i];
          inventoryQuntityInDropdown = Constants.UNIT_PRICE[i];
          break;
        }
      }
      rawMaterialProductRadioValue = null;
      actualProductRadioValue = Constants.PURCHASED_PRODUCTS;
      rawIssuedListDropDown = null;
    });
  }

  loadRawListData() async {
    if (await NetworkStatus.getInternetStatus()) {
      this.getRawProductsIssuesList().then((value) {
        setState(() {
          _rawIssuesList.clear();
          _rawIssuesList.addAll(value);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<RawProductsIssueDAO>> getRawProductsIssuesList() async {
    setState(() {
      _rawIssuesList.clear();
    });
    String body = json.encode({"bu": buId, "filters": {}});

    var response = await _productService
        .getRawProductIssueList(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      // Dialogs.yesCancelDialog(
      //     context,
      //     Language().getString(Constants.ERROR, selectedLang),
      //     onError.toString(),
      //     Language().getString(Constants.OKAY_STR, selectedLang),
      //     "",
      //     false);
    });
    List<RawProductsIssueDAO> list = [];
    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      bool isString = false;
      if (resObj is String) {
        isString = true;
      }

      if (!isString) {
        var data = resObj["results"];

        for (var obj in data) {
          list.add(RawProductsIssueDAO.fromJson(obj));
        }
      }
    } else {
      // Dialogs.yesCancelDialog(
      //     context,
      //     Language().getString(Constants.ERROR, selectedLang),
      //     _grpcResponse.message,
      //     Language().getString(Constants.OKAY_STR, selectedLang),
      //     "",
      //     false);
    }

    return list;
  }

  Widget showProductTypeView(StateSetter setState) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 5.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Row(
              children: [
                Radio(
                  value: Constants.PURCHASED_PRODUCTS,
                  activeColor: Color(Constants.APP_COLOR),
                  groupValue: actualProductRadioValue,
                  onChanged: (dynamic value) {
                    setState(() {
                      actualProductRadioValue = value;
                      rawMaterialProductRadioValue = null;
                      rawIssuedListDropDown = null;
                      _batchNumController.clear();
                    });
                  },
                ),
                Expanded(
                  child: Text(Language()
                      .getString(Constants.PURCHASED_PRODUCTS, selectedLang)),
                ),
              ],
            ),
          ),
          Expanded(
            child: Row(
              children: [
                Radio(
                  value: Constants.MANUFACTURED_INHOUSE,
                  activeColor: Color(Constants.APP_COLOR),
                  groupValue: rawMaterialProductRadioValue,
                  onChanged: (dynamic value) {
                    if (_rawIssuesList.length > 0) {
                      setState(() {
                        rawMaterialProductRadioValue = value;
                        actualProductRadioValue = null;
                        _batchNumController.clear();
                      });
                    } else {
                      setState(() {
                        rawMaterialProductRadioValue = null;
                        actualProductRadioValue = Constants.PURCHASED_PRODUCTS;
                      });
                      Dialogs.yesCancelDialog(
                          context,
                          Language().getString(Constants.ERROR, selectedLang),
                          Language().getString(
                              Constants.YOU_HAVE_NO_RAW_MATERIAL_LIST,
                              selectedLang),
                          Language()
                              .getString(Constants.OKAY_STR, selectedLang),
                          "",
                          false);
                    }
                  },
                ),
                Expanded(
                  child: Text(Language()
                      .getString(Constants.MANUFACTURED_INHOUSE, selectedLang)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  showSelectedIssuedCardView(RawProductsIssueDAO model, TextAlign textAlign) {
    return Container(
        child: Card(
      child: Padding(
        padding: const EdgeInsets.all(5.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Expanded(
                child: Container(
                    child: Text(
                        Language()
                            .getString(Constants.ISSUANCE_ID, selectedLang),
                        style: TextStyle(
                            color: Color(Constants.APP_COLOR),
                            fontSize: 12.0,
                            fontWeight: FontWeight.bold))),
              ),
              Expanded(
                  flex: 2,
                  child: Container(
                      child: Row(
                    children: [
                      Container(child: Text(": ")),
                      Expanded(
                        child: Container(
                          child: Text("${model.issueNumber}",
                              style: TextStyle(
                                fontSize: 12.0,
                              )),
                        ),
                      ),
                    ],
                  )))
            ]),
            Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Expanded(
                child: Container(
                    child: Text(
                        Language().getString(Constants.ISSUED_TO, selectedLang),
                        style: TextStyle(
                            color: Color(Constants.APP_COLOR),
                            fontSize: 12.0,
                            fontWeight: FontWeight.bold))),
              ),
              Expanded(
                  flex: 2,
                  child: Row(
                    children: [
                      Container(child: Text(": ")),
                      Expanded(
                        child: Container(
                            child: Text("${model.issuedTo!.userName}",
                                style: TextStyle(
                                  fontSize: 12.0,
                                ))),
                      ),
                    ],
                  ))
            ]),
            Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Expanded(
                child: Container(
                    child: Text(
                        Language().getString(Constants.DATE, selectedLang),
                        style: TextStyle(
                            color: Color(Constants.APP_COLOR),
                            fontSize: 12.0,
                            fontWeight: FontWeight.bold))),
              ),
              Expanded(
                  flex: 2,
                  child: Row(
                    children: [
                      Container(child: Text(": ")),
                      Expanded(
                        child: Container(
                            child: Text(
                                AppUtills.getDateFormate(
                                    model.createdDate.toString()),
                                style: TextStyle(
                                  fontSize: 12.0,
                                ))),
                      ),
                    ],
                  ))
            ]),
            Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Expanded(
                child: Container(
                    child: Text(
                        Language().getString(Constants.PURPOSE, selectedLang),
                        style: TextStyle(
                            color: Color(Constants.APP_COLOR),
                            fontSize: 12.0,
                            fontWeight: FontWeight.bold))),
              ),
              Expanded(
                  flex: 2,
                  child: Row(
                    children: [
                      Container(child: Text(": ")),
                      Expanded(
                        child: Container(
                            child: Text(model.issuedPurpose!,
                                style: TextStyle(
                                  fontSize: 12.0,
                                ))),
                      ),
                    ],
                  ))
            ])
          ],
        ),
      ),
    ));
  }

  void bindingProductData(BuProductModal modelData) {
    if (widget.title ==
        Language().getString(Constants.UPDATE_PRODUCT, selectedLang)) {
      imageRelativePath = modelData.images == null ? "" : modelData.images!;
    }
    if (modelData.batchPrice!.length > 0) {
      for (int p = 0; p < modelData.batchPrice!.length; p++) {
        _priceList.add(
          PriceModel(
              batchNumber: modelData.batchPrice![p].batchNumber,
              currencyName: modelData.batchPrice![p].currencyName,
              expireDate: modelData.batchPrice![p].expiryDate,
              manufacturDate: modelData.batchPrice![p].manufactureDate,
              mrp: modelData.batchPrice![p].mrp.toString(),
              netRate: modelData.batchPrice![p].netRate.toString(),
              price: modelData.batchPrice![p].price.toString(),
              priceIn: modelData.batchPrice![p].unitPrice,
              quantity: modelData.batchPrice![p].quantity.toString(),
              quantityIn: modelData.batchPrice![p].quantityIn,
              issuedTo: modelData.batchPrice![p].issuedTo,
              isRawMaterial: modelData.batchPrice![p].isRawMaterial,
              isActualProduct: modelData.batchPrice![p].isActualProduct,
              description: modelData.batchPrice![p].description,
              issueNumber: modelData.batchPrice![p].issueNumber,
              issuedId: modelData.batchPrice![p].issueId,
              barcode: modelData.batchPrice![p].barcode),
        );
      }
    }

    _skuController.text = modelData.sku!;
    _productNameController.text = modelData.name!;
    _brandController.text = modelData.brand!;
    _descriptionController.text = modelData.description!;

    /// Condition for stock available or not
    if (modelData.inStock!) {
      inStockRadioValue = Constants.YES_STRING;
    } else {
      inStockRadioValue = Constants.NO_STRING;
    }

    /// Condition for product for sale or not
    if (modelData.forSale!) {
      forSaleRadioValue = Constants.YES_STRING;
    } else {
      forSaleRadioValue = Constants.NO_STRING;
    }

    _batchNumController.text = modelData.batchNumber!;
    formattedManufactureDate = modelData.expiryDate != null
        ? formatter.format(modelData.expiryDate!)
        : "";

    formattedExpireDate = modelData.expiryDate != null
        ? formatter.format(modelData.expiryDate!)
        : "";

    /// Manufacture details
    if (modelData.manufactureDetails != null) {
      _modelNumberController.text = modelData.manufactureDetails!.modelNumber!;
      _dialCodeController.text = modelData.manufactureDetails!.dialCode!;
      _manufactureNameController.text = modelData.manufactureDetails!.name!;
      _manufactureAddressController.text = _manufactureAddressController.text =
          modelData.manufactureDetails!.manufacturerAddress!;
      _buildingNumController.text = modelData.manufactureDetails!.buildiName!;
      _areaController.text = modelData.manufactureDetails!.area!;
      _cityController.text = modelData.manufactureDetails!.city!;
      _talukController.text = modelData.manufactureDetails!.taluka!;
      _landMarkController.text = modelData.manufactureDetails!.landmark!;

      _districtController.text = modelData.manufactureDetails!.district!;
      _pinController.text = modelData.manufactureDetails!.pin!;
      if (modelData.manufactureDetails!.releaseDate != null)
        formattedReleaseDate =
            formatter.format(modelData.manufactureDetails!.releaseDate!);
    }

    /// Item Details
    if (modelData.shippingDetails != null) {
      /// Spilt weight value
      if (modelData.shippingDetails!.weight!.isNotEmpty) {
        List weightSplitText = modelData.shippingDetails!.weight!.split(" ");
        _weightController.text = weightSplitText[0];
        for (int i = 0; i < Constants.weightMeasurementsList.length; i++) {
          if (Constants.weightMeasurementsList[i] == weightSplitText[1]) {
            setState(() {
              weightDropdownValue = Constants.weightMeasurementsList[i];
            });
          }
        }
      }

      /// Split height value
      if (modelData.shippingDetails!.height!.isNotEmpty) {
        List heightSplitText = modelData.shippingDetails!.height!.split(" ");
        _heightController.text = heightSplitText[0];
        for (int i = 0; i < Constants.measurementsList.length; i++) {
          if (Constants.measurementsList[i] == heightSplitText[1]) {
            setState(() {
              heightDropdownValue = Constants.measurementsList[i];
            });
          }
        }
      }

      /// Split width value
      if (modelData.shippingDetails!.width!.isNotEmpty) {
        List widthSplitText = modelData.shippingDetails!.width!.split(" ");
        _widthController.text = widthSplitText[0];
        for (int i = 0; i < Constants.measurementsList.length; i++) {
          if (Constants.measurementsList[i] == widthSplitText[1]) {
            setState(() {
              widthDropdownValue = Constants.measurementsList[i];
            });
          }
        }
      }

      /// Spilt depth value
      if (modelData.shippingDetails!.depth != "") {
        List depthSplitText = modelData.shippingDetails!.depth!.split(" ");
        _depthController.text = depthSplitText[0];
        for (int i = 0; i < Constants.measurementsList.length; i++) {
          if (Constants.measurementsList[i] == depthSplitText[1]) {
            depthDropdownValue = Constants.measurementsList[i];
          }
        }
      }

      /// Spilt volume value
      if (modelData.shippingDetails!.volume != "") {
        List volumeSplitText = modelData.shippingDetails!.volume!.split(" ");
        volumeController.text = volumeSplitText[0];
        for (int i = 0; i < Constants.volumeMeasurementsList.length; i++) {
          if (Constants.volumeMeasurementsList[i] == volumeSplitText[1]) {
            volumeDropdownValue = Constants.volumeMeasurementsList[i];
          }
        }
      }
    }

    /// quantity details
    if (modelData.quantityIn != null) {
      for (int i = 0; i < Constants.UNIT_PRICE.length; i++) {
        if (modelData.quantityIn == Constants.UNIT_PRICE[i]) {
          quantityDropdownValue = Constants.UNIT_PRICE[i];
        }
      }
    }
    for (int i = 0; i < modelData.offers!.length; i++) {
      _offersList.add(OffersModel(
          offerId: modelData.offers![i].offerId,
          offerName: modelData.offers![i].offerName ?? "",
          offerQuantity: modelData.offers![i].offerQuantity ?? "" as num?,
          minOrder: modelData.offers![i].minOrder ?? 0,
          maxOrder: modelData.offers![i].maxOrder ?? 0,
          startDate: modelData.offers![i].startDate ?? "",
          endDate: modelData.offers![i].endDate ?? "",
          details: modelData.offers![i].details ?? "",
          offerDiscount: modelData.offers![i].offerType ?? "",
          isOfferActive: modelData.offers![i].isOfferActive ?? false,
          isOfferExpired: modelData.offers![i].isOfferExpired));
    }

    for (int i = 0; i < modelData.attributes!.length; i++) {
      attributesList.add(ProductAttributeModel(
          attributeKey: modelData.attributes![i].entries.toList()[0].key,
          attributeValue: modelData.attributes![i].entries.toList()[0].value));
    }

    for (int i = 0; i < modelData.suppliers!.length; i++) {
      _supplierList.add(SupplierModel(
          id: modelData.suppliers![i].id,
          name: modelData.suppliers![i].name,
          city: modelData.suppliers![i].city,
          district: modelData.suppliers![i].district,
          locality: modelData.suppliers![i].locality,
          contact: modelData.suppliers![i].phoneNo));
    }

    if (modelData.tax != null) {
      for (int i = 0; i < Constants.taxTypes.length; i++) {
        if (modelData.tax!.type == Constants.taxTypes[i]) {
          taxDropdownValue = Constants.taxTypes[i];
        }
      }

      for (int i = 0; i < Constants.taxRateValues.length; i++) {
        String taxPercentage = "${modelData.tax!.value}" + " %";
        if (taxPercentage == Constants.taxRateValues[i]) {
          taxValueDropdownValue = Constants.taxRateValues[i];
        }
      }

      hsnCodeController.text = modelData.tax!.hsnCode!;
      if (widget.isFromRawMaterialPage && modelData.isRawProduct!) {
        int totalInventoryCount = 0;
        for (int i = 0; i < modelData.rawInventoryData!.length; i++) {
          totalInventoryCount = totalInventoryCount +
              (modelData.rawInventoryData![i].quantity as int);

          rawInventoryList.add(RawInventory(
              issuedTo: modelData.rawInventoryData![i].issuedTo,
              quantity: modelData.rawInventoryData![i].quantity,
              batchNumber: modelData.rawInventoryData![i].batchNumber));
        }

        // productTotalQuantity = productTotalQuantity - totalInventoryCount;
      }
    }

    // for (int i = 0; i < modelData.quantityAdjustList.length; i++) {
    quantityAdjustmentList.addAll(modelData.quantityAdjustList!);
    // }
  }

  Widget onCreateDynamicRawInventory() {
    return Column(children: <Widget>[
      for (int i = 0; i < rawInventoryList.length; i++)
        Container(
          margin: EdgeInsets.symmetric(
            vertical: 5.0,
          ),
          child: Column(children: <Widget>[
            RawInventoryExpandedPage(
              title: Language().getString(Constants.ISSUED_TO, selectedLang) +
                  " : ${rawInventoryList[i].issuedTo}",
              managementModel: rawInventoryList[i],
            )
          ]),
        ),
    ]);
  }

  void showBarcodePopup({bool canAddMultiple = false, int index = 0}) {
    showDialog(
      context: context,
      builder: (_) {
        return BarcodePopup(
          barcode: canAddMultiple
              ? _priceList[index].barcode
              : _barcodeController.text,
          productName: _productNameController.text,
          price: canAddMultiple ? _priceList[index].price : "",
          onScan: () => scanAndAssign(context,
              canAddMultiple: canAddMultiple, batchIndex: index),
          onGenerate: () => generateAndAssign(
              canAddMultiple: canAddMultiple, batchIndex: index),
        );
      },
    );
  }

  buildBarcodeField(String textName, TextEditingController _controller,
      bool _isKeyboard, bool isMandatory,
      {bool enable = true}) {
    return Container(
        color: Color(Constants.GREY_COLOR_LIGHT),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  child: Container(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: EdgeInsets.all(8.0),
                  child: isMandatory
                      ? RichText(
                          text: TextSpan(children: [
                            TextSpan(
                              text:
                                  Language().getString(textName, selectedLang),
                              style: TextStyle(
                                  fontSize: StyleView.FONT_SIZE_15,
                                  fontFamily: StyleView.FONT_TITLE,
                                  color: Colors.black),
                            ),
                            TextSpan(
                                text: "\*",
                                style: TextStyle(
                                    fontSize: StyleView.FONT_SIZE_15,
                                    color: Colors.red))
                          ]),
                        )
                      : Text(
                          Language().getString(textName, selectedLang),
                          style: TextStyle(
                              fontSize: StyleView.FONT_SIZE_15,
                              fontWeight: StyleView.fontMedium),
                        ),
                ),
              )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                color: Colors.white,
                alignment: Alignment.centerLeft,
                padding: EdgeInsets.only(left: 5.0),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                          controller: _controller,
                          keyboardType: _isKeyboard
                              ? TextInputType.numberWithOptions(signed: true)
                              : TextInputType.text,
                          textInputAction: TextInputAction.next,
                          enabled: enable,
                          style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintText:
                                Language().getString(textName, selectedLang),
                          ),
                          inputFormatters: (_isKeyboard)
                              ? [
                                  CommonMethods.inputTextFormatter(
                                      isDouble: true)
                                ]
                              : []),
                    ),
                    Container(
                      child: IconButton(
                        onPressed: () {
                          showBarcodePopup();
                        },
                        icon: Icon(
                          Icons.qr_code,
                          color: Color(Constants.APP_COLOR),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            )
          ],
        ));
  }

  buildDropDownIssuedRawList(StateSetter setState) {
    return Container(
        padding: EdgeInsets.all(5),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            RichText(
              text: TextSpan(children: [
                TextSpan(
                  text: Language().getString(
                      Constants.RAW_MATERIAL_ISSUANCE_NOTE, selectedLang),
                  style: TextStyle(
                      color: theme.colorScheme.primary,
                      fontSize: StyleView.FONT_SIZE_15,
                      fontFamily: StyleView.FONT_TITLE,
                      fontWeight: StyleView.fontMedium),
                ),
                TextSpan(
                    text: "\*",
                    style: TextStyle(
                        fontSize: StyleView.FONT_SIZE_15,
                        fontFamily: StyleView.FONT_TITLE,
                        color: Colors.red))
              ]),
            ),
            Container(
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5.0),
                  border: Border.all(color: Colors.grey)),
              margin: EdgeInsets.symmetric(vertical: 10),
              child: InkWell(
                onTap: () {
                  CommonMethods.hideKeyboard(context);
                  if (_rawIssuesList.length > 0) {
                    this.showRawIssuedNoteListData(setState);
                  } else {
                    Dialogs.yesCancelDialog(
                        context,
                        Language().getString(Constants.ERROR, selectedLang),
                        Language().getString(
                            Constants.NO_RAW_MATERIAL_ISSUANCE_LIST,
                            selectedLang),
                        Language().getString(Constants.OKAY_STR, selectedLang),
                        "",
                        false);
                  }
                },
                child: Container(
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5.0),
                        color: Colors.white70),
                    padding: EdgeInsets.only(left: 5, right: 5),
                    child: Row(
                      children: [
                        Expanded(
                          flex: 4,
                          child: (rawIssuedListDropDown == null)
                              ? Container(
                                  height: 50,
                                  alignment: Alignment.centerLeft,
                                  child: Text(
                                    Language().getString(
                                        Constants.SELECT_RAW_MATERIAL_NOTE,
                                        selectedLang),
                                    style: TextStyle(fontSize: 15.0),
                                  ))
                              : showSelectedIssuedCardView(
                                  rawIssuedListDropDown!, TextAlign.start),
                        ),
                        Expanded(
                          child: Container(
                            child: Icon(Icons.expand_more),
                          ),
                        ),
                      ],
                    )),
              ),
            ),
            SizedBox(
              height: 1,
              child: new Container(color: Color(Constants.GREY_COLOR)),
            ),
          ],
        ));
  }

  showRawIssuedNoteListData(StateSetter setState) {
    return showDialog(
      context: context,
      builder: (context) => Container(
        margin: EdgeInsets.symmetric(vertical: 15.0, horizontal: 10.0),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(5.0), color: Colors.white),
        child: Scaffold(
          backgroundColor: Colors.transparent,
          bottomNavigationBar: Container(
              height: 50.0,
              alignment: Alignment.centerRight,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: InkWell(
                    onTap: () {
                      Navigator.of(context).pop();
                    },
                    child: Text(
                        Language().getString(Constants.CLOSE, selectedLang),
                        style: TextStyle(
                            color: Color(Constants.APP_COLOR),
                            fontSize: 15.0,
                            fontWeight: FontWeight.bold))),
              )),
          body: Container(
              child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                // this.buildDropdownRawList(setState),
                Expanded(
                  child: Container(
                    margin: EdgeInsets.only(top: 10.0),
                    child: ListView.builder(
                      shrinkWrap: true,
                      itemBuilder: (context, index) {
                        return InkWell(
                            onTap: () {
                              Navigator.of(context).pop();
                              setState(() {
                                rawIssuedListDropDown = _rawIssuesList[index];
                                _batchNumController.text =
                                    _rawIssuesList[index].issueBatchNumber!;
                              });
                            },
                            child: this.showRawIssueNotesList(index));
                      },
                      itemCount: _rawIssuesList.length,
                    ),
                  ),
                )
              ],
            ),
          )),
        ),
      ),
    );
  }

  Widget offerHeaderText(String name) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 5.0),
      child: Text(
        Language().getString(name, selectedLang),
        style: TextStyle(
            color: Colors.black, //(Constants.APP_COLOR),
            fontSize: 15.0,
            fontWeight: FontWeight.bold),
      ),
    );
  }

  Widget inventoryBottomView(int index, bool isUpdateInventory) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 10),
      child: CommonButtonsView(
        context: context,
        b1Text: Language().getString(Constants.STR_CANCEL, selectedLang),
        b2Text: Language().getString(Constants.CONTINUE, selectedLang),
        onb1Action: () {
          Navigator.of(context).pop();
        },
        onb2Action: () async {
          String errorMessage = this.validateInventoryFields();
          if (errorMessage.isNotEmpty) {
            Dialogs.yesCancelDialog(
                context,
                Language().getString(Constants.ERROR, selectedLang),
                Language().getString(errorMessage, selectedLang),
                Language().getString(Constants.OKAY_STR, selectedLang),
                "",
                false);
          } else {
            if (remainingBatchQuantity != "0.0") {
              if (remainigQuantityValidation(isUpdateInventory)) {
                // double.parse(_locationQuantityController.text) >
                //   double.parse(inventoryQuantityDropdown.quantity)) {
                Dialogs.yesCancelDialog(
                    context,
                    Language().getString(Constants.ERROR, selectedLang),
                    Language()
                        .getString(Constants.INVALID_QUANTITY, selectedLang),
                    Language().getString(Constants.OKAY_STR, selectedLang),
                    "",
                    false);
              } else {
                final action = await Dialogs.yesCancelDialog(
                    context,
                    Language().getString(Constants.INFO, selectedLang),
                    Language().getString(
                            Constants
                                .ARE_YOU_SURE_ADD_ENTER_QUANTITY_TO_INVENTORY,
                            selectedLang) +
                        " \"${locationDropdownValue!.locationName}\"",
                    Language().getString(Constants.YES_STRING, selectedLang),
                    Language().getString(Constants.NO_STRING, selectedLang),
                    true);

                if (action == DialogAction.yes) {
                  this.updatingBatchQuantity(
                      index, isUpdateInventory, setState);
                }
              }
            } else {
              Dialogs.yesCancelDialog(
                  context,
                  Language().getString(Constants.ERROR, selectedLang),
                  Language()
                      .getString(Constants.INVALID_QUANTITY, selectedLang),
                  Language().getString(Constants.OKAY_STR, selectedLang),
                  "",
                  false);
            }
          }
        },
      ),
    );
  }

  showAllocatedBatchesWithLocationDetails() {
    if (inventoryList.length > 0) {
      return Container(
        margin: EdgeInsets.only(top: 10.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              child: Text(
                Language().getString(Constants.STOCK_AT_DIFF_LOC, selectedLang),
                style: TextStyle(
                    fontWeight: FontWeight.w600,
                    color: Color(Constants.APP_COLOR)),
              ),
            ),
            InventoryListDataTable(
              batchList: inventoryList,
              strBatchNumber:
                  Language().getString(Constants.BATCH_NO, selectedLang),
              strQuantity:
                  Language().getString(Constants.QUANTITY, selectedLang),
            )
          ],
        ),
      );
    } else {
      return SizedBox();
    }
  }

  showBatchPricingDetails(PriceModel? inventoryDropdownQuantity, int index,
      bool isUpdateInventory) {
    if (inventoryList.length > 0 && inventoryDropdownQuantity != null) {
      bool isExist = false;

      for (int i = 0; i < inventoryList.length; i++) {
        for (int j = 0; j < inventoryList[i].locationBatchList!.length; j++) {
          if (inventoryDropdownQuantity.batchNumber ==
              inventoryList[i].locationBatchList![j].batchNumber) {
            isExist = true;
          }
        }
      }
      if (isExist) {
        return Container(
          margin: EdgeInsets.only(top: 10.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                child: Text(
                  Language().getString(
                      Constants.BATCH_DETAILAS_AT_DIFF_LOC, selectedLang),
                  style: TextStyle(
                      fontWeight: FontWeight.w600,
                      color: Color(Constants.APP_COLOR)),
                ),
              ),
              InventoryLocationBatchView(
                batchList: inventoryList,
                batchNumber: inventoryDropdownQuantity.batchNumber,
                strBatchNumber:
                    Language().getString(Constants.BATCH_NO, selectedLang),
                strQuantity:
                    Language().getString(Constants.QUANTITY, selectedLang),
                strUpdatedBy:
                    Language().getString(Constants.UPDATED_BY, selectedLang),
                strUpdatedDate:
                    Language().getString(Constants.UPDATED_DATE, selectedLang),
                strAdjustedQuantity: Language()
                    .getString(Constants.ADJUSTED_QUANTITY, selectedLang),
                strReason: Language().getString(Constants.REASON, selectedLang),
              )
            ],
          ),
        );
      } else {
        return SizedBox();
      }
    } else {
      return Container();
    }
  }

  showLocationBatchNumbers(String? locationName) {
    for (int i = 0; i < inventoryList.length; i++) {
      if (locationName == inventoryList[i].locationName) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              child: Text(
                  Language().getString(Constants.BATCHES_IN_LOC, selectedLang),
                  style: TextStyle(
                      color: Color(Constants.APP_COLOR),
                      fontWeight: FontWeight.w600)),
            ),
            InventoryLocationBatchView(
              isShowLocationDetails: true,
              locationsList: inventoryList[i].locationBatchList,
              strBatchNumber:
                  Language().getString(Constants.BATCH_NO, selectedLang),
              strQuantity:
                  Language().getString(Constants.QUANTITY, selectedLang),
              strUpdatedBy:
                  Language().getString(Constants.UPDATED_BY, selectedLang),
              strUpdatedDate:
                  Language().getString(Constants.UPDATED_DATE, selectedLang),
              strAdjustedQuantity: Language()
                  .getString(Constants.ADJUSTED_QUANTITY, selectedLang),
              strReason: Language().getString(Constants.REASON, selectedLang),
            )
          ],
        );
      }
    }
  }

  showBatchPriceData(String title, String value) {
    return Container(
        margin: EdgeInsets.symmetric(vertical: 2.0),
        child: Row(children: [
          Expanded(
            child: Text(title,
                style: TextStyle(
                    fontSize: 14.0,
                    fontFamily: StyleView.FONT_TITLE,
                    color: Color(Constants.APP_COLOR),
                    fontWeight: FontWeight.bold)),
          ),
          Text("  : "),
          Expanded(
              flex: 2,
              child: Text(
                "$value",
                style: TextStyle(
                  fontSize: 13.0,
                  fontFamily: StyleView.FONT_TITLE,
                  color: Colors.black,
                ),
              )),
        ]));
  }

  Widget showRemainingInventoryQuantity(PriceModel? inventoryDropdownQuantity,
      int index, bool isUpdateInventory) {
    num inventoryTotalQuantity = 0;
    _selectedLocationQuantity = 0;
    if (inventoryDropdownQuantity != null) {
      if (isUpdateInventory) {
        for (int j = 0; j < inventoryList.length; j++) {
          for (int i = 0; i < inventoryList[j].locationBatchList!.length; i++) {
            if (inventoryDropdownQuantity.batchNumber ==
                inventoryList[j].locationBatchList![i].batchNumber) {
              inventoryTotalQuantity = inventoryTotalQuantity +
                  inventoryList[j].locationBatchList![i].quantity!;
            }
          }
        }
      } else {
        for (int j = 0; j < inventoryList.length; j++) {
          for (int i = 0; i < inventoryList[j].locationBatchList!.length; i++) {
            if (inventoryDropdownQuantity.batchNumber ==
                inventoryList[j].locationBatchList![i].batchNumber) {
              inventoryTotalQuantity = inventoryTotalQuantity +
                  inventoryList[j].locationBatchList![i].quantity!;
            }
          }
        }
      }

      remainingBatchQuantity =
          (double.parse(inventoryDropdownQuantity.quantity!) -
                  inventoryTotalQuantity)
              .toString();

      _locationQuantityController.text = remainingBatchQuantity!;
      _selectedLocationQuantity = double.parse(remainingBatchQuantity!);
      return Container(
          margin: EdgeInsets.only(top: 5.0),
          child: Row(
            children: [
              Container(
                child: Text(
                  Language().getString(
                      Constants.QUANTITY_NOT_ASSIGNED_TO_LOCATION,
                      selectedLang),
                  style: TextStyle(
                      fontSize: 12.0,
                      color: Color(Constants.APP_COLOR),
                      fontWeight: FontWeight.bold),
                ),
              ),
              Text(
                "  : ",
                style: TextStyle(
                  fontSize: 13.0,
                  color: Color(Constants.APP_COLOR),
                ),
              ),
              Container(
                child: Text(
                  "$remainingBatchQuantity",
                  style: TextStyle(
                    fontSize: 12.0,
                    color: Color(Constants.APP_COLOR),
                  ),
                ),
              ),
            ],
          ));
    } else {
      return Container();
    }
  }

  Widget showTotoalInventotyQuantity() {
    remainingBatchQuantity = inventoryQuantityDropdown!.quantity;
    return Container(
      child: Text(
          Language().getString(
                  Constants.BATCH_NO + " " + Constants.TOTAL_QUANTITY_STRING,
                  selectedLang) +
              " : " +
              inventoryQuantityDropdown!.quantity,
          style: TextStyle(fontSize: 10.0, color: Colors.deepOrange[300])),
    );
  }

  Widget addInventoryQuantityInPriceDetails(
      StateSetter setState, bool isUpdate) {
    String textMessage = "";
    if (isUpdate) {
      textMessage =
          "${Language().getString(Constants.QUANTITY_NOT_ASSIGNED_TO_LOCATION, selectedLang)} : $remainingCurrentBatchQuantity";
    } else {
      textMessage =
          "${Language().getString(Constants.QUANTITY_NOT_ASSIGNED_TO_LOCATION, selectedLang)} : ${_qntyController.text}";
    }
    return Container(
        margin: EdgeInsets.symmetric(
          vertical: 5.0,
          horizontal: 5.0,
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  margin: EdgeInsets.only(left: 5.0),
                  child: new Text(
                      Language().getString(
                          Constants.INVENTORY_LOCATION, selectedLang),
                      style: TextStyle(
                          fontSize: StyleView.FONT_SIZE_18,
                          fontWeight: FontWeight.bold,
                          color: Colors.black)),
                ),
                Container(
                  margin: EdgeInsets.only(left: 5.0, top: 10.0),
                  child: new Text(
                      Language().getString(textMessage, selectedLang),
                      style: TextStyle(
                          fontWeight: StyleView.fontSemiBold,
                          color: Colors.black)),
                ),
              ],
            ),
          ),
          SizedBox(height: 5.0),
          this.inventoryLocations(setState),
          SizedBox(height: 5.0),
          this.buildInventiryUnitPriceDropdown(setState, isUpdate)
        ]));
  }

  String validateAddInstantsInventotyFields(bool isUpdate) {
    if (double.parse(_locationQuantityController.text) >
        double.parse(_qntyController.text)) {
      return Constants.INVENTORY_QUANTITY_SHOULD_NOT_BE_MOREACTUAL_QUAN;
    } else {
      return "";
    }
  }

  onSaveInstantInventoryData(
      bool isUpdateBatchPrice, int batchPriceUpdateIndex) {
    if (locationDropdownValue != null &&
        _locationQuantityController.text.isNotEmpty &&
        _priceList.length > 0) {
      if (isUpdateBatchPrice) {
        if (inventoryList.length > 0) {
          int existLocationIndex = -1;
          bool isExistLocation = false;

          /**
         * Update Inventory Location Data
         */
          for (int index = 0; index < inventoryList.length; index++) {
            /**
             * Inventory Location Search
             */
            if (locationDropdownValue!.locationName ==
                inventoryList[index].locationName) {
              existLocationIndex = index;
              isExistLocation = true;
              // if (inventoryList[index].locationId == null ||
              //     inventoryList[index].locationId.isEmpty) {
              inventoryList[index].locationId =
                  locationDropdownValue!.locationId;
              // }
            }
          }

          if (isExistLocation) {
            int existBatchIndex = -1;
            bool isExistBatchLocation = false;
            for (int k = 0;
                k < inventoryList[existLocationIndex].locationBatchList!.length;
                k++) {
              /**
                     * Inventory Batch Number Search
                     */
              if (_priceList[batchPriceUpdateIndex].batchNumber ==
                  inventoryList[existLocationIndex]
                      .locationBatchList![k]
                      .batchNumber) {
                inventoryQuantityDropdown = _priceList[batchPriceUpdateIndex];
                existBatchIndex = existLocationIndex;
                isExistBatchLocation = true;
              }
            }

            /**
              * Updating Inventory Quantity If Location Exist
              */
            if (isExistBatchLocation) {
              this.onSaveInventoryDetails(isUpdateBatchPrice, existBatchIndex);
            } else {
              /**
             * Adding New Inventory If Location not Exist In Inventory
             */
              inventoryQuantityDropdown = _priceList[batchPriceUpdateIndex];

              List<InventoryDetailsDAO> locationBatchData = [];
              locationBatchData
                  .addAll(inventoryList[existLocationIndex].locationBatchList!);
              locationBatchData.add(InventoryDetailsDAO(
                  batchNumber: inventoryQuantityDropdown!.batchNumber,
                  quantityIn: inventoryQuntityInDropdown != null
                      ? inventoryQuntityInDropdown
                      : Constants.UNIT_PRICE[0],
                  quantity: double.parse(_locationQuantityController.text),
                  updatedUser: userName,
                  updatedDate: updatedCurrentDateTime));
              inventoryList[existLocationIndex] = InventoryManagementModel(
                  locationName: locationDropdownValue!.locationName,
                  locationId: locationDropdownValue!.locationId,
                  locationBatchList: locationBatchData);

              setState(() {
                inventoryList.reversed;
                Navigator.of(context).pop();
              });
            }
          } else {
            /**
               * Adding new inventory location
               */
            inventoryQuantityDropdown = _priceList[batchPriceUpdateIndex];
            List<InventoryDetailsDAO> locationBatchData = [];
            locationBatchData.add(InventoryDetailsDAO(
                batchNumber: inventoryQuantityDropdown!.batchNumber,
                quantityIn: inventoryQuntityInDropdown != null
                    ? inventoryQuntityInDropdown
                    : Constants.UNIT_PRICE[0],
                quantity: double.parse(_locationQuantityController.text),
                updatedUser: userName,
                updatedDate: updatedCurrentDateTime));
            inventoryList.add(InventoryManagementModel(
                locationName: locationDropdownValue!.locationName,
                locationId: locationDropdownValue!.locationId,
                locationBatchList: locationBatchData));

            setState(() {
              inventoryList.reversed;
              Navigator.of(context).pop();
            });
          }
        } else {
          /**
           * Adding New Inventory Location
           */
          inventoryQuantityDropdown = _priceList[batchPriceUpdateIndex];
          List<InventoryDetailsDAO> locationBatchData = [];
          locationBatchData.add(InventoryDetailsDAO(
              batchNumber: inventoryQuantityDropdown!.batchNumber,
              quantityIn: inventoryQuntityInDropdown != null
                  ? inventoryQuntityInDropdown
                  : Constants.UNIT_PRICE[0],
              quantity: double.parse(_locationQuantityController.text),
              updatedUser: userName,
              updatedDate: updatedCurrentDateTime));
          inventoryList.add(InventoryManagementModel(
              locationName: locationDropdownValue!.locationName,
              locationId: locationDropdownValue!.locationId,
              locationBatchList: locationBatchData));

          setState(() {
            inventoryList.reversed;
            Navigator.of(context).pop();
          });
        }
      } else {
        inventoryQuantityDropdown = _priceList.last;
        bool isExist = false;
        int index = -1;
        for (int i = 0; i < inventoryList.length; i++) {
          /**
           * Location Name validation in Inventory List
           */
          if (locationDropdownValue!.locationName ==
              inventoryList[i].locationName) {
            isExist = true;
            index = i;

            // if (inventoryList[i].locationId == null ||
            //     inventoryList[i].locationId.isEmpty) {
            inventoryList[i].locationId = locationDropdownValue!.locationId;
            // }
          }
        }
        /**
         * If Location Exist in Inventory List
         */
        if (isExist) {
          bool isBatchExist = false;
          int existIndex = -1;

          for (int j = 0;
              j < inventoryList[index].locationBatchList!.length;
              j++) {
            /**
                 * Batch Number Validation in Inventory List
                 */
            if (inventoryQuantityDropdown!.batchNumber ==
                inventoryList[index].locationBatchList![j].batchNumber) {
              isBatchExist = true;
              existIndex = j;
            }
          }

          /**
           * If Batch Number Exist in Inventory Location Batch
           */
          if (isBatchExist) {
            inventoryList[index].locationBatchList![existIndex].updatedDate =
                updatedCurrentDateTime;
            inventoryList[index].locationBatchList![existIndex].updatedUser =
                userName;
            inventoryList[index].locationBatchList![existIndex].quantity =
                inventoryList[index].locationBatchList![existIndex].quantity! +
                    double.parse(_locationQuantityController.text);

            inventoryList[index].locationBatchList![existIndex].quantityIn =
                inventoryQuntityInDropdown != null
                    ? inventoryQuntityInDropdown
                    : Constants.UNIT_PRICE[0];
          } else {
            /**
             * Adding New Batch Number in Inventory Locations
             */
            List<InventoryDetailsDAO> locationBatchData = [];
            locationBatchData.addAll(inventoryList[index].locationBatchList!);
            locationBatchData.add(InventoryDetailsDAO(
                batchNumber: inventoryQuantityDropdown!.batchNumber,
                quantityIn: inventoryQuntityInDropdown != null
                    ? inventoryQuntityInDropdown
                    : Constants.UNIT_PRICE[0],
                quantity: double.parse(_locationQuantityController.text),
                updatedUser: userName,
                updatedDate: updatedCurrentDateTime));
            inventoryList[index] = InventoryManagementModel(
                locationName: locationDropdownValue!.locationName,
                locationId: locationDropdownValue!.locationId,
                locationBatchList: locationBatchData);
          }
        } else {
          /**
           * Adding New Inventory Location
           */
          List<InventoryDetailsDAO> locationBatchData = [];
          locationBatchData.add(InventoryDetailsDAO(
              batchNumber: inventoryQuantityDropdown!.batchNumber,
              quantityIn: inventoryQuntityInDropdown != null
                  ? inventoryQuntityInDropdown
                  : Constants.UNIT_PRICE[0],
              quantity: double.parse(_locationQuantityController.text),
              updatedUser: userName,
              updatedDate: updatedCurrentDateTime));
          inventoryList.add(InventoryManagementModel(
              locationName: locationDropdownValue!.locationName,
              locationId: locationDropdownValue!.locationId,
              locationBatchList: locationBatchData));
        }

        setState(() {
          inventoryList.reversed;
          Navigator.of(context).pop();
        });
      }
    } else {
      Navigator.of(context).pop();
    }
  }

  addNewQuantityAdjustment() {
    return SizedBox(
        height: 25.0,
        width: 25.0,
        child: FloatingActionButton(
          heroTag: "quantity_adjustment",
          onPressed: () {
            if (inventoryList.length > 0) {
              CommonMethods.hideKeyboard(context);
              buildQuantityAdjustmentFields(-1, false, QuantityAdjustmentDAO());
            } else {
              Dialogs.yesCancelDialog(
                  context,
                  Language().getString(Constants.ERROR, selectedLang),
                  Language().getString(
                      Constants.YOU_HAVE_NO_INVENTORY_LOC, selectedLang),
                  Language().getString(Constants.OKAY_STR, selectedLang),
                  "",
                  false);
            }
          },
          child: Icon(
            Icons.add,
            size: 15,
          ),
          backgroundColor: Color(0xFF083e64),
        ));
  }

  buildQuantityAdjustmentFields(
      int index, bool isUpdate, QuantityAdjustmentDAO quantityModel) {
    if (isUpdate) {
      quantityAdjustmentBatchDropdown = null;
      quantityAdjustmentLocationDropdown = null;
      _locationBatchesInQuantityAdjustment.clear();
      quantityForUpdate = quantityModel.quantity;
      for (int i = 0; i < inventoryList.length; i++) {
        for (int k = 0; k < inventoryList[i].locationBatchList!.length; k++) {
          if (quantityModel.batchNumber ==
              inventoryList[i].locationBatchList![k].batchNumber) {
            _locationBatchesInQuantityAdjustment
                .addAll(inventoryList[i].locationBatchList!);
            quantityAdjustmentBatchDropdown =
                inventoryList[i].locationBatchList![k];
            remainingAdjustmentQuantity =
                inventoryList[i].locationBatchList![k].quantity;
          }
        }
      }

      for (int j = 0; j < inventoryList.length; j++) {
        // for (var q = 0; q < inventoryList[j].locationBatchList.length; q++) {
        if (quantityModel.locationName == inventoryList[j].locationName) {
          quantityAdjustmentLocationDropdown = inventoryList[j];
        }
        // }
      }
      adjustmentReasonDropdownValue = quantityModel.reason;
      updatedCurrentDateTime = quantityModel.updatedDate;
      // _locationQuantityController.text = quantityModel.quantity.toString();
    } else {
      this.clearQuantityAdjustData();
    }

    return showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => Container(
            decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(10.0)),
                color: Colors.white),
            margin: EdgeInsets.symmetric(horizontal: 10.0, vertical: 20.0),
            child: StatefulBuilder(
                builder: (context, StateSetter setState) => Scaffold(
                    backgroundColor: Colors.transparent,
                    bottomNavigationBar: Container(
                      margin: EdgeInsets.symmetric(
                        horizontal: 5.0,
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Container(
                              margin: EdgeInsets.only(right: 1.0),
                              child: ElevatedButton(
                                onPressed: () {
                                  this.clearQuantityAdjustData();
                                  Navigator.of(context).pop();
                                },
                                style: ElevatedButton.styleFrom(
                                    backgroundColor:
                                        Color(Constants.APP_COLOR)),
                                child: Text(
                                    Language().getString(
                                        Constants.STR_CANCEL, selectedLang),
                                    style: TextStyle(color: Colors.white)),
                              ),
                            ),
                          ),
                          Expanded(
                            child: Container(
                              margin: EdgeInsets.only(left: 1.0),
                              child: ElevatedButton(
                                onPressed: () async {
                                  String errorMessage =
                                      validateAdjustmentFields();

                                  if (errorMessage.isNotEmpty) {
                                    Dialogs.yesCancelDialog(
                                        context,
                                        Language().getString(
                                            Constants.ERROR, selectedLang),
                                        Language().getString(
                                            errorMessage, selectedLang),
                                        Language().getString(
                                            Constants.OKAY_STR, selectedLang),
                                        "",
                                        false);
                                  } else {
                                    final action =
                                        await Dialogs.yesCancelDialog(
                                            context,
                                            Language().getString(
                                                Constants.INFO, selectedLang),

                                            // "Are you sure, Do you want add entered quantity to \"${quantityAdjustmentLocationDropdown!.locationName}\"",
                                            Language().getString(
                                                Constants
                                                        .DO_YOU_WANT_TO_ADD_ENTERED_QUANTITY +
                                                    "\"${quantityAdjustmentLocationDropdown!.locationName}\"",
                                                selectedLang),
                                            Language().getString(
                                                Constants.YES_STRING,
                                                selectedLang),
                                            Language().getString(
                                                Constants.NO_STRING,
                                                selectedLang),
                                            true);

                                    if (action == DialogAction.yes) {
                                      this.saveQuantityAdjustmentValues(
                                          isUpdate, index, setState);
                                    }
                                  }
                                },
                                style: ElevatedButton.styleFrom(
                                    backgroundColor:
                                        Color(Constants.APP_COLOR)),
                                child: Text(
                                    (isUpdate)
                                        ? Language().getString(
                                            Constants.UPDATE_STRING,
                                            selectedLang)
                                        : Language().getString(
                                            Constants.ADD, selectedLang),
                                    style: TextStyle(color: Colors.white)),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                    body: SingleChildScrollView(
                      child: Container(
                        margin: EdgeInsets.symmetric(
                            vertical: 10.0, horizontal: 10.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            new Text(
                                Language().getString(
                                    Constants.QUANTITY_ADJUSTMENT,
                                    selectedLang),
                                style: TextStyle(
                                    fontSize: StyleView.FONT_SIZE_15,
                                    fontWeight: FontWeight.bold,
                                    color: Color(Constants.APP_COLOR))),
                            SizedBox(height: 5.0),
                            new Text(
                                Language().getString(
                                    Constants.LOCATION, selectedLang),
                                style: TextStyle(
                                    fontSize: StyleView.FONT_SIZE_15,
                                    fontWeight: FontWeight.bold,
                                    color: Color(Constants.APP_COLOR))),
                            SizedBox(height: 5.0),
                            (isUpdate)
                                ? Container(
                                    decoration: AppUtills.boxDecoration(),
                                    child: TextView(
                                        title: Language().getString(
                                            Constants.LOCATION_NAME,
                                            selectedLang),
                                        value: quantityModel.locationName),
                                  )
                                : this.inventoryLocationsInQuantityAdjustment(
                                    setState), //this.inventoryLocations(setState),

                            if (quantityAdjustmentLocationDropdown != null)
                              Container(
                                margin: EdgeInsets.symmetric(vertical: 5.0),
                                child: this
                                    .showQuantityAdjustmentLocationBatchNumbers(
                                        quantityModel.locationName),
                              ),

                            Container(
                                child: Row(
                              children: <Widget>[
                                new Text(
                                    Language().getString(
                                        Constants.BATCH_NO, selectedLang),
                                    style: TextStyle(
                                        fontSize: StyleView.FONT_SIZE_15,
                                        fontWeight: FontWeight.bold,
                                        color: Color(Constants.APP_COLOR))),
                                SizedBox(
                                  width: 3.0,
                                ),
                                // (quantityAdjustmentBatchDropdown != null)
                                //     ? Container(
                                //         child: Text(
                                //             Language().getString(
                                //                     Constants
                                //                         .TOTAL_QUANTITY_STRING,
                                //                     selectedLang) +
                                //                 " : $remainingAdjustmentQuantity",
                                //             style: TextStyle(
                                //                 fontSize: 10.0,
                                //                 color: Colors.deepOrange[300])),
                                //       )
                                //     : Container()
                              ],
                            )),

                            this.showLocationBatchesInQuantityAdjustment(
                                setState),
                            // this.inventoryBatchQuantity(setState,
                            //     isFromQuantityAdjustment: true),
                            if (quantityAdjustmentBatchDropdown != null)
                              Container(
                                  margin: EdgeInsets.only(top: 5.0),
                                  child: Row(
                                    children: [
                                      Container(
                                        child: Text(
                                          Language().getString(
                                              Constants
                                                  .TOTAL_AVAILABLE_QUAN_FOR_BATCH,
                                              selectedLang),
                                          style: TextStyle(
                                              fontSize: 12.0,
                                              color: Color(Constants.APP_COLOR),
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ),
                                      Text("  : ",
                                          style: TextStyle(
                                              fontSize: 13.0,
                                              color: Color(Constants.APP_COLOR),
                                              fontWeight: FontWeight.w600)),
                                      Container(
                                        child: Text(
                                          "${quantityAdjustmentBatchDropdown!.quantity} ${quantityAdjustmentBatchDropdown!.quantityIn}",
                                          style: TextStyle(
                                            fontSize: 12.0,
                                            color: Color(Constants.APP_COLOR),
                                          ),
                                        ),
                                      ),
                                    ],
                                  )),
                            (quantityAdjustmentBatchDropdown != null)
                                ? this.showRemainingInventoryAdjustQuantity(
                                    quantityModel, index, isUpdate)
                                : Container(),
                            if (quantityAdjustmentBatchDropdown != null)
                              this.showQuantityAdjustmentBatchPricingDetails(
                                  quantityModel, index, isUpdate),

                            new Text(
                                Language()
                                    .getString(Constants.REASON, selectedLang),
                                style: TextStyle(
                                    fontSize: StyleView.FONT_SIZE_15,
                                    fontWeight: FontWeight.bold,
                                    color: Color(Constants.APP_COLOR))),
                            SizedBox(height: 5.0),
                            this.adjustmentQuantityReasonDropdown(setState),
                            new Text(
                                Language().getString(
                                    Constants.QUANTITY, selectedLang),
                                style: TextStyle(
                                    fontSize: StyleView.FONT_SIZE_15,
                                    fontWeight: FontWeight.bold,
                                    color: Color(Constants.APP_COLOR))),
                            SizedBox(height: 5.0),
                            SizedBox(
                                height: 70,
                                child: new TextFormField(
                                  keyboardType: TextInputType.number,
                                  style: TextStyle(
                                      fontFamily: StyleView.FONT_TITLE),
                                  controller: _quantityAdjutmentController,
                                  decoration: StyleView.getInputDecoration(
                                      helper: Language().getString(
                                          Constants.ENTER_QUANTITY,
                                          selectedLang)),
                                  inputFormatters: [
                                    new LengthLimitingTextInputFormatter(6),
                                    CommonMethods.inputTextFormatter(
                                        isNumber: true)
                                  ],
                                  onChanged: (value) async {
                                    if (value.isNotEmpty) {
                                      if (isUpdate &&
                                          double.parse(
                                                  remainingBatchQuantity!) !=
                                              0) {
                                        if (double.parse(remainingBatchQuantity
                                                .toString()) <
                                            double.parse(
                                                _quantityAdjutmentController
                                                    .text)) {
                                          final action =
                                              await Dialogs.yesCancelDialog(
                                                  context,
                                                  Language().getString(
                                                      Constants.WARNING,
                                                      selectedLang),
                                                  Language().getString(
                                                      Constants
                                                          .QUANTITY_SHOULD_NOT_MORETHAN_AVAIL_,
                                                      selectedLang),
                                                  Language().getString(
                                                      Constants.OKAY_STR,
                                                      selectedLang),
                                                  "",
                                                  false);
                                          if (action == DialogAction.yes) {
                                            _quantityAdjutmentController.text =
                                                "$remainingBatchQuantity";
                                          }
                                        }
                                      } else {
                                        if (double.parse(
                                                _quantityAdjutmentController
                                                    .text) >
                                            quantityAdjustmentBatchDropdown!
                                                .quantity!) {
                                          final action =
                                              await Dialogs.yesCancelDialog(
                                                  context,
                                                  Language().getString(
                                                      Constants.WARNING,
                                                      selectedLang),
                                                  Language().getString(
                                                      Constants
                                                          .QUANTITY_SHOULD_NOT_MORETHAN_AVAIL_,
                                                      selectedLang),
                                                  Language().getString(
                                                      Constants.OKAY_STR,
                                                      selectedLang),
                                                  "",
                                                  false);
                                          if (action == DialogAction.yes) {
                                            _quantityAdjutmentController.text =
                                                "${quantityAdjustmentBatchDropdown!.quantity}";
                                          }
                                        }
                                      }
                                    }
                                  },
                                )),
                          ],
                        ),
                      ),
                    )))));
  }

  Widget adjustmentQuantityReasonDropdown(StateSetter setState) {
    return Container(
      margin: EdgeInsets.symmetric(
        vertical: 5.0,
      ),
      decoration: AppUtills.boxDecoration(),
      padding: EdgeInsets.all(1),
      child: Container(
        color: Colors.white70,
        padding: EdgeInsets.only(left: 5, right: 5),
        child: DropdownButton<String>(
          onTap: () {
            FocusScope.of(context).requestFocus(
                new FocusNode()); //CommonMethods.hideKeyboard(context);
          },
          isExpanded: true,
          hint: Text(Language().getString(Constants.REASON, selectedLang)),
          underline: SizedBox(),
          items: Constants.adjustmentReasonList.map((String reason) {
            return DropdownMenuItem<String>(
              value: reason,
              child: new Text(
                reason,
                style: TextStyle(fontFamily: StyleView.FONT_TITLE),
              ),
            );
          }).toList(),
          value: adjustmentReasonDropdownValue,
          onChanged: (String? model) {
            setState(() {
              adjustmentReasonDropdownValue = model;
            });
          },
        ),
      ),
    );
  }

  saveQuantityAdjustmentValues(bool isUpdate, int index, StateSetter setter) {
    if (isUpdate) {
      /**
       * If requested quantity is more than exist quantity
       */
      num enteredQuantity = double.parse(_quantityAdjutmentController.text);

      bool isLocationExist = false;

      if (quantityAdjustmentLocationDropdown!.locationName ==
          quantityAdjustmentList[index].locationName) {
        isLocationExist = true;
      }

      if (isLocationExist) {
        bool isBatchExist = false;
        int existIndex = -1;
        for (var i = 0;
            i <
                quantityAdjustmentList[index]
                    .quantityAdjustLocationsList!
                    .length;
            i++) {
          if (quantityAdjustmentBatchDropdown!.batchNumber ==
              quantityAdjustmentList[index]
                  .quantityAdjustLocationsList![i]
                  .batchNumber) {
            isBatchExist = true;
            existIndex = i;
          }
        }

        if (isBatchExist) {
          num? existBatchQuantity = 0;
          existBatchQuantity = quantityAdjustmentList[index]
              .quantityAdjustLocationsList![existIndex]
              .quantity;

          quantityAdjustmentList[index]
              .quantityAdjustLocationsList![existIndex]
              .quantity = existBatchQuantity! + enteredQuantity;
          this.validatingSelectedBatchQuantity(setState);
          setter(() {
            quantityAdjustmentList.reversed;
            Navigator.of(context).pop();
          });
        } else {
          List<InventoryDetailsDAO> _addNewBatch =
              quantityAdjustmentList[index].quantityAdjustLocationsList!;

          _addNewBatch.add(InventoryDetailsDAO(
              batchNumber: quantityAdjustmentBatchDropdown!.batchNumber,
              quantity: enteredQuantity,
              quantityIn: "Unit",
              quantityAdjustmentReason: adjustmentReasonDropdownValue != null
                  ? adjustmentReasonDropdownValue
                  : ""));

          quantityAdjustmentList[index] = QuantityAdjustmentDAO(
              locationName: quantityAdjustmentLocationDropdown!.locationName,
              batchNumber: quantityAdjustmentBatchDropdown!.batchNumber,
              reason: adjustmentReasonDropdownValue != null
                  ? adjustmentReasonDropdownValue
                  : "",
              updatedBy: userName,
              updatedDate: updatedCurrentDateTime,
              quantity: enteredQuantity,
              quantityAdjustLocationsList: _addNewBatch);
          this.validatingSelectedBatchQuantity(setState);
          setter(() {
            quantityAdjustmentList.reversed;
            Navigator.of(context).pop();
          });
        }
      } else {
        List<InventoryDetailsDAO> _addNewBatch = [];

        _addNewBatch.add(InventoryDetailsDAO(
            batchNumber: quantityAdjustmentBatchDropdown!.batchNumber,
            quantity: enteredQuantity,
            quantityIn: "Unit",
            quantityAdjustmentReason: adjustmentReasonDropdownValue != null
                ? adjustmentReasonDropdownValue
                : ""));

        quantityAdjustmentList[index] = QuantityAdjustmentDAO(
            locationName: quantityAdjustmentLocationDropdown!.locationName,
            batchNumber: quantityAdjustmentBatchDropdown!.batchNumber,
            reason: adjustmentReasonDropdownValue != null
                ? adjustmentReasonDropdownValue
                : "",
            updatedBy: userName,
            updatedDate: updatedCurrentDateTime,
            quantity: enteredQuantity + quantityAdjustmentList[index].quantity!,
            quantityAdjustLocationsList: _addNewBatch);
        this.validatingSelectedBatchQuantity(setState);
        setter(() {
          quantityAdjustmentList.reversed;
          Navigator.of(context).pop();
        });
      }
    } else {
      // this.validatingSelectedBatchQuantity(setState);
      num enteredQuantity = double.parse(_quantityAdjutmentController.text);
      bool isLocationExist = false;
      int existIndex = -1;

      for (int i = 0; i < quantityAdjustmentList.length; i++) {
        for (int j = 0;
            j < quantityAdjustmentList[i].quantityAdjustLocationsList!.length;
            j++) {
          if (quantityAdjustmentLocationDropdown!.locationName ==
              quantityAdjustmentList[i].locationName) {
            isLocationExist = true;
            existIndex = i;
          }
        }
      }

      if (isLocationExist) {
        bool isBatchExist = false;
        int index = -1;
        for (var i = 0;
            i <
                quantityAdjustmentList[existIndex]
                    .quantityAdjustLocationsList!
                    .length;
            i++) {
          if (quantityAdjustmentBatchDropdown!.batchNumber ==
              quantityAdjustmentList[existIndex]
                  .quantityAdjustLocationsList![i]
                  .batchNumber) {
            isBatchExist = true;
            index = i;
          }
        }

        if (isBatchExist) {
          num? existBatchQuantity = 0;
          existBatchQuantity = quantityAdjustmentList[existIndex]
              .quantityAdjustLocationsList![index]
              .quantity;

          quantityAdjustmentList[existIndex]
              .quantityAdjustLocationsList![index]
              .quantity = existBatchQuantity! + enteredQuantity;
          this.validatingSelectedBatchQuantity(setState);
          setter(() {
            quantityAdjustmentList.reversed;
            Navigator.of(context).pop();
          });
        } else {
          List<InventoryDetailsDAO> _addNewBatch =
              quantityAdjustmentList[existIndex].quantityAdjustLocationsList!;

          _addNewBatch.add(InventoryDetailsDAO(
              batchNumber: quantityAdjustmentBatchDropdown!.batchNumber,
              quantity: enteredQuantity,
              quantityIn: "Unit",
              quantityAdjustmentReason: adjustmentReasonDropdownValue != null
                  ? adjustmentReasonDropdownValue
                  : ""));

          quantityAdjustmentList[existIndex] = QuantityAdjustmentDAO(
              locationName: quantityAdjustmentLocationDropdown!.locationName,
              batchNumber: quantityAdjustmentBatchDropdown!.batchNumber,
              reason: adjustmentReasonDropdownValue != null
                  ? adjustmentReasonDropdownValue
                  : "",
              updatedBy: userName,
              updatedDate: updatedCurrentDateTime,
              quantity: enteredQuantity,
              quantityAdjustLocationsList: _addNewBatch);
          this.validatingSelectedBatchQuantity(setState);
          setter(() {
            quantityAdjustmentList.reversed;
            Navigator.of(context).pop();
          });
        }
      } else {
        List<InventoryDetailsDAO> _addNewBatch = [];

        _addNewBatch.add(InventoryDetailsDAO(
            batchNumber: quantityAdjustmentBatchDropdown!.batchNumber,
            quantity: double.parse(_quantityAdjutmentController.text),
            quantityIn: "Unit",
            quantityAdjustmentReason: adjustmentReasonDropdownValue != null
                ? adjustmentReasonDropdownValue
                : ""));
        quantityAdjustmentList.add(
          QuantityAdjustmentDAO(
              locationName: quantityAdjustmentLocationDropdown!.locationName,
              batchNumber: quantityAdjustmentBatchDropdown!.batchNumber,
              reason: adjustmentReasonDropdownValue != null
                  ? adjustmentReasonDropdownValue
                  : "",
              updatedBy: userName,
              updatedDate: updatedCurrentDateTime,
              quantity: double.parse(_quantityAdjutmentController.text),
              quantityAdjustLocationsList: _addNewBatch),
        );
        this.validatingSelectedBatchQuantity(setState);
        setter(() {
          quantityAdjustmentList.reversed;
          Navigator.of(context).pop();
        });
      }
    }
  }

  String validateAdjustmentFields() {
    if (quantityAdjustmentLocationDropdown == null) {
      return Constants.PLEASE_SELECT_LOCATION;
    } else if (quantityAdjustmentBatchDropdown == null) {
      return Constants.PLEASE_SELECT_BATCH_NO;
    } else if (_quantityAdjutmentController.text.isEmpty) {
      return Constants.PLEASE_ENTER_QUANTITY;
    } else {
      return "";
    }
  }

  Widget onCreateDynamicQuantityAdjustment() {
    return Column(children: <Widget>[
      for (int i = 0; i < quantityAdjustmentList.length; i++)
        Container(
          margin: EdgeInsets.symmetric(
            vertical: 5.0,
          ),
          child: Column(children: <Widget>[
            InventoryExpandedPage(
              forQuantityAdjustment: true,
              quantityAdjustmentDAOModel: quantityAdjustmentList[i],
              quantityAdjustmentList:
                  quantityAdjustmentList[i].quantityAdjustLocationsList,
              editPage: () async {
                buildQuantityAdjustmentFields(
                    i, true, quantityAdjustmentList[i]);
              },
              removeItem: () async {
                final action = await Dialogs.removeItem(
                  context,
                  quantityAdjustmentList[i].locationName,
                  Language().getString(Constants.WARNING, selectedLang),
                  Language().getString(Constants.WARNING_TEXT, selectedLang),
                  cancel:
                      Language().getString(Constants.STR_CANCEL, selectedLang),
                  yes: Language().getString(Constants.YES_STRING, selectedLang),
                );
                if (action == DialogAction.yes) {
                  bool isLocationExist = false;
                  int index = -1;
                  for (int j = 0; j < inventoryList.length; j++) {
                    if (quantityAdjustmentList[i].locationName ==
                        inventoryList[j].locationName) {
                      isLocationExist = true;
                      index = j;
                    }
                  }

                  if (isLocationExist) {
                    for (int r = 0;
                        r <
                            quantityAdjustmentList[i]
                                .quantityAdjustLocationsList!
                                .length;
                        r++) {
                      bool isBatchExist = false;
                      int batchIndex = -1;

                      for (int k = 0;
                          k < inventoryList[index].locationBatchList!.length;
                          k++) {
                        if (quantityAdjustmentList[i]
                                .quantityAdjustLocationsList![r]
                                .batchNumber ==
                            inventoryList[index]
                                .locationBatchList![k]
                                .batchNumber) {
                          isBatchExist = true;
                          batchIndex = k;
                        }
                      }

                      if (isBatchExist) {
                        setState(() {
                          inventoryList[index]
                              .locationBatchList![batchIndex]
                              .quantity = inventoryList[index]
                                  .locationBatchList![batchIndex]
                                  .quantity! +
                              quantityAdjustmentList[i]
                                  .quantityAdjustLocationsList![r]
                                  .quantity!;
                        });
                      }
                    }

                    setState(() {
                      quantityAdjustmentList.removeAt(i);
                    });
                  }
                }
              },
              strBatchNumber:
                  Language().getString(Constants.BATCH_NO, selectedLang),
              strLocation:
                  Language().getString(Constants.LOCATION, selectedLang),
              strTotalAtLocation: Language()
                  .getString(Constants.TOTAL_AT_LOCATION, selectedLang),
            ),
          ]),
        ),
    ]);
  }

  clearQuantityAdjustData() {
    setState(() {
      // locationDropdownValue = null;
      // inventoryQuantityDropdown = null;
      adjustmentReasonDropdownValue = null;
      _quantityAdjutmentController.clear();
      remainingAdjustmentQuantity = 0;
      quantityAdjustmentBatchDropdown = null;
      quantityAdjustmentLocationDropdown = null;
      _locationBatchesInQuantityAdjustment.clear();
    });
  }

  buildMobileNumberTextFormField(
      String textName, TextEditingController _controller) {
    return Container(
        // padding: EdgeInsets.all(1),
        child: Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(Language().getString(textName, selectedLang),
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_15,
                            fontFamily: Constants.INDIAN_RUPEE))),
              )),
        ),
        Expanded(
            flex: 2,
            child: Row(
              children: [
                Expanded(
                  flex: 2,
                  child: Container(
                      color: Colors.white70,
                      padding: EdgeInsets.only(left: 5),
                      child: TextFormField(
                          controller: _dialCodeController,
                          inputFormatters: [
                            new LengthLimitingTextInputFormatter(6),
                            CommonMethods.inputTextFormatter(isNumber: true)
                          ],
                          keyboardType: (defaultTargetPlatform ==
                                  TargetPlatform.iOS)
                              ? TextInputType.numberWithOptions(signed: true)
                              : TextInputType.number,
                          textInputAction: TextInputAction.next,
                          onChanged: (value) {
                            _dialCodeController.text =
                                "+" + _dialCodeController.text;
                            _dialCodeController.selection =
                                TextSelection.fromPosition(TextPosition(
                                    offset: _dialCodeController.text.length));
                          },
                          decoration: InputDecoration(
                              border: InputBorder.none,
                              hintText: Language()
                                  .getString(Constants.CODE, selectedLang),
                              hintStyle: TextStyle(
                                  fontSize: 11.0, color: Colors.black)))),
                ),
                Expanded(
                  flex: 3,
                  child: Container(
                    color: Colors.white70,
                    child: TextFormField(
                      controller: _controller,
                      keyboardType:
                          (defaultTargetPlatform == TargetPlatform.iOS)
                              ? TextInputType.numberWithOptions(signed: true)
                              : TextInputType.number,
                      textInputAction: TextInputAction.done,
                      // focusNode: FocusNode(canRequestFocus: false),
                      style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                      decoration: InputDecoration(
                        hintText: Language().getString(textName, selectedLang),
                        border: InputBorder.none,
                      ),
                      inputFormatters: [
                        new LengthLimitingTextInputFormatter(10),
                        CommonMethods.inputTextFormatter(isNumber: true)
                      ],
                    ),
                  ),
                ),
              ],
            ))
      ],
    ));
  }

  showRawIssueNotesList(int index) {
    return Container(
        margin: EdgeInsets.only(bottom: 5.0),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(5.0),
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                  offset: Offset(0.0, 1.0), blurRadius: 2.5, color: Colors.grey)
            ]),
        child: Padding(
          padding: const EdgeInsets.all(5.0),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                      child: Text(
                    Language().getString(Constants.ISSUANCE_ID, selectedLang),
                    style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                        fontSize: 15.0,
                        fontWeight: FontWeight.w500),
                  )),
                  Expanded(
                      flex: 2,
                      child: Row(children: [
                        Container(child: Text(": ")),
                        Expanded(
                            child: Container(
                          child: Text(
                            "${_rawIssuesList[index].issueNumber}",
                            textAlign: TextAlign.start,
                            style: TextStyle(
                              fontSize: 13.0,
                            ),
                          ),
                        ))
                      ]))
                ],
              ),
              Row(
                children: [
                  Expanded(
                      child: Text(
                    Language().getString(Constants.ISSUED_TO, selectedLang),
                    style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                        fontSize: 15.0,
                        fontWeight: FontWeight.w500),
                  )),
                  Expanded(
                      flex: 2,
                      child: Row(
                        children: [
                          Container(child: Text(": ")),
                          Expanded(
                            child: Container(
                              child: Text(
                                "${_rawIssuesList[index].issuedTo!.userName}",
                                style: TextStyle(
                                  fontSize: 13.0,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ))
                ],
              ),
              Row(
                children: [
                  Expanded(
                      child: Text(
                    Language().getString(Constants.ISSUED_DATE, selectedLang),
                    style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                        fontSize: 15.0,
                        fontWeight: FontWeight.w500),
                  )),
                  Expanded(
                      flex: 2,
                      child: Row(
                        children: [
                          Container(child: Text(": ")),
                          Expanded(
                            child: Container(
                              child: Text(
                                AppUtills.getDateFormate(_rawIssuesList[index]
                                    .createdDate
                                    .toString()),
                                style: TextStyle(
                                  fontSize: 13.0,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ))
                ],
              ),
              Row(
                children: [
                  Expanded(
                      child: Text(
                    Language().getString(Constants.PURPOSE, selectedLang),
                    style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                        fontSize: 15.0,
                        fontWeight: FontWeight.w500),
                  )),
                  Expanded(
                      flex: 2,
                      child: Row(
                        children: [
                          Container(child: Text(": ")),
                          Expanded(
                            child: Container(
                              child: Text(
                                _rawIssuesList[index].issuedPurpose!,
                                style: TextStyle(
                                  fontSize: 13.0,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ))
                ],
              )
            ],
          ),
        ));
  }

  buildInventiryUnitPriceDropdown(StateSetter setState, bool isForUpdate) {
    return Container(
      decoration: AppUtills.boxDecoration(customContainerColor: Colors.white),
      child: Row(
        children: <Widget>[
          Expanded(
            flex: 2,
            child: Padding(
              padding: const EdgeInsets.all(5.0),
              child: TextFormField(
                keyboardType: (defaultTargetPlatform == TargetPlatform.iOS)
                    ? TextInputType.numberWithOptions(signed: true)
                    : TextInputType.number,
                style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                controller: _locationQuantityController,
                textInputAction: TextInputAction.done,
                decoration: InputDecoration(
                  hintText: Language()
                      .getString(Constants.QUANTITY_AT_LOCATION, selectedLang),
                  border: InputBorder.none,
                ),
                inputFormatters: [
                  new LengthLimitingTextInputFormatter(6),
                  CommonMethods.inputTextFormatter(isDouble: true)
                ],
                onChanged: (value) {
                  if (value.isNotEmpty && isForUpdate) {
                    if (double.parse(remainingCurrentBatchQuantity.toString()) <
                        double.parse(_locationQuantityController.text)) {
                      _locationQuantityController.clear();
                      Dialogs.yesCancelDialog(
                          context,
                          Language().getString(Constants.WARNING, selectedLang),
                          Language().getString(
                              Constants.QUANTITY_SHOULD_NOT_MORETHAN_AVAIL_,
                              selectedLang),
                          Language()
                              .getString(Constants.OKAY_STR, selectedLang),
                          "",
                          false);
                    }
                  }
                },
              ),
            ),
          ),
          Expanded(
              child: Container(
                  padding: EdgeInsets.only(left: 5),
                  child: DropdownButton<String>(
                      onTap: () {
                        FocusScope.of(context).requestFocus(
                            new FocusNode()); //CommonMethods.hideKeyboard(context);
                      },
                      value: inventoryQuntityInDropdown,
                      hint: new Text(
                        Language().getString(Constants.SELECT, selectedLang),
                      ),
                      isExpanded: true,
                      underline: SizedBox(),
                      onChanged: (String? data) {
                        setState(() {
                          inventoryQuntityInDropdown = data;
                        });
                      },
                      items: Constants.UNIT_PRICE.map((String model) {
                        return new DropdownMenuItem<String>(
                          child: new Text(model),
                          value: model,
                        );
                      }).toList()))),
        ],
      ),
    );
  }

  String validateOfferFields() {
    if (_offerNameController.text.isEmpty) {
      return Constants.PLEASE_ENTER_VALID_OFFER_NAME;
    } else if (offerRadioValue == Constants.OFFER_IN_AMOUNT &&
        _offerQtyController.text.isEmpty) {
      return Constants.PLEASE_ENTER_OFFER_VALUE;
    } else if (offerRadioValue == Constants.OFFER_IN_PERCENTAGE &&
        offerInPercentage == null) {
      return Constants.PLEASE_SELECT_OFFER_PERCENTAGE;
    } else {
      return "";
    }
  }

  buildPriceBatchNumberTextField(bool isUpdate) {
    return Container(
        // padding: EdgeInsets.all(1),
        child: Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: RichText(
                      text: TextSpan(children: [
                        TextSpan(
                          text: Language()
                              .getString(Constants.BATCH_NO, selectedLang),
                          style: TextStyle(
                              fontSize: StyleView.FONT_SIZE_15,
                              fontFamily: StyleView.FONT_TITLE,
                              color: Colors.black),
                        ),
                        TextSpan(
                            text: "\*",
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                color: Colors.red))
                      ]),
                    )),
              )),
        ),
        Expanded(
          flex: 2,
          child: Container(
            color: Colors.white,
            padding: EdgeInsets.only(left: 5),
            child: TextField(
              enabled: ((rawIssuedListDropDown != null &&
                          rawIssuedListDropDown!
                              .issueBatchNumber!.isNotEmpty) ||
                      isUpdate)
                  ? false
                  : true,
              controller: _batchNumController,
              textInputAction: TextInputAction.next,
              style: TextStyle(
                fontFamily: Constants.INDIAN_RUPEE,
              ),
              decoration: InputDecoration(
                border: InputBorder.none,
                hintText:
                    Language().getString(Constants.BATCH_NO, selectedLang),
              ),
            ),
          ),
        )
      ],
    ));
  }

  bool remainigQuantityValidation(bool isUpdate) {
    if (isUpdate) {
      num x = double.parse(remainingBatchQuantity!) + _selectedLocationQuantity;
      if (double.parse(_locationQuantityController.text) > x) {
        return true;
      } else {
        return false;
      }
    } else {
      if (double.parse(_locationQuantityController.text) >
          double.parse(remainingBatchQuantity!)) {
        return true;
      } else {
        return false;
      }
    }
  }

  showAllocatedLocations(PriceModel modelData, int index) {
    List<InventoryManagementModel> _locationsList = [];
    // _locationQuantityController
    totalCurrentBatchQuantity = 0;
    remainingCurrentBatchQuantity = 0;
    for (int i = 0; i < inventoryList.length; i++) {
      for (int j = 0; j < inventoryList[i].locationBatchList!.length; j++) {
        if (modelData.batchNumber ==
            inventoryList[i].locationBatchList![j].batchNumber) {
          _locationsList.add(inventoryList[i]);
          totalCurrentBatchQuantity = totalCurrentBatchQuantity +
              inventoryList[i].locationBatchList![j].quantity!;
        }
      }
    }

    if (_locationsList.length > 0) {
      num value = double.parse(modelData.quantity!);

      remainingCurrentBatchQuantity = value - totalCurrentBatchQuantity;

      return Container(
        margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 5.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              child: Text(
                Language().getString(
                    Constants.BATCH_DETAILAS_AT_DIFF_LOC, selectedLang),
                style: TextStyle(
                    fontWeight: FontWeight.w600,
                    color: Color(Constants.APP_COLOR)),
              ),
            ),
            InventoryLocationBatchView(
              batchNumber: modelData.batchNumber,
              batchList: _locationsList,
              strBatchNumber:
                  Language().getString(Constants.BATCH_NO, selectedLang),
              strQuantity:
                  Language().getString(Constants.QUANTITY, selectedLang),
              strUpdatedBy:
                  Language().getString(Constants.UPDATED_BY, selectedLang),
              strUpdatedDate:
                  Language().getString(Constants.UPDATED_DATE, selectedLang),
              strAdjustedQuantity: Language()
                  .getString(Constants.ADJUSTED_QUANTITY, selectedLang),
              strReason: Language().getString(Constants.REASON, selectedLang),
            ),
          ],
        ),
      );
    } else {
      remainingCurrentBatchQuantity = double.parse(_qntyController.text);
      return Container();
    }
  }

  Widget showLocationBatchesInQuantityAdjustment(StateSetter setState) {
    return Container(
      margin: EdgeInsets.symmetric(
        vertical: 5.0,
      ),
      decoration: AppUtills.boxDecoration(),
      padding: EdgeInsets.all(1),
      child: Container(
        color: Colors.white70,
        padding: EdgeInsets.only(left: 5, right: 5),
        child: DropdownButton<InventoryDetailsDAO>(
          onTap: () {
            CommonMethods.hideKeyboard(context);
          },
          isExpanded: true,
          hint: Text(Language().getString(Constants.BATCH_NO, selectedLang)),
          underline: SizedBox(),
          items: _locationBatchesInQuantityAdjustment
              .map((InventoryDetailsDAO batchPrice) {
            return DropdownMenuItem<InventoryDetailsDAO>(
              value: batchPrice,
              child: new Text(
                batchPrice.batchNumber!,
                style: TextStyle(fontFamily: StyleView.FONT_TITLE),
              ),
            );
          }).toList(),
          value: quantityAdjustmentBatchDropdown,
          onChanged: (InventoryDetailsDAO? model) {
            setState(() {
              quantityAdjustmentBatchDropdown = model;
              remainingAdjustmentQuantity = model!.quantity;
            });
          },
        ),
      ),
    );
  }

  Widget inventoryLocationsInQuantityAdjustment(StateSetter setState) {
    return Container(
        margin: EdgeInsets.symmetric(
          vertical: 5.0,
        ),
        decoration: AppUtills.boxDecoration(),
        padding: EdgeInsets.all(1),
        child: Container(
            color: Colors.white70,
            padding: EdgeInsets.only(left: 5, right: 5),
            child: DropdownButton<InventoryManagementModel>(
                onTap: () {
                  FocusScope.of(context).requestFocus(
                      new FocusNode()); //CommonMethods.hideKeyboard(context);
                },
                isExpanded: true,
                hint: Text(
                    Language().getString(Constants.LOCATION, selectedLang)),
                underline: SizedBox(),
                items:
                    inventoryList.map((InventoryManagementModel locationData) {
                  return DropdownMenuItem<InventoryManagementModel>(
                    value: locationData,
                    child: new Text(
                      locationData.locationName!,
                      style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                    ),
                  );
                }).toList(),
                value: quantityAdjustmentLocationDropdown,
                onChanged: (InventoryManagementModel? location) {
                  setState(() {
                    _locationBatchesInQuantityAdjustment.clear();
                    quantityAdjustmentBatchDropdown = null;
                    quantityAdjustmentLocationDropdown = location;
                    _locationBatchesInQuantityAdjustment.addAll(
                        quantityAdjustmentLocationDropdown!.locationBatchList!);
                  });
                })));
  }

  showQuantityAdjustmentBatchPricingDetails(
      QuantityAdjustmentDAO _adjustmentModel,
      int index,
      bool isUpdateInventory) {
    if (quantityAdjustmentList.length > 0 &&
        quantityAdjustmentBatchDropdown != null) {
      bool isExist = false;

      for (int i = 0; i < quantityAdjustmentList.length; i++) {
        for (int j = 0;
            j < quantityAdjustmentList[i].quantityAdjustLocationsList!.length;
            j++) {
          if (quantityAdjustmentBatchDropdown!.batchNumber ==
              quantityAdjustmentList[i]
                  .quantityAdjustLocationsList![j]
                  .batchNumber) {
            isExist = true;
          }
        }
      }
      if (isExist) {
        return Container(
          margin: EdgeInsets.only(top: 10.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                child: Text(
                  Language().getString(
                      Constants.BATCH_DETAILAS_AT_DIFF_LOC, selectedLang),
                  style: TextStyle(
                      fontWeight: FontWeight.w600,
                      color: Color(Constants.APP_COLOR)),
                ),
              ),
              InventoryLocationBatchView(
                isFromQuantityAdjustment: true,
                quantityAdjustmentList: quantityAdjustmentList,
                batchNumber: quantityAdjustmentBatchDropdown!.batchNumber,
                batchList: [],
                locationsList: [],
                strBatchNumber:
                    Language().getString(Constants.BATCH_NO, selectedLang),
                strQuantity:
                    Language().getString(Constants.QUANTITY, selectedLang),
                strUpdatedBy:
                    Language().getString(Constants.UPDATED_BY, selectedLang),
                strUpdatedDate:
                    Language().getString(Constants.UPDATED_DATE, selectedLang),
                strAdjustedQuantity: Language()
                    .getString(Constants.ADJUSTED_QUANTITY, selectedLang),
                strReason: Language().getString(Constants.REASON, selectedLang),
              )
            ],
          ),
        );
      } else {
        return SizedBox();
      }
    } else {
      return Container();
    }
  }

  showQuantityAdjustmentLocationBatchNumbers(String? locationName) {
    for (int i = 0; i < quantityAdjustmentList.length; i++) {
      if (locationName == quantityAdjustmentList[i].locationName) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              child: Text(
                  Language().getString(Constants.BATCHES_IN_LOC, selectedLang),
                  style: TextStyle(
                      color: Color(Constants.APP_COLOR),
                      fontWeight: FontWeight.w600)),
            ),
            InventoryLocationBatchView(
              isShowLocationDetails: true,
              locationsList:
                  quantityAdjustmentList[i].quantityAdjustLocationsList,
              strBatchNumber:
                  Language().getString(Constants.BATCH_NO, selectedLang),
              strQuantity:
                  Language().getString(Constants.QUANTITY, selectedLang),
              strUpdatedBy:
                  Language().getString(Constants.UPDATED_BY, selectedLang),
              strUpdatedDate:
                  Language().getString(Constants.UPDATED_DATE, selectedLang),
              strAdjustedQuantity: Language()
                  .getString(Constants.ADJUSTED_QUANTITY, selectedLang),
              strReason: Language().getString(Constants.REASON, selectedLang),
            )
          ],
        );
      }
    }
  }

  Widget showRemainingInventoryAdjustQuantity(
      QuantityAdjustmentDAO inventoryDropdownQuantity,
      int index,
      bool isUpdateInventory) {
    num inventoryTotalQuantity = 0;
    _selectedLocationQuantity = 0;
    if (quantityAdjustmentBatchDropdown != null) {
      if (isUpdateInventory) {
        for (int j = 0; j < quantityAdjustmentList.length; j++) {
          for (int i = 0;
              i < quantityAdjustmentList[j].quantityAdjustLocationsList!.length;
              i++) {
            if (quantityAdjustmentBatchDropdown!.batchNumber ==
                quantityAdjustmentList[j]
                    .quantityAdjustLocationsList![i]
                    .batchNumber) {
              inventoryTotalQuantity = inventoryTotalQuantity +
                  quantityAdjustmentList[j]
                      .quantityAdjustLocationsList![i]
                      .quantity!;
            }
          }
        }
      } else {
        for (int j = 0; j < quantityAdjustmentList.length; j++) {
          for (int i = 0;
              i < quantityAdjustmentList[j].quantityAdjustLocationsList!.length;
              i++) {
            if (quantityAdjustmentBatchDropdown!.batchNumber ==
                quantityAdjustmentList[j]
                    .quantityAdjustLocationsList![i]
                    .batchNumber) {
              inventoryTotalQuantity = inventoryTotalQuantity +
                  quantityAdjustmentList[j]
                      .quantityAdjustLocationsList![i]
                      .quantity!;
            }
          }
        }
      }

      remainingBatchQuantity =
          quantityAdjustmentBatchDropdown!.quantity.toString();
      // (quantityAdjustmentBatchDropdown.quantity - inventoryTotalQuantity)
      //     .toString();

      _quantityAdjutmentController.text = remainingBatchQuantity!;
      _selectedLocationQuantity = double.parse(remainingBatchQuantity!);
      return Container(
          margin: EdgeInsets.only(top: 5.0),
          child: Row(
            children: [
              Container(
                child: Text(
                  Language().getString(
                      Constants.QUANTITY_NOT_ASSIGNED_TO_LOCATION,
                      selectedLang),
                  style: TextStyle(
                      fontSize: 12.0,
                      color: Color(Constants.APP_COLOR),
                      fontWeight: FontWeight.bold),
                ),
              ),
              Text(
                "  : ",
                style: TextStyle(
                  fontSize: 13.0,
                  color: Color(Constants.APP_COLOR),
                ),
              ),
              Container(
                child: Text(
                  "$remainingBatchQuantity",
                  style: TextStyle(
                    fontSize: 12.0,
                    color: Color(Constants.APP_COLOR),
                  ),
                ),
              ),
            ],
          ));
    } else {
      return Container();
    }
  }

  Future<void> loadProductData() async {
    if (await NetworkStatus.getInternetStatus()) {
      List<BuProductModal> fecthProductData = await ProductsApiService.instance
          .getProductDataById(
              context: context,
              productId: widget.productId!,
              buId: buId!,
              langError: Language().getString(Constants.ERROR, selectedLang),
              langOk: Language().getString(Constants.OKAY_STR, selectedLang));
      if (fecthProductData.length > 0) {
        setState(() => _productsList.addAll(fecthProductData));
        bindingProductData(_productsList[0]);
      }
      loadDropdowns();
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<void> loadDropdowns() async {
    setState(() => isLoadingProgress = true);

    List<ProductSectorDAO> fetchSectorData = await ProductsApiService.instance
        .getProductSector(
            context: context,
            langError: Language().getString(Constants.ERROR, selectedLang),
            langOk: Language().getString(Constants.OKAY_STR, selectedLang));
    setState(() => isLoadingProgress = false);
    if (fetchSectorData.length > 0) {
      setState(() => productSectorList.addAll(fetchSectorData));
      if (widget.title ==
              Language().getString(Constants.UPDATE_PRODUCT, selectedLang) &&
          _productsList[0].productSector != null) {
        for (int i = 0; i < fetchSectorData.length; i++) {
          if (_productsList[0].productSector == fetchSectorData[i].sectorName) {
            setState(() => productSectorDropdown = fetchSectorData[i]);
          }
        }
      }
      if (productSectorDropdown != null) {
        loadProductCategories(parentCode: productSectorDropdown!.parentId!);
      }
    }
    this.getBuData().then((value) {
      _buList.addAll(value);
      if (_buList.length > 0) {
        /// Getting bu locations
        setState(() {
          locationsList.addAll(_buList[0].locationsList!);
        });
      }
    });

    this.getCurrencyNames().then((list) {
      list.sort();
      _currencyNameList.addAll(list);
    });

    this.getCountryTypes().then((onValue) {
      countryList.addAll(onValue);
      if (countryList.length > 0) {
        for (int i = 0; i < countryList.length; i++) {
          if (countryList[i].name == "India") {
            setState(() {
              _countryName = countryList[i];
              if (widget.title !=
                  Language()
                      .getString(Constants.UPDATE_PRODUCT, selectedLang)) {
                _dialCodeController.text = _countryName!.countryCode!;
              }
            });
            getStates(_countryName!.name!).then((onValue) {
              setState(() {
                stateList.addAll(onValue);
              });
            });
          }
        }
      }
    });

    await this.getContacts(buId).then((value) {
      _connectionsList.addAll(value);
    });
    // if (widget.isFromRawMaterialPage) {
    await this.loadRawListData();
    // }
  }

  Future<void> loadProductSubCategory({required int parentCode}) async {
    if (isLoadingProgress && widget.title == Constants.UPDATE_PRODUCT) {
      setState(() => isLoadingProgress = !isLoadingProgress);
    }
    List<ProductSubCategoryDAO> fetchSubCategory =
        await ProductsApiService.instance.getProductSubCategories(
            context: context,
            parentCode: parentCode,
            langError: Language().getString(Constants.ERROR, selectedLang),
            langOk: Language().getString(Constants.OKAY_STR, selectedLang));
    setState(() => isLoadingProgress = false);
    if (fetchSubCategory.length > 0) {
      setState(() => productSubCategories.addAll(fetchSubCategory));
      if (widget.title ==
              Language().getString(Constants.UPDATE_PRODUCT, selectedLang) &&
          _productsList[0].productSubCategory != null) {
        for (int i = 0; i < fetchSubCategory.length; i++) {
          if (_productsList[0].productSubCategory == fetchSubCategory[i].type) {
            setState(() => _productSubCategory = fetchSubCategory[i]);
          }
        }
      }
    }
  }

  Future<void> loadProductCategories({required int parentCode}) async {
    setState(() => isLoadingProgress = true);
    List<ProductCategoryDAO> fetchCategorieData =
        await ProductsApiService.instance.getProductCategories(
            context: context,
            parentCode: parentCode,
            langError: Language().getString(Constants.ERROR, selectedLang),
            langOk: Language().getString(Constants.OKAY_STR, selectedLang));
    setState(() => isLoadingProgress = false);
    if (fetchCategorieData.length > 0) {
      setState(() => productCategories.addAll(fetchCategorieData));
      if (widget.title ==
              Language().getString(Constants.UPDATE_PRODUCT, selectedLang) &&
          _productsList[0].productCategory != null) {
        for (int i = 0; i < fetchCategorieData.length; i++) {
          if (_productsList[0].productCategory == fetchCategorieData[i].type) {
            setState(() => _productCategory = fetchCategorieData[i]);
          }
        }
      }
    }
    if (_productCategory != null) {
      loadProductSubCategory(parentCode: _productCategory!.code!);
    }
  }
}
