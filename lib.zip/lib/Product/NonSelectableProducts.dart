import 'dart:convert';
import 'dart:io';
import 'package:vyaparlive/Product/controller/non_select_products_controller.dart';
import 'package:vyaparlive/core/enums/privilleges_enum.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:vyaparlive/utills/animation/list_loader/ListLoader.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:flutx/flutx.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/ModelProduct.dart';
import 'package:vyaparlive/model/product_model/ProductModel.dart';
import 'package:vyaparlive/service/product_services.dart';

class NonSelectableProducts extends StatefulWidget {
  NonSelectableProducts({this.buId, this.buName, this.isSelectable = false});
  final String? buId;
  final String? buName;
  final bool isSelectable;
  @override
  _NonSelectableProductsViewState createState() =>
      _NonSelectableProductsViewState();
}

class _NonSelectableProductsViewState extends State<NonSelectableProducts> {
  bool isAddbuttonvisible = true;
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  var counter = 1;
  List<ModelProduct> _productsList = [];
  List<BuProductModal> _searchProductsList = [];
  List<ModelProduct> _modelProducts = [];
  bool isLoading = false;
  final _searchController = TextEditingController();
  bool isItemSelected = false;
  var mycolor = Colors.white;
  bool isLoadingProgress = true;
  String progressMessage = Constants.GETTING_DATA;
  late ProductService _productService;
  String? orgCurrencySymbol = "";
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  late ThemeData theme;
  late NonSelectableController _controller;
  @override
  void initState() {
    super.initState();
    _controller = FxControllerStore.putOrFind(NonSelectableController());
    theme = AppTheme.vyaparTheme;
    _productService = ProductService();
    loadProductData("");
    // orgCurrencySymbol = AppController.instance.getBuCurrencySymbol;
    String? symbol = AppController.instance.getBuCurrencySymbol;
    orgCurrencySymbol = (symbol != null && symbol.isNotEmpty && symbol!="-") ? symbol : "\u20B9";
  }

  Future<List<BuProductModal>> getBuProducts(id, parmsurl) async {
    String body = json.encode({
      "id": id,
      "filter": {
        "name": parmsurl,
        "for_sale": true,
      }
    });

    var response = await _productService
        .getProductByBuId_v2(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    isLoading = true;

    List<BuProductModal> _products = [];
    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      var data = resObj['results'];
      for (var i in data) {
        _products.add(BuProductModal.fromJson(i));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return _products;
  }

  Widget _buidBody() {
    if (isLoadingProgress) {
      return ListLoader();
    } else if (!isLoadingProgress && _modelProducts.length == 0) {
      return Container(
          child: Center(
              child: Text(
        Language().getString(Constants.NO_DATA_FOUND, selectedLang),
      )));
    } else {
      return Container(
        margin: EdgeInsets.symmetric(horizontal: 10.0, vertical: 5.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Container(height: 50, child: buildSearchBarView()),
            Expanded(
              child: Container(
                margin: EdgeInsets.only(top: 10),
                child: AnimationLimiter(
                  child: ListView.separated(
                      shrinkWrap: true,
                      physics: new BouncingScrollPhysics(
                          parent: AlwaysScrollableScrollPhysics()),
                      itemBuilder: (context, index) =>
                          AnimationConfiguration.staggeredList(
                            position: index,
                            duration: Duration(milliseconds: 900),
                            child: SlideAnimation(
                              verticalOffset: 50.0,
                              child: FadeInAnimation(
                                child: Container(
                                  child: Card(
                                      elevation: 7.0,
                                      shadowColor: theme.colorScheme.primary,
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(10.0)),
                                      color: Colors.white,
                                      child: InkWell(
                                          onTap: () {
                                            if (_modelProducts[index]
                                                .isButton!) {
                                              setState(() {
                                                _modelProducts[index].isButton =
                                                    !_modelProducts[index]
                                                        .isButton!;
                                              });
                                            } else {
                                              if (widget.isSelectable) {
                                                setState(() {
                                                  _modelProducts[index]
                                                      .isButton = true;
                                                });
                                              }
                                            }
                                          },
                                          child: listRowEditUpdate(
                                              _modelProducts[index], index))),
                                ),
                              ),
                            ),
                          ),
                      separatorBuilder: (context, index) =>
                          new Divider(height: 5, color: Colors.transparent),
                      itemCount: _modelProducts.length),
                ),
              ),
            )
          ],
        ),
      );
    }
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  void setState(VoidCallback fn) {
    // TODO: implement setState
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
      body: FxBuilder(
          controller: _controller,
          builder: (_controller) => Stack(
                children: [
                  SafeArea(
                    child: Scaffold(
                      key: _scaffoldkey,
                      backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                      appBar: AppBar(
                        iconTheme:
                            IconThemeData(color: theme.colorScheme.primary),
                        centerTitle: true,
                        elevation: 0,
                        title: AppbarName(
                            title: Language()
                                .getString(Constants.PRODUCTS_STR, selectedLang),
                            buName: "${widget.buName}"),
                        backgroundColor: Colors.transparent,
                      ),
                      bottomNavigationBar: (_modelProducts.length > 0 &&
                              _modelProducts.any((item) => item.isButton!))
                          ? Padding(
                              padding: const EdgeInsets.only(bottom: 24),
                              child: CommonButtonsView(
                                  context: context,
                                  b1Text: Language().getString(
                                      Constants.CONTINUE, selectedLang),
                                  b2Text: "",
                                  onb1Action: () {
                                    for (int i = 0;
                                        i < _modelProducts.length;
                                        i++) {
                                      if (_modelProducts[i].isButton!) {
                                        _productsList.add(_modelProducts[i]);
                                      }
                                    }
                                    _controller.onBack(
                                        rootContext: context,
                                        productsList:
                                            _productsList); // Navigator.pop(context, _productsList);
                                  }),
                            )
                          : null,
                      body: _buidBody(),
                    ),
                  ),
                  // AppUtills.showLoadingView(
                  //     context: context,
                  //     message: Language().getString(progressMessage, selectedLang),
                  //     isLoading: isLoadingProgress),
                ],
              )),
    );
  }

  Widget listRowEditUpdate(item, int index) {
    bool isOfferActive = false;
    for (int i = 0; i < _modelProducts[index].offerList!.length; i++) {
      if (_modelProducts[index].offerList![i].isOfferActive! &&
          !_modelProducts[index].offerList![i].isOfferExpired!) {
        isOfferActive = true;
      } else {
        isOfferActive = false;
      }
    }
    return Stack(
      children: [
        SizedBox(
          height: (kIsWeb || Platform.isWindows)
              ? MediaQuery.of(context).size.height * 0.12
              : MediaQuery.of(context).size.height * 0.15,
          child: Row(
            children: <Widget>[
              Expanded(
                child: Container(
                    child: ClipRRect(
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(10.0),
                            bottomLeft: Radius.circular(10.0)),
                        child: AppUtills.imageAspectRatio(
                            _modelProducts[index].images,
                            aspectRatio: 16 / 12,
                            context: context))

                    // Container(
                    //     padding: EdgeInsets.all(5.5),
                    //     margin: EdgeInsets.all(2.5),
                    //     child: AppUtills.displayImage(
                    //         _modelProducts[index].images!)),
                    ),
              ),
              Expanded(
                flex: 3,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          margin: EdgeInsets.symmetric(
                              horizontal: 10.0, vertical: 5.0),
                          alignment: Alignment.centerLeft,
                          child: Text(
                            "${_modelProducts[index].name}",
                            style: TextStyle(
                                color:
                                    Colors.black, //theme.colorScheme.primary,
                                overflow: TextOverflow.ellipsis,
                                fontWeight: StyleView.fontSemiBold),
                          ),
                        ),
                        this.showPriceDetails(index),
                      ],
                    ),
                    Container(
                      padding: EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          if (isOfferActive &&
                              CommonMethods.isPrivillegeExist(
                                  context,
                                  PrivillegesActions
                                      .KEY_TRANSACTIONS_TRANSACTION_STEPS_ORDER_DISCUSSION_SELLER_PRODUCTS_OFFERS))
                            Container(
                              child: InkWell(
                                  onTap: () {
                                    this.renderShowOfferForProduct(index);
                                  },
                                  child: Container(
                                    child: Text(
                                      Language().getString(
                                          Constants.OFFERS, selectedLang),
                                      style: TextStyle(
                                          color: StyleView.offerColor,
                                          fontSize: 15.0,
                                          decoration: TextDecoration.underline),
                                    ),
                                  )),
                            ),
                          FxSpacing.width(10.0),
                          if (CommonMethods.isPrivillegeExist(
                              context,
                              PrivillegesActions
                                  .KEY_TRANSACTIONS_TRANSACTION_STEPS_ORDER_DISCUSSION_SELLER_PRODUCTS_DETAILS))
                            Container(
                              child: InkWell(
                                onTap: () {
                                  _controller.onProductDetails(
                                      productId: _modelProducts[index].id!,
                                      buId: widget.buId!);
                                },
                                child: Row(
                                  children: [
                                    Text(
                                      Language().getString(
                                          Constants.DETAILS, selectedLang),
                                      style: TextStyle(
                                          color: theme.colorScheme.primary,
                                          fontWeight: StyleView.fontSemiBold,
                                          decoration: TextDecoration.underline),
                                    ),
                                    Icon(
                                      Icons.arrow_outward_sharp,
                                      size: 18.0,
                                      color: theme.colorScheme.primary,
                                    )
                                  ],
                                ),
                              ),
                            )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        if (_modelProducts[index].isButton!)
          Positioned(
              right: 5,
              top: 2,
              child: Icon(Icons.check_circle_rounded,
                  color: Colors.green, size: 20.0)),
      ],
    );
  }

  renderShowOfferForProduct(int index) {
    if (_modelProducts[index].offerList!.length > 0) {
      for (int i = 0; i < _modelProducts[index].offerList!.length; i++) {
        if (_modelProducts[index].offerList![i].isOfferActive!) {
          return Dialogs.showOffer(
              context,
              _modelProducts[index].offerList![i].offerQuantity,
              _modelProducts[index].offerList![i].offerName,
              _modelProducts[index].offerList![i].minOrder,
              _modelProducts[index].offerList![i].maxOrder,
              _modelProducts[index].offerList![i].offerType);
        }
      }
    }
  }

  buildSearchBarView() {
    return Card(
      elevation: 5.0,
      shadowColor: theme.colorScheme.primary,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0),
          side:
              BorderSide(color: theme.colorScheme.primary, strokeAlign: 0.01)),
      child: Row(
        children: <Widget>[
          Expanded(
              flex: 5,
              child: Row(
                children: [
                  Expanded(
                    flex: 5,
                    child: Container(
                      padding: EdgeInsets.only(left: 15),
                      child: TextFormField(
                        textInputAction: TextInputAction.done,
                        controller: _searchController,
                        onChanged: onSearchTextChanged,
                        style: TextStyle(fontWeight: StyleView.fontSemiBold),
                        decoration: InputDecoration(
                            border: InputBorder.none,
                            hintText: Language().getString(
                                Constants.SEARCH_BY_PRODUCT, selectedLang),
                            hintStyle: TextStyle(
                                fontSize: 13.0,
                                fontWeight: StyleView.fontSemiBold)),
                      ),
                    ),
                  ),
                  if (_searchController.text.isNotEmpty)
                    Expanded(
                      flex: 1,
                      child: Container(
                        child: IconButton(
                            icon: Icon(Icons.close,
                                color: Colors.red, size: 20.0),
                            onPressed: () {
                              isLoading = false;
                              _searchController.clear();
                              onSearchTextChanged('');
                            }),
                      ),
                    )
                ],
              )),
        ],
      ),
    );
  }

  onSearchTextChanged(String text) async {
    if (text.isEmpty) {
      setState(() {
        isLoadingProgress = true;
      });
      isLoading = false;
      loadProductData("");
    } else {
      loadProductData(_searchController.text);
    }
  }

  loadProductData(String productName) async {
    if (await NetworkStatus.getInternetStatus()) {
      this.getBuProducts(widget.buId, productName).then((value) {
        setState(() {
          _searchProductsList.clear();
          _modelProducts.clear();
          _searchProductsList.addAll(value);
          for (int i = 0; i < _searchProductsList.length; i++) {
            bool isPriceAvailable = false;

            for (int j = 0;
                j < _searchProductsList[i].batchPrice!.length;
                j++) {
              if (_searchProductsList[i].batchPrice![j].quantity != 0 &&
                  _searchProductsList[i].batchPrice![j].price != 0) {
                isPriceAvailable = true;
              }
            }

            if (isPriceAvailable) {
              _modelProducts.add(ModelProduct(
                  id: _searchProductsList[i].id,
                  name: _searchProductsList[i].name,
                  counter: 0,
                  isButton: false,
                  images: _searchProductsList[i].images,
                  price: _searchProductsList[i].batchPrice![0].price,
                  quantity: 0,
                  isItemSelected: false,
                  offerList: _searchProductsList[i].offers,
                  quantityIn: _searchProductsList[i].batchPrice![0].quantityIn,
                  batchPriceList: _searchProductsList[i].batchPrice));
            }
          }
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  showPriceDetails(int index) {
    if (_modelProducts[index].price != null) {
      return Container(
          margin: EdgeInsets.symmetric(horizontal: 10.0),
          alignment: Alignment.centerLeft,
          child: Row(
            children: [
              // Text(
              //   Language().getString(Constants.PRICE, selectedLang),
              //   style: TextStyle(
              //       color: Colors.black,
              //       fontSize: 14.0,
              //       fontFamily: StyleView.FONT_TITLE),
              // ),
              // Text("  : "),
              Text(
                "\u20B9" +
                    CommonMethods.getAvailablePrice(
                        _modelProducts[index].batchPriceList!) +
                    " ${_modelProducts[index].quantityIn}",
                style: TextStyle(
                    color: Colors.black54,
                    fontSize: 12,
                    fontWeight: StyleView.fontMedium),
              ),
            ],
          ));
    } else {
      return Container();
    }
  }
}
