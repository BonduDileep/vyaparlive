import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/TextView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/service/bu_list_grpc_service.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Product/ProductHistoryPage.dart';
import 'package:vyaparlive/Product/product_transaction_view/PendingProducts.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/OrderDAO.dart';
import 'package:vyaparlive/model/product_model/ProductModel.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'dart:convert';

import '../../core/enums/privilleges_enum.dart';

class ProductTransactionPage extends StatefulWidget {
  ProductTransactionPage({this.productDetails});
  final BuProductModal? productDetails;
  @override
  _ProductTransactionPageState createState() => _ProductTransactionPageState();
}

class _ProductTransactionPageState extends State<ProductTransactionPage> {
  List<OrderDAO> _ordersList = [];

  String? buId = "";
  String? buName = "";
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  String fromDate = "";
  String toDate = "";
  DateTime mnthStartDate =
      DateTime.utc(DateTime.now().year, DateTime.now().month, 1);
  DateFormat formatter = DateFormat("yyyy-MM-dd");
  late BuListGrpcService _transactionService;
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    _transactionService = new BuListGrpcService();
    theme = AppTheme.vyaparTheme;
    buId = AppController.instance.getMyBuId;
    buName = AppController.instance.getBuName;
    fromDate = formatter.format(mnthStartDate);
    toDate = formatter.format(DateTime.now());
    loadPendingProductsData("");
  }

  loadPendingProductsData(String parms) async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
      });
      getProductOrderData(parms).then((value) {
        setState(() {
          _ordersList.addAll(value);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
      body: Stack(
        children: [
          SafeArea(
            child: Scaffold(
              key: _scaffoldkey,
              backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
              appBar: AppBar(
                centerTitle: true,
                elevation: 0,
                iconTheme: IconThemeData(color: theme.colorScheme.primary),
                backgroundColor: Colors.transparent, //(Constants.APP_COLOR),
                title: AppbarName(
                    title: Language()
                        .getString(Constants.TRANSACTIONS_STR, selectedLang),
                    buName: "$buName"),
                actions: [
                  AppUtills.homeButton(context),
                ],
              ),
              body: Container(
                  margin: EdgeInsets.all(5.0),
                  child: Column(
                    children: <Widget>[
                      Card(
                          elevation: 5.0,
                          shadowColor: theme.colorScheme.primary,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5),
                              side: BorderSide(
                                  color: theme.colorScheme.primaryContainer,
                                  strokeAlign: 0.02)),
                          child: Container(
                            padding: EdgeInsets.all(10.0),
                            child: Column(
                              children: <Widget>[
                                TextView(
                                    title: Language().getString(
                                        Constants.PRODUCT_NAME, selectedLang),
                                    value: "${widget.productDetails!.name}"),
                                if (widget.productDetails?.batchPrice?.length !=
                                    0)
                                  Container(
                                    child: Column(
                                      children: [
                                        TextView(
                                            title: Language().getString(
                                                Constants.QUANTITY, selectedLang),
                                            value:
                                                "${widget.productDetails!.batchPrice?[0].quantity}"),
                                        TextView(
                                            title: Language().getString(
                                                Constants.PRICE, selectedLang),
                                            value:
                                                "${widget.productDetails!.batchPrice?[0].price}"),
                                        TextView(
                                            title: Language().getString(
                                                Constants.BATCH_NO, selectedLang),
                                            value:
                                                "${widget.productDetails!.batchPrice?[0].batchNumber}")
                                      ],
                                    ),
                                  )
                              ],
                            ),
                          )),
                      Container(
                        color: Color(Constants.APP_BACKGROUND_COLOR),
                        margin: EdgeInsets.only(top: 20.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: <Widget>[
                            if (CommonMethods.isPrivillegeExist(
                                context,
                                PrivillegesActions
                                    .KEY_PRODUCT_LIST_ITEM_TRANSACTIONS_PENDING_ORDERS))
                              InkWell(
                                  onTap: () {
                                    if (_ordersList.length > 0) {
                                      Navigator.push(
                                          context,
                                          PageTransition(
                                              context: context,
                                              page: PendingProductOrdersPage(
                                                productId:
                                                    widget.productDetails!.id,
                                                productName:
                                                    widget.productDetails!.name,
                                              )));
                                    } else {
                                      Dialogs.yesCancelDialog(
                                          context,
                                          Language().getString(
                                              Constants.INFO, selectedLang),
                                          Language().getString(
                                              Constants.NO_PENDING_ORDERS,
                                              selectedLang),
                                          Language().getString(
                                              Constants.OKAY_STR, selectedLang),
                                          "",
                                          false);
                                    }
                                  },
                                  child: Card(
                                      elevation: 5,
                                      shadowColor: theme.colorScheme.primary,
                                      shape: new RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(5),
                                          side: new BorderSide(
                                              color: theme
                                                  .colorScheme.primaryContainer,
                                              strokeAlign: 0.02)),
                                      child: Padding(
                                        padding: const EdgeInsets.all(15.0),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              Language().getString(
                                                  Constants.PENDING_ORDERS,
                                                  selectedLang),
                                              style: TextStyle(
                                                fontWeight: StyleView.fontBold,
                                                color: Colors.black,
                                              ),
                                            ),
                                            Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.end,
                                              children: [
                                                Container(
                                                  height: 25.0,
                                                  width: 25.0,
                                                  alignment:
                                                      Alignment.centerRight,
                                                  margin: EdgeInsets.symmetric(
                                                      horizontal: 10.0),
                                                  decoration: BoxDecoration(
                                                      color: Colors.orange[900],
                                                      shape: BoxShape.circle),
                                                  child: Center(
                                                    child: Text(
                                                      "${_ordersList.length}",
                                                      style: TextStyle(
                                                          color: Colors.white,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          fontSize: 11.0),
                                                    ),
                                                  ),
                                                ),
                                                Icon(
                                                  Icons.arrow_forward_ios_rounded,
                                                  size: 18.0,
                                                )
                                              ],
                                            ),
                                          ],
                                        ),
                                      ))),
                            if (CommonMethods.isPrivillegeExist(
                                context,
                                PrivillegesActions
                                    .KEY_PRODUCT_LIST_ITEM_TRANSACTIONS_ORDER_HISTORY))
                              InkWell(
                                onTap: () {
                                  Navigator.push(
                                      context,
                                      new MaterialPageRoute(
                                          builder: (context) =>
                                              ProductHistoryPage(
                                                  productId: widget
                                                      .productDetails!.id)));
                                },
                                child: Card(
                                  elevation: 5,
                                  shadowColor: theme.colorScheme.primary,
                                  shape: new RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(5),
                                      side: new BorderSide(
                                          color:
                                              theme.colorScheme.primaryContainer,
                                          strokeAlign: 0.02)),
                                  child: Padding(
                                    padding: const EdgeInsets.all(15.0),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                            Language().getString(
                                                Constants.ORDER_HISTORY,
                                                selectedLang),
                                            style: TextStyle(
                                                fontWeight: StyleView.fontBold,
                                                color: Colors.black)),
                                        Icon(
                                          Icons.arrow_forward_ios_rounded,
                                          size: 18.0,
                                        )
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ),
                    ],
                  )),
            ),
          ),
          AppUtills.showLoadingView(
              context: context,
              message: Language().getString(progressMessage, selectedLang),
              isLoading: isLoadingProgress),
        ],
      ),
    );
  }

  Future<List<OrderDAO>> getProductOrderData(String parms) async {
    String body = json.encode(
        {"buId": buId, "productId": widget.productDetails!.id, "filters": {}});

    var response = await _transactionService
        .findPendingProductsByProductId(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<OrderDAO> list = [];

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      bool isString = CommonMethods.checkResponseType(resObj);
      if (!isString) {
        var data = resObj['results'];
        for (var i in data) {
          list.add(OrderDAO.fromJson(i));
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return list;
  }
}
