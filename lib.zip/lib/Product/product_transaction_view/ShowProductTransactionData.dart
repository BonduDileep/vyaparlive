import 'package:flutter/material.dart';
import 'package:vyaparlive/components/Constants.dart';

class ShowProductTransactionData extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          Container(
            child: Row(
              children: [
                Expanded(
                    child: Text(
                  Constants.DATE,
                  style: textStyle(),
                )),
                Expanded(child: Text(Constants.TO, style: textStyle())),
                Expanded(child: Text(Constants.QUANTITY, style: textStyle())),
                Expanded(child: Text(Constants.INVOICE, style: textStyle())),
              ],
            ),
          )
        ],
      ),
    );
  }

  textStyle() {
    return TextStyle(
      color: Color(Constants.APP_COLOR),
      fontSize: 15.0,
      fontWeight: FontWeight.bold,
    );
  }
}
