import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/service/bu_list_grpc_service.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/DateFilterUtil.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/invoice_view/InvoiceDesingView.dart';
import 'package:vyaparlive/model/OrderDAO.dart';
import 'package:vyaparlive/model/PendingProductsDAO.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'dart:convert';

class PendingProductOrdersPage extends StatefulWidget {
  final String? productId;
  final String? productName;
  PendingProductOrdersPage({this.productId, this.productName});
  @override
  _PendingProductOrdersPageState createState() =>
      _PendingProductOrdersPageState();
}

class _PendingProductOrdersPageState extends State<PendingProductOrdersPage> {
  String? buName = "";
  String? buId = "";
  late BuListGrpcService _transactionService;
  List<PendingProductsDAO> pendingOrdersList = [];
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  bool isOpenDateFilterView = false;
  final _searchController = TextEditingController();
  final double calendarHeight = 40.0;
  String formatedUserDob = "";
  String fromDate = "";
  String toDate = "";
  DateFormat formatter = DateFormat("yyyy-MM-dd");
  DateTime selectedDate = DateTime.now();
  bool isLoading = false;
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  bool isShowFloatButton = false;
  static String showLoaderText = Constants.NO_DATA_FOUND;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  DateTime mnthStartDate =
      DateTime.utc(DateTime.now().year, DateTime.now().month, 1);
  bool isForSearchFilter = false;
  String searchParams = "";
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _transactionService = new BuListGrpcService();
    buName = AppController.instance.getBuName;
    buId = AppController.instance.getMyBuId;
    fromDate = formatter.format(mnthStartDate);
    toDate = formatter.format(DateTime.now());
    searchParams =
        "?${Constants.DATE_FROM}$fromDate&${Constants.DATE_TO}$toDate";
    loadPendingOrdersData("");
  }

  loadPendingOrdersData(String parms) async {
    if (await NetworkStatus.getInternetStatus()) {
      if (!isForSearchFilter) {
        setState(() {
          isLoadingProgress = true;
        });
      }

      getPendingProductsData(parms).then((value) {
        setState(() {
          if (value.length > 0) {
            pendingOrdersList.clear();
            pendingOrdersList.addAll(value);
          } else {
            showLoaderText = Constants.NO_DATA_FOUND;
          }
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
        body: Stack(
      children: [
        SafeArea(
          child: Scaffold(
            key: _scaffoldkey,
            backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
            floatingActionButton: (isShowFloatButton)
                ? FloatingActionButton(
                    backgroundColor: Color(Constants.APP_COLOR),
                    onPressed: () {
                      setState(() {
                        isShowFloatButton = false;
                        isLoadingProgress = true;
                      });
                      fromDate = formatter.format(mnthStartDate);
                      toDate = formatter.format(DateTime.now());
                      String params =
                          "?${Constants.DATE_FROM}$fromDate&${Constants.DATE_TO}$toDate";
                      loadPendingOrdersData(params);
                    },
                    child: Text(
                      Language().getString(Constants.CLEAR_FILTERS, selectedLang),
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white, fontSize: 11.0),
                    ))
                : null,
            appBar: AppBar(
              backgroundColor: Colors.transparent, //Color(Constants.APP_COLOR),
              centerTitle: true,
              elevation: 0,
              iconTheme: IconThemeData(color: theme.colorScheme.primary),
              title: AppbarName(
                  title: Language()
                      .getString(Constants.PENDING_ORDERS, selectedLang),
                  buName: "$buName"),
              actions: [
                AppUtills.homeButton(context),
              ],
            ),
            body: Container(
              margin: EdgeInsets.symmetric(vertical: 5.0, horizontal: 5.0),
              child: Column(
                children: [
                  buildSearchFilterView(),
                  (isOpenDateFilterView)
                      ? buildDateFilterView()
                      : new Container(),
                  Container(
                    margin: EdgeInsets.symmetric(vertical: 5.0),
                    child: Row(
                      children: [
                        Container(
                          child: Text(
                            Language()
                                .getString(Constants.PRODUCT_NAME, selectedLang),
                            style: TextStyle(
                                fontWeight: FontWeight.w900,
                                color: Color(Constants.APP_COLOR)),
                          ),
                        ),
                        Text(" : "),
                        Expanded(
                          child: Container(
                            child: Text(
                              "${widget.productName}",
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                  Container(
                    child: (pendingOrdersList.length > 0)
                        ? Expanded(
                            child: Container(
                              margin: EdgeInsets.symmetric(
                                horizontal: 5.0,
                                vertical: 5.0,
                              ),
                              decoration: BoxDecoration(
                                border: Border.all(
                                  color: Color(Constants.APP_COLOR),
                                ),
                              ),
                              child: Column(
                                children: [
                                  Container(
                                    padding: EdgeInsets.all(
                                      5.0,
                                    ),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        this.renderHeaderText(Constants.DATE, 1),
                                        this.renderHeaderText(Constants.TO, 1),
                                        this.renderHeaderText(
                                            Constants.QUANTITY, 2),
                                        this.renderHeaderText(
                                            Constants.INVOICE, 1)
                                      ],
                                    ),
                                  ),
                                  Divider(
                                    color: Color(Constants.APP_COLOR),
                                  ),
                                  Expanded(
                                    child: ListView.builder(
                                      shrinkWrap: true,
                                      itemBuilder: (context, index) {
                                        return Container(
                                          padding: EdgeInsets.all(
                                            5.0,
                                          ),
                                          margin:
                                              EdgeInsets.symmetric(vertical: 5.0),
                                          child: Row(
                                            children: [
                                              Expanded(
                                                child: Text(
                                                  AppUtills.getDateFormate(
                                                      pendingOrdersList[index]
                                                          .invoiceDate
                                                          .toString()),
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                    fontSize: 13.0,
                                                    color: Color(
                                                        Constants.APP_COLOR),
                                                  ),
                                                ),
                                              ),
                                              Expanded(
                                                child: Text(
                                                  "${pendingOrdersList[index].buyerData!.buName}",
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                    fontSize: 13.0,
                                                    color: Color(
                                                        Constants.APP_COLOR),
                                                  ),
                                                ),
                                              ),
                                              Expanded(
                                                child: Text(
                                                  "${pendingOrdersList[index].productData!.length > 0 ? pendingOrdersList[index].productData![0].quantity : ""}",
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                    fontSize: 13.0,
                                                    color: Color(
                                                        Constants.APP_COLOR),
                                                  ),
                                                ),
                                              ),
                                              Expanded(
                                                child: InkWell(
                                                  onTap: () {
                                                    Navigator.push(
                                                        context,
                                                        PageTransition(
                                                            context: context,
                                                            page:
                                                                InvoiceDesingPage(
                                                              transactionId:
                                                                  pendingOrdersList[
                                                                          index]
                                                                      .transactionId,
                                                              invoiceNo:
                                                                  pendingOrdersList[
                                                                          index]
                                                                      .invoiceNo
                                                                      .toString(),
                                                              invoiceId:
                                                                  pendingOrdersList[
                                                                          index]
                                                                      .invoiceId,
                                                              transactionName:
                                                                  pendingOrdersList[
                                                                          index]
                                                                      .buyerData!
                                                                      .buName,
                                                              transactionDate:
                                                                  pendingOrdersList[
                                                                          index]
                                                                      .invoiceDate
                                                                      .toString(),
                                                            )));
                                                  },
                                                  child: Text(
                                                    Language().getString(
                                                            Constants.INVOICE,
                                                            selectedLang) +
                                                        " #${pendingOrdersList[index].invoiceNo}",
                                                    textAlign: TextAlign.center,
                                                    style: TextStyle(
                                                      fontSize: 13.0,
                                                      decoration: TextDecoration
                                                          .underline,
                                                      color: Color(
                                                          Constants.APP_COLOR),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        );
                                      },
                                      itemCount: pendingOrdersList.length,
                                    ),
                                  )
                                ],
                              ),
                            ),
                          )
                        : Expanded(
                            child: Center(
                              child: Text(showLoaderText),
                            ),
                          ),
                  )
                ],
              ),
            ),
          ),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    ));
  }

  showProductData(OrderDAO historyModel) {
    return Container(
      padding: EdgeInsets.all(
        5.0,
      ),
      margin: EdgeInsets.symmetric(vertical: 5.0),
      child: Row(
        children: [
          Expanded(
            child: Text(
              AppUtills.getDateFormate(
                  historyModel.orderDetails!.orderDate.toString()),
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 13.0,
                color: Color(Constants.APP_COLOR),
              ),
            ),
          ),
          Expanded(
              child: Text(
            "${historyModel.buyer!.name}",
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 13.0,
              color: Color(Constants.APP_COLOR),
            ),
          )),
          Expanded(
            child: Text(
              "",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 13.0,
                color: Color(Constants.APP_COLOR),
              ),
            ),
          ),
          Expanded(
              flex: 2,
              child: Text(
                "",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 13.0,
                  color: Color(Constants.APP_COLOR),
                ),
              )),
        ],
      ),
    );
  }

  renderHeaderText(String text, int _flex) {
    return Expanded(
      flex: _flex,
      child: Text(
        Language().getString(text, selectedLang),
        textAlign: TextAlign.center,
        style: TextStyle(
            fontSize: 13.0,
            fontWeight: FontWeight.bold,
            color: Color(
              Constants.APP_COLOR,
            )),
      ),
    );
  }

  buildSearchFilterView() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(5.0),
        border: Border.all(
          color: Colors.grey,
        ),
      ),
      child: Row(
        children: <Widget>[
          Expanded(
              flex: 5,
              child: Row(
                children: <Widget>[
                  Expanded(
                    flex: 5,
                    child: Container(
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(5.0),
                            bottomLeft: Radius.circular(5.0),
                          )),
                      padding: EdgeInsets.only(left: 5),
                      child: TextFormField(
                        controller: _searchController,
                        onChanged: onSearchTextChanged,
                        style: TextStyle(fontFamily: Constants.INDIAN_RUPEE),
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: Language()
                              .getString(Constants.SEARCH, selectedLang),
                        ),
                      ),
                    ),
                  ),
                  _searchController.text.isNotEmpty
                      ? Container(
                          color: Colors.white,
                          child: IconButton(
                              icon: Icon(
                                Icons.close,
                                color: Colors.red,
                                size: 20.0,
                              ),
                              onPressed: () {
                                setState(() {
                                  _searchController.clear();
                                });
                                onSearchTextChanged(_searchController.text);
                              }))
                      : new Container()
                ],
              )),
          Container(
            color: Colors.grey,
          ),
          Container(
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                    topRight: Radius.circular(5.0),
                    bottomRight: Radius.circular(5.0))),
            child: IconButton(
                icon: Icon(
                  Icons.date_range,
                  size: 30.0,
                  color: Colors.blue,
                ),
                onPressed: () {
                  if (isOpenDateFilterView) {
                    setState(() {
                      isOpenDateFilterView = !isOpenDateFilterView;
                    });
                  } else {
                    setState(() {
                      isOpenDateFilterView = true;
                    });
                  }
                }),
          ),
        ],
      ),
    );
  }

  buildDateFilterView() {
    return DateFilterUtill(
      fromDate: fromDate,
      toDate: toDate,
      onFromDateSelected: (value) {
        setState(() {
          fromDate = value;
        });
      },
      onToDateSelected: (value) {
        setState(() {
          toDate = value;
        });
      },
      onSearchParms: () {
        setState(() {
          isLoadingProgress = true;
          isShowFloatButton = true;
        });
        String params =
            "?${Constants.DATE_FROM}$fromDate&${Constants.DATE_TO}$toDate";
        loadPendingOrdersData(params);
      },
    );
  }

  onSearchTextChanged(String text) async {
    showLoaderText = Constants.LOADING;
    isForSearchFilter = true;
    if (text.isEmpty) {
      // isLoading = false;
      setState(() {
        isLoadingProgress = true;
      });
      String params =
          "?${Constants.DATE_FROM}$fromDate&${Constants.DATE_TO}$toDate";
      loadPendingOrdersData(params);
    } else {
      String params =
          "?name=$text&${Constants.DATE_FROM}$fromDate&${Constants.DATE_TO}$toDate";

      loadPendingOrdersData(params);
    }
  }

  Future<List<PendingProductsDAO>> getPendingProductsData(String parms) async {
    setState(() {
      pendingOrdersList.clear();
    });

    String body = json
        .encode({"buId": buId, "productId": widget.productId, "filters": {}});

    var response = await _transactionService
        .findPendingProductsByProductId(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<PendingProductsDAO> list = [];

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      var data = resObj['results'];
      for (var i in data) {
        list.add(PendingProductsDAO.fromJson(i));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return list;
  }
}
