import 'package:vyaparlive/service/api_service/TransactionApiService.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Reports/DownloadAllReports.dart';
import 'package:vyaparlive/Reports/InvoiceAmountAlign.dart';
import 'package:vyaparlive/Transaction/ListOfTransactions.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/DateFilterUtil.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/invoice_view/InvoiceDesingView.dart';
import 'package:vyaparlive/model/ProductHistoryModel.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'dart:convert';

import 'package:vyaparlive/utills/vyapar_info.dart';

class ProductHistoryPage extends StatefulWidget {
  final String? productId;
  final bool isFromSalesReport;
  final bool isFromBuyReport;
  final bool isForRawMaterialReport;
  final bool isForSalableReport;
  final String? filterStartDate;
  final String? filterEndDate;
  ProductHistoryPage(
      {this.productId,
      this.isFromSalesReport = false,
      this.isFromBuyReport = false,
      this.isForRawMaterialReport = false,
      this.isForSalableReport = false,
      this.filterEndDate,
      this.filterStartDate});
  @override
  _ProductHistoryPageState createState() => _ProductHistoryPageState();
}

class _ProductHistoryPageState extends State<ProductHistoryPage> {
  String? buId = "";
  String? buName = "";
  final double calendarHeight = 40.0;
  TextEditingController _searchController = TextEditingController();
  DateTime selectedDate = DateTime.now();
  String formatedUserDob = "";
  String? fromDate = "";
  String? toDate = "";
  DateFormat formatter = DateFormat("yyyy-MM-dd");
  // ProgressDialog progressDialog;
  bool isOpenDateFilterView = true;
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  bool isLoadingProgress = true;
  String progressMessage = Constants.GETTING_DATA;
  bool isShowFloatButton = false;
  static String showLoaderText = Constants.NO_DATA_FOUND;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  DateTime mnthStartDate =
      DateTime.utc(DateTime.now().year, DateTime.now().month, 1);
  List<ProductHistoryModel> _productHistoryList = [];
  late ThemeData theme;
  late TextEditingController fromDateController = new TextEditingController();
  late TextEditingController toDateController = new TextEditingController();
  String productName = "";
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    buId = AppController.instance.getMyBuId;
    buName = AppController.instance.getBuName;
    if (widget.isForSalableReport || widget.isForRawMaterialReport) {
      fromDate = widget.filterStartDate;
      toDate = widget.filterEndDate;
      fromDateController.text = widget.filterStartDate!;
      toDateController.text = widget.filterEndDate!;
      isShowFloatButton = true;
    } else {
      fromDate = formatter.format(mnthStartDate);
      toDate = formatter.format(DateTime.now());
      fromDateController.text = fromDate!;
      toDateController.text = toDate!;
    }

    loadProductData();
  }

  loadProductData({String name = "", String invoiceNo = ""}) async {
    if (await NetworkStatus.getInternetStatus()) {
      List<ProductHistoryModel> fetchProductHistory = [];
      setState(() {
        fetchProductHistory.clear();
      });
      Map<String, dynamic> mapData = {
        "DateFrom": fromDateController.text,
        "DateTo": toDateController.text,
        "bill_no": invoiceNo,
        "name": name,
      };
      if (widget.isFromBuyReport) {
        fetchProductHistory = await TransactionApiService.instance
            .fetchBuyProductsHistory(
                context: context,
                productId: widget.productId!,
                mapData: mapData,
                langError: Language().getString(Constants.ERROR, selectedLang),
                langOk: Language().getString(Constants.OKAY_STR, selectedLang));
      } else if (widget.isFromSalesReport) {
        fetchProductHistory = await TransactionApiService.instance
            .fetchSellProductsHistory(
                context: context,
                productId: widget.productId!,
                mapData: mapData,
                langError: Language().getString(Constants.ERROR, selectedLang),
                langOk: Language().getString(Constants.OKAY_STR, selectedLang));
      } else {
        fetchProductHistory = await TransactionApiService.instance
            .fetchProductsHistory(
                context: context,
                productId: widget.productId!,
                mapData: mapData,
                langError: Language().getString(Constants.ERROR, selectedLang),
                langOk: Language().getString(Constants.OKAY_STR, selectedLang));
      }

      setState(() {
        isLoadingProgress = false;
        _productHistoryList.clear();
      });

      if (fetchProductHistory.length > 0) {
        setState(() => _productHistoryList.addAll(fetchProductHistory));

        if (fetchProductHistory[0].productData != null) {
          setState(() =>
              productName = fetchProductHistory[0].productData!.productName!);
        }
      } else {
        setState(() => showLoaderText = Constants.NO_DATA_FOUND);
      }
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
        body: Stack(
      children: [
        SafeArea(
          child: Scaffold(
            key: _scaffoldkey,
            backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
            floatingActionButton: (isShowFloatButton)
                ? FloatingActionButton(
                    backgroundColor: theme.colorScheme.primary,
                    onPressed: () {
                      setState(() {
                        isShowFloatButton = false;
                        isLoadingProgress = true;
                        fromDateController.text = fromDate!;
                        toDateController.text = toDate!;
                        _searchController.clear();
                      });
          
                      loadProductData();
                    },
                    child: Text(
                      Language().getString(Constants.CLEAR_FILTERS, selectedLang),
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white, fontSize: 11.0),
                    ))
                : null,
            appBar: AppBar(
              backgroundColor: Colors.transparent, //Color(Constants.APP_COLOR),
              centerTitle: true,
              elevation: 0,
              iconTheme: IconThemeData(color: theme.colorScheme.primary),
              title: AppbarName(
                  title: (widget.isFromBuyReport || widget.isFromSalesReport)
                      ? Language().getString(
                          widget.isFromSalesReport
                              ? Constants.PRODUCT_SALES_HISTORY
                              : Constants.PRODUCT_BUY_HISTORY,
                          selectedLang)
                      : Language()
                          .getString(Constants.PRODUCT_HISTORY, selectedLang),
                  buName: "$buName"),
          
              actions: [
                AppUtills.homeButton(context),
              ],
            ),
            body: Container(
                margin: EdgeInsets.symmetric(vertical: 5.0, horizontal: 5.0),
                child: Column(
                  children: [
                    // (_productHistoryList.length > 0)
                    //     ? this.showDownloadButton()
                    //     : Container(),
                    buildSearchView(),
                    buildDateFilterView(),
                    (_productHistoryList.length > 0)
                        ? Container(
                            padding: EdgeInsets.symmetric(vertical: 10),
                            child: RichText(
                              text: TextSpan(children: [
                                TextSpan(
                                  text: Language().getString(
                                      Constants.PRODUCT_NAME, selectedLang),
                                  style: TextStyle(
                                    fontSize: 15.0,
                                    fontFamily: StyleView.FONT_TITLE,
                                    fontWeight: FontWeight.bold,
                                    color: Color(Constants.APP_COLOR),
                                  ),
                                ),
                                TextSpan(
                                    text: " : $productName",
                                    style: TextStyle(
                                        color: Color(Constants.APP_COLOR),
                                        fontSize: 15.0,
                                        fontFamily: StyleView.FONT_TITLE))
                              ]),
                            ),
                          )
                        : Container(),
                    Container(
                        child: Expanded(
                      child: (_productHistoryList.length > 0)
                          ? SingleChildScrollView(
                              scrollDirection: Axis.vertical,
                              child: this.showProductData(),
                            )
                          : Center(
                              child: Text(Language()
                                  .getString(showLoaderText, selectedLang)),
                            ),
                    ))
                  ],
                )),
          ),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    ));
  }

  renderTableRowHeading(String hederText) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          child: Text(
            hederText,
            style: TextStyle(
                color: Color(Constants.APP_COLOR),
                fontWeight: FontWeight.bold,
                fontSize: 13.0),
          ),
        ),
      ),
    );
  }

  renderHeaderText(String text, int _flex) {
    return Expanded(
      flex: _flex,
      child: Text(
        Language().getString(text, selectedLang),
        textAlign: TextAlign.center,
        style: TextStyle(
            fontSize: 13.0,
            fontWeight: FontWeight.bold,
            color: Color(
              Constants.APP_COLOR,
            )),
      ),
    );
  }

  buildDateFilterView() {
    return Padding(
      padding: const EdgeInsets.only(top: 10.0),
      child: DateFilterUtill(
        isShowSearchButton: true,
        fromDate: "",
        toDate: "",
        fromDateController: fromDateController,
        toDateController: toDateController,
        onFromDateSelected: (value) {
          setState(() {
            fromDateController.text = value;
          });
        },
        onToDateSelected: (value) {
          setState(() {
            toDateController.text = value;
          });
        },
        onSearchParms: () {
          setState(() {
            isLoadingProgress = true;
            isShowFloatButton = true;
          });

          loadProductData();
        },
      ),
    );
  }

  onSearchTextChanged(String text) async {
    showLoaderText = Constants.LOADING;
    if (text.isEmpty) {
      setState(() {
        isLoadingProgress = true;
      });
      loadProductData();
    } else {
      if (CommonMethods.isNumeric(_searchController.text)) {
        loadProductData(invoiceNo: _searchController.text);
      } else {
        loadProductData(name: _searchController.text);
      }
    }
  }

  showProductData() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Table(
        border: TableBorder.all(
          color: Colors.black,
        ),
        defaultColumnWidth: FixedColumnWidth(110),
        children: [
          TableRow(children: [
            this.renderTableHeaders(
                Language().getString(Constants.DATE, selectedLang)),
            this.renderTableHeaders(Language().getString(
                widget.isFromSalesReport
                    ? Constants.SOLD_TO
                    : Constants.BUY_FROM,
                selectedLang)),
            this.renderTableHeaders(
                Language().getString(Constants.QUANTITY, selectedLang)),
            this.renderTableHeaders(
                Language().getString(Constants.BATCH_NO, selectedLang)),
            this.renderTableHeaders(
                Language().getString("Total Quantity", selectedLang)),
            this.renderTableHeaders(Language()
                .getString(Constants.PRODUCT_AMOUNT_TOTAL, selectedLang)),
            this.renderTableHeaders(
                Language().getString(Constants.INVOICE, selectedLang)),
            this.renderTableHeaders(
                Language().getString(Constants.INVOICE_AMOUNT, selectedLang)),
            this.renderTableHeaders(
                Language().getString(Constants.DELIVERY_STATUS, selectedLang)),
            this.renderTableHeaders(
                Language().getString("Payment Status", selectedLang))
          ]),
          for (int i = 0; i < _productHistoryList.length; i++)
            this.renderProductHistoryData(_productHistoryList[i])
        ],
      ),
    );
  }

  buildSearchView() {
    return Container(
      height: 40.0,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(5.0),
        border: Border.all(
          color: Colors.grey,
        ),
      ),
      child: Row(
        children: <Widget>[
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5.0),
                color: Colors.white,
              ),
              padding: EdgeInsets.only(left: 5),
              child: TextFormField(
                controller: _searchController,
                onChanged: onSearchTextChanged,
                style: TextStyle(fontFamily: 'IndianRupee'),
                decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: Language()
                        .getString(Constants.SEARCH_BY_NAME, selectedLang),
                    hintStyle: TextStyle(
                        color: Colors.black,
                        fontSize: 13.0,
                        fontFamily: StyleView.FONT_TITLE)),
              ),
            ),
          ),
          (_searchController.text.length > 0)
              ? Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                      topRight: Radius.circular(5.0),
                      bottomRight: Radius.circular(5.0),
                    ),
                    color: Colors.white,
                  ),
                  child: IconButton(
                      icon: Icon(
                        Icons.close,
                        color: Colors.red,
                        size: 20.0,
                      ),
                      onPressed: () {
                        CommonMethods.hideKeyboard(context);
                        _searchController.clear();
                        onSearchTextChanged(_searchController.text);
                      }),
                )
              : Container(),
        ],
      ),
    );
  }

  Widget renderTableHeaders(String? headerText) {
    return Container(
      alignment: Alignment.center,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Text(
          Language().getString(headerText, selectedLang),
          textAlign: TextAlign.center,
          style: TextStyle(
              color: Color(Constants.APP_COLOR),
              fontWeight: FontWeight.bold,
              fontSize: 13.0),
        ),
      ),
    );
  }

  renderTableData(InvoiceProducts products) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          child: Text("${products.quantity}",
              style:
                  TextStyle(fontSize: 13.0, color: Color(Constants.APP_COLOR))),
        ),
      ),
    );
  }

  renderProductHistoryData(ProductHistoryModel historyModel) {
    String name = "";
    if (historyModel.buyer!.id == AppController.instance.getMyBuId &&
        !widget.isFromSalesReport) {
      name = "${historyModel.seller!.name}";
    } else {
      name = "${historyModel.buyer!.name}";
    }

    String transactionType = "";
    if (historyModel.buyer!.isOffline! || historyModel.seller!.isOffline!) {
      transactionType = "Offline";
    } else {
      transactionType = "Online";
    }
    return TableRow(
      children: [
        Center(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              child: Text(
                  "${AppUtills.getDateFormate(historyModel.invocieDate.toString())}",
                  style: TextStyle(
                      fontSize: 13.0, color: Color(Constants.APP_COLOR))),
            ),
          ),
        ),
        Container(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: RichText(
              text: TextSpan(children: [
                TextSpan(
                  text: name,
                  style: TextStyle(
                    fontSize: 13.0,
                    fontFamily: StyleView.FONT_TITLE,
                    color: Color(Constants.APP_COLOR),
                  ),
                ),
                TextSpan(
                    text: " ($transactionType)",
                    style: TextStyle(
                        color: Colors.grey,
                        fontSize: 10.0,
                        fontFamily: StyleView.FONT_TITLE))
              ]),
            ),
          ),
        ),

        historyModel.productData!=null ? this.showInvoiceProductsQuantity(historyModel.productData!):Container(),
        historyModel.productData!=null ? this.showInvoiceProductsBatchNumber(historyModel.productData!):Container(),
        historyModel.productData!=null ? this.renderTableData(historyModel.productData!):Container(),
        historyModel.productData!=null ? this.showInvoiceProductsAmount(historyModel.productData!):Container(),
        InkWell(
          onTap: () {
            Navigator.push(
                context,
                PageTransition(
                    context: context,
                    page: InvoiceDesingPage(
                        transactionId: historyModel.transactionId,
                        invoiceNo: historyModel.billNo.toString(),
                        transactionDate: historyModel.createdDate.toString(),
                        transactionName: buName,
                        buyerName: historyModel.buyer!.name,
                        sellerName: historyModel.seller!.name,
                        invoiceId: historyModel.invoiceId)));
          },
          child: Padding(
            padding: const EdgeInsets.all(5.0),
            child: Text(
              Constants.INVOICE + " #${historyModel.billNo}",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 13.0,
                color: Color(Constants.APP_COLOR),
                decoration: TextDecoration.underline,
              ),
            ),
          ),
        ),
        InvoiceAmountAlign(
            invoiceAmount:
                CommonMethods.getCurrencyValues(historyModel.invoiceAmount)),
        InkWell(
          onTap: () {
            Navigator.push(
              context,
              PageTransition(
                  context: context,
                  page: ListOfTransactionsPage(
                    transactionId: historyModel.transactionId,
                  )),
            );
          },
          child: Padding(
            padding: const EdgeInsets.all(5.0),
            child: Text(
              historyModel.deliveryStatus!,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 13.0,
                color: Color(Constants.APP_COLOR),
                decoration: TextDecoration.underline,
              ),
            ),
          ),
        ),
        InkWell(
          onTap: () {
            Navigator.push(
              context,
              PageTransition(
                  context: context,
                  page: ListOfTransactionsPage(
                    transactionId: historyModel.transactionId,
                  )),
            );
          },
          child: Padding(
            padding: const EdgeInsets.all(5.0),
            child: Text(
              historyModel.paymentStatus!,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 13.0,
                color: Color(Constants.APP_COLOR),
                decoration: TextDecoration.underline,
              ),
            ),
          ),
        ),
      ],
    );
  }

  showDownloadButton() {
    String reqBody = "";
    String reqUrl = "";
    String fileName = "";
    if (widget.isFromBuyReport) {
      reqUrl = Constants.NEW_BASE_URL +
          "http-utils/reports/productBuyHistory"; //fieldsalesbyproduct/buy";
      fileName = "Purchased Products Report";
    } else if (widget.isFromSalesReport) {
      reqUrl = Constants.NEW_BASE_URL +
          "http-utils/reports/productSellHistory"; //fieldsalesbyproduct/sell";
      fileName = "Sales Product Report";
    } else {
      reqUrl =
          Constants.NEW_BASE_URL + "http-utils/reports/producttransactions";
      fileName = "Product Order History Report";
    }
    Map filtersData = {
      "DateFrom": fromDate,
      "DateTo": toDate,
    };
    if (CommonMethods.isNumeric(_searchController.text)) {
      filtersData['bill_no'] = _searchController.text;
      filtersData['name'] = "";
    } else {
      filtersData['name'] = _searchController.text;
      filtersData['bill_no'] = "";
    }
    reqBody =
        json.encode({"productId": widget.productId, "filters": filtersData});

    var encryptedData = VyaparInfo.encryptData(reqBody);
    Map map = {
      "data": encryptedData,
      "Authorization": AppController.instance.getAuthorizationKey
    };

    return DownloadAllReportsPage(
      url: reqUrl,
      isApiCallComplete: (apiCallCompleted) {
        if (apiCallCompleted) {
          setState(() {
            isLoadingProgress = false;
          });
        } else {
          setState(() {
            isLoadingProgress = true;
          });
        }
      },
      mapData: map,
      fileName: fileName,
      strDownload: Language().getString(Constants.DOWNLOAD, selectedLang),
    );
  }

  Widget showInvoiceProductsQuantity(InvoiceProducts _products) {
    return Container(
      child: Column(
        children: [
          // for (int i = 0; i < _products.length; i++)
          Container(
            alignment: Alignment.center,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                "${_products.quantity}",
                textAlign: TextAlign.start,
                style: TextStyle(
                  fontSize: 12.0,
                  color: Color(Constants.APP_COLOR),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget showInvoiceProductsAmount(InvoiceProducts _products) {
    return Container(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          // for (int i = 0; i < _products.length; i++)
          Container(
              child: InvoiceAmountAlign(
                  invoiceAmount: CommonMethods.getCurrencyValues(
                      _products.productAmountTotal)))
        ],
      ),
    );
  }

  Widget showInvoiceProductsBatchNumber(InvoiceProducts products) {
    return Container(
      child: Column(
        children: [
          // for (int i = 0; i < _products.length; i++)
          Container(
            alignment: Alignment.center,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                "${products.batchNumber}",
                textAlign: TextAlign.start,
                style: TextStyle(
                  fontSize: 12.0,
                  color: Color(Constants.APP_COLOR),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
