import 'package:vyaparlive/components/StyleView.dart';
import 'package:flutter/material.dart';

class PopupMenuItemDesingView extends StatelessWidget {
  final String? assetPath;
  final String? itemName;
  PopupMenuItemDesingView({this.assetPath, this.itemName});
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          margin: EdgeInsets.symmetric(horizontal: 2.0),
          child: ImageIcon(
            AssetImage(assetPath!),
            size: 15.0,
            color: Colors.black, //(Constants.APP_COLOR),
          ),
        ),
        SizedBox(width: 5.0),
        Expanded(
          child: Text(
            itemName!,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
                fontSize: 15.0,
                color: Colors.black, //(Constants.APP_COLOR),
                fontWeight: StyleView.fontMedium),
          ),
        ),
      ],
    );
  }
}
