import 'package:flutter/material.dart';

class SearchFilterView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
