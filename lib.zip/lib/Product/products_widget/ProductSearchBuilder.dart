import 'package:vyaparlive/components/Constants.dart';
import 'package:flutter/material.dart';

class ProductSearchBuilder extends StatelessWidget {
  ProductSearchBuilder(this._categoryItems, this.itemValue,
      {required this.onChanged});
  final List<String> _categoryItems;
  final String itemValue;
  final Function(String?) onChanged;
  @override
  Widget build(BuildContext context) {
    return Container(
        color: Colors.grey,
        child: Row(
          children: <Widget>[
            Expanded(
                flex: 1,
                child: Container(
                  color: Colors.white,
                  padding: EdgeInsets.only(left: 5),
                  child: TextFormField(
                    style: TextStyle(fontFamily: Constants.INDIAN_RUPEE),
                    decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: Constants.SEARCH_WITH_DOT),
                  ),
                )),
            Expanded(
                flex: 1,
                child: Container(
                  margin: EdgeInsets.only(left: 2),
                  color: Colors.white,
                  padding: EdgeInsets.only(left: 5),
                  child: DropdownButton<String>(
                    value: itemValue,
                    isExpanded: true,
                    hint: Text(Constants.CATEGORY),
                    underline: Container(),
                    onChanged: (String? newValue) {
                      onChanged(newValue);
                      // setState(() {
                      // itemValue = newValue;
                      // });
                    },
                    items: _categoryItems
                        .map<DropdownMenuItem<String>>((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(value),
                      );
                    }).toList(),
                  ),
                ))
          ],
        ));
  }
}
