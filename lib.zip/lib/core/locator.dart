import 'package:get_it/get_it.dart';
import 'package:vyaparlive/core/services/bu_services.dart';
import 'package:vyaparlive/core/services/login_service.dart';
import 'package:vyaparlive/core/services/notification_service.dart';
import 'package:vyaparlive/core/services/user_services.dart';
import 'package:vyaparlive/core/view_models/bu_model.dart';
import 'package:vyaparlive/core/view_models/homeview_model.dart';
import 'package:vyaparlive/core/view_models/login_view_model.dart';
import 'package:vyaparlive/core/view_models/user_view_model.dart';
import 'package:vyaparlive/core/view_models/version_view_model.dart';

GetIt locator = GetIt.instance;
void setUpLocator() {
  ///Registering services
  locator.registerLazySingleton<BuServices>(() => BuServices());
  locator.registerLazySingleton<LoginService>(() => LoginService());
  locator.registerLazySingleton<UserServices>(() => UserServices());
  locator
      .registerLazySingleton<NotificationService>(() => NotificationService());

  ///Registering view models
  locator.registerLazySingleton<LoginViewModel>(() => LoginViewModel());
  locator.registerLazySingleton<UserViewModel>(() => UserViewModel());
  locator.registerLazySingleton<BuViewModel>(() => BuViewModel());
  locator.registerLazySingleton<HomeViewModel>(() => HomeViewModel());
  locator.registerLazySingleton<VersionViewModel>(() => VersionViewModel());
}
