import 'package:flutter/cupertino.dart';

enum ViewState { Idle, Busy }

abstract class BaseModel extends ChangeNotifier {
  ViewState _state = ViewState.Idle;

  ViewState get viewState => this._state;

  setViewState(ViewState viewState) {
    this._state = viewState;
    notifyListeners();
  }
}
