import 'dart:convert';

import 'package:vyaparlive/components/Previlage.dart';
import 'package:vyaparlive/core/services/login_service.dart';
import 'package:vyaparlive/core/view_models/base_model.dart';
import 'package:vyaparlive/core/view_models/user_view_model.dart';
import 'package:vyaparlive/utills/SharePref.dart';
import 'package:vyaparlive/core/locator.dart';

enum LoginState {
  LOGIN_IDLE,
  LOGIN_IN_PROGRESS,
  LOGIN_ERROR,
  LOGIN_SUCCESS,
  CODE_SUCCESS,
  CODE_FAILURE,
  CODE_VALIDATE_IN_PROGRESS
}

class LoginViewModel extends BaseModel {
  LoginService? _service = locator<LoginService>();
  UserViewModel? _userViewModel = locator<UserViewModel>();

  Previlage? _userPrevileges;

  LoginState _loginState = LoginState.LOGIN_IDLE;

  String? _userId = "";

  String? get userId => this._userId;

  String? _loginError = "";

  String? _invitationId;

  String? get invitationId => this._invitationId;

  String? get loginError => this._loginError;

  Previlage? get loggedUserPrevileges => this._userPrevileges;

  setInvitationId(String id) {
    this._invitationId = id;
    notifyListeners();
  }

  setLoginError(String? message) {
    _loginError = message;
    notifyListeners();
  }

  LoginState get loginState => _loginState;

  void setLoginState(LoginState loginState) {
    this._loginState = loginState;
    notifyListeners();
  }

  ///setting userId
  void setUserId(String? userId) {
    this._userId = userId;
    notifyListeners();
  }

  ///login functionality
  Future<bool> login(String mobileNumber, String password) async {
    setLoginState(LoginState.LOGIN_IN_PROGRESS);

    /* preparing request body for login */
    String body = json.encode({"contact": mobileNumber, "password": password});

    /* service call */
    var response = await _service!.login(body).catchError((onError) {
      setLoginState(LoginState.LOGIN_ERROR);
      setLoginError(onError.toString());
      return null;
    });

    /* decode response.body */
    Map<String, dynamic>? data = json.decode(response.body);
    if (response.statusCode == 200) {
      setLoginState(LoginState.LOGIN_SUCCESS);
      updateSharedPrefs(data, mobileNumber, password);
      setUserId(data!['data']["userId"]);
      setPermissions(data);

      /* getting userdata by userId */
      _userViewModel!.getUserDataById(_userId!);

      return true;
    } else {
      setLoginState(LoginState.LOGIN_ERROR);
      setLoginError(
          data!.containsKey('message') ? data['message'] : "UNKNOWN ERROR");
      return false;
    }
  }

  Future<bool> validateInvitationCode(String mobileNum, String code) async {
    bool codeStatus = false;
    setLoginState(LoginState.CODE_VALIDATE_IN_PROGRESS);
    String reqBody = json.encode({"contact": mobileNum, "code": code});
    var response =
        await _service!.post_validateInvitation(reqBody).catchError((onError) {
      print("CODE ERROR: $onError");
      setLoginState(LoginState.CODE_FAILURE);
      return null;
    });

    // var responseBody = json.decode(response.body);
    if (response.statusCode == 200) {
      setLoginError("Invitation Accepted.");
      setLoginState(LoginState.CODE_SUCCESS);
      codeStatus = true;
    } else {
      setLoginState(LoginState.CODE_FAILURE);
      setLoginError("Invalid invitation please contact your invitee.");
      codeStatus = false;
    }

    return codeStatus;
  }

  void updateSharedPrefs(var userData, String mobileNum, String password) {
    SharePref().insertUserId(userData['data']["userId"]);
    SharePref().savePhoneNumber(mobileNum);
    SharePref().savePassword(password);
    SharePref().saveUserName(userData['data']['user_name']);
    SharePref().saveProfilePic(userData['data']['profile_pic']);
  }

  void setPermissions(response) {
    if (response != null && response["data"]["bu"] != null) {
      var permissionObject = response["data"]["bu"][0]["roles"];
      for (var data in permissionObject['permissions']) {
        _userPrevileges!.setPermissions(data["code"]);
      }
      notifyListeners();
    }
  }
}
