import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:vyaparlive/Transaction/buyer/DiscussionView.dart';
import 'package:vyaparlive/Transaction/ListOfTransactions.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/core/enums/notification_enum.dart';
import 'package:vyaparlive/core/enums/home_view_enum.dart';
import 'package:vyaparlive/core/services/notification_service.dart';
import 'package:vyaparlive/core/view_models/base_model.dart';
import 'package:vyaparlive/core/view_models/bu_model.dart';
import 'package:vyaparlive/model/BuBasicDataModel.dart';
import 'package:vyaparlive/core/locator.dart';
import 'package:vyaparlive/model/NotificationsDAO.dart';
import 'package:vyaparlive/order_form/OrderFormDetails.dart';
import 'package:vyaparlive/orders_view/OrderDetails.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:vyaparlive/utills/SharePref.dart';
import 'package:socket_io_client/socket_io_client.dart' as io;

class HomeViewModel extends BaseModel {
  io.Socket? socket;
  BuViewModel? _buViewModel = locator<BuViewModel>();
  NotificationService? _notificationService = locator<NotificationService>();
  BuildContext? mContext;
  String? _userId = "0";
  String mFilePath = "";
  String? get userId => this._userId;
  List<BuBasicDataModel> _buList = [];
  List<NotificationsDAO> notifications = [];
  List<String> notificationsViewedList = [];

  Map<String, dynamic>? pushNotificationData;

  /// bulist getter
  List<BuBasicDataModel> get buList => this._buList;

  ///Notifications getter
  List<NotificationsDAO> get notificationsList => this.notifications;

  setBuildContext(BuildContext context) {
    this.mContext = context;
  }

  getBuildContext() => this.mContext;

  ///HomeViewState initialize, getter and setter
  HomeViewState _homeViewState = HomeViewState.HOME_VIEW__BU_IN_PROGRESS;
  get homeViewState => this._homeViewState;
  setHomeViewState(HomeViewState _state) {
    _homeViewState = _state;
    notifyListeners();
  }

  ///FcmNotficationState initialize, getter and setter
  FcmNotficationState _fcmNotficationState =
      FcmNotficationState.FCM_NOTIFICATION_IDLE;
  get fcmNotificationState => this._fcmNotficationState;

  setFcmNotificationState(FcmNotficationState _state) {
    _fcmNotficationState = _state;
    notifyListeners();
  }

  setFcmMessageData(Map<String, dynamic>? message) {
    pushNotificationData = message;
    if (message != null) {
      // && message.containsKey('data')) {
      String? id =
          message['notification_id']; //message['data']['notification_id'];
      SharePref().getFCMMessageList().then((value) {
        List? messageIds = json.decode(value!);
        if (notificationsViewedList.contains(id)) {
          setFcmNotificationState(FcmNotficationState.FCM_NOTIFICATION_SEEN);
        } else if (messageIds!.contains(id)) {
          setFcmNotificationState(FcmNotficationState.FCM_NOTIFICATION_SEEN);
        } else {
          setFcmNotificationState(FcmNotficationState.NEW_FCM_NOTIFICATION);
        }
      });
    }

    notifyListeners();
  }

  ///AppNotificationState initialize, getter and setter
  AppNotificationState _appNotificationState =
      AppNotificationState.NOTIFICATION_IDLE;
  get aAppNotificationState => _appNotificationState;
  setAppNotificationState(AppNotificationState _state) {
    this._appNotificationState = _state;
    notifyListeners();
  }

  get viewedNotificationsList => this.notificationsViewedList;

  get getFcmMessage => this.pushNotificationData;

  // setFcmMessageData(Map<String, dynamic> message) {
  //   pushNotificationData = message;
  //   if (message != null && message.containsKey('data')) {
  //     String id = message['data']['google.message_id'];
  //     if (notificationsViewedList.contains(id)) {
  //       setFcmNotificationState(FcmNotficationState.FCM_NOTIFICATION_SEEN);
  //     } else {
  //       setFcmNotificationState(FcmNotficationState.NEW_FCM_NOTIFICATION);
  //     }
  //   }

  //   notifyListeners();
  // }

  // setViewednotification(String notificationId) {
  //   // notificationsViewedList.add(notificationId);

  // }

  Future<bool> setViewednotification(String notificationId) async {
    SharePref sharePref = SharePref();
    String? data = await sharePref.getFCMMessageList();
    List? messageIdsList = [];
    if (data != null) {
      messageIdsList = json.decode(data);
    }
    messageIdsList!.add(notificationId);

    sharePref.saveFCMMessageList(json.encode(messageIdsList));
    notificationsViewedList.add(notificationId);
    return true;
  }

  setUserId(String? userId) {
    this._userId = userId;
    notifyListeners();
  }

  setNotificationsList(var response) {
    notifications.clear();
    var data = json.decode(response.body);
    bool isString = false;
    if (data['data'] is String) {
      isString = true;
    }
    List<NotificationsDAO> list = [];
    if (!isString) {
      for (var dataObject in data['data']['results']) {
        /// need to compare with date
        NotificationsDAO notificationData =
            NotificationsDAO.fromJson(dataObject);

        list.add(notificationData);
      }
    }

    this.notifications = list;

    notifyListeners();
  }

  Future<List<BuBasicDataModel>> getHomeViewBuList(
      String userId, BuildContext context, List<BuBasicDataModel> list) async {
    setHomeViewState(HomeViewState.HOME_VIEW__BU_IN_PROGRESS);
    // await _buViewModel.getBuList(userId);

    // this._buList = _buViewModel.buList;
    // this._buList = await getBuList(userId, context);
    if (list.length > 0) {
      setHomeViewState(HomeViewState.HOME_VIEW_NOTIFICATIONS_IN_PROGRESS);

      /// Nageswarao
      // getNotifications(this.buList[0].id);
    }
    // setBuData();
    setHomeViewState(HomeViewState.HOME_VIEW_IDLE);

    // notifyListeners();
    return _buViewModel!.buList;
  }

  getNotifications(String buId) async {
    setAppNotificationState(AppNotificationState.NOTIFICATION_LOADING);
    var response = await _notificationService!
        .getNotifications(buId, buildParamsForGetTodayNotifications());
    if (response.statusCode == 200) {
      setNotificationsList(response);
    } else if (response.statusCode == 401) {
      CommonMethods.handleUnauthorizedAccess(this.mContext!);
    } else {
      String message = "";
      var data = json.decode(response.body);
      if (data.containsKey('message')) {
        message = data['message'];
      }
    }
    setAppNotificationState(AppNotificationState.NOTIFICATION_IDLE);
    setHomeViewState(HomeViewState.HOME_VIEW_IDLE);
  }

  String buildParamsForGetTodayNotifications() {
    DateFormat formatter = DateFormat("yyyy-MM-dd");
    String startDate = formatter.format(DateTime.now());
    String endDate = formatter.format(DateTime.now());
    String convertedDate = AppUtills.getOneDayAddedDate(endDate);
    return "?${Constants.DATE_FROM}$startDate&${Constants.DATE_TO}$convertedDate";
  }

  void setBuData() {
    if (buList.length > 0) {
      if (AppController.instance.getMyBuId == null ||
          AppController.instance.getMyBuId == "") {
        AppController.instance.setMyBuId = buList[0].id;
        AppController.instance.setBuName = buList[0].businessName;
      } else {
        for (int i = 0; i < buList.length; i++) {
          if (AppController.instance.getMyBuId == buList[i].id) {
            AppController.instance.setMyBuId = buList[i].id;
            AppController.instance.setBuName = buList[i].businessName;
          }
        }
      }
    }
    AppController.instance.buList = buList;
  }

  void notificationRoute(
      BuildContext context, Map<String, dynamic>? notification,{bool fromNotificationScreen=false}) async {
    if (homeViewState != HomeViewState.HOME_VIEW_IDLE && !fromNotificationScreen) {
      return;
    }

    if (fcmNotificationState == FcmNotficationState.FCM_NOTIFICATION_SEEN && !fromNotificationScreen) {
      return;
    }
    var notificationData = notification;
    //Platform.isIOS ? notification : notification!['data'];
    String? screen = notificationData!['notification_type'];
    String? id = notificationData["notification_id"];

    setFcmNotificationState(FcmNotficationState.FCM_NOTIFICATION_SEEN);
    AppController.instance.setViewednotification = id;
    String? transactionId = notificationData['transaction_id'];

    if (screen == Constants.PUSH_TRANSACTION_STARTED) {
      Navigator.push(
          context,
          new MaterialPageRoute(
              builder: (context) => DiscussionView(
                    transactionId: transactionId,
                    transactionName: "",
                    firebaseToken: "",
                  )));
    } else if (screen == Constants.PUSH_DISCUSSION_STARTED) {
      String transactionName = "";

      Navigator.push(
          context,
          new MaterialPageRoute(
              builder: (context) => DiscussionView(
                    transactionId: transactionId,
                    transactionName: transactionName,
                    firebaseToken: "",
                  )));
    } else if (screen == Constants.PUSH_TRANSACTION_PACKING) {
      this.naviToTransactionMenuPage(context, transactionId);
    } else if (screen == Constants.PUSH_TRANSACTION_ORDER) {
      this.naviToTransactionMenuPage(context, transactionId);
    } else if (screen == Constants.PUSH_TRANSACTION_INVOICE) {
      this.naviToTransactionMenuPage(context, transactionId);
    } else if (screen == Constants.PUSH_TRANSACTION_DELIVERY) {
      this.naviToTransactionMenuPage(context, transactionId);
    } else if (screen == Constants.PUSH_STOCK_RECONCILIATION_STARTED) {
      this.naviToTransactionMenuPage(context, transactionId);
    } else if (screen == Constants.PUSH_STOCK_RECONCILIATION_NOT_RESOLVED) {
      this.naviToTransactionMenuPage(context, transactionId);
    } else if (screen == Constants.PUSH_STOCK_RECONCILIATION_RESOLVED) {
      this.naviToTransactionMenuPage(context, transactionId);
    } else if (screen == Constants.PUSH_PAYMENT_RECONCILIATION_STARTED) {
      this.naviToTransactionMenuPage(context, transactionId);
    } else if (screen == Constants.PUSH_PAYMENT_RECONCILIATION_NOT_RESOLVED) {
      this.naviToTransactionMenuPage(context, transactionId);
    } else if (screen == Constants.PUSH_PAYMENT_RECONCILIATION_RESOLVED) {
      this.naviToTransactionMenuPage(context, transactionId);
    } else if (screen == Constants.PUSH_TRANSACTION_MENU_ORDER) {
      this.naviToTransactionMenuPage(context, transactionId);
    }if (screen == Constants.PUSH_CREATE_OFFLINE_ORDER) {
      Navigator.push(
          context,
          new MaterialPageRoute(
              builder: (context) => OrderFormDetailsPage(
                    orderFormId: transactionId,
                    transactionName: "",
                  )));
    } else {
      this.naviToTransactionMenuPage(context, transactionId);
    }
  }

  naviToTransactionMenuPage(BuildContext context, String? transactionId) {
    Navigator.push(
      context,
      PageTransition(
        context: context,
        page: ListOfTransactionsPage(
          transactionId: transactionId,
        ),
      ),
    );
  }

  void initSocket(String? transactionId) {
    String url = "${Constants.NEW_BASE_URL}communication";

    socket = io.io('$url', <String, dynamic>{
      'autoConnect': true,
      'transports': ['websocket']
    });

    socket!.on('connect', (_) {
      print("socket connected:");
      sendJoinChat(transactionId);
    });

    socket!.on('error', (error) {
      print(error);
    });
  }

  unSubscribes() {
    if (socket != null) {
      socket!.disconnect();
    }
  }

  void sendJoinChat(String? transactionId) {
    socket!.emit("joinChat", transactionId);
  }

  sendMessage(
      {String? type = "TEXT",
      String img = '',
      String message = '',
      String? transactionId,
      String? userName}) async {
    String timeStamp = DateTime.now().toUtc().toString();
    var messageObject = json.decode(message);
    var messageMap = Map<String, Object?>();
    messageMap['sender_id'] = AppController.instance.myBuId;

    messageMap['message'] = messageObject["message"];
    messageMap['bu_id'] = messageObject["bu_id"];

    messageMap['chat_id'] = transactionId;
    messageMap['type'] = type;

    messageMap['user_name'] = userName;
    messageMap['message_date'] = timeStamp;
    messageMap["order_placed_by"] = timeStamp;
    messageMap['order_status'] = 'success';

    String jsonString = json.encode(messageMap);

    socket!.emit('new_message', jsonString);
  }

  Future<List<BuBasicDataModel>> getBuList(
      String userId, BuildContext context) async {
    await _buViewModel!.getBuList(userId);

    this._buList = _buViewModel!.buList;
    setBuData();
    return _buViewModel!.buList;
  }
}
