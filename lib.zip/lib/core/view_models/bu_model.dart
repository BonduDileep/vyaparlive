import 'dart:convert';
import 'package:vyaparlive/core/locator.dart';
import 'package:vyaparlive/core/services/bu_services.dart';
import 'package:vyaparlive/core/view_models/base_model.dart';
import 'package:vyaparlive/model/BuBasicDataModel.dart';

class BuViewModel extends BaseModel {
  BuServices? _buServices = locator<BuServices>();
  // HomeViewModel _homeViewModel = locator<HomeViewModel>();
  List<BuBasicDataModel> _buList = [];

  /// bulist getter
  List<BuBasicDataModel> get buList => this._buList;

  /// bulist setter
  setBuList(var response) {
    var dataObj = response['data'];
    bool isString = false;
    if (dataObj is String) {
      isString = true;
    }
    List<BuBasicDataModel> list = [];
    if (!isString) {
      for (var noteJson in dataObj) {
        list.add(BuBasicDataModel.fromJson(noteJson));
      }
    }
    _buList = list;
  }

  getBuList(String userId) async {
    setViewState(ViewState.Busy);
    var response = await _buServices!.getOrganizationListByUserId(userId);
    if (response.statusCode == 200) {
      setBuList(json.decode(response.body));
    }
    setViewState(ViewState.Idle);
    notifyListeners();
  }
}
