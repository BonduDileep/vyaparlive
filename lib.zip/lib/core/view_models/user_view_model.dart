import 'dart:convert';

import 'package:vyaparlive/core/services/user_services.dart';
import 'package:vyaparlive/core/view_models/base_model.dart';
import 'package:vyaparlive/model/UserModel.dart';
import 'package:vyaparlive/core/locator.dart';

class UserViewModel extends BaseModel {
  UserServices? _services = locator<UserServices>();

  UserModel? _userModel;
  List<UserModel> _userList = [];

  UserModel? get userData => this._userModel;
  List<UserModel> get usersList => this._userList;

  setUsersList(List<UserModel> list) {
    _userList = list;
    notifyListeners();
  }

  setUserModel(UserModel userModel) {
    this._userModel = userModel;
    notifyListeners();
  }

  /// getting complete user detauls by userId
  void getUserDataById(String userId) async {
    var response = await _services!.getUserById(userId).catchError((onError) {
      print("GETTING USER ERROR: $onError");
      return null;
    });

    var data = json.decode(response.body);
    if (response.statusCode == 200) {
      try {
        setUserModel(UserModel.fromJson(data['data'][0]));
      } catch (e) {
        print("GETTING USER ERROR: $e");
      }
    } else {
      print("GETTING USER ERROR: " + data['message']);
    }
  }

  /// getting users list by buId
  void getAllUsersByBuId(String buId) async {
    var response = await _services!.getUserById(buId).catchError((onError) {
      print("ERROR WHILE GETTING USERS LIST BY BU_ID: $onError");
      return null;
    });

    var data = json.decode(response.body);
    if (response.statusCode == 200) {
      List<UserModel> _users = [];
      for (var user in data['data']) {
        _users.add(UserModel.fromJson(user));
      }

      setUsersList(_users);
    } else {
      print("ERROR WHILE GETTING USERS LIST BY BU_ID: $data['message']");
    }
  }
}
