import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
// import 'package:install_plugin_v2/install_plugin_v2.dart';
import 'package:path_provider/path_provider.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/core/enums/home_view_enum.dart';
import 'package:vyaparlive/core/view_models/base_model.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/service/app_version_service.dart';

class VersionViewModel extends BaseModel {
  // NotificationService _notificationService = locator<NotificationService>();
  AppVersionGrpcService _versionGrpcService = AppVersionGrpcService();
  String mFilePath = "";
  String _downloadPercentage = "0%";

  ///Version check state initialize, getter and setter
  VersionCheckState _versionCheckState = VersionCheckState.NO_VERION_CHANGE;

  get versionCheckState => _versionCheckState;

  setVersionCheckState(VersionCheckState _state) {
    _versionCheckState = _state;
    notifyListeners();
  }

  ///Version check state initialize, getter and setter
  ApkDownloadingState _apkDownloadingState = ApkDownloadingState.DOWNLOAD_IDLE;
  get apkDownloadingState => _apkDownloadingState;
  setApkDownloadingState(ApkDownloadingState _state) {
    _apkDownloadingState = _state;
    notifyListeners();
  }

  get downloadedPercentage => _downloadPercentage;
  setApkDownloadProgress(String progress) {
    this._downloadPercentage = progress;
    notifyListeners();
  }

  // Future<bool> getVersion() async {
  //   bool isVersionUpdate = false;
  //   // PackageInfo packageInfo = await PackageInfo.fromPlatform();

  //   // String appName = packageInfo.appName;
  //   // String packageName = packageInfo.packageName;
  //   // String version = packageInfo.version;
  //   // int buildNumber = int.parse(packageInfo.buildNumber);

  //   // String projectCode=await GetVersion.projectCode;
  //   var response = await _notificationService.versioncheck();
  //   if (response.statusCode == 200) {
  //     var data = json.decode(response.body);
  //     bool isString = false;
  //     if (data['data'] is String) {
  //       isString = true;
  //     }

  //     if (!isString) {
  //       num versionString = data['data']['version'];

  //       if (versionString > Constants.APP_VERSION) {
  //         isVersionUpdate = true;
  //         setVersionCheckState(VersionCheckState.NEW_VERSION_AVAILABLE);
  //       } else {
  //         setVersionCheckState(VersionCheckState.NO_VERION_CHANGE);
  //       }
  //     }
  //   }
  //   return isVersionUpdate;
  // }

  Future<void> downloadApkFile() async {
    String file = "vyapar_live.apk";
    Dio dio = Dio();
    try {
      String downloadsDirectory =
          (await getExternalStorageDirectory())!.absolute.path;

      mFilePath = "$downloadsDirectory/$file";
      // deleteFile(mFilePath);
      await dio.download(Constants.APK_URL, mFilePath,
          onReceiveProgress: (rec, total) async {
        setApkDownloadingState(ApkDownloadingState.DOWNLOAD_IN_PROGRESS);
        double progress = ((rec / total) * 100);
        setApkDownloadProgress(progress.toStringAsFixed(0) + "%");

        if (progress == 100) {
          setApkDownloadingState(ApkDownloadingState.DOWNLOAD_COMPLETED);

          //show install fields
        }
      });
    } catch (e) {
      print("$e");
      setApkDownloadingState(ApkDownloadingState.DOWNLOAD_IDLE);
    }
  }

  void onClickInstallApk() async {
    if (mFilePath.isEmpty) {
      print('make sure the apk file is set');
      return;
    }

    // InstallPlugin.installApk(mFilePath, 'com.example.apanavyapar')
    //     .then((result) {
    //   print('install apk $result');
    //   if (result == 'Success') {
    //     // deleteFile(mFilePath);
    //     // setApkDownloadingState(ApkDownloadingState.DOWNLOAD_IDLE);
    //   }
    // }).catchError((error) {
    //   print('install apk error: $error');
    // });
    // Map<PermissionGroup, PermissionStatus> permissions =
    //     await PermissionHandler().requestPermissions([PermissionGroup.storage]);
    // if (permissions[PermissionGroup.storage] == PermissionStatus.granted) {

    // } else {
    //   print('Permission request fail!');
    // }
  }

  Future<void> deleteFile(String path) async {
    try {
      var file = File(path);

      if (await file.exists()) {
        // file exits, it is safe to call delete on it
        await file.delete();
      }
    } catch (e) {
      // error in getting access to the file
      print("DELETE FILE ERROR: $e");
    }
  }

  Future<bool> getVersion() async {
    bool isVersionUpdate = false;
    String body = json.encode({"version": Constants.APP_VERSION});
    var response =
        await _versionGrpcService.checkNewVersion(body).catchError((onError) {
      isVersionUpdate = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);

      if (data['newVersionAvailable']) {
        isVersionUpdate = true;
        setVersionCheckState(VersionCheckState.NEW_VERSION_AVAILABLE);
      } else {
        setVersionCheckState(VersionCheckState.NO_VERION_CHANGE);
      }
    } else {
      return isVersionUpdate = false;
    }
  
    return isVersionUpdate;
  }
}
