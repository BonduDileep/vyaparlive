import 'package:http/http.dart' as http;
import 'package:vyaparlive/components/Constants.dart';

class LoginService {
  Future<http.Response> validateInvitationCode(
      String invitationCode, String contactNumber) {
    var response = http.get(
      Uri.parse(Constants.NEW_BASE_URL +
          "invitation/code/" +
          invitationCode +
          "/" +
          contactNumber),
      headers: {
        'Content-type': 'application/json',
        'Accept': 'application/json',
      },
    );

    return response;
  }

  // ignore: non_constant_identifier_names
  Future<http.Response> post_validateInvitation(String body) {
    var response = http.post(
        Uri.parse(Constants.NEW_BASE_URL + "invitation/ac"),
        body: body,
        headers: {
          'Content-type': 'application/json',
          'Accept': 'application/json',
        });

    return response;
  }

  Future<http.Response> login(String body) {
    var response = http.post(Uri.parse(Constants.NEW_BASE_URL + "user/login"),
        body: body,
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        });

    return response;
  }
}
