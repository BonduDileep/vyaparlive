import 'package:http/http.dart' as http;
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/Constants.dart';

class NotificationService {
  /*
   * Getting Notifications list by bu id 
   * @param String userId
   * @return http response
   */
  Future<http.Response> getNotifications(String buId, String params) {
    var response = http.get(
      Uri.parse(
          Constants.NEW_BASE_URL + "lookup/notification/bu/" + buId + params),
      headers: {
        'Content-type': 'application/json',
        'authorization': AppController.instance.getAuthorizationKey
      },
    );
    return response;
  }

  /*
   * Getting Notifications list by bu id 
   * @param String userId
   * @return http response
   */
  Future<http.Response> versioncheck() {
    // NEW_BASE_URL + "lookup/yrApk",
    var response = http.get(
      Uri.parse(Constants.APK_VERSION_CHECK_URL),
      headers: {
        'Content-type': 'application/json',
      },
    );
    return response;
  }
}
