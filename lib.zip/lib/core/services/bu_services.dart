import 'package:http/http.dart' as http;
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/Constants.dart';

class BuServices {
  Map headers = {
    'Content-type': 'application/json',
    'Accept': 'application/json',
  };

  /*
   * Getting Bu list by user id 
   * @param String userId
   * @return http response
   */
  // "organization/userId/" + userId,
  Future<http.Response> getOrganizationListByUserId(String userId) {
    var response = http.get(
      Uri.parse(Constants.NEW_BASE_URL + "organization/v2/user/" + userId),
      headers: {
        'Content-type': 'application/json',
        'Accept': 'application/json',
        'authorization': AppController.instance.getAuthorizationKey
      },
    );

    return response;
  }
}
