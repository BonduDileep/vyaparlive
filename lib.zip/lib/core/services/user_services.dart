import 'package:http/http.dart' as http;
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/Constants.dart';

class UserServices {
  Future<http.Response> createuser(String body) {
    var response = http.post(Uri.parse(Constants.NEW_BASE_URL + "user"),
        headers: {
          'Content-Type': 'application/json',
          'authorization': AppController.instance.getAuthorizationKey
        },
        body: body);
    return response;
  }

  // ignore: non_constant_identifier_names
  Future<http.Response> updateUser_put(String body) {
    var response = http.put(Uri.parse(Constants.NEW_BASE_URL + "user"),
        headers: {
          'Content-Type': 'application/json',
          'authorization': AppController.instance.getAuthorizationKey
        },
        body: body);
    return response;
  }

  Future<http.Response> getUserById(String userId) {
    var response = http
        .get(Uri.parse(Constants.NEW_BASE_URL + "user/" + userId), headers: {
      'Content-Type': 'application/json',
      'authorization': AppController.instance.getAuthorizationKey
    });
    return response;
  }
}
