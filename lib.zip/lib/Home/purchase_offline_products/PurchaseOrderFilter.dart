import 'package:flutter/material.dart';

import '../../components/Constants.dart';
import '../../components/StyleView.dart';
import '../../config/Language.dart';

class PurchaseOrderFilter extends StatelessWidget {
  final String? selectedFilter;
  final String? selectedLang;
  final Function(String selectedValue) onFilterSelection;
  final VoidCallback onApplyFilter;
  final ThemeData theme;

  const PurchaseOrderFilter(
      {Key? key,
      this.selectedFilter,
      this.selectedLang,
      required this.onFilterSelection,
      required this.onApplyFilter,
      required this.theme})
      : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Container(
        child: IconButton(
            onPressed: () {
              this.buildProductFilterDialog(context);
            },
            icon: Icon(
              Icons.filter_alt,
              color: theme.colorScheme.primary,
            )));
  }

  buildProductFilterDialog(BuildContext context) {
    String? filterSelected = null;
    return showDialog(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) {
          return StatefulBuilder(builder: (context, StateSetter setState) {
            return Scaffold(
                backgroundColor: Colors.transparent,
                body: Center(
                  child: Container(
                    margin: EdgeInsets.symmetric(horizontal: 20, vertical: 70),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.all(Radius.circular(15.0)),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        Align(
                          alignment: Alignment.topRight,
                          child: GestureDetector(
                            onTap: () {
                              Navigator.of(context).pop();
                            },
                            child: Padding(
                              padding: EdgeInsets.all(5.0),
                              child: Icon(
                                Icons.close,
                                color: Colors.red,
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 2.5,
                        ),
                        Text(
                          Language()
                              .getString(Constants.SORT_BY_STR, selectedLang),
                          style: TextStyle(
                              fontSize: StyleView.FONT_SIZE_18,
                              fontFamily: StyleView.FONT_TITLE),
                          textAlign: TextAlign.center,
                        ),
                        SizedBox(
                          height: 2.5,
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width,
                          height: 2,
                          color: Colors.grey,
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        Container(
                          child: Row(
                            children: [
                              Radio(
                                  materialTapTargetSize:
                                      MaterialTapTargetSize.shrinkWrap,
                                  value: Constants.ALL,
                                  groupValue: filterSelected,
                                  activeColor: Color(Constants.APP_COLOR),
                                  onChanged: (dynamic selectedValue) {
                                    setState(() {
                                      filterSelected = selectedValue;
                                    });
                                    onFilterSelection(selectedValue);
                                  }),
                              Text(
                                Language().getString(
                                    Constants.ALL, selectedLang),
                              )
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        
                        Container(
                          child: Row(
                            children: [
                              Radio(
                                  materialTapTargetSize:
                                      MaterialTapTargetSize.shrinkWrap,
                                  value: Constants.RAW_MATERIAL,
                                  groupValue: filterSelected,
                                  activeColor: Color(Constants.APP_COLOR),
                                  onChanged: (dynamic selectedValue) {
                                    setState(() {
                                      filterSelected = selectedValue;
                                    });
                                    onFilterSelection(selectedValue);
                                  }),
                              Text(
                                Language().getString(
                                    Constants.RAW_MATERIAL, selectedLang),
                              )
                            ],
                          ),
                        ),
                        Container(
                          child: Row(
                            children: [
                              Radio(
                                  materialTapTargetSize:
                                      MaterialTapTargetSize.shrinkWrap,
                                  value: Constants.CONSUMABLE_GOODS,
                                  groupValue: filterSelected,
                                  activeColor: Color(Constants.APP_COLOR),
                                  onChanged: (dynamic selectedValue) {
                                    setState(() {
                                      filterSelected = selectedValue;
                                    });
                                    onFilterSelection(selectedValue);
                                  }),
                              Text(
                                Language().getString(
                                    Constants.CONSUMABLE_GOODS, selectedLang),
                              )
                            ],
                          ),
                        ),
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            shape: RoundedRectangleBorder(
                                borderRadius: new BorderRadius.circular(10.0)),
                            backgroundColor: theme.colorScheme.primary,
                            textStyle: TextStyle(color: Colors.white),
                            elevation: 0,
                          ),
                          onPressed: () {
                            onApplyFilter();
                            Navigator.of(context).pop();
                          },
                          child: Text(
                            Language().getString(
                                Constants.APPLY_FILTER, selectedLang),
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontFamily: StyleView.FONT_TITLE),
                          ),
                        ),
                        SizedBox(height: 10)
                      ],
                    ),
                  ),
                ));
          });
        });
  }
}
