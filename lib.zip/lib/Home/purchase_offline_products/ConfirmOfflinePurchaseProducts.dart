import 'dart:convert';

import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Transaction/TransactionsPage.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/BuListModel.dart';
import 'package:vyaparlive/model/BusinessUnitModel.dart';
import 'package:vyaparlive/model/Contacts.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/ModelProduct.dart';
import 'package:vyaparlive/model/bu_model/LocationsModel.dart';
import 'package:vyaparlive/service/bu_list_grpc_service.dart';
import 'package:vyaparlive/service/invitation_services.dart';
import 'package:vyaparlive/service/organization_service.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:vyaparlive/utills/SharePref.dart';
import 'package:clipboard/clipboard.dart';
import 'package:custom_searchable_dropdown/custom_searchable_dropdown.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
// import 'package:share/share.dart';
import 'package:toast/toast.dart';

class ConfirmProducts extends StatefulWidget {
  final List<ModelProduct> productList;
  final String? offlineBuyerName;
  final String? offlineBuyerId;
  final String? offlineSellerName;
  final String? offlineSellerId;
  final bool? directOrder;
  ConfirmProducts({
    required this.productList,
    this.directOrder = false,
    this.offlineBuyerName,
    this.offlineBuyerId,
    this.offlineSellerId,
    this.offlineSellerName,
    super.key,
  });

  @override
  State<ConfirmProducts> createState() => _ConfirmProductsState();
}

class _ConfirmProductsState extends State<ConfirmProducts> {
  late ThemeData theme;
  bool isLoadingProgress = false;
  String progressMessage = Constants.PLEASE_WAIT;
  List<ModelProduct> _productList = [];
  late List<TextEditingController> quantityController = [];
  // late List<ModelProduct> selectedProducts = [];
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  List<BuListModel> _buList = [];
  BuListModel? contactData;
  late InvitationService _invitationService;
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  late BuListGrpcService _buListGrpcService;
  late String? userName;
  late String? userId;
  late List<num> unitPrice = [];
  late TextEditingController _searchController = new TextEditingController();
  List<Contacts> connectionsList = [];
  Contacts? connectionData;
  String? connectionType;
  late OrganizationService _organizationService;
  List<Locations> locationsList = [];
  Locations? locationsData;
  late BuListGrpcService _transactionService;
  String shareSellerName = '';
  String shareBuyerName = '';
  late SharedPreferences sharedPreferences;
  @override
  void initState() {
    super.initState();
    shareSellerName = widget.offlineSellerName!;
    theme = AppTheme.vyaparTheme;
    _invitationService = InvitationService();
    _buListGrpcService = BuListGrpcService();
    _organizationService = OrganizationService();
    _transactionService = BuListGrpcService();
    _productList.addAll(widget.productList);
    // selectedProducts.addAll(widget.productList);
    for (int i = 0; i < _productList.length; i++) {
      quantityController.add(
          new TextEditingController(text: _productList[i].quantity.toString()));
    }
    SharePref().getUserId().then((value) => userId = value);
    SharePref().getUserName().then((value) => userName = value);
    // loadGetContacts('');
  }

  loadGetContacts(String params) async {
    if (await NetworkStatus.getInternetStatus()) {
      isLoadingProgress = true;
      if (params == 'Offline') {
        await getAllContacts(params).then((value) => _buList.addAll(value));
        if (_buList.length == 0) {
          Dialogs.yesCancelDialog(
              context,
              Language().getString(Constants.ERROR, selectedLang),
              Language().getString(
                  Constants.USER_HAS_NO_OFFLINE_CONNECTIONS, selectedLang),
              Language().getString(Constants.OKAY_STR, selectedLang),
              "",
              false);
          return;
        }
        showContactsList();
        return;
      }
      if (params == 'Online') {
        await getConnections().then((value) => connectionsList.addAll(value));
        await getLocationsData().then((value) => {
              if (value.length > 0)
                {locationsList.addAll(value[0].locationsList!)}
            });
        if (connectionsList.length == 0) {
          return Dialogs.yesCancelDialog(
              context,
              Language().getString(Constants.ERROR, selectedLang),
              Language().getString(
                  Constants.USER_HAS_NO_ONLINE_CONNECTIONS, selectedLang),
              Language().getString(Constants.OKAY_STR, selectedLang),
              "",
              false);
        }
        if (locationsList.length == 0) {
          return Dialogs.yesCancelDialog(
              context,
              Language().getString(Constants.ERROR, selectedLang),
              Language().getString(
                  Constants.BUSSINESS_UNIT_HAS_NO_LOCATIONS, selectedLang),
              Language().getString(Constants.OKAY_STR, selectedLang),
              "",
              false);
        }
        showConnectionsListDialog();
        return;
      }
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<Contacts>> getConnections() async {
    setState(() {
      connectionsList.clear();
    });
    String body =
        json.encode({"buId": AppController.instance.getMyBuId, "filters": {}});

    var response = await _invitationService
        .findAllConnections_grpc(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<Contacts> _model = [];

    setState(() => isLoadingProgress = false);

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);

      for (var noteJson in resObj['results']) {
        _model.add(Contacts.fromJson(noteJson));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    return _model;
  }

  Future<List<BusinessUnitModel>> getLocationsData() async {
    setState(() {
      locationsList.clear();
      isLoadingProgress = true;
      progressMessage = Constants.GETTING_DATA;
    });
    String body = json.encode({"id": AppController.instance.getMyBuId});
    var response = await _organizationService
        .getOrganizationDataById(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<BusinessUnitModel> _list = [];

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var object = json.decode(_grpcResponse.message!);
      _list.add(BusinessUnitModel.fromJson(object[0]));
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }

    return _list;
  }

  Future<List<BuListModel>> getAllContacts(String params) async {
    String body = json.encode({
      "buId": AppController.instance.getMyBuId,
      "filters": {"name": ''}
    });

    var response = await _invitationService
        .getContactsByBuId_grpc(
            body, AppController.instance.getAuthorizationKey, params)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    setState(() {
      isLoadingProgress = false;
    });
    List<BuListModel> _list = [];
    GRPCResponse data = response;
    if (!data.getIsError! && !data.getIsException!) {
      var resBody = json.decode(data.message!);
      var resultArray = resBody['results'];
      for (var object in resultArray) {
        _list.add(BuListModel.fromJson(object));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          data.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }

    return _list;
  }

  Map<String, dynamic> prepareBody(
      {required String sellerId,
      required String sellerName,
      required String recordId,
      required bool isOfflineConnection}) {
    Map<String, dynamic> body;
    body = {
      "id": "",
      "is_offline": isOfflineConnection,
      "order_type":isOfflineConnection?"offline_direct_buy":"online_direct_buy",
      "buyer": {
        "id": (widget.directOrder!)
            ? widget.offlineBuyerId
            : AppController.instance.getMyBuId,
        "name": (widget.directOrder!)
            ? widget.offlineBuyerName
            : AppController.instance.buName,
      },
      "seller": {
        "id": (recordId.isNotEmpty) ? recordId : sellerId,
        "name": sellerName,
        "is_offline": isOfflineConnection,
      },
      "sender": {
        "id": AppController.instance.getMyBuId,
      },
      "ctr": {"type": "", "Agent": "", "transaction_ref": ""},
      "discussion": {
        "initiator": sellerId,
        "initiator_user": sellerName,
        "message_start_date": "",
        "confirmation_message": [],
        "confirmation_status": ""
      }
    };
    return body;
  }

  postBodyForDirectOrder(Map<String, dynamic> data) async {
    setState(() => isLoadingProgress = true);

    String body = json.encode(data);

    var response = await _transactionService
        .createDirectTransaction(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;

    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);
      prepareTransactionsProductsBody(data);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  postBodyForProductsBuy({required Map<String, dynamic> data}) async {
    setState(() => isLoadingProgress = true);

    String body = json.encode(data);
    // return;
    var response = await _buListGrpcService
        .beginTransaction(body, AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);
      prepareTransactionsProductsBody(data);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  prepareTransactionsProductsBody(String? transactionId) async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = "Sending products..";
    });

    List<Map<String, dynamic>> productsArray = [];
    var productsObject;
    for (int i = 0; i < _productList.length; i++) {
      if (_productList[i].quantity != 0 && _productList[i].name!.isNotEmpty) {
        productsObject = {
          "id": _productList[i].id,
          "unit_price": 0,
          "quantity": _productList[i].quantity,
          "total": 0,
          "offer_selected": false,
          "product_name": _productList[i].name
        };
        productsArray.add(productsObject);
      }
    }

    Map data = {
      "id": transactionId,
      "order_details": {
        "user_id": userId,
        "user_name": userName,
        "products": productsArray
      }
    };
    if (connectionType == 'Online' && locationsData != null) {
      data['ship_to_address'] = locationsData!.locationId;
    }
    String body = json.encode(data);

    var response = await _buListGrpcService
        .createPlaceOrder(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
        progressMessage = "";
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    setState(() {
      isLoadingProgress = false;
      progressMessage = "";
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      if (connectionType == 'Online') {
        final action = await Dialogs.yesCancelDialog(
            context,
            Language().getString(Constants.SUCCESS, selectedLang),
            Language().getString(
                Constants.ORDER_PLACED_SUCCSESSFULLY_ALERT_STRING,
                selectedLang),
            Language().getString(Constants.OK_STRING, selectedLang),
            "",
            false);
        if (action == DialogAction.yes) {
          Navigator.pushAndRemoveUntil(
              context,
              new MaterialPageRoute(builder: (context) => TransactionsView()),
              (route) => false);
        }
        return;
      }
      String url = '${Constants.WHATSAPP_INVOICE_URL}$transactionId/shared-po';
      return showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
          actions: [
            Container(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  TextButton(
                      onPressed: () {
                        if (kIsWeb) {
                          openCopyAlertDialog(context, url);
                        } else {
                          String message =
                              'Hello $shareSellerName,\n\n${AppController.instance.buName} has generated a new PO(Purchase Order), please click below url to view the details\n\n$url';

                          SharePlus.instance.share(ShareParams(
                            text: message,
                            title: "${Constants.APANAVYAPAR} PO",
                            subject: "${Constants.APANAVYAPAR} PO",
                          ));
                          // Share.share(message,
                          //     subject: "${Constants.APANAVYAPAR} PO");
                        }
                      },
                      child: Text(
                          Language().getString(Constants.SHARE, selectedLang),
                          style: TextStyle(
                            fontSize: 18.0,
                            color: Color(
                              Constants.APP_COLOR,
                            ),
                          ))),
                  TextButton(
                      onPressed: () {
                        Navigator.pushAndRemoveUntil(
                            context,
                            new MaterialPageRoute(
                                builder: (context) => TransactionsView()),
                            (route) => false);
                      },
                      child: Text(
                          Language()
                              .getString(Constants.OKAY_STR, selectedLang),
                          style: TextStyle(
                            fontSize: 18.0,
                            color: Color(
                              Constants.APP_COLOR,
                            ),
                          ))),
                ],
              ),
            )
          ],
          content: Container(
            child: Text(
              Language().getString(
                  Constants.ORDER_PLACED_SUCCSESSFULLY_ALERT_STRING,
                  selectedLang),
            ),
          ),
        ),
      );
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  openCopyAlertDialog(BuildContext context, String url) {
    return showDialog(
        barrierDismissible: false,
        context: context,
        barrierColor: Colors.black54,
        builder: (BuildContext context) {
          return AlertDialog(
            elevation: 100.0,
            contentPadding: EdgeInsets.fromLTRB(15.0, 0, 15.0, 0),
            backgroundColor: Colors.white,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(7.0))),
            actions: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  InkWell(
                    onTap: () => {
                      Navigator.of(context).pop(),
                    },
                    child: Text(
                      Constants.STR_CANCEL,
                      style: TextStyle(
                          color: theme.colorScheme.primary,
                          fontSize: 15,
                          fontWeight: StyleView.fontMedium),
                    ),
                  ),
                  InkWell(
                    onTap: () => {
                      FlutterClipboard.copy("$url").then((value) => {
                            print('copied'),
                            Toast.show("copied to clipboard",
                                duration: Toast.lengthShort,
                                gravity: Toast.bottom)
                          }),
                      Navigator.of(context).pop(),
                    },
                    child: Text(
                      "Copy",
                      style: TextStyle(
                          color: theme.colorScheme.primary,
                          fontSize: 15,
                          fontWeight: StyleView.fontMedium),
                    ),
                  )
                ],
              )
            ],
            titlePadding: EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 10.0),
            title: Text(
              Language().getString(Constants.STR_COPY_TO_SHARE, selectedLang),
              style: TextStyle(
                  color: theme.colorScheme.primary,
                  fontSize: 15,
                  fontWeight: StyleView.fontRegular),
            ),
            content: Container(child: Text("$url")),
          );
        });
  }

  showDialogForConnection() {
    return showDialog(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(15.0))),
              title: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Container(
                    child: Text(
                      Language()
                          .getString(Constants.SELECT_CONNECTION, selectedLang),
                      style: TextStyle(
                          color: theme.colorScheme.primary,
                          fontWeight: StyleView.fontMedium,
                          fontSize: 15.0),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      connectionType = null;
                      Navigator.of(context).pop();
                    },
                    child: Icon(
                      Icons.close,
                      color: Colors.red,
                    ),
                  ),
                ],
              ),
              content:
                  StatefulBuilder(builder: (context, StateSetter setState) {
                return Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Container(
                      width: MediaQuery.of(context).size.width,
                      height: 50,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                            borderRadius: new BorderRadius.circular(30.0),
                          ),
                          backgroundColor: theme.colorScheme.primary,
                          textStyle: TextStyle(
                              color: Colors.white,
                              fontFamily: StyleView.FONT_TITLE,
                              fontWeight: StyleView.fontMedium),
                          elevation: 3.0,
                        ),
                        onPressed: () => {
                          setState(() => connectionType = 'Offline'),
                          Navigator.of(context).pop(),
                          loadGetContacts("Offline"),
                        },
                        child: Padding(
                          padding: EdgeInsets.symmetric(vertical: 15),
                          child: Text(Language().getString(
                              Constants.OFFLINE_CONNECTIONS, selectedLang)),
                        ),
                      ),
                    ),
                    SizedBox(height: 20.0),
                    Container(
                      width: MediaQuery.of(context).size.width,
                      height: 50,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                            borderRadius: new BorderRadius.circular(30.0),
                          ),
                          backgroundColor: theme.colorScheme.primary,
                          textStyle: TextStyle(
                              color: Colors.white,
                              fontFamily: StyleView.FONT_TITLE,
                              fontWeight: StyleView.fontMedium),
                          elevation: 3.0,
                        ),
                        onPressed: () => {
                          setState(() => connectionType = "Online"),
                          Navigator.of(context).pop(),
                          loadGetContacts("Online"),
                        },
                        child: Padding(
                          padding: EdgeInsets.symmetric(vertical: 15),
                          child: Text(Language().getString(
                              Constants.ONLINE_CONNECTIONS, selectedLang)),
                        ),
                      ),
                    )
                  ],
                );
              }));
        });
  }

  Widget renderTableHeaders(String? headerText) {
    return Container(
      alignment: Alignment.center,
      padding: EdgeInsets.all(8.0),
      child: Text(
        Language().getString(headerText!, selectedLang),
        textAlign: TextAlign.center,
        style: TextStyle(
            color: Colors.black,
            fontWeight: StyleView.fontMedium,
            fontSize: 15.0),
      ),
    );
  }

  showContactsList() {
    return showDialog(
        context: context,
        builder: (context) => AlertDialog(
              titlePadding: EdgeInsets.only(left: 20, right: 10, top: 10),
              title: Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      Language().getString(
                          Constants.SELECT_OFFLINE_CONNECTION, selectedLang),
                      style: TextStyle(
                        color: theme.colorScheme.primary,
                        fontSize: 16,
                        fontWeight: StyleView.fontMedium,
                      ),
                    ),
                    IconButton(
                        onPressed: () => Navigator.of(context).pop(),
                        icon: Icon(Icons.close, color: Colors.red)),
                  ],
                ),
              ),
              content: Container(
                height: 60.0,
                decoration: BoxDecoration(
                    color: Colors.white70,
                    border: Border.all(color: Colors.grey),
                    borderRadius: BorderRadius.circular(5)),
                // padding: EdgeInsets.only(left: 5, right: 5),
                child: CustomSearchableDropDown(
                  items: _buList.toList(),
                  dropDownMenuItems: _buList.map((item) => item.name).toList(),
                  label: Language().getString(
                      Constants.PLEASE_SELECT_CONNECTION, selectedLang),
                  labelStyle: TextStyle(
                      overflow: TextOverflow.ellipsis,
                      fontWeight: StyleView.fontMedium,
                      color: Colors.black,
                      fontSize: 14.0),
                  suffixIcon: Padding(
                      padding: const EdgeInsets.all(0.0),
                      child: Icon(
                        Icons.keyboard_arrow_down_outlined,
                        color: Colors.black,
                      )),
                  hint: Language().getString(
                      Constants.PLEASE_SELECT_CONNECTION, selectedLang),
                  dropdownHintText: Language().getString(
                      Constants.PLEASE_SELECT_CONNECTION, selectedLang),
                  onChanged: (value) {
                    if (value != null) {
                      Navigator.of(context).pop();
                      contactData = value;
                      shareSellerName = value!.name!;
                      Map<String, dynamic> data = prepareBody(
                          sellerId: value!.buId!,
                          sellerName: value!.name!,
                          recordId: value!.recordId!,
                          isOfflineConnection: true);
                      postBodyForProductsBuy(data: data);
                    }
                  },
                ),
              ),
            ));
  }

  showConnectionsListDialog() {
    return showDialog(
        context: context,
        builder: (context) => Container(
              padding: EdgeInsets.symmetric(vertical: 50, horizontal: 20),
              child: StatefulBuilder(
                builder: ((context, setState) {
                  return ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: AppBackgroundView(
                      body: Scaffold(
                        backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                        bottomNavigationBar: Padding(
                          padding: const EdgeInsets.only(
                              left: 10, right: 10, bottom: 30),
                          child: CommonButtonsView(
                            context: context,
                            b1Text: Language()
                                .getString(Constants.STR_CANCEL, selectedLang),
                            b2Text: Language().getString(
                                Constants.PLACE_ORDER_STR, selectedLang),
                            onb1Action: () => {
                              setState(() {
                                connectionType = null;
                                locationsData = null;
                                connectionData = null;
                              }),
                              Navigator.of(context).pop()
                            },
                            onb2Action: () async {
                              if (connectionData == null) {
                                Dialogs.yesCancelDialog(
                                    context,
                                    Language().getString(
                                        Constants.ERROR, selectedLang),
                                    Language().getString(
                                        Constants.PLEASE_SELECT_CONNECTION,
                                        selectedLang),
                                    Language().getString(
                                        Constants.OKAY_STR, selectedLang),
                                    "",
                                    false);
                                return;
                              }
                              if (locationsData == null) {
                                Dialogs.yesCancelDialog(
                                    context,
                                    Language().getString(
                                        Constants.ERROR, selectedLang),
                                    Language().getString(
                                        Constants
                                            .PLEASE_SELECT_SHIP_TO_LOCATION,
                                        selectedLang),
                                    Language().getString(
                                        Constants.OKAY_STR, selectedLang),
                                    "",
                                    false);
                                return;
                              }
                              shareSellerName = connectionData!.buName!;
                              Map<String, dynamic> data = prepareBody(
                                  sellerId: connectionData!.buId!,
                                  sellerName: connectionData!.buName!,
                                  recordId: '',
                                  isOfflineConnection: false);
                              Navigator.of(context).pop();
                              postBodyForDirectOrder(data);
                            },
                          ),
                        ),
                        body: Padding(
                          padding: const EdgeInsets.all(24.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: EdgeInsets.only(top: 16, bottom: 10),
                                child: Text(
                                  Language().getString(
                                      Constants.CONNECTIONS_STR, selectedLang),
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: StyleView.fontMedium),
                                ),
                              ),
                              Container(
                                height: 60.0,
                                decoration: BoxDecoration(
                                    color: Colors.white70,
                                    border: Border.all(color: Colors.grey),
                                    borderRadius: BorderRadius.circular(5)),
                                // padding: EdgeInsets.only(left: 5, right: 5),
                                child: CustomSearchableDropDown(
                                  items: connectionsList.toList(),
                                  dropDownMenuItems: connectionsList
                                      .map((item) => item.buName)
                                      .toList(),
                                  label: Language().getString(
                                      Constants.PLEASE_SELECT_CONNECTION,
                                      selectedLang),
                                  labelStyle: TextStyle(
                                      overflow: TextOverflow.ellipsis,
                                      fontWeight: StyleView.fontMedium,
                                      color: Colors.black,
                                      fontSize: 14.0),
                                  suffixIcon: Padding(
                                      padding: const EdgeInsets.all(0.0),
                                      child: Icon(
                                        Icons.keyboard_arrow_down_outlined,
                                        color: Colors.black,
                                      )),
                                  hint: Language().getString(
                                      Constants.PLEASE_SELECT_CONNECTION,
                                      selectedLang),
                                  dropdownHintText: Language().getString(
                                      Constants.PLEASE_SELECT_CONNECTION,
                                      selectedLang),
                                  onChanged: (value) {
                                    if (value != null) {
                                      setState(() => connectionData = value);
                                    }
                                  },
                                ),
                              ),
                              SizedBox(height: 20),
                              Padding(
                                padding: EdgeInsets.only(top: 16, bottom: 10),
                                child: Text(
                                  Language().getString(
                                      Constants.SHIP_TO_LOCATION, selectedLang),
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: StyleView.fontMedium),
                                ),
                              ),
                              Container(
                                height: 60.0,
                                decoration: BoxDecoration(
                                    color: Colors.white70,
                                    border: Border.all(color: Colors.grey),
                                    borderRadius: BorderRadius.circular(5)),
                                // padding: EdgeInsets.only(left: 5, right: 5),
                                child: CustomSearchableDropDown(
                                  items: locationsList.toList(),
                                  dropDownMenuItems: locationsList
                                      .map((item) => item.locationName)
                                      .toList(),
                                  label: Language().getString(
                                      Constants.PLEASE_SELECT_SHIP_TO_LOCATION,
                                      selectedLang),
                                  labelStyle: TextStyle(
                                      overflow: TextOverflow.ellipsis,
                                      fontWeight: StyleView.fontMedium,
                                      color: Colors.black,
                                      fontSize: 14.0),
                                  suffixIcon: Padding(
                                      padding: const EdgeInsets.all(0.0),
                                      child: Icon(
                                        Icons.keyboard_arrow_down_outlined,
                                        color: Colors.black,
                                      )),
                                  hint: Language().getString(
                                      Constants.PLEASE_SELECT_SHIP_TO_LOCATION,
                                      selectedLang),
                                  dropdownHintText: Language().getString(
                                      Constants.PLEASE_SELECT_SHIP_TO_LOCATION,
                                      selectedLang),
                                  onChanged: (value) {
                                    if (value != null) {
                                      // Navigator.of(context).pop();
                                      setState(() => locationsData = value);
                                      // Map<String, dynamic> data = prepareBody(
                                      //     sellerId: value!.id!,
                                      //     sellerName: value!.buName!,
                                      //     recordId: '');
                                      // postBodyForProductsBuy(data: data);
                                    }
                                  },
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                }),
              ),
            ));
  }

  Widget renderTableData(String value) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          child: Text("$value",
              style: TextStyle(
                  fontSize: 13,
                  color: Colors.black,
                  fontWeight: StyleView.fontRegular)),
        ),
      ),
    );
  }

  onUpdateTextFormPosition(int index, String value) {
    quantityController[index] = TextEditingController(text: value);
    quantityController[index].selection = TextSelection.fromPosition(
        TextPosition(offset: quantityController[index].text.length));
  }

  onIncrease(int index) {
    int findIndex = _productList
        .indexWhere((element) => element.id == _productList[index].id);
    if (findIndex != -1) {
      num? count = _productList[findIndex].quantity;
      count = count! + 1;
      setState(() {
        quantityController[index].text = "$count";
        _productList[findIndex].quantity = count;
        onUpdateTextFormPosition(index, "$count");
      });
      return;
    }
    num? count = 0;
    if (quantityController[index].text.isNotEmpty) {
      count = int.parse(quantityController[index].text);
    }
    count = count + 1;
    setState(() {
      quantityController[index].text = "$count";
      _productList.add(ModelProduct(
          id: _productList[index].id,
          name: _productList[index].name,
          quantity: count));
    });
  }

  onDecrease(int index) {
    num count = 0;
    if (quantityController[index].text.isEmpty) {
      return;
    }
    count = int.parse(quantityController[index].text);
    count = count - 1;
    if (count < 0) return;
    // if (count == 0) {
    // int findIndex = _productList
    //     .indexWhere((element) => element.id == _productList[index].id);
    // if (findIndex != -1) {
    //   setState(() {
    //     _productList.removeAt(findIndex);
    //     quantityController[index].clear();
    //   });
    // }
    // } else {
    int findIndex = _productList
        .indexWhere((element) => element.id == _productList[index].id);
    if (findIndex != -1) {
      setState(() {
        _productList[findIndex].quantity = count;
        quantityController[index].text = "$count";
        onUpdateTextFormPosition(index, "$count");
      });
    }
    // }
  }

  Widget dynamicTextFormField(int index) {
    return Container(
      child: Row(
        children: [
          IconButton(
              padding: EdgeInsets.zero,
              onPressed: () => onDecrease(index),
              icon: Icon(Icons.remove, color: Colors.black)),
          Container(
            width: 50.0,
            height: 25.0,
            decoration: AppUtills.boxDecoration(),
            child: TextFormField(
              controller: quantityController[index],
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 14, fontWeight: StyleView.fontRegular),
              keyboardType: TextInputType.numberWithOptions(signed: true),
              textInputAction: TextInputAction.done,
              decoration: InputDecoration(
                  hintText: "0",
                  contentPadding:
                      EdgeInsets.only(bottom: Constants.CONTENT_PADDING_18_13),
                  hintStyle: TextStyle(
                      fontSize: 14, fontWeight: StyleView.fontRegular),
                  border: InputBorder.none),
              inputFormatters: [
                new LengthLimitingTextInputFormatter(5),
                CommonMethods.inputTextFormatter(isNumber: true)
              ],
              onChanged: (value) {
                if (value.isEmpty) {
                  int findIndex = _productList.indexWhere(
                      (element) => element.id == _productList[index].id);
                  if (findIndex != -1) {
                    _productList.removeAt(findIndex);
                    quantityController[index].clear();
                  }
                } else {
                  if (value != '0') {
                    int findIndex = _productList.indexWhere(
                        (element) => element.id == _productList[index].id);
                    if (findIndex != -1) {
                      _productList[findIndex].quantity = int.parse(value);
                      onUpdateTextFormPosition(index, value);
                    } else {
                      _productList.add(ModelProduct(
                          quantity: int.parse(value),
                          id: _productList[index].id,
                          name: _productList[index].name));
                      onUpdateTextFormPosition(index, value);
                    }
                  }
                }
              },
            ),
          ),
          IconButton(
              padding: EdgeInsets.zero,
              onPressed: () => onIncrease(index),
              icon: Icon(Icons.add, color: Colors.black))
        ],
      ),
    );
  }

  TableRow renderTableRowText(int index) {
    num availableQuantity = 0;

    for (var i = 0; i < _productList[index].batchPriceList!.length; i++) {
      availableQuantity =
          availableQuantity + _productList[index].batchPriceList![i].quantity!;
    }
    return TableRow(
      children: [
        renderTableData(_productList[index].name!),
        renderTableData('$availableQuantity'),
        renderTableData('${_productList[index].counterNew}'),
        // renderTableData('0'),
        dynamicTextFormField(index)
      ],
    );
  }

  Widget buildSearchBarView() {
    return Container(
      height: 50.0,
      child: Padding(
        padding: const EdgeInsets.only(left: 10),
        child: Card(
          elevation: 2.5,
          shadowColor: theme.colorScheme.primary,
          shape: new RoundedRectangleBorder(
              borderRadius: new BorderRadius.circular(15),
              side: new BorderSide(
                  color: theme.colorScheme.primary, strokeAlign: 0.01)),
          child: Row(
            children: <Widget>[
              Expanded(
                child: Container(
                  padding: EdgeInsets.only(left: 15),
                  child: TextFormField(
                    controller: _searchController,
                    onChanged: onSearchTextChanged,
                    style: TextStyle(fontWeight: StyleView.fontMedium),
                    decoration: InputDecoration(
                        contentPadding: EdgeInsets.only(bottom: 10),
                        border: InputBorder.none,
                        hintText: Language()
                            .getString(Constants.SEARCH_BY_NAME, selectedLang),
                        hintStyle: TextStyle(
                            fontSize: 13.0, fontWeight: StyleView.fontMedium)),
                  ),
                ),
              ),
              (_searchController.text.length > 0)
                  ? Container(
                      color: Colors.white,
                      child: IconButton(
                          icon: Icon(
                            Icons.close,
                            color: Colors.red,
                            size: 20.0,
                          ),
                          onPressed: () {
                            _searchController.clear();
                            CommonMethods.hideKeyboard(context);
                            onSearchTextChanged(_searchController.text);
                          }),
                    )
                  : Container(),
            ],
          ),
        ),
      ),
    );
  }

  onSearchTextChanged(String text) async {
    if (text.isEmpty) {
      setState(() => _productList.clear());
      _productList.addAll(widget.productList);
      return;
    }
    setState(() => _productList.clear());
    List<ModelProduct> data = widget.productList
        .where((element) => (element.name!.toLowerCase().contains(text) ||
            element.name!.toUpperCase().contains(text)))
        .toList();
    _productList.addAll(data);
    print(data);
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        AppBackgroundView(
            body: SafeArea(
          child: Scaffold(
            backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
            appBar: AppBar(
              centerTitle: true,
              elevation: 0,
              iconTheme: IconThemeData(color: theme.colorScheme.primary),
              backgroundColor: Colors.transparent,
              title: AppbarName(
                  title: Language()
                      .getString(Constants.REVIEW_PRODUCTS_ORDER, selectedLang),
                  buName: AppController.instance.buName),
            ),
            bottomNavigationBar: Container(
              padding: EdgeInsets.only(left: 10, right: 10, bottom: 30),
              child: CommonButtonsView(
                context: context,
                b1Text: Language().getString(Constants.BACK, selectedLang),
                b2Text: Language().getString(Constants.CONFIRM, selectedLang),
                onb1Action: () => Navigator.of(context).pop(),
                onb2Action: () {
                  if (widget.directOrder!) {
                    Map<String, dynamic> data = prepareBody(
                        sellerId: widget.offlineSellerId!,
                        sellerName: widget.offlineSellerName!,
                        recordId: '',
                        isOfflineConnection: true);
                    postBodyForProductsBuy(data: data);
                  } else {
                    showDialogForConnection();
                  }
                },
              ),
            ),
            body: Container(
              padding: EdgeInsets.all(16),
              child: Column(
                children: [
                  Container(
                      padding: EdgeInsets.only(bottom: 20),
                      child: buildSearchBarView()),
                  if (widget.productList.length > 0)
                    Expanded(
                        child: Column(
                      children: [
                        if (widget.directOrder!)
                          Container(
                            alignment: Alignment.center,
                            padding: EdgeInsets.symmetric(vertical: 16),
                            child: Text(
                              Language().getString(
                                      Constants.ORDER_TO, selectedLang) +
                                  '  ${widget.offlineSellerName}',
                              style: TextStyle(
                                  color: theme.colorScheme.primary,
                                  fontWeight: StyleView.fontSemiBold,
                                  decoration: TextDecoration.underline),
                            ),
                          ),
                        Expanded(
                          child: SingleChildScrollView(
                            scrollDirection: Axis.vertical,
                            child: SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              child: Table(
                                defaultVerticalAlignment:
                                    TableCellVerticalAlignment.middle,
                                border: TableBorder.all(
                                    color: Colors.black,
                                    borderRadius: BorderRadius.circular(5)),
                                defaultColumnWidth: FixedColumnWidth(150),
                                children: [
                                  TableRow(children: [
                                    renderTableHeaders(Constants.PRODUCT_NAME),
                                    renderTableHeaders(
                                        Constants.AVAILABLE_QUANTITY),
                                    renderTableHeaders(
                                        Constants.SOLD_IN_30_DAYS),
                                    renderTableHeaders(
                                        Constants.PURCHASE_QUANTITY),
                                  ]),
                                  for (int i = 0; i < _productList.length; i++)
                                    renderTableRowText(i)
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    )),
                ],
              ),
            ),
          ),
        )),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    );
  }
}
