import 'dart:convert';

import 'package:vyaparlive/Home/purchase_offline_products/ConfirmOfflinePurchaseProducts.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/Dialog.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/ModelProduct.dart';
import 'package:vyaparlive/model/product_model/ProductModel.dart';
import 'package:vyaparlive/service/product_services.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:vyaparlive/utills/SharePref.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'PurchaseOrderFilter.dart';

class PurchaseOfflineOrders extends StatefulWidget {
  const PurchaseOfflineOrders({super.key});

  @override
  State<PurchaseOfflineOrders> createState() => _PurchaseOfflineOrdersState();
}

class _PurchaseOfflineOrdersState extends State<PurchaseOfflineOrders> {
  late ThemeData theme;
  String? buName;
  String? userId;
  late ProductService _productService;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late List<BuProductModal> _productList = [];
  num _pageCount = 0;
  num _pageLimitCount = 20;
  late ScrollController _scrollController;
  bool isLoadingProgress = true;
  String progressMessage = Constants.PLEASE_WAIT;
  bool isLoadMore = false;
  late List<TextEditingController> quantityController = [];
  late List<ModelProduct> selectedProducts = [];
  late TextEditingController _searchController = new TextEditingController();
  String? showLoaderText = 'Loading..';
  bool isSearchForParams = false;
  late SharedPreferences sharedPreferences;
  @override
  void initState() {
    super.initState();
    _productService = new ProductService();
    theme = AppTheme.vyaparTheme;
    buName = AppController.instance.buName;
    _scrollController = ScrollController(); //..addListener(loadMore);
    loadProductsData();
    SharePref().getUserId().then((onValue) {
      setState(() {
        userId = onValue;
      });
    });
  }

  Future<void> loadProductsData() async {
    getBuProducts().then((value) {
      if (value.length == 0) {
        showLoaderText = Constants.NO_DATAFOUND_STRING;
      }
      _productList.clear();
      quantityController.clear();
      _productList.addAll(value);
      for (var i = 0; i < _productList.length; i++) {
        quantityController.add(new TextEditingController());
      }

      if (selectedProducts.length == 0) return;
      for (int i = 0; i < selectedProducts.length; i++) {
        final findIndex = _productList
            .indexWhere((element) => element.id == selectedProducts[i].id);
        if (findIndex != -1) {
          quantityController[findIndex].text =
              "${selectedProducts[i].quantity}";
        }
      }
    });
  }

  Future<void> loadMore() async {
    if (isLoadMore) return;
    if (_scrollController.position.pixels ==
        _scrollController.position.maxScrollExtent) {
      _pageCount = _pageCount + _pageLimitCount;
      isLoadMore = true;
      getBuProducts().then((value) {
        _productList.addAll(value);
        for (var i = 0; i < _productList.length; i++) {
          quantityController.add(new TextEditingController());
        }
      });
    }
  }

  Future<List<BuProductModal>> getBuProducts(
      {String productName = "",
      bool inStock = false,
      bool? forSale = false,
      bool isFromRawMaterial = false,
      bool? isForOffer = false}) async {
    String body = "";
    Map filterObject = {
      "name": _searchController.text,
      "from": _pageCount,
      "count": _pageLimitCount,
      "isDesc": true,
    };

    // if (selectedFilter != null) {
    //   if (selectedFilter!.isNotEmpty &&
    //       selectedFilter == Constants.RAW_MATERIAL) {
    //     filterObject["raw_material"] = true;
    //   } else if (selectedFilter!.isNotEmpty &&
    //       selectedFilter == Constants.CONSUMABLE_GOODS) {
    //     filterObject["is_consumable"] = true;
    //   }
    // }

    body = json.encode(
        {"id": AppController.instance.getMyBuId, "filter": filterObject});

    var response = await _productService
        .getAllProductsbyBuId(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
        isLoadMore = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<BuProductModal> products = [];

    // setState(() {
    //   isLoadingProgress = false;
    //   isLoadMore = false;
    // });
    GRPCResponse _grpcResp = response;
    if (!_grpcResp.getIsError! && !_grpcResp.getIsException!) {
      var resObj = json.decode(_grpcResp.message!);
      var data = resObj['data'];
      // for (var i in data) {
      //   products.add(BuProductModal.fromJson(i));
      // }

      Map filter = {
        "name": _searchController.text,
        // "raw_material": true,
        "product_sector": "",
        "product_segment": "",
        "product_category": "",
        "product_sub_category": ""
      };

      if (selectedFilter != null) {
        if (selectedFilter!.isNotEmpty &&
            selectedFilter == Constants.RAW_MATERIAL) {
          filter["raw_material"] = true;
        } else if (selectedFilter!.isNotEmpty &&
            selectedFilter == Constants.CONSUMABLE_GOODS) {
          filter["is_consumable"] = true;
        } else {
          filter["all_products"] = true;
        }
      } else {
        filter["all_products"] = true;
      }
      Map rawMaterialBody = {
        "id": AppController.instance.getMyBuId,
        "filter": filter
      };

      String request = json.encode(rawMaterialBody);

      var rawMaterialResponse = await _productService
          .getProductByBuId_v2(
              body: request, token: AppController.instance.getAuthorizationKey)
          .catchError((onError) {
        print(onError);
      });

      setState(() {
        isLoadingProgress = false;
        isLoadMore = false;
      });

      GRPCResponse _grpcResponse = rawMaterialResponse;
      if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
        var resObj = json.decode(_grpcResponse.message!);
        var data = resObj['results'];
        for (var i in data) {
          products.add(BuProductModal.fromJson(i));
        }
      }
    } else {
      setState(() {
        isLoadingProgress = false;
        isLoadMore = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResp.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }

    return products;
  }

  Widget renderTableHeaders(String? headerText) {
    return Container(
      alignment: Alignment.center,
      padding: EdgeInsets.all(8.0),
      child: Text(
        Language().getString(headerText, selectedLang),
        textAlign: TextAlign.center,
        style: TextStyle(
            color: Colors.black,
            fontWeight: StyleView.fontMedium,
            fontSize: 15.0),
      ),
    );
  }

  Widget renderTableData(String value) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          child: Text("$value",
              style: TextStyle(
                  fontSize: 13,
                  color: Colors.black,
                  fontWeight: StyleView.fontRegular)),
        ),
      ),
    );
  }

  onUpdateTextFormPosition(int index, String value) {
    quantityController[index] = TextEditingController(text: value);
    quantityController[index].selection = TextSelection.fromPosition(
        TextPosition(offset: quantityController[index].text.length));
  }

  onIncrease(int index) {
    int findIndex = selectedProducts
        .indexWhere((element) => element.id == _productList[index].id);
    if (findIndex != -1) {
      num? count = selectedProducts[findIndex].quantity;
      count = count! + 1;
      setState(() {
        quantityController[index].text = "$count";
        selectedProducts[findIndex].quantity = count;
        onUpdateTextFormPosition(index, "$count");
      });
      return;
    }
    num? count = 0;
    if (quantityController[index].text.isNotEmpty) {
      count = int.parse(quantityController[index].text);
    }
    count = count + 1;
    setState(() {
      quantityController[index].text = "$count";
      selectedProducts.add(ModelProduct(
          batchPriceList: _productList[index].batchPrice,
          id: _productList[index].id,
          name: _productList[index].name,
          counter: _productList[index].totalSoldQuantity!.toInt(),
          counterNew: _productList[index].totalSoldQuantity,
          quantity: count));
    });
  }

  onDecrease(int index) {
    num count = 0;
    if (quantityController[index].text.isEmpty) {
      return;
    }
    count = int.parse(quantityController[index].text);
    count = count - 1;
    if (count == 0) {
      int findIndex = selectedProducts
          .indexWhere((element) => element.id == _productList[index].id);
      if (findIndex != -1) {
        setState(() {
          selectedProducts.removeAt(findIndex);
          quantityController[index].clear();
        });
      }
    } else {
      int findIndex = selectedProducts
          .indexWhere((element) => element.id == _productList[index].id);
      if (findIndex != -1) {
        setState(() {
          selectedProducts[findIndex].quantity = count;
          quantityController[index].text = "$count";
          onUpdateTextFormPosition(index, "$count");
        });
      }
    }
  }

  Widget dynamicTextFormField(int index) {
    return Container(
      child: Row(
        children: [
          IconButton(
              padding: EdgeInsets.zero,
              onPressed: () => onDecrease(index),
              icon: Icon(Icons.remove, color: Colors.black)),
          Container(
            width: 50.0,
            height: 25.0,
            decoration: AppUtills.boxDecoration(),
            child: TextFormField(
              controller: quantityController[index],
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 14, fontWeight: StyleView.fontRegular),
              keyboardType: TextInputType.numberWithOptions(signed: true),
              textInputAction: TextInputAction.done,
              decoration: InputDecoration(
                  hintText: "0",
                  contentPadding:
                      EdgeInsets.only(bottom: Constants.CONTENT_PADDING_18_13),
                  hintStyle: TextStyle(
                      fontSize: 14, fontWeight: StyleView.fontRegular),
                  border: InputBorder.none),
              inputFormatters: [
                new LengthLimitingTextInputFormatter(5),
                CommonMethods.inputTextFormatter(isNumber: true)
              ],
              onChanged: (value) {
                if (value.isEmpty) {
                  int findIndex = selectedProducts.indexWhere(
                      (element) => element.id == _productList[index].id);
                  if (findIndex != -1) {
                    selectedProducts.removeAt(findIndex);
                    quantityController[index].clear();
                  }
                } else {
                  if (value != '0') {
                    int findIndex = selectedProducts.indexWhere(
                        (element) => element.id == _productList[index].id);
                    if (findIndex != -1) {
                      selectedProducts[findIndex].quantity = int.parse(value);
                      onUpdateTextFormPosition(index, value);
                    } else {
                      selectedProducts.add(ModelProduct(
                          batchPriceList: _productList[index].batchPrice,
                          quantity: int.parse(value),
                          id: _productList[index].id,
                          counter:
                              _productList[index].totalSoldQuantity!.toInt(),
                          counterNew: _productList[index].totalSoldQuantity,
                          name: _productList[index].name));
                      onUpdateTextFormPosition(index, value);
                    }
                  }
                }
              },
            ),
          ),
          IconButton(
              padding: EdgeInsets.zero,
              onPressed: () => onIncrease(index),
              icon: Icon(Icons.add, color: Colors.black))
        ],
      ),
    );
  }

  TableRow renderTableRowText(int index) {
    num availableQuantity = 0;

    for (var i = 0; i < _productList[index].batchPrice!.length; i++) {
      availableQuantity =
          availableQuantity + _productList[index].batchPrice![i].quantity!;
    }
    return TableRow(
      children: [
        renderTableData(_productList[index].name!),
        renderTableData('$availableQuantity'),
        renderTableData('${_productList[index].totalSoldQuantity}'),
        // renderTableData('0'),
        dynamicTextFormField(index)
      ],
    );
  }

  Widget buildSearchBarView() {
    return Container(
      height: 50.0,
      child: Padding(
        padding: const EdgeInsets.only(left: 10),
        child: Card(
          elevation: 2.5,
          shadowColor: theme.colorScheme.primary,
          shape: new RoundedRectangleBorder(
              borderRadius: new BorderRadius.circular(15),
              side: new BorderSide(
                  color: theme.colorScheme.primary, strokeAlign: 0.01)),
          child: Row(
            children: <Widget>[
              Expanded(
                child: Container(
                  padding: EdgeInsets.only(left: 15),
                  child: TextFormField(
                    controller: _searchController,
                    onChanged: onSearchTextChanged,
                    style: TextStyle(fontWeight: StyleView.fontSemiBold),
                    decoration: InputDecoration(
                        contentPadding: EdgeInsets.only(bottom: 10),
                        border: InputBorder.none,
                        hintText: Language()
                            .getString(Constants.SEARCH_BY_NAME, selectedLang),
                        hintStyle: TextStyle(
                            fontSize: 13.0,
                            fontWeight: StyleView.fontSemiBold)),
                  ),
                ),
              ),
              (_searchController.text.length > 0)
                  ? Container(
                      color: Colors.white,
                      child: IconButton(
                          icon: Icon(
                            Icons.close,
                            color: Colors.red,
                            size: 20.0,
                          ),
                          onPressed: () {
                            _searchController.clear();
                            CommonMethods.hideKeyboard(context);
                            onSearchTextChanged(_searchController.text);
                          }),
                    )
                  : Container(),
              PurchaseOrderFilter(
                theme: theme,
                selectedLang: selectedLang,
                selectedFilter: selectedFilter,
                onFilterSelection: (String selectedValue) {
                  setState(() {
                    selectedFilter = selectedValue;
                  });
                },
                onApplyFilter: () {
                  setState(() {
                    isLoadingProgress = true;
                  });
                  loadProductsData();
                },
              )
            ],
          ),
        ),
      ),
    );
  }

  String? selectedFilter;

  onSearchTextChanged(String text) async {
    if (text.isEmpty) {
      isSearchForParams = false;
      _productList.clear();
      loadProductsData();
    } else {
      setState(() {
        isSearchForParams = true;
        _productList.clear();
        showLoaderText = Constants.LOADING;
      });
      loadProductsData();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        AppBackgroundView(
            body: SafeArea(
              child: Scaffold(
                        backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                        appBar: AppBar(
              elevation: 0,
              centerTitle: true,
              backgroundColor: Colors.transparent,
              iconTheme: IconThemeData(color: theme.colorScheme.primary),
              title: AppbarName(
                  title: Language()
                      .getString(Constants.CREATE_PURCHASE_ORDER, selectedLang),
                  buName: "$buName"),
                        ),
                        bottomNavigationBar: (selectedProducts.length > 0)
                ? Container(
                    padding: EdgeInsets.only(left: 10, right: 10, bottom: 30),
                    child: CommonButtonsView(
                      context: context,
                      b1Text: Language()
                          .getString(Constants.STR_CANCEL, selectedLang),
                      b2Text:
                          Language().getString(Constants.CONTINUE, selectedLang),
                      onb1Action: () => Navigator.of(context).pop(),
                      onb2Action: () {
                        List<ModelProduct> data = selectedProducts
                            .where((element) => element.quantity != 0)
                            .toList();
                        Navigator.push(
                            context,
                            new MaterialPageRoute(
                                builder: (context) => ConfirmProducts(
                                      productList: data,
                                      offlineBuyerId: "",
                                      offlineBuyerName: '',
                                      offlineSellerId: '',
                                      offlineSellerName: '',
                                      directOrder: false,
                                    )));
                      },
                    ),
                  )
                : SizedBox(),
                        body: Container(
              padding: EdgeInsets.all(16),
              child: Column(
                children: [
                  Container(
                      padding: EdgeInsets.only(bottom: 20),
                      child: buildSearchBarView()),
                  (_productList.length > 0)
                      ? Expanded(
                          child: Column(
                            children: [
                              Expanded(
                                child: SingleChildScrollView(
                                  controller: _scrollController,
                                  scrollDirection: Axis.vertical,
                                  child: SingleChildScrollView(
                                    scrollDirection: Axis.horizontal,
                                    child: Table(
                                      defaultVerticalAlignment:
                                          TableCellVerticalAlignment.middle,
                                      border: TableBorder.all(
                                          color: Colors.black,
                                          borderRadius: BorderRadius.circular(5)),
                                      defaultColumnWidth: FixedColumnWidth(150),
                                      children: [
                                        TableRow(children: [
                                          renderTableHeaders(Language().getString(
                                              Constants.PRODUCT_NAME,
                                              selectedLang)),
                                          renderTableHeaders(Language().getString(
                                              Constants.AVAILABLE_QUANTITY,
                                              selectedLang)),
                                          renderTableHeaders(Language().getString(
                                              Constants.SOLD_IN_30_DAYS,
                                              selectedLang)),
                                          renderTableHeaders(Language().getString(
                                              Constants.PURCHASE_QUANTITY,
                                              selectedLang)),
                                        ]),
                                        for (int i = 0;
                                            i < _productList.length;
                                            i++)
                                          renderTableRowText(i)
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        )
                      : Expanded(
                          child: Center(
                            child: Text(
                              showLoaderText!,
                              style: TextStyle(
                                  color: theme.colorScheme.primary,
                                  fontSize: 15,
                                  fontWeight: StyleView.fontMedium),
                            ),
                          ),
                        ),
                ],
              ),
                        ),
                      ),
            )),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    );
  }
}
