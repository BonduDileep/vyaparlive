import 'package:vyaparlive/Home/purchase_offline_products/OfflinePurchaseOrders.dart';
import 'package:vyaparlive/Organization/AllBUListPage.dart';
import 'package:vyaparlive/Product/ProductsMenuPage.dart';
import 'package:vyaparlive/Transaction/TransactionsPage.dart';
import 'package:vyaparlive/offline_connections/OfflineConnections.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/connections_view/ContactsPage.dart';
import 'package:vyaparlive/orders_view/OrdersPage.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:vyaparlive/retailer_view/RetailerDashboard.dart';
import 'package:flutter/material.dart';
import 'package:flutx/flutx.dart';

class HomeController extends FxController {
  void navigateProductMenu() {
    Navigator.pushAndRemoveUntil(
        context,
        PageTransition(
          context: context,
          page: ProductsMenuPage(),
        ),
        (route) => false);
  }

  void navigateOrdrsPage() {
    Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => OrdersPage()),
        (route) => false);
  }

  void navigateTransactionPage() {
    Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => TransactionsView()),
        (route) => false);
  }

  void navigateRetailPage() {
    Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(
            builder: (context) => RetailerDashboard(
                  retailCustomerId: "",
                  retailName: "",
                )),
        (Route<dynamic> route) => false);
  }

  void navigateConnections() {
    Navigator.pushAndRemoveUntil(
        context,
        PageTransition(context: context, page: ContactsView()),
        (route) => false);
  }

  void navigateBuList() {
    Navigator.pushAndRemoveUntil(
        context,
        PageTransition(
            context: context,
            page: AllBUListView(
              title: Constants.BUSINESS_UNIT_LIST_STRING,
            )),
        (route) => false);
  }

  void navigateOfflinePurchaseOrders() {
    Navigator.push(context,
        new MaterialPageRoute(builder: (context) => PurchaseOfflineOrders()));
  }

  void navigateOfflineConnections() {
    Navigator.pushAndRemoveUntil(
        context,
        new MaterialPageRoute(builder: (context) => OfflineConnections()),
        (route) => false);
  }

  @override
  String getTag() {
    return "home_controller";
  }
}
