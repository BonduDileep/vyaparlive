import 'dart:async';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:custom_searchable_dropdown/custom_searchable_dropdown.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../components/Constants.dart';
import '../../model/BuListModel.dart';

enum ShareOrderFormActions { yes, no }

class ShareOrderForm {
  static Future<ShareOrderFormActions> showShareOrderFormDialog(
      {required BuildContext context,
      required List<BuListModel> offlineConnectionsList,
      required Function(BuListModel) onShare,
      required VoidCallback onClose}) async {
    BuListModel? selectedDropdownValue;
    TextEditingController _controller = new TextEditingController();
    final action = await showDialog(
        context: context,
        builder: (context) {
          return Container(
            margin: EdgeInsets.symmetric(horizontal: 10.0, vertical: 20.0),
            child: StatefulBuilder(builder: (context, setState) {
              return Scaffold(
                bottomNavigationBar: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: CommonButtonsView(
                    context: context,
                    b1Text: Constants.STR_CANCEL,
                    b2Text: Constants.SHARE,
                    onb1Action: () => onClose(),
                    onb2Action: () => {onShare(selectedDropdownValue!)},
                  ),
                ),
                body: Container(
                  padding: EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        decoration: BoxDecoration(
                            color: Colors.white70,
                            border: Border.all(color: Colors.grey),
                            borderRadius: BorderRadius.circular(5)),
                        child: CustomSearchableDropDown(
                          items: offlineConnectionsList.toList(),
                          dropDownMenuItems: offlineConnectionsList
                              .map((item) => item.name)
                              .toList(),
                          label: Constants.PLEASE_SELECT_CONNECTION,
                          labelStyle: TextStyle(
                              overflow: TextOverflow.ellipsis,
                              fontWeight: StyleView.fontMedium,
                              color: Colors.black,
                              fontSize: 14.0),
                          suffixIcon: Padding(
                              padding: const EdgeInsets.all(0.0),
                              child: Icon(
                                Icons.keyboard_arrow_down_outlined,
                                color: Colors.black,
                              )),
                          hint: Constants.PLEASE_SELECT_CONNECTION,
                          dropdownHintText: Constants.PLEASE_SELECT_CONNECTION,
                          onChanged: (value) {
                            print("onChanged");
                            selectedDropdownValue = value;
                          },
                        ),
                      ),
                      Container(
                        alignment: Alignment.center,
                        padding: const EdgeInsets.all(24.0),
                        child: Text(
                          "OR",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: Colors.black,
                              fontWeight: StyleView.fontSemiBold),
                        ),
                      ),
                      Container(
                        height: 50,
                        padding: EdgeInsets.only(top: 0, left: 8, right: 8),
                        decoration: AppUtills.boxDecoration(
                            customBorderColor: Colors.black),
                        child: TextFormField(
                          controller: _controller,
                          decoration: InputDecoration(
                              hintText: "Enter mobile number",
                              border: InputBorder.none),
                          keyboardType: TextInputType.number,
                          inputFormatters: [
                            new LengthLimitingTextInputFormatter(10),
                            FilteringTextInputFormatter.digitsOnly
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              );
            }),
          );
        });

    return (action != null
        ? action as FutureOr<ShareOrderFormActions>
        : ShareOrderFormActions.no);
  }

  static showContactsList(
      {required BuildContext context, required List<BuListModel> buList}) {
    return showDialog(
        context: context,
        builder: (context) => AlertDialog(
              titlePadding: EdgeInsets.only(left: 20, right: 10, top: 10),
              title: Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Select Offline Connection",
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: StyleView.fontMedium,
                      ),
                    ),
                    IconButton(
                        onPressed: () => Navigator.of(context).pop(),
                        icon: Icon(Icons.close, color: Colors.red)),
                  ],
                ),
              ),
              content: Container(
                height: 60.0,
                decoration: BoxDecoration(
                    color: Colors.white70,
                    border: Border.all(color: Colors.grey),
                    borderRadius: BorderRadius.circular(5)),
                child: CustomSearchableDropDown(
                  items: buList.toList(),
                  dropDownMenuItems: buList.map((item) => item.name).toList(),
                  label: Constants.PLEASE_SELECT_CONNECTION,
                  labelStyle: TextStyle(
                      overflow: TextOverflow.ellipsis,
                      fontWeight: StyleView.fontMedium,
                      color: Colors.black,
                      fontSize: 14.0),
                  suffixIcon: Padding(
                      padding: const EdgeInsets.all(0.0),
                      child: Icon(
                        Icons.keyboard_arrow_down_outlined,
                        color: Colors.black,
                      )),
                  hint: Constants.PLEASE_SELECT_CONNECTION,
                  dropdownHintText: Constants.PLEASE_SELECT_CONNECTION,
                  onChanged: (value) {},
                ),
              ),
            ));
  }
}
