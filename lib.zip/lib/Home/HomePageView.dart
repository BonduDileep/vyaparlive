import 'dart:async';
import 'dart:io';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:dio/dio.dart';
import 'package:share_plus/share_plus.dart';
import 'package:toast/toast.dart';
import 'package:vyaparlive/Home/controller/home_controller.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/core/enums/privilleges_enum.dart';
import 'package:vyaparlive/help/HelpChatScreenView.dart';
import 'package:vyaparlive/notifications_view/NotificationPage.dart';
import 'package:vyaparlive/redux/actions/reset_data.dart';
import 'package:vyaparlive/service/api_service/InvitationApiService.dart';
import 'package:vyaparlive/service/api_service/OrganizationApiService.dart';
import 'package:vyaparlive/service/organization_service.dart';
import 'package:vyaparlive/service/user_services.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:clipboard/clipboard.dart';
import 'package:custom_searchable_dropdown/custom_searchable_dropdown.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:flutx/flutx.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
// import 'package:share/share.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Organization/CreateBUPage.dart';
import 'package:vyaparlive/Transaction/ListOfTransactions.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/MyDrawer.dart';
import 'package:vyaparlive/components/Dialog.dart';
import 'package:vyaparlive/components/text_styles.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/core/enums/notification_enum.dart';
import 'package:vyaparlive/core/locator.dart';
import 'package:vyaparlive/core/view_models/homeview_model.dart';
import 'package:vyaparlive/model/BuBasicDataModel.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/InviteesModel.dart';
import 'package:vyaparlive/model/NotificationsDAO.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:vyaparlive/service/invitation_services.dart';
import 'dart:convert';
import 'package:vyaparlive/utills/SharePref.dart';
import 'package:vyaparlive/utills/printer/bt_thermal_manager.dart';
import 'package:vyaparlive/utills/printer/bt_thermal_receipt.dart';
import 'package:vyaparlive/utills/printer/bt_thermal_scan_page.dart';

import '../model/BuListModel.dart';
import '../ondc_menu/OndcOrdersView.dart';
import '../redux/actions/menu_action.dart';
import '../redux/state/app_state.dart';
import '../utills/CommonButtonsView.dart';
import '../utills/vyapar_info.dart';

class HomePageView extends StatefulWidget {
  @override
  HomePageViewState createState() => HomePageViewState();
}

class HomePageViewState extends State<HomePageView> {
  // ProgressDialog progressDialog;
  int _currentPageIndex = 0;
  int bottomIndex = 0;
  late PageController _pageController;
  String selectedLang = AppController.instance.getSelectedlanguage;
  SharedPreferences? sharedPreferences;
  String buId = "";
  List<dynamic> updateNotifications = [];

  List<String> _gridImages = [];
  static DateTime now = DateTime.now();
  String todayDate = DateFormat('EEEE, d-MMM-yyyy').format(now);
  List<BuBasicDataModel> buList = [];
  BuBasicDataModel? dropdownValue;
  BuBasicDataModel? data;
  bool isLoading = false;
  String? userId = "";
  String? phoneNumber = "";
  List<NotificationsDAO> notificationsList = [];
  static int i = 0;
  bool isBuListEmpty = false;
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  HomeViewModel? _homeViewModel = locator<HomeViewModel>();
  String? appBarTitle = "";
  bool isLoadingProgress = true;
  String progressMessage = Constants.GETTING_DATA;
  String? selectedBuId;
  List<InviteesModel> _inviteesModel = [];
  late InvitationService _invitationService;
  bool showInvitationCircleProgress = false;
  List<String> listValues = [
    Constants.STR_PRODUCTS,
    Constants.STR_RETAIL,
    Constants.STR_CREATE_PURCHASE_ORDER,
    Constants.STR_ONLINE_CONNECTIONS,
    Constants.STR_OFFLINE_CONNECTIONS,
    Constants.STR_MY_COMPANY,
    Constants.STR_SHARE_ORDER_FORM,
  ];
  late OrganizationService _organizationService;
  late ThemeData theme;
  late HomeController _homeController;
  late UserService _userService;
  final StreamController<String?> selectNotificationStream =
      StreamController<String?>.broadcast();
  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
      new FlutterLocalNotificationsPlugin();
  AndroidInitializationSettings? initializationSettingsAndroid;
  DarwinInitializationSettings? initializationSettingsIOS;
  List<BuListModel> offlineConnections = [];
  BuListModel? offlineConnectonDropdown;
  TextEditingController shareOrderFormController = new TextEditingController();

  String share_mobile_number = "";
  String share_customer_name = "Customer";

  late var _dio;

  @override
  void initState() {
    super.initState();
    _dio = Dio();
    this.getLoadLanguage();
    _homeController = FxControllerStore.putOrFind(HomeController());
    theme = AppTheme.vyaparTheme;
    _userService = new UserService();
    _organizationService = new OrganizationService();
    _invitationService = InvitationService();
    SharePref().getPhoneNumber().then((value) {
      setState(() {
        phoneNumber = value;
      });
    });
    SharePref().getHomePageSelectedBuId().then((value) {
      setState(() {
        selectedBuId = value;
      });
    });

    SharePref().getUserId().then((onValue) {
      setState(() {
        userId = onValue;
        this.loadHomePageServiceCalls();
      });
    });

    _pageController =
        new PageController(initialPage: _currentPageIndex, keepPage: true);
    appBarTitle = Language().getString(Constants.HOME_STR, selectedLang);
  }

  loadHomePageServiceCalls() async {
    _homeViewModel!.setBuildContext(context);
    _homeViewModel!.setUserId(userId);
    Future.delayed(Duration(milliseconds: 500));
    await getUserBuList().then((value) {
      if (value.length > 0) {
        _homeViewModel!.getHomeViewBuList("", context, value);
        buList.addAll(value);

        // setState(() => selectedBuId = null);
        setBuData();
      } else {
        isBuListEmpty = true;
      }
    });
    if (!kIsWeb && !Platform.isWindows) {
      registerNotification();
    }
    if (AppController.instance.getMyBuId != null) {
      final List<BuListModel> fetchOfflineConnections =
          await InvitationApiService.instance.getOfflineConnectionsByBuId(
              context: context,
              buId: AppController.instance.getMyBuId,
              mapFilter: {"name": ""},
              langError: Language().getString(Constants.ERROR, selectedLang),
              langOk: Language().getString(Constants.OKAY_STR, selectedLang));
      setState(() {
        isLoadingProgress = false;
        offlineConnections.clear();
      });
      if (fetchOfflineConnections.length > 0) {
        offlineConnections.addAll(fetchOfflineConnections);
      }
    }
  }

  Future<void> setBuData() async {
    if (buList.length > 0) {
      if (AppController.instance.getBuList == null ||
          AppController.instance.getBuList.length == 0) {
        AppController.instance.setBuList = buList;
      }
      if (selectedBuId == null || selectedBuId!.isEmpty) {
        for (int i = 0; i < buList.length; i++) {
          if (buList[i].rootValue == 0) {
            setState(() {
              dropdownValue = buList[i];
              AppController.instance.setMyBuId = buList[i].id;
              AppController.instance.setBuName = buList[i].businessName;
              SharePref().saveHomePageSelectedBuId(buList[i].id!);
              _homeViewModel!.notificationsList.clear();
              AppController.instance.setInpersonOrdeerAccept =
                  buList[i].isInpersonOrderAccept;
              AppController.instance.setBuCurrencySymbol =
                  buList[i].orgCurrencySymbol;
              AppController.instance.setBuCountryCode =
                  buList[i].orgCountryCode;
              AppController.instance.setBuCountryDialCode =
                  buList[i].dialerCode;
            });
            break;
          }
        }
      } else {
        for (int i = 0; i < buList.length; i++) {
          if (selectedBuId == buList[i].id) {
            setState(() {
              dropdownValue = buList[i];
              AppController.instance.setMyBuId = buList[i].id;
              AppController.instance.setBuName = buList[i].businessName;
              _homeViewModel!.notificationsList.clear();
              AppController.instance.setInpersonOrdeerAccept =
                  buList[i].isInpersonOrderAccept;
              AppController.instance.setBuCurrencySymbol =
                  buList[i].orgCurrencySymbol;
              AppController.instance.setBuCountryCode =
                  buList[i].orgCountryCode;
              AppController.instance.setBuCountryDialCode =
                  buList[i].dialerCode;
            });
            break;
          }
        }
      }
    }
    if (dropdownValue != null) {
      updateBuFeatures();
    }
  }

  Future<void> updateBuFeatures() async {
    StoreProvider.of<AppState>(context).dispatch(ResetData());
    setState(() {
      listValues.clear();
      _gridImages.clear();
      isLoadingProgress = true;
      progressMessage = Constants.PLEASE_WAIT;
    });
    StoreProvider.of<AppState>(context).dispatch(ResetData());
    Map<String, dynamic> mapData = {"id": userId, "bu": dropdownValue!.id};
    List<dynamic> featuresList = await OrganizationApiService.instance
        .getBuFeatures(context: context, mapData: mapData);
    setState(() => isLoadingProgress = false);
    if (featuresList.length > 0) {
      updateListItems(featuresList);
      StoreProvider.of<AppState>(context)
          .dispatch(MenuAppState(featureMenu: featuresList));
    }
  }
  //Language convertion

  getLoadLanguage() async {
    Language().loadLanguageFile();
  }

  // App exit alertDialog functionality
  Future<bool> _alert() async {
    final action = await Dialogs.yesCancelDialog(
        context,
        Language().getString(Constants.ARE_YOU_SURE_STRING, selectedLang),
        Language()
            .getString(Constants.DO_YOU_WANT_EXIT_APP_STRING, selectedLang),
        Language().getString(Constants.YES_STRING, selectedLang),
        Language().getString(Constants.NO_STRING, selectedLang),
        true);

    if (action == DialogAction.yes) {
      if (Platform.isAndroid) {
        SystemNavigator.pop();
      } else if (Platform.isIOS) {
        exit(0);
      }
      return true;
    } else {
      return false;
    }
  }

  @override
  void dispose() {
    _pageController.dispose();
    _homeController.dispose();
    selectNotificationStream.close();
    super.dispose();
  }

  gridCardViewData(int index) {
    return InkWell(
      onTap: () {
        switch (listValues[index]) {
          case Constants.STR_PRODUCTS:
            _homeController.navigateProductMenu();
            break;
          case Constants.STR_RETAIL:
            _homeController
                .navigateRetailPage(); // _homeController.navigateTransactionPage();
            break;
          case Constants.STR_CREATE_PURCHASE_ORDER:
            _homeController
                .navigateOfflinePurchaseOrders(); //_homeController.navigateRetailPage();
            break;
          case Constants.STR_ONLINE_CONNECTIONS:
            _homeController
                .navigateConnections(); //_homeController.navigateOfflinePurchaseOrders();
            break;
          case Constants.STR_OFFLINE_CONNECTIONS:
            _homeController
                .navigateOfflineConnections(); // _homeController.navigateOrdrsPage();
            break;
          case Constants.STR_MY_COMPANY:
            _homeController
                .navigateBuList(); //  _homeController.navigateConnections();
            break;
          // case 6:
          //   _homeController.navigateOfflineConnections();
          //   break;
          // case 7:
          //   _homeController.navigateBuList();
          // break;
          case Constants.STR_SHARE_ORDER_FORM:
            showShareOrderFormDialog();
            break;
          case Constants.ONDC_STR:
            Navigator.pushAndRemoveUntil(
                context,
                PageTransition(context: context, page: OndcOrdersView()),
                (route) => false);
            break;
          default:
            break;
        }
      },
      child: Card(
        color: Colors.white,
        elevation: 5,
        shadowColor: theme.colorScheme.primaryContainer,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
          side: BorderSide(
              color: theme.colorScheme.primaryContainer, strokeAlign: 1),
        ),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Expanded(
                child: Image.asset(
                  _gridImages[index],
                  height: 50,
                  width: 50,
                ),
              ),
              Expanded(
                child: Container(
                    padding: EdgeInsets.only(top: 10),
                    child: AutoSizeText(
                      Language().getString(listValues[index], selectedLang),
                      textAlign: TextAlign.center,
                      maxLines: 2,
                      minFontSize: 10,
                      stepGranularity: 1,
                      style: TextStyle(
                          fontWeight: StyleView.fontMedium,
                          color: Colors.black),
                    )),
              )
            ],
          ),
        ),
      ),
    );
  }

  shareOrderFormWhatsapp(String contact, StateSetter setState) async {
    String apiURL = "${Constants.NEW_BASE_URL}lookup/whatsapp/send-order-form";
    final payload = {
      "buId": AppController.instance.getMyBuId,
      "contact": "+91${contact}",
      "buName": AppController.instance.getBuName,
      "name": share_customer_name
    };
    try {
      Response response = await _dio.post(
        apiURL,
        data: payload,
        options: Options(
          headers: {
            "Content-Type": "application/json",
          },
        ),
      );
      Map map = response.data;
      print("data of whatsapp: ${map.toString()}");

      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          Language().getString("Order form shared successfully!", selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);

      if (action == DialogAction.yes) {
        setState(() {
          shareOrderFormController.text = "";
        });

        Navigator.of(context).pop();
      }
    } catch (e) {
      print(e);
    }
  }

  Future<void> showShareOrderFormDialog() async {
    String shareData = json.encode({"id": AppController.instance.getMyBuId});
    return showDialog(
        context: context,
        builder: (context) {
          return Container(
            margin: EdgeInsets.symmetric(horizontal: 10.0, vertical: 20.0),
            child: StatefulBuilder(builder: (context, setState) {
              return Scaffold(
                bottomNavigationBar: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: CommonButtonsView(
                    context: context,
                    b1Text: Language()
                        .getString(Constants.STR_CANCEL, selectedLang),
                    b2Text: Language().getString(Constants.SHARE, selectedLang),
                    onb1Action: () => {
                      setState(() {
                        shareOrderFormController.clear();
                        offlineConnectonDropdown = null;
                      }),
                      Navigator.of(context).pop()
                    },
                    onb2Action: () {
                      // Navigator.of(context).pop();
                      // String body =
                      //     json.encode({"id": AppController.instance.getMyBuId});
                      // shareOrderFormUrl(
                      //     "${Constants.SHARE_ORDER_FORM_URL}order-form/" +
                      //         VyaparInfo.encryptData(body));

                      if (share_mobile_number.isEmpty) {
                        Dialogs.yesCancelDialog(
                            context,
                            Language().getString(Constants.ERROR, selectedLang),
                            "Please enter mobile number or select connection!",
                            Language()
                                .getString(Constants.OKAY_STR, selectedLang),
                            "",
                            false);
                        return;
                      }

                      shareOrderFormWhatsapp(share_mobile_number, setState);
                    },
                  ),
                ),
                body: GestureDetector(
                  onTap: () {
                    FocusScope.of(context).unfocus();
                  },
                  behavior: HitTestBehavior.opaque,
                  child: Container(
                    padding: EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (offlineConnections.length > 0)
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 16.0),
                                child: Text(
                                  Language().getString(
                                      Constants.SELECT_OFFLINE_CONNECTION,
                                      selectedLang),
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontWeight: StyleView.fontSemiBold,
                                  ),
                                ),
                              ),
                              Container(
                                decoration: BoxDecoration(
                                    color: Colors.white70,
                                    border: Border.all(color: Colors.grey),
                                    borderRadius: BorderRadius.circular(5)),
                                child: CustomSearchableDropDown(
                                  enabled:
                                      (shareOrderFormController.text.isEmpty)
                                          ? true
                                          : false,
                                  showClearButton: true,
                                  items: offlineConnections.toList(),
                                  dropDownMenuItems: offlineConnections
                                      .map((item) => item.name)
                                      .toList(),
                                  label: Language().getString(
                                      Constants.PLEASE_SELECT_CONNECTION,
                                      selectedLang),
                                  labelStyle: TextStyle(
                                      overflow: TextOverflow.ellipsis,
                                      fontWeight: StyleView.fontMedium,
                                      color: Colors.black,
                                      fontSize: 14.0),
                                  suffixIcon: Padding(
                                      padding: const EdgeInsets.all(0.0),
                                      child: Icon(
                                          Icons.keyboard_arrow_down_outlined,
                                          color: Colors.black)),
                                  hint: Language().getString(
                                      Constants.PLEASE_SELECT_CONNECTION,
                                      selectedLang),
                                  dropdownHintText: Language().getString(
                                      Constants.PLEASE_SELECT_CONNECTION,
                                      selectedLang),
                                  onChanged: (value) {
                                    offlineConnectonDropdown = value;
                                    setState(() {
                                      share_mobile_number =
                                          offlineConnectonDropdown!.contact!;
                                      share_customer_name =
                                          offlineConnectonDropdown!.name!;
                                    });
                                  },
                                ),
                              ),
                              Container(
                                alignment: Alignment.center,
                                padding:
                                    const EdgeInsets.symmetric(vertical: 16.0),
                                child: Text(
                                  "OR",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: StyleView.fontSemiBold),
                                ),
                              ),
                            ],
                          ),
                        Container(
                          height: 50,
                          padding: EdgeInsets.only(top: 0, left: 8, right: 8),
                          decoration: AppUtills.boxDecoration(
                              customBorderColor:
                                  (offlineConnectonDropdown == null)
                                      ? Colors.black
                                      : Colors.grey),
                          child: TextFormField(
                            enabled: (offlineConnectonDropdown == null)
                                ? true
                                : false,
                            controller: shareOrderFormController,
                            decoration: InputDecoration(
                                hintText: Language().getString(
                                    Constants.ENTER_MOBILE_NUMBER,
                                    selectedLang),
                                border: InputBorder.none),
                            keyboardType: TextInputType.number,
                            inputFormatters: [
                              new LengthLimitingTextInputFormatter(10),
                              FilteringTextInputFormatter.digitsOnly
                            ],
                            onChanged: (value) => setState(() {
                              share_mobile_number = value;
                            }),
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Container(
                          child: Row(
                            children: [
                              Expanded(
                                child: SelectableText(
                                    "${Constants.SHARE_ORDER_FORM_URL}order-form/" +
                                        VyaparInfo.encryptData(shareData),
                                    style: TextStyle(
                                        fontSize: 15.0,
                                        fontWeight: FontWeight.bold,
                                        color: Color(Constants.APP_COLOR))),
                              ),
                              SizedBox(
                                width: 10,
                              ),
                              InkWell(
                                onTap: () {
                                  String url =
                                      "${Constants.SHARE_ORDER_FORM_URL}order-form/" +
                                          VyaparInfo.encryptData(shareData);
                                  FlutterClipboard.copy(url).then((value) => {
                                        print('copied'),
                                        Toast.show("Copied to clipboard",
                                            duration: Toast.lengthShort,
                                            gravity: Toast.bottom)
                                      });
                                },
                                child: Icon(
                                  Icons.copy,
                                  color: Color(Constants.APP_COLOR),
                                ),
                              )
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              );
            }),
          );
        });
  }

  shareOrderFormUrl(String url) {
    return showDialog(
        barrierDismissible: false,
        context: context,
        builder: (context) => AlertDialog(
              contentPadding: EdgeInsets.fromLTRB(10.0, 24.0, 0.0, 24.0),
              content: Container(
                height: 250.0,
                child: Column(
                  children: [
                    Text(
                      Language()
                          .getString("Share order form url", selectedLang),
                      textAlign: TextAlign.start,
                      style: TextStyle(
                          fontSize: 15.0,
                          fontWeight: FontWeight.bold,
                          color: Color(Constants.APP_COLOR)),
                    ),
                    Container(
                      margin: EdgeInsets.only(top: 50.0),
                      child: SelectableText(url),
                    )
                  ],
                ),
              ),
              actions: <Widget>[
                TextButton(
                  child: new Text(
                    Language().getString(Constants.CLOSE, selectedLang),
                    style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                        fontSize: StyleView.FONT_SIZE_15),
                  ),
                  onPressed: () => Navigator.of(context).pop(),
                ),
                SizedBox(width: 110.0),
                TextButton(
                  child: new Text(
                    Language().getString(
                        (kIsWeb)
                            ? Language().getString(Constants.COPY, selectedLang)
                            : Language()
                                .getString(Constants.SHARE, selectedLang),
                        selectedLang),
                    style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                        fontSize: StyleView.FONT_SIZE_15),
                  ),
                  onPressed: () {
                    if (kIsWeb) {
                      FlutterClipboard.copy(url).then((value) => {
                            print('copied'),
                            Toast.show("Copied to clipboard",
                                duration: Toast.lengthShort,
                                gravity: Toast.bottom)
                          });
                    } else {
                      SharePlus.instance.share(ShareParams(
                        text: url,
                        title: Language().getString(
                            Constants.APANAVYAPAR_INVITATION, selectedLang),
                        subject: Language().getString(
                            Constants.APANAVYAPAR_INVITATION, selectedLang),
                      ));
                      // Share.share(
                      //   url,
                      //   subject: Language().getString(
                      //       Constants.APANAVYAPAR_INVITATION, selectedLang),
                      // );
                    }
                  },
                ),
              ],
            ));
  }

  Widget _buildBody() {
    return AppBackgroundView(
      body: Stack(
        children: [
          WillPopScope(
              onWillPop: _alert,
              child: ChangeNotifierProvider<HomeViewModel?>.value(
                value: _homeViewModel,
                child: Consumer<HomeViewModel>(
                    builder: (context, model, child) => Container(
                          child: SafeArea(
                            child: Scaffold(
                                key: _scaffoldkey,
                                appBar: AppBar(
                                  actions: [
                                    IconButton(
                                        onPressed: () {
                                          Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                      NotificationPageView()));
                                        },
                                        icon: Icon(Icons.notifications_active))
                                  ],
                                  leading: null,
                                  iconTheme: IconThemeData(
                                      color: theme.colorScheme.primary),
                                  elevation: 0,
                                  backgroundColor: Colors.transparent,
                                  title: FxText.displayMedium(
                                      Language()
                                          .getString(appBarTitle, selectedLang),
                                      style: TextStyle(
                                          fontWeight: StyleView.fontSemiBold,
                                          fontSize: 17.0,
                                          color: theme.colorScheme.primary)),
                                  centerTitle: true,
                                ),
                                floatingActionButton:
                                    !(CommonMethods.isPrivillegeExist(context,
                                            PrivillegesActions.KEY_HOME_HELP))
                                        ? Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: ElevatedButton(
                                              onPressed: () async {
                                                Navigator.push(
                                                    context,
                                                    PageTransition(
                                                        context: context,
                                                        page:
                                                            HelpChatScreenView()));
                                              },
                                              style: ElevatedButton.styleFrom(
                                                backgroundColor: theme
                                                    .colorScheme
                                                    .primary, // Button color
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          30.0), // Rounded corners
                                                ),
                                                padding: EdgeInsets.symmetric(
                                                    horizontal: 10,
                                                    vertical:
                                                        12), // Button padding
                                              ),
                                              child: Row(
                                                mainAxisSize: MainAxisSize.min,
                                                children: [
                                                  Icon(Icons.support_agent,
                                                      color: Colors
                                                          .white), // Optional icon
                                                  SizedBox(
                                                      width:
                                                          10), // Spacing between icon and text
                                                  Text(
                                                    Language().getString(
                                                        Constants.STR_ASK_HELP,
                                                        selectedLang),
                                                    style: TextStyle(
                                                        color: Colors.white,
                                                        fontSize: 16),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          )
                                        : Container(),
                                drawer: MyDrawer(buList: model.buList),
                                backgroundColor: Colors.transparent,
                                body: (buList.length > 0)
                                    ? Container(
                                        child: LayoutBuilder(builder:
                                            (BuildContext context,
                                                BoxConstraints boxConstrainst) {
                                          return Container(
                                            margin: EdgeInsets.only(
                                                top: (kIsWeb) ? 20 : 10),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: [
                                                Container(
                                                    child: showAllBusinessList(
                                                        "")),
                                                if (listValues.length > 0 &&
                                                    _gridImages.length > 0)
                                                  Expanded(
                                                      child: Container(
                                                    margin:
                                                        EdgeInsets.only(top: 0),
                                                    child: GridView.builder(
                                                      padding:
                                                          EdgeInsets.all(15),
                                                      gridDelegate:
                                                          SliverGridDelegateWithFixedCrossAxisCount(
                                                        crossAxisCount: ((kIsWeb ||
                                                                    Platform
                                                                        .isWindows) &&
                                                                boxConstrainst
                                                                        .maxWidth >
                                                                    800)
                                                            ? listValues.length
                                                            : (kIsWeb ||
                                                                    Platform
                                                                        .isWindows)
                                                                ? 2
                                                                : 2,
                                                        mainAxisSpacing: 5.0,
                                                        crossAxisSpacing: 5.0,
                                                      ),
                                                      itemBuilder: (_, index) {
                                                        return gridCardViewData(
                                                            index);
                                                      },
                                                      itemCount:
                                                          listValues.length,
                                                    ),
                                                  ))
                                              ],
                                            ),
                                          );
                                        }),
                                      )
                                    : Container(
                                        child:
                                            showCreateBusinessUnitMessage())),
                          ),
                        )),
              )),
          AppUtills.showLoadingView(
              context: context,
              message: Language().getString(progressMessage, selectedLang),
              isLoading: isLoadingProgress),
        ],
      ),
    );
  }

  @override
  void setState(VoidCallback fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  Widget build(BuildContext context) {
    ToastContext().init(context);
    return FxBuilder(
        controller: _homeController,
        builder: (_homeController) => _buildBody());
  }

  Widget showCreateBusinessUnitMessage() {
    return Center(
      child: Visibility(
        visible: isBuListEmpty,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              margin: EdgeInsets.symmetric(
                vertical: 10.0,
              ),
              child: Text(
                "Welcome to Vyapar Live",
                style: TextStyle(
                    fontSize: 18.0,
                    fontWeight: StyleView.fontMedium,
                    color: theme.colorScheme.primary),
              ),
            ),
            Container(
              margin: EdgeInsets.symmetric(
                vertical: 10.0,
              ),
              child: InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => CreateBUView(
                        title: Constants.CREATE_BUSINESS_UNIT,
                        isOrgUpdate: false,
                      ),
                    ),
                  ).then((value) {
                    this.loadHomePageServiceCalls();
                  });
                },
                child: Text(
                    "To get started\nSetup your Organisation - Click Here",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        decoration: TextDecoration.underline,
                        fontSize: 17.0,
                        fontWeight: StyleView.fontRegular,
                        color: theme.colorScheme.primary)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget showBusinessUnitList(model) {
    return Container(
      padding: EdgeInsets.only(
        left: 8,
        right: 5,
      ),
      decoration: ShapeDecoration(
        shape: RoundedRectangleBorder(
          side: BorderSide(
              width: 0.5, color: Colors.white, style: BorderStyle.solid),
          borderRadius: BorderRadius.all(Radius.circular(5.0)),
        ),
      ),
      child: DropdownButton<BuBasicDataModel>(
          icon: Icon(
            Icons.arrow_drop_down_outlined,
            color: theme.colorScheme.primary,
          ),
          value: dropdownValue,
          isExpanded: true,
          hint: Text(Language().getString(Constants.SELECT_BU, selectedLang)),
          underline: SizedBox(),
          onChanged: (BuBasicDataModel? data) async {
            // loadHomePageServiceCalls();

            setState(() {
              dropdownValue = data;
              AppController.instance.setMyBuId = data!.id;
              AppController.instance.setBuName = data.businessName;
              SharePref().saveHomePageSelectedBuId(dropdownValue!.id!);
              AppController.instance.setBuCurrencySymbol =
                  data.orgCurrencySymbol;
              listValues.clear();
            });
            updateBuFeatures();
          },
          items: buList.map((BuBasicDataModel buModel) {
            return new DropdownMenuItem<BuBasicDataModel>(
              child: new Text(
                buModel.businessName!,
                style: TextStyle(fontWeight: StyleView.fontSemiBold),
              ),
              value: buModel,
            );
          }).toList()),
    );
  }

  showRecentActivities() {
    return Container(
        child: ListView.builder(
            shrinkWrap: true,
            itemBuilder: (context, index) => InkWell(
                  onTap: () {
                    Navigator.push(
                        context,
                        PageTransition(
                          context: context,
                          page: ListOfTransactionsPage(
                            transactionId: _homeViewModel!
                                .notificationsList[index].transactionId,
                          ),
                        ));
                  },
                  child: this.designNotificationCard(
                      _homeViewModel!.notificationsList[index]),
                ),
            itemCount: _homeViewModel!.notificationsList.length));
  }

  designNotificationCard(NotificationsDAO notificationData) {
    String? notificationSender = "";
    String? message = "";
    if (notificationData.buyer!.id == AppController.instance.getMyBuId) {
      notificationSender = notificationData.seller!.name;
    } else {
      notificationSender = notificationData.buyer!.name;
    }

    message = AppUtills.getNotificationMessage(notificationSender,
        notificationData.notificationType, notificationData.buyer!.id);

    return Container(
      child: Card(
        elevation: 2.0,
        color: Colors.grey[100],
        child: Padding(
          padding: const EdgeInsets.all(5.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      "$message",
                      style: CustomTextStyle.subHeaderTextStyle(),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 5,
              ),
              Container(
                margin: EdgeInsets.symmetric(
                  vertical: 5.0,
                ),
                child: Text(
                  AppUtills.getDateFormate(
                      notificationData.createdDate.toString()),
                  style: CustomTextStyle.subHeaderTextStyle(),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  containerDecoration(Color? backgroudColor, Color? borderColor) {
    return BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Colors.white),
        boxShadow: [
          BoxShadow(
              offset: Offset(0.0, 1.0),
              color: Colors.grey[400]!,
              blurRadius: 3.0)
        ]);
  }

  colorsHandling(int index) {
    if (index == 0) {
      if (updateNotifications[0]["Orders"] != 0) {
        return Colors.red;
      } else {
        return Colors.transparent;
      }
    } else if (index == 1) {
      if (updateNotifications[1]["Payments"] != 0) {
        return Colors.red;
      } else {
        return Colors.transparent;
      }
    } else if (index == 2) {
      if (updateNotifications[2]["Invitations"] != 0) {
        return Colors.red;
      } else {
        return Colors.transparent;
      }
    }
    if (index == 3) {
      if (updateNotifications[3]["Stock Delivery"] != 0) {
        return Colors.red;
      } else {
        return Colors.transparent;
      }
    }
  }

  displayNotificationsCount(int index) {
    if (index == 0) {
      return buildNotificationIconView(updateNotifications[0]["Orders"]);
    } else if (index == 1) {
      return buildNotificationIconView(updateNotifications[1]["Payments"]);
    } else if (index == 2) {
      return buildNotificationIconView(updateNotifications[2]["Invitations"]);
    } else if (index == 3) {
      return buildNotificationIconView(
          updateNotifications[3]["Stock Delivery"]);
    }
  }

  buildNotificationIconView(var notification) {
    if (notification != 0 && notification != null) {
      return Container(
          child: Text(
        "$notification",
        style: TextStyle(
          color: Colors.white,
          fontSize: 8,
        ),
        textAlign: TextAlign.center,
      ));
    }
  }

  void registerNotification() async {
    FirebaseMessaging _fcm = FirebaseMessaging.instance;
    await Future.delayed(Duration(seconds: 1));
    await _fcm.getToken().then((token) async {
      print("Firebase token : $token");
      try {
        SharePref().getUserId().then((onValue) async {
          setState(() {
            userId = onValue;
          });
          SharePref().saveFirebaseToken(token!);
          String body = json.encode({"id": userId, "firebase_token": token});
          updateFirebaseToken(body);
        });
      } catch (err) {}
    }).catchError((err) {
      Toast.show(err.message.toString(),
          duration: Toast.lengthShort, gravity: Toast.bottom);
    });
    _fcm.requestPermission();
    FirebaseMessaging.onMessage.listen((message) {
      configLocalNotification(message);
      showNotification(message.notification, message);
      return;
    });

    FirebaseMessaging.onMessageOpenedApp.listen((message) async {
      _homeViewModel!
          .setFcmNotificationState(FcmNotficationState.NEW_FCM_NOTIFICATION);
      _homeViewModel!.notificationRoute(context, message.data);
      return;
    });
  }

  Future updateFirebaseToken(String? body) async {
    var response = await _userService
        .updateFirebaseToken_grpc(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      print("Update firebase token $resObj");
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message!,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  void configLocalNotification(RemoteMessage remoteMessage) {
    initializationSettingsAndroid =
        new AndroidInitializationSettings('@mipmap/ic_launcher');
    initializationSettingsIOS = new DarwinInitializationSettings();
    //get icon from android/manifest
    InitializationSettings initializationSettings = new InitializationSettings(
        android: initializationSettingsAndroid, iOS: initializationSettingsIOS);
    flutterLocalNotificationsPlugin.initialize(initializationSettings,
        onDidReceiveNotificationResponse: (notification) async {
      _homeViewModel!
          .setFcmNotificationState(FcmNotficationState.NEW_FCM_NOTIFICATION);
      _homeViewModel!.notificationRoute(context, remoteMessage.data);
    });
  }

  void showNotification(RemoteNotification? remoteNotification,
      RemoteMessage? remoteMessage) async {
    final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
        new FlutterLocalNotificationsPlugin();
    var androidPlatformChannelSpecifics = new AndroidNotificationDetails(
      Platform.isAndroid ? 'com.mrsoft.vyaparlive' : 'com.mr.vyaparlive',
      'Vyapar Live',
      playSound: true,
      enableVibration: true,
      importance: Importance.max,
      priority: Priority.high,
    );
    var iOSPlatformChannelSpecifics = new DarwinNotificationDetails();
    var platformChannelSpecifics = new NotificationDetails(
        android: androidPlatformChannelSpecifics,
        iOS: iOSPlatformChannelSpecifics);

    await flutterLocalNotificationsPlugin.show(0, remoteNotification!.title,
        remoteNotification.body, platformChannelSpecifics,
        payload: remoteMessage.toString());
  }

  void startNavigate(Map<String, dynamic> notification) {
    _homeViewModel!.notificationRoute(context, notification);
  }

  bool isNotificationViewed(String notificationId) {
    return AppController.instance.notificationsViewedList
        .contains(notificationId);
  }

  Widget showAllRecentActivitesList(model) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.40,
      child: Card(
        elevation: 5.0,
        margin: EdgeInsets.symmetric(vertical: 5, horizontal: 12),
        color: Colors.blue[50],
        child: Container(
          decoration: BoxDecoration(
              image: DecorationImage(
                  image: AssetImage("assets/images/chat_image_8.png"),
                  fit: BoxFit.cover)),
          constraints: BoxConstraints(
              minHeight: 100.0,
              maxHeight: model.notificationsList.length > 0 ? 150.0 : 100.0),
          padding: EdgeInsets.all(5.0),
          width: MediaQuery.of(context).size.width,
          child: RefreshIndicator(
            onRefresh: () {
              model.getNotifications(AppController.instance.getMyBuId);
              return Future.delayed(Duration(seconds: 2));
            },
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      margin: EdgeInsets.only(left: 10),
                      child: Text(
                        Language().getString(
                                Constants.RECENT_ACTIVITY, selectedLang) +
                            " :",
                        style: CustomTextStyle.headerTextStyle(),
                      ),
                    ),
                    SizedBox(width: 10),
                    (model.aAppNotificationState ==
                            AppNotificationState.NOTIFICATION_LOADING)
                        ? SizedBox(
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                            ),
                            height: 15.0,
                            width: 15.0,
                          )
                        : Container(),
                  ],
                ),
                Expanded(
                  child: Container(
                      margin: EdgeInsets.only(top: 5.0),
                      child: (model.notificationsList.length > 0)
                          ? this.showRecentActivities()
                          : Container(
                              margin: EdgeInsets.only(left: 10),
                              child: Text(
                                Language().getString(
                                    Constants.NO_ACTIVITY, selectedLang),
                                style: CustomTextStyle.regularTextStyle(),
                              ),
                            )),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget showAllBusinessList(model) {
    return Container(
        margin: EdgeInsets.symmetric(horizontal: 15),
        child: Card(
            elevation: 10,
            shadowColor: Colors.white,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
                side: BorderSide(color: theme.colorScheme.primary)),
            child: Padding(
              padding: EdgeInsets.all(1.0),
              child: this.showBusinessUnitList(model),
            )));
  }

  Future<List<BuBasicDataModel>> getUserBuList() async {
    listValues.clear();
    String body = json.encode({"id": userId});
    var response = await _organizationService
        .getBulistByUserId(body: body, token: "")
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    setState(() {
      isLoadingProgress = false;
    });
    List<BuBasicDataModel> _list = [];
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var responseBody = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(responseBody)) {
        for (var obj in responseBody) {
          _list.add(BuBasicDataModel.fromJson(obj));
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message!,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    return _list;
  }

  List<String> updateListItems(featureList) {
    for (var element in featureList) {
      if (element == PrivillegesActions.KEY_HOME_PRODUCTS) {
        listValues.add(Constants.STR_PRODUCTS);
        _gridImages.add('assets/images/products_icon.png');
      }
      if (element == PrivillegesActions.KEY_HOME_RETAIL) {
        listValues.add(Constants.STR_RETAIL);
        _gridImages.add('assets/images/retail_icon.png');
      }
      if (element == PrivillegesActions.KEY_HOME_CREATE_PURCHASE_ORDER) {
        listValues.add(Constants.STR_CREATE_PURCHASE_ORDER);
        _gridImages.add('assets/images/orders_icon.png');
      }
      if (element == PrivillegesActions.KEY_HOME_ONLINE_CONNECTIONS) {
        listValues.add(Constants.STR_ONLINE_CONNECTIONS);
        _gridImages.add('assets/images/orders_icon.png');
      }
      if (element == PrivillegesActions.KEY_HOME_OFFLINE_CONNECTIONS) {
        listValues.add(Constants.STR_OFFLINE_CONNECTIONS);
        _gridImages.add('assets/images/on_site_icon.png');
      }
      if (element == PrivillegesActions.KEY_HOME_MY_COMPANY) {
        listValues.add(Constants.STR_MY_COMPANY);
        _gridImages.add('assets/images/customer_icon.png');
      }
      if (element == PrivillegesActions.KEY_HOME_ONDC) {
        listValues.add(Constants.ONDC_STR);
        _gridImages.add('assets/images/ondc_marketplace.png');
      }
      if (element == PrivillegesActions.KEY_HOME_SHARE_ORDER_FORM) {
        listValues.add(Constants.STR_SHARE_ORDER_FORM);
        _gridImages.add('assets/images/customer_icon.png');
      }
    }

    return listValues;
  }
}
