import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:custom_searchable_dropdown/custom_searchable_dropdown.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:flutx/flutx.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/DateFilterUtil.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/Contacts.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/NotificationsDAO.dart';
import 'package:http/http.dart' as http;
import 'package:vyaparlive/notifications_view/NotificationCard.dart';
import 'dart:convert';

import 'package:vyaparlive/service/Service.dart';
import 'package:vyaparlive/service/invitation_services.dart';

import '../core/locator.dart';
import '../core/view_models/homeview_model.dart';

class NotificationPageView extends StatefulWidget {
  @override
  _NotificationPageViewState createState() => _NotificationPageViewState();
}

class _NotificationPageViewState extends State<NotificationPageView>
    with TickerProviderStateMixin {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? buName = "";
  String? buId = "";
  // ProgressDialog progressDialog;
  List<NotificationsDAO> notificationsList = [];
  List<NotificationsDAO> responseNotificationsList = [];
  bool isLoading = false;
  late Service _service;
  var startDate;
  var endDate;
  DateFormat formatter = DateFormat("yyyy-MM-dd");
  DateTime selectedDate = DateTime.now();
  final double calendarHeight = 40.0;
  List<Contacts> _contactsModel = [];
  Contacts? connectionName;
  final List<DropdownMenuItem> searchItems = [];
  String params = "";
  String todayDate = "";
  String? convertedDate = "";
  bool isLoadingProgress = true;
  String progressMessage = Constants.GETTING_DATA;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  late InvitationService _invitationService;
  DateTime mnthStartDate =
      DateTime.utc(DateTime.now().year, DateTime.now().month, 1);
  late ThemeData theme;
  late TextEditingController _fromDateController;
  late TextEditingController _toDateController;
  late AnimationController _animationController;
  HomeViewModel? _homeViewModel = locator<HomeViewModel>();

  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    initBottomSheetAnimation();
    _invitationService = InvitationService();
    startDate = formatter.format(DateTime.now().subtract(Duration(days: 7)));
    endDate = formatter.format(DateTime.now());
    todayDate = formatter.format(DateTime.now());
    _service = Service();
    _fromDateController = new TextEditingController(
        text: formatter.format(DateTime.now().subtract(Duration(days: 7))));
    _toDateController =
        new TextEditingController(text: formatter.format(DateTime.now()));
    buName = AppController.instance.getBuName;
    buId = AppController.instance.getMyBuId;

    convertedDate = AppUtills.getOneDayAddedDate(endDate);
    params =
        "?${Constants.DATE_FROM}$startDate&${Constants.DATE_TO}$convertedDate";
    Future.delayed(Duration(seconds: 1)).then((value) {
      serviceCallNotifications(params);
      isLoadingProgress = true;
      loadConnectionsData();
    });
  }

  initBottomSheetAnimation() {
    _animationController = BottomSheet.createAnimationController(this);
    _animationController.duration =
        const Duration(milliseconds: Constants.bottomSheet_duration);
    _animationController.reverseDuration =
        const Duration(milliseconds: Constants.bottomSheet_reverse_duration);
    _animationController.drive(CurveTween(curve: Curves.easeIn));
  }

  serviceCallNotifications(String params) async {
    if (await NetworkStatus.getInternetStatus()) {
      getNotifications(buId!, params).then((value) {
        setState(() {
          notificationsList.addAll(value);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  loadConnectionsData() {
    // setState(() {
    //   isLoadingProgress = true;
    // });

    this.getContacts(buId).then((onValue) {
      _contactsModel.addAll(onValue);
    });
  }

  Future<List<Contacts>> getContacts(String? buId) async {
    setState(() {
      _contactsModel.clear();
    });
    String body = json.encode({"buId": buId, "filters": {}});

    var response = await _invitationService
        .findAllConnections_grpc(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<Contacts> _model = [];
    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);

      for (var noteJson in resObj['results']) {
        _model.add(Contacts.fromJson(noteJson));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
      return _model;
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Widget buildSearchView() {
    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: ListView(
        shrinkWrap: true,
        children: [
          DateFilterUtill(
            isShowSearchButton: true,
            fromDate: "",
            toDate: "",
            fromDateController: _fromDateController,
            toDateController: _toDateController,
            onFromDateSelected: (value) {
              setState(() {
                // startDate = value;
                _fromDateController.text = value;
              });
            },
            onToDateSelected: (value) {
              setState(() {
                // endDate = value;
                _toDateController.text = value;
              });
            },
            onSearchParms: () {
              setState(() {
                isLoadingProgress = true;
              });
              if (endDate == todayDate) {
                convertedDate = AppUtills.getOneDayAddedDate(endDate);
              } else {
                convertedDate = endDate;
              }
              params =
                  "?${Constants.DATE_FROM}${_fromDateController.text}&${Constants.DATE_TO}${_toDateController.text}" +
                      "&name=${connectionName != null ? connectionName!.buName : ""}";
              print(params);
              serviceCallNotifications(params);
            },
          ),
          FxSpacing.height(10.0),
          Container(child: showConnectionsList()),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
      body: Stack(
        children: [
          WillPopScope(
            onWillPop: () {
              return CommonMethods.onBackPress(context).then((value) => value);
            },
            child: SafeArea(
              child: Scaffold(
                key: _scaffoldkey,
                backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                appBar: AppBar(
                  iconTheme: IconThemeData(color: theme.colorScheme.primary),
                  backgroundColor: Colors.transparent, //(Constants.APP_COLOR),
                  centerTitle: true,
                  elevation: 0,
                  title: AppbarName(
                      title: Language()
                          .getString(Constants.NOTIFICATIONS_STR, selectedLang),
                      buName: "$buName"),
                ),
                // drawer: MyDrawer(),
                body: Container(
                  margin: EdgeInsets.all(5.0),
                  child: RefreshIndicator(
                    onRefresh: () {
                      serviceCallNotifications("");
                      return Future.delayed(Duration(seconds: 3));
                    },
                    child: Column(
                      children: [
                        buildSearchView(),
                        Expanded(
                          child: (notificationsList.length > 0)
                              ? Container(
                                  margin: EdgeInsets.only(top: 20.0),
                                  child: AnimationLimiter(
                                    child: ListView.builder(
                                      shrinkWrap: true,
                                      itemBuilder: (context, index) =>
                                          AnimationConfiguration.staggeredList(
                                              position: index,
                                              child: SlideAnimation(
                                                  verticalOffset: 50.0,
                                                  child: FadeInAnimation(
                                                      child: notificationCard(
                                                          notificationsList[
                                                              index])))),
                                      itemCount: notificationsList.length,
                                    ),
                                  ),
                                )
                              : Center(
                                  child: Text(
                                  Language().getString(
                                      Constants.NO_DATA_FOUND, selectedLang),
                                )),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
          AppUtills.showLoadingView(
              context: context,
              message: Language().getString(progressMessage, selectedLang),
              isLoading: isLoadingProgress),
        ],
      ),
    );
  }

  notificationCard(NotificationsDAO notificationData) {
    String? notificationSender = "";
    String? message = "";
    if (notificationData.buyer!.id == AppController.instance.getMyBuId) {
      notificationSender = notificationData.seller!.name;
    } else {
      notificationSender = notificationData.buyer!.name;
    }
    message = AppUtills.getNotificationMessage(notificationSender,
        notificationData.notificationType, notificationData.buyer!.id);

    return NotificationCard(
      message: message,
      notificationDate: notificationData.createdDate,
      onNotificationClick: () {
        Map<String, dynamic> data = {
          "notification_type": notificationData.notificationType,
          "notification_id": notificationData.id,
          "transaction_id": notificationData.transactionId
        };
        _homeViewModel!.notificationRoute(context, data,fromNotificationScreen: true);
      },
    );
  }

  showConnectionsList() {
    return Container(
        decoration: AppUtills.boxDecoration(),
        child: CustomSearchableDropDown(
          items: _contactsModel.toList(),
          label:
              Language().getString(Constants.SEARCH_BY_BUSINESS, selectedLang),
          labelStyle:
              TextStyle(fontWeight: StyleView.fontSemiBold, fontSize: 14.0),
          suffixIcon: Padding(
            padding: const EdgeInsets.all(0.0),
            child: Icon(Icons.search),
          ),
          dropDownMenuItems: _contactsModel.map((item) {
            return item.buName;
          }).toList(),
          onChanged: (value) {
            if (value != null) {
              setState(() {
                connectionName = value;
                isLoadingProgress = true;
                params = "?name=${connectionName!.buName!}" +
                    "&${Constants.DATE_FROM}${_fromDateController.text}&${Constants.DATE_TO}${_toDateController.text}";
                serviceCallNotifications(params);
              });
            }
            // else {
            //   setState(() {
            //     isLoadingProgress = true;
            //     params =
            //         "?${Constants.DATE_FROM}$startDate&${Constants.DATE_TO}$convertedDate";
            //     serviceCallNotifications(params);
            //   });
            // }
          },
        ));
  }

  Future<List<NotificationsDAO>> getNotifications(
      String buId, String params) async {
    notificationsList.clear();
    Map<String, dynamic> mapData = {"id": buId};
    String body = json.encode(mapData);
    http.Response response = await _service
        .getNotifications(buId, params)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<NotificationsDAO> _model = [];
    isLoading = true;

    setState(() {
      isLoadingProgress = false;
    });

    if (response.statusCode == 200) {
      var data = json.decode(response.body);
      bool isString = false;
      if (data['data'] is String) {
        isString = true;
      }
      if (!isString) {
        var resultArray = data['data']['results'];
        for (var dataObject in resultArray) {
          _model.add(NotificationsDAO.fromJson(dataObject));
        }
      }
    } else if (response.statusCode == 401) {
      CommonMethods.handleUnauthorizedAccess(context);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          response.body,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    return _model;
  }
}
