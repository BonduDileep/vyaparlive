import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:vyaparlive/components/AppUtills.dart';

class NotificationCard extends StatelessWidget {
  final String? message;
  final DateTime? notificationDate;
  final VoidCallback? onNotificationClick;

  NotificationCard({
    this.message,
    this.notificationDate,
    this.onNotificationClick
  });
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: (){
        onNotificationClick!();
      },
      child: Card(
        shadowColor: AppTheme.vyaparTheme.colorScheme.primary,
        elevation: 8.0,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Container(
                      child: Text(
                        "$message",
                        style: TextStyle(
                            color: Colors
                                .black, //AppTheme.vyaparTheme.colorScheme.primary,
                            fontWeight: StyleView.fontSemiBold),
                      ),
                    ),
                  ),
                ],
              ),
              Container(
                margin: EdgeInsets.symmetric(vertical: 5.0),
                child: Text(
                  AppUtills.getDateFormate(notificationDate.toString()),
                  style: TextStyle(
                      fontSize: 13.0, fontWeight: StyleView.fontRegular),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
