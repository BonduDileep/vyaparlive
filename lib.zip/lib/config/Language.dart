import 'dart:collection';
import 'package:flutter/services.dart';
import 'package:spreadsheet_decoder/spreadsheet_decoder.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/dao/LanguageDao.dart';

var languageStrings = [];
Map languages = {};
HashMap hashMap = new HashMap<int, String>();
List<LanguageDao> languagesList = [];
List<LanguageDao> langs = [];

List<String> sample = [];
List<String> listTab = [];
List<String> list = [];

class Language {
  getString(str, selectedLang) {
    String? languageString = str;
    languagesList = AppController.instance.getLanguageData;
    languagesList.forEach((item) {
      if (item.english != null) {
        if (item.english == str) {
          if (selectedLang == 'en') {
            languageString = str;
          } else if (selectedLang == 'te') {
            if (item.telugu != null) {
              languageString = item.telugu;
            }
          } else {
            if (item.hindi != null) {
              languageString = item.hindi;
            }
          }
        }
      }
    });
    if (selectedLang == 'en') {
      return languageString;
    } else {
      return languageString;
    }
  }

  // this function is unneccessarily used - need to remove in all classes with proper check
  Future<void> loadFile() async {
    // print('load file data from local storage');
  }

  Future<void> loadLanguageFile() async {
    if (AppController.instance.isLanguageFileLoaded) {
      return;
    }

    // if (kIsWeb) {
    //   return;
    // }
    try {
      // String dir = (await getApplicationDocumentsDirectory()).path;

      // var file =
      //     new File('$dir/language_strings_vyapar_live.xlsx').readAsBytesSync();
      // var decoder = new SpreadsheetDecoder.decodeBytes(file);
      ByteData data = await rootBundle
          .load('assets/lang/language_strings_vyapar_live.xlsx');
      var decoder = SpreadsheetDecoder.decodeBytes(data.buffer.asUint8List());

      var table = decoder.tables['Sheet2']!;
      var fields;
      fields = table.rows;

      for (var i = 0; i < fields.length; i++) {
        LanguageDao languageDao = LanguageDao(
            english: fields[i][1], hindi: fields[i][2], telugu: fields[i][3]);
        languagesList.add(languageDao);
      }
      AppController.instance.setlanguageData = languagesList;
      AppController.instance.setIsLanguageFileLoaded = true;
    } catch (e) {
      print("language : $e");
    }
  }
}
