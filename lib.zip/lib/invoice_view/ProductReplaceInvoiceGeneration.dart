import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/invoice_view/BatchPriceDropdownView.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/InvoiceDAO.dart';
import 'package:vyaparlive/model/ModelProduct.dart';
import 'package:vyaparlive/model/bu_model/PaymentTermsModel.dart';
import 'package:vyaparlive/model/product_model/BatchPriceDAO.dart';
import 'package:vyaparlive/model/product_model/OffersDAO.dart';
import 'package:vyaparlive/model/product_model/ProductModel.dart';
import 'dart:convert';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/service/bu_list_grpc_service.dart';
import 'package:vyaparlive/service/organization_service.dart';
import 'package:vyaparlive/service/product_services.dart';

class ProductReplaceInvoiceGeneratePage extends StatefulWidget {
  final List<ModelProduct>? products;
  final String? transactionId;
  final String? termType;
  final String? invoiceNo;
  final String? buyerId;
  final String? invoiceId;
  ProductReplaceInvoiceGeneratePage(
      {this.products,
      this.transactionId,
      this.termType,
      this.invoiceNo,
      this.buyerId,
      this.invoiceId});
  @override
  _ProductReplaceInvoiceGeneratePageState createState() =>
      _ProductReplaceInvoiceGeneratePageState();
}

class _ProductReplaceInvoiceGeneratePageState
    extends State<ProductReplaceInvoiceGeneratePage> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? buName = "";
  String? radioButtonValue = "";
  String discountType = "";
  static const String OFFER_IN_PERCENTAGE = "Discount in percentage";
  static const String OFFER_IN_RUPEES = "Discount in rupees";
  static const String CONNECTION_TERMS = "Connection Specific Terms";
  static const String BU_TERMS = "Business Unit Terms";
  String? termsRadioButtonValue = "";
  final _rupeeController = TextEditingController();
  String? offerInPercentage;
  List<ModelProduct> selectedProductsList = [];
  int? _selectedCount = 0;
  bool isOfferActive = false;
  final List<TextEditingController> unitPriceController = [];
  String termType = "";
  String buttonText = "";

  List<InvoiceDAO> _invoiceData = [];
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  String url = "";
  late BuListGrpcService _transactionService;
  List<TextEditingController> _quantityInputController = [];
  bool isEnableTextEditingController = true;
  List<BatchPriceDAO?> batchPriceDropdown = [];
  List<BuProductModal> _productList = [];
  String? buId = "";
  List<bool> isShowBatchPrice = [];
  late ProductService _productService;
  String? orgCurrencySymbol = "";
  late OrganizationService _organizationService;
  PaymentTerms? termsData;
  List<ModelProduct> tempProductList = [];
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  List<ModelProduct> invoiceProductsList = [];
  double editControllerBottomMargin = 15;
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _productService = ProductService();
    _organizationService = OrganizationService();
    buId = AppController.instance.getMyBuId;
    _transactionService = BuListGrpcService();
    termsRadioButtonValue = CONNECTION_TERMS;
    termType = "connection";
    loadInvoiceData();
    buName = AppController.instance.getBuName;
    orgCurrencySymbol = AppController.instance.getBuCurrencySymbol;
    if (kIsWeb) {
      editControllerBottomMargin = 20;
    }
  }

  loadInvoiceData() async {
    buttonText = "Re Generate Invoice";
    if (await NetworkStatus.getInternetStatus()) {
      this.getInvoiceData().then((value) {
        _invoiceData.addAll(value);
        if (_invoiceData.length > 0) {
          if (_invoiceData[0].invoiceDetails!.replacedProducts!.length > 0) {
            this.updateProductsData(
                _invoiceData[0].invoiceDetails!.replacedProducts!);
          } else {
            this.updateProductsData(_invoiceData[0].invoiceDetails!.products!);
          }
        }
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        AppBackgroundView(
          body: SafeArea(
            child: Scaffold(
              key: _scaffoldkey,
              backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
              appBar: AppBar(
                centerTitle: true,
                elevation: 0,
                iconTheme: IconThemeData(color: theme.colorScheme.primary),
                backgroundColor: Colors.transparent, //Color(Constants.APP_COLOR),
                title: AppbarName(
                    title: Language()
                        .getString(Constants.RE_GENERATE_INVOICE, selectedLang),
                    buName: buName),
                actions: [
                  AppUtills.homeButton(context),
                ],
              ),
              bottomNavigationBar: (_invoiceData.length > 0)
                  ? Container(
                      padding:
                          EdgeInsets.only(left: 10.0, right: 10.0, bottom: 30),
                      child: CommonButtonsView(
                        context: context,
                        b1Text: "",
                        b2Text: Language().getString(buttonText, selectedLang),
                        onb1Action: () {},
                        onb2Action: () {
                          renerationProductsPopup();
                        },
                      ))
                  : null,
              body: Container(
                decoration: AppUtills.appBackgroundWithImage(),
                margin: EdgeInsets.symmetric(
                  vertical: 10.0,
                  horizontal: 5.0,
                ),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(bottom: 5.0),
                      child: Row(
                        children: [
                          Expanded(
                            child: Row(children: [
                              Container(
                                child: Radio(
                                  value: CONNECTION_TERMS,
                                  groupValue: termsRadioButtonValue,
                                  onChanged: (dynamic values) {
                                    setState(() {
                                      termsRadioButtonValue = values;
                                      termType = "connection";
                                    });
                                  },
                                  materialTapTargetSize:
                                      MaterialTapTargetSize.shrinkWrap,
                                ),
                              ),
                              Expanded(
                                  child: Row(
                                children: [
                                  Expanded(
                                      child: Text(
                                          Language().getString(
                                              CONNECTION_TERMS, selectedLang),
                                          style: TextStyle(fontSize: 14.0))),
                                  InkWell(
                                      onTap: () async {
                                        await this
                                            .serviceCallGetTerms(
                                                termType: "connection")
                                            .then((value) {
                                          termsData = value;
                                        });
            
                                        if (termsData != null) {
                                          this.showTermsDataView(
                                              CONNECTION_TERMS);
                                        }
                                      },
                                      child: Icon(Icons.info,
                                          size: 20.0,
                                          color: theme.colorScheme.primary))
                                ],
                              ))
                            ]),
                          ),
                          Expanded(
                            child: Row(children: [
                              Container(
                                child: Radio(
                                  value: BU_TERMS,
                                  groupValue: termsRadioButtonValue,
                                  onChanged: (dynamic values) {
                                    setState(() {
                                      termsRadioButtonValue = values;
                                      termType = "bu";
                                    });
                                  },
                                  materialTapTargetSize:
                                      MaterialTapTargetSize.shrinkWrap,
                                ),
                              ),
                              Expanded(
                                  child: Row(
                                children: [
                                  Expanded(
                                      child: Text(
                                    Language().getString(BU_TERMS, selectedLang),
                                    style: TextStyle(fontSize: 14.0),
                                  )),
                                  InkWell(
                                      onTap: () async {
                                        await serviceCallGetTerms(termType: "bu")
                                            .then((value) {
                                          termsData = value;
                                        });
            
                                        if (termsData != null) {
                                          showTermsDataView(BU_TERMS);
                                        }
                                      },
                                      child: Icon(Icons.info,
                                          size: 20.0,
                                          color: theme.colorScheme.primary))
                                ],
                              ))
                            ]),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                            border:
                                Border.all(color: Color(Constants.APP_COLOR))),
                        child: Column(
                          children: [
                            Container(
                              child: Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: Row(
                                  children: [
                                    Expanded(
                                      flex: 2,
                                      child: Text(
                                        Language().getString(
                                            Constants.PRODUCTS_STR, selectedLang),
                                        style: TextStyle(
                                          color: Color(Constants.APP_COLOR),
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      flex: 2,
                                      child: Text(
                                        Language().getString(
                                            Constants.QUANTITY, selectedLang),
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          color: Color(Constants.APP_COLOR),
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      child: Text(
                                        Language().getString(Constants.PRICE_UNIT,
                                                selectedLang) +
                                            " ( $orgCurrencySymbol )",
                                        style: TextStyle(
                                          color: Color(Constants.APP_COLOR),
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      child: Text(
                                        Language().getString(
                                            Constants.OFFER, selectedLang),
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          color: Color(Constants.APP_COLOR),
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Divider(
                              color: Color(Constants.APP_COLOR),
                            ),
                            Expanded(
                              child: Container(
                                child: ListView.separated(
                                  separatorBuilder: (context, index) => Divider(
                                    color: Colors.transparent,
                                    height: 5.0,
                                  ),
                                  itemBuilder: (context, index) {
                                    return Container(
                                      child: this.renderProductDataDesign(index),
                                    );
                                  },
                                  itemCount: selectedProductsList.length,
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    );
  }

  /// Desinging for show products data in ROW
  renderProductDataDesign(int index) {
    return Container(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(5.0),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    flex: 2,
                    child: Row(
                      children: [
                        Container(
                          height: 20.0,
                          width: 25.0,
                          child: Checkbox(
                              activeColor: Color(Constants.APP_COLOR),
                              value: selectedProductsList[index].isButton,
                              onChanged: (value) {
                                setState(() {
                                  selectedProductsList[index].isButton = value;
                                  tempProductList[index].isButton = value;
                                });
                              }),
                        ),
                        Expanded(
                            child: Text(
                          "${selectedProductsList[index].name}",
                          style: TextStyle(
                            fontSize: 13.0,
                            color: Color(Constants.APP_COLOR),
                            fontWeight: FontWeight.bold,
                          ),
                        )),
                      ],
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        (isEnableTextEditingController)
                            ? InkWell(
                                onTap: () {
                                  if (selectedProductsList[index].isButton!) {
                                    this.renderRemoveProductQuantity(
                                        index, setState);
                                  } else {
                                    Dialogs.yesCancelDialog(
                                        context,
                                        Language().getString(
                                            Constants.INFO, selectedLang),
                                        Language().getString(
                                            Constants.FOR_FURTHER_ACTION,
                                            selectedLang),
                                        Language().getString(
                                            Constants.OKAY_STR, selectedLang),
                                        "",
                                        false);
                                  }
                                },
                                child: Icon(Icons.remove),
                              )
                            : Container(),
                        this.designQuantityInputField(index),
                        (isEnableTextEditingController)
                            ? InkWell(
                                onTap: () {
                                  if (selectedProductsList[index].isButton!) {
                                    this.renderAddProductQuantity(
                                        index, setState);
                                  } else {
                                    Dialogs.yesCancelDialog(
                                        context,
                                        Language().getString(
                                            Constants.INFO, selectedLang),
                                        Language().getString(
                                            Constants.FOR_FURTHER_ACTION,
                                            selectedLang),
                                        Language().getString(
                                            Constants.OKAY_STR, selectedLang),
                                        "",
                                        false);
                                  }
                                },
                                child: Icon(Icons.add),
                              )
                            : Container()
                      ],
                    ),
                  ),
                  this.renderProductUnitPrice(index),
                  this.renderProductOffers(index)
                ],
              ),
              (selectedProductsList[index].batchPriceList!.length > 0)
                  ? batchPricingDropdown(
                      selectedProductsList[index].batchPriceList!, index)
                  : Container()
            ],
          ),
        ),
      ),
    );
  }

  designQuantityInputField(int index) {
    return Container(
      height: 30.0,
      width: 50.0,
      alignment: Alignment.center,
      decoration: BoxDecoration(border: Border.all(color: Colors.grey)),
      child: TextFormField(
        textAlign: TextAlign.center,
        enabled: isEnableTextEditingController,
        enableInteractiveSelection: false,
        cursorWidth: 1.0,
        controller: _quantityInputController[index],
        decoration: InputDecoration(
            hintText: "0",
            border: InputBorder.none,
            contentPadding:
                EdgeInsets.fromLTRB(0, 0, 0, editControllerBottomMargin)),
        keyboardType: TextInputType.number,
        style: TextStyle(fontSize: 12.0),
        inputFormatters: [
          new LengthLimitingTextInputFormatter(5),
          FilteringTextInputFormatter.digitsOnly
        ],
        onChanged: (value) async {
          /// Adding input value for product counter value
          if (selectedProductsList.length > 0) {
            setState(() {
              selectedProductsList[index].quantity =
                  int.parse(value.isEmpty ? "0" : value);
              tempProductList[index].quantity =
                  int.parse(value.isEmpty ? "0" : value);
            });
          }
        },
      ),
    );
  }

  /// Showing product Offers
  renderProductOffers(int index) {
    return Expanded(
      child: (selectedProductsList[index].offerData != null &&
              selectedProductsList[index].offerData!.isOfferActive! &&
              !selectedProductsList[index].offerData!.isOfferExpired!)
          ? Column(
              children: [
                Container(
                  height: 25.0,
                  width: 25.0,
                  child: Checkbox(
                    activeColor: Color(Constants.APP_COLOR),
                    value: selectedProductsList[index].offerSelected,
                    onChanged: (value) {
                      setState(() {
                        selectedProductsList[index].offerSelected = value;
                        tempProductList[index].offerSelected = value;
                      });
                    },
                  ),
                ),
                Container(
                  child: InkWell(
                    onTap: () {
                      Dialogs.showOffer(
                          context,
                          selectedProductsList[index].offerData!.offerQuantity,
                          selectedProductsList[index].offerData!.offerName,
                          selectedProductsList[index].offerData!.minOrder,
                          selectedProductsList[index].offerData!.maxOrder,
                          selectedProductsList[index].offerData!.offerType);
                    },
                    child: Text(
                      Language().getString(Constants.OFFER, selectedLang),
                      style: TextStyle(
                          color: StyleView.offerColor,
                          decoration: TextDecoration.underline),
                    ),
                  ),
                )
              ],
            )
          : Center(
              child: Text(
                Language().getString(Constants.NO_ACTIVE_OFFER, selectedLang),
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontSize: 11.0,
                    color: StyleView.offerColor,
                    fontWeight: FontWeight.bold),
              ),
            ),
    );
  }

  /// Showing Product unit price
  renderProductUnitPrice(int index) {
    if (isShowBatchPrice[index]) {
      unitPriceController[index] = TextEditingController(
          text: selectedProductsList[index].unitPrice.toString());
      unitPriceController[index].selection = TextSelection.fromPosition(
          TextPosition(offset: unitPriceController[index].text.length));
      isShowBatchPrice[index] = false;
    } else {
      unitPriceController[index] = TextEditingController(
          text: selectedProductsList[index].unitPrice.toString());
      unitPriceController[index].selection = TextSelection.fromPosition(
          TextPosition(offset: unitPriceController[index].text.length));
    }
    return Expanded(
      child: Container(
        height: 25.0,
        width: 0.0,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          border: Border.all(
            color: Colors.grey,
          ),
        ),
        child: Center(
          child: TextFormField(
            cursorWidth: 1.0,
            enabled: false,
            // enableInteractiveSelection: false,
            textAlign: TextAlign.center,
            controller: unitPriceController[index],
            keyboardType: TextInputType.number,
            style: TextStyle(
              fontSize: 12.0,
              fontWeight: FontWeight.bold,
            ),
            decoration: InputDecoration(
                border: InputBorder.none,
                hintText: "0",
                contentPadding:
                    EdgeInsets.fromLTRB(0, 0, 0, editControllerBottomMargin)),
            onChanged: (value) {
              /// Adding updated unit price to selected list
              selectedProductsList[index].unitPrice = double.parse(value);
              tempProductList[index].unitPrice = double.parse(value);
            },
          ),
        ),
      ),
    );
  }

  /// Removing product quantity
  renderRemoveProductQuantity(int index, StateSetter setState) {
    _selectedCount = selectedProductsList[index].quantity as int?;

    if (_selectedCount == 1) {
      setState(() {
        selectedProductsList[index].quantity = _selectedCount;
        tempProductList[index].quantity = _selectedCount;
        _quantityInputController[index] = TextEditingController(
            text: selectedProductsList[index].quantity.toString());
        _quantityInputController[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _quantityInputController[index].text.length));
      });
    } else {
      _selectedCount = _selectedCount! - 1;
      setState(() {
        selectedProductsList[index].quantity = _selectedCount;
        tempProductList[index].quantity = _selectedCount;
        _quantityInputController[index] = TextEditingController(
            text: selectedProductsList[index].quantity.toString());
        _quantityInputController[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _quantityInputController[index].text.length));
      });
    }
  }

  /// Adding product quantiy
  renderAddProductQuantity(int index, StateSetter setState) {
    int _count = selectedProductsList[index].quantity as int;

    _count++;
    setState(() {
      selectedProductsList[index].quantity = _count;
      tempProductList[index].quantity = _count;
      _quantityInputController[index] = TextEditingController(
          text: selectedProductsList[index].quantity.toString());
      _quantityInputController[index].selection = TextSelection.fromPosition(
          TextPosition(offset: _quantityInputController[index].text.length));
    });
  }

  loadBatchNumbersList(String? productId, String? batchNumber) async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
        progressMessage = Constants.GETTING_BATCH_PRICING;
      });
      this.getProuctById(productId, batchNumber).then((onValue) {
        setState(() {
          _productList.clear();
          _productList.addAll(onValue);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<BuProductModal>> getProuctById(
      String? productId, String? batchNumber) async {
    String body = json.encode({"id": productId, "buId": buId});

    var response = await _productService
        .getProductDetailsByProductId_grpc(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          "$onError",
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<BuProductModal> data = [];

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      data.add(BuProductModal.fromJson(resObj[0]));
      this.addingBatchPricing(data, productId, batchNumber);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return data;
  }

  showConfirmationPopup() {
    return showDialog(
      context: context,
      barrierColor: Colors.black54,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        actions: [
          Container(
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                TextButton(
                  onPressed: () async {
                    Navigator.of(context).pop();
                  },
                  child: Text(
                    Language().getString(Constants.STR_CANCEL, selectedLang),
                    style: TextStyle(
                      color: Color(Constants.APP_COLOR),
                      fontSize: 18.0,
                    ),
                  ),
                ),
                TextButton(
                  onPressed: () async {
                    Navigator.of(context).pop();
                    setState(() {
                      isLoadingProgress = true;
                      progressMessage = Constants.GENERATING_INVOICE;
                    });
                    if (await NetworkStatus.getInternetStatus()) {
                      this.productReplacement();
                    } else {
                      AppUtills.showSnackBar(
                          _scaffoldkey,
                          Language()
                              .getString(Constants.NO_INTERNET, selectedLang),
                          snackBarBgColor: Colors.black,
                          messageColor: Colors.white,
                          buttonColor: Colors.white);
                    }
                  },
                  child: Text(
                    Language().getString(Constants.NO_STRING, selectedLang),
                    style: TextStyle(
                      color: Color(Constants.APP_COLOR),
                      fontSize: 18.0,
                    ),
                  ),
                ),
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    this.showInvoiceDiscountPopup();
                  },
                  child: Text(
                    Language().getString(Constants.YES_STRING, selectedLang),
                    style: TextStyle(
                      color: Color(Constants.APP_COLOR),
                      fontSize: 18.0,
                    ),
                  ),
                ),
              ]))
        ],
        contentPadding: EdgeInsets.fromLTRB(25.0, 25.0, 10.0, 25.0),
        content: Container(
          child: Text(Language()
              .getString(Constants.ADD_ADDITIONAL_DISCOUNT, selectedLang)),
        ),
      ),
    );
  }

  showInvoiceDiscountPopup() {
    radioButtonValue = OFFER_IN_PERCENTAGE;
    discountType = "percent";
    return showDialog(
        context: context,
        barrierColor: Colors.black54,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    _rupeeController.clear();
                    offerInPercentage = null;
                    radioButtonValue = null;
                  },
                  child: Text(
                    Language().getString(Constants.STR_CANCEL, selectedLang),
                    style: TextStyle(
                      color: Color(Constants.APP_COLOR),
                      fontSize: 18.0,
                    ),
                  ),
                ),
                TextButton(
                  onPressed: () async {
                    Navigator.of(context).pop();

                    if (await NetworkStatus.getInternetStatus()) {
                      setState(() {
                        isLoadingProgress = true;
                      });

                      this.productReplacement();
                    } else {
                      AppUtills.showSnackBar(
                          _scaffoldkey,
                          Language()
                              .getString(Constants.NO_INTERNET, selectedLang),
                          snackBarBgColor: Colors.black,
                          messageColor: Colors.white,
                          buttonColor: Colors.white);
                    }
                  },
                  child: Text(
                    Language().getString(Constants.OKAY_STR, selectedLang),
                    style: TextStyle(
                      color: Color(Constants.APP_COLOR),
                      fontSize: 18.0,
                    ),
                  ),
                ),
              ],
              contentPadding: EdgeInsets.fromLTRB(25.0, 25.0, 10.0, 25.0),
              content: StatefulBuilder(
                  builder: (BuildContext context, StateSetter setState) {
                return Container(
                  height: 200.0,
                  child: Column(
                    children: [
                      Container(
                        child: Row(
                          children: [
                            Radio(
                                activeColor: Color(Constants.APP_COLOR),
                                value: OFFER_IN_PERCENTAGE,
                                groupValue: radioButtonValue,
                                onChanged: (dynamic value) {
                                  setState(() {
                                    radioButtonValue = OFFER_IN_PERCENTAGE;
                                    discountType = "percent";
                                    _rupeeController.clear();
                                  });
                                }),
                            Expanded(
                              child: Text(
                                Language().getString(
                                    OFFER_IN_PERCENTAGE, selectedLang),
                                style: TextStyle(
                                    color: Color(Constants.APP_COLOR)),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        child: Row(
                          children: [
                            Radio(
                                activeColor: Color(Constants.APP_COLOR),
                                value: OFFER_IN_RUPEES,
                                groupValue: radioButtonValue,
                                onChanged: (dynamic value) {
                                  setState(() {
                                    radioButtonValue = OFFER_IN_RUPEES;
                                    discountType = "number";

                                    offerInPercentage = null;
                                  });
                                }),
                            Expanded(
                              child: Text(
                                Language().getString(
                                        OFFER_IN_RUPEES, selectedLang) +
                                    " ( $orgCurrencySymbol ) ",
                                style: TextStyle(
                                    color: Color(Constants.APP_COLOR)),
                              ),
                            ),
                          ],
                        ),
                      ),
                      (radioButtonValue == OFFER_IN_RUPEES)
                          ? this.buildInputFieldForAmount()
                          : this.buildOfferPercentageDropdown(setState)
                    ],
                  ),
                );
              }),
            ));
  }

  buildInputFieldForAmount() {
    return Container(
      height: 40.0,
      margin: EdgeInsets.symmetric(
        vertical: 10.0,
      ),
      decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(
            color: Colors.grey,
          ),
          borderRadius: BorderRadius.circular(5.0)),
      child: Padding(
        padding: const EdgeInsets.all(5.0),
        child: TextFormField(
          controller: _rupeeController,
          keyboardType: TextInputType.number,
          decoration: InputDecoration(
              border: InputBorder.none,
              hintText:
                  Language().getString(Constants.ENTER_AMOUNT, selectedLang)),
        ),
      ),
    );
  }

  buildOfferPercentageDropdown(StateSetter setState) {
    return Container(
      margin: EdgeInsets.symmetric(
        vertical: 5.0,
      ),
      height: 50.0,
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(
          color: Colors.grey,
        ),
        borderRadius: BorderRadius.circular(5.0),
      ),
      padding: EdgeInsets.all(5),
      child: DropdownButton<String>(
        onTap: () {
          FocusScope.of(context).unfocus();
        },
        value: offerInPercentage,
        hint: new Text("%"),
        isExpanded: true,
        underline: SizedBox(),
        onChanged: (String? data) {
          setState(() {
            offerInPercentage = data;
          });
        },
        items: Constants.PERCENTAGELIST.map((String model) {
          return new DropdownMenuItem<String>(
            child: new Text(model),
            value: model,
          );
        }).toList(),
      ),
    );
  }

  void productReplacement() async {
    List<Map<String, dynamic>> productsArray = [];
    var productsObject;

    // List<Map<String, dynamic>> replacedProductsArray = [];
    // var replacedProductsObject;

    // for (int j = 0; j < invoiceProductsList.length; j++) {
    //   for (int i = 0; i < selectedProductsList.length; i++) {
    //     if (invoiceProductsList[j].id == selectedProductsList[i].id) {
    //       int replacedQuantity = 0;
    //       if (selectedProductsList[i].isButton &&
    //           selectedProductsList[i].quantity != 0) {
    //         replacedQuantity = selectedProductsList[i].quantity -
    //             invoiceProductsList[j].quantity;
    //         replacedProductsObject = {
    //           "id": selectedProductsList[i].id,
    //           "quantity": replacedQuantity,
    //           "unit_price": selectedProductsList[i].unitPrice,
    //           "offer_selected": selectedProductsList[i].offerSelected,
    //           "batch_number": batchPriceDropdown[i].batchNumber,
    //           "quantity_in": selectedProductsList[i].quantityIn
    //         };
    //         replacedProductsArray.add(replacedProductsObject);
    //       }
    //     }
    //   }
    // }

    for (int i = 0; i < tempProductList.length; i++) {
      if (tempProductList[i].isButton! && tempProductList[i].quantity != 0) {
        productsObject = {
          "id": tempProductList[i].id,
          "quantity": tempProductList[i].quantity,
          "unit_price": tempProductList[i].unitPrice,
          "offer_selected": tempProductList[i].offerSelected,
          "batch_number": tempProductList[i].batchNumber,
          "quantity_in": tempProductList[i].quantityIn
        };
        productsArray.add(productsObject);
      }
    }
    List<String> splitValue = [];

    if (radioButtonValue == OFFER_IN_PERCENTAGE && offerInPercentage != null) {
      splitValue = offerInPercentage!.split(" %");
    } else {
      splitValue
          .add(_rupeeController.text.isEmpty ? "0.0" : _rupeeController.text);
    }

    // Map data = {
    //   "bill_no": int.parse(widget.invoiceNo),
    //   "txnId": widget.transactionId,
    //   "products": productsArray,
    //   "term_type": termType,
    //   "additional_discount_type": discountType,
    //   "additional_discount": double.parse(splitValue[0]),
    //   "replaced_products": {"products": replacedProductsArray},
    //   "stock_reconciliation":
    //       _invoiceData[0].invoiceDetails.stockReconciliation,
    // };

    Map data = {
      "invoice_id": widget.invoiceId,
      "additional_discount": double.parse(splitValue[0]),
      "additional_discount_type": discountType,
      "adjusted_products": productsArray
    };

    String body = json.encode(data);
    var response = await _transactionService
        .productReplacementGRPC(
            body, AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      // this.showProductReplacementPopup();
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          Language().getString(
              Constants.INVOICE_UPDATED_SUCCESSFULLY, selectedLang),
          Language().getString(Constants.YES_STRING, selectedLang),
          "",
          false);
      if (action == DialogAction.yes) {
        Navigator.pop(context);
        Navigator.pop(context);
        Navigator.pop(context);
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          response.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  Future<List<InvoiceDAO>> getInvoiceData() async {
    setState(() {
      isLoadingProgress = true;
    });
    String body = json.encode({
      "id": widget.invoiceId,
    });
    List<InvoiceDAO> list = [];
    var response = await _transactionService
        .getInvoiceDetailsByInvoiceId(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      list.add(InvoiceDAO.fromJson(resObj[0]));
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
      return list;
  }

  batchPricingDropdown(List<BatchPriceDAO> batchNumberList, int index) {
    if (batchNumberList.length > 0) {
      if (batchPriceDropdown[index] == null) {
        batchPriceDropdown[index] = batchNumberList[0];
      }

      return BatchPriceDropDownView(
        canShowPrice: false,
        canShowDynamicPricing: false,
        currentDropdownIndex: index,
        batchPricingList: batchNumberList,
        batchDropdown: batchPriceDropdown,
        selectedDropdownValue: (data) {
          setState(() {
            batchPriceDropdown[index] = data;
            selectedProductsList[index].unitPrice =
                batchPriceDropdown[index]!.price;
          });
        },
        strBatchPricing: Language().getString(Constants.BATCH_NO, selectedLang),
        strAvailableQuantity:
            Language().getString(Constants.AVAILABLE_QUANTITY, selectedLang),
        isShowTextBatchNo: true,
      );
    }
  }

  Future<PaymentTerms?> serviceCallGetTerms({String termType = ""}) async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = Constants.GETTING_TERMS;
    });
    String body = json.encode(
        {"seller_id": buId, "buyer_id": widget.buyerId, "term_type": termType});

    var response = await _organizationService
        .findSpecificTerms(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    PaymentTerms? terms;
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      terms = PaymentTerms.fromJson(resObj);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return terms;
  }

  showTermsDataView(String termType) {
    return showDialog(
        context: context,
        builder: (context) => Container(
              margin: EdgeInsets.symmetric(horizontal: 20.0, vertical: 50.0),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: AppBackgroundView(
                  body: Scaffold(
                    backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                    body: Container(
                      margin: EdgeInsets.symmetric(
                          vertical: 10.0, horizontal: 10.0),
                      child: SingleChildScrollView(
                        child: Column(
                          children: [
                            Container(
                              child: Row(
                                children: [
                                  Expanded(
                                    child: Text(
                                      Language()
                                          .getString(termType, selectedLang),
                                      style: TextStyle(
                                        fontSize: 15.0,
                                        fontWeight: StyleView.fontSemiBold,
                                        color: theme.colorScheme.primary,
                                      ),
                                    ),
                                  ),
                                  IconButton(
                                      onPressed: () {
                                        Navigator.of(context).pop();
                                      },
                                      icon:
                                          Icon(Icons.close, color: Colors.red))
                                ],
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.symmetric(vertical: 5.0),
                              decoration: AppUtills.boxDecoration(),
                              child: Column(
                                children: [
                                  this.buildTermsTextView(
                                      Constants.INVOICE_CURRENCY_CODE_STRING,
                                      termsData!.invoicecurrencycode!),
                                  SizedBox(
                                    height: 1,
                                    child: new Container(
                                        color: Color(Constants.GREY_COLOR)),
                                  ),
                                  this.buildTermsTextView(
                                      Constants.INVOICE_PAYMENT_TERMS,
                                      termsData!.invoicePaymentTerms!),
                                  SizedBox(
                                    height: 1,
                                    child: new Container(
                                        color: Color(Constants.GREY_COLOR)),
                                  ),
                                  this.buildTermsTextView(
                                      Constants.PENALTY_REASON,
                                      termsData!.penaltyAmount != null
                                          ? termsData!.penaltyAmount!.reason!
                                          : ""),
                                  SizedBox(
                                    height: 1,
                                    child: new Container(
                                        color: Color(Constants.GREY_COLOR)),
                                  ),
                                  this.buildTermsTextView(
                                      Constants.PENALTY_AMOUNT,
                                      (termsData!.penaltyAmount != null &&
                                              termsData!.penaltyAmount!.value !=
                                                  null)
                                          ? "${termsData!.penaltyAmount!.value} %"
                                          : ""),
                                  SizedBox(
                                    height: 1,
                                    child: new Container(
                                        color: Color(Constants.GREY_COLOR)),
                                  ),
                                  this.buildTermsTextView(
                                      Constants.ADVANCE_PAYMENT,
                                      (termsData!.advancePayment != null &&
                                              termsData!
                                                      .advancePayment!.value !=
                                                  null)
                                          ? "${termsData!.advancePayment!.value} %"
                                          : ""),
                                ],
                              ),
                            ),
                            buildTextField(Constants.CUSTOME_REMARKS),
                            buildCommentFieldView(termsData!.comment!),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ));
  }

  buildTextField(String _text) {
    return Container(
      margin: EdgeInsets.symmetric(
        vertical: 10.0,
      ),
      child: Row(
        children: <Widget>[
          Align(
              child: Text(Language().getString(_text, selectedLang),
                  style: TextStyle(
                      color: theme.colorScheme.primary,
                      fontFamily: StyleView.FONT_TITLE,
                      fontWeight: StyleView.fontMedium,
                      fontSize: StyleView.FONT_SIZE_15)))
        ],
      ),
    );
  }

  buildCommentFieldView(String value) {
    return Container(
        height: MediaQuery.of(context).size.height * 0.25,
        width: MediaQuery.of(context).size.width,
        margin: EdgeInsets.symmetric(
          vertical: 5.0,
        ),
        decoration: BoxDecoration(
          border: Border.all(
            color: Colors.grey,
          ),
          borderRadius: BorderRadius.circular(5.0),
          color: Colors.white70,
        ),
        padding: EdgeInsets.only(left: 5),
        child: Text(
          value,
        ));
  }

  Widget buildTermsTextView(String text, String value) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 55,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(Language().getString(text, selectedLang),
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: StyleView.FONT_TITLE))),
                  )),
            ),
            Expanded(
              child: Container(
                  height: 55,
                  color: Colors.white,
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(value,
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: StyleView.FONT_TITLE))),
                  )),
            )
          ],
        ));
  }

  addingBatchPricing(List<BuProductModal> productData, String? productId,
      String? batchNumber) {
    for (int i = 0; i < selectedProductsList.length; i++) {
      if (productData[0].id == selectedProductsList[i].id) {
        setState(() {
          batchPriceDropdown[i] = null;
          selectedProductsList[i].batchPriceList =
              bindingProductInvoiceBatchNumber(
                  selectedProductsList[i].batchNumber,
                  productData[0]); //productData[0].batchPrice;
          selectedProductsList[i].offerData =
              getActiveOffer(productData[0].offers!);
        });
      }
    }
  }

  OffersDAO? getActiveOffer(List<OffersDAO> offersList) {
    OffersDAO? _activeOffer;

    for (int i = 0; i < offersList.length; i++) {
      if (offersList[i].isOfferActive! && !offersList[i].isOfferExpired!) {
        _activeOffer = offersList[i];
      }
    }

    return _activeOffer;
  }

  List<BatchPriceDAO> bindingProductInvoiceBatchNumber(
      String? batchNumber, BuProductModal productData) {
    List<BatchPriceDAO> _batchNumber = [];
    for (var i = 0; i < productData.batchPrice!.length; i++) {
      if (batchNumber == productData.batchPrice![i].batchNumber) {
        _batchNumber.add(productData.batchPrice![i]);
      }
    }
    return _batchNumber;
  }

  showProductReplacementPopup() {
    return showDialog(
        context: context,
        barrierColor: Colors.black54,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
              elevation: 100.0,
              contentPadding: EdgeInsets.fromLTRB(15.0, 0, 15.0, 10.0),
              backgroundColor: Color(0XFFE0E0E0),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(
                  Radius.circular(
                    7.0,
                  ),
                ),
              ),
              title:
                  Text(Language().getString(Constants.SUCCESS, selectedLang)),
              content: Container(
                child: Text(Language().getString(
                    Constants.INVOICE_UPDATED_SUCCESSFULLY, selectedLang)),
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    Navigator.pop(context);
                    Navigator.pop(context);
                    Navigator.pop(context);
                  },
                  child: Text(
                    Language().getString(Constants.OKAY_STR, selectedLang),
                    style: TextStyle(
                        color: Color(Constants.APP_COLOR), fontSize: 18.0),
                  ),
                )
              ],
            ));
  }

  renerationProductsPopup() {
    return showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => Container(
              margin: EdgeInsets.symmetric(vertical: 30.0, horizontal: 20.0),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: AppBackgroundView(
                  body: Scaffold(
                    bottomNavigationBar: Container(
                        padding:
                            EdgeInsets.only(left: 10, right: 10, bottom: 30),
                        child: CommonButtonsView(
                          context: context,
                          b1Text: Language()
                              .getString(Constants.STR_CANCEL, selectedLang),
                          b2Text: Language()
                              .getString(Constants.CONFIRM, selectedLang),
                          onb1Action: () => Navigator.of(context).pop(),
                          onb2Action: () {
                            Navigator.of(context).pop();
                            this.showConfirmationPopup();
                          },
                        )),
                    backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                    body: Container(
                      margin: EdgeInsets.symmetric(
                          vertical: 10.0, horizontal: 10.0),
                      child: ListView.builder(
                          itemBuilder: (context, index) =>
                              selectedProductsList[index].isButton!
                                  ? Card(
                                      elevation: 5.0,
                                      child: Container(
                                        padding: EdgeInsets.all(10.0),
                                        child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: <Widget>[
                                            this.showProductDetails(
                                                Constants.PRODUCT_NAME,
                                                selectedProductsList[index]
                                                    .name),
                                            this.showProductDetails(
                                                Constants.QUANTITY,
                                                selectedProductsList[index]
                                                    .quantity
                                                    .toString()),
                                            this.showProductDetails(
                                                Constants.PRICE_UNIT,
                                                selectedProductsList[index]
                                                    .unitPrice
                                                    .toString()),
                                          ],
                                        ),
                                      ))
                                  : Container(),
                          itemCount: selectedProductsList.length),
                    ),
                  ),
                ),
              ),
            ));
  }

  Widget showProductDetails(String title, String? value) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 2.0),
      child: Row(children: <Widget>[
        Expanded(
          child: Text(
            Language().getString(title, selectedLang),
            style: TextStyle(
                color: Color(Constants.APP_COLOR),
                fontSize: 13.0,
                fontWeight: FontWeight.bold),
          ),
        ),
        Expanded(
          flex: 2,
          child: Text(
            " :  $value",
            style: TextStyle(fontSize: 13.0),
          ),
        )
      ]),
    );
  }

  updateProductsData(List<Product> _productsList) {
    for (int i = 0; i < _productsList.length; i++) {
      unitPriceController.add(TextEditingController());
      _quantityInputController.add(new TextEditingController());
      batchPriceDropdown.add(null);
      isShowBatchPrice.add(true);
      setState(() {
        selectedProductsList.add(
          ModelProduct(
              id: _productsList[i].id,
              images: null,
              name: _productsList[i].productName,
              quantity: _productsList[i].quantity,
              counter: 0,
              isButton: true,
              isItemSelected: false,
              unitPrice: _productsList[i].unitPrice,
              price: _productsList[i].unitPrice,
              offerData: _productsList[i].offerData,
              offerSelected: _productsList[i].offerSelected,
              batchPriceList: [],
              offerList: [],
              batchNumber: _productsList[i].batchNumber,
              quantityIn: _productsList[i].quantityIn),
        );
        tempProductList.add(
          ModelProduct(
              id: _productsList[i].id,
              images: null,
              name: _productsList[i].productName,
              quantity: _productsList[i].quantity,
              counter: 0,
              isButton: true,
              isItemSelected: false,
              unitPrice: _productsList[i].unitPrice,
              price: _productsList[i].unitPrice,
              offerData: _productsList[i].offerData,
              offerSelected: _productsList[i].offerSelected,
              batchPriceList: [],
              offerList: [],
              batchNumber: _productsList[i].batchNumber,
              quantityIn: _productsList[i].quantityIn),
        );
        invoiceProductsList.add(
          ModelProduct(
              id: _productsList[i].id,
              images: null,
              name: _productsList[i].productName,
              quantity: _productsList[i].quantity,
              counter: 0,
              isButton: true,
              isItemSelected: false,
              unitPrice: _productsList[i].unitPrice,
              price: _productsList[i].unitPrice,
              offerData: _productsList[i].offerData,
              offerSelected: _productsList[i].offerSelected,
              batchPriceList: [],
              offerList: [],
              batchNumber: _productsList[i].batchNumber,
              quantityIn: _productsList[i].quantityIn),
        );
        _quantityInputController[i] =
            TextEditingController(text: _productsList[i].quantity.toString());
        _quantityInputController[i].selection = TextSelection.fromPosition(
            TextPosition(offset: _quantityInputController[i].text.length));
        this.loadBatchNumbersList(
            _productsList[i].id, _productsList[i].batchNumber);
      });
    }
  }
}
