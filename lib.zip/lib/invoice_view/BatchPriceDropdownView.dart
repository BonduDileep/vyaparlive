import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/model/product_model/BatchPriceDAO.dart';

import '../components/AppUtills.dart';

class BatchPriceDropDownView extends StatelessWidget {
  final List<BatchPriceDAO?>? batchDropdown;
  final List<BatchPriceDAO>? batchPricingList;
  final Function(BatchPriceDAO?)? selectedDropdownValue;
  final int? currentDropdownIndex;
  final bool isFromRetailPage;
  final String? strBatchPricing;
  final String? strAvailableQuantity;
  final bool isShowTextBatchNo;
  final Function(String)? onChangeFinalPrice;
  final Function(int?)? onEdit;
  final List<TextEditingController>? finalPriceEditController;
  final List<bool>? canShowPriceEditField;
  final bool canShowDynamicPricing;
  final bool canShowPrice;
  final bool? canShowEdit;
  final num? editedPrice;
  BatchPriceDropDownView(
      {this.batchDropdown,
      this.batchPricingList,
      this.selectedDropdownValue,
      this.currentDropdownIndex,
      this.isFromRetailPage = false,
      required this.strBatchPricing,
      required this.strAvailableQuantity,
      this.isShowTextBatchNo = false,
      this.onEdit,
      this.onChangeFinalPrice,
      this.finalPriceEditController,
      this.canShowPriceEditField,
      required this.canShowDynamicPricing,
      required this.canShowPrice,
      this.canShowEdit,
      this.editedPrice});
  @override
  Widget build(BuildContext context) {
    final quantity = batchDropdown![currentDropdownIndex!]!.quantity;

    String formattedQty = (quantity! % 1 == 0)
        ? quantity.toStringAsFixed(0)
        : quantity.toStringAsFixed(2);
    return Container(
      margin: EdgeInsets.symmetric(vertical: 2.0),
      child: Padding(
        padding: const EdgeInsets.all(5.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              child: Row(
                children: <Widget>[
                  Container(
                      height: 20.0,
                      child: Text("$strBatchPricing : ",
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.bold,
                              color: Color(Constants.APP_COLOR),
                              fontFamily: StyleView.FONT_TITLE))),
                  Expanded(
                    flex: 2,
                    child: Container(
                        padding: EdgeInsets.only(left: 5, right: 5),
                        child: (isShowTextBatchNo)
                            ? Container(
                                margin: EdgeInsets.symmetric(vertical: 5.0),
                                child: Text(
                                    batchDropdown![currentDropdownIndex!]!
                                        .batchNumber!),
                              )
                            : DropdownButton<BatchPriceDAO>(
                                isExpanded: true,
                                value: batchDropdown![currentDropdownIndex!],
                                hint: Text(Constants.BATCH_NO),
                                underline: SizedBox(),
                                onChanged: (BatchPriceDAO? data) {
                                  selectedDropdownValue!(data);
                                },
                                onTap: () {
                                  return CommonMethods.hideKeyboard(context);
                                },
                                items: batchPricingList!
                                    .map((BatchPriceDAO model) {
                                  return new DropdownMenuItem<BatchPriceDAO>(
                                      onTap: () {
                                        return CommonMethods.hideKeyboard(
                                            context);
                                      },
                                      child: new Text(model.batchNumber!),
                                      value: model);
                                }).toList())),
                  ),
                  (isFromRetailPage || canShowDynamicPricing)
                      ? Container(
                          child: Row(
                          children: [
                            Text((canShowPrice
                                    ? Constants.PRICE
                                    : Constants.MRP) +
                                " : " +
                                CommonMethods.getCurrencyValues(canShowPrice
                                    ? batchDropdown![currentDropdownIndex!]!
                                        .price
                                    : batchDropdown![currentDropdownIndex!]!
                                        .mrp)),
                            (canShowEdit != null && canShowEdit!
                                ? Padding(
                                    padding: const EdgeInsets.only(left: 5),
                                    child: InkWell(
                                        child: Icon(Icons.edit,
                                            size: 15,
                                            color: Color(Constants.APP_COLOR)),
                                        onTap: () => {
                                              this.onEdit!(
                                                  currentDropdownIndex!)
                                            }),
                                  )
                                : Container())
                          ],
                        ))
                      : Container()
                ],
              ),
            ),
            Container(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    strAvailableQuantity!,
                    style: TextStyle(
                        fontSize: 14.0,
                        fontWeight: FontWeight.bold,
                        color: Color(Constants.APP_COLOR)),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                        "   : ${formattedQty}  ${batchDropdown![currentDropdownIndex!]!.quantityIn}"),
                  ),
                  (canShowDynamicPricing)
                      ? (canShowPriceEditField != null &&
                              canShowPriceEditField!.length >
                                  currentDropdownIndex! &&
                              canShowPriceEditField![currentDropdownIndex!])
                          ? Expanded(
                              child: Text(
                                "Final Price:",
                                style: TextStyle(
                                    fontSize: 14.0,
                                    fontWeight: FontWeight.bold,
                                    color: Color(Constants.APP_COLOR)),
                              ),
                            )
                          : Container()
                      : Container(),
                  (canShowDynamicPricing &&
                          canShowPriceEditField != null &&
                          canShowPriceEditField!.length >
                              currentDropdownIndex! &&
                          canShowPriceEditField![currentDropdownIndex!])
                      ? Expanded(
                          child: Container(
                            alignment: Alignment.bottomCenter,
                            decoration: AppUtills.boxDecoration(),
                            height: 30,
                            child: TextFormField(
                              textAlign: TextAlign.center,
                              enableInteractiveSelection: false,
                              controller: finalPriceEditController![
                                  currentDropdownIndex!],
                              decoration: InputDecoration(
                                contentPadding:
                                    EdgeInsets.only(bottom: kIsWeb ? 18 : 15),
                                hintText: "0",
                                border: InputBorder.none,
                              ),
                              keyboardType: TextInputType.numberWithOptions(
                                  decimal: true, signed: true),
                              style: TextStyle(fontSize: 12.0),
                              inputFormatters: [
                                new LengthLimitingTextInputFormatter(10),
                                // FilteringTextInputFormatter.digitsOnly
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'^\d*\.?\d{0,2}')),
                              ],
                              onChanged: (text) {
                                this.onChangeFinalPrice!(text);
                              },
                            ),
                          ),
                        )
                      : Container(
                          child: Text(
                            editedPrice != null
                                ? "Final Price: " +
                                    CommonMethods.getCurrencyValues(editedPrice)
                                : "",
                            style: TextStyle(
                                fontSize: 12.0,
                                fontWeight: FontWeight.w500,
                                color: Color(Constants.APP_COLOR)),
                          ),
                        ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
