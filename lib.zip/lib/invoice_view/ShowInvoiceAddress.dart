import 'package:flutter/material.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/model/bu_model/AddressDetailsModel.dart';

class ShowInvoiceAddress extends StatelessWidget {
  final Address? invoiceAddress;
  final String? name;
  final String? gstNumber;
  final String? mobileNumber;
  final String? contactPerson;
  final bool isSellerAddress;
  final String? orgPanNumber;
  final String? orgCinNumber;
  final bool? canShowEmailPanCin;
  ShowInvoiceAddress(
      {required this.invoiceAddress,
      required this.name,
      required this.gstNumber,
      required this.mobileNumber,
      this.contactPerson,
      this.isSellerAddress = false,
      this.orgPanNumber,
      this.orgCinNumber,
      this.canShowEmailPanCin = true});

  @override
  Widget build(BuildContext context) {
    return Container(
        child: Padding(
      padding: const EdgeInsets.all(8.0),
      child: RichText(
        text: TextSpan(
          children: <TextSpan>[
            TextSpan(
                text: CommonMethods.captilizeText(name!),
                style: TextStyle(
                    fontSize: 18.0,
                    fontFamily: StyleView.FONT_TITLE,
                    color: Color(Constants.APP_COLOR),
                    decoration: TextDecoration.underline,
                    fontWeight: StyleView.fontSemiBold)),
            TextSpan(
              text: "\n\n" +
                  CommonMethods.getAddressData(address: invoiceAddress),
              style: TextStyle(
                fontSize: 13.0,
                height: 1.5,
                fontFamily: StyleView.FONT_TITLE,
                fontWeight: StyleView.fontMedium,
                color: Color(Constants.APP_COLOR),
              ),
            ),
            if (isSellerAddress)
              TextSpan(
                text:
                    "\n\n${Constants.PHONE_NUMBER} : ${mobileNumber != null && mobileNumber!.isNotEmpty ? mobileNumber : "-"}",
                style: TextStyle(
                  fontSize: 14.0,
                  height: 1.3,
                  fontWeight: StyleView.fontRegular,
                  fontFamily: StyleView.FONT_TITLE,
                  color: Color(Constants.APP_COLOR),
                ),
              ),
            if (isSellerAddress && canShowEmailPanCin == true)
              TextSpan(
                text:
                    "\n\n ${Constants.EMAIL} : ${invoiceAddress!.emailOnInvoice}",
                style: TextStyle(
                  fontSize: 14.0,
                  height: 1.3,
                  fontWeight: StyleView.fontRegular,
                  fontFamily: StyleView.FONT_TITLE,
                  color: Color(Constants.APP_COLOR),
                ),
              ),
            if (gstNumber != null)
              TextSpan(
                text: "\n\n ${Constants.GST_NO} : $gstNumber",
                style: TextStyle(
                  fontSize: 14.0,
                  height: 1.3,
                  fontWeight: StyleView.fontRegular,
                  fontFamily: StyleView.FONT_TITLE,
                  color: Color(Constants.APP_COLOR),
                ),
              ),
            if (canShowEmailPanCin == true && orgPanNumber != null)
              TextSpan(
                text: "\n\n ${Constants.PAN} : $orgPanNumber",
                style: TextStyle(
                  fontSize: 14.0,
                  height: 1.3,
                  fontWeight: StyleView.fontRegular,
                  fontFamily: StyleView.FONT_TITLE,
                  color: Color(Constants.APP_COLOR),
                ),
              ),
            if (canShowEmailPanCin == true && orgCinNumber != null)
              TextSpan(
                text: "\n\n${Constants.CIN} : $orgCinNumber",
                style: TextStyle(
                  fontSize: 14.0,
                  height: 1.3,
                  fontWeight: StyleView.fontRegular,
                  fontFamily: StyleView.FONT_TITLE,
                  color: Color(Constants.APP_COLOR),
                ),
              ),
            if (!isSellerAddress)
              TextSpan(
                text: "\n\n${Constants.CONTACT_NUMBER} : $mobileNumber",
                style: TextStyle(
                  fontSize: 14.0,
                  height: 1.3,
                  fontWeight: StyleView.fontRegular,
                  fontFamily: StyleView.FONT_TITLE,
                  color: Color(Constants.APP_COLOR),
                ),
              ),
          ],
        ),
      ),
    ));
  }
}
