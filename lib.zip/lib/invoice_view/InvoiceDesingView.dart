import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/image_hero/ImageHeroView.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:vyaparlive/utills/webview_page.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:mime/mime.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/TransactionDetailsView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/invoice_view/GenerateInvoice.dart';
import 'package:vyaparlive/invoice_view/ProductReplaceInvoiceGeneration.dart';
import 'package:vyaparlive/invoice_view/ShowInvoiceAddress.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/InvoiceDAO.dart';
import 'package:vyaparlive/model/ModelProduct.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'dart:convert';
import 'package:vyaparlive/service/bu_list_grpc_service.dart';

class InvoiceDesingPage extends StatefulWidget {
  final String? buyerName;
  final String? transactionName;
  final String? transactionId;
  final String? transactionDate;
  final String? invoiceNo;
  final bool isFromStockReconciliation;
  final bool? isForProductReplacement;
  final String? sellerName;
  final String? invoiceId;
  final bool? isOfflineTransaction;
  final String? sellerId;
  InvoiceDesingPage({
    this.transactionName,
    this.transactionDate,
    this.buyerName,
    this.transactionId,
    this.invoiceNo,
    this.isFromStockReconciliation = false,
    this.isForProductReplacement,
    this.sellerName = "",
    this.invoiceId,
    this.isOfflineTransaction = false,
    this.sellerId,
  });
  @override
  _InvoiceDesingPageState createState() => _InvoiceDesingPageState();
}

class _InvoiceDesingPageState extends State<InvoiceDesingPage> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? buName = "";
  List<InvoiceDAO> _invoiceDetailsList = [];
  List<ModelProduct> invoiceProducts = [];
  double textFontSize = 13.0;
  int subTotalAmount = 0;
  int invoiceAmount = 0;
  int amountPaid = 0;
  int balanceAmount = 0;
  int gstAmount = 0;
  String? taxType = "";
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  late BuListGrpcService _transactionService;
  String? orgCurrencySymbol = "";
  List<Product> userProductsList = [];
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  List<Map> _namesData = [];
  late ThemeData theme;
  String imageRelativePath = '';
  int columnNumber = 0;
  @override
  void initState() {
    super.initState();
    this.getLoadLanguage();
    theme = AppTheme.vyaparTheme;
    buName = AppController.instance.getBuName;
    _transactionService = BuListGrpcService();
    loadInvoiceData();
  }

  getLoadLanguage() async {
    setState(() {
      _namesData = [
        {"name": Language().getString(Constants.NAME_STRING, selectedLang)},
        {"name": Language().getString(Constants.TXN_ID, selectedLang)},
        {
          "name":
              Language().getString(Constants.TXN_INITIATED_DATE, selectedLang)
        }
      ];
    });
  }

  loadInvoiceData() async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
      });
      getInvoiceData().then((value) {
        setState(() {
          _invoiceDetailsList.addAll(value);

          if (_invoiceDetailsList.length > 0 &&
              _invoiceDetailsList[0].invoiceDetails != null &&
              _invoiceDetailsList[0].invoiceDetails!.products!.length > 0) {
            imageRelativePath =
                _invoiceDetailsList[0].invoiceDetails!.sellerInvocie!;
            userProductsList
                .addAll(_invoiceDetailsList[0].invoiceDetails!.products!);
            taxType = userProductsList[0].taxType;
            for (int i = 0; i < _invoiceDetailsList[0].products!.length; i++) {
              invoiceProducts.add(ModelProduct(
                  id: _invoiceDetailsList[0].products![i].id,
                  name: _invoiceDetailsList[0].products![i].productName,
                  quantity: _invoiceDetailsList[0].products![i].quantity,
                  unitPrice: _invoiceDetailsList[0].products![i].unitPrice,
                  images:
                      _invoiceDetailsList[0].products![i].productImage!.length >
                              0
                          ? _invoiceDetailsList[0].products![i].productImage![0]
                          : null,
                  price: _invoiceDetailsList[0].products![i].totalPrice,
                  counter: 0,
                  offerList: [],
                  isButton: true,
                  offerData: _invoiceDetailsList[0].products![i].offerData,
                  offerSelected: false,
                  isItemSelected: false));
            }
          }
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  showOfflineSellerInvocie() {
    // if ( _invoiceDetailsList[0].sellerContactDetails!.isOffline == false) {
    //   return Container();
    // }
    if (widget.isOfflineTransaction == false &&
        AppController.instance.getMyBuId != widget.sellerId) {
      return Container();
    }
    if (imageRelativePath.isEmpty) {
      return Container();
    }
    return Container(
      alignment: Alignment.center,
      child: InkWell(
          onTap: () {
            List<String?> path = imageRelativePath.split('/');
            if (kIsWeb) {
              AppUtills.launchURL(
                  '${Constants.IAMGE_BUCKET_URL}$imageRelativePath');
            } else {
              if (lookupMimeType(imageRelativePath) == 'application/pdf') {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => WebViewPage(
                            url:
                                '${Constants.IAMGE_BUCKET_URL}$imageRelativePath',
                            screenName: "",
                            loadS3PDF: true)));
              } else {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => ImageHeroView(
                              fileUrl:
                                  '${Constants.IAMGE_BUCKET_URL}$imageRelativePath',
                              tagName: path[1],
                            )));
              }
            }
          },
          child: Text(
            Language()
                .getString(Constants.SELLER_ORIGINAL_INVOICE, selectedLang),
            style: TextStyle(
                color: theme.colorScheme.primary,
                fontWeight: StyleView.fontSemiBold,
                decoration: TextDecoration.underline),
          )),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
        body: Stack(
      children: [
        SafeArea(
          child: Scaffold(
            key: _scaffoldkey,
            backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
            appBar: AppBar(
              backgroundColor: Colors.transparent, //(Constants.APP_COLOR),
              centerTitle: true,
              elevation: 0,
              iconTheme: IconThemeData(color: theme.colorScheme.primary),
              title: AppbarName(
                  title: Language()
                      .getString(Constants.INVOICE_DETAILS, selectedLang),
                  buName: "$buName"),

              actions: [
                AppUtills.homeButton(context),
              ],
            ),
            bottomNavigationBar: this.renderBottomView(),
            body: Container(
              decoration: AppUtills.appBackgroundWithImage(),
              margin: EdgeInsets.all(5.0),
              child: Column(
                children: <Widget>[
                  TransactionDetailsViewPage(
                      transactionName: widget.transactionName ?? "",
                      transactionId: widget.transactionId ?? "",
                      transactionDate: widget.transactionDate,
                      namesData: _namesData),
                  Container(
                      padding: EdgeInsets.symmetric(vertical: 14),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Container(
                            margin: EdgeInsets.symmetric(
                              vertical: 5.0,
                            ),
                            padding: EdgeInsets.all(5.0),
                            decoration: BoxDecoration(
                                border: Border.all(color: Colors.black),
                                borderRadius: BorderRadius.circular(5.0)),
                            child: Text(
                              Language().getString(
                                      Constants.INVOICE, selectedLang) +
                                  " #" +
                                  widget.invoiceNo,
                              style: TextStyle(color: Colors.black),
                            ),
                          ),
                          Container(
                            height: 30.0,
                            child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: theme.colorScheme.primary,
                                    padding: EdgeInsets.all(5)),
                                onPressed: () {
                                  var url =
                                      '${Constants.WHATSAPP_INVOICE_URL}${widget.transactionId}/invoice-pdf/${widget.invoiceNo}';
                                  if (kIsWeb) {
                                    AppUtills.launchURL(url);
                                  } else {
                                    // var url ='${Constants.LOOKUP_BASE_URL}transaction/${widget.transactionId}/invoice-pdf/${widget.invoiceNo}';

                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) => WebViewPage(
                                                  url: url,
                                                  screenName: "",
                                                  loadS3PDF: true,
                                                )));
                                    // Navigator.push(
                                    //     context,
                                    //     new MaterialPageRoute(
                                    //         builder: (context) =>
                                    //             InvoiceWebViewPage(
                                    //               invoiceId: widget.invoiceNo,
                                    //               transactionId:
                                    //                   widget.transactionId,
                                    //             )));
                                  }
                                },
                                child: Text(
                                    Language().getString(
                                        Constants.PRINT_VIEW, selectedLang),
                                    style: TextStyle(color: Colors.white))),
                          )
                        ],
                      )),
                  Expanded(
                    child: Container(
                      child: _invoiceDetailsList.length == 0
                          ? Center(
                              child: Text(Language().getString(
                                  Constants.NO_DATA_FOUND, selectedLang)),
                            )
                          : SingleChildScrollView(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  showOfflineSellerInvocie(),
                                  Container(
                                      margin: EdgeInsets.symmetric(
                                        vertical: 10.0,
                                      ),
                                      decoration: BoxDecoration(
                                          color: Colors.white,
                                          border:
                                              Border.all(color: Colors.black),
                                          borderRadius:
                                              BorderRadius.circular(5.0)),
                                      child: Column(
                                        children: <Widget>[
                                          Container(
                                            height: 40.0,
                                            decoration: BoxDecoration(
                                                color: Colors.grey,
                                                borderRadius: BorderRadius.only(
                                                    topLeft:
                                                        Radius.circular(5.0))),
                                            child: Row(children: <Widget>[
                                              Expanded(
                                                child: Container(
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.all(
                                                            8.0),
                                                    child: Text(
                                                      Language().getString(
                                                          Constants.SOLD_BY,
                                                          selectedLang),
                                                      style: TextStyle(
                                                          fontWeight: StyleView
                                                              .fontSemiBold,
                                                          fontSize: 13.0,
                                                          fontFamily: StyleView
                                                              .FONT_TITLE,
                                                          color: Colors.white),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Expanded(
                                                child: Container(
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.all(
                                                            8.0),
                                                    child: Text(
                                                      Language().getString(
                                                          Constants.SOLD_TO,
                                                          selectedLang),
                                                      style: TextStyle(
                                                          fontWeight: StyleView
                                                              .fontSemiBold,
                                                          fontSize: 13.0,
                                                          fontFamily: StyleView
                                                              .FONT_TITLE,
                                                          color: Colors.white),
                                                    ),
                                                  ),
                                                ),
                                              )
                                            ]),
                                          ),
                                          SizedBox(
                                              height: 1.0,
                                              child: Container(
                                                  color: Colors.black)),
                                          Container(
                                              padding: EdgeInsets.only(top: 10),
                                              child: Row(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: <Widget>[
                                                    Expanded(
                                                        child: this
                                                            .showSoldByAddress()),
                                                    Expanded(
                                                      child: this
                                                          .showSoldToAddress(),
                                                    )
                                                  ]))
                                        ],
                                      )),
                                  SizedBox(height: 5.0),
                                  this.showInvoiceItemsData(),
                                  (_invoiceDetailsList[0]
                                              .invoiceDetails!
                                              .replacedProducts!
                                              .length >
                                          0)
                                      ? Container(
                                          margin: EdgeInsets.symmetric(
                                              vertical: 5.0),
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                  margin: EdgeInsets.symmetric(
                                                      vertical: 5.0),
                                                  child: Text(
                                                      Language().getString(
                                                          "Replace/Additional Products Quantity Details",
                                                          selectedLang),
                                                      style: TextStyle(
                                                          decoration:
                                                              TextDecoration
                                                                  .underline,
                                                          color: Color(Constants
                                                              .APP_COLOR),
                                                          fontSize: 15.0,
                                                          fontWeight: FontWeight
                                                              .bold))),
                                              this.showReplacedProductsData()
                                            ],
                                          ),
                                        )
                                      : Container(),
                                  SizedBox(height: 10.0),
                                  (_invoiceDetailsList[0].invoiceDetails ==
                                          null)
                                      ? Container()
                                      : Container(
                                          width:
                                              MediaQuery.of(context).size.width,
                                          padding: EdgeInsets.all(10.0),
                                          alignment: Alignment.centerRight,
                                          child: Table(
                                            border: TableBorder.all(
                                              color: Colors.black,
                                            ),
                                            children: [
                                              this.renderPaymentDetails(
                                                  this.renderTableRowHeading(
                                                      "1. ${Language().getString(Constants.PRODUCT_COST, selectedLang)} ( $orgCurrencySymbol ) ",
                                                      TextAlign.left),
                                                  this.renderTableRowValue(
                                                      CommonMethods.getCurrencyValues(
                                                          _invoiceDetailsList[0]
                                                              .invoiceDetails!
                                                              .productToatalCost),
                                                      Alignment.centerRight)),
                                              this.renderPaymentDetails(
                                                  this.renderTableRowHeading(
                                                      "2. ${Language().getString(Constants.TOTAL_OFFER, selectedLang)} ( $orgCurrencySymbol )",
                                                      TextAlign.left),
                                                  this.renderTableRowValue(
                                                      CommonMethods
                                                          .getCurrencyValues(
                                                              _invoiceDetailsList[
                                                                      0]
                                                                  .invoiceDetails!
                                                                  .totalOffer),
                                                      Alignment.centerRight)),
                                              this.renderPaymentDetails(
                                                  this.renderTableRowHeading(
                                                      "3. ${Language().getString(Constants.SUB_TOTAL, selectedLang)} (1-2) ( $orgCurrencySymbol )",
                                                      TextAlign.left),
                                                  this.renderTableRowValue(
                                                      CommonMethods
                                                          .getCurrencyValues(
                                                              _invoiceDetailsList[
                                                                      0]
                                                                  .invoiceDetails!
                                                                  .subTotal),
                                                      Alignment.centerRight)),
                                              (taxType == Constants.IGST)
                                                  ? this.renderPaymentDetails(
                                                      this.renderTableRowHeading(
                                                          "4. ${Language().getString(Constants.IGST_TOTAL, selectedLang)} ( $orgCurrencySymbol )",
                                                          TextAlign.left),
                                                      this.renderTableRowValue(
                                                          CommonMethods.getCurrencyValues(
                                                              _invoiceDetailsList[
                                                                      0]
                                                                  .invoiceDetails!
                                                                  .igstTotal),
                                                          Alignment
                                                              .centerRight))
                                                  : this.renderPaymentDetails(
                                                      Container(), Container()),
                                              (taxType != Constants.IGST)
                                                  ? this.renderPaymentDetails(
                                                      this.renderTableRowHeading(
                                                          "4. ${Language().getString(Constants.SGST_TOTAL, selectedLang)} ( $orgCurrencySymbol )",
                                                          TextAlign.left),
                                                      this.renderTableRowValue(
                                                          CommonMethods.getCurrencyValues(
                                                              _invoiceDetailsList[
                                                                      0]
                                                                  .invoiceDetails!
                                                                  .sgstTotal),
                                                          Alignment
                                                              .centerRight))
                                                  : this.renderPaymentDetails(
                                                      Container(), Container()),
                                              (taxType != Constants.IGST)
                                                  ? this.renderPaymentDetails(
                                                      this.renderTableRowHeading(
                                                          "5. ${Language().getString(Constants.CGST_TOTAL, selectedLang)} ( $orgCurrencySymbol )",
                                                          TextAlign.left),
                                                      this.renderTableRowValue(
                                                          CommonMethods.getCurrencyValues(
                                                              _invoiceDetailsList[
                                                                      0]
                                                                  .invoiceDetails!
                                                                  .cgstTotal),
                                                          Alignment
                                                              .centerRight))
                                                  : this.renderPaymentDetails(
                                                      Container(), Container()),
                                              this.renderPaymentDetails(
                                                  (taxType == Constants.IGST)
                                                      ? this.renderTableRowHeading(
                                                          "5. ${Language().getString(Constants.TOTAL_PRICE, selectedLang)} (3+4) ( $orgCurrencySymbol )",
                                                          TextAlign.left)
                                                      : this.renderTableRowHeading(
                                                          "6. ${Language().getString(Constants.TOTAL_PRICE, selectedLang)} (3+4+5) ( $orgCurrencySymbol )",
                                                          TextAlign.left),
                                                  this.renderTableRowValue(
                                                      CommonMethods
                                                          .getCurrencyValues(
                                                              _invoiceDetailsList[
                                                                      0]
                                                                  .invoiceDetails!
                                                                  .totalPrice),
                                                      Alignment.centerRight)),
                                              this.renderPaymentDetails(
                                                  (taxType == Constants.IGST)
                                                      ? this.renderTableRowHeading(
                                                          "6. ${Language().getString(Constants.ADDITIONAL_DISCOUNT, selectedLang)} ( $orgCurrencySymbol )" +
                                                              (_invoiceDetailsList[
                                                                              0]
                                                                          .invoiceDetails!
                                                                          .additionalDiscountType ==
                                                                      'percent'
                                                                  ? (" ( ${_invoiceDetailsList[0].invoiceDetails!.additionalDiscountValue} % )")
                                                                  : ""),
                                                          TextAlign.left)
                                                      : this.renderTableRowHeading(
                                                          "7. ${Language().getString(Constants.ADDITIONAL_DISCOUNT, selectedLang)} ( $orgCurrencySymbol )" +
                                                              (_invoiceDetailsList[
                                                                              0]
                                                                          .invoiceDetails!
                                                                          .additionalDiscountType ==
                                                                      'percent'
                                                                  ? (" ( ${_invoiceDetailsList[0].invoiceDetails!.additionalDiscountValue} % )")
                                                                  : ""),
                                                          TextAlign.left),
                                                  this.renderTableRowValue(
                                                      CommonMethods
                                                          .getCurrencyValues(
                                                              _invoiceDetailsList[
                                                                      0]
                                                                  .invoiceDetails!
                                                                  .additionalDiscount),
                                                      Alignment.centerRight)),
                                              for (var item
                                                  in _invoiceDetailsList[0].invoiceDetails!
                                                      .additionalCharges!)
                                                renderAdditionalCharges(item),
                                              this.renderPaymentDetails(
                                                  (taxType == Constants.IGST)
                                                      ? this.renderTableRowHeading(
                                                          "${getInvoiceColumnNumber()}. ${Language().getString(Constants.INVOICE_AMOUNT, selectedLang)} ${getInvoiceAmountNumbers()} ( $orgCurrencySymbol )",
                                                          TextAlign.left)
                                                      : this.renderTableRowHeading(
                                                          "${getInvoiceColumnNumber()}. ${Language().getString(Constants.INVOICE_AMOUNT, selectedLang)} ${getInvoiceAmountNumbers()} ( $orgCurrencySymbol )",
                                                          TextAlign.left),
                                                  this.renderTableRowValue(
                                                      CommonMethods
                                                          .getCurrencyValues(
                                                              getInvoiceAmount()),
                                                      Alignment.centerRight)),
                                              this.renderPaymentDetails(
                                                  (taxType == Constants.IGST)
                                                      ? this.renderTableRowHeading(
                                                          "${++columnNumber}. ${Language().getString(Constants.AMOUNT_PAID, selectedLang)} ( $orgCurrencySymbol )",
                                                          TextAlign.left)
                                                      : this.renderTableRowHeading(
                                                          "${++columnNumber}. ${Language().getString(Constants.AMOUNT_PAID, selectedLang)} ( $orgCurrencySymbol )",
                                                          TextAlign.left),
                                                  this.renderTableRowValue(
                                                      CommonMethods
                                                          .getCurrencyValues(0),
                                                      Alignment.centerRight)),
                                              this.renderPaymentDetails(
                                                  (taxType == Constants.IGST)
                                                      ? this.renderTableRowHeading(
                                                          "${++columnNumber}. ${Language().getString(Constants.INVOICE_BALANCE_DUE, selectedLang)} (${columnNumber - 2}-${columnNumber - 1}) ( $orgCurrencySymbol )",
                                                          TextAlign.left)
                                                      : this.renderTableRowHeading(
                                                          "${++columnNumber}. ${Language().getString(Constants.INVOICE_BALANCE_DUE, selectedLang)} (${columnNumber - 2}-${columnNumber - 1}) ( $orgCurrencySymbol )",
                                                          TextAlign.left),
                                                  this.renderTableRowValue(
                                                      CommonMethods
                                                          .getCurrencyValues(
                                                              getInvoiceAmount()),
                                                      Alignment.centerRight))
                                            ],
                                          )),
                                ],
                              ),
                            ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    ));
  }

  renderPaymentDetails(Widget w1, Widget w2) {
    return TableRow(children: [w1, w2]);
  }

  num getInvoiceAmount() {
    num finalTotal = _invoiceDetailsList[0].invoiceDetails!.finalTotal!;
    List<AdditionalCharges> list = _invoiceDetailsList[0].additionalCharges!;
    for (var i = 0; i < list.length; i++) {
      finalTotal += list[i].value!;
    }

    return finalTotal;
  }

  int getInvoiceColumnNumber() {
    if (_invoiceDetailsList[0].invoiceDetails!.additionalCharges!.length > 0) {
      return ++columnNumber;
    } else {
      return taxType == Constants.IGST ? columnNumber += 7 : columnNumber += 8;
    }
  }

  String getInvoiceAmountNumbers() {
    String value = "";
    List<AdditionalCharges> list = _invoiceDetailsList[0].invoiceDetails!.additionalCharges!;
    if (taxType == Constants.IGST) {
      value =
          list.length > 0 ? "((5-6)${getNumberListForCalculation()})" : "(5-6)";
    } else {
      value =
          list.length > 0 ? "((6-7)${getNumberListForCalculation()})" : "(6-7)";
    }

    return value;
  }

  String getNumberListForCalculation() {
    String value = "+";
    int counter = taxType == Constants.IGST ? 6 : 7;
    for (int i = counter; i < columnNumber - 1; i++) {
      value += "${i + 1}+";
    }

    if (value.endsWith('+')) {
      value = value.substring(0, value.length - 1);
    }
    return value;
  }

  renderAdditionalCharges(AdditionalCharges item) {
    if (taxType == Constants.IGST) {
      columnNumber = columnNumber == 0 ? columnNumber + 7 : columnNumber + 1;
    } else {
      columnNumber = columnNumber == 0 ? columnNumber + 8 : columnNumber + 1;
    }
    return renderPaymentDetails(
        renderTableRowHeading("$columnNumber. ${item.label}", TextAlign.start),
        renderTableRowValue("${item.value!}", Alignment.centerRight));
  }

  renderBottomView() {
    if (widget.isFromStockReconciliation) {
      return Container(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 30),
          child: CommonButtonsView(
            context: context,
            b1Text: Language().getString(Constants.STR_CANCEL, selectedLang),
            b2Text:
                Language().getString(Constants.UPDATE_INVOICE, selectedLang),
            onb1Action: () => Navigator.of(context).pop(),
            onb2Action: () async {
              if (widget.isForProductReplacement!) {
                Navigator.push(
                  context,
                  PageTransition(
                    context: context,
                    page: ProductReplaceInvoiceGeneratePage(
                        products: invoiceProducts,
                        transactionId: widget.transactionId,
                        termType: "",
                        invoiceNo: widget.invoiceNo,
                        invoiceId: _invoiceDetailsList[0].invoiceId),
                  ),
                );
              } else {
                Navigator.push(
                  context,
                  PageTransition(
                    context: context,
                    page: GenerateInvociePage(
                        products: invoiceProducts,
                        transactionId: widget.transactionId,
                        termType: "",
                        isFromStockReconciliation:
                            widget.isFromStockReconciliation,
                        invoiceNo: widget.invoiceNo,
                        invoiceId: _invoiceDetailsList[0].invoiceId),
                  ),
                );
              }
            },
          ));
    } else {
      return null;
    }
  }

  showInvoiceItemsData() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Table(
        border: TableBorder.all(
          color: Colors.black,
        ),
        defaultColumnWidth: FixedColumnWidth(150),
        children: [
          TableRow(children: [
            this.renderTableRowHeading(
                Language().getString("S.No.", selectedLang), TextAlign.center),
            this.renderTableRowHeading(
                Language().getString(Constants.PRODUCT_NAME, selectedLang),
                TextAlign.center),
            this.renderTableRowHeading(
                Language().getString(Constants.HSN_CODE, selectedLang),
                TextAlign.center),
            this.renderTableRowHeading(
                Language().getString(Constants.QUANTITY, selectedLang),
                TextAlign.center),
            this.renderTableRowHeading(
                Language().getString(Constants.BATCH_NO, selectedLang),
                TextAlign.center),
            this.renderTableRowHeading(
                Language().getString(Constants.PRICE_UNIT, selectedLang) +
                    " ($orgCurrencySymbol) ",
                TextAlign.center),
            this.renderTableRowHeading(
                Language().getString(Constants.PRODUCT_COST, selectedLang) +
                    " ($orgCurrencySymbol) ",
                TextAlign.center),
            this.renderTableRowHeading(
                Language().getString(Constants.OFFER_VALUE, selectedLang) +
                    " (%)",
                TextAlign.center),
            this.renderTableRowHeading(
                Language().getString(Constants.OFFER_AMOUNT, selectedLang) +
                    " ($orgCurrencySymbol)",
                TextAlign.center),
            this.renderTableRowHeading(
                Language()
                        .getString(Constants.TOTAL_OFFER_AMOUNT, selectedLang) +
                    " ($orgCurrencySymbol)",
                TextAlign.center),
            if (taxType == Constants.IGST)
              this.renderTableRowHeading("$taxType", TextAlign.center),
            if (taxType != Constants.IGST)
              this.renderTableRowHeading(
                  "${Constants.SGST} (%)", TextAlign.center),
            if (taxType != Constants.IGST)
              this.renderTableRowHeading(
                  "${Constants.SGST} ($orgCurrencySymbol)", TextAlign.center),
            if (taxType != Constants.IGST)
              this.renderTableRowHeading(
                  "${Constants.CGST} (%)", TextAlign.center),
            if (taxType != Constants.IGST)
              this.renderTableRowHeading(
                  "${Constants.CGST} ($orgCurrencySymbol)", TextAlign.center),
            this.renderTableRowHeading(
                Language().getString(Constants.GST_TOTAL, selectedLang) +
                    " ($orgCurrencySymbol)",
                TextAlign.center),
            this.renderTableRowHeading(
                Language().getString(
                        Constants.PRODUCT_AMOUNT_TOTAL, selectedLang) +
                    " ($orgCurrencySymbol)",
                TextAlign.center),
          ]),
          for (int i = 0; i < userProductsList.length; i++)
            this.showInvoiceProducts(i)
        ],
      ),
    );
  }

  renderTableRowHeading(String hederText, TextAlign _textAlign) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        child: Text(
          hederText,
          textAlign: _textAlign,
          style: TextStyle(
              color: Color(Constants.APP_COLOR),
              fontWeight: FontWeight.bold,
              fontSize: 13.0),
        ),
      ),
    );
  }

  Future<List<InvoiceDAO>> getInvoiceData() async {
    String body = json.encode({"id": widget.invoiceId});
    List<InvoiceDAO> list = [];
    var response = await _transactionService
        .getInvoiceDetailsByInvoiceId(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(resObj)) {
        list.add(InvoiceDAO.fromJson(resObj[0]));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }

    return list;
  }

  showSoldByAddress() {
    String? symbol = _invoiceDetailsList[0].sellerContactDetails!.currencySymbol; 
    // orgCurrencySymbol =
    //     _invoiceDetailsList[0].sellerContactDetails!.currencySymbol;
    orgCurrencySymbol = (symbol != null && symbol.isNotEmpty && symbol != "-")
        ? symbol
        : "\u20B9";
    String? panNumber = "";
    String? cinNumber = "";
    for (var i = 0;
        i < _invoiceDetailsList[0].sellerContactDetails!.taxList!.length;
        i++) {
      if (_invoiceDetailsList[0].sellerContactDetails!.taxList![i].schemeName ==
          Constants.PAN) {
        panNumber = _invoiceDetailsList[0]
            .sellerContactDetails!
            .taxList![i]
            .schemeNumber;
      }

      if (_invoiceDetailsList[0].sellerContactDetails!.taxList![i].schemeName ==
          Constants.CIN) {
        cinNumber = _invoiceDetailsList[0]
            .sellerContactDetails!
            .taxList![i]
            .schemeNumber;
      }
    }

    return ShowInvoiceAddress(
        invoiceAddress: _invoiceDetailsList[0].sellerContactDetails!.address,
        name: _invoiceDetailsList[0].sellerContactDetails!.contactName,
        gstNumber: _invoiceDetailsList[0].sellerContactDetails!.gstNumber,
        mobileNumber:
            "${_invoiceDetailsList[0].sellerContactDetails!.countryCode} ${_invoiceDetailsList[0].sellerContactDetails!.contactNumber}",
        isSellerAddress: true,
        orgPanNumber: panNumber,
        orgCinNumber: cinNumber,
        canShowEmailPanCin: false);
  }

  showSoldToAddress() {
    return ShowInvoiceAddress(
        invoiceAddress: _invoiceDetailsList[0].buyerContactDetails!.address,
        name: _invoiceDetailsList[0].buyerContactDetails!.contactName,
        gstNumber: _invoiceDetailsList[0].buyerContactDetails!.gstNumber,
        mobileNumber:
            "${_invoiceDetailsList[0].buyerContactDetails!.countryCode} ${_invoiceDetailsList[0].buyerContactDetails!.contact}");
  }

  showInvoiceProducts(int i) {
    return TableRow(children: [
      this.renderTableRowValue("${i + 1}", Alignment.center),
      this.renderTableRowValue(
          "${userProductsList[i].productName}", Alignment.centerLeft),
      this.renderTableRowValue(
          "${userProductsList[i].hsnCode} ", Alignment.center),
      this.renderTableRowValue(
          "${userProductsList[i].quantity} ${userProductsList[i].quantityIn}",
          Alignment.center),
      this.renderTableRowValue(
          "${userProductsList[i].batchNumber}", Alignment.center),
      this.renderTableRowValue(
          CommonMethods.getCurrencyValues(userProductsList[i].unitPrice),
          Alignment.center),
      this.renderTableRowValue(
          CommonMethods.getCurrencyValues(userProductsList[i].productCost),
          Alignment.center),
      this.renderTableRowValue(
          "${userProductsList[i].offerData != null && userProductsList[i].offerSelected! ? userProductsList[i].offerData!.offerQuantity : 0}",
          Alignment.center),
      this.renderTableRowValue(
          CommonMethods.getCurrencyValues(userProductsList[i].offerAmount),
          Alignment.center),
      this.renderTableRowValue(
          CommonMethods.getCurrencyValues(
              userProductsList[i].productTotalOffer),
          Alignment.center),
      if (taxType == Constants.IGST)
        this.renderTableRowValue(
            CommonMethods.getCurrencyValues(userProductsList[i].gst),
            Alignment.center),
      if (taxType != Constants.IGST)
        this.renderTableRowValue(
            "${userProductsList[i].sgstPercentage}", Alignment.center),
      if (taxType != Constants.IGST)
        this.renderTableRowValue(
            CommonMethods.getCurrencyValues(userProductsList[i].sgst),
            Alignment.center),
      if (taxType != Constants.IGST)
        this.renderTableRowValue(
            "${userProductsList[i].cgstPercentage}", Alignment.center),
      if (taxType != Constants.IGST)
        this.renderTableRowValue(
            CommonMethods.getCurrencyValues(userProductsList[i].cgst),
            Alignment.center),
      this.renderTableRowValue(
          CommonMethods.getCurrencyValues(userProductsList[i].gstTotal),
          Alignment.center),
      this.renderTableRowValue(
          CommonMethods.getCurrencyValues(
              userProductsList[i].productAmountTotal),
          Alignment.center),
    ]);
  }

  renderTableRowValue(String value, Alignment _textAlign) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        alignment: _textAlign,
        child: Text(value,
            style: TextStyle(
                fontSize: textFontSize, color: Color(Constants.APP_COLOR))),
      ),
    );
  }

  renderTableRowGstValue(String sgst, String cgst) {
    return Table(
      border: TableBorder.all(
        color: Colors.black,
      ),
      children: [
        TableRow(children: [
          Center(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                child: Text(
                  "$sgst",
                  style: TextStyle(
                      color: Color(Constants.APP_COLOR), fontSize: 13.0),
                ),
              ),
            ),
          ),
          Center(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                child: Text(
                  "$cgst",
                  style: TextStyle(
                      color: Color(Constants.APP_COLOR), fontSize: 13.0),
                ),
              ),
            ),
          )
        ])
      ],
    );
  }

  showReplacedProductsData() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Table(
        border: TableBorder.all(
          color: Colors.black,
        ),
        defaultColumnWidth: FixedColumnWidth(150),
        children: [
          TableRow(children: [
            this.renderTableRowHeading(
                Language().getString("S.No.", selectedLang), TextAlign.center),
            this.renderTableRowHeading(
                Language().getString(Constants.PRODUCT_NAME, selectedLang),
                TextAlign.center),
            this.renderTableRowHeading(
                Language().getString(Constants.HSN_CODE, selectedLang),
                TextAlign.center),
            this.renderTableRowHeading(
                Language().getString(Constants.QUANTITY, selectedLang),
                TextAlign.center),
            this.renderTableRowHeading(
                Language().getString(Constants.BATCH_NO, selectedLang),
                TextAlign.center)
          ]),
          for (int i = 0;
              i <
                  _invoiceDetailsList[0]
                      .invoiceDetails!
                      .replacedProducts!
                      .length;
              i++)
            this.showReplacedInvoiceProducts(i)
        ],
      ),
    );
  }

  showReplacedInvoiceProducts(int i) {
    return TableRow(children: [
      this.renderTableRowValue("${i + 1}", Alignment.center),
      this.renderTableRowValue(
          "${_invoiceDetailsList[0].invoiceDetails!.replacedProducts![i].productName}",
          Alignment.centerLeft),
      this.renderTableRowValue(
          "${_invoiceDetailsList[0].invoiceDetails!.replacedProducts![i].hsnCode}",
          Alignment.centerLeft),
      this.renderTableRowValue(
          "${_invoiceDetailsList[0].invoiceDetails!.replacedProducts![i].quantity} ${_invoiceDetailsList[0].invoiceDetails!.replacedProducts![i].quantityIn}",
          Alignment.center),
      this.renderTableRowValue(
          "${_invoiceDetailsList[0].invoiceDetails!.replacedProducts![i].batchNumber}",
          Alignment.center)
    ]);
  }
}
