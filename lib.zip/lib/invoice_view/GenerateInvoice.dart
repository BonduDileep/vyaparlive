import 'package:vyaparlive/components/BackDropInvoiceDateButton.dart';
import 'package:vyaparlive/components/additional_charges/AdditionalChargeButton.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/CustomRowWidget.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/invoice_view/BatchPriceDropdownView.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/InvoiceDAO.dart';
import 'package:vyaparlive/model/ModelProduct.dart';
import 'package:vyaparlive/model/bu_model/PaymentTermsModel.dart';
import 'package:vyaparlive/model/product_model/BatchPriceDAO.dart';
import 'package:vyaparlive/model/product_model/OffersDAO.dart';
import 'package:vyaparlive/model/product_model/ProductModel.dart';
import 'package:vyaparlive/model/stock_returns/FinalCreditNoteDAO.dart';
import 'package:vyaparlive/model/transaction/InvoiceDetailsModel.dart';
import 'dart:convert';

import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/service/bu_list_grpc_service.dart';
import 'package:vyaparlive/service/organization_service.dart';
import 'package:vyaparlive/service/product_services.dart';

class GenerateInvociePage extends StatefulWidget {
  final List<ModelProduct>? products;
  final String? transactionId;
  final String? termType;
  final bool isFromStockReconciliation;
  final String? invoiceNo;
  final String? buyerId;
  final String? invoiceId;
  GenerateInvociePage(
      {this.products,
      this.transactionId,
      this.termType,
      this.isFromStockReconciliation = false,
      this.invoiceNo,
      this.buyerId,
      this.invoiceId});
  @override
  _GenerateInvociePageState createState() => _GenerateInvociePageState();
}

class _GenerateInvociePageState extends State<GenerateInvociePage> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? buName = "";
  String? radioButtonValue = Constants.OFFER_IN_PERCENTAGE;
  String discountType = "percent";
  // static const String OFFER_IN_PERCENTAGE = "Discount in percentage";
  static const String OFFER_IN_RUPEES = "Discount in rupees";
  static const String CONNECTION_TERMS = "Connection Specific Terms";
  static const String BU_TERMS = "Business Unit Terms";
  String? termsRadioButtonValue = "";
  final _rupeeController = TextEditingController();
  String? offerInPercentage;
  List<ModelProduct> selectedProductsList = [];
  num? _selectedCount = 0;
  bool isOfferActive = false;
  final List<TextEditingController> unitPriceController = [];
  String termType = "";
  String buttonText = "";

  List<InvoiceDAO> _invoiceData = [];
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  String url = "";
  late BuListGrpcService _transactionService;
  List<TextEditingController> _quantityInputController = [];
  bool isEnableTextEditingController = true;
  List<BatchPriceDAO?> batchPriceDropdown = [];
  List<BuProductModal> _productList = [];
  String? buId = "";
  List<bool> isShowBatchPrice = [];
  late ProductService _productService;
  String? orgCurrencySymbol = "";
  late OrganizationService _organizationService;
  PaymentTerms? termsData;
  InvoiceDetails? invoiceDetails;
  bool isShowBottomButton = false;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  double editControllerBottomMargin = 15;
  List<FinalCreditNoteDAO> _creditNoteList = [];
  FinalCreditNoteDAO? creditNoteDropdownValue;
  TextEditingController creditNoteAdjustmentController =
      new TextEditingController();
  late ThemeData theme;

  List<bool> canShowPriceEditField = [];
  List<TextEditingController> _finalPriceEditController = [];

  List<Map<String, String>> additionalCharges = [];
  String? backDateInvoice;
  bool isIncludeGST = true;
  bool addAdditionalDiscount = false;
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _productService = ProductService();
    _organizationService = OrganizationService();
    buId = AppController.instance.getMyBuId;
    _transactionService = BuListGrpcService();
    termsRadioButtonValue = CONNECTION_TERMS;
    termType = "connection";
    if (widget.isFromStockReconciliation) {
      isEnableTextEditingController = false;
    }
    loadInvoiceData();
    buName = AppController.instance.getBuName;
    // orgCurrencySymbol = AppController.instance.getBuCurrencySymbol;
    String? symbol = AppController.instance.getBuCurrencySymbol;
    orgCurrencySymbol = (symbol != null && symbol.isNotEmpty && symbol != "-")
        ? symbol
        : "\u20B9";

    if (kIsWeb) {
      editControllerBottomMargin = 20;
    }
  }

  loadInvoiceData() async {
    if (widget.isFromStockReconciliation) {
      if (await NetworkStatus.getInternetStatus()) {
        await this.getInvoiceData().then((value) {
          _invoiceData.addAll(value);
          if (_invoiceData.length > 0) {
            invoiceDetails = _invoiceData[0].invoiceDetails;
          }
          if (invoiceDetails != null) {
            buttonText = Constants.RE_GENERATE_INVOICE;
            isShowBottomButton = true;
            for (int i = 0; i < invoiceDetails!.products!.length; i++) {
              unitPriceController.add(TextEditingController());
              _quantityInputController.add(new TextEditingController());
              batchPriceDropdown.add(null);
              isShowBatchPrice.add(true);
              _finalPriceEditController
                  .add(new TextEditingController(text: ""));
              canShowPriceEditField.add(false);
              setState(() {
                selectedProductsList.add(
                  ModelProduct(
                      id: invoiceDetails!.products![i].id,
                      images: null,
                      name: invoiceDetails!.products![i].productName,
                      quantity: invoiceDetails!.products![i].quantity,
                      counter: 0,
                      isButton: true,
                      isItemSelected: false,
                      unitPrice: invoiceDetails!.products![i].unitPrice,
                      price: invoiceDetails!.products![i].unitPrice,
                      offerData: invoiceDetails!.products![i].offerData,
                      offerSelected: invoiceDetails!.products![i].offerSelected,
                      batchPriceList:
                          invoiceDetails!.products![i].batchPricingList,
                      offerList: [],
                      quantityIn: invoiceDetails!.products![i].quantityIn,
                      batchNumber: invoiceDetails!.products![i].batchNumber),
                );
                _quantityInputController[i] = TextEditingController(
                    text: invoiceDetails!.products![i].quantity.toString());
                _quantityInputController[i].selection =
                    TextSelection.fromPosition(TextPosition(
                        offset: _quantityInputController[i].text.length));
                _finalPriceEditController[i] = TextEditingController(
                    text: invoiceDetails!.products![i].unitPrice.toString());
                _finalPriceEditController[i].selection =
                    TextSelection.fromPosition(TextPosition(
                        offset: _finalPriceEditController[i].text.length));
              });

              this.loadBatchNumbersList(invoiceDetails!.products![i].id);
            }
          }
        });
      } else {
        AppUtills.showSnackBar(_scaffoldkey,
            Language().getString(Constants.NO_INTERNET, selectedLang),
            snackBarBgColor: Colors.black,
            messageColor: Colors.white,
            buttonColor: Colors.white);
      }
    } else {
      /// Getting products from PO page
      this.renderProductsToList();
      // await this.getAllCreditFinalNotes().then((value) {
      //   setState(() {
      //     _creditNoteList.clear();
      //     _creditNoteList.addAll(value);
      //   });
      // });
    }
  }

  renderTableRowDetails(Widget titleWidget, Widget valueWidget) {
    return TableRow(children: [titleWidget, valueWidget]);
  }

  renderTableRowValue(String value, {TextAlign textAlign = TextAlign.center}) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        child: Text(value,
            textAlign: textAlign,
            style: TextStyle(fontSize: 13, color: Color(Constants.APP_COLOR))),
      ),
    );
  }

  renderTableRowHeading(String? hederText, TextAlign _textAlign) {
    return Container(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Text(
          Language().getString(hederText, selectedLang),
          textAlign: _textAlign,
          style: TextStyle(
              color: Color(Constants.APP_COLOR),
              fontWeight: FontWeight.bold,
              fontSize: 13.0),
        ),
      ),
    );
  }

  renderAdditionalCharges(Map<String, String> item, int index) {
    return renderTableRowDetails(
        renderTableRowHeading("${item["label"]}", TextAlign.start),
        renderAdditionalChargeValueWidget("${item["value"]}", index));
  }

  renderAdditionalChargeValueWidget(String value, int index) {
    return Container(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          renderTableRowValue(value, textAlign: TextAlign.start),
          Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child: InkWell(
                child: Icon(
                  Icons.remove_circle_outline,
                  size: 25,
                  color: Colors.red,
                ),
                onTap: () async {
                  final item = additionalCharges[index];
                  final action = await Dialogs.yesCancelDialog(
                      context,
                      Language()
                          .getString(Constants.CONFIRMATION, selectedLang),
                      Language().getString(
                          "Are you sure, do you want to delete additional charge for ${item["label"]}?",
                          selectedLang),
                      Language().getString(Constants.YES_STRING, selectedLang),
                      Language().getString(Constants.NO_STRING, selectedLang),
                      true);

                  if (action == DialogAction.yes) {
                    setState(() {
                      additionalCharges.removeAt(index);
                    });
                  }
                }),
          ),
        ],
      ),
    );
  }

  Widget renderAdditionalChargeList() {
    return Container(
      padding: EdgeInsets.only(left: 5.0, right: 5.0, bottom: 5.0),
      width: MediaQuery.of(context).size.width,
      alignment: Alignment.centerRight,
      child: Table(
        border: TableBorder.all(
          color: Colors.black,
        ),
        children: [
          for (int index = 0; index < additionalCharges.length; index++)
            renderAdditionalCharges(additionalCharges[index], index),
        ],
      ),
    );
  }

  Widget renderBottomContent() {
    return Container(
        child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        renderAdditionalChargeList(),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
          child: AdditionalChargeButton(
            selectedLang: selectedLang!,
            buttonText: "Add additional charges",
            onAdd: (val1, val2) {
              setState(() {
                additionalCharges.add({"label": val1, "value": val2});
              });
            },
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
          child: Row(
            children: [
              BackDropInvoiceDateButton(
                  selectedLang: selectedLang!,
                  buttonText: "Back date invoice",
                  onSelected: (val1) {
                    print("selected date: " + val1);
                    setState(() {
                      backDateInvoice = val1;
                    });
                  }),
              SizedBox(
                width: 10.0,
              ),
              Text(
                backDateInvoice != null ? ": ${backDateInvoice!}" : "",
                style: TextStyle(
                    color: Colors.black, fontWeight: StyleView.fontMedium),
              )
            ],
          ),
        ),
        Container(
            padding: EdgeInsets.only(bottom: 20, left: 10, right: 10),
            child: CommonButtonsView(
              context: context,
              b1Text: "",
              b2Text: Language().getString(buttonText, selectedLang),
              onb1Action: () {},
              onb2Action: () {
                invoiceProductsValidation();
              },
            ))
      ],
    ));
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
        body: Stack(
      children: [
        SafeArea(
          child: Scaffold(
            key: _scaffoldkey,
            backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
            appBar: AppBar(
              centerTitle: true,
              elevation: 0,
              iconTheme: IconThemeData(color: theme.colorScheme.primary),
              backgroundColor: Colors.transparent, //Color(Constants.APP_COLOR),
              title: AppbarName(
                  title: Language()
                      .getString(Constants.GENERATE_INVOICE, selectedLang),
                  buName: "$buName"),
              actions: [
                AppUtills.homeButton(context),
              ],
            ),
            bottomNavigationBar:
                (isShowBottomButton) ? renderBottomContent() : null,
            body: Container(
              decoration: AppUtills.appBackgroundWithImage(),
              margin: EdgeInsets.symmetric(
                vertical: 10.0,
                horizontal: 5.0,
              ),
              child: Column(
                children: [
                  Container(
                    margin: EdgeInsets.only(bottom: 5.0),
                    child: Row(
                      children: [
                        Expanded(
                          child: Row(children: [
                            Container(
                              child: Radio(
                                value: CONNECTION_TERMS,
                                groupValue: termsRadioButtonValue,
                                onChanged: (dynamic values) {
                                  setState(() {
                                    termsRadioButtonValue = values;
                                    termType = "connection";
                                  });
                                },
                                materialTapTargetSize:
                                    MaterialTapTargetSize.shrinkWrap,
                              ),
                            ),
                            Expanded(
                                child: Row(
                              children: [
                                Expanded(
                                    child: Text(
                                        Language().getString(
                                            CONNECTION_TERMS, selectedLang),
                                        style: TextStyle(fontSize: 14.0))),
                                InkWell(
                                    onTap: () async {
                                      await serviceCallGetTerms(
                                              termType: "connection")
                                          .then((value) {
                                        termsData = value;
                                      });

                                      if (termsData != null) {
                                        showTermsDataView(CONNECTION_TERMS);
                                      }
                                    },
                                    child: Icon(Icons.info,
                                        size: 20.0,
                                        color: theme.colorScheme.primary))
                              ],
                            ))
                          ]),
                        ),
                        Expanded(
                          child: Row(children: [
                            Container(
                              child: Radio(
                                value: BU_TERMS,
                                groupValue: termsRadioButtonValue,
                                onChanged: (dynamic values) {
                                  setState(() {
                                    termsRadioButtonValue = values;
                                    termType = "bu";
                                  });
                                },
                                materialTapTargetSize:
                                    MaterialTapTargetSize.shrinkWrap,
                              ),
                            ),
                            Expanded(
                                child: Row(
                              children: [
                                Expanded(
                                    child: Text(
                                  Language().getString(BU_TERMS, selectedLang),
                                  style: TextStyle(fontSize: 14.0),
                                )),
                                InkWell(
                                    onTap: () async {
                                      await serviceCallGetTerms(termType: "bu")
                                          .then((value) {
                                        termsData = value;
                                      });

                                      if (termsData != null) {
                                        showTermsDataView(BU_TERMS);
                                      }
                                    },
                                    child: Icon(Icons.info,
                                        size: 20.0,
                                        color: theme.colorScheme.primary))
                              ],
                            ))
                          ]),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                          border:
                              Border.all(color: Color(Constants.APP_COLOR))),
                      child: Column(
                        children: [
                          Container(
                            child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: Row(
                                children: [
                                  Expanded(
                                    flex: 2,
                                    child: Text(
                                      Language().getString(
                                          Constants.PRODUCT, selectedLang),
                                      style: TextStyle(
                                        color: Color(Constants.APP_COLOR),
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    flex: 2,
                                    child: Text(
                                      Language().getString(
                                          Constants.QUANTITY, selectedLang),
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: Color(Constants.APP_COLOR),
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    child: Text(
                                      Language().getString(Constants.PRICE_UNIT,
                                              selectedLang) +
                                          " ( $orgCurrencySymbol )",
                                      style: TextStyle(
                                        color: Color(Constants.APP_COLOR),
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    child: Text(
                                      Language().getString(
                                          Constants.OFFER, selectedLang),
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: Color(Constants.APP_COLOR),
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Divider(
                            color: Color(Constants.APP_COLOR),
                          ),
                          Expanded(
                            child: Container(
                              child: ListView.separated(
                                separatorBuilder: (context, index) => Divider(
                                  color: Colors.transparent,
                                  height: 5.0,
                                ),
                                itemBuilder: (context, index) {
                                  return Container(
                                    child: this.renderProductDataDesign(
                                        index,
                                        selectedProductsList[index]
                                            .selectedUnit!),
                                  );
                                },
                                itemCount: selectedProductsList.length,
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    ));
  }

  bool showUnitDropdown(String? qty) {
    if (qty != null &&
        (qty.toLowerCase() == "kg" || qty.toLowerCase() == "litre"))
      return true;
    return false;
  }

  /// Desinging for show products data in ROW
  renderProductDataDesign(int index, String selectedUnit) {
    return Container(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(5.0),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    flex: 2,
                    child: Row(
                      children: [
                        Container(
                          height: 20.0,
                          width: 25.0,
                          child: Checkbox(
                              activeColor: Color(Constants.APP_COLOR),
                              value: selectedProductsList[index].isButton,
                              onChanged: (value) {
                                if (selectedProductsList[index]
                                        .batchPriceList!
                                        .length >
                                    0) {
                                  if (!widget.isFromStockReconciliation) {
                                    setState(() {
                                      selectedProductsList[index].isButton =
                                          value;
                                    });
                                  }
                                } else {
                                  Dialogs.yesCancelDialog(
                                      context,
                                      Language().getString(
                                          Constants.ERROR, selectedLang),
                                      Language().getString(
                                              Constants.THIS_PRODUCT,
                                              selectedLang) +
                                          " \"${selectedProductsList[index].name}\" " +
                                          Language().getString(
                                              Constants
                                                  .HAS_ZERO_QUANTITY_PLEASE_UPDATE,
                                              selectedLang),
                                      Language().getString(
                                          Constants.OKAY_STR, selectedLang),
                                      "",
                                      false);
                                }
                              }),
                        ),
                        Expanded(
                            child: Text(
                          "${selectedProductsList[index].name}",
                          style: TextStyle(
                            fontSize: 13.0,
                            color: Color(Constants.APP_COLOR),
                            fontWeight: FontWeight.bold,
                          ),
                        )),
                      ],
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        (isEnableTextEditingController)
                            ? InkWell(
                                onTap: () {
                                  if (selectedProductsList[index].isButton!) {
                                    this.renderRemoveProductQuantity(
                                        index, setState);
                                  } else {
                                    Dialogs.yesCancelDialog(
                                        context,
                                        Language().getString(
                                            Constants.INFO, selectedLang),
                                        Language().getString(
                                            Constants.FOR_FURTHER_ACTION,
                                            selectedLang),
                                        Language().getString(
                                            Constants.OKAY_STR, selectedLang),
                                        "",
                                        false);
                                  }
                                },
                                child: Icon(Icons.remove),
                              )
                            : Container(),
                        // renderProductQuantity(index),
                        this.designQuantityInputField(index),
                        if (showUnitDropdown(
                            selectedProductsList[index].quantityIn))
                          SizedBox(
                            width: 2,
                          ),
                        if (showUnitDropdown(
                            selectedProductsList[index].quantityIn))
                          Container(
                            height: 30,
                            padding: EdgeInsets.symmetric(horizontal: 6),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(6),
                              border: Border.all(color: Colors.black45),
                            ),
                            child: DropdownButton<String>(
                              value: selectedUnit,
                              underline: SizedBox(),
                              iconSize: 18,
                              onChanged: (unit) {
                                setState(() {
                                  if (selectedProductsList[index]
                                              .actual_quantity! <
                                          1 &&
                                      (unit == "kg" || unit == "litre")) {
                                    showQuantityAlert(index, unit!);
                                    return;
                                  }

                                  selectedProductsList[index].selectedUnit =
                                      unit;

                                  /// UPDATE MULTIPLIER
                                  if (unit == "kg") {
                                    selectedProductsList[index].unitMultiplier =
                                        1;
                                  }
                                  if (unit == "gram") {
                                    selectedProductsList[index].unitMultiplier =
                                        0.001;
                                  }

                                  if (unit == "litre") {
                                    selectedProductsList[index].unitMultiplier =
                                        1;
                                  }
                                  if (unit == "ml") {
                                    selectedProductsList[index].unitMultiplier =
                                        0.001;
                                  }

                                  /// RECALCULATE PRICE
                                  int sIndex = selectedProductsList.indexWhere(
                                      (e) =>
                                          e.id ==
                                          selectedProductsList[index].id);

                                  selectedProductsList[index].price =
                                      selectedProductsList[index].counterNew! *
                                          selectedProductsList[index]
                                              .unitPrice! *
                                          selectedProductsList[index]
                                              .unitMultiplier!;

                                  if (sIndex != -1) {
                                    final p = selectedProductsList[sIndex];
                                    p.price = p.counterNew! *
                                        p.unitPrice! *
                                        selectedProductsList[index]
                                            .unitMultiplier!;
                                    p.selectedUnit = unit;
                                  }
                                });
                              },
                              items: (selectedProductsList[index].quantityIn ==
                                          "kg"
                                      ? ["kg", "gram"]
                                      : ["litre", "ml"])
                                  .map((u) => DropdownMenuItem(
                                        value: u,
                                        child: Text(
                                          u,
                                          style: TextStyle(fontSize: 12),
                                        ),
                                      ))
                                  .toList(),
                            ),
                          ),
                        (isEnableTextEditingController)
                            ? InkWell(
                                onTap: () {
                                  if (selectedProductsList[index].isButton!) {
                                    this.renderAddProductQuantity(
                                        index, setState);
                                  } else {
                                    Dialogs.yesCancelDialog(
                                        context,
                                        Language().getString(
                                            Constants.INFO, selectedLang),
                                        Language().getString(
                                            Constants.FOR_FURTHER_ACTION,
                                            selectedLang),
                                        Language().getString(
                                            Constants.OKAY_STR, selectedLang),
                                        "",
                                        false);
                                  }
                                },
                                child: Icon(Icons.add),
                              )
                            : Container()
                      ],
                    ),
                  ),
                  this.renderProductUnitPrice(
                      selectedProductsList[index].batchPriceList!, index),
                  this.renderProductOffers(index)
                ],
              ),
              (selectedProductsList[index].batchPriceList!.length > 0)
                  ? batchPricingDropdown(
                      selectedProductsList[index].batchPriceList!, index)
                  : Container(
                      margin: EdgeInsets.symmetric(vertical: 5.0),
                      alignment: Alignment.centerLeft,
                      child: Text(
                        "This product has zero quantity, please update quantity",
                        style: TextStyle(
                            color: Colors.red,
                            fontWeight: FontWeight.w500,
                            fontSize: 13.0),
                      ),
                    )
            ],
          ),
        ),
      ),
    );
  }

  showQuantityAlert(int index, String unit) async {
    Dialogs.yesCancelDialog(
        context,
        Language().getString(Constants.ALERT, selectedLang),
        Language().getString(Constants.QUANTITY_WARNINIG, selectedLang),
        Language().getString(Constants.OKAY_STR, selectedLang),
        "",
        false);
  }

  designQuantityInputField(int index) {
    return Container(
      height: 30.0,
      width: 50.0,
      alignment: Alignment.center,
      decoration: BoxDecoration(border: Border.all(color: Colors.grey)),
      child: TextFormField(
        textAlign: TextAlign.center,
        enabled: isEnableTextEditingController,
        // enableInteractiveSelection: false,
        cursorWidth: 1.0,
        controller: _quantityInputController[index],
        decoration: InputDecoration(
            hintText: "0",
            border: InputBorder.none,
            contentPadding:
                EdgeInsets.fromLTRB(0, 0, 0, editControllerBottomMargin)),
        keyboardType: TextInputType.numberWithOptions(signed: true),

        style: TextStyle(fontSize: 12.0),
        inputFormatters: [
          new LengthLimitingTextInputFormatter(5),
          CommonMethods.inputTextFormatter(isNumber: true)
        ],
        onChanged: (value) async {
          /// Adding input value for product counter value
          if (value.isEmpty) {
            setState(() {
              selectedProductsList[index].quantity =
                  widget.products![index].quantity;
              _quantityInputController[index].clear();
            });
          } else if (int.parse(value) > widget.products![index].quantity!) {
            final action = await Dialogs.yesCancelDialog(
                context,
                Language().getString(Constants.ERROR, selectedLang),
                Language().getString(Constants.QUANTITY_WARNINIG, selectedLang),
                Language().getString(Constants.OKAY_STR, selectedLang),
                "",
                false);

            if (action == DialogAction.yes) {
              setState(() {
                selectedProductsList[index].quantity =
                    widget.products![index].quantity;
                _quantityInputController[index] = TextEditingController(
                    text: selectedProductsList[index].quantity.toString());
                _quantityInputController[index].selection =
                    TextSelection.fromPosition(TextPosition(
                        offset: _quantityInputController[index].text.length));
              });
            }
          } else {
            if (selectedProductsList.length > 0) {
              setState(() {
                selectedProductsList[index].quantity = int.parse(value);
                print(selectedProductsList[index].quantity);
              });
            }
          }
        },
      ),
    );
  }

  /// Showing product Offers
  renderProductOffers(int index) {
    return Expanded(
      child: (selectedProductsList[index].offerData != null &&
              selectedProductsList[index].offerData!.isOfferActive! &&
              !selectedProductsList[index].offerData!.isOfferExpired!)
          ? Column(
              children: [
                Container(
                  height: 25.0,
                  width: 25.0,
                  child: Checkbox(
                    activeColor: Colors.green,
                    value: selectedProductsList[index].offerSelected,
                    onChanged: (value) {
                      setState(() {
                        selectedProductsList[index].offerSelected = value;
                      });
                    },
                  ),
                ),
                Container(
                  child: InkWell(
                    onTap: () {
                      Dialogs.showOffer(
                          context,
                          selectedProductsList[index].offerData!.offerQuantity,
                          selectedProductsList[index].offerData!.offerName,
                          selectedProductsList[index].offerData!.minOrder,
                          selectedProductsList[index].offerData!.maxOrder,
                          selectedProductsList[index].offerData!.offerType);
                    },
                    child: Text(
                      Language().getString(Constants.OFFER, selectedLang),
                      style: TextStyle(
                          color: StyleView.offerColor,
                          decoration: TextDecoration.underline),
                    ),
                  ),
                )
              ],
            )
          : Center(
              child: Text(
                Language().getString(Constants.NO_ACTIVE_OFFER, selectedLang),
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontSize: 11.0,
                    color: StyleView.offerColor,
                    fontWeight: FontWeight.bold),
              ),
            ),
    );
  }

  /// Showing Product unit price
  renderProductUnitPrice(List<BatchPriceDAO> _batchList, int index) {
    if (_batchList.length > 0) {
      if (batchPriceDropdown[index] == null) {
        if (widget.isFromStockReconciliation) {
          selectedProductsList[index].unitPrice = _batchList[0].price;
        } else {
          bool isPriceAvailable = false;
          int availIndex = -1;
          for (int i = 0; i < _batchList.length; i++) {
            if (_batchList[i].price != 0) {
              isPriceAvailable = true;
              availIndex = i;
              break;
            }
          }
          if (isPriceAvailable && selectedProductsList[index].unitPrice != 0) {
            // selectedProductsList[index].unitPrice =
            //     _batchList[availIndex].price;
          }
        }
      }
    }

    if (isShowBatchPrice[index]) {
      unitPriceController[index] = TextEditingController(
          text: selectedProductsList[index].unitPrice.toString());
      unitPriceController[index].selection = TextSelection.fromPosition(
          TextPosition(offset: unitPriceController[index].text.length));
      isShowBatchPrice[index] = false;
    } else {
      unitPriceController[index] = TextEditingController(
          text: selectedProductsList[index].unitPrice.toString());
      unitPriceController[index].selection = TextSelection.fromPosition(
          TextPosition(offset: unitPriceController[index].text.length));
    }
    return Expanded(
      child: Container(
        height: 25.0,
        width: 0.0,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          border: Border.all(
            color: Colors.grey,
          ),
        ),
        child: Center(
          child: TextFormField(
            cursorWidth: 1.0,
            enableInteractiveSelection: false,
            textAlign: TextAlign.center,
            enabled: false,
            controller: unitPriceController[index],
            keyboardType: TextInputType.numberWithOptions(signed: true),
            style: TextStyle(
              fontSize: 12.0,
              fontWeight: FontWeight.bold,
            ),
            decoration: InputDecoration(
                border: InputBorder.none,
                hintText: "0",
                contentPadding:
                    EdgeInsets.fromLTRB(0, 0, 0, editControllerBottomMargin)),
            onChanged: (value) {
              if (value.isNotEmpty) {
                /// Adding updated unit price to selected list
                selectedProductsList[index].unitPrice = double.parse(value);
              }
            },
          ),
        ),
      ),
    );
  }

  /// Showing product quantity
  renderProductQuantity(int index) {
    return new Container(
      height: 20.0,
      width: 40.0,
      margin: EdgeInsets.symmetric(
        horizontal: 3.0,
      ),
      decoration: BoxDecoration(border: Border.all(color: Colors.grey)),
      child: Center(
        child: Text(
          "${selectedProductsList[index].quantity}",
          style: TextStyle(fontSize: 11.0, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }

  /// Removing product quantity
  renderRemoveProductQuantity(int index, StateSetter setState) {
    _selectedCount = selectedProductsList[index].quantity;

    if (_selectedCount == 1) {
      setState(() {
        selectedProductsList[index].quantity = _selectedCount;
        _quantityInputController[index] = TextEditingController(
            text: selectedProductsList[index].quantity.toString());
        _quantityInputController[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _quantityInputController[index].text.length));
      });
    } else {
      _selectedCount = _selectedCount! - 1;
      setState(() {
        selectedProductsList[index].quantity = _selectedCount;
        _quantityInputController[index] = TextEditingController(
            text: selectedProductsList[index].quantity.toString());
        _quantityInputController[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _quantityInputController[index].text.length));
      });
    }
  }

  /// Adding product quantiy
  renderAddProductQuantity(int index, StateSetter setState) {
    num? _count = selectedProductsList[index].quantity;

    if (_count == widget.products![index].quantity) {
      setState(() {
        selectedProductsList[index].quantity = _count;
        _quantityInputController[index] = TextEditingController(
            text: selectedProductsList[index].quantity.toString());
        _quantityInputController[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _quantityInputController[index].text.length));
      });
    } else {
      _count = _count! + 1;
      setState(() {
        selectedProductsList[index].quantity = _count;
        _quantityInputController[index] = TextEditingController(
            text: selectedProductsList[index].quantity.toString());
        _quantityInputController[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _quantityInputController[index].text.length));
      });
    }
  }

  loadBatchNumbersList(String? productId) async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
        progressMessage = Constants.GETTING_BATCH_PRICING;
      });
      this.getProuctById(productId).then((onValue) {
        setState(() {
          _productList.clear();
          _productList.addAll(onValue);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<BuProductModal>> getProuctById(String? productId) async {
    String body = json.encode({"id": productId, "buId": buId});

    var response = await _productService
        .getProductDetailsByProductId_grpc(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          "$onError",
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<BuProductModal> data = [];

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      data.add(BuProductModal.fromJson(resObj[0]));
      this.addingBatchPricing(data, productId);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }

    return data;
  }

  renderProductsToList() {
    buttonText = Constants.GENERATE_INVOICE;
    isShowBottomButton = true;
    for (int i = 0; i < widget.products!.length; i++) {
      if (widget.products![i].quantity != 0) {
        /// Adding TextEditingControllers to a list
        unitPriceController.add(new TextEditingController());
        _quantityInputController.add(new TextEditingController());
        if (widget.products![i].batchPriceList!.length > 0) {
          batchPriceDropdown.add(null);
          isShowBatchPrice.add(true);
          _finalPriceEditController.add(new TextEditingController(text: ""));
          canShowPriceEditField.add(false);

          ModelProduct product = widget.products![i];
          num actual_quantity = product.quantity!;
          String selectedUnit = product.quantityIn!;
          num quantity = product.quantity!;
          setState(() {
            isEnableTextEditingController = true;

            if (quantity < 1) {
              if (product.quantityIn == "kg") {
                selectedUnit = "gram";
              } else if (product.quantityIn == "litre") {
                selectedUnit = "ml";
              }
              quantity = quantity * 1000;
              print("Converted Quantity: $quantity");
            }
            widget.products![i].quantity = quantity;
            selectedProductsList.add(
              ModelProduct(
                  id: widget.products![i].id,
                  images: widget.products![i].images,
                  name: widget.products![i].name,
                  quantity: quantity, //widget.products![i].quantity,
                  counter: 0,
                  isButton: false,
                  isItemSelected: false,
                  unitPrice: widget.products![i].unitPrice,
                  price: widget.products![i].unitPrice,
                  offerData: widget.products![i].offerData,
                  offerSelected: widget.products![i].offerSelected,
                  batchPriceList: widget.products![i].batchPriceList,
                  offerList: [],
                  quantityIn: widget.products![i].quantityIn,
                  selectedUnit: selectedUnit,
                  actual_quantity: actual_quantity),
            );
          });

          _quantityInputController[i] =
              TextEditingController(text: quantity.toString());
          _quantityInputController[i].selection = TextSelection.fromPosition(
              TextPosition(offset: _quantityInputController[i].text.length));
          _finalPriceEditController[i] = TextEditingController(
              text: widget.products![i].unitPrice.toString());
          _finalPriceEditController[i].selection = TextSelection.fromPosition(
              TextPosition(offset: _finalPriceEditController[i].text.length));
          unitPriceController[i] = TextEditingController(
              text: widget.products![i].unitPrice.toString());
          unitPriceController[i].selection = TextSelection.fromPosition(
              TextPosition(offset: unitPriceController[i].text.length));
          this.loadBatchNumbersList(widget.products![i].id);
        }
      }
    }
  }

  showConfirmationPopup() {
    return showDialog(
      context: context,
      barrierColor: Colors.black54,
      barrierDismissible: false,
      builder: (context) => StatefulBuilder(builder: (context, setState) {
        return AlertDialog(
          actions: [
            Container(
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    TextButton(
                      onPressed: () {
                        Navigator.of(context).pop();
                        setState(() {
                          isIncludeGST = true;
                          addAdditionalDiscount = false;
                          radioButtonValue = Constants.OFFER_IN_PERCENTAGE;
                          discountType = "percent";
                        });
                        _rupeeController.clear();
                        offerInPercentage = null;
                        // radioButtonValue = null;
                      },
                      child: Text(
                        Language()
                            .getString(Constants.STR_CANCEL, selectedLang),
                        style: TextStyle(
                          color: Colors.red,
                          fontSize: 18.0,
                        ),
                      ),
                    ),
                    TextButton(
                      onPressed: () async {
                        Navigator.of(context).pop();

                        setState(() {
                          isLoadingProgress = true;
                          progressMessage = Constants.GENERATING_INVOICE;
                        });
                        if (await NetworkStatus.getInternetStatus()) {
                          if (widget.isFromStockReconciliation) {
                            this.updateInvoice();
                          } else {
                            /// For Create Invoice
                            this.serviceCallInvoice();
                          }
                        } else {
                          AppUtills.showSnackBar(
                              _scaffoldkey,
                              Language().getString(
                                  Constants.NO_INTERNET, selectedLang),
                              snackBarBgColor: Colors.black,
                              messageColor: Colors.white,
                              buttonColor: Colors.white);
                        }
                      },
                      child: Text(
                        Language().getString(
                            Constants.GENERATE_INVOICE, selectedLang),
                        style: TextStyle(
                          color: Color(Constants.APP_COLOR),
                          fontSize: 18.0,
                        ),
                      ),
                    ),
                    // TextButton(
                    //   onPressed: () {
                    //     Navigator.of(context).pop();
                    //     this.showInvoiceDiscountPopup();
                    //   },
                    //   child: Text(
                    //     Language()
                    //         .getString(Constants.YES_STRING, selectedLang),
                    //     style: TextStyle(
                    //       color: Color(Constants.APP_COLOR),
                    //       fontSize: 18.0,
                    //     ),
                    //   ),
                    // ),
                  ]),
            )
          ],
          contentPadding: EdgeInsets.fromLTRB(25.0, 25.0, 10.0, 25.0),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              buildIncludeGSTView(setState),
              SizedBox(
                height: 5.0,
              ),
              Divider(
                color: Colors.grey,
                thickness: 1,
              ),
              SizedBox(
                height: 5.0,
              ),
              buildAdditionalDiscountView(setState),
              SizedBox(
                height: 10.0,
              ),
              addAdditionalDiscount
                  ? buildAdditionalDiscountSelectionView(setState)
                  : Container(),
            ],
          ),
        );
      }),
    );
  }

  buildAdditionalDiscountSelectionView(StateSetter setState) {
    // radioButtonValue = Constants.OFFER_IN_PERCENTAGE;
    // discountType = "percent";
    return Container(
      // height: 350.0,
      child: Column(
        children: [
          Container(
            child: Row(
              children: [
                Radio(
                    activeColor: Color(Constants.APP_COLOR),
                    value: Constants.OFFER_IN_PERCENTAGE,
                    groupValue: radioButtonValue,
                    onChanged: (dynamic value) {
                      setState(() {
                        radioButtonValue = Constants.OFFER_IN_PERCENTAGE;
                        discountType = "percent";
                        _rupeeController.clear();
                      });
                    }),
                Expanded(
                  child: Text(
                    Language()
                        .getString(Constants.OFFER_IN_PERCENTAGE, selectedLang),
                    style: TextStyle(color: Color(Constants.APP_COLOR)),
                  ),
                ),
              ],
            ),
          ),
          Container(
            child: Row(
              children: [
                Radio(
                    activeColor: Color(Constants.APP_COLOR),
                    value: Constants.OFFER_IN_AMOUNT,
                    groupValue: radioButtonValue,
                    onChanged: (dynamic value) {
                      setState(() {
                        radioButtonValue = Constants.OFFER_IN_AMOUNT;
                        discountType = "number";

                        offerInPercentage = null;
                      });
                    }),
                Expanded(
                  child: Text(
                    Language().getString(
                            Constants.OFFER_IN_AMOUNT, selectedLang) +
                        " ( $orgCurrencySymbol ) ",
                    style: TextStyle(color: Color(Constants.APP_COLOR)),
                  ),
                ),
              ],
            ),
          ),
          (radioButtonValue == Constants.OFFER_IN_AMOUNT)
              ? buildInputFieldForAmount()
              : buildOfferPercentageDropdown(setState)
        ],
      ),
    );
  }

  buildAdditionalDiscountView(StateSetter setState) {
    return Container(
        child: Row(
      children: <Widget>[
        Container(
          child: Checkbox(
            activeColor: Color(Constants.APP_COLOR),
            value: addAdditionalDiscount,
            onChanged: (value) {
              setState(
                () {
                  addAdditionalDiscount = value!;
                  if (!value) {
                    radioButtonValue = Constants.OFFER_IN_PERCENTAGE;
                    discountType = "percent";
                    _rupeeController.clear();
                    offerInPercentage = null;
                  }
                },
              );
            },
          ),
        ),
        Expanded(
          child: Text(
            Language()
                .getString(Constants.ADD_ADDITIONAL_DISCOUNT, selectedLang),
            style: TextStyle(
              fontWeight: StyleView.fontMedium,
              color: Color(Constants.APP_COLOR),
              fontSize: 14,
            ),
          ),
        )
      ],
    ));
  }

  buildIncludeGSTView(StateSetter setState) {
    return Container(
        child: Row(
      children: <Widget>[
        Container(
          child: Checkbox(
            activeColor: Color(Constants.APP_COLOR),
            value: isIncludeGST,
            onChanged: (value) {
              setState(
                () {
                  isIncludeGST = value!;
                },
              );
            },
          ),
        ),
        Container(
          child: Text(
            "Include GST",
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Color(Constants.APP_COLOR),
              fontSize: 14,
            ),
          ),
        )
      ],
    ));
  }

  showInvoiceDiscountPopup() {
    radioButtonValue = Constants.OFFER_IN_PERCENTAGE;
    discountType = "percent";
    return showDialog(
        context: context,
        barrierColor: Colors.black54,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    _rupeeController.clear();
                    offerInPercentage = null;
                    radioButtonValue = null;
                  },
                  child: Text(
                    Language().getString(Constants.STR_CANCEL, selectedLang),
                    style: TextStyle(
                      color: Color(Constants.APP_COLOR),
                      fontSize: 18.0,
                    ),
                  ),
                ),
                TextButton(
                  onPressed: () async {
                    Navigator.of(context).pop();

                    if (await NetworkStatus.getInternetStatus()) {
                      setState(() {
                        isLoadingProgress = true;
                      });
                      if (widget.isFromStockReconciliation) {
                        /// For Invoice Update
                        this.updateInvoice();
                      } else {
                        /// For Create Invoice
                        this.serviceCallInvoice();
                      }
                    } else {
                      AppUtills.showSnackBar(
                          _scaffoldkey,
                          Language()
                              .getString(Constants.NO_INTERNET, selectedLang),
                          snackBarBgColor: Colors.black,
                          messageColor: Colors.white,
                          buttonColor: Colors.white);
                    }
                  },
                  child: Text(
                    Language().getString(Constants.OKAY_STR, selectedLang),
                    style: TextStyle(
                      color: Color(Constants.APP_COLOR),
                      fontSize: 18.0,
                    ),
                  ),
                ),
              ],
              contentPadding: EdgeInsets.fromLTRB(25.0, 25.0, 10.0, 25.0),
              content: StatefulBuilder(
                  builder: (BuildContext context, StateSetter setState) {
                return SingleChildScrollView(
                  child: Container(
                    // height: 350.0,
                    child: Column(
                      children: [
                        Container(
                          child: Row(
                            children: [
                              Radio(
                                  activeColor: Color(Constants.APP_COLOR),
                                  value: Constants.OFFER_IN_PERCENTAGE,
                                  groupValue: radioButtonValue,
                                  onChanged: (dynamic value) {
                                    setState(() {
                                      radioButtonValue =
                                          Constants.OFFER_IN_PERCENTAGE;
                                      discountType = "percent";
                                      _rupeeController.clear();
                                    });
                                  }),
                              Expanded(
                                child: Text(
                                  Language().getString(
                                      Constants.OFFER_IN_PERCENTAGE,
                                      selectedLang),
                                  style: TextStyle(
                                      color: Color(Constants.APP_COLOR)),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          child: Row(
                            children: [
                              Radio(
                                  activeColor: Color(Constants.APP_COLOR),
                                  value: OFFER_IN_RUPEES,
                                  groupValue: radioButtonValue,
                                  onChanged: (dynamic value) {
                                    setState(() {
                                      radioButtonValue = OFFER_IN_RUPEES;
                                      discountType = "number";

                                      offerInPercentage = null;
                                    });
                                  }),
                              Expanded(
                                child: Text(
                                  Language().getString(
                                          OFFER_IN_RUPEES, selectedLang) +
                                      " ( $orgCurrencySymbol ) ",
                                  style: TextStyle(
                                      color: Color(Constants.APP_COLOR)),
                                ),
                              ),
                            ],
                          ),
                        ),
                        (radioButtonValue == OFFER_IN_RUPEES)
                            ? this.buildInputFieldForAmount()
                            : this.buildOfferPercentageDropdown(setState),
                        // this.showFinalCreditNoteView(setState)
                      ],
                    ),
                  ),
                );
              }),
            ));
  }

  buildInputFieldForAmount() {
    return Container(
      height: 40.0,
      margin: EdgeInsets.symmetric(
        vertical: 10.0,
      ),
      decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(
            color: Colors.grey,
          ),
          borderRadius: BorderRadius.circular(5.0)),
      child: Padding(
        padding: const EdgeInsets.all(5.0),
        child: TextFormField(
          controller: _rupeeController,
          keyboardType: TextInputType.numberWithOptions(signed: true),
          inputFormatters: [CommonMethods.inputTextFormatter(isNumber: true)],
          decoration: InputDecoration(
              border: InputBorder.none,
              hintText:
                  Language().getString(Constants.ENTER_AMOUNT, selectedLang),
              contentPadding: EdgeInsets.only(bottom: 10.0)),
        ),
      ),
    );
  }

  buildOfferPercentageDropdown(StateSetter setState) {
    return Container(
      margin: EdgeInsets.symmetric(
        vertical: 5.0,
      ),
      height: 50.0,
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(
          color: Colors.grey,
        ),
        borderRadius: BorderRadius.circular(5.0),
      ),
      padding: EdgeInsets.all(5),
      child: DropdownButton<String>(
        onTap: () {
          FocusScope.of(context).unfocus();
        },
        value: offerInPercentage,
        hint: new Text("%"),
        isExpanded: true,
        underline: SizedBox(),
        onChanged: (String? data) {
          setState(() {
            offerInPercentage = data;
          });
        },
        items: Constants.PERCENTAGELIST.map((String model) {
          return new DropdownMenuItem<String>(
            child: new Text(model),
            value: model,
          );
        }).toList(),
      ),
    );
  }

  void serviceCallInvoice() async {
    List<Map<String, dynamic>> productArrayList = [];
    var productObject;

    for (int i = 0; i < selectedProductsList.length; i++) {
      if (selectedProductsList[i].isButton! &&
          selectedProductsList[i].batchPriceList!.length > 0) {
        if (selectedProductsList[i].quantity != 0) {
          num quantity = (selectedProductsList[i].selectedUnit == 'gram' ||
                  selectedProductsList[i].selectedUnit == 'ml')
              ? selectedProductsList[i].quantity! / 1000
              : selectedProductsList[i].quantity!;
          productObject = {
            "id": selectedProductsList[i].id,
            "quantity": quantity, //selectedProductsList[i].quantity,
            "unit_price": selectedProductsList[i].unitPrice,
            "offer_selected": selectedProductsList[i].offerSelected,
            "batch_no": batchPriceDropdown[i]!.batchNumber,
            "quantity_in": batchPriceDropdown[i]!.quantityIn
          };
          productArrayList.add(productObject);
        }
      }
    }

    List<String> splitValue = [];

    if (radioButtonValue == Constants.OFFER_IN_PERCENTAGE &&
        offerInPercentage != null) {
      splitValue = offerInPercentage!.split(" %");
      // discountValue = splitValue[0];
    } else {
      splitValue
          .add(_rupeeController.text.isEmpty ? "0.0" : _rupeeController.text);
    }

    List<Map<String, dynamic>> _additionalCharges = [];

    for (var element in additionalCharges) {
      _additionalCharges.add(
          {"label": element["label"], "value": num.parse(element["value"]!)});
    }

    Map data = {
      "txnId": widget.transactionId,
      "products": productArrayList,
      "term_type": termType,
      "additional_discount_type": discountType,
      "additional_discount": double.parse(splitValue[0]),
      "crn_id": creditNoteDropdownValue?.noteId,
      "crn_amount": int.parse(creditNoteAdjustmentController.text.isEmpty
          ? "0"
          : creditNoteAdjustmentController.text),
      "additional_charges": _additionalCharges,
      "include_gst": isIncludeGST,
    };

    if (backDateInvoice != null) {
      data["invoice_back_dt"] = backDateInvoice;
    }
    String body = json.encode(data);
    // http.Response
    var response = await _transactionService
        .generateTransactionInvoice(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    // _service.sendPackingDetails(body)

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          Language().getString(
              Constants.INVOICE_GENERATED_SUCCESSFULLY, selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);

      if (action == DialogAction.yes) {
        Navigator.pop(context);
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  void updateInvoice() async {
    List<Map<String, dynamic>> productsArray = [];
    var productsObject;

    for (int i = 0; i < selectedProductsList.length; i++) {
      if (selectedProductsList[i].quantity != 0) {
        productsObject = {
          "id": selectedProductsList[i].id,
          "quantity": selectedProductsList[i].quantity,
          "unit_price": selectedProductsList[i].unitPrice,
          "offer_selected": selectedProductsList[i].offerSelected,
          "batch_number": batchPriceDropdown[i]!.batchNumber,
          "quantity_in": batchPriceDropdown[i]!.quantityIn
        };
        productsArray.add(productsObject);
      }
    }
    List<String> splitValue = [];

    if (radioButtonValue == Constants.OFFER_IN_PERCENTAGE &&
        offerInPercentage != null) {
      splitValue = offerInPercentage!.split(" %");
      // discountValue = splitValue[0];
    } else {
      splitValue
          .add(_rupeeController.text.isEmpty ? "0.0" : _rupeeController.text);
    }

    Map data = {
      "bill_no": widget.invoiceNo!,
      "txnId": widget.transactionId,
      "products": productsArray,
      "package_details": invoiceDetails!.packageDetails,
      "assign_packing": invoiceDetails!.assignPackingDetails,
      "order_track": invoiceDetails!.orderTrackDetails,
      "stock_reconciliation": invoiceDetails!.stockReconciliation,
      "payment_reconciliation": invoiceDetails!.paymentReconciliation,
      "term_type": termType,
      "additional_discount_type": discountType,
      "additional_discount": double.parse(splitValue[0]),
      "actual_delivery_date": invoiceDetails!.actualDeliveryDate,
      "actual_delivery_time": invoiceDetails!.actualDeliveryTime,
      "stock_received_by": invoiceDetails!.receivedBy,
      "stock_received_status": invoiceDetails!.stockReceivedStatus,
      "delivery_status": invoiceDetails!.deliveryStatus,
    };

    String body = json.encode(data);
    // http.Response
    var response = await _transactionService
        .editInvoice(body, AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      return showDialog(
          context: context,
          barrierColor: Colors.black54,
          barrierDismissible: false,
          builder: (context) => AlertDialog(
                elevation: 100.0,
                contentPadding: EdgeInsets.fromLTRB(15.0, 0, 15.0, 10.0),
                backgroundColor: Color(0XFFE0E0E0),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(
                    Radius.circular(
                      7.0,
                    ),
                  ),
                ),
                title: Text(
                  Language().getString(Constants.SUCCESS, selectedLang),
                ),
                content: Container(
                  child: Text(Language().getString(
                      Constants.INVOICE_UPDATED_SUCCESSFULLY, selectedLang)),
                ),
                actions: [
                  TextButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                      Navigator.pop(context);
                      Navigator.pop(context);
                      Navigator.pop(context);
                    },
                    child: Text(
                      Language().getString(Constants.OKAY_STR, selectedLang),
                      style: TextStyle(
                          color: Color(Constants.APP_COLOR), fontSize: 18.0),
                    ),
                  )
                ],
              ));
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          "${_grpcResponse.message}",
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  void productReplacement() async {
    List<Map<String, dynamic>> productsArray = [];
    var productsObject;

    for (int i = 0; i < selectedProductsList.length; i++) {
      if (selectedProductsList[i].isButton!) {
        if (selectedProductsList[i].quantity != 0) {
          productsObject = {
            "id": selectedProductsList[i].id,
            "quantity": selectedProductsList[i].quantity,
            "unit_price": selectedProductsList[i].unitPrice,
            "offer_selected": selectedProductsList[i].offerSelected
          };
          productsArray.add(productsObject);
        }
      }
    }
    List<String> splitValue = [];

    if (radioButtonValue == Constants.OFFER_IN_PERCENTAGE &&
        offerInPercentage != null) {
      splitValue = offerInPercentage!.split(" %");
    } else {
      splitValue
          .add(_rupeeController.text.isEmpty ? "0.0" : _rupeeController.text);
    }

    Map data = {
      "bill_no": int.parse(widget.invoiceNo!),
      "txnId": widget.transactionId,
      "products": productsArray,
      "term_type": termType,
      "additional_discount_type": discountType,
      "additional_discount": double.parse(splitValue[0]),
    };

    String body = json.encode(data);
    var response = await _transactionService
        .productReplacementGRPC(
            body, AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      this.showProductReplacementPopup();
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          response.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  Future<List<InvoiceDAO>> getInvoiceData() async {
    setState(() {
      isLoadingProgress = true;
    });
    String body = json.encode({"id": widget.invoiceId});
    List<InvoiceDAO> list = [];
    var response = await _transactionService
        .getInvoiceDetailsByInvoiceId(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      list.add(InvoiceDAO.fromJson(resObj[0]));
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    return list;
  }

  batchPricingDropdown(List<BatchPriceDAO> batchNumberList, int index) {
    if (batchNumberList.length > 0) {
      if (batchPriceDropdown[index] == null) {
        // Prefer the batch passed in via widget.products (original source).
        String? preferredBatch;
        if (widget.products != null &&
            index < widget.products!.length &&
            widget.products![index].batchNumber != null &&
            widget.products![index].batchNumber!.isNotEmpty) {
          preferredBatch = widget.products![index].batchNumber;
        }
        int preferredIndex = -1;
        if (preferredBatch != null) {
          for (int i = 0; i < batchNumberList.length; i++) {
            if (batchNumberList[i].batchNumber == preferredBatch) {
              preferredIndex = i;
              break;
            }
          }
        }

        if (preferredIndex != -1) {
          batchPriceDropdown[index] = batchNumberList[preferredIndex];
        } else if (widget.isFromStockReconciliation) {
          batchPriceDropdown[index] = batchNumberList[0];
        } else {
          bool isPriceAvailable = false;
          int availIndex = -1;
          for (int i = 0; i < batchNumberList.length; i++) {
            if (batchNumberList[i].price != 0) {
              isPriceAvailable = true;
              availIndex = i;
              break;
            }
          }
          if (isPriceAvailable) {
            batchPriceDropdown[index] = batchNumberList[availIndex];
            // _finalPriceEditController[index].text =
            //     "${batchNumberList[availIndex].price}";
          }
        }
      }

      return BatchPriceDropDownView(
        canShowDynamicPricing: true,
        currentDropdownIndex: index,
        batchPricingList: batchNumberList,
        batchDropdown: batchPriceDropdown,
        finalPriceEditController: _finalPriceEditController,
        canShowPriceEditField: canShowPriceEditField,
        canShowPrice: true,
        canShowEdit: true,
        selectedDropdownValue: (data) {
          setState(() {
            batchPriceDropdown[index] = (data!);
            selectedProductsList[index].unitPrice =
                batchPriceDropdown[index]!.price;
          });
        },
        onChangeFinalPrice: (value) {
          if (value.isEmpty) {
            return;
          }
          num price = num.parse(value);
          if (price > 0) {
            setState(() {
              selectedProductsList[index].unitPrice = price;
            });
          }
        },
        onEdit: (index) {
          setState(() {
            canShowPriceEditField[index!] = !canShowPriceEditField[index];
          });
        },
        strBatchPricing: Language().getString(Constants.BATCH_NO, selectedLang),
        strAvailableQuantity:
            Language().getString(Constants.AVAILABLE_QUANTITY, selectedLang),
        isShowTextBatchNo: (widget.isFromStockReconciliation) ? true : false,
      );
    }
  }

  Future<PaymentTerms?> serviceCallGetTerms({String termType = ""}) async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = Constants.GETTING_DATA;
    });
    String body = json.encode({
      "seller_id": buId,
      "buyer_id": widget.buyerId,
      "term_type": termType,
    });

    var response = await _organizationService
        .findSpecificTerms(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    PaymentTerms? terms;
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      terms = PaymentTerms.fromJson(resObj);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }

    return terms;
  }

  showTermsDataView(String termType) {
    return showDialog(
        context: context,
        builder: (context) => Container(
              margin: EdgeInsets.symmetric(horizontal: 10.0, vertical: 50.0),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: AppBackgroundView(
                  body: Scaffold(
                    backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                    body: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: StreamBuilder<Object>(
                          stream: null,
                          builder: (context, snapshot) {
                            return AppBackgroundView(
                              body: SingleChildScrollView(
                                child: Column(
                                  children: [
                                    Container(
                                      child: Row(
                                        children: [
                                          Expanded(
                                            child: Text(
                                              Language().getString(
                                                  termType, selectedLang),
                                              style: TextStyle(
                                                fontSize: 15.0,
                                                fontWeight:
                                                    StyleView.fontSemiBold,
                                                color:
                                                    theme.colorScheme.primary,
                                              ),
                                            ),
                                          ),
                                          IconButton(
                                              onPressed: () {
                                                Navigator.of(context).pop();
                                              },
                                              icon: Icon(Icons.close,
                                                  color: Colors.red))
                                        ],
                                      ),
                                    ),
                                    Container(
                                      margin:
                                          EdgeInsets.symmetric(vertical: 5.0),
                                      decoration: AppUtills.boxDecoration(),
                                      child: Column(
                                        children: [
                                          this.buildTermsTextView(
                                              Constants
                                                  .INVOICE_CURRENCY_CODE_STRING,
                                              termsData!.invoicecurrencycode!),
                                          SizedBox(
                                            height: 1,
                                            child: new Container(
                                                color: Color(
                                                    Constants.GREY_COLOR)),
                                          ),
                                          this.buildTermsTextView(
                                              Constants.INVOICE_PAYMENT_TERMS,
                                              termsData!.invoicePaymentTerms!),
                                          SizedBox(
                                            height: 1,
                                            child: new Container(
                                                color: Color(
                                                    Constants.GREY_COLOR)),
                                          ),
                                          this.buildTermsTextView(
                                              Constants.PENALTY_REASON,
                                              termsData!.penaltyAmount != null
                                                  ? termsData!
                                                      .penaltyAmount!.reason!
                                                  : ""),
                                          SizedBox(
                                            height: 1,
                                            child: new Container(
                                                color: Color(
                                                    Constants.GREY_COLOR)),
                                          ),
                                          this.buildTermsTextView(
                                              Constants.PENALTY_AMOUNT,
                                              (termsData!.penaltyAmount !=
                                                          null &&
                                                      termsData!.penaltyAmount!
                                                              .value !=
                                                          null)
                                                  ? "${termsData!.penaltyAmount!.value} %"
                                                  : ""),
                                          SizedBox(
                                            height: 1,
                                            child: new Container(
                                                color: Color(
                                                    Constants.GREY_COLOR)),
                                          ),
                                          this.buildTermsTextView(
                                              Constants.ADVANCE_PAYMENT,
                                              (termsData!.advancePayment !=
                                                          null &&
                                                      termsData!.advancePayment!
                                                              .value !=
                                                          null)
                                                  ? "${termsData!.advancePayment!.value} %"
                                                  : ""),
                                        ],
                                      ),
                                    ),
                                    buildTextField(Constants.CUSTOME_REMARKS),
                                    buildCommentFieldView(termsData!.comment!),
                                  ],
                                ),
                              ),
                            );
                          }),
                    ),
                  ),
                ),
              ),
            ));
  }

  buildTextField(String _text) {
    return Container(
      margin: EdgeInsets.symmetric(
        vertical: 10.0,
      ),
      child: Row(
        children: <Widget>[
          Align(
              child: Text(Language().getString(_text, selectedLang),
                  style: TextStyle(
                      color: theme.colorScheme.primary,
                      fontFamily: StyleView.FONT_TITLE,
                      fontWeight: StyleView.fontMedium,
                      fontSize: StyleView.FONT_SIZE_15)))
        ],
      ),
    );
  }

  buildCommentFieldView(String value) {
    return Container(
        height: MediaQuery.of(context).size.height * 0.25,
        width: MediaQuery.of(context).size.width,
        margin: EdgeInsets.symmetric(
          vertical: 5.0,
        ),
        decoration: BoxDecoration(
          border: Border.all(
            color: Colors.grey,
          ),
          borderRadius: BorderRadius.circular(5.0),
          color: Colors.white70,
        ),
        padding: EdgeInsets.only(left: 5),
        child: Text(
          value,
        ));
  }

  Widget buildTermsTextView(String text, String value) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 55,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(Language().getString(text, selectedLang),
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: StyleView.FONT_TITLE))),
                  )),
            ),
            Expanded(
              child: Container(
                  height: 55,
                  color: Colors.white,
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(value,
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: StyleView.FONT_TITLE))),
                  )),
            )
          ],
        ));
  }

  addingBatchPricing(List<BuProductModal> productData, String? productId) {
    for (int i = 0; i < selectedProductsList.length; i++) {
      if (productData[0].id == selectedProductsList[i].id) {
        setState(() {
          batchPriceDropdown[i] = null;
          if (widget.isFromStockReconciliation) {
            selectedProductsList[i].batchPriceList =
                bindingProductInvoiceBatchNumber(
                    selectedProductsList[i].batchNumber,
                    productData[0]); //productData[0].batchPrice;
          } else {
            selectedProductsList[i].batchPriceList = bindingAvailableBatches(
                productData[0]); //productData[0].batchPrice;
          }

          selectedProductsList[i].offerData =
              getActiveOffer(productData[0].offers!);
          selectedProductsList[i].isButton =
              bindingAvailableBatches(productData[0]).length > 0 ? true : false;
        });
      }
    }
  }

  OffersDAO? getActiveOffer(List<OffersDAO> offersList) {
    OffersDAO? _activeOffer;

    for (int i = 0; i < offersList.length; i++) {
      if (offersList[i].isOfferActive! && !offersList[i].isOfferExpired!) {
        _activeOffer = offersList[i];
      }
    }

    return _activeOffer;
  }

  List<BatchPriceDAO> bindingAvailableBatches(BuProductModal productData) {
    List<BatchPriceDAO> _batchNumber = [];
    for (var i = 0; i < productData.batchPrice!.length; i++) {
      if (productData.batchPrice![i].quantity != 0) {
        _batchNumber.add(productData.batchPrice![i]);
      }
    }
    return _batchNumber;
  }

  List<BatchPriceDAO> bindingProductInvoiceBatchNumber(
      String? batchNumber, BuProductModal productData) {
    List<BatchPriceDAO> _batchNumber = [];
    for (var i = 0; i < productData.batchPrice!.length; i++) {
      if (batchNumber == productData.batchPrice![i].batchNumber) {
        _batchNumber.add(productData.batchPrice![i]);
      }
    }
    return _batchNumber;
  }

  showProductReplacementPopup() {
    return showDialog(
        context: context,
        barrierColor: Colors.black54,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
              elevation: 100.0,
              contentPadding: EdgeInsets.fromLTRB(15.0, 0, 15.0, 10.0),
              backgroundColor: Color(0XFFE0E0E0),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(
                  Radius.circular(
                    7.0,
                  ),
                ),
              ),
              title:
                  Text(Language().getString(Constants.SUCCESS, selectedLang)),
              content: Container(
                child: Text(Language().getString(
                    Constants.INVOICE_GENERATED_SUCCESSFULLY, selectedLang)),
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    Navigator.pop(context);
                    Navigator.pop(context);
                    Navigator.pop(context);
                  },
                  child: Text(
                    Language().getString(Constants.OKAY_STR, selectedLang),
                    style: TextStyle(
                        color: Color(Constants.APP_COLOR), fontSize: 18.0),
                  ),
                )
              ],
            ));
  }

  void invoiceProductsValidation() async {
    bool isProductSelected = false;
    for (int i = 0; i < selectedProductsList.length; i++) {
      if (selectedProductsList[i].isButton!) {
        isProductSelected = true;
        break;
      }
    }

    /// If select any product if() block will execute.
    if (isProductSelected) {
      if (buttonText == Constants.GENERATE_INVOICE) {
        bool isQuantityMismatch = false;
        for (int i = 0; i < selectedProductsList.length; i++) {
          if (selectedProductsList[i].isButton!) {
            num multiplier = AppUtills.getUnitMultiplier(
                selectedProductsList[i].selectedUnit);
            final maxQtyBase = batchPriceDropdown[i]!.quantity!;

            // Convert typed qty to base unit (kg/ltr)
            final qtyInBase = selectedProductsList[i].quantity! * multiplier;

            // num selectBatchQuantity = batchPriceDropdown[i]!.quantity!;
            // if (selectedProductsList[i].quantity! > selectBatchQuantity)
            if (qtyInBase > maxQtyBase) {
              isQuantityMismatch = true;
              break;
            }
          }
        }

        /// If quantity is greater than selected batch quantity if() block will execute.
        if (isQuantityMismatch) {
          final action = await Dialogs.yesCancelDialog(
              context,
              Language().getString(Constants.INFO, selectedLang),
              Language().getString(
                  Constants.GENERATE_INVOICE_PRICE_CHANGE, selectedLang),
              Language().getString(Constants.OKAY_STR, selectedLang),
              Language().getString(Constants.STR_CANCEL, selectedLang),
              true);
          if (action == DialogAction.yes) {
            this.showConfirmationPopup();
          }
        } else {
          this.showConfirmationPopup();
        }
      } else {
        this.showConfirmationPopup();
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.INFO, selectedLang),
          Language().getString(
              Constants.PLEASE_SELECT_ATLEAST_ANY_PRODUCT_ALERT_STRING,
              selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          Language().getString(Constants.STR_CANCEL, selectedLang),
          true);
    }
  }

  Future<List<FinalCreditNoteDAO>> getAllCreditFinalNotes() async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = Constants.PLEASE_WAIT;
    });
    String body = json.encode({
      "bu": widget.buyerId,
      "seller_bu": buId,
      "filters": {},
    });
    List<FinalCreditNoteDAO> list = [];
    var response = await _transactionService
        .getCreditNotedSellerBuyerId(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(resObj)) {
        for (var obj in resObj) list.add(FinalCreditNoteDAO.fromJson(obj));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    return list;
  }

  Widget showFinalCreditNoteView(StateSetter setState) {
    return Container(
      margin: EdgeInsets.only(
        top: 10.0,
      ),
      child: Column(
        children: [
          Container(
            child: Text(
              "Adjust amout from final credit notes:",
              style: TextStyle(
                  color: Color(Constants.APP_COLOR),
                  fontSize: 14.0,
                  fontWeight: FontWeight.w600),
            ),
          ),
          Container(
            margin: EdgeInsets.symmetric(vertical: 5.0),
            height: 40.0,
            padding: EdgeInsets.all(3.0),
            decoration: AppUtills.boxDecoration(),
            child: DropdownButton<FinalCreditNoteDAO>(
              onTap: () {
                return CommonMethods.hideKeyboard(context);
              },
              isExpanded: true,
              underline: SizedBox(),
              value: creditNoteDropdownValue,
              onChanged: (FinalCreditNoteDAO? value) {
                setState(() {
                  creditNoteDropdownValue = value;
                });
              },
              items: _creditNoteList.map((FinalCreditNoteDAO item) {
                return DropdownMenuItem<FinalCreditNoteDAO>(
                  child: Text("${item.crnNo}"),
                  value: item,
                );
              }).toList(),
            ),
          ),
          (creditNoteDropdownValue != null)
              ? Container(
                  margin: EdgeInsets.only(top: 5.0),
                  child: CustomRowWidget(
                      title: Language()
                          .getString("Final Credit Amout", selectedLang),
                      titleTextSize: 12.0,
                      valueFlex: 1,
                      titleFlex: 2,
                      value: "${creditNoteDropdownValue!.finalCreditAmout}"),
                )
              : Container(),
          Container(
            decoration: AppUtills.boxDecoration(),
            padding: EdgeInsets.all(3.0),
            child: TextFormField(
              controller: creditNoteAdjustmentController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                border: InputBorder.none,
                hintText: "Enter Amount",
              ),
            ),
          )
        ],
      ),
    );
  }
}
