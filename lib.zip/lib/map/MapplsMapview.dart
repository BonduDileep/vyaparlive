import 'package:flutter/material.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/config/Language.dart';
// import 'package:map_my_india/map_my_india.dart';

class MapplsMapview extends StatefulWidget {
  const MapplsMapview({super.key});

  @override
  State<MapplsMapview> createState() => _MapplsMapviewState();
}

class _MapplsMapviewState extends State<MapplsMapview> {
  double userLatitude = 0;
  double userLogitude = 0;
  // List<SuggestedLocations> _elocation = [];
  bool showAutoSuggestWidget = false;
  TextEditingController textController = TextEditingController();
  // SuggestedLocations? selectedAddress;
  String? selectedLang = AppController.instance.getSelectedlanguage;
  @override
  void initState() {
    super.initState();
  }

  // void addMarker(double latitude, double longitude) async {
  //   mapController
  //       .addSymbol(SymbolOptions(geometry: LatLng(17.4660736, 78.3966645)));
  // }

  Widget autosuggestWidget() {
    return SizedBox();
    // return Column(
    //   children: [
    //     new SizedBox(height: 90),
    //     Container(
    //         padding: const EdgeInsets.fromLTRB(12, 0, 12, 0),
    //         decoration: const BoxDecoration(color: Colors.white),
    //         child: TextFormField(
    //             controller: textController,
    //             decoration: const InputDecoration(
    //                 hintText: "Search Here", fillColor: Colors.white),
    //             maxLines: 1,
    //             onChanged: (text) {
    //               //callAutoSuggest(text);
    //             })),
    //     // const SizedBox(
    //     //   height: 20,
    //     // ),
    //     _elocation.isNotEmpty
    //         ? Expanded(
    //             child: Container(
    //                 // padding: const EdgeInsets.fromLTRB(12, 0, 12, 0),
    //                 decoration: const BoxDecoration(
    //                   color: Colors.white,
    //                 ),
    //                 child: ListView.builder(
    //                     itemCount: _elocation.length,
    //                     itemBuilder: (context, index) {
    //                       return ListTile(
    //                         contentPadding: const EdgeInsets.all(12),
    //                         focusColor: Colors.white,
    //                         title: Text(_elocation[index].placeName ?? ''),
    //                         subtitle: Text(
    //                           _elocation[index].placeAddress ?? '',
    //                           maxLines: 2,
    //                         ),
    //                         onTap: () {
    //                           CommonMethods.hideKeyboard(context);
    //                           // addMarker(_elocation[index]);
    //                           // callGeocode(_elocation[index].placeAddress);
    //                           setState(() {
    //                             selectedAddress = _elocation[index];
    //                             _elocation.clear();
    //                           });
    //                           textController.text = '';
    //                         },
    //                       );
    //                     })))
    //         : Container()
    //   ],
    // );
  }

  // void callAutoSuggest(String text) async {
  //   if (text.length > 2) {
  //     try {
  //       AutoSuggestResponse? response =
  //           await MapmyIndiaAutoSuggest(query: text).callAutoSuggest();
  //       if (response != null && response.suggestedLocations != null) {
  //         setState(() {
  //           _elocation = response.suggestedLocations!;
  //         });
  //       } else {
  //         setState(() {
  //           _elocation = [];
  //         });
  //       }
  //     } catch (e) {
  //       if (e is PlatformException) {
  //         Fluttertoast.showToast(msg: '${e.code} --- ${e.message}');
  //       }
  //     }
  //   } else {
  //     setState(() {
  //       _elocation = [];
  //     });
  //   }
  // }

  // callGeocode(String? address) async {
  //   try {
  //     GeocodeResponse? response =
  //         await MapmyIndiaGeoCoding(address: address!).callGeocoding();
  //     if (response != null &&
  //         response.results != null &&
  //         response.results!.isNotEmpty) {
  //       addMarker(
  //           response.results![0].latitude!, response.results![0].longitude!);
  //     }
  //   } catch (e) {
  //     if (e is PlatformException) {
  //       Fluttertoast.showToast(msg: '${e.code} --- ${e.message}');
  //     }
  //   }
  // }

  @override
  void setState(VoidCallback fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  void dispose() {
    // mapController.dispose();
    textController.dispose();
    // selectedAddress = null;
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          extendBodyBehindAppBar: true,
          appBar: AppBar(
              title: Text(
                  Language().getString(Constants.SELECT_LOCATION, selectedLang))),
          body: Column(
            children: [
              autosuggestWidget(),
              // selectedAddress != null
              //     ? Positioned(
              //         bottom: 15,
              //         left: 16,
              //         right: 16,
              //         child: Container(
              //           color: Colors.white,
              //           child: Column(
              //             crossAxisAlignment: CrossAxisAlignment.end,
              //             children: [
              //               ListTile(
              //                 contentPadding: const EdgeInsets.all(12),
              //                 focusColor: Colors.white,
              //                 title: Text(
              //                   selectedAddress!.placeName ?? '',
              //                   style: TextStyle(
              //                       color: Colors.black,
              //                       fontWeight: StyleView.fontMedium),
              //                 ),
              //                 subtitle: Text(
              //                   selectedAddress!.placeAddress ?? '',
              //                   maxLines: 2,
              //                 ),
              //                 onTap: () {},
              //               ),
              //               Padding(
              //                 padding: const EdgeInsets.symmetric(horizontal: 8),
              //                 child: ElevatedButton(
              //                     style: ElevatedButton.styleFrom(
              //                         elevation: 5,
              //                         shape: RoundedRectangleBorder(
              //                             borderRadius: BorderRadius.circular(
              //                                 Constants.buttonRadius.large)),
              //                         backgroundColor: Color(0xff41B3A2)),
              //                     onPressed: () {
              //                       Navigator.of(context).pop(selectedAddress);
              //                     },
              //                     child: Container(
              //                       child: Text(
              //                         Constants.CONFIRM,
              //                         style: TextStyle(
              //                           color: Colors.white,
              //                           fontWeight: StyleView.fontMedium,
              //                         ),
              //                         textAlign: TextAlign.center,
              //                       ),
              //                     )),
              //               )
              //             ],
              //           ),
              //         ),
              //       )
              //     : Container()
            ],
          )
      
          // Stack(
          //   children: [
          //     MapmyIndiaMap(
          //       initialCameraPosition: CameraPosition(
          //           target: LatLng(17.4660736, 78.3966645), zoom: 14.0),
          //       onMapCreated: (map) => {
          //         mapController = map,
          //       },
          //       onMapClick: ((point, coordinates) {
          //         Fluttertoast.showToast(msg: coordinates.toString());
          //       }),
          //       onStyleLoadedCallback: () {
          //         // callGeocode();
          //         addMarker(0, 0);
          //         setState(() {
          //           showAutoSuggestWidget = true;
          //         });
          //       },
          //     ),
          //     showAutoSuggestWidget ? autosuggestWidget() : Container(),
          // selectedAddress != null
          //     ? Positioned(
          //         bottom: 15,
          //         left: 16,
          //         right: 16,
          //         child: Container(
          //           color: Colors.white,
          //           child: Column(
          //             crossAxisAlignment: CrossAxisAlignment.end,
          //             children: [
          //               ListTile(
          //                 contentPadding: const EdgeInsets.all(12),
          //                 focusColor: Colors.white,
          //                 title: Text(
          //                   selectedAddress!.placeName ?? '',
          //                   style: TextStyle(
          //                       color: Colors.black,
          //                       fontWeight: StyleView.fontMedium),
          //                 ),
          //                 subtitle: Text(
          //                   selectedAddress!.placeAddress ?? '',
          //                   maxLines: 2,
          //                 ),
          //                 onTap: () {},
          //               ),
          //               Padding(
          //                 padding: const EdgeInsets.symmetric(horizontal: 8),
          //                 child: ElevatedButton(
          //                     style: ElevatedButton.styleFrom(
          //                         elevation: 5,
          //                         shape: RoundedRectangleBorder(
          //                             borderRadius: BorderRadius.circular(
          //                                 Constants.buttonRadius.large)),
          //                         backgroundColor: Color(0xff41B3A2)),
          //                     onPressed: () {
          //                       Navigator.of(context).pop(selectedAddress);
          //                     },
          //                     child: Container(
          //                       child: Text(
          //                         Constants.CONFIRM,
          //                         style: TextStyle(
          //                           color: Colors.white,
          //                           fontWeight: StyleView.fontMedium,
          //                         ),
          //                         textAlign: TextAlign.center,
          //                       ),
          //                     )),
          //               )
          //             ],
          //           ),
          //         ),
          //       )
          //     : Container()
          //   ],
          // ),
          ),
    );
  }
}
