import 'dart:io';
import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:vyaparlive/components/layout_template.dart';
import 'package:vyaparlive/redux/app_reducer.dart';
import 'package:vyaparlive/redux/state/app_state.dart';
import 'package:vyaparlive/router/router.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:vyaparlive/core/locator.dart';
import 'package:vyaparlive/splash_view/SplashView.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:redux/redux.dart';

import 'firebase_options.dart';

class MyHttpOverrides extends HttpOverrides {
  @override
  HttpClient createHttpClient(SecurityContext? context) {
    return super.createHttpClient(context)
      ..badCertificateCallback =
          (X509Certificate cert, String host, int port) => true;
  }
}

Future<RemoteMessage> _handleMessage(RemoteMessage message) async {
  return message; // Return the message as a Future
}

void main() async {
  await dotenv.load(fileName: "assets/config.env");
  WidgetsFlutterBinding.ensureInitialized();
  HttpOverrides.global = new MyHttpOverrides();
  if (!kIsWeb && !Platform.isWindows) {
    // await Firebase.initializeApp();

    await Firebase.initializeApp(
      name: "vyaparlive",
      options: DefaultFirebaseOptions.currentPlatform,
    );

    FlutterError.onError = FirebaseCrashlytics.instance.recordFlutterError;

    FirebaseAnalytics analytics = FirebaseAnalytics.instance;
    analytics.logEvent(name: 'Initialized App');
  }
  FirebaseMessaging.onBackgroundMessage(_handleMessage);
  setUpLocator();

  final store =
      Store<AppState>(appReducer, initialState: AppState(mapData: null));
  runApp(MyApp(
    store: store,
  ));
}

class MyApp extends StatelessWidget {
  final Store<AppState> store;

  MyApp({Key? key, required this.store}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();
    if (kIsWeb) {
      return StoreProvider(
          store: store,
          child: MaterialApp(
            debugShowCheckedModeBanner: false,
            theme: ThemeData(
              fontFamily: 'Montserrat',
              useMaterial3: false,
              primarySwatch: Colors.blue,
            ),
            builder: (context, child) => MediaQuery(
              data: MediaQuery.of(context)
                  .copyWith(textScaler: TextScaler.linear(1.0)),
              child: LayoutTemplate(
                child: child,
              ),
            ),
            navigatorKey: navigatorKey,
            onGenerateRoute: generateRoute,
            initialRoute: '/',
          ));
    } else {
      return StoreProvider<AppState>(
          store: store,
          child: MaterialApp(
              debugShowCheckedModeBanner: false,
              theme: ThemeData(
                fontFamily: 'Montserrat',
                useMaterial3: false,
                primarySwatch: Colors.blue,
                colorScheme: ColorScheme.light(
                  primary: Colors.blue,
                ),
              ),
              builder: (context, child) {
                return MediaQuery(
                  data: MediaQuery.of(context)
                      .copyWith(textScaler: TextScaler.linear(1.0)),
                  child: child!,
                );
              },
              home: SplashPage()));
    }
  }
}


// import 'dart:async';
// import 'dart:io';
// import 'package:flutter/services.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_esc_pos_utils/flutter_esc_pos_utils.dart';
// import 'package:print_bluetooth_thermal/post_code.dart';
// import 'package:print_bluetooth_thermal/print_bluetooth_thermal.dart';
// import 'package:image/image.dart' as img;
// import 'package:print_bluetooth_thermal/print_bluetooth_thermal_windows.dart';

// void main() {
//   runApp(const MyApp());
// }

// class MyApp extends StatefulWidget {
//   const MyApp({super.key});

//   @override
//   MyAppState createState() => MyAppState();
// }

// class MyAppState extends State<MyApp> {
//   String _info = "";
//   String _msj = '';
//   bool connected = false;
//   List<BluetoothInfo> items = [];
//   final List<String> _options = ["permission bluetooth granted", "bluetooth enabled", "connection status", "update info"];

//   String _selectSize = "2";
//   final _txtText = TextEditingController(text: "Hello developer");
//   bool _progress = false;
//   String _msjprogress = "";

//   String optionprinttype = "58 mm";
//   List<String> options = ["58 mm", "80 mm"];

//   @override
//   void initState() {
//     super.initState();
//     initPlatformState();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       home: Scaffold(
//         appBar: AppBar(
//           title: const Text('Plugin example app'),
//           actions: [
//             PopupMenuButton(
//               elevation: 3.2,
//               //initialValue: _options[1],
//               onCanceled: () {
//                 debugPrint('You have not chossed anything');
//               },
//               tooltip: 'Menu',
//               onSelected: (Object select) async {
//                 String sel = select as String;
//                 if (sel == "permission bluetooth granted") {
//                   bool status = await PrintBluetoothThermal.isPermissionBluetoothGranted;
//                   setState(() {
//                     _info = "permission bluetooth granted: $status";
//                   });
//                   //open setting permision if not granted permision
//                 } else if (sel == "bluetooth enabled") {
//                   bool state = await PrintBluetoothThermal.bluetoothEnabled;
//                   setState(() {
//                     _info = "Bluetooth enabled: $state";
//                   });
//                 } else if (sel == "update info") {
//                   initPlatformState();
//                 } else if (sel == "connection status") {
//                   final bool result = await PrintBluetoothThermal.connectionStatus;
//                   connected = result;
//                   setState(() {
//                     _info = "connection status: $result";
//                   });
//                 }
//               },
//               itemBuilder: (BuildContext context) {
//                 return _options.map((String option) {
//                   return PopupMenuItem(
//                     value: option,
//                     child: Text(option),
//                   );
//                 }).toList();
//               },
//             )
//           ],
//         ),
//         body: SingleChildScrollView(
//           scrollDirection: Axis.vertical,
//           child: Container(
//             padding: const EdgeInsets.all(20),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               spacing: 3,
//               children: [
//                 Text('info: $_info\n '),
//                 Text(_msj),
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                   children: [
//                     const Text("Type print"),
//                     const SizedBox(width: 10),
//                     DropdownButton<String>(
//                       value: optionprinttype,
//                       items: options.map((String option) {
//                         return DropdownMenuItem<String>(
//                           value: option,
//                           child: Text(option),
//                         );
//                       }).toList(),
//                       onChanged: (String? newValue) {
//                         setState(() {
//                           optionprinttype = newValue!;
//                         });
//                       },
//                     ),
//                   ],
//                 ),
//                 SingleChildScrollView(
//                   scrollDirection: Axis.horizontal,
//                   child: Row(
//                     spacing: 5,
//                     children: [
//                       ElevatedButton(
//                         onPressed: () {
//                           getBluetoots();
//                         },
//                         child: Row(
//                           children: [
//                             Visibility(
//                               visible: _progress,
//                               child: const SizedBox(
//                                 width: 25,
//                                 height: 25,
//                                 child: CircularProgressIndicator.adaptive(strokeWidth: 1, backgroundColor: Colors.blue),
//                               ),
//                             ),
//                             const SizedBox(width: 5),
//                             Text(_progress ? _msjprogress : "Search"),
//                           ],
//                         ),
//                       ),
//                       ElevatedButton(
//                         onPressed: connected ? disconnect : null,
//                         child: const Text("Disconnect"),
//                       ),
//                       ElevatedButton(
//                         onPressed: connected ? printTest : null,
//                         child: const Text("Test"),
//                       ),
//                     ],
//                   ),
//                 ),
//                 Container(
//                     height: 200,
//                     decoration: BoxDecoration(
//                       borderRadius: const BorderRadius.all(Radius.circular(10)),
//                       color: Colors.grey.withAlpha(50),
//                     ),
//                     child: ListView.builder(
//                       itemCount: items.isNotEmpty ? items.length : 0,
//                       itemBuilder: (context, index) {
//                         return ListTile(
//                           onTap: () {
//                             String mac = items[index].macAdress;
//                             connect(mac);
//                           },
//                           title: Text('Name: ${items[index].name}'),
//                           subtitle: Text("macAddress: ${items[index].macAdress}"),
//                         );
//                       },
//                     )),
//                 const SizedBox(height: 10),
//                 Container(
//                   padding: const EdgeInsets.all(10),
//                   decoration: BoxDecoration(
//                     borderRadius: const BorderRadius.all(Radius.circular(10)),
//                     color: Colors.grey.withAlpha(50),
//                   ),
//                   child: Column(children: [
//                     const Text("Text size without the library without external packets, print images still it should not use a library"),
//                     const SizedBox(height: 10),
//                     Row(
//                       children: [
//                         Expanded(
//                           child: TextField(
//                             controller: _txtText,
//                             decoration: const InputDecoration(
//                               border: OutlineInputBorder(),
//                               labelText: "Text",
//                             ),
//                           ),
//                         ),
//                         const SizedBox(width: 5),
//                         DropdownButton<String>(
//                           hint: const Text('Size'),
//                           value: _selectSize,
//                           items: <String>['1', '2', '3', '4', '5'].map((String value) {
//                             return DropdownMenuItem<String>(
//                               value: value,
//                               child: Text(value),
//                             );
//                           }).toList(),
//                           onChanged: (String? select) {
//                             setState(() {
//                               _selectSize = select.toString();
//                             });
//                           },
//                         )
//                       ],
//                     ),
//                     ElevatedButton(
//                       onPressed: connected ? printWithoutPackage : null,
//                       child: const Text("Print"),
//                     ),
//                   ]),
//                 ),
//                 const SizedBox(height: 10),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }

//   Future<void> initPlatformState() async {
//     String platformVersion;
//     int porcentbatery = 0;
//     // Platform messages may fail, so we use a try/catch PlatformException.
//     try {
//       platformVersion = await PrintBluetoothThermal.platformVersion;
//       //debugPrint("patformversion: $platformVersion");
//       porcentbatery = await PrintBluetoothThermal.batteryLevel;
//     } on PlatformException {
//       platformVersion = 'Failed to get platform version.';
//     }

//     // If the widget was removed from the tree while the asynchronous platform
//     // message was in flight, we want to discard the reply rather than calling
//     // setState to update our non-existent appearance.
//     if (!mounted) return;

//     final bool result = await PrintBluetoothThermal.bluetoothEnabled;
//     debugPrint("bluetooth enabled: $result");
//     if (result) {
//       _msj = "Bluetooth enabled, please search and connect";
//     } else {
//       _msj = "Bluetooth not enabled";
//     }

//     setState(() {
//       _info = "$platformVersion ($porcentbatery% battery)";
//     });
//   }

//   Future<void> getBluetoots() async {
//     setState(() {
//       _progress = true;
//       _msjprogress = "Wait";
//       items = [];
//     });
//     final List<BluetoothInfo> listResult = await PrintBluetoothThermal.pairedBluetooths;

//     /*await Future.forEach(listResult, (BluetoothInfo bluetooth) {
//       String name = bluetooth.name;
//       String mac = bluetooth.macAdress;
//     });*/

//     setState(() {
//       _progress = false;
//     });

//     if (listResult.isEmpty) {
//       _msj = "There are no bluetoohs linked, go to settings and link the printer";
//     } else {
//       _msj = "Touch an item in the list to connect";
//     }

//     setState(() {
//       items = listResult;
//     });
//   }

//   Future<void> connect(String mac) async {
//     setState(() {
//       _progress = true;
//       _msjprogress = "Connecting...";
//       connected = false;
//     });
//     final bool result = await PrintBluetoothThermal.connect(macPrinterAddress: mac);
//     debugPrint("state conected $result");
//     if (result) connected = true;
//     setState(() {
//       _progress = false;
//     });
//   }

//   Future<void> disconnect() async {
//     final bool status = await PrintBluetoothThermal.disconnect;
//     setState(() {
//       connected = false;
//     });
//     debugPrint("status disconnect $status");
//   }

//   Future<void> printTest() async {
//     /*if (kDebugMode) {
//       bool result = await PrintBluetoothThermalWindows.writeBytes(bytes: "Hello \n".codeUnits);
//       return;
//     }*/

//     bool conexionStatus = await PrintBluetoothThermal.connectionStatus;
//     //debugPrint("connection status: $conexionStatus");
//     if (conexionStatus) {
//       bool result = false;
//       if (Platform.isWindows) {
//         List<int> ticket = await testWindows();
//         result = await PrintBluetoothThermalWindows.writeBytes(bytes: ticket);
//       } else {
//         List<int> ticket = await testTicket();
//         result = await PrintBluetoothThermal.writeBytes(ticket);
//       }
//       debugPrint("print test result:  $result");
//     } else {
//       debugPrint("print test conexionStatus: $conexionStatus");
//       setState(() {
//         disconnect();
//       });
//       //throw Exception("Not device connected");
//     }
//   }

//   Future<void> printString() async {
//     bool conexionStatus = await PrintBluetoothThermal.connectionStatus;
//     if (conexionStatus) {
//       String enter = '\n';
//       await PrintBluetoothThermal.writeBytes(enter.codeUnits);
//       //size of 1-5
//       String text = "Hello";
//       await PrintBluetoothThermal.writeString(printText: PrintTextSize(size: 1, text: text));
//       await PrintBluetoothThermal.writeString(printText: PrintTextSize(size: 2, text: "$text size 2"));
//       await PrintBluetoothThermal.writeString(printText: PrintTextSize(size: 3, text: "$text size 3"));
//     } else {
//       //desconectado
//       debugPrint("desconectado bluetooth $conexionStatus");
//     }
//   }

//   Future<List<int>> testTicket() async {
//     List<int> bytes = [];
//     // Using default profile
//     final profile = await CapabilityProfile.load();
//     final generator = Generator(optionprinttype == "58 mm" ? PaperSize.mm58 : PaperSize.mm80, profile);
//     //bytes += generator.setGlobalFont(PosFontType.fontA);
//     bytes += generator.reset();

//     final ByteData data = await rootBundle.load('assets/mylogo.jpg');
//     final Uint8List bytesImg = data.buffer.asUint8List();
//     img.Image? image = img.decodeImage(bytesImg);

//     if (Platform.isIOS) {
//       // Resizes the image to half its original size and reduces the quality to 80%
//       final resizedImage = img.copyResize(image!, width: image.width ~/ 1.3, height: image.height ~/ 1.3, interpolation: img.Interpolation.nearest);
//       final bytesimg = Uint8List.fromList(img.encodeJpg(resizedImage));
//       //image = img.decodeImage(bytesimg);
//     }

//     //Using `ESC *`
//     //bytes += generator.image(image!);

//     bytes += generator.text('Regular: aA bB cC dD eE fF gG hH iI jJ kK lL mM nN oO pP qQ rR sS tT uU vV wW xX yY zZ');
//     bytes += generator.text('Special 1: ñÑ àÀ èÈ éÉ üÜ çÇ ôÔ', styles: const PosStyles(codeTable: 'CP1252'));
//     bytes += generator.text('Special 2: blåbærgrød', styles: const PosStyles(codeTable: 'CP1252'));

//     bytes += generator.text('Bold text', styles: const PosStyles(bold: true));
//     bytes += generator.text('Reverse text', styles: const PosStyles(reverse: true));
//     bytes += generator.text('Underlined text', styles: const PosStyles(underline: true), linesAfter: 1);
//     bytes += generator.text('Align left', styles: const PosStyles(align: PosAlign.left));
//     bytes += generator.text('Align center', styles: const PosStyles(align: PosAlign.center));
//     bytes += generator.text('Align right', styles: const PosStyles(align: PosAlign.right), linesAfter: 1);

//     bytes += generator.row([
//       PosColumn(
//         text: 'col3',
//         width: 3,
//         styles: const PosStyles(align: PosAlign.center, underline: true),
//       ),
//       PosColumn(
//         text: 'col6',
//         width: 6,
//         styles: const PosStyles(align: PosAlign.center, underline: true),
//       ),
//       PosColumn(
//         text: 'col3',
//         width: 3,
//         styles: const PosStyles(align: PosAlign.center, underline: true),
//       ),
//     ]);

//     //barcode

//     final List<int> barData = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 4];
//     bytes += generator.barcode(Barcode.upcA(barData));

//     //QR code
//     bytes += generator.qrcode('example.com');

//     bytes += generator.text(
//       'Text size 50%',
//       styles: const PosStyles(
//         fontType: PosFontType.fontB,
//       ),
//     );
//     bytes += generator.text(
//       'Text size 100%',
//       styles: const PosStyles(
//         fontType: PosFontType.fontA,
//       ),
//     );
//     bytes += generator.text(
//       'Text size 200%',
//       styles: const PosStyles(
//         height: PosTextSize.size2,
//         width: PosTextSize.size2,
//       ),
//     );

//     bytes += generator.feed(2);
//     //bytes += generator.cut();
//     return bytes;
//   }

//   Future<List<int>> testWindows() async {
//     List<int> bytes = [];

//     bytes += PostCode.text(text: "Size compressed", fontSize: FontSize.compressed);
//     bytes += PostCode.text(text: "Size normal", fontSize: FontSize.normal);
//     bytes += PostCode.text(text: "Bold", bold: true);
//     bytes += PostCode.text(text: "Inverse", inverse: true);
//     bytes += PostCode.text(text: "AlignPos right", align: AlignPos.right);
//     bytes += PostCode.text(text: "Size big", fontSize: FontSize.big);
//     bytes += PostCode.enter();

//     //List of rows
//     bytes += PostCode.row(texts: ["PRODUCT", "VALUE"], proportions: [60, 40], fontSize: FontSize.compressed);
//     for (int i = 0; i < 3; i++) {
//       bytes += PostCode.row(texts: ["Item $i", "$i,00"], proportions: [60, 40], fontSize: FontSize.compressed);
//     }

//     bytes += PostCode.line();

//     bytes += PostCode.barcode(barcodeData: "123456789");
//     bytes += PostCode.qr("123456789");

//     bytes += PostCode.enter(nEnter: 5);

//     return bytes;
//   }

//   Future<void> printWithoutPackage() async {
//     //impresion sin paquete solo de PrintBluetoothTermal
//     bool connectionStatus = await PrintBluetoothThermal.connectionStatus;
//     if (connectionStatus) {
//       String text = "${_txtText.text}\n";
//       bool result = await PrintBluetoothThermal.writeString(printText: PrintTextSize(size: int.parse(_selectSize), text: text));
//       debugPrint("status print result: $result");
//       setState(() {
//         _msj = "printed status: $result";
//       });
//     } else {
//       //no conectado, reconecte
//       setState(() {
//         _msj = "no connected device";
//       });
//       debugPrint("no conectado");
//     }
//   }
// }