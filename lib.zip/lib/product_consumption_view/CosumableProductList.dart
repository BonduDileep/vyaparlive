import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/MyDrawer.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/ProductConsumptionDAO.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:vyaparlive/product_consumption_view/ConsumableProductCardView.dart';
import 'package:vyaparlive/product_consumption_view/ConsumableProductsPage.dart';
import 'package:vyaparlive/product_consumption_view/ConsumpleProductDetails.dart';
import 'package:vyaparlive/service/consumable_product_grpc.dart';

class ConsumableProductList extends StatefulWidget {
  @override
  _ConsumableProductListState createState() => _ConsumableProductListState();
}

class _ConsumableProductListState extends State<ConsumableProductList> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? buId = "";
  String? buName = "";
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  List<ProductConsumptionDAO> _productsList = [];
  bool isLoadingProgress = true;
  String progressMessage = Constants.GETTING_DATA;
  late ConsumableGrpcService _consumableGrpcService;
  List<num> batchQuantityList = [];
  num totalBatchQuantity = 0;
  TextEditingController _searchController = TextEditingController();
  List<Map> _mapData = [];

  @override
  void initState() {
    super.initState();
    _consumableGrpcService = ConsumableGrpcService();
    buId = AppController.instance.getMyBuId;
    buName = AppController.instance.getBuName;
    this.getLoadLanguage();
    this.loadProductsData();
  }

  loadProductsData({String name = ""}) async {
    if (await NetworkStatus.getInternetStatus()) {
      this.getProductList(name: name).then((value) {
        setState(() {
          _productsList.clear();
          batchQuantityList.clear();
          _productsList.addAll(value);
          for (int i = 0; i < _productsList.length; i++) {
            if (_productsList[i].batchPrice!.length > 0) {
              totalBatchQuantity = 0;
              for (int j = 0; j < _productsList[i].batchPrice!.length; j++) {
                totalBatchQuantity = totalBatchQuantity +
                    _productsList[i].batchPrice![j].quantity!;
              }
              batchQuantityList.add(totalBatchQuantity);
            } else {
              batchQuantityList.add(0);
            }
          }
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  getLoadLanguage() {
    _mapData = [
      {'name': Language().getString(Constants.PRICE, selectedLang)},
      {'name': Language().getString(Constants.QUANTITY, selectedLang)},
      {'name': Language().getString(Constants.EDIT, selectedLang)},
      {'name': Language().getString(Constants.DETAILS, selectedLang)},
    ];
  }

  Future<List<ProductConsumptionDAO>> getProductList({String name = ""}) async {
    setState(() {
      _productsList.clear();
      batchQuantityList.clear();
    });
    String body = json.encode({
      "bu_id": buId,
      "filters": {"name": name}
    });

    var response = await _consumableGrpcService
        .getProductListByBuId(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    setState(() {
      isLoadingProgress = false;
    });
    List<ProductConsumptionDAO> list = [];
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(data)) {
        for (var object in data['results']) {
          list.add(ProductConsumptionDAO.fromJson(object));
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return list;
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        child: Stack(
          children: [
            SafeArea(
              child: Scaffold(
                  key: _scaffoldkey,
                  backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                  appBar: AppBar(
                    centerTitle: true,
                    title: Column(children: <Widget>[
                      Text(
                          Language().getString(
                              Constants.CONSUMABLE_PRODUCT_LIST, selectedLang),
                          style: TextStyle(fontSize: 15.0)),
                      Text(
                        AppController.instance.getBuName,
                        style: TextStyle(fontSize: 13.0),
                      )
                    ]),
                    backgroundColor: Color(0xFF083e64),
                    actions: [
                      TextButton(
                          onPressed: () {
                            Navigator.push(
                                context,
                                PageTransition(
                                    context: context,
                                    page: ConsumableProductPage(
                                      title: Constants.CREATE_CONSUMABLE_PRODUCTS,
                                    ))).then((value) => loadProductsData());
                          },
                          child: Icon(Icons.add, color: Colors.white))
                    ],
                  ),
                  drawer: MyDrawer(),
                  body: Container(
                    margin: EdgeInsets.symmetric(vertical: 5.0, horizontal: 5.0),
                    child: Column(
                      children: [
                        this.buildSearchBarView(),
                        (_productsList.length > 0 && _mapData.length > 0)
                            ? Expanded(
                                child: ListView.separated(
                                    itemBuilder: (context, index) {
                                      return ConsumableProductCardPage(
                                          productData: _productsList[index],
                                          batchQuantity: batchQuantityList[index],
                                          onEdit: () {
                                            Navigator.push(
                                                context,
                                                PageTransition(
                                                    context: context,
                                                    page: ConsumableProductPage(
                                                      title: Language().getString(
                                                          Constants
                                                              .UPDATE_CONSUMABLE_PRODUCTS,
                                                          selectedLang),
                                                      productId:
                                                          _productsList[index].id,
                                                    ))).then((value) =>
                                                this.loadProductsData());
                                          },
                                          onDetails: () {
                                            Navigator.push(
                                                context,
                                                PageTransition(
                                                    context: context,
                                                    page:
                                                        ConsumableProductDetails(
                                                      productId:
                                                          _productsList[index].id,
                                                    )));
                                          },
                                          mapData: _mapData);
                                    },
                                    separatorBuilder: (context, index) => Divider(
                                          color: Colors.transparent,
                                          height: 5.0,
                                        ),
                                    itemCount: _productsList.length))
                            : Container(
                                child: Text(Language().getString(
                                    Constants.NO_DATA_FOUND, selectedLang))),
                      ],
                    ),
                  )),
            ),
            AppUtills.showLoadingView(
                context: context,
                message: Language().getString(progressMessage, selectedLang),
                isLoading: isLoadingProgress),
          ],
        ),
        onWillPop: () {
          return CommonMethods.onBackPress(context).then((value) => value);
        });
  }

  Widget buildSearchBarView() {
    return Container(
      height: 40.0,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(5.0),
        border: Border.all(
          color: Colors.grey,
        ),
      ),
      child: Row(
        children: <Widget>[
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(5.0),
                  bottomLeft: Radius.circular(5.0),
                ),
                color: Colors.white,
              ),
              padding: EdgeInsets.only(left: 5),
              child: TextFormField(
                controller: _searchController,
                onChanged: onSearchTextChanged,
                style: TextStyle(fontFamily: 'IndianRupee'),
                decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: Language()
                        .getString(Constants.SEARCH_BY_NAME, selectedLang),
                    hintStyle: TextStyle(
                        fontSize: 13.0, fontFamily: StyleView.FONT_TITLE)),
              ),
            ),
          ),
          (_searchController.text.length > 0)
              ? Container(
                  color: Colors.white,
                  child: IconButton(
                      icon: Icon(
                        Icons.close,
                        color: Colors.red,
                        size: 20.0,
                      ),
                      onPressed: () {
                        CommonMethods.hideKeyboard(context);
                        _searchController.clear();
                        onSearchTextChanged(_searchController.text);
                      }),
                )
              : Container(),
        ],
      ),
    );
  }

  onSearchTextChanged(String text) async {
    if (text.isEmpty) {
      isLoadingProgress = true;
      this.loadProductsData();
    } else {
      isLoadingProgress = false;
      this.loadProductsData(name: text);
    }
  }
}
