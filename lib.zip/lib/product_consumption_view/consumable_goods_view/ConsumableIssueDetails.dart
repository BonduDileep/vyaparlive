import 'dart:convert';

import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/CustomRowWidget.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/RawProductsIssueDAO.dart';
import 'package:vyaparlive/model/TransactionsModel.dart';
import 'package:vyaparlive/service/product_services.dart';

class ConsumableProductIssueDetailsPage extends StatefulWidget {
  final String? recordId;

  ConsumableProductIssueDetailsPage({this.recordId});
  @override
  _ConsumableProductIssueDetailsPageState createState() =>
      _ConsumableProductIssueDetailsPageState();
}

class _ConsumableProductIssueDetailsPageState
    extends State<ConsumableProductIssueDetailsPage> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? buId = "";
  String? buName = "";
  String selectedLang = AppController.instance.getSelectedlanguage;
  SharedPreferences? sharedPreferences;
  bool isLoadingProgress = true;
  String progressMessage = Constants.GETTING_DATA;
  String showLoaderText = Constants.NO_DATA_FOUND;
  List<RawProductsIssueDAO> _rawIssuesList = [];
  late ProductService _productService;
  ScrollController? _scrollController;
  ScrollController? _finalProductsScrollController;
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _scrollController = new ScrollController();
    _finalProductsScrollController = new ScrollController();
    _productService = ProductService();
    buId = AppController.instance.getMyBuId;
    buName = AppController.instance.getBuName;

    this.loadServiceCallGetData();
  }

  loadServiceCallGetData() async {
    this.getRawIssuesDataById(widget.recordId).then((value) {
      setState(() {
        _rawIssuesList.clear();
        _rawIssuesList.addAll(value);
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
        body: Stack(
      children: [
        SafeArea(
          child: Scaffold(
              key: _scaffoldkey,
              backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
              appBar: AppBar(
                  backgroundColor: Colors.transparent, //(Constants.APP_COLOR),
                  centerTitle: true,
                  elevation: 0,
                  iconTheme: IconThemeData(color: theme.colorScheme.primary),
                  title: AppbarName(
                      title: Language()
                          .getString(Constants.RAW_ISSUE_DETAILS, selectedLang),
                      buName: "$buName")),
              body: Container(
                margin: EdgeInsets.symmetric(vertical: 5.0, horizontal: 5.0),
                child: (_rawIssuesList.length > 0)
                    ? Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          (_rawIssuesList.length > 0)
                              ? Container(
                                  margin: EdgeInsets.symmetric(vertical: 10.0),
                                  child: this.showIssueDetails())
                              : Container(),
                          Text(
                              Language().getString(
                                  Constants.RAW_MATERIALS, selectedLang),
                              style: TextStyle(
                                  color: Color(Constants.APP_COLOR),
                                  fontSize: 15.0,
                                  fontWeight: FontWeight.bold)),
                          Expanded(
                              child: Scrollbar(
                            thumbVisibility: true,
                            thickness: 7.0,
                            controller: _scrollController,
                            child: ListView.separated(
                                controller: _scrollController,
                                shrinkWrap: true,
                                physics: BouncingScrollPhysics(
                                    parent: AlwaysScrollableScrollPhysics()),
                                itemBuilder: (context, index) {
                                  return this.showRawProductDetails(
                                      _rawIssuesList[0].productist![index]);
                                },
                                separatorBuilder: (context, index) => Divider(
                                    color: Colors.transparent, height: 0.0),
                                itemCount: _rawIssuesList[0].productist!.length),
                          )),
                          if (_rawIssuesList[0].finalProductsList!.length > 0)
                            Container(
                                margin: EdgeInsets.symmetric(vertical: 5.0),
                                child: Text(
                                    Language().getString(
                                        Constants.FINAL_PRODUCT, selectedLang),
                                    style: TextStyle(
                                        color: Color(Constants.APP_COLOR),
                                        fontSize: 15.0,
                                        fontWeight: FontWeight.bold))),
                          Expanded(
                            child:
                                this.showFinalProductDetails(_rawIssuesList[0]),
                          )
                        ],
                      )
                    : Container(
                        child: Center(
                        child: Text(
                            Language().getString(showLoaderText, selectedLang)),
                      )),
              )),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    ));
  }

  Future<List<RawProductsIssueDAO>> getRawIssuesDataById(String? id) async {
    setState(() {
      _rawIssuesList.clear();
    });
    String body = json.encode({"id": id, "bu_id": buId});

    var response = await _productService
        .findIssueDataByIssueId(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<RawProductsIssueDAO> list = [];
    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(resObj)) {
        list.add(RawProductsIssueDAO.fromJson(resObj[0]));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return list;
  }

  Widget showFinalProductDetails(RawProductsIssueDAO modelData) {
    if (modelData.finalProductsList!.length > 0) {
      return Scrollbar(
          controller: _finalProductsScrollController,
          thumbVisibility: true,
          thickness: 7.0,
          child: ListView.builder(
              controller: _finalProductsScrollController,
              physics: BouncingScrollPhysics(
                  parent: AlwaysScrollableScrollPhysics()),
              shrinkWrap: true,
              itemBuilder: (context, index) => Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Card(
                        elevation: 5.0,
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Column(
                            children: [
                              Container(
                                margin: EdgeInsets.symmetric(
                                  vertical: 5.0,
                                ),
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: Container(
                                        child: Text(
                                          Language().getString(
                                              Constants.ADDED_BY, selectedLang),
                                          style: TextStyle(
                                              color: Color(Constants.APP_COLOR),
                                              fontSize: 15.0,
                                              fontWeight: FontWeight.w500),
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      flex: 2,
                                      child: Container(
                                        child: Text(
                                          " : ${modelData.finalProductsList![index].addedByUser}",
                                          style: TextStyle(
                                              fontSize: 14.0,
                                              fontWeight: FontWeight.w500),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.symmetric(
                                  vertical: 5.0,
                                ),
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: Container(
                                        child: Text(
                                          Language().getString(
                                              Constants.PRODUCT_NAME,
                                              selectedLang),
                                          style: TextStyle(
                                              color: Color(Constants.APP_COLOR),
                                              fontSize: 15.0,
                                              fontWeight: FontWeight.w500),
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      flex: 2,
                                      child: Container(
                                        child: Text(
                                          " : ${modelData.finalProductsList![index].productName}",
                                          style: TextStyle(
                                              fontSize: 14.0,
                                              fontWeight: FontWeight.w500),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.symmetric(
                                  vertical: 5.0,
                                ),
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: Container(
                                        child: Text(
                                          Language().getString(
                                              Constants.QUANTITY, selectedLang),
                                          style: TextStyle(
                                              color: Color(Constants.APP_COLOR),
                                              fontSize: 15.0,
                                              fontWeight: FontWeight.w500),
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      flex: 2,
                                      child: Container(
                                        child: Text(
                                          " : ${modelData.finalProductsList![index].quantity} ${modelData.finalProductsList![index].quantityIn}",
                                          style: TextStyle(
                                              fontSize: 14.0,
                                              fontWeight: FontWeight.w500),
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.symmetric(
                                  vertical: 5.0,
                                ),
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: Container(
                                        child: Text(
                                          Language().getString(
                                              Constants.BATCH_NO, selectedLang),
                                          style: TextStyle(
                                              color: Color(Constants.APP_COLOR),
                                              fontSize: 15.0,
                                              fontWeight: FontWeight.w500),
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      flex: 2,
                                      child: Container(
                                        child: Text(
                                          " : ${modelData.finalProductsList![index].batchNumber}",
                                          style: TextStyle(
                                              fontSize: 14.0,
                                              fontWeight: FontWeight.w500),
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.symmetric(
                                  vertical: 5.0,
                                ),
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: Container(
                                        child: Text(
                                          Language().getString(
                                              Constants.DATE, selectedLang),
                                          style: TextStyle(
                                              color: Color(Constants.APP_COLOR),
                                              fontSize: 15.0,
                                              fontWeight: FontWeight.w500),
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      flex: 2,
                                      child: Container(
                                        child: (modelData
                                                    .finalProductsList![index]
                                                    .createdDate !=
                                                null)
                                            ? Text(
                                                " : " +
                                                    AppUtills.getDateFormate(
                                                      modelData
                                                          .finalProductsList![
                                                              index]
                                                          .createdDate
                                                          .toString(),
                                                    ),
                                                style: TextStyle(
                                                    fontSize: 14.0,
                                                    fontWeight:
                                                        FontWeight.w500),
                                              )
                                            : Text(""),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      )
                    ],
                  ),
              itemCount: modelData.finalProductsList!.length));
    } else {
      return Container();
    }
  }

  Widget showRawProductDetails(Product modelData) {
    return Container(
      child: Card(
        elevation: 5.0,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                margin: EdgeInsets.symmetric(
                  vertical: 3.0,
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Container(
                        child: Text(
                          Language()
                              .getString(Constants.PRODUCT_NAME, selectedLang),
                          style: TextStyle(
                              color: Color(Constants.APP_COLOR),
                              fontSize: 15.0,
                              fontWeight: FontWeight.w500),
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Container(
                        child: Text(
                          " : ${modelData.productName}",
                          style: TextStyle(
                              fontSize: 14.0, fontWeight: FontWeight.w500),
                        ),
                      ),
                    )
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.symmetric(
                  vertical: 3.0,
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Container(
                        child: Text(
                          Language()
                              .getString(Constants.QUANTITY, selectedLang),
                          style: TextStyle(
                              color: Color(Constants.APP_COLOR),
                              fontSize: 15.0,
                              fontWeight: FontWeight.w500),
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Container(
                        child: Text(
                          " : ${modelData.quantity} ${modelData.quantityIn}",
                          style: TextStyle(
                              fontSize: 14.0, fontWeight: FontWeight.w500),
                        ),
                      ),
                    )
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.symmetric(
                  vertical: 3.0,
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Container(
                        child: Text(
                          Language().getString(Constants.PURPOSE, selectedLang),
                          style: TextStyle(
                              color: Color(Constants.APP_COLOR),
                              fontSize: 15.0,
                              fontWeight: FontWeight.w500),
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Container(
                        child: Text(
                          " : ${_rawIssuesList[0].issuedPurpose}",
                          style: TextStyle(
                              fontSize: 14.0, fontWeight: FontWeight.w500),
                        ),
                      ),
                    )
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.symmetric(
                  vertical: 3.0,
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Container(
                        child: Text(
                          Language().getString(Constants.DATE, selectedLang),
                          style: TextStyle(
                              color: Color(Constants.APP_COLOR),
                              fontSize: 15.0,
                              fontWeight: FontWeight.w500),
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Container(
                        child: Text(
                          " : " +
                              AppUtills.getDateFormate(
                                  _rawIssuesList[0].createdDate.toString()),
                          style: TextStyle(
                              fontSize: 14.0, fontWeight: FontWeight.w500),
                        ),
                      ),
                    )
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget showIssueDetails() {
    return Container(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomRowWidget(
              title: Language().getString(Constants.ISSUED_TO, selectedLang),
              value: _rawIssuesList[0].issuedTo?.userName ?? ""),
          CustomRowWidget(
              title: Language().getString(Constants.ISSUANCE_ID, selectedLang),
              value: "${_rawIssuesList[0].issueNumber}")
        ],
      ),
    );
  }
}
