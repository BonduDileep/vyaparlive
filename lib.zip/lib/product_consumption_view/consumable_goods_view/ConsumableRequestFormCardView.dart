import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/model/RawRequestFormDAO.dart';

class ConsumableRequestFormCardView extends StatelessWidget {
  final RawRequestFormDAO? modelData;
  final List<Map> mapData;
  ConsumableRequestFormCardView({this.modelData, required this.mapData});

  @override
  Widget build(BuildContext context) {
    return Card(
        elevation: 5,
        shadowColor: AppTheme.vyaparTheme.colorScheme.primary,
        shape: new RoundedRectangleBorder(
            borderRadius: new BorderRadius.circular(5),
            side: new BorderSide(
                color: AppTheme.vyaparTheme.colorScheme.primaryContainer,
                strokeAlign: 1)),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              this.cardItems(mapData[0]['name'], "${modelData!.requestNumber}"),
              this.cardItems(
                  mapData[1]['name'],
                  modelData!.requestedBy != null
                      ? modelData!.requestedBy!.userName
                      : ""),
              this.cardItems(mapData[3]['name'], modelData!.purpose),
              this.cardItems(mapData[5]['name'], modelData!.department),
              this.cardItems(mapData[6]['name'], modelData!.batchNumber),
              this.cardItems(
                  mapData[4]['name'], requestFormStatus(modelData!.status)),
              this.cardItems(mapData[2]['name'],
                  AppUtills.getDateFormate(modelData!.createdDate.toString())),
            ],
          ),
        ));
  }

  cardItems(String? title, String? value) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 3.0),
      child: Row(
        children: [
          Expanded(
            child: Text(
              "$title",
              style: TextStyle(
                  color: Colors.black,
                  fontSize: 15.0,
                  fontWeight: StyleView.fontSemiBold),
            ),
          ),
          Expanded(
              flex: 2,
              child: Row(
                children: [
                  Container(
                    child: Text(":  "),
                  ),
                  Expanded(
                    child: Container(
                      child: Text(
                        "$value",
                        style: TextStyle(
                            fontSize: 13.0,
                            color: Colors.black,
                            fontWeight: StyleView.fontMedium),
                      ),
                    ),
                  ),
                ],
              ))
        ],
      ),
    );
  }

  String requestFormStatus(num? statusCode) {
    if (statusCode == 1) {
      return "accepted";
    } else if (statusCode == 2) {
      return "rejected";
    } else {
      return "pending";
    }
  }
}
