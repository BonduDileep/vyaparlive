import 'dart:convert';

import 'package:vyaparlive/product_consumption_view/consumable_goods_view/EditConsumableRequestPage.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:flutx/flutx.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/DateFilterUtil.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/RawRequestFormDAO.dart';
import 'package:vyaparlive/product_consumption_view/raw_material_view/RawRequestFormCardView.dart';
import 'package:vyaparlive/service/product_services.dart';

import '../../core/enums/privilleges_enum.dart';

class ConsumableRequetsPage extends StatefulWidget {
  @override
  _ConsumableRequetsPageState createState() => _ConsumableRequetsPageState();
}

class _ConsumableRequetsPageState extends State<ConsumableRequetsPage> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? buId = "";
  String? buName = "";
  late ProductService _productService;
  final _searchController = TextEditingController();
  String selectedLang = AppController.instance.getSelectedlanguage;
  SharedPreferences? sharedPreferences;
  bool isEnableDateFilter = false;
  bool isShowFloatButton = false;
  String startDate = "";
  String endDate = "";
  DateFormat formatter = DateFormat("yyyy-MM-dd");
  DateTime mnthStartDate =
      DateTime.utc(DateTime.now().year, DateTime.now().month, 1);
  static String showLoaderText = Constants.NO_DATA_FOUND;
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  List<RawRequestFormDAO> formList = [];
  bool isSearchForParams = false;
  String selectedStatus = "";
  var filterOptions = [];
  List<String> _checked = [];
  List<Map> _mapData = [];
  late ThemeData theme;
  late TextEditingController fromDateController = TextEditingController();
  late TextEditingController toDateController = new TextEditingController();
  @override
  void initState() {
    super.initState();
    this.getLoadLanguage();
    theme = AppTheme.vyaparTheme;
    _productService = ProductService();
    buId = AppController.instance.getMyBuId;
    buName = AppController.instance.buName;
    startDate = formatter.format(mnthStartDate);
    endDate = formatter.format(DateTime.now());
    fromDateController.text = startDate;
    toDateController.text = endDate;
    updateFilterOptionsData();
    loadFormListData();
  }

  loadFormListData(
      {String fromDate = "",
      String toDate = "",
      String name = "",
      num status = 0}) async {
    if (await NetworkStatus.getInternetStatus()) {
      if (!isSearchForParams) {
        setState(() {
          isLoadingProgress = true;
        });
      }
      getRawRequestFormList(status: status, name: name).then((value) {
        formList.clear();
        // setState(() {
        if (value.length > 0) {
          formList.addAll(value);
        } else {
          showLoaderText = Constants.NO_DATA_FOUND;
        }
        // });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  getLoadLanguage() async {
    _mapData = [
      {'name': Language().getString(Constants.REQUESTED_ID, selectedLang)},
      {'name': Language().getString(Constants.REQUESTED_BY, selectedLang)},
      {'name': Language().getString(Constants.DATE, selectedLang)},
      {'name': Language().getString(Constants.PURPOSE, selectedLang)},
      {'name': Language().getString(Constants.STATUS_STRING, selectedLang)},
      {'name': Language().getString(Constants.DEPARTMENT, selectedLang)},
      {'name': Language().getString(Constants.BATCH_NO, selectedLang)},
    ];
  }

  updateFilterOptionsData() {
    isShowFloatButton = false;

    selectedStatus = "";
    filterOptions = [
      {
        'id': 1,
        'name': Language().getString(Constants.PENDING, selectedLang),
        'isFilterValue': false
      },
      {
        'id': 2,
        'name': Language().getString(Constants.ACCEPTED, selectedLang),
        'isFilterValue': false
      },
      {
        'id': 3,
        'name': Language().getString(Constants.REJECTED, selectedLang),
        'isFilterValue': false
      },
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        SafeArea(
          child: Scaffold(
            key: _scaffoldkey,
            backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
            floatingActionButton: (isShowFloatButton)
                ? FloatingActionButton(
                    backgroundColor: theme.colorScheme.primary,
                    onPressed: () {
                      isLoadingProgress = true;
                      fromDateController.text = startDate;
                      toDateController.text = endDate;
                      updateFilterOptionsData();
                      loadFormListData();
                    },
                    child: Text(
                      Language().getString(Constants.CLEAR_FILTERS, selectedLang),
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 10.0, color: Colors.white),
                    ),
                  )
                : null,
            body: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: [
                  FxSpacing.height(10),
                  buildSearchBarView(),
                  FxSpacing.height(10),
                  // (isEnableDateFilter)
                  //     ?
                  Padding(
                    padding: const EdgeInsets.only(left: 5.0, right: 5.0),
                    child: DateFilterUtill(
                      isShowSearchButton: true,
                      fromDate: "",
                      toDate: "",
                      fromDateController: fromDateController,
                      toDateController: toDateController,
                      onFromDateSelected: (value) {
                        setState(() {
                          fromDateController.text = value;
                        });
                      },
                      onToDateSelected: (value) {
                        setState(() {
                          toDateController.text = value;
                        });
                      },
                      onSearchParms: () {
                        setState(() {
                          isShowFloatButton = true;
                          isLoadingProgress = true;
                        });
          
                        loadFormListData();
                      },
                    ),
                  ),
                  // : Container(),
                  FxSpacing.height(10),
                  (formList.length > 0)
                      ? Expanded(
                          child: AnimationLimiter(
                            child: ListView.separated(
                              shrinkWrap: true,
                              separatorBuilder: (context, index) => new Divider(
                                height: 5,
                                color: Colors.transparent,
                              ),
                              itemBuilder: (context, index) =>
                                  AnimationConfiguration.staggeredList(
                                      position: index,
                                      duration: Duration(milliseconds: 900),
                                      child: SlideAnimation(
                                          verticalOffset: 50.0,
                                          child: FadeInAnimation(
                                              child: showRequestFormList(
                                                  formList[index])))),
                              itemCount: formList.length,
                            ),
                          ),
                        )
                      : Container(
                          child: Center(
                              child: Text(Language()
                                  .getString(showLoaderText, selectedLang)))),
                ],
              ),
            ),
          ),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    );
  }

  Widget showRequestFormList(RawRequestFormDAO modelData) {
    return InkWell(
      onTap: () {
        if (!CommonMethods.isPrivillegeExist(
            context,
            PrivillegesActions
                .CONSUMABLE_MATERIAL_MENU_CONSUMABLE_MATERIAL_ISSUANCE_ISSUE_FORM_CLICK)) {
          return;
        }
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => EditConsumableRequestPage(
                      recordId: modelData.id,
                      productList: modelData.productList,
                      formStatus: requestFormStatus(modelData.status),
                      date: AppUtills.getDateFormate(
                          modelData.createdDate.toString()),
                      requestedBy: modelData.issuedTo != null
                          ? modelData.issuedTo!.userName
                          : "",
                      userId: modelData.issuedTo != null
                          ? modelData.issuedTo!.userId
                          : "",
                      purpose: modelData.purpose,
                      isShowEditableProducts: true,
                      requestNumber: modelData.requestNumber,
                      department: modelData.department,
                      batchNumber: modelData.batchNumber,
                    ))).then((value) => loadFormListData());
      },
      child: RawRequestFormCardView(
        modelData: modelData,
        mapData: _mapData,
        canShowBatchNumber: false,
      ),
    );
  }

  String requestFormStatus(num? statusCode) {
    if (statusCode == 1) {
      return "accepted";
    } else if (statusCode == 2) {
      return "rejected";
    } else {
      return "pending";
    }
  }

  cardItems(String title, String value) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 3.0),
      child: Row(
        children: [
          Expanded(
            child: Text(
              "$title",
              style: TextStyle(
                  color: Color(Constants.APP_COLOR),
                  fontSize: 14.0,
                  fontWeight: FontWeight.bold),
            ),
          ),
          Text("  :   "),
          Expanded(
              flex: 2,
              child: Container(
                child: Text(
                  "$value",
                  style: TextStyle(fontSize: 13.0),
                ),
              ))
        ],
      ),
    );
  }

  buildSearchBarView() {
    return Container(
      height: 50.0,
      child: Card(
        elevation: 5,
        shadowColor: theme.colorScheme.primary,
        shape: new RoundedRectangleBorder(
            borderRadius: new BorderRadius.circular(15),
            side: new BorderSide(
                color: theme.colorScheme.primary, strokeAlign: 0.02)),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: TextFormField(
                  controller: _searchController,
                  onChanged: onSearchTextChanged,
                  style: TextStyle(fontWeight: StyleView.fontSemiBold),
                  decoration: InputDecoration(
                      contentPadding: EdgeInsets.only(bottom: 10),
                      border: InputBorder.none,
                      hintText: Language().getString(
                          Constants.SEARCH_BY_REQUESTER_NAME, selectedLang),
                      hintStyle: TextStyle(
                          fontSize: 13.0, fontWeight: StyleView.fontSemiBold)),
                ),
              ),
            ),
            (_searchController.text.length > 0)
                ? Container(
                    color: Colors.white,
                    child: IconButton(
                        icon: Icon(
                          Icons.close,
                          color: Colors.red,
                          size: 20.0,
                        ),
                        onPressed: () {
                          CommonMethods.hideKeyboard(context);
                          _searchController.clear();
                          onSearchTextChanged(_searchController.text);
                        }),
                  )
                : Container(),
            // Container(
            //   color: Colors.white,
            //   child: IconButton(
            //       icon: Icon(Icons.date_range),
            //       onPressed: () {
            //         CommonMethods.hideKeyboard(context);
            //         setState(() {
            //           if (isEnableDateFilter) {
            //             isEnableDateFilter = false;
            //           } else {
            //             isEnableDateFilter = true;
            //           }
            //         });
            //       }),
            // ),
            Container(
              child: IconButton(
                  icon: Icon(
                    Icons.filter_list,
                    color: theme.colorScheme.primary,
                  ),
                  onPressed: () {
                    CommonMethods.hideKeyboard(context);
                    buildProductFilterDialog();
                  }),
            ),
          ],
        ),
      ),
    );
  }

  onSearchTextChanged(String text) async {
    showLoaderText = Constants.LOADING;
    if (text.isEmpty) {
      isSearchForParams = false;
      loadFormListData();
    } else {
      isSearchForParams = true;
      loadFormListData(name: text);
    }
  }

  Future<List<RawRequestFormDAO>> getRawRequestFormList(
      {String fromDate = "",
      String toDate = "",
      num status = 0,
      String name = ""}) async {
    String body = json.encode({
      "bu": buId,
      "filters": {
        "DateFrom": fromDateController.text,
        "DateTo": toDateController.text,
        "status": status,
        "name": name,
        "is_consumable":true
      }
    });

    var response = await _productService
        .getRawRequestFormList(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    List<RawRequestFormDAO> _list = [];

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var reqData = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(reqData)) {
        var arrayData = reqData['results'];

        for (var obj in arrayData) {
          _list.add(RawRequestFormDAO.fromJson(obj));
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return _list;
  }

  buildProductFilterDialog() {
    return showDialog(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) {
          return StatefulBuilder(builder: (context, StateSetter setState) {
            return Scaffold(
                backgroundColor: Colors.transparent,
                body: Center(
                  child: Container(
                    margin: EdgeInsets.symmetric(horizontal: 20, vertical: 70),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.all(Radius.circular(15.0)),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        Align(
                          alignment: Alignment.topRight,
                          child: GestureDetector(
                            onTap: () {
                              Navigator.of(context).pop();
                            },
                            child: Padding(
                              padding: EdgeInsets.all(5.0),
                              child: Icon(
                                Icons.close,
                                color: Colors.red,
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 2.5,
                        ),
                        Text(
                          Language()
                              .getString(Constants.SORT_BY_STR, selectedLang),
                          style: TextStyle(
                              fontSize: StyleView.FONT_SIZE_18,
                              fontFamily: StyleView.FONT_TITLE),
                          textAlign: TextAlign.center,
                        ),
                        SizedBox(
                          height: 2.5,
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width,
                          height: 2,
                          color: Colors.grey,
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        // CheckboxGroup(
                        //   labels: filterOptions,
                        //   checked: _checked,
                        //   onSelected: (List selected) {
                        //     if (selected.length > 1) {
                        //       selected.removeAt(0);
                        //     }
                        //     setState(() {
                        //       _checked = selected;
                        //     });
                        //   },
                        // ),
                        Container(
                          child: ListView.builder(
                              shrinkWrap: true,
                              itemCount: filterOptions.length,
                              itemBuilder: (BuildContext context, int index) {
                                return Container(
                                  margin: EdgeInsets.symmetric(horizontal: 5),
                                  child: Row(
                                    children: [
                                      SizedBox(
                                        height: 40,
                                        width: 40,
                                        child: Checkbox(
                                            activeColor:
                                                theme.colorScheme.primary,
                                            value: filterOptions[index]
                                                ['isFilterValue'],
                                            onChanged: (bool? value) {
                                              setState(() {
                                                filterOptions[index]
                                                    ['isFilterValue'] = value!;
                                                selectedStatus =
                                                    filterOptions[index]
                                                        ['name'];
                                              });
                                            }),
                                      ),
                                      Text(
                                        Language().getString(
                                            filterOptions[index]['name'],
                                            selectedLang),
                                        style: TextStyle(
                                            fontWeight: StyleView.fontSemiBold,
                                            color: (filterOptions[index]
                                                        ['isFilterValue'] ==
                                                    true)
                                                ? Colors.grey
                                                : Colors.black),
                                      ),
                                    ],
                                  ),
                                );
                              }),
                        ),

                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            shape: RoundedRectangleBorder(
                                borderRadius: new BorderRadius.circular(10.0)),
                            backgroundColor: theme.colorScheme.primary,
                            textStyle: TextStyle(color: Colors.white),
                            elevation: 0,
                          ),
                          onPressed: () {
                            if (selectedStatus.isNotEmpty) {
                              setState(() {
                                isLoadingProgress = true;
                                isShowFloatButton = true;
                              });
                              loadFormListData(
                                  fromDate: startDate,
                                  toDate: endDate,
                                  status:
                                      getStatusCodeByFilter(selectedStatus));
                            }
                            Navigator.of(context).pop();
                            // if (_checked[0] ==
                            //     Language().getString(
                            //         Constants.PENDING, selectedLang)) {
                            //   selectedStatus = Constants.PENDING;
                            // } else if (_checked[0] ==
                            //     Language().getString(
                            //         Constants.REJECTED, selectedLang)) {
                            //   selectedStatus = Constants.REJECTED;
                            // } else {
                            //   selectedStatus = Constants.ACCEPTED;
                            // }
                          },
                          child: Text(Language()
                              .getString(Constants.APPLY_FILTER, selectedLang)),
                        ),
                        SizedBox(height: 10)
                      ],
                    ),
                  ),
                ));
          });
        });
  }

  num getStatusCodeByFilter(String status) {
    if (status == "Accepted") {
      return 1;
    } else if (status == "Rejected") {
      return 2;
    } else {
      return 0;
    }
  }
}
