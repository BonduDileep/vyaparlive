import 'dart:convert';

import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/DepartmentDAO.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/RawMaterialTemplateDAO.dart';
import 'package:vyaparlive/model/UserModel.dart';
import 'package:vyaparlive/model/product_model/ProductModel.dart';
import 'package:vyaparlive/service/Service.dart';
import 'package:vyaparlive/service/product_services.dart';
import 'package:vyaparlive/service/user_services.dart';
import 'package:vyaparlive/utills/SharePref.dart';
import 'package:http/http.dart' as http;

class CreateConsumableTemplatePgae extends StatefulWidget {
  final bool isFromRawRequestForm;
  final RawMaterialTemplateDAO? modelData;
  final bool updateTemplate;
  final String? templateId;
  CreateConsumableTemplatePgae(
      {this.isFromRawRequestForm = false,
      this.modelData,
      this.updateTemplate = false,
      this.templateId});
  @override
  _CreateConsumableTemplatePgaeState createState() => _CreateConsumableTemplatePgaeState();
}

class _CreateConsumableTemplatePgaeState extends State<CreateConsumableTemplatePgae> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? buName = "";
  String? buId = "";
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  List<BuProductModal> _productsList = [];
  List<BuProductModal> _rawProductsList = [];
  bool isLoadingProgress = true;
  String progressMessage = Constants.GETTING_DATA;
  late ProductService _productService;
  TextEditingController _nameController = TextEditingController();
  TextEditingController _descriptionController = TextEditingController();
  BuProductModal? finishProductDropdown;
  BuProductModal? rawProductDropdown;
  List<TextEditingController> _listQuantityController = [];
  List<String?> _listQuantityIn = [];
  List<TemplateRawProductsDAO> _selectedRawProducts = [];
  List<RawMaterialTemplateDAO> _templatesList = [];
  RawMaterialTemplateDAO? templateDropdown;
  bool _isVisible = true;
  RawMaterialTemplateDAO? templateData;
  String? loginUserId = "";
  String? userName = "";
  TextEditingController _purposeController = TextEditingController();
  final TextEditingController _issueBatchNumberController =
      new TextEditingController();
  DepartmentDAO? _departmentDropdownValue;
  List<DepartmentDAO> _departmentList = [];
  late Service _service;
  List<BuProductModal> _tempProductList = [];
  final TextEditingController _searchController = TextEditingController();
  List<BuProductModal> _responseProducts = [];
  List<BuProductModal> _selectedFinishedProductsList = [];
  num showFinishedProductsList = 0;
  bool flag = true;
  late UserService _userService;
  UserModel? _userModel;
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _productService = ProductService();
    _userService = UserService();
    _service = Service();
    buName = AppController.instance.getBuName;
    buId = AppController.instance.getMyBuId;
    SharePref().getUserId().then((value) {
      setState(() {
        loginUserId = value;
      });
      SharePref().getUserName().then((value) {
        setState(() {
          userName = value;
        });
      });
    });

    if (widget.isFromRawRequestForm) {
      setState(() {
        _isVisible = false;
      });

      this.loadGetTamplatesData();
    } else {
      this.allServiceCalls();
    }
  }

  allServiceCalls() async {
    if (await NetworkStatus.getInternetStatus()) {
      await getBuProducts().then((onValue) {
        setState(() {
          for (int i = 0; i < onValue.length; i++) {
            if (onValue[i].isRawProduct!) {
              _rawProductsList.add(onValue[i]);
            } else {
              // _productsList.add(onValue[i]);
              // _tempProductList.add(onValue[i]);
              _responseProducts.add(BuProductModal(
                name: onValue[i].name,
                id: onValue[i].id,
                isProductSelected: false,
              ));
            }
          }
        });
      });

      if (widget.updateTemplate) {
        await loadTemplateDataById(templateId: widget.templateId);
      }

      if (widget.isFromRawRequestForm) {
        await this.getUserDataById().then((value) {
          setState(() {
            _userModel = value;
          });
        });
        await getDepartments().then((value) {
          setState(() {
            _departmentList.clear();
            _departmentList.addAll(value);
            for (int i = 0; i < _departmentList.length; i++) {
              if (_userModel != null &&
                  _userModel!.businessUnits![0].departmentName ==
                      _departmentList[i].name) {
                _departmentDropdownValue = _departmentList[i];
              }
            }
          });
        });
      }
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  loadTemplateDataById({String? templateId = ""}) async {
    await this.findTemplateDataById(templateId: templateId).then((value) {
      if (value.length > 0) {
        setState(() {
          _selectedRawProducts.clear();
          _listQuantityController.clear();
          _listQuantityIn.clear();

          templateData = value[0];
          if (templateData != null) {
            _nameController.text = templateData!.templateName!;
            _descriptionController.text = templateData!.description!;
            _selectedRawProducts.addAll(templateData!.rawProducts!);

            for (int i = 0; i < _selectedRawProducts.length; i++) {
              _listQuantityController.add(new TextEditingController());
              _listQuantityIn.add(null);
              _listQuantityController[i].text =
                  _selectedRawProducts[i].quantity.toString();
              _listQuantityIn[i] = _selectedRawProducts[i].quantityIn;
            }
            _selectedFinishedProductsList
                .addAll(templateData!.finishedProductsList!);

            for (int i = 0; i < _selectedFinishedProductsList.length; i++) {
              for (int j = 0; j < _productsList.length; j++) {
                if (_selectedFinishedProductsList[i].id ==
                    _productsList[j].id) {
                  _tempProductList[j].isProductSelected = true;
                  _productsList[j].isProductSelected = true;
                }
              }
            }
          }
        });
      }
    });
  }

  @override
  void dispose() {
    _nameController.clear();
    _descriptionController.clear();
    finishProductDropdown = null;
    rawProductDropdown = null;
    _selectedRawProducts.clear();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
        body: Stack(
      children: [
        SafeArea(
          child: Scaffold(
            key: _scaffoldkey,
            backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
            appBar: AppBar(
              backgroundColor: Colors.transparent, //(Constants.APP_COLOR),
              centerTitle: true,
              elevation: 0,
              iconTheme: IconThemeData(color: theme.colorScheme.primary),
              title: AppbarName(
                  title: Language()
                      .getString(Constants.CREATE_TEMPLATE, selectedLang),
                  buName: "$buName"),
            ),
            bottomNavigationBar: (widget.isFromRawRequestForm)
                ? this.bottomViewFromRequestForm()
                : this.bottomView(),
            body: SingleChildScrollView(
              child: Container(
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Column(
                    children: [
                      (widget.isFromRawRequestForm)
                          ? this.buildTemplateDropdown()
                          : this.buildTableContent(
                              Constants.TEMPLATE_NAME, _nameController),
                      (widget.isFromRawRequestForm)
                          ? Container()
                          : this.buildTableContent(Constants.DESCRIPTION_STRING,
                              _descriptionController),
                      (widget.isFromRawRequestForm)
                          ? Container()
                          : this.buildFinishedProductsSection(),
                      Visibility(
                          visible: _isVisible,
                          child: Column(children: [
                            this.buildRawMaterialProductsSection(),
                            this.buildSelectedRawProductsCardView(),
                          ]))
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    ));
  }

  loadGetTamplatesData() async {
    if (await NetworkStatus.getInternetStatus()) {
      await this.getAllTemplatesData().then((value) {
        _templatesList.clear();
        _templatesList.addAll(value);
      });

      if (_templatesList.length > 0) {
        this.allServiceCalls();
      }
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<RawMaterialTemplateDAO>> getAllTemplatesData() async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = Constants.GETTING_DATA;
    });
    String body = json.encode({"bu": buId, "filters": {}});
    var response = await _productService
        .getRawTemplatesByBuId(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    List<RawMaterialTemplateDAO> _list = [];
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(resObj)) {
        var resultArray = resObj['results'];
        if (resultArray.length > 0) {
          for (var obj in resultArray) {
            _list.add(RawMaterialTemplateDAO.fromJson(obj));
          }
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return _list;
  }

  Future<List<BuProductModal>> getBuProducts() async {
    setState(() {
      _productsList.clear();
      _rawProductsList.clear();
    });
    String body = json.encode({
      "id": buId,
      "filter": {"all_products": true}
    });

    var response = await _productService
        .getProductByBuId_v2(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<BuProductModal> products = [];

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      var data = resObj['results'];
      for (var i in data) {
        products.add(BuProductModal.fromJson(i));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return products;
  }

  buildTableContent(String textName, TextEditingController _controller) {
    return Container(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: EdgeInsets.only(top: 5.0),
            child: Text(
              Language().getString(textName, selectedLang),
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Container(
            decoration:
                AppUtills.boxDecoration(customContainerColor: Colors.white),
            margin: EdgeInsets.only(top: 5.0),
            child: Padding(
              padding: const EdgeInsets.all(5.0),
              child: TextField(
                controller: _controller,
                style: TextStyle(
                  fontFamily: 'IndianRupee',
                ),
                decoration: InputDecoration(
                  border: InputBorder.none,
                  hintText: Language().getString(textName, selectedLang),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  buildFinishedProductsSection() {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 5.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
              margin: EdgeInsets.only(top: 5.0),
              child: Text(
                  Language()
                      .getString(Constants.FINISHED_PRODUCTS, selectedLang),
                  style: TextStyle(fontWeight: FontWeight.bold))),
          Container(
              width: MediaQuery.of(context).size.width,
              margin: EdgeInsets.only(top: 5.0),
              decoration:
                  AppUtills.boxDecoration(customContainerColor: Colors.white),
              child: InkWell(
                  onTap: () async {
                    CommonMethods.hideKeyboard(context);
                    await this.updateProductsData();
                    this.finshedProductsDropdown();
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(Language()
                        .getString(Constants.SEARCH_BY_PRODUCT, selectedLang)),
                  ))),
          (_selectedFinishedProductsList.length > 0)
              ? this.showSelectedProducts()
              : Container(),
        ],
      ),
    );
  }

  showSelectedProducts() {
    return Column(
      children: [
        for (var i = 0; i < _selectedFinishedProductsList.length; i++)
          Card(
            elevation: 2.5,
            child: Padding(
              padding: const EdgeInsets.all(5.0),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      Language()
                          .getString(Constants.PRODUCT_NAME, selectedLang),
                      style: TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 15.0,
                          color: Color(Constants.APP_COLOR)),
                    ),
                  ),
                  Text(" : "),
                  Expanded(
                    flex: 2,
                    child: Text(
                      _selectedFinishedProductsList[i].name!,
                      style: TextStyle(
                          color: Color(Constants.APP_COLOR),
                          fontSize: 13.0,
                          fontWeight: FontWeight.w500),
                    ),
                  ),
                ],
              ),
            ),
          )
      ],
    );
  }

  finshedProductsDropdown() {
    return showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => StatefulBuilder(
            builder: (context, StateSetter setState) => Container(
                  decoration: BoxDecoration(
                      color: Color(Constants.APP_BACKGROUND_COLOR),
                      borderRadius: BorderRadius.circular(5.0)),
                  margin:
                      EdgeInsets.symmetric(vertical: 10.0, horizontal: 20.0),
                  child: AppBackgroundView(
                      body: Scaffold(
                    backgroundColor: Colors.transparent,
                    bottomNavigationBar: Container(
                        padding: EdgeInsets.symmetric(vertical: 10),
                        child: CommonButtonsView(
                          context: context,
                          b1Text: Language()
                              .getString(Constants.CLOSE, selectedLang),
                          b2Text: Language()
                              .getString(Constants.CONFIRM, selectedLang),
                          onb1Action: () {
                            setState(() {
                              _productsList.clear();
                              _tempProductList.clear();
                            });

                            Navigator.of(context).pop();
                          },
                          onb2Action: () {
                            setState(() {
                              _selectedFinishedProductsList.clear();
                            });

                            this.updateSelectedProducts();

                            Navigator.of(context).pop();
                          },
                        )),
                    body: Container(
                      margin: EdgeInsets.symmetric(
                          vertical: 10.0, horizontal: 10.0),
                      child: Column(
                        children: [
                          Container(
                              decoration: AppUtills.boxDecoration(
                                  customContainerColor: Colors.white),
                              padding: EdgeInsets.all(5.0),
                              child: TextFormField(
                                controller: _searchController,
                                decoration: InputDecoration(
                                  border: InputBorder.none,
                                  hintText: Language().getString(
                                      Constants.SEARCH_BY_PRODUCT,
                                      selectedLang),
                                ),
                                onChanged: (text) {
                                  setState(() {
                                    _productsList.clear();
                                  });

                                  if (text.isEmpty) {
                                    setState(() {
                                      _productsList.addAll(_tempProductList);
                                    });

                                    return;
                                  }

                                  _tempProductList.forEach((element) {
                                    if (element.name!
                                        .toLowerCase()
                                        .contains(text.toLowerCase()))
                                      _productsList.add(element);
                                  });

                                  setState(() {
                                    _productsList = _productsList;
                                  });
                                },
                              )),
                          Expanded(
                            child: Container(
                                margin: EdgeInsets.only(top: 5.0),
                                child: ListView.builder(
                                  shrinkWrap: true,
                                  itemBuilder: (context, index) => Card(
                                    elevation: 2.5,
                                    child: Padding(
                                      padding: const EdgeInsets.all(10.0),
                                      child: Row(
                                        children: [
                                          Expanded(
                                            child: Text(
                                                _productsList[index].name!,
                                                style: TextStyle(
                                                    color: Color(
                                                        Constants.APP_COLOR),
                                                    fontWeight:
                                                        FontWeight.w700)),
                                          ),
                                          Container(
                                            child: Checkbox(
                                                activeColor: Colors.green,
                                                value: _productsList[index]
                                                    .isProductSelected,
                                                onChanged: (value) {
                                                  setState(() {
                                                    _productsList[index]
                                                            .isProductSelected =
                                                        value;
                                                  });
                                                }),
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                  itemCount: _productsList.length,
                                )),
                          )
                        ],
                      ),
                    ),
                  )),
                )));
  }

  updateSelectedProducts() {
    setState(() {
      if (_searchController.text.isNotEmpty) {
        _searchController.clear();
        _productsList.clear();
        _productsList.addAll(_tempProductList);
      }
      for (int i = 0; i < _productsList.length; i++) {
        if (_productsList[i].isProductSelected!) {
          setState(() {
            _selectedFinishedProductsList.add(_productsList[i]);
          });
        }
      }
      _tempProductList.clear();
      _productsList.clear();
    });
  }

  bottomView() {
    return Container(
        child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: CommonButtonsView(
              context: context,
              b1Text: Language().getString(Constants.STR_CANCEL, selectedLang),
              b2Text: Language().getString(
                  (widget.updateTemplate)
                      ? Constants.UPDATE_STRING
                      : Constants.CONFIRM,
                  selectedLang),
              onb1Action: () {
                Navigator.of(context).pop();
              },
              onb2Action: () async {
                String _error = validateMandatoryFields();
                if (_error.isNotEmpty) {
                  Dialogs.yesCancelDialog(
                      context,
                      Language().getString(Constants.ERROR, selectedLang),
                      _error,
                      Language().getString(Constants.OKAY_STR, selectedLang),
                      "",
                      false);
                } else {
                  if (await NetworkStatus.getInternetStatus()) {
                    if (widget.updateTemplate) {
                      setState(() {
                        isLoadingProgress = true;
                        progressMessage = Constants.UPDATING;
                      });
                      this.serviceCallUpdateRawRequestTemplate();
                    } else {
                      setState(() {
                        isLoadingProgress = true;
                        progressMessage = Constants.CREATING;
                      });
                      this.serviceCallCreateRawRequestTemplate();
                    }
                  } else {
                    AppUtills.showSnackBar(
                        _scaffoldkey,
                        Language()
                            .getString(Constants.NO_INTERNET, selectedLang),
                        snackBarBgColor: Colors.black,
                        messageColor: Colors.white,
                        buttonColor: Colors.white);
                  }
                }
              },
            )));
  }

  buildRawMaterialProductsSection() {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 5.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
              margin: EdgeInsets.only(top: 5.0),
              child: Text(
                  Language().getString(Constants.RAW_MATERIAL, selectedLang),
                  style: TextStyle(fontWeight: FontWeight.bold))),
          Container(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                    child: Container(
                        child: InkWell(
                            onTap: () {
                              CommonMethods.hideKeyboard(context);
                              this.rawMaterialProductsDropdown();
                            },
                            child: Container(
                              margin: EdgeInsets.only(top: 5.0),
                              decoration: AppUtills.boxDecoration(
                                  customContainerColor: Colors.white),
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    (rawProductDropdown == null)
                                        ? Text(Language().getString(
                                            Constants
                                                .SEARCH_BY_RAW_MATERIAL_NAME,
                                            selectedLang))
                                        : Text(rawProductDropdown!.name!),
                                    Container(
                                      child: Icon(
                                          Icons.keyboard_arrow_down_rounded),
                                    )
                                  ],
                                ),
                              ),
                            )))),
                this.buildCustomButton()
              ],
            ),
          )
        ],
      ),
    );
  }

  rawMaterialProductsDropdown() {
    return showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
              actions: [
                InkWell(
                    onTap: () {
                      Navigator.of(context).pop();
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                          Language().getString(Constants.CLOSE, selectedLang),
                          style: TextStyle(
                              fontSize: 15.0,
                              color: Colors.red,
                              fontWeight: FontWeight.bold)),
                    ))
              ],
              content: Container(
                width: double.maxFinite,
                margin: EdgeInsets.symmetric(vertical: 5.0),
                child: Column(
                  children: [
                    // Container(
                    //   decoration: AppUtills.boxDecoration(),
                    //   child: SearchableDropdown.single(
                    //     items: _rawProductsList.map((BuProductModal model) {
                    //       return new DropdownMenuItem<BuProductModal>(
                    //         child: new Text(model.name),
                    //         value: model,
                    //       );
                    //     }).toList(),
                    //     value: rawProductDropdown,
                    //     underline: Container(),
                    //     hint: Language().getString(
                    //         Constants.SEARCH_BY_RAW_MATERIAL_NAME,
                    //         selectedLang),
                    //     searchHint: Language().getString(
                    //         Constants.SEARCH_BY_RAW_MATERIAL_NAME,
                    //         selectedLang),
                    //     onChanged: (value) {
                    //       Navigator.of(context).pop();
                    //       setState(() {
                    //         rawProductDropdown = value;
                    //       });
                    //     },
                    //     isExpanded: true,
                    //   ),
                    // ),
                    Expanded(
                      child: Container(
                          margin: EdgeInsets.only(top: 5.0),
                          child: ListView.builder(
                            shrinkWrap: true,
                            itemBuilder: (context, index) => InkWell(
                              onTap: () {
                                Navigator.of(context).pop();
                                setState(() {
                                  rawProductDropdown = _rawProductsList[index];
                                });
                              },
                              child: Card(
                                elevation: 2.5,
                                child: Padding(
                                  padding: const EdgeInsets.all(10.0),
                                  child: Text(_rawProductsList[index].name!,
                                      style: TextStyle(
                                          color: Color(Constants.APP_COLOR),
                                          fontWeight: FontWeight.w700)),
                                ),
                              ),
                            ),
                            itemCount: _rawProductsList.length,
                          )),
                    )
                  ],
                ),
              ),
            ));
  }

  buildCustomButton() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: InkWell(
        onTap: () {
          if (rawProductDropdown != null) {
            bool isProductExist = false;
            int existIndex = -1;
            for (int i = 0; i < _selectedRawProducts.length; i++) {
              if (rawProductDropdown!.id == _selectedRawProducts[i].productId) {
                isProductExist = true;
                existIndex = i;
              }
            }

            if (isProductExist) {
              setState(() {
                _selectedRawProducts[existIndex].quantity =
                    _selectedRawProducts[existIndex].quantity! + 1;
                _listQuantityController[existIndex].text =
                    _selectedRawProducts[existIndex].quantity.toString();
                _listQuantityIn[existIndex] =
                    _selectedRawProducts[existIndex].quantityIn;
                rawProductDropdown = null;
              });
            } else {
              setState(() {
                _selectedRawProducts.add(TemplateRawProductsDAO(
                    rawProductName: rawProductDropdown!.name,
                    productId: rawProductDropdown!.id,
                    quantity: 1,
                    quantityIn: ""));
                _listQuantityController
                    .add(new TextEditingController(text: "1"));
                _listQuantityIn.add(null);
                rawProductDropdown = null;
              });
            }
          } else {
            Dialogs.yesCancelDialog(
                context,
                Language().getString(Constants.ERROR, selectedLang),
                Language().getString(
                    Constants.PLEASE_SELECT_RAW_MATERIALS, selectedLang),
                Language().getString(Constants.OKAY_STR, selectedLang),
                "",
                false);
          }
        },
        child: Container(
          height: 30.0,
          width: 30.0,
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20.0),
              color: Color(Constants.APP_COLOR)),
          child: Icon(Icons.add, color: Colors.white, size: 20.0),
        ),
      ),
    );
  }

  buildSelectedRawProductsCardView() {
    return Container(
      child: ListView.separated(
          shrinkWrap: true,
          separatorBuilder: (context, index) => new Divider(
                color: Colors.transparent,
                height: 0.0,
              ),
          itemCount: _selectedRawProducts.length,
          itemBuilder: (context, index) {
            return Card(
                child: Container(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: Container(
                        child: new Text(
                          _selectedRawProducts[index].rawProductName!,
                          style: TextStyle(
                            color: Color(Constants.APP_COLOR),
                            fontSize: 15.0,
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      child: Container(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Container(
                                child: InkWell(
                              onTap: () {
                                this.renderRemoveProductQuantity(index);
                              },
                              child: Icon(Icons.remove),
                            )),
                            Container(
                              width: 50.0,
                              height: 30.0,
                              alignment: Alignment.bottomCenter,
                              decoration: AppUtills.boxDecoration(),
                              child: this.designQuantityInputField(index),
                            ),
                            Container(
                                child: InkWell(
                              onTap: () {
                                this.renderAddProductQuantity(index);
                              },
                              child: Icon(Icons.add),
                            ))
                          ],
                        ),
                      ),
                    ),
                    Expanded(child: this.buildQuantityInDropdown(index)),
                  ],
                ),
              ),
            ));
          }),
    );
  }

  designQuantityInputField(int index) {
    return Container(
      height: 60.0,
      width: 60.0,
      child: TextFormField(
        enableInteractiveSelection: false,
        textAlign: TextAlign.center,
        controller: _listQuantityController[index],
        decoration: InputDecoration(
          contentPadding: EdgeInsets.only(bottom: Constants.CONTENT_PADDING_18_15),
          hintText: "0",
          border: InputBorder.none,
        ),
        keyboardType: TextInputType.number,
        style: TextStyle(fontSize: 12.0),
        inputFormatters: [
          new LengthLimitingTextInputFormatter(5),
          FilteringTextInputFormatter.digitsOnly
        ],
        onChanged: (value) {
          if (value.isNotEmpty) {
            setState(() {
              _selectedRawProducts[index].quantity = int.parse(value);
              _listQuantityController[index] = TextEditingController(
                  text: _selectedRawProducts[index].quantity.toString());
              _listQuantityController[index].selection =
                  TextSelection.fromPosition(TextPosition(
                      offset: _listQuantityController[index].text.length));
            });
          } else {
            setState(() {
              _selectedRawProducts[index].quantity = 0;
              _listQuantityController[index] = TextEditingController(
                  text: _selectedRawProducts[index].quantity.toString());
              _listQuantityController[index].selection =
                  TextSelection.fromPosition(TextPosition(
                      offset: _listQuantityController[index].text.length));
            });
          }
        },
      ),
    );
  }

  buildQuantityInDropdown(int index) {
    if (_listQuantityIn[index] == null) {
      _listQuantityIn[index] = Constants.UNIT_PRICE[0];
      _selectedRawProducts[index].quantityIn = _listQuantityIn[index];
    }
    return Container(
        color: Colors.white,
        margin: EdgeInsets.symmetric(horizontal: 7.0),
        child: DropdownButton<String>(
            onTap: () {
              return CommonMethods.hideKeyboard(context);
            },
            value: _listQuantityIn[index],
            isExpanded: true,
            hint: new Text(
              Language().getString(Constants.SELECT, selectedLang),
            ),
            underline: SizedBox(),
            onChanged: (String? data) {
              setState(() {
                _listQuantityIn[index] = data;
                _selectedRawProducts[index].quantityIn = _listQuantityIn[index];
              });
            },
            items: Constants.UNIT_PRICE.map((String model) {
              return new DropdownMenuItem<String>(
                child: new Text(model),
                value: model,
              );
            }).toList()));
  }

  renderRemoveProductQuantity(int index) {
    num? _selectedCount = _selectedRawProducts[index].quantity;
    if (_selectedCount != 0 && _selectedCount != 1) {
      _selectedCount = _selectedCount! - 1;
      setState(() {
        _selectedRawProducts[index].quantity = _selectedCount;
        _listQuantityController[index] = TextEditingController(
            text: _selectedRawProducts[index].quantity.toString());
        _listQuantityController[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _listQuantityController[index].text.length));
      });
    }
  }

  /// Adding product quantiy
  renderAddProductQuantity(int index) {
    int _count = _selectedRawProducts[index].quantity as int;
    _count++;
    setState(() {
      _selectedRawProducts[index].quantity = _count;
      _listQuantityController[index] = TextEditingController(
          text: _selectedRawProducts[index].quantity.toString());
      _listQuantityController[index].selection = TextSelection.fromPosition(
          TextPosition(offset: _listQuantityController[index].text.length));
    });
  }

  serviceCallCreateRawRequestTemplate() async {
    List<Map<String, dynamic>?> _list = [];
    var object;

    List<Map<String, dynamic>> _finishedProductsList = [];
    var finishProductsObj;

    for (int i = 0; i < _selectedRawProducts.length; i++) {
      if (_selectedRawProducts[i].quantity != 0) {
        object = {
          "id": _selectedRawProducts[i].productId,
          "quantity": _selectedRawProducts[i].quantity,
          "quantity_in": _selectedRawProducts[i].quantityIn
        };
      }

      _list.add(object);
    }

    for (int i = 0; i < _selectedFinishedProductsList.length; i++) {
      finishProductsObj = {
        "id": _selectedFinishedProductsList[i].id,
        "name": _selectedFinishedProductsList[i].name
      };
      _finishedProductsList.add(finishProductsObj);
    }
    Map data = {
      "bu": buId,
      "name": _nameController.text,
      "description": _descriptionController.text,
      "finished_products": _finishedProductsList,
      "note": "",
      "issued_to": "",
      "raw_material_products": _list
    };

    String body = json.encode(data);
    var response = await _productService
        .createRawTemplate(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          resObj,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);

      if (action == DialogAction.yes) {
        Navigator.of(context).pop();
        Navigator.of(context);
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  String validateMandatoryFields() {
    if (_nameController.text.isEmpty) {
      return "Please enter template name";
    } else if (_selectedRawProducts.length == 0) {
      return "Please add raw products by click on \" + \" ";
    } else {
      return "";
    }
  }

  buildTemplateDropdown() {
    if (_templatesList.length > 0) {
      return Container(
        margin: EdgeInsets.symmetric(vertical: 5.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
                margin: EdgeInsets.only(top: 5.0),
                child: Text(
                    Language()
                        .getString(Constants.SELECT_TEMPLATE, selectedLang),
                    style: TextStyle(fontWeight: FontWeight.bold))),
            Container(
                child: InkWell(
                    onTap: () {
                      CommonMethods.hideKeyboard(context);
                      this.templatePopupDropdown();
                    },
                    child: Container(
                      margin: EdgeInsets.only(top: 5.0),
                      decoration: AppUtills.boxDecoration(
                          customContainerColor: Colors.white),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            (templateDropdown == null)
                                ? Text(Language().getString(
                                    Constants.SELECT_TEMPLATE, selectedLang))
                                : Text(templateDropdown!.templateName!),
                            Container(
                              child: Icon(Icons.keyboard_arrow_down_rounded),
                            )
                          ],
                        ),
                      ),
                    )))
          ],
        ),
      );
    } else {
      return Container(
          child: Center(
        child: Text(
            Language()
                .getString(Constants.YOU_HAVE_NO_RAW_TEMPLATES, selectedLang),
            style: TextStyle(
                color: Color(Constants.APP_COLOR),
                fontSize: 15.0,
                fontWeight: FontWeight.bold)),
      ));
    }
  }

  templatePopupDropdown() {
    return showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
              actions: [
                InkWell(
                    onTap: () {
                      Navigator.of(context).pop();
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                          Language().getString(Constants.CLOSE, selectedLang),
                          style: TextStyle(
                              fontSize: 15.0,
                              color: Colors.red,
                              fontWeight: FontWeight.bold)),
                    ))
              ],
              content: Container(
                width: double.maxFinite,
                margin: EdgeInsets.symmetric(vertical: 5.0),
                child: Column(
                  children: [
                    // Container(
                    //   decoration: AppUtills.boxDecoration(),
                    //   child: SearchableDropdown.single(
                    //     items:
                    //         _templatesList.map((RawMaterialTemplateDAO model) {
                    //       return new DropdownMenuItem<RawMaterialTemplateDAO>(
                    //         child: new Text(model.templateName),
                    //         value: model,
                    //       );
                    //     }).toList(),
                    //     value: templateDropdown,
                    //     underline: Container(),
                    //     hint: Language()
                    //         .getString(Constants.SEARCH, selectedLang),
                    //     searchHint: Language()
                    //         .getString(Constants.SEARCH, selectedLang),
                    //     onChanged: (value) {
                    //       Navigator.of(context).pop();
                    //       setState(() {
                    //         templateDropdown = value;
                    //         _isVisible = true;
                    //       });
                    //       this.loadTemplateDataById(
                    //           templateId: templateDropdown.templateId);
                    //     },
                    //     isExpanded: true,
                    //   ),
                    // ),
                    Expanded(
                      child: Container(
                          margin: EdgeInsets.only(top: 5.0),
                          child: ListView.builder(
                            shrinkWrap: true,
                            itemBuilder: (context, index) => InkWell(
                              onTap: () {
                                Navigator.of(context).pop();
                                setState(() {
                                  templateDropdown = _templatesList[index];
                                  _isVisible = true;
                                });
                                this.loadTemplateDataById(
                                    templateId: templateDropdown!.templateId);
                              },
                              child: Card(
                                elevation: 2.5,
                                child: Padding(
                                  padding: const EdgeInsets.all(10.0),
                                  child: Text(
                                      _templatesList[index].templateName!,
                                      style: TextStyle(
                                          color: Color(Constants.APP_COLOR),
                                          fontWeight: FontWeight.w700)),
                                ),
                              ),
                            ),
                            itemCount: _templatesList.length,
                          )),
                    )
                  ],
                ),
              ),
            ));
  }

  Future<List<RawMaterialTemplateDAO>> findTemplateDataById(
      {String? templateId = ""}) async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = "Template data loading..";
    });
    Map data = {
      "bu": buId,
      "raw_material_id": templateId,
    };

    String body = json.encode(data);
    var response = await _productService
        .findDataByTemplateId(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    List<RawMaterialTemplateDAO> _list = [];
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(resObj)) {
        _list.add(RawMaterialTemplateDAO.fromJson(resObj));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return _list;
  }

  serviceCallUpdateRawRequestTemplate() async {
    List<Map<String, dynamic>?> _list = [];
    var object;
    List<Map<String, dynamic>> _finishedProductsList = [];
    var finishProductsObj;

    for (int i = 0; i < _selectedRawProducts.length; i++) {
      if (_selectedRawProducts[i].quantity != 0) {
        object = {
          "id": _selectedRawProducts[i].productId,
          "quantity": _selectedRawProducts[i].quantity,
          "quantity_in": _selectedRawProducts[i].quantityIn
        };
      }

      _list.add(object);
    }

    for (int i = 0; i < _selectedFinishedProductsList.length; i++) {
      finishProductsObj = {
        "id": _selectedFinishedProductsList[i].id,
        "name": _selectedFinishedProductsList[i].name
      };
      _finishedProductsList.add(finishProductsObj);
    }
    Map data = {
      "raw_material_id": widget.templateId,
      "bu": buId,
      "name": _nameController.text,
      "description": _descriptionController.text,
      "finished_products": _finishedProductsList,
      "note": "",
      "issued_to": "",
      "raw_material_products": _list
    };

    String body = json.encode(data);
    var response = await _productService
        .updateTemplate(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          resObj,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);

      if (action == DialogAction.yes) {
        Navigator.of(context).pop();
        Navigator.of(context);
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  bottomViewFromRequestForm() {
    if (_templatesList.length > 0) {
      return Container(
          child: Padding(
              padding: const EdgeInsets.all(10.0),
              child: CommonButtonsView(
                context: context,
                b1Text:
                    Language().getString(Constants.STR_CANCEL, selectedLang),
                b2Text: Language().getString(Constants.CONFIRM, selectedLang),
                onb1Action: () {
                  Navigator.of(context).pop();
                },
                onb2Action: () async {
                  String _error = validateMandatoryFields();
                  if (_error.isNotEmpty) {
                    Dialogs.yesCancelDialog(
                        context,
                        Language().getString(Constants.ERROR, selectedLang),
                        _error,
                        Language().getString(Constants.OKAY_STR, selectedLang),
                        "",
                        false);
                  } else {
                    this.showPurposeTextField();
                  }
                },
              )));
    } else {
      return null;
    }
  }

  showPurposeTextField() {
    return showDialog(
        context: context,
        barrierColor: Colors.black54,
        barrierDismissible: false,
        builder: (context) =>
            StatefulBuilder(builder: (context, StateSetter setState) {
              return Container(
                  margin:
                      EdgeInsets.symmetric(vertical: 20.0, horizontal: 10.0),
                  child: AppBackgroundView(
                    body: Scaffold(
                        bottomNavigationBar: Container(
                            margin: EdgeInsets.symmetric(horizontal: 10.0),
                            padding: EdgeInsets.symmetric(vertical: 10),
                            child: CommonButtonsView(
                              context: context,
                              b1Text: Language().getString(
                                  Constants.STR_CANCEL, selectedLang),
                              b2Text: Language()
                                  .getString(Constants.CONFIRM, selectedLang),
                              onb1Action: () {
                                Navigator.of(context).pop();
                              },
                              onb2Action: () async {
                                if (_departmentDropdownValue == null) {
                                  Dialogs.yesCancelDialog(
                                      context,
                                      Language().getString(
                                          Constants.ERROR, selectedLang),
                                      Language().getString(
                                          Constants.PLEASE_SELECT_DEPARTMENT,
                                          selectedLang),
                                      Language().getString(
                                          Constants.OKAY_STR, selectedLang),
                                      "",
                                      false);
                                } else {
                                  if (await NetworkStatus.getInternetStatus()) {
                                    Navigator.of(context).pop();
                                    this.createRequestForm();
                                  } else {
                                    AppUtills.showSnackBar(
                                        _scaffoldkey,
                                        Language().getString(
                                            Constants.NO_INTERNET,
                                            selectedLang),
                                        snackBarBgColor: Colors.black,
                                        messageColor: Colors.white,
                                        buttonColor: Colors.white);
                                  }
                                }
                              },
                            )),
                        backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                        body: Container(
                            margin: EdgeInsets.symmetric(
                                vertical: 10.0, horizontal: 10.0),
                            child: Column(
                              children: [
                                Container(
                                  margin: EdgeInsets.symmetric(vertical: 5.0),
                                  child: Text(
                                    Language().getString(
                                        "Purpose Details", selectedLang),
                                    style: TextStyle(
                                        color: Color(Constants.APP_COLOR),
                                        fontSize: 15.0,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.symmetric(vertical: 10.0),
                                  child: TextFormField(
                                      controller: _purposeController,
                                      style: TextStyle(
                                          fontFamily: StyleView.FONT_TITLE),
                                      decoration: StyleView.getInputDecoration(
                                          helper: Language().getString(
                                              Constants.PURPOSE, selectedLang)),
                                      maxLines: 3),
                                ),
                                Container(
                                  margin: EdgeInsets.symmetric(vertical: 10.0),
                                  child: TextFormField(
                                    controller: _issueBatchNumberController,
                                    style: TextStyle(
                                        fontFamily: StyleView.FONT_TITLE),
                                    decoration: StyleView.getInputDecoration(
                                        helper: Language().getString(
                                            Constants.BATCH_NO, selectedLang)),
                                  ),
                                ),
                                this.buildDepartmentDropdown(setState)
                              ],
                            ))),
                  ));
            }));
  }

  createRequestForm() async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = Constants.CREATING;
    });
    List<Map<String, dynamic>?> finalProducts = [];
    var productsObj;
    for (int i = 0; i < _selectedRawProducts.length; i++) {
      if (_selectedRawProducts[i].quantity != 0) {
        productsObj = {
          "id": _selectedRawProducts[i].productId,
          "quantity": int.parse(_listQuantityController[i].text),
          "quantity_in": _listQuantityIn[i],
          "product_name": _selectedRawProducts[i].rawProductName
        };
      }

      finalProducts.add(productsObj);
    }

    Map data = {
      "bu": buId,
      "products": finalProducts,
      "issued_purpose": _purposeController.text,
      "issued_to": loginUserId,
      "requested_by": {"user_id": loginUserId, "user_name": userName},
      "issue_batch_number": _issueBatchNumberController.text,
      "department": _departmentDropdownValue!.name
    };

    String body = json.encode(data);

    var response = await _productService
        .rawRequestForm(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
      if (action == DialogAction.yes) {
        Navigator.pop(context);
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  Future<List<DepartmentDAO>> getDepartments() async {
    http.Response response = await _service.get_department();
    List<DepartmentDAO> list = [];

    if (response.statusCode == 200) {
      var data = json.decode(response.body);
      for (var object in data["data"]) {
        list.add(DepartmentDAO.fromJson(object));
      }
    }
    return list;
  }

  buildDepartmentDropdown(StateSetter setState) {
    return Container(
        padding: EdgeInsets.all(1),
        margin: EdgeInsets.symmetric(vertical: 5.0),
        decoration: AppUtills.boxDecoration(),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 5),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                            Language().getString(
                                Constants.CONTACT_DEPT, selectedLang),
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: StyleView.FONT_TITLE))),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5, right: 5),
                  child: DropdownButton<DepartmentDAO>(
                      value: _departmentDropdownValue,
                      isExpanded: true,
                      hint: Text(Language().getString(
                          Constants.SELECT_DEPARTMENT, selectedLang)),
                      underline: SizedBox(),
                      onChanged: (DepartmentDAO? data) {
                        setState(() {
                          _departmentDropdownValue = data;
                        });
                      },
                      onTap: () {
                        CommonMethods.hideKeyboard(context);
                      },
                      items: _departmentList.map((DepartmentDAO model) {
                        return new DropdownMenuItem<DepartmentDAO>(
                          child: new Text(model.name!),
                          value: model,
                        );
                      }).toList())),
            )
          ],
        ));
  }

  updateProductsData() {
    setState(() {
      for (int i = 0; i < _responseProducts.length; i++) {
        _productsList.add(BuProductModal(
          id: _responseProducts[i].id,
          name: _responseProducts[i].name,
          isProductSelected: _responseProducts[i].isProductSelected,
        ));
      }
      _tempProductList.addAll(_productsList);

      for (int i = 0; i < _selectedFinishedProductsList.length; i++) {
        for (int j = 0; j < _responseProducts.length; j++) {
          if (_selectedFinishedProductsList[i].id == _responseProducts[j].id) {
            _productsList[j].isProductSelected = true;
          }
        }
      }
    });
  }

  Future<UserModel?> getUserDataById() async {
    String body = json.encode({"id": loginUserId});
    // http.Response
    var response = await _userService
        .getUserById_grpc(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    UserModel? _users;

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(resObj)) {
        _users = UserModel.fromJson(resObj[0]);
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return _users;
  }
}
