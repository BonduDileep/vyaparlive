import 'dart:convert';
import 'dart:core';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Reports/DownloadAllReports.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/MyDrawer.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/invoice_view/BatchPriceDropdownView.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/ModelProduct.dart';
import 'package:vyaparlive/model/product_model/BatchPriceDAO.dart';
import 'package:vyaparlive/model/product_model/ProductModel.dart';
import 'package:vyaparlive/model/UserModel.dart';
import 'package:vyaparlive/retailer_view/card_view/ProductsCardView.dart';
import 'package:vyaparlive/service/product_services.dart';
import 'package:vyaparlive/service/user_services.dart';
import 'package:vyaparlive/utills/vyapar_info.dart';

import 'ConsumableProductIssueList.dart';
import 'ConsumableRequetsPage.dart';

class ConsumableMaterialTabView extends StatefulWidget {
  final bool isFromDrawer;
  ConsumableMaterialTabView({this.isFromDrawer = false});
  @override
  _ConsumableMaterialTabViewState createState() => _ConsumableMaterialTabViewState();
}

class _ConsumableMaterialTabViewState extends State<ConsumableMaterialTabView>
    with TickerProviderStateMixin {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? buId = "";
  String? buName = "";
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  String showLoaderText = Constants.NO_DATA_FOUND;
  List<ModelProduct> _productsList = [];
  List<TextEditingController> _enterProductCount = [];
  bool isSearchForParams = false;
  late ProductService _productService;
  final TextEditingController _searchController = TextEditingController();
  List<ModelProduct> selectedList = [];
  List<UserModel> _usersList = [];
  late UserService _userService;
  UserModel? issuedToDropdownValue;
  final TextEditingController _purposeController = TextEditingController();
  bool isEnableDateFilter = true;
  String fromDate = "";
  String toDate = "";
  DateFormat formatter = DateFormat("yyyy-MM-dd");
  DateTime mnthStartDate =
      DateTime.utc(DateTime.now().year, DateTime.now().month, 1);
  bool isEnableFloatButton = false;
  bool isShowProductName = false;
  ModelProduct? _selectedProductData;
  List<BuProductModal> responseProducts = [];
  String showProductText = "";
  List<BatchPriceDAO?> batchPricingDropdownList = [];
  final TextEditingController productNameController = TextEditingController();
  final TextEditingController quantityController = TextEditingController();
  List<String?> quantityInDropdownValue = [];
  BuProductModal? productNameDropdownValue;
  TabController? _tabController;
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    theme = AppTheme.vyaparTheme;
    _productService = ProductService();
    _userService = UserService();
    buId = AppController.instance.getMyBuId;
    buName = AppController.instance.getBuName;
    fromDate = formatter.format(mnthStartDate);
    toDate = formatter.format(DateTime.now());
    this.loadServiceCalls();
  }

  loadServiceCalls() async {
    await this.getUsersList();
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
      body: WillPopScope(
        onWillPop: () async {
          if (widget.isFromDrawer) {
            return CommonMethods.onBackPress(context);
          } else {
            return true;
          }
        },
        child: Stack(
          children: [
            SafeArea(
              child: Scaffold(
                  key: _scaffoldkey,
                  backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                  appBar: AppBar(
                      backgroundColor:
                          Colors.transparent, //(Constants.APP_COLOR),
                      centerTitle: true,
                      elevation: 0,
                      iconTheme: IconThemeData(color: theme.colorScheme.primary),
                      title: AppbarName(
                          title: Language().getString(
                              Constants.CONSUMABLE_GOODS_ISSUANCE, selectedLang),
                          buName: "$buName"),
                      // actions: [
                      //   (_productConsumptionPrivileges.view_create_raw_issue_note)
                      //       ? IconButton(
                      //           onPressed: () {
                      //             this.clearData();
                      //             this.showProductsView();
                      //           },
                      //           icon: Icon(
                      //             Icons.add,
                      //             color: Colors.white,
                      //           ))
                      //       : null
                      // ],
                      bottom: PreferredSize(
                        preferredSize: Size.fromHeight(
                            MediaQuery.of(context).size.height * 0.09),
                        child: TabBar(
                            indicatorSize: TabBarIndicatorSize.tab,
                            controller: _tabController,
                            indicator: BoxDecoration(
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.grey,
                                    blurRadius: 6.0,
                                  ),
                                  BoxShadow(
                                      color: Colors.white, offset: Offset(0, 9)),
                                ],
                                borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(10),
                                    topRight: Radius.circular(10)),
                                color: Colors.white),
                            tabs: [
                              Tab(
                                  child: Text(
                                Language().getString(
                                    Constants.REQUEST_FORMS, selectedLang),
                                style: TextStyle(
                                    color: theme.colorScheme.primary,
                                    fontWeight: StyleView.fontBold),
                              )),
                              Tab(
                                  child: Text(
                                Language().getString(
                                    Constants.ISSUANCE_NOTES, selectedLang),
                                style: TextStyle(
                                    color: theme.colorScheme.primary,
                                    fontWeight: StyleView.fontBold),
                              )),
                            ]),
                      )),
                  drawer: (widget.isFromDrawer) ? MyDrawer() : null,
                  body: TabBarView(
                      controller: _tabController,
                      physics: NeverScrollableScrollPhysics(),
                      children: [ConsumableRequetsPage(), ConsumableProductIssueListPage()])),
            ),
            AppUtills.showLoadingView(
                context: context,
                message: Language().getString(progressMessage, selectedLang),
                isLoading: isLoadingProgress),
          ],
        ),
      ),
    );
  }

  showProductsView() {
    return showDialog(
        context: context,
        barrierColor: Colors.black54,
        barrierDismissible: false,
        builder: (context) => StatefulBuilder(
                builder: (BuildContext context, StateSetter setState) {
              return Container(
                margin: EdgeInsets.symmetric(vertical: 20.0, horizontal: 10.0),
                child: Scaffold(
                    bottomNavigationBar: this.bottomView(),
                    backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                    body: Container(
                        margin: EdgeInsets.symmetric(
                            vertical: 10.0, horizontal: 10.0),
                        child: Column(
                          children: [
                            this.showProductSearchView(setState),
                            (_productsList.length > 0 && isShowProductName)
                                ? this.showProductNames(setState)
                                : Container(
                                    margin: EdgeInsets.symmetric(vertical: 5.0),
                                    child: (showProductText ==
                                                Constants.NO_DATA_FOUND ||
                                            showProductText == "")
                                        ? Text(Language().getString(
                                            showProductText, selectedLang))
                                        : Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              Text(Language().getString(
                                                  showProductText,
                                                  selectedLang)),
                                              Container(
                                                height: 10.0,
                                                width: 10.0,
                                                margin: EdgeInsets.symmetric(
                                                    horizontal: 5.0),
                                                child:
                                                    CircularProgressIndicator(
                                                  strokeWidth: 2.0,
                                                ),
                                              )
                                            ],
                                          ),
                                  ),
                            (selectedList.length > 0)
                                ? this.showSelectedProductsView(setState)
                                : Container(),
                          ],
                        ))),
              );
            }));
  }

  Widget bottomView() {
    return Container(
        margin: EdgeInsets.symmetric(horizontal: 10.0),
        child: Row(
          children: [
            Expanded(
              child: Container(
                margin: EdgeInsets.only(right: 1.0),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(Constants.APP_COLOR),
                  ),
                  onPressed: () {
                    clearData();
                    Navigator.of(context).pop();
                  },
                  child: Text(
                    Language().getString(Constants.STR_CANCEL, selectedLang),
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
            Expanded(
              child: Container(
                margin: EdgeInsets.only(left: 1.0),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      backgroundColor: Color(Constants.APP_COLOR)),
                  onPressed: () async {
                    if (selectedList.length == 0) {
                      Dialogs.yesCancelDialog(
                          context,
                          Language().getString(Constants.ERROR, selectedLang),
                          Language().getString(
                              Constants.SELECT_PRODUCTS, selectedLang),
                          Language()
                              .getString(Constants.OKAY_STR, selectedLang),
                          "",
                          false);
                    } else {
                      this.showIssueUsersList();
                    }
                  },
                  child: Text(
                    Language().getString(Constants.CONTINUE, selectedLang),
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
          ],
        ));
  }

  loadProductData(String productName, StateSetter setState) async {
    if (await NetworkStatus.getInternetStatus()) {
      this.getBuProducts(productName: productName).then((onValue) {
        setState(() {
          responseProducts.clear();
          _productsList.clear();
          responseProducts.addAll(onValue);
          if (responseProducts.length > 0) {
            for (int i = 0; i < responseProducts.length; i++) {
              if (responseProducts[i].batchPrice!.length > 0) {
                showProductText = "";

                _productsList.add(ModelProduct(
                    id: responseProducts[i].id,
                    name: responseProducts[i].name,
                    counter: 0,
                    isButton: false,
                    images: responseProducts[i].imageThumbnail!.length > 0
                        ? responseProducts[i].imageThumbnail![0].image
                        : null,
                    price: 0,
                    quantity: responseProducts[i].batchPrice![0].quantity,
                    isItemSelected: false,
                    unitPrice: responseProducts[i].batchPrice![0].price,
                    offerList: responseProducts[i].offers,
                    batchPriceList: responseProducts[i].batchPrice));

                isShowProductName = true;
              } else {
                showProductText = Constants.NO_DATA_FOUND;
              }
            }
          } else {
            showProductText = Constants.NO_DATA_FOUND;
          }
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<BuProductModal>> getBuProducts({String productName = ""}) async {
    String body = json.encode({
      "id": buId,
      "filter": {"name": productName, "is_consumable": true}
    });

    var response = await _productService
        .getProductByBuId_v2(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<BuProductModal> products = [];

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      var data = resObj['results'];
      for (var i in data) {
        products.add(BuProductModal.fromJson(i));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return products;
  }

  removeProductsQuantity(int index, StateSetter setState) {
    int? countDecrement = selectedList[index].counter;
    setState(() {
      if (countDecrement! > 1) {
        countDecrement = countDecrement! - 1;
        selectedList[index].counter = countDecrement;

        setState(() {
          selectedList[index].counter = countDecrement;
          _enterProductCount[index] = TextEditingController(
              text: selectedList[index].counter.toString());
          _enterProductCount[index].selection = TextSelection.fromPosition(
              TextPosition(offset: _enterProductCount[index].text.length));
        });
      }
    });
  }

  addProductsQuantity(int index, StateSetter setState) {
    int? countIncrement = selectedList[index].counter;

    if (countIncrement == 1) {
      setState(() {
        countIncrement = countIncrement! + 1;
        selectedList[index].counter = countIncrement;

        _enterProductCount[index] =
            TextEditingController(text: selectedList[index].counter.toString());
        _enterProductCount[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _enterProductCount[index].text.length));
      });
    } else {
      setState(() {
        countIncrement = countIncrement! + 1;
        selectedList[index].counter = countIncrement;

        _enterProductCount[index] =
            TextEditingController(text: selectedList[index].counter.toString());
        _enterProductCount[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _enterProductCount[index].text.length));
      });
    }
  }

  designQuantityInputField(int index, StateSetter setState) {
    return Container(
      height: 60.0,
      width: 60.0,
      child: TextFormField(
        enableInteractiveSelection: false,
        textAlign: TextAlign.center,
        controller: _enterProductCount[index],
        decoration: InputDecoration(
          hintText: "",
          border: InputBorder.none,
        ),
        keyboardType: TextInputType.numberWithOptions(signed: true),
        style: TextStyle(fontSize: 12.0),
        inputFormatters: [
          new LengthLimitingTextInputFormatter(5),
          FilteringTextInputFormatter.digitsOnly
        ],
        onFieldSubmitted: (value) {
          if (value == "0" || value.isEmpty) {
            selectedList[index].counter = 1;
          }
        },
        onChanged: (value) {
          setState(() {
            if (selectedList.length > 0) {
              if (value.isEmpty) {
                selectedList[index].counter = 0;
              } else {
                selectedList[index].counter = int.parse(value);
              }
            }
          });
        },
      ),
    );
  }

  getUsersList({String name = ""}) async {
    if (await NetworkStatus.getInternetStatus()) {
      this.getAllUsers(name: name).then((value) {
        setState(() {
          _usersList.clear();
          _usersList.addAll(value);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  /// Service call for getUsers
  Future<List<UserModel>> getAllUsers({String name = ""}) async {
    setState(() {
      _usersList.clear();
    });
    String body = json.encode({"id": buId, "filters": {}});

    var response = await _userService
        .getUserByBuId_grpc(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    List<UserModel> _users = [];
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      var resultArray = resObj['results'];
      for (var data in resultArray) {
        _users.add(UserModel.fromJson(data));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return _users;
  }

  showIssueUsersList() {
    return showDialog(
        context: context,
        barrierColor: Colors.black54,
        barrierDismissible: false,
        builder: (context) =>
            StatefulBuilder(builder: (context, StateSetter setState) {
              return Container(
                margin: EdgeInsets.symmetric(vertical: 20.0, horizontal: 10.0),
                child: Scaffold(
                    bottomNavigationBar: Container(
                        margin: EdgeInsets.symmetric(horizontal: 10.0),
                        child: Row(
                          children: [
                            Expanded(
                              child: Container(
                                margin: EdgeInsets.only(right: 1.0),
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Color(Constants.APP_COLOR),
                                  ),
                                  onPressed: () {
                                    issuedToDropdownValue = null;
                                    _purposeController.clear();
                                    Navigator.of(context).pop();
                                  },
                                  child: Text(
                                    Language().getString(
                                        Constants.STR_CANCEL, selectedLang),
                                    style: TextStyle(color: Colors.white),
                                  ),
                                ),
                              ),
                            ),
                            Expanded(
                              child: Container(
                                margin: EdgeInsets.only(left: 1.0),
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Color(Constants.APP_COLOR),
                                  ),
                                  onPressed: () async {
                                    if (issuedToDropdownValue == null) {
                                      Dialogs.yesCancelDialog(
                                          context,
                                          Language().getString(
                                              Constants.ERROR, selectedLang),
                                          Language().getString(
                                              Constants.SELECT_USER,
                                              selectedLang),
                                          Language().getString(
                                              Constants.OKAY_STR, selectedLang),
                                          "",
                                          false);
                                    } else {
                                      Navigator.of(context).pop();
                                      Navigator.of(context).pop();
                                      this.createRawProductIssueList();
                                    }
                                  },
                                  child: Text(
                                    Language().getString(
                                        Constants.CONFIRM, selectedLang),
                                    style: TextStyle(color: Colors.white),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        )),
                    backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                    body: Container(
                        margin: EdgeInsets.symmetric(
                            vertical: 10.0, horizontal: 10.0),
                        child: Column(
                          children: [
                            Container(
                              margin: EdgeInsets.symmetric(vertical: 5.0),
                              child: Text(
                                Language().getString(
                                    Constants.ISSUING_DETAILS, selectedLang),
                                style: TextStyle(
                                    color: Color(Constants.APP_COLOR),
                                    fontSize: 15.0,
                                    fontWeight: FontWeight.bold),
                              ),
                            ),
                            // this.buildDropdownIssueTo(setState),
                            Expanded(
                              child: Container(
                                margin: EdgeInsets.symmetric(vertical: 5.0),
                                child: TextFormField(
                                    controller: _purposeController,
                                    style: TextStyle(
                                        fontFamily: StyleView.FONT_TITLE),
                                    decoration: StyleView.getInputDecoration(
                                        helper: Language().getString(
                                            Constants.PURPOSE, selectedLang)),
                                    maxLines: 3),
                              ),
                            ),
                          ],
                        ))),
              );
            }));
  }

  // buildDropdownIssueTo(StateSetter setState) {
  //   return Container(
  //     margin: EdgeInsets.symmetric(vertical: 5.0),
  //     decoration: AppUtills.boxDecoration(),
  //     child: SearchableDropdown.single(
  //       items: _usersList.map((UserModel model) {
  //         return new DropdownMenuItem<UserModel>(
  //           child: new Text(model.name),
  //           value: model,
  //         );
  //       }).toList(),
  //       value: issuedToDropdownValue,
  //       underline: Container(),
  //       hint: Language().getString(Constants.ISSUED_TO, selectedLang),
  //       searchHint: Language().getString(Constants.ISSUED_TO, selectedLang),
  //       onChanged: (value) {
  //         setState(() {
  //           issuedToDropdownValue = value;
  //         });
  //       },
  //       isExpanded: true,
  //     ),
  //   );
  // }

  createRawProductIssueList() async {
    setState(() {
      isLoadingProgress = true;
    });
    List<Map<String, dynamic>> productsArrayList = [];
    var object;
    if (selectedList.length > 0) {
      for (int i = 0; i < selectedList.length; i++) {
        object = {
          "id": selectedList[i].id,
          "quantity": selectedList[i].counter,
          "batch_no": batchPricingDropdownList[i]!.batchNumber,
          "quantity_in": quantityInDropdownValue[i]
        };
        productsArrayList.add(object);
      }
    }

    String body = json.encode({
      "bu_id": buId,
      "issued_purpose": _purposeController.text,
      "issued_to": issuedToDropdownValue!.name,
      "products": productsArrayList
    });

    var response = await _productService
        .createRawProductIssue(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
    });

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          Language().getString(Constants.ISSUANCE_CREATED, selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);

      if (action == DialogAction.yes) {
        this.clearData();
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  Widget showProductNames(StateSetter setState) {
    return Container(
        height: 100.0,
        decoration: BoxDecoration(
          color: Colors.grey[400],
          borderRadius: BorderRadius.circular(5.0),
        ),
        child: ListView.builder(
          itemBuilder: (context, index) {
            return InkWell(
              onTap: () {
                CommonMethods.hideKeyboard(context);
                setState(() {
                  quantityController.text = "1";
                  _productsList[index].counter =
                      int.parse(quantityController.text);
                  productNameController.text = _productsList[index].name!;
                  isShowProductName = false;
                  _selectedProductData = _productsList[index];
                });
              },
              child: Card(
                color: Colors.grey[100],
                elevation: 2.5,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(_productsList[index].name!,
                          style: TextStyle(color: Colors.black)),
                      Icon(Icons.arrow_forward, color: Colors.blue, size: 20.0),
                    ],
                  ),
                ),
              ),
            );
          },
          itemCount: _productsList.length,
          shrinkWrap: true,
        ));
  }

  batchPricingDropdownView(
      List<BatchPriceDAO> batchNumberList, int index, StateSetter setState) {
    if (batchNumberList.length > 0 && batchPricingDropdownList.length > 0) {
      if (batchPricingDropdownList[index] == null) {
        batchPricingDropdownList[index] = batchNumberList[0];
      }

      return Expanded(
        child: BatchPriceDropDownView(
            canShowPrice: false,
            canShowDynamicPricing: false,
            currentDropdownIndex: index,
            batchPricingList: batchNumberList,
            batchDropdown: batchPricingDropdownList,
            selectedDropdownValue: (data) {
              setState(() {
                batchPricingDropdownList[index] = data;
              });
            },
            strBatchPricing:
                Language().getString(Constants.BATCH_NO, selectedLang),
            strAvailableQuantity: Language()
                .getString(Constants.AVAILABLE_QUANTITY, selectedLang)),
      );
    }
  }

  batchQuantityUnitsropdownView(int index, StateSetter setState) {
    if (quantityInDropdownValue[index] == null) {
      quantityInDropdownValue[index] = "unit";
    }
    return Expanded(
      child: Row(
        children: [
          Container(
              child: Text(
                  Language().getString(Constants.QUANTITY_IN, selectedLang) +
                      " : ",
                  style: TextStyle(
                      fontSize: 14.0,
                      fontWeight: FontWeight.bold,
                      color: Color(Constants.APP_COLOR)))),
          Expanded(
              child: Container(
                  color: Colors.white,
                  padding: EdgeInsets.only(left: 5),
                  child: DropdownButton<String>(
                      onTap: () {
                        return CommonMethods.hideKeyboard(context);
                      },
                      value: quantityInDropdownValue[index],
                      hint: new Text(
                        Language().getString(Constants.SELECT, selectedLang),
                      ),
                      underline: SizedBox(),
                      onChanged: (String? data) {
                        setState(() {
                          quantityInDropdownValue[index] = data;
                        });
                      },
                      items: Constants.UNIT_PRICE.map((String model) {
                        return new DropdownMenuItem<String>(
                          child: new Text(model),
                          value: model,
                        );
                      }).toList()))),
        ],
      ),
    );
  }

  addToInvoiceProductsArray(StateSetter setState) {
    setState(() {
      bool isExist = false;
      int index = -1;
      for (int i = 0; i < selectedList.length; i++) {
        if (_selectedProductData!.id == selectedList[i].id) {
          isExist = true;
          index = i;
        }
      }

      if (isExist) {
        selectedList[index].counter =
            selectedList[index].counter! + int.parse(quantityController.text);

        _enterProductCount[index] =
            TextEditingController(text: selectedList[index].counter.toString());
        _enterProductCount[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _enterProductCount[index].text.length));
      } else {
        selectedList.add(ModelProduct(
            name: _selectedProductData!.name,
            id: _selectedProductData!.id,
            price: _selectedProductData!.price,
            counter: int.parse(quantityController.text),
            images: _selectedProductData!.images,
            isButton: _selectedProductData!.isButton,
            isItemSelected: _selectedProductData!.isItemSelected,
            batchPriceList: _selectedProductData!.batchPriceList,
            unitPrice: _selectedProductData!.unitPrice,
            quantity: _selectedProductData!.quantity));

        _enterProductCount.add(new TextEditingController());
        batchPricingDropdownList.add(null);
        quantityInDropdownValue.add(null);
      }

      _selectedProductData = null;
      productNameController.clear();
      quantityController.clear();
    });
  }

  Widget showSelectedProductsView(StateSetter setState) {
    return Expanded(
        child: Container(
      margin: EdgeInsets.only(top: 5.0),
      decoration: AppUtills.boxDecoration(),
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.all(5.0),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    Language().getString(Constants.PRODUCT_NAME, selectedLang),
                    style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                        fontWeight: FontWeight.bold),
                  ),
                ),
                Expanded(
                  child: Text(
                    Language().getString(Constants.QUANTITY, selectedLang),
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
          ),
          Divider(
            color: Color(Constants.APP_COLOR),
          ),
          Expanded(
            child: ListView.separated(
                shrinkWrap: true,
                separatorBuilder: (context, index) => new Divider(
                      color: Colors.transparent,
                      height: 0.0,
                    ),
                itemCount: selectedList.length,
                itemBuilder: (context, index) {
                  _enterProductCount[index] = TextEditingController(
                      text: selectedList[index].counter.toString());
                  _enterProductCount[index].selection =
                      TextSelection.fromPosition(TextPosition(
                          offset: _enterProductCount[index].text.length));
                  return Card(
                    child: Column(
                      children: [
                        ProductsCardView(
                          onRemoveProductQuantit: () {
                            removeProductsQuantity(index, setState);
                          },
                          onAddProductQuantity: () {
                            addProductsQuantity(index, setState);
                          },
                          desingQuntityField: Container(
                            width: 50.0,
                            height: 30.0,
                            alignment: Alignment.bottomCenter,
                            decoration: AppUtills.boxDecoration(),
                            child:
                                this.designQuantityInputField(index, setState),
                          ),
                          productName: selectedList[index].name,
                          removeProduct: () async {
                            final action = await Dialogs.yesCancelDialog(
                                context,
                                Language()
                                    .getString(Constants.WARNING, selectedLang),
                                Language().getString(
                                    Constants.WARNING_TEXT, selectedLang),
                                Language().getString(
                                    Constants.OKAY_STR, selectedLang),
                                "",
                                false);

                            if (action == DialogAction.yes) {
                              setState(() {
                                selectedList.removeAt(index);
                                batchPricingDropdownList.removeAt(index);
                                quantityInDropdownValue.removeAt(index);
                              });
                            }
                          },
                          productTotalPrice: 0,
                          isFromRawProductIssuePage: true,
                        ),
                        Container(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              (batchPricingDropdownList.length > 0)
                                  ? this.batchPricingDropdownView(
                                      selectedList[index].batchPriceList!,
                                      index,
                                      setState)
                                  : Container(),
                            ],
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.symmetric(horizontal: 5.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              (quantityInDropdownValue.length > 0)
                                  ? this.batchQuantityUnitsropdownView(
                                      index, setState)
                                  : Container()
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                }),
          )
        ],
      ),
    ));
  }

  clearData() {
    setState(() {
      _productsList.clear();
      batchPricingDropdownList.clear();
      _enterProductCount.clear();
      productNameController.clear();
      quantityController.clear();
      _selectedProductData = null;
      selectedList.clear();
      showProductText = "";
      _purposeController.clear();
      issuedToDropdownValue = null;
    });
  }

  Widget showProductSearchView(StateSetter setState) {
    return Container(
      decoration: AppUtills.boxDecoration(),
      margin: EdgeInsets.only(top: 5.0),
      height: 40.0,
      alignment: Alignment.centerLeft,
      child: Container(
        color: Colors.grey,
        alignment: Alignment.centerLeft,
        child: Row(
          children: [
            Expanded(
              flex: 2,
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(5.0),
                      bottomLeft: Radius.circular(5.0)),
                  color: Color(Constants.APP_BACKGROUND_COLOR),
                ),
                margin: EdgeInsets.only(right: 1.0),
                child: Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: TextField(
                    controller: productNameController,
                    keyboardType: TextInputType.text,
                    // focusNode: FocusNode(),
                    decoration: InputDecoration(
                        hintText: Language().getString(
                            Constants.SEARCH_BY_PRODUCT, selectedLang),
                        hintStyle: TextStyle(fontSize: 12.0),
                        border: InputBorder.none),
                    onChanged: (_text) {
                      if (_text.isNotEmpty) {
                        setState(() {
                          showProductText = Constants.LOADING;
                        });

                        this.loadProductData(_text, setState);
                      } else {
                        setState(() {
                          showProductText = "";
                          isShowProductName = false;
                          _productsList.clear();
                        });
                      }
                    },
                    style: TextStyle(
                        fontSize: 12.0, decoration: TextDecoration.none),
                  ),
                ),
              ),
            ),
            Expanded(
              child: Container(
                color: Color(Constants.APP_BACKGROUND_COLOR),
                margin: EdgeInsets.only(right: 1.0),
                child: Padding(
                  padding: const EdgeInsets.all(2.0),
                  child: TextFormField(
                    controller: quantityController,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: Language()
                          .getString(Constants.QUANTITY, selectedLang),
                      hintStyle: TextStyle(fontSize: 12.0),
                    ),
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 12.0),
                  ),
                ),
              ),
            ),
            SizedBox(
              width: 30.0,
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                      topRight: Radius.circular(5.0),
                      bottomRight: Radius.circular(5.0)),
                  color: Color(Constants.APP_BACKGROUND_COLOR),
                ),
                child: IconButton(
                    padding: EdgeInsets.all(0.0),
                    icon: Icon(
                      Icons.add,
                    ),
                    onPressed: () {
                      if (_selectedProductData != null) {
                        if (_selectedProductData!.counter == 0) {
                          Dialogs.yesCancelDialog(
                              context,
                              Language()
                                  .getString(Constants.ERROR, selectedLang),
                              Language().getString(
                                  Constants.ENTER_VALID_QUANTITY, selectedLang),
                              Language()
                                  .getString(Constants.OKAY_STR, selectedLang),
                              "",
                              false);
                        } else {
                          this.addToInvoiceProductsArray(setState);
                        }
                      }

                      return CommonMethods.hideKeyboard(context);
                    }),
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget showDownloadButton() {
    String reqBody = "";
    String reqUrl = "";
    reqUrl = Constants.NEW_BASE_URL + "http-utils/reports/rawIssueNotes";
    reqBody = json.encode({
      "bu_id": buId,
      "filters": {
        "name": _searchController.text,
        "DateFrom": fromDate,
        "DateTo": toDate
      }
    });

    var encryptedData = VyaparInfo.encryptData(reqBody);
    Map map = {
      "data": encryptedData,
      "Authorization": AppController.instance.getAuthorizationKey
    };
    return DownloadAllReportsPage(
        isApiCallComplete: (apiCallCompleted) {
          if (apiCallCompleted) {
            setState(() {
              isLoadingProgress = false;
            });
          } else {
            setState(() {
              isLoadingProgress = true;
            });
          }
        },
        url: reqUrl,
        mapData: map,
        fileName: Constants.RAW_MARETIAL_ISSUE,
        strDownload: Language().getString(Constants.DOWNLOAD, selectedLang));
  }
}
