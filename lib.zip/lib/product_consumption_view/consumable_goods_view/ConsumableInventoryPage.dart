import 'dart:async';

import 'package:vyaparlive/Home/HomePageView.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Product/EditMyProduct.dart';
import 'package:vyaparlive/Product/ProductDetailsPage.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/MyDrawer.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/product_model/BatchPriceDAO.dart';
import 'package:vyaparlive/model/product_model/InventoryDetailsDAO.dart';
import 'package:vyaparlive/model/product_model/ProductModel.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'dart:convert';

import 'package:vyaparlive/service/product_services.dart';

import '../../core/enums/privilleges_enum.dart';

class ConsumableMaterialInventoryPage extends StatefulWidget {
  final bool isAppBarVisible;
  final bool isFromReports;
  final String? productId;
  ConsumableMaterialInventoryPage(
      {this.isAppBarVisible = false,
      this.isFromReports = false,
      this.productId = ""});

  @override
  _ConsumableMaterialInventoryPageState createState() =>
      _ConsumableMaterialInventoryPageState();
}

class _ConsumableMaterialInventoryPageState extends State<ConsumableMaterialInventoryPage> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String fromrange = "";
  String torange = "";
  String? buId = "";
  String? buName = "";
  List<BuProductModal> _productsList = [];
  final _searchController = TextEditingController();
  bool isLoading = false;
  bool isLoadingProgress = true;
  String progressMessage = Constants.GETTING_DATA;
  static String showLoaderText = Constants.NO_DATA_FOUND;
  late ProductService _productService;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  List<num> batchQuantityList = [];
  num totalBatchQuantity = 0;
  ScrollController? _scrollController;
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _scrollController = new ScrollController();
    _productService = ProductService();
    buId = AppController.instance.getMyBuId;
    buName = AppController.instance.getBuName;
    loadProducts("");
  }

  loadProducts(String productName) async {
    if (await NetworkStatus.getInternetStatus()) {
      getBuProducts(productName).then((value) {
        setState(() {
          if (value.length > 0) {
            _productsList.clear();
            _productsList.addAll(value);

            /// Adding all batch items quantity
            for (int i = 0; i < _productsList.length; i++) {
              if (_productsList[i].batchPrice!.length > 0) {
                totalBatchQuantity = 0;
                for (int j = 0; j < _productsList[i].batchPrice!.length; j++) {
                  totalBatchQuantity = totalBatchQuantity +
                      _productsList[i].batchPrice![j].quantity!;
                }
                batchQuantityList.add(totalBatchQuantity);
              } else {
                batchQuantityList.add(0);
              }
            }
          } else {
            _productsList.clear();
            showLoaderText = Constants.NO_DATA_FOUND;
          }
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
      body: WillPopScope(
        onWillPop: () async {
          if (widget.isAppBarVisible && widget.isFromReports) {
            return true;
          } else {
            return CommonMethods.onBackPress(context);
          }
        },
        child: Stack(
          children: [
            SafeArea(
              child: Scaffold(
                backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                appBar: (widget.isAppBarVisible)
                    ? AppBar(
                        iconTheme:
                            IconThemeData(color: theme.colorScheme.primary),
                        elevation: 0,
                        backgroundColor:
                            Colors.transparent, //(Constants.APP_COLOR),
                        centerTitle: true,
                        leading: IconButton(
                            onPressed: () async {
                              if (widget.isAppBarVisible &&
                                  widget.isFromReports) {
                                return Navigator.of(context).pop();
                              } else {
                                Navigator.pushAndRemoveUntil(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => HomePageView()),
                                    (Route<dynamic> route) => false);
                              }
                            },
                            icon: Icon(Icons.arrow_back)),
                        title: AppbarName(
                            title: Language().getString(
                                Constants.INVENTORY_LOCATION, selectedLang),
                            buName: "$buName"),
                      )
                    : null,
                drawer: (widget.isAppBarVisible) ? null : MyDrawer(),
                body: Container(
                  margin: EdgeInsets.symmetric(vertical: 5.0, horizontal: 5.0),
                  color: Color(Constants.APP_BACKGROUND_COLOR),
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        Container(
                          height: 50.0,
                          margin: EdgeInsets.all(10),
                          child: Card(
                            shadowColor: theme.colorScheme.primary,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20),
                                side: BorderSide(
                                    color: theme.colorScheme.primary,
                                    strokeAlign: 0.01)),
                            child: Padding(
                              padding: EdgeInsets.only(left: 15),
                              child: TextField(
                                  controller: _searchController,
                                  style: TextStyle(
                                      fontWeight: StyleView.fontSemiBold),
                                  decoration: new InputDecoration(
                                      contentPadding: EdgeInsets.only(bottom: 10),
                                      hintText: Language().getString(
                                          Constants.SEARCH_BY_PRODUCT,
                                          selectedLang),
                                      hintStyle: TextStyle(
                                          fontSize: 13.0,
                                          fontWeight: StyleView.fontSemiBold),
                                      border: InputBorder.none),
                                  onChanged: onSearchTextChanged),
                            ),
                          ),
                        ),
                        Expanded(
                          child: _productsList.length == 0
                              ? Center(
                                  child: Text(Language()
                                      .getString(showLoaderText, selectedLang)))
                              : Container(
                                  padding: EdgeInsets.all(10),
                                  child: AnimationLimiter(
                                      child: ListView.separated(
                                          controller: _scrollController,
                                          shrinkWrap: true,
                                          cacheExtent: 9999,
                                          physics: BouncingScrollPhysics(
                                              parent:
                                                  AlwaysScrollableScrollPhysics()),
                                          itemCount: _productsList.length,
                                          separatorBuilder:
                                              (BuildContext context, int index) =>
                                                  Divider(
                                                      height: 1.0,
                                                      color: Colors.transparent),
                                          itemBuilder:
                                              (BuildContext ctxt, int index) {
                                            return AnimationConfiguration
                                                .staggeredList(
                                                    position: index,
                                                    child: SlideAnimation(
                                                        verticalOffset: 50.0,
                                                        child: FadeInAnimation(
                                                            child: InkWell(
                                                                onTap: () {
                                                                  Navigator.push(
                                                                      context,
                                                                      PageTransition(
                                                                          context:
                                                                              context,
                                                                          page:
                                                                              ProductDetailsPage(
                                                                            productId:
                                                                                _productsList[index].id,
                                                                            currentBuId:
                                                                                buId,
                                                                            isShowBasicDetails: widget.isFromReports
                                                                                ? true
                                                                                : false,
                                                                          )));
                                                                },
                                                                child:
                                                                    listRowEditUpdate(
                                                                        index)))));
                                          })),
                                ),
                        ),
                      ]),
                ),
              ),
            ),
            AppUtills.showLoadingView(
                context: context,
                message: Language().getString(progressMessage, selectedLang),
                isLoading: isLoadingProgress),
          ],
        ),
      ),
    );
  }

  Widget listRowEditUpdate(int index) {
    if (_productsList[index].inventoryData!.length > 0) {
      return Card(
          child: ExpansionTile(
              leading: Container(
                  height: 70.0,
                  width: 70.0,
                  child: CachedNetworkImage(
                      imageUrl:
                          '${Constants.IAMGE_BUCKET_URL}${_productsList[index].images}',
                      // placeholder: (context, url) => SizedBox(
                      //       width: 5,
                      //       height: 5,
                      //       child: CircularProgressIndicator(),
                      //     ),
                      errorWidget: (context, url, error) => Icon(Icons.error),
                      width: 70.0,
                      height: 70.0,
                      fit: BoxFit.cover)),
              children: <Widget>[
                for (int i = 0;
                    i < _productsList[index].inventoryData!.length;
                    i++)
                  Container(
                    margin: EdgeInsets.symmetric(horizontal: 10.0),
                    child: showInventoryLocationsData(
                        _productsList[index]
                            .inventoryData![i]
                            .locationBatchList!,
                        _productsList[index].inventoryData![i].locationName),
                  )
              ],
              title: Container(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Expanded(
                        flex: 3,
                        child: showProductDetails(_productsList[index], index)),
                  ],
                ),
              )));
    } else {
      return nonExpanssionCardDesign(index);
    }

    //
  }

  nonExpanssionCardDesign(int index) {
    int availableQuantity = 0;
    String? quantityIn = Constants.UNIT_PRICE[0];
    for (int i = 0; i < _productsList[index].batchPrice!.length; i++) {
      if (_productsList[index].batchPrice![i].quantity != 0) {
        availableQuantity = availableQuantity +
            (_productsList[index].batchPrice![i].quantity as int);
        quantityIn = _productsList[index].batchPrice![i].quantityIn;
      }
    }

    // print("product image ${_productsList[index].images}");
    return Card(
        child: ExpansionTile(
            leading: Container(
                height: 70.0,
                width: 70.0,
                child: CachedNetworkImage(
                    imageUrl:
                        '${Constants.IAMGE_BUCKET_URL}${_productsList[index].images}',
                    // placeholder: (context, url) => SizedBox(
                    //       width: 5,
                    //       height: 5,
                    //       child: CircularProgressIndicator(),
                    //     ),
                    errorWidget: (context, url, error) => Icon(Icons.error),
                    width: 70.0,
                    height: 70.0,
                    fit: BoxFit.cover)),
            children: <Widget>[],
            trailing: const SizedBox(),
            title: Container(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Expanded(
                    flex: 3,
                    child: Container(
                      margin: EdgeInsets.symmetric(horizontal: 5.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Row(
                            children: <Widget>[
                              new Expanded(
                                flex: 3,
                                child: Container(
                                  child: Text(
                                    _productsList[index].name!,
                                    style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 16.0,
                                        fontWeight: StyleView.fontBold),
                                  ),
                                ),
                              ),
                              if (!widget.isFromReports &&
                                  CommonMethods.isPrivillegeExist(
                                      context,
                                      PrivillegesActions
                                          .CONSUMABLE_MATERIAL_MENU_CONSUMABLE_MATERIAL_INVENTORY_EDIT))
                                Expanded(
                                  child: Container(
                                    alignment: Alignment.centerLeft,
                                    child: InkWell(
                                        onTap: () {
                                          Navigator.push(
                                              context,
                                              new MaterialPageRoute(
                                                  builder: (context) =>
                                                      EditMyProductPage(
                                                        title: Constants
                                                            .UPDATE_PRODUCT,
                                                        buId:
                                                            _productsList[index]
                                                                .buId,
                                                        productId:
                                                            _productsList[index]
                                                                .id,
                                                      ))).then(
                                              (value) => this.loadProducts(""));
                                        },
                                        child: Icon(
                                          FeatherIcons.edit,
                                          size: 18,
                                          color: theme.colorScheme.primary,
                                        )),
                                  ),
                                ),
                            ],
                          ),
                          SizedBox(height: 5),
                          if (_productsList[index].batchPrice!.length > 0)
                            Row(
                              children: [
                                Expanded(
                                  flex: 2,
                                  child: Container(
                                    child: Text(
                                      Language().getString(
                                          Constants
                                              .QUANTITY_NOT_ASSIGNED_TO_LOCATION,
                                          selectedLang),
                                      style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 13.0,
                                          fontWeight: StyleView.fontSemiBold),
                                    ),
                                  ),
                                ),
                                Text(" :  "),
                                Expanded(
                                  child: Container(
                                    child: Text(
                                      "$availableQuantity $quantityIn",
                                      style: TextStyle(
                                          fontSize: 12,
                                          fontWeight: StyleView.fontMedium),
                                    ),
                                  ),
                                ),
                              ],
                            )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            )));
  }

  Future<List<BuProductModal>> getBuProducts(String productName) async {
    String body = json.encode({
      "id": buId,
      "filter": {"name": productName, "is_consumable": true}
    });

    var response = await _productService
        .getProductByBuId_v2(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    isLoading = true;

    List<BuProductModal> _products = [];
    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      var data = resObj['results'];
      for (var i in data) {
        _products.add(BuProductModal.fromJson(i));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return _products;
  }

  onSearchTextChanged(String text) async {
    showLoaderText = Constants.LOADING;
    if (text.isEmpty) {
      loadProducts("");
    } else {
      loadProducts(text);
    }
  }

  Widget showInventoryLocationsData(
      List<BatchPriceDAO> locationData, String? locationName) {
    List<InventoryDetailsDAO> _locationBatchData = [];
    for (int i = 0; i < locationData.length; i++) {
      _locationBatchData.add(InventoryDetailsDAO(
          batchNumber: locationData[i].batchNumber,
          quantityIn: locationData[i].quantityIn,
          quantity: locationData[i].quantity));
    }

    return Column(
      children: [
        for (int i = 0; i < _locationBatchData.length; i++)
          Card(
              elevation: 5.0,
              child: Container(
                padding: EdgeInsets.all(5.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    new Container(
                      margin: EdgeInsets.symmetric(vertical: 3.0),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              Language()
                                  .getString(Constants.LOCATION, selectedLang),
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 14.0,
                                  fontWeight: StyleView.fontSemiBold),
                            ),
                          ),
                          Text("  : "),
                          Expanded(
                            flex: 2,
                            child: Container(
                              child: Text(
                                "$locationName",
                                style: TextStyle(
                                    color: Colors.black,
                                    fontWeight: StyleView.fontRegular,
                                    fontSize: 13.0),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    new Container(
                      margin: EdgeInsets.symmetric(vertical: 3.0),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                                Language().getString(
                                    Constants.QUANTITY, selectedLang),
                                style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 14.0,
                                    fontWeight: StyleView.fontSemiBold)),
                          ),
                          Text("  : "),
                          Expanded(
                            flex: 2,
                            child: Text(
                                "${_locationBatchData[i].quantity} ${_locationBatchData[i].quantityIn}",
                                style: TextStyle(
                                    color: Colors.black,
                                    fontWeight: StyleView.fontRegular,
                                    fontSize: 13.0)),
                          ),
                        ],
                      ),
                    ),
                    new Container(
                      margin: EdgeInsets.symmetric(vertical: 3.0),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                                Language().getString(
                                    Constants.BATCH_NO, selectedLang),
                                style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 14.0,
                                    fontWeight: StyleView.fontSemiBold)),
                          ),
                          Text("  : "),
                          Expanded(
                            flex: 2,
                            child: Text("${_locationBatchData[i].batchNumber}",
                                style: TextStyle(
                                    color: Colors.black,
                                    fontWeight: StyleView.fontRegular,
                                    fontSize: 13.0)),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ))
      ],
    );
  }

  Widget showProductDetails(BuProductModal productData, int index) {
    num inventoryTotal = 0;
    num remainingQuantity = 0;
    String? quantityIn = Constants.UNIT_PRICE[0];
    for (int i = 0; i < productData.inventoryData!.length; i++) {
      for (int j = 0;
          j < productData.inventoryData![i].locationBatchList!.length;
          j++) {
        // if (productData.inventoryData![i].locationBatchList![j].quantity != 0) {
        inventoryTotal = inventoryTotal +
            productData.inventoryData![i].locationBatchList![j].quantity!;
        remainingQuantity = batchQuantityList[index] - inventoryTotal;
        quantityIn =
            productData.inventoryData![i].locationBatchList![j].quantityIn;
        // }
      }
    }
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 5.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Expanded(
                flex: 3,
                child: Container(
                  child: Text(
                    productData.name!,
                    style: TextStyle(
                        color: Colors.black,
                        fontWeight: StyleView.fontBold,
                        fontSize: 16),
                  ),
                ),
              ),
              if (!widget.isFromReports &&
                  CommonMethods.isPrivillegeExist(
                      context, PrivillegesActions.CONSUMABLE_MATERIAL_MENU_CONSUMABLE_MATERIAL_INVENTORY_EDIT))
                Expanded(
                  child: Container(
                    alignment: Alignment.centerLeft,
                    child: InkWell(
                        onTap: () {
                          Navigator.push(
                                  context,
                                  new MaterialPageRoute(
                                      builder: (context) => EditMyProductPage(
                                            title: Constants.UPDATE_PRODUCT,
                                            buId: productData.buId,
                                            productId: productData.id,
                                          )))
                              .then((value) => this.loadProducts(""));
                        },
                        child: Container(
                          child: Icon(
                            FeatherIcons.edit,
                            size: 18,
                            color: theme.colorScheme.primary,
                          ),
                        )),
                  ),
                ),
            ],
          ),
          SizedBox(height: 5),
          if (productData.batchPrice!.length > 0)
            new Container(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    child: Row(
                      children: [
                        Expanded(
                          flex: 2,
                          child: Container(
                            child: Text(
                              Language().getString(
                                  Constants.ASSIGNED_QUANTITY_TO_LOCATION,
                                  selectedLang),
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 13.0,
                                  fontWeight: StyleView.fontSemiBold),
                            ),
                          ),
                        ),
                        Text("  :   "),
                        Expanded(
                          child: Container(
                            child: Text(
                              "$inventoryTotal $quantityIn",
                              style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: StyleView.fontMedium),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 5),
                  Container(
                    child: Row(
                      children: [
                        Expanded(
                          flex: 2,
                          child: Container(
                            child: Text(
                              Language().getString(
                                  Constants.QUANTITY_NOT_ASSIGNED_TO_LOCATION,
                                  selectedLang),
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 13.0,
                                  fontWeight: StyleView.fontSemiBold),
                            ),
                          ),
                        ),
                        Text("  :   "),
                        Expanded(
                          child: Container(
                            child: Text(
                              "$remainingQuantity $quantityIn",
                              style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: StyleView.fontMedium),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            )
        ],
      ),
    );
  }

  Future<List<BuProductModal>> getProuctById() async {
    String body = json.encode({"id": widget.productId, "buId": buId});

    var response = await _productService
        .getProductDetailsByProductId_grpc(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          "$onError",
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<BuProductModal> data = [];

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      data.add(BuProductModal.fromJson(resObj[0]));
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
      return data;
  }
}
