import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/model/RawProductsIssueDAO.dart';

class ConsumableProductIsuuesCardPage extends StatelessWidget {
  final RawProductsIssueDAO? modelData;
  ConsumableProductIsuuesCardPage({this.modelData});
  @override
  Widget build(BuildContext context) {
    return Card(
        elevation: 5.0,
        shadowColor: AppTheme.vyaparTheme.colorScheme.primary,
        shape: new RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(5),
            side: new BorderSide(
                color: AppTheme.vyaparTheme.colorScheme.primaryContainer,
                strokeAlign: 1)),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                this.caardItemView(
                    Constants.ISSUED_TO,
                    modelData!.issuedTo != null
                        ? modelData!.issuedTo!.userName
                        : ""),
                this.caardItemView(
                    Constants.APPROVED_BY,
                    modelData!.approvedBy != null
                        ? modelData!.approvedBy!.userName
                        : ""),
                this.caardItemView(
                    Constants.REQUESTED_BY,
                    modelData!.requestedBy != null
                        ? modelData!.requestedBy!.userName
                        : ""),
                this.caardItemView(
                    Constants.ISSUANCE_ID, "${modelData!.issueNumber}"),
                this.caardItemView(
                    Constants.REQUESTED_ID, "${modelData!.requestNumber}"),
                this.caardItemView(
                    Constants.PURPOSE, "${modelData!.issuedPurpose}"),
                this.caardItemView(
                    Constants.DEPARTMENT, "${modelData!.department}"),
                this.caardItemView(
                    Constants.BATCH_NO, "${modelData!.issueBatchNumber}"),
                this.caardItemView(Constants.APPROVAL_DATE,
                    AppUtills.getDateFormate("${modelData!.createdDate}"))
              ],
            ),
          ),
        ));
  }

  caardItemView(String title, String? value) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 3.0),
      child: Row(
        children: <Widget>[
          new Expanded(
            child: Text(
              title,
              style: TextStyle(
                  color: Colors.black,
                  fontSize: 15.0,
                  fontWeight: StyleView.fontSemiBold),
            ),
          ),
          Text(
            " : ",
          ),
          Expanded(
            flex: 2,
            child: new Container(
              child: Text(
                "$value",
                style: TextStyle(
                    color: Colors.black,
                    fontSize: 13.0,
                    fontWeight: StyleView.fontMedium),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
