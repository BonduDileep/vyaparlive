import 'dart:convert';

import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Transaction/card_view/ProductCardDesign.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/invoice_view/BatchPriceDropdownView.dart';
import 'package:vyaparlive/model/DepartmentDAO.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/InvoiceDAO.dart';
import 'package:vyaparlive/model/ModelProduct.dart';
import 'package:vyaparlive/model/UserModel.dart';
import 'package:vyaparlive/model/product_model/BatchPriceDAO.dart';
import 'package:vyaparlive/model/product_model/ProductModel.dart';
import 'package:vyaparlive/retailer_view/card_view/ProductsCardView.dart';
import 'package:vyaparlive/service/Service.dart';
import 'package:vyaparlive/service/product_services.dart';
import 'package:vyaparlive/service/user_services.dart';
import 'package:vyaparlive/utills/SharePref.dart';
import 'package:http/http.dart' as http;

import '../../core/enums/privilleges_enum.dart';
import 'ConsumableTabView.dart';

class EditConsumableRequestPage extends StatefulWidget {
  final String? recordId;
  final List<Product>? productList;
  final String? formStatus;
  final String? date;
  final String? requestedBy;
  final String? purpose;
  final String? userId;
  final bool isShowEditableProducts;
  final bool isFromCreateRequestForm;
  final num? requestNumber;
  final String? department;
  final String? batchNumber;

  EditConsumableRequestPage(
      {this.recordId,
      this.productList,
      this.formStatus,
      this.date,
      this.requestedBy,
      this.purpose,
      this.userId,
      this.isShowEditableProducts = false,
      this.isFromCreateRequestForm = false,
      this.requestNumber = 0,
      this.department,
      this.batchNumber});

  @override
  _EditConsumableRequestPageState createState() => _EditConsumableRequestPageState();
}

class _EditConsumableRequestPageState extends State<EditConsumableRequestPage> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? buId = "";
  String? buName = "";
  String showProductText = "";
  List<BatchPriceDAO?> batchPricingDropdownList = [];
  final TextEditingController productNameController = TextEditingController();
  final TextEditingController quantityController = TextEditingController();

  List<String?> quantityInDropdownValue = [];
  BuProductModal? productNameDropdownValue;
  String selectedLang = AppController.instance.getSelectedlanguage;
  SharedPreferences? sharedPreferences;
  List<ModelProduct> _productsList = [];
  bool isShowProductName = false;
  late ProductService _productService;
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  ModelProduct? _selectedProductData;
  List<ModelProduct> selectedList = [];
  List<TextEditingController> _enterProductCount = [];
  List<UserModel> _usersList = [];
  late UserService _userService;
  UserModel? issuedToDropdownValue;
  final TextEditingController _purposeController = TextEditingController();
  List<BuProductModal> responseProducts = [];
  List<ModelProduct> selectedProductsList = [];
  final List<TextEditingController> unitPriceController = [];
  List<TextEditingController> _quantityInputController = [];
  List<BatchPriceDAO?> batchPriceDropdown = [];
  List<bool> isShowBatchPrice = [];
  int? _selectedCount = 0;
  String? orgCurrencySymbol = "";
  List<BuProductModal> _productList = [];
  String? userId = "";
  String? userName = "";
  DepartmentDAO? _departmentDropdownValue;
  List<DepartmentDAO> _departmentList = [];
  late Service _service;
  final TextEditingController _issueBatchNumberController =
      new TextEditingController();
  ScrollController? _scrollController;
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _scrollController = new ScrollController();
    _productService = ProductService();
    _userService = UserService();
    _service = Service();
    buId = AppController.instance.getMyBuId;
    buName = AppController.instance.buName;
    // orgCurrencySymbol = AppController.instance.getBuCurrencySymbol;
    String? symbol = AppController.instance.getBuCurrencySymbol;
    orgCurrencySymbol = (symbol != null && symbol.isNotEmpty && symbol!="-") ? symbol : "\u20B9";
    if (!widget.isFromCreateRequestForm) {
      loadServiceCalls();
      _purposeController.text = widget.purpose!;
      _issueBatchNumberController.text = widget.batchNumber!;
    }
    this.renderProducts();

    SharePref().getUserId().then((value) {
      setState(() {
        userId = value;
      });
    });
    SharePref().getUserName().then((value) {
      setState(() {
        userName = value;
      });
    });
  }

  loadServiceCalls() async {
    await this.getUsersList();
    await this.serviceCallDepartments();
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
        body: Stack(
      children: [
        SafeArea(
          child: Scaffold(
            key: _scaffoldkey,
            backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
            appBar: AppBar(
              backgroundColor: Colors.transparent, //(Constants.APP_COLOR),
              centerTitle: true,
              elevation: 0,
              iconTheme: IconThemeData(color: theme.colorScheme.primary),
              title: AppbarName(
                  title: (widget.isFromCreateRequestForm)
                      ? Language()
                          .getString(Constants.REQUEST_FORM_DETAILS, selectedLang)
                      : Language()
                          .getString(Constants.EDIT_REQUEST, selectedLang),
                  buName: "$buName"),
              actions: [
                (widget.formStatus == "pending" && widget.isShowEditableProducts)
                    ? IconButton(
                        onPressed: () {
                          this.clearData();
                          this.showProductsView();
                        },
                        icon: Icon(
                          Icons.add,
                          color: Colors.white,
                        ))
                    : Container()
              ],
            ),
            bottomNavigationBar: this.showBottomView(),
            body: Container(
              margin: EdgeInsets.symmetric(vertical: 5.0, horizontal: 5.0),
              child: Column(
                children: [
                  this.showRequestFormDetails(),
                  (widget.formStatus == "pending" &&
                          widget.isShowEditableProducts)
                      ? this.showUserEditableProducts()
                      : this.showuserNonEditableProducts()
                ],
              ),
            ),
          ),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    ));
  }

  /// Desinging for show products data in ROW
  renderProductDataDesign(int index) {
    return Container(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(5.0),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: Row(
                      children: [
                        Container(
                          height: 20.0,
                          width: 25.0,
                          child: Checkbox(
                              activeColor: Color(Constants.APP_COLOR),
                              value: selectedProductsList[index].isButton,
                              onChanged: (value) {
                                setState(() {
                                  selectedProductsList[index].isButton = value;
                                });
                              }),
                        ),
                        Expanded(
                            child: Text(
                          "${selectedProductsList[index].name}",
                          style: TextStyle(
                            fontSize: 13.0,
                            color: Color(Constants.APP_COLOR),
                            fontWeight: FontWeight.bold,
                          ),
                        )),
                      ],
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        InkWell(
                          onTap: () {
                            if (selectedProductsList[index].isButton!) {
                              this.renderRemoveProductQuantity(index, setState);
                            } else {
                              Dialogs.yesCancelDialog(
                                  context,
                                  Language()
                                      .getString(Constants.INFO, selectedLang),
                                  Language().getString(
                                      Constants
                                          .PLEASE_SELECT_PRODUCT_FURTHER_ACTION,
                                      selectedLang),
                                  Language().getString(
                                      Constants.OKAY_STR, selectedLang),
                                  "",
                                  false);
                            }
                          },
                          child: Icon(Icons.remove),
                        ),

                        // renderProductQuantity(index),
                        this.designQuantityInputField(index),
                        InkWell(
                          onTap: () {
                            if (selectedProductsList[index].isButton!) {
                              this.renderAddProductQuantity(index, setState);
                            } else {
                              Dialogs.yesCancelDialog(
                                  context,
                                  Language()
                                      .getString(Constants.INFO, selectedLang),
                                  Language().getString(
                                      Constants
                                          .PLEASE_SELECT_PRODUCT_FURTHER_ACTION,
                                      selectedLang),
                                  Language().getString(
                                      Constants.OKAY_STR, selectedLang),
                                  "",
                                  false);
                            }
                          },
                          child: Icon(Icons.add),
                        )
                      ],
                    ),
                  ),
                  this.renderProductUnitPrice(
                    index,
                    selectedProductsList[index].batchPriceList!,
                  ),
                ],
              ),
              (selectedProductsList[index].batchPriceList!.length > 0)
                  ? batchPricingDropdown(
                      selectedProductsList[index].batchPriceList!, index)
                  : Container(
                      margin: EdgeInsets.symmetric(vertical: 5.0),
                      alignment: Alignment.centerLeft,
                      child: Text(
                        "This product has zero quantity, please update quantity",
                        style: TextStyle(
                            color: Colors.red,
                            fontWeight: FontWeight.w500,
                            fontSize: 13.0),
                      ),
                    )
            ],
          ),
        ),
      ),
    );
  }

  batchPricingDropdown(List<BatchPriceDAO> batchNumberList, int index) {
    if (batchNumberList.length > 0) {
      if (batchPriceDropdown[index] == null) {
        batchPriceDropdown[index] = batchNumberList[0];
      }

      return BatchPriceDropDownView(
          canShowPrice: false,
          canShowDynamicPricing: false,
          currentDropdownIndex: index,
          batchPricingList: batchNumberList,
          batchDropdown: batchPriceDropdown,
          selectedDropdownValue: (data) {
            setState(() {
              batchPriceDropdown[index] = data;
              selectedProductsList[index].unitPrice =
                  batchPriceDropdown[index]!.price;
            });
          },
          strBatchPricing:
              Language().getString(Constants.BATCH_NO, selectedLang),
          strAvailableQuantity:
              Language().getString(Constants.AVAILABLE_QUANTITY, selectedLang));
    }
  }

  designQuantityInputField(int index) {
    return Container(
      height: 30.0,
      width: 50.0,
      alignment: Alignment.center,
      decoration: BoxDecoration(border: Border.all(color: Colors.grey)),
      child: TextFormField(
        textAlign: TextAlign.center,
        enableInteractiveSelection: false,
        cursorWidth: 1.0,
        controller: _quantityInputController[index],
        decoration: InputDecoration(
          hintText: "0",
          border: InputBorder.none,
        ),
        keyboardType: TextInputType.number,
        style: TextStyle(fontSize: 12.0),
        inputFormatters: [
          new LengthLimitingTextInputFormatter(5),
          FilteringTextInputFormatter.digitsOnly
        ],
        onChanged: (value) async {
          /// Adding input value for product counter value
          if (value.isEmpty) {
            setState(() {
              selectedProductsList[index].quantity =
                  widget.productList![index].quantity;
              _quantityInputController[index].clear();
            });
          } else if (int.parse(value) > widget.productList![index].quantity!) {
            final action = await Dialogs.yesCancelDialog(
                context,
                Language().getString(Constants.ERROR, selectedLang),
                Language().getString(Constants.QUANTITY_WARNINIG, selectedLang),
                Language().getString(Constants.OKAY_STR, selectedLang),
                "",
                false);

            if (action == DialogAction.yes) {
              setState(() {
                selectedProductsList[index].quantity =
                    widget.productList![index].quantity;
                _quantityInputController[index] = TextEditingController(
                    text: selectedProductsList[index].quantity.toString());
                _quantityInputController[index].selection =
                    TextSelection.fromPosition(TextPosition(
                        offset: _quantityInputController[index].text.length));
              });
            }
          } else {
            if (selectedProductsList.length > 0) {
              setState(() {
                selectedProductsList[index].quantity = int.parse(value);
              });
            }
          }
        },
      ),
    );
  }

  /// Showing Product unit price
  renderProductUnitPrice(int index, List<BatchPriceDAO> _batchList) {
    if (_batchList.length > 0) {
      if (batchPriceDropdown[index] == null) {
        selectedProductsList[index].unitPrice = _batchList[0].price;
      }
    }

    if (isShowBatchPrice[index]) {
      unitPriceController[index] = TextEditingController(
          text: selectedProductsList[index].unitPrice.toString());
      unitPriceController[index].selection = TextSelection.fromPosition(
          TextPosition(offset: unitPriceController[index].text.length));
      isShowBatchPrice[index] = false;
    } else {
      unitPriceController[index] = TextEditingController(
          text: selectedProductsList[index].unitPrice.toString());
      unitPriceController[index].selection = TextSelection.fromPosition(
          TextPosition(offset: unitPriceController[index].text.length));
    }
    return Expanded(
      child: Container(
        height: 30.0,
        width: 50.0,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          border: Border.all(
            color: Colors.grey,
          ),
        ),
        child: Center(
          child: TextFormField(
            cursorWidth: 1.0,
            enableInteractiveSelection: false,
            textAlign: TextAlign.center,
            enabled: false,
            controller: unitPriceController[index],
            keyboardType: TextInputType.number,
            style: TextStyle(
              fontSize: 12.0,
              fontWeight: FontWeight.bold,
            ),
            decoration:
                InputDecoration(border: InputBorder.none, hintText: "0"),
            onChanged: (value) {
              /// Adding updated unit price to selected list
              selectedProductsList[index].unitPrice = double.parse(value);
            },
          ),
        ),
      ),
    );
  }

  /// Showing product quantity
  renderProductQuantity(int index) {
    return new Container(
      height: 20.0,
      width: 40.0,
      margin: EdgeInsets.symmetric(
        horizontal: 3.0,
      ),
      decoration: BoxDecoration(border: Border.all(color: Colors.grey)),
      child: Center(
        child: Text(
          "${selectedProductsList[index].quantity}",
          style: TextStyle(fontSize: 11.0, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }

  /// Removing product quantity
  renderRemoveProductQuantity(int index, StateSetter setState) {
    _selectedCount = selectedProductsList[index].quantity as int?;

    if (_selectedCount == 1) {
      setState(() {
        selectedProductsList[index].quantity = _selectedCount;
        _quantityInputController[index] = TextEditingController(
            text: selectedProductsList[index].quantity.toString());
        _quantityInputController[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _quantityInputController[index].text.length));
      });
    } else {
      _selectedCount = _selectedCount! - 1;
      setState(() {
        selectedProductsList[index].quantity = _selectedCount;
        _quantityInputController[index] = TextEditingController(
            text: selectedProductsList[index].quantity.toString());
        _quantityInputController[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _quantityInputController[index].text.length));
      });
    }
  }

  /// Adding product quantiy
  renderAddProductQuantity(int index, StateSetter setState) {
    int? _count = selectedProductsList[index].quantity as int?;

    if (_count == widget.productList![index].quantity) {
      setState(() {
        selectedProductsList[index].quantity = _count;
        _quantityInputController[index] = TextEditingController(
            text: selectedProductsList[index].quantity.toString());
        _quantityInputController[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _quantityInputController[index].text.length));
      });
    } else {
      _count = _count! + 1;
      setState(() {
        selectedProductsList[index].quantity = _count;
        _quantityInputController[index] = TextEditingController(
            text: selectedProductsList[index].quantity.toString());
        _quantityInputController[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _quantityInputController[index].text.length));
      });
    }
  }

  showProductsView() {
    return showDialog(
        context: context,
        barrierColor: Colors.black54,
        barrierDismissible: false,
        builder: (context) => StatefulBuilder(
                builder: (BuildContext context, StateSetter setState) {
              return Container(
                margin: EdgeInsets.symmetric(vertical: 20.0, horizontal: 5.0),
                child: Scaffold(
                    bottomNavigationBar: this.bottomView(),
                    backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                    body: Container(
                        margin: EdgeInsets.symmetric(
                            vertical: 10.0, horizontal: 5.0),
                        child: Column(
                          children: [
                            this.showProductSearchView(setState),
                            (_productsList.length > 0 && isShowProductName)
                                ? this.showProductNames(setState)
                                : Container(
                                    margin: EdgeInsets.symmetric(vertical: 5.0),
                                    child: (showProductText ==
                                                Constants.NO_DATA_FOUND ||
                                            showProductText == "")
                                        ? Text(showProductText)
                                        : Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              Text(showProductText),
                                              Container(
                                                height: 10.0,
                                                width: 10.0,
                                                margin: EdgeInsets.symmetric(
                                                    horizontal: 5.0),
                                                child:
                                                    CircularProgressIndicator(
                                                  strokeWidth: 2.0,
                                                ),
                                              )
                                            ],
                                          ),
                                  ),
                            (selectedList.length > 0)
                                ? this.showSelectedProductsView(setState)
                                : Container(),
                          ],
                        ))),
              );
            }));
  }

  Widget showProductSearchView(StateSetter setState) {
    return Container(
      decoration: AppUtills.boxDecoration(),
      margin: EdgeInsets.only(top: 5.0),
      height: 40.0,
      alignment: Alignment.centerLeft,
      child: Container(
        color: Colors.grey,
        alignment: Alignment.centerLeft,
        child: Row(
          children: [
            Expanded(
              flex: 2,
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(5.0),
                      bottomLeft: Radius.circular(5.0)),
                  color: Color(Constants.APP_BACKGROUND_COLOR),
                ),
                margin: EdgeInsets.only(right: 1.0),
                child: Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: TextField(
                    controller: productNameController,
                    keyboardType: TextInputType.text,
                    // focusNode: FocusNode(),
                    decoration: InputDecoration(
                        hintText:Language().getString("Search by product name..", selectedLang),
                        hintStyle: TextStyle(fontSize: 12.0),
                        border: InputBorder.none),
                    onChanged: (_text) {
                      if (_text.isNotEmpty) {
                        setState(() {
                          showProductText = Constants.LOADING;
                        });

                        this.loadProductData(_text, setState);
                      } else {
                        setState(() {
                          showProductText = "";
                          isShowProductName = false;
                          _productsList.clear();
                        });
                      }
                    },
                    style: TextStyle(
                        fontSize: 12.0, decoration: TextDecoration.none),
                  ),
                ),
              ),
            ),
            Expanded(
              child: Container(
                color: Color(Constants.APP_BACKGROUND_COLOR),
                margin: EdgeInsets.only(right: 1.0),
                child: Padding(
                  padding: const EdgeInsets.all(2.0),
                  child: TextFormField(
                    controller: quantityController,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: Constants.QUANTITY,
                      hintStyle: TextStyle(fontSize: 12.0),
                    ),
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 12.0),
                  ),
                ),
              ),
            ),
            SizedBox(
              width: 30.0,
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                      topRight: Radius.circular(5.0),
                      bottomRight: Radius.circular(5.0)),
                  color: Color(Constants.APP_BACKGROUND_COLOR),
                ),
                child: IconButton(
                    padding: EdgeInsets.all(0.0),
                    icon: Icon(
                      Icons.add,
                    ),
                    onPressed: () {
                      CommonMethods.hideKeyboard(context);
                      if (_selectedProductData != null) {
                        if (_selectedProductData!.counter == 0) {
                          Dialogs.yesCancelDialog(
                              context,
                              Language()
                                  .getString(Constants.ERROR, selectedLang),
                              Language().getString(
                                  Constants.ENTER_VALID_QUANTITY, selectedLang),
                              Language()
                                  .getString(Constants.OKAY_STR, selectedLang),
                              "",
                              false);
                        } else {
                          this.addToInvoiceProductsArray(setState);
                        }
                      }
                    }),
              ),
            )
          ],
        ),
      ),
    );
  }

  addToInvoiceProductsArray(StateSetter setState) {
    setState(() {
      bool isExist = false;
      int index = -1;
      for (int i = 0; i < selectedList.length; i++) {
        if (_selectedProductData!.id == selectedList[i].id) {
          isExist = true;
          index = i;
        }
      }

      if (isExist) {
        selectedList[index].counter =
            selectedList[index].counter! + int.parse(quantityController.text);

        _enterProductCount[index] =
            TextEditingController(text: selectedList[index].counter.toString());
        _enterProductCount[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _enterProductCount[index].text.length));
      } else {
        selectedList.add(ModelProduct(
            name: _selectedProductData!.name,
            id: _selectedProductData!.id,
            price: _selectedProductData!.price,
            counter: int.parse(quantityController.text),
            images: _selectedProductData!.images,
            isButton: _selectedProductData!.isButton,
            isItemSelected: _selectedProductData!.isItemSelected,
            batchPriceList: _selectedProductData!.batchPriceList,
            unitPrice: _selectedProductData!.unitPrice,
            quantity: _selectedProductData!.quantity));

        _enterProductCount.add(new TextEditingController());
        batchPricingDropdownList.add(null);
        quantityInDropdownValue.add(null);
      }

      _selectedProductData = null;
      productNameController.clear();
      quantityController.clear();
    });
  }

  Widget bottomView() {
    return Container(
        margin: EdgeInsets.symmetric(horizontal: 10.0),
        child: Row(
          children: [
            if (CommonMethods.isPrivillegeExist(
                context,
                PrivillegesActions
                    .CONSUMABLE_MATERIAL_MENU_CONSUMABLE_MATERIAL_ISSUANCE_ISSUE_FORM_CLICK))
              Expanded(
                child: Container(
                  margin: EdgeInsets.only(right: 1.0),
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Color(Constants.APP_COLOR)),
                    onPressed: () {
                      clearData();
                      Navigator.of(context).pop();
                    },
                    child: Text(
                      Language().getString(Constants.STR_CANCEL, selectedLang),
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ),
              ),
            Expanded(
              child: Container(
                margin: EdgeInsets.only(left: 1.0),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      backgroundColor: Color(Constants.APP_COLOR)),
                  onPressed: () async {
                    if (selectedList.length == 0) {
                      Dialogs.yesCancelDialog(
                          context,
                          Language().getString(Constants.ERROR, selectedLang),
                          Language().getString(
                              Constants.SELECT_PRODUCTS, selectedLang),
                          Language()
                              .getString(Constants.OKAY_STR, selectedLang),
                          "",
                          false);
                    } else {
                      // this.showIssueUsersList();

                      for (int i = 0; i < selectedList.length; i++) {
                        bool isProductExist = false;
                        int index = -1;
                        for (int j = 0; j < selectedProductsList.length; j++) {
                          if (selectedProductsList[j].id ==
                              selectedList[i].id) {
                            setState(() {
                              isProductExist = true;
                              index = j;
                            });
                          }
                        }

                        if (isProductExist) {
                          setState(() {
                            selectedProductsList[index].quantity =
                                (selectedProductsList[index].quantity! +
                                    selectedList[i].counter!);

                            _quantityInputController[index] =
                                TextEditingController(
                                    text: selectedProductsList[index]
                                        .quantity
                                        .toString());
                            _quantityInputController[index].selection =
                                TextSelection.fromPosition(TextPosition(
                                    offset: _quantityInputController[index]
                                        .text
                                        .length));
                          });
                        } else {
                          unitPriceController.add(new TextEditingController());
                          _quantityInputController
                              .add(new TextEditingController());

                          batchPriceDropdown.add(null);
                          isShowBatchPrice.add(true);
                          setState(() {
                            selectedProductsList.add(
                              ModelProduct(
                                  id: selectedList[i].id,
                                  images: "",
                                  name: selectedList[i].name,
                                  quantity: selectedList[i].counter,
                                  counter: 0,
                                  isButton: true,
                                  isItemSelected: false,
                                  unitPrice: selectedList[i].unitPrice,
                                  price: selectedList[i].unitPrice,
                                  offerData: null,
                                  offerSelected: false,
                                  batchPriceList:
                                      selectedList[i].batchPriceList,
                                  offerList: []),
                            );
                          });

                          for (int k = 0;
                              k < selectedProductsList.length;
                              k++) {
                            setState(() {
                              _quantityInputController[k] =
                                  TextEditingController(
                                      text: selectedProductsList[k]
                                          .quantity
                                          .toString());
                              _quantityInputController[k].selection =
                                  TextSelection.fromPosition(TextPosition(
                                      offset: _quantityInputController[k]
                                          .text
                                          .length));
                            });
                          }
                        }
                      }
                    }
                    Navigator.of(context).pop();
                  },
                  child: Text(
                    Language().getString(Constants.CONTINUE, selectedLang),
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
          ],
        ));
  }

  loadProductData(String productName, StateSetter setState) async {
    if (await NetworkStatus.getInternetStatus()) {
      this.getBuProducts(productName: productName).then((onValue) {
        setState(() {
          responseProducts.clear();
          _productsList.clear();
          responseProducts.addAll(onValue);
          if (responseProducts.length > 0) {
            for (int i = 0; i < responseProducts.length; i++) {
              if (responseProducts[i].batchPrice!.length > 0) {
                showProductText = "";

                _productsList.add(ModelProduct(
                    id: responseProducts[i].id,
                    name: responseProducts[i].name,
                    counter: 0,
                    isButton: false,
                    images: responseProducts[i].imageThumbnail!.length > 0
                        ? responseProducts[i].imageThumbnail![0].image
                        : null,
                    price: 0,
                    quantity: responseProducts[i].batchPrice![0].quantity,
                    isItemSelected: false,
                    unitPrice: responseProducts[i].batchPrice![0].price,
                    offerList: responseProducts[i].offers,
                    batchPriceList: responseProducts[i].batchPrice));

                isShowProductName = true;
              } else {
                showProductText = Constants.NO_DATA_FOUND;
              }
            }
          } else {
            showProductText = Constants.NO_DATA_FOUND;
          }
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<BuProductModal>> getBuProducts({String productName = ""}) async {
    String body = json.encode({
      "id": buId,
      "filter": {"name": productName, "raw_material": true}
    });

    var response = await _productService
        .getProductByBuId_v2(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<BuProductModal> products = [];

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      var data = resObj['results'];
      for (var i in data) {
        products.add(BuProductModal.fromJson(i));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return products;
  }

  Widget showProductNames(StateSetter setState) {
    return Container(
        height: 100.0,
        decoration: BoxDecoration(
          color: Colors.grey[400],
          borderRadius: BorderRadius.circular(5.0),
        ),
        child: ListView.builder(
          itemBuilder: (context, index) {
            return InkWell(
              onTap: () {
                CommonMethods.hideKeyboard(context);
                setState(() {
                  quantityController.text = "1";
                  _productsList[index].counter =
                      int.parse(quantityController.text);
                  productNameController.text = _productsList[index].name!;
                  isShowProductName = false;
                  _selectedProductData = _productsList[index];
                });
              },
              child: Card(
                color: Colors.grey[100],
                elevation: 2.5,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(_productsList[index].name!,
                          style: TextStyle(color: Colors.black)),
                      Icon(Icons.arrow_forward, color: Colors.blue, size: 20.0),
                    ],
                  ),
                ),
              ),
            );
          },
          itemCount: _productsList.length,
          shrinkWrap: true,
        ));
  }

  Widget showSelectedProductsView(StateSetter setState) {
    return Expanded(
        child: Container(
      margin: EdgeInsets.only(top: 5.0),
      decoration: AppUtills.boxDecoration(),
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.all(5.0),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    Language().getString(Constants.PRODUCT_NAME, selectedLang),
                    style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                        fontWeight: FontWeight.bold),
                  ),
                ),
                Expanded(
                  child: Text(
                    Language().getString(Constants.QUANTITY, selectedLang),
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
          ),
          Divider(
            color: Color(Constants.APP_COLOR),
          ),
          Expanded(
            child: ListView.separated(
                shrinkWrap: true,
                separatorBuilder: (context, index) => new Divider(
                      color: Colors.transparent,
                      height: 0.0,
                    ),
                itemCount: selectedList.length,
                itemBuilder: (context, index) {
                  _enterProductCount[index] = TextEditingController(
                      text: selectedList[index].counter.toString());
                  _enterProductCount[index].selection =
                      TextSelection.fromPosition(TextPosition(
                          offset: _enterProductCount[index].text.length));
                  return Card(
                    child: Column(
                      children: [
                        ProductsCardView(
                          onRemoveProductQuantit: () {
                            removeProductsQuantity(index, setState);
                          },
                          onAddProductQuantity: () {
                            addProductsQuantity(index, setState);
                          },
                          desingQuntityField: Container(
                            width: 50.0,
                            height: 30.0,
                            alignment: Alignment.bottomCenter,
                            decoration: AppUtills.boxDecoration(),
                            child: this.quantityInputFieldSelectedProducts(
                                index, setState),
                          ),
                          productName: selectedList[index].name,
                          removeProduct: () async {
                            final action = await Dialogs.yesCancelDialog(
                                context,
                                Language()
                                    .getString(Constants.WARNING, selectedLang),
                                Language().getString(
                                    Constants.WARNING_TEXT, selectedLang),
                                Language().getString(
                                    Constants.OKAY_STR, selectedLang),
                                "",
                                false);

                            if (action == DialogAction.yes) {
                              setState(() {
                                selectedList.removeAt(index);
                                batchPricingDropdownList.removeAt(index);
                                quantityInDropdownValue.removeAt(index);
                              });
                            }
                          },
                          productTotalPrice: 0,
                          isFromRawProductIssuePage: true,
                        ),
                        Container(
                          child: (batchPricingDropdownList.length > 0)
                              ? this.batchPricingDropdownView(
                                  selectedList[index].batchPriceList!,
                                  index,
                                  setState)
                              : Container(),
                        ),
                      ],
                    ),
                  );
                }),
          )
        ],
      ),
    ));
  }

  batchPricingDropdownView(
      List<BatchPriceDAO> batchNumberList, int index, StateSetter setState) {
    if (batchNumberList.length > 0 && batchPricingDropdownList.length > 0) {
      if (batchPricingDropdownList[index] == null) {
        batchPricingDropdownList[index] = batchNumberList[0];
      }

      return Container(
        margin: EdgeInsets.symmetric(vertical: 2.0),
        child: Padding(
          padding: const EdgeInsets.all(5.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                child: Row(
                  children: <Widget>[
                    Container(
                        height: 20.0,
                        child: Text(
                            Language().getString(
                                    Constants.BATCH_NO, selectedLang) +
                                " : ",
                            style: TextStyle(
                                fontSize: 13.0,
                                fontWeight: FontWeight.bold,
                                color: Color(Constants.APP_COLOR)))),
                    Expanded(
                      flex: 2,
                      child: Container(
                          padding: EdgeInsets.only(left: 5, right: 5),
                          child: DropdownButton<BatchPriceDAO>(
                              value: batchPricingDropdownList[index],
                              hint: Text(Language()
                                  .getString(Constants.BATCH_NO, selectedLang)),
                              underline: SizedBox(),
                              onChanged: (BatchPriceDAO? data) {
                                setState(() {
                                  batchPricingDropdownList[index] = data;
                                });
                              },
                              onTap: () {
                                return CommonMethods.hideKeyboard(context);
                              },
                              items: batchPricingDropdownList
                                  .map((BatchPriceDAO? model) {
                                return new DropdownMenuItem<BatchPriceDAO>(
                                    onTap: () {
                                      return CommonMethods.hideKeyboard(
                                          context);
                                    },
                                    child: new Text(model!.batchNumber!),
                                    value: model);
                              }).toList())),
                    ),
                  ],
                ),
              ),
              Container(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      Constants.AVAILABLE_QUANTITY,
                      style: TextStyle(
                          fontSize: 13.0,
                          fontWeight: FontWeight.bold,
                          color: Color(Constants.APP_COLOR)),
                    ),
                    Expanded(
                      child: Text(
                          "   : ${batchPricingDropdownList[index]!.quantity}  ${batchPricingDropdownList[index]!.quantityIn}"),
                    ),
                  ],
                ),
              ),
              (quantityInDropdownValue.length > 0)
                  ? this.batchQuantityUnitsropdownView(index, setState)
                  : Container()
            ],
          ),
        ),
      );
    }
  }

  batchQuantityUnitsropdownView(int index, StateSetter setState) {
    if (quantityInDropdownValue[index] == null) {
      quantityInDropdownValue[index] = "unit";
    }
    return Row(
      children: [
        Container(
            child: Text(
                Language().getString(Constants.QUANTITY_IN, selectedLang) +
                    " : ",
                style: TextStyle(
                    fontSize: 13.0,
                    fontWeight: FontWeight.bold,
                    color: Color(Constants.APP_COLOR)))),
        Expanded(
            child: Container(
                color: Colors.white,
                padding: EdgeInsets.only(left: 5),
                child: DropdownButton<String>(
                    onTap: () {
                      return CommonMethods.hideKeyboard(context);
                    },
                    value: quantityInDropdownValue[index],
                    hint: new Text(
                      Language().getString(Constants.SELECT, selectedLang),
                    ),
                    underline: SizedBox(),
                    onChanged: (String? data) {
                      setState(() {
                        quantityInDropdownValue[index] = data;
                      });
                    },
                    items: Constants.UNIT_PRICE.map((String model) {
                      return new DropdownMenuItem<String>(
                        child: new Text(model),
                        value: model,
                      );
                    }).toList()))),
      ],
    );
  }

  removeProductsQuantity(int index, StateSetter setState) {
    int? countDecrement = selectedList[index].counter;
    setState(() {
      if (countDecrement! > 1) {
        countDecrement = countDecrement! - 1;
        selectedList[index].counter = countDecrement;

        setState(() {
          selectedList[index].counter = countDecrement;
          _enterProductCount[index] = TextEditingController(
              text: selectedList[index].counter.toString());
          _enterProductCount[index].selection = TextSelection.fromPosition(
              TextPosition(offset: _enterProductCount[index].text.length));
        });
      }
    });
  }

  addProductsQuantity(int index, StateSetter setState) {
    int? countIncrement = selectedList[index].counter;

    if (countIncrement == 1) {
      setState(() {
        countIncrement = countIncrement! + 1;
        selectedList[index].counter = countIncrement;

        _enterProductCount[index] =
            TextEditingController(text: selectedList[index].counter.toString());
        _enterProductCount[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _enterProductCount[index].text.length));
      });
    } else {
      setState(() {
        countIncrement = countIncrement! + 1;
        selectedList[index].counter = countIncrement;

        _enterProductCount[index] =
            TextEditingController(text: selectedList[index].counter.toString());
        _enterProductCount[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _enterProductCount[index].text.length));
      });
    }
  }

  quantityInputFieldSelectedProducts(int index, StateSetter setState) {
    return Container(
      height: 60.0,
      width: 60.0,
      child: TextFormField(
        enableInteractiveSelection: false,
        textAlign: TextAlign.center,
        controller: _enterProductCount[index],
        decoration: InputDecoration(
          hintText: "",
          border: InputBorder.none,
        ),
        keyboardType: TextInputType.numberWithOptions(signed: true),
        style: TextStyle(fontSize: 12.0),
        inputFormatters: [
          new LengthLimitingTextInputFormatter(5),
          FilteringTextInputFormatter.digitsOnly
        ],
        onFieldSubmitted: (value) {
          if (value == "0" || value.isEmpty) {
            selectedList[index].counter = 1;
          }
        },
        onChanged: (value) {
          setState(() {
            if (selectedList.length > 0) {
              if (value.isEmpty) {
                selectedList[index].counter = 0;
              } else {
                selectedList[index].counter = int.parse(value);
              }
            }
          });
        },
      ),
    );
  }

  getUsersList({String name = ""}) async {
    if (await NetworkStatus.getInternetStatus()) {
      this.getAllUsers(name: name).then((value) {
        setState(() {
          _usersList.clear();
          _usersList.addAll(value);
          for (int i = 0; i < _usersList.length; i++) {
            if (widget.userId == _usersList[i].id) {
              issuedToDropdownValue = _usersList[i];
            }
          }
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  /// Service call for getUsers
  Future<List<UserModel>> getAllUsers({String name = ""}) async {
    setState(() {
      _usersList.clear();
      progressMessage = "Getting users..";
    });
    String body = json.encode({"id": buId, "filters": {}});

    var response = await _userService
        .getUserByBuId_grpc(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    List<UserModel> _users = [];
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      var resultArray = resObj['results'];
      for (var data in resultArray) {
        _users.add(UserModel.fromJson(data));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return _users;
  }

  showIssueUsersList() {
    return showDialog(
        context: context,
        barrierColor: Colors.black54,
        barrierDismissible: false,
        builder: (context) =>
            StatefulBuilder(builder: (context, StateSetter setState) {
              return Container(
                margin: EdgeInsets.symmetric(vertical: 20.0, horizontal: 20.0),
                child: AppBackgroundView(
                    body: Scaffold(
                        bottomNavigationBar: Container(
                            margin: EdgeInsets.symmetric(horizontal: 10.0),
                            padding: EdgeInsets.symmetric(vertical: 10),
                            child: CommonButtonsView(
                              context: context,
                              b1Text: Language().getString(
                                  Constants.STR_CANCEL, selectedLang),
                              b2Text: Language()
                                  .getString(Constants.CONFIRM, selectedLang),
                              onb1Action: () {
                                Navigator.of(context).pop();
                              },
                              onb2Action: () async {
                                if (issuedToDropdownValue == null) {
                                  Dialogs.yesCancelDialog(
                                      context,
                                      Language().getString(
                                          Constants.ERROR, selectedLang),
                                      Language().getString(
                                          Constants.SELECT_USER, selectedLang),
                                      Language().getString(
                                          Constants.OKAY_STR, selectedLang),
                                      "",
                                      false);
                                } else {
                                  Navigator.of(context).pop();

                                  this.acceptRequestForm();
                                }
                              },
                            )),
                        backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                        body: Container(
                            margin: EdgeInsets.symmetric(
                                vertical: 10.0, horizontal: 10.0),
                            child: SingleChildScrollView(
                              child: Column(
                                children: [
                                  Container(
                                    margin: EdgeInsets.symmetric(vertical: 5.0),
                                    child: Text(
                                      Language().getString(
                                          Constants.ISSUING_DETAILS,
                                          selectedLang),
                                      style: TextStyle(
                                          color: Color(Constants.APP_COLOR),
                                          fontSize: 15.0,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                  this.buildDropdownIssueTo(setState),
                                  Container(
                                    margin: EdgeInsets.symmetric(vertical: 5.0),
                                    child: TextFormField(
                                        controller: _purposeController,
                                        style: TextStyle(
                                            fontFamily: StyleView.FONT_TITLE),
                                        decoration:
                                            StyleView.getInputDecoration(
                                                helper: Language().getString(
                                                    Constants.PURPOSE,
                                                    selectedLang),
                                                customHelperColor:
                                                    Color(Constants.APP_COLOR)),
                                        maxLines: 3),
                                  ),
                                  // Container(
                                  //   margin:
                                  //       EdgeInsets.symmetric(vertical: 10.0),
                                  //   child: TextFormField(
                                  //       controller: _issueBatchNumberController,
                                  //       style: TextStyle(
                                  //           fontFamily: StyleView.FONT_TITLE),
                                  //       decoration:
                                  //           StyleView.getInputDecoration(
                                  //               helper: Language().getString(
                                  //                   Constants.BATCH_NO,
                                  //                   selectedLang),
                                  //               customHelperColor:
                                  //                   Color(Constants.APP_COLOR)),
                                  //       maxLines: 3),
                                  // ),
                                  this.buildDepartmentDropdown(setState)
                                ],
                              ),
                            )))),
              );
            }));
  }

  buildDropdownIssueTo(StateSetter setState) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          margin: EdgeInsets.symmetric(vertical: 10.0),
          child: Text(
            Language().getString(Constants.ISSUED_TO, selectedLang),
            style: TextStyle(
                color: Color(Constants.APP_COLOR), fontWeight: FontWeight.w600),
          ),
        ),
        Container(
          margin: EdgeInsets.symmetric(vertical: 5.0),
          decoration: AppUtills.boxDecoration(),
          child: DropdownButton<UserModel>(
            items: _usersList.map((UserModel model) {
              return new DropdownMenuItem<UserModel>(
                child: new Text("${model.name}"),
                value: model,
              );
            }).toList(),
            value: issuedToDropdownValue,
            underline: Container(),
            hint: Text(Language().getString(Constants.ISSUED_TO, selectedLang)),
            onChanged: (value) {
              setState(() {
                issuedToDropdownValue = value;
              });
            },
            isExpanded: true,
          ),
        ),
      ],
    );
  }

  clearData() {
    setState(() {
      _productsList.clear();
      batchPricingDropdownList.clear();
      _enterProductCount.clear();
      productNameController.clear();
      quantityController.clear();
      _selectedProductData = null;
      selectedList.clear();
      showProductText = "";
      _purposeController.clear();
      issuedToDropdownValue = null;
    });
  }

  renderProducts() {
    for (int i = 0; i < widget.productList!.length; i++) {
      // for (int j = 0; j < widget.productList[i].batchPricingList.length; j++) {
      //   if (widget.productList[i].batchPricingList[j].quantity != 0) {
      /// Adding TextEditingControllers to a list
      unitPriceController.add(new TextEditingController());
      _quantityInputController.add(new TextEditingController());

      batchPriceDropdown.add(null);
      isShowBatchPrice.add(true);
      setState(() {
        selectedProductsList.add(
          ModelProduct(
              id: widget.productList![i].id,
              images: widget.productList![i].imageUrl!.length > 0
                  ? widget.productList![i].imageUrl![0].image
                  : "",
              name: widget.productList![i].productName,
              quantity: widget.productList![i].quantity,
              counter: 0,
              isButton: true,
              isItemSelected: false,
              unitPrice: widget.productList![i].unitPrice,
              price: widget.productList![i].unitPrice,
              offerData: null,
              offerSelected: false,
              batchPriceList: [],
              offerList: []),
        );
        _quantityInputController[i] = TextEditingController(
            text: widget.productList![i].quantity.toString());
        _quantityInputController[i].selection = TextSelection.fromPosition(
            TextPosition(offset: _quantityInputController[i].text.length));
      });
      //   }
      // }

      if (!widget.isFromCreateRequestForm) {
        this.loadBatchNumbersList(widget.productList![i].id);
      }
    }
  }

  loadBatchNumbersList(String? productId) async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
        progressMessage = "Getting Batch Pricing Data..";
      });
      this.getProuctById(productId).then((onValue) {
        setState(() {
          _productList.clear();
          _productList.addAll(onValue);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey, "No Internet Connection",
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<BuProductModal>> getProuctById(String? productId) async {
    String body = json.encode({"id": productId, "buId": buId});

    var response = await _productService
        .getProductDetailsByProductId_grpc(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          "$onError",
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<BuProductModal> data = [];

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      data.add(BuProductModal.fromJson(resObj[0]));
      this.addingBatchPricing(data, productId);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return data;
  }

  addingBatchPricing(List<BuProductModal> productData, String? productId) {
    for (int i = 0; i < selectedProductsList.length; i++) {
      if (productData[0].id == selectedProductsList[i].id) {
        setState(() {
          batchPriceDropdown[i] = null;
          selectedProductsList[i].batchPriceList = bindingAvailableBatches(
              productData[0], i); //productData[0].batchPrice;
          // selectedProductsList[i].unitPrice =
          //     productData[0].batchPrice.length > 0
          //         ? productData[0].batchPrice[0].price
          //         : 0;
        });
      }
    }
  }

  List<BatchPriceDAO> bindingAvailableBatches(
      BuProductModal productData, int productIndex) {
    List<BatchPriceDAO> _batchNumber = [];
    for (var i = 0; i < productData.batchPrice!.length; i++) {
      if (productData.batchPrice![i].quantity != 0 &&
          productData.batchPrice![i].price != 0) {
        _batchNumber.add(productData.batchPrice![i]);
      }
    }
    return _batchNumber;
  }

  showBottomView() {
    if (widget.formStatus == "pending" && widget.isShowEditableProducts) {
      return Container(
          padding: EdgeInsets.symmetric(vertical: 20, horizontal: 10),
          child: Row(children: [
            if (CommonMethods.isPrivillegeExist(
                context,
                PrivillegesActions
                    .CONSUMABLE_MATERIAL_MENU_CONSUMABLE_MATERIAL_ISSUANCE_ISSUE_FORM_CANCEL))
              Expanded(
                  child: Padding(
                padding: const EdgeInsets.all(1.0),
                child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: theme.colorScheme.primary),
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    child: Text(
                      Constants.STR_CANCEL,
                      style: TextStyle(fontWeight: StyleView.fontMedium),
                    )),
              )),
            if (CommonMethods.isPrivillegeExist(
                context,
                PrivillegesActions
                    .CONSUMABLE_MATERIAL_MENU_CONSUMABLE_MATERIAL_ISSUANCE_ISSUE_FORM_REJECT))
              Expanded(
                  child: Padding(
                padding: const EdgeInsets.all(1.0),
                child: ElevatedButton(
                    style:
                        ElevatedButton.styleFrom(backgroundColor: Colors.red),
                    onPressed: () async {
                      final action = await Dialogs.yesCancelDialog(
                          context,
                          Language().getString(Constants.WARNING, selectedLang),
                          Language()
                              .getString(Constants.REJECT_INFO, selectedLang),
                          Language()
                              .getString(Constants.YES_STRING, selectedLang),
                          Language()
                              .getString(Constants.NO_STRING, selectedLang),
                          true);

                      if (action == DialogAction.yes) {
                        this.rejectRawRequestForm();
                      }
                    },
                    child: Text(
                      Constants.REJECT_STRING,
                      style: TextStyle(fontWeight: StyleView.fontMedium),
                    )),
              )),
            if (CommonMethods.isPrivillegeExist(
                context,
                PrivillegesActions
                    .CONSUMABLE_MATERIAL_MENU_CONSUMABLE_MATERIAL_ISSUANCE_ISSUE_FORM_ACCEPT))
              Expanded(
                  child: Padding(
                padding: const EdgeInsets.all(1.0),
                child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green[800]),
                    onPressed: () => this.issueRawProductsValidation(),
                    child: Text(Language()
                        .getString(Constants.ACCEPT_STRING, selectedLang))),
              ))
          ]));
    } else {
      return Container(
        margin: EdgeInsets.symmetric(horizontal: 5.0, vertical: 5.0),
        padding: EdgeInsets.all(20),
        child: Row(children: [
          Container(
            child: Text(
              Constants.STATUS_STRING,
              style: TextStyle(
                  color: Color(Constants.APP_COLOR),
                  fontWeight: FontWeight.w800,
                  fontSize: 15.0),
            ),
          ),
          Expanded(
              child: Container(
            child: Text(
              " : ${widget.formStatus}",
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13.0),
            ),
          ))
        ]),
      );
    }
  }

  acceptRequestForm() async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = "Accepting..";
    });
    List<Map<String, dynamic>> arrayProducts = [];
    var object;

    for (int i = 0; i < selectedProductsList.length; i++) {
      if (selectedProductsList[i].quantity != 0) {
        object = {
          "id": selectedProductsList[i].id,
          "quantity": selectedProductsList[i].quantity,
          "batch_no": batchPriceDropdown[i]!.batchNumber,
          "product_name": selectedProductsList[i].name,
          "quantity_in": batchPriceDropdown[i]!.quantityIn
        };

        arrayProducts.add(object);
      }
    }
    Map data = {
      "bu": buId,
      "raw_material_id": widget.recordId,
      "products": arrayProducts,
      "issued_to": {
        "user_id": issuedToDropdownValue!.id,
        "user_name": issuedToDropdownValue!.name
      },
      "approved_by": {"user_id": userId, "user_name": userName},
      "issued_purpose": _purposeController.text,
      "issue_batch_number": _issueBatchNumberController.text,
      "department": _departmentDropdownValue!.name,
      "is_consumable":true
    };
    String body = json.encode(data);

    print("accept: ${body}");

    var response = await _productService
        .acceptRawRequestForm(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          "$onError",
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          resObj,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);

      if (action == DialogAction.yes) {
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) =>
                    ConsumableMaterialTabView(isFromDrawer: true)));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  String requestFormStatus(num statusCode) {
    if (statusCode == 1) {
      return "accepted";
    } else if (statusCode == 2) {
      return "rejected";
    } else {
      return "pending";
    }
  }

  showRequestFormDetails() {
    return Container(
      margin: EdgeInsets.only(bottom: 5.0),
      child: Card(
          elevation: 2.0,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                this.cardItems(
                    Language().getString(Constants.REQUEST_ID, selectedLang),
                    "${widget.requestNumber}"),
                this.cardItems(
                    Language().getString(Constants.REQUESTED_BY, selectedLang),
                    widget.requestedBy),
                this.cardItems(
                    Language().getString(
                        (widget.isFromCreateRequestForm)
                            ? Constants.REQUEST_DATE
                            : Constants.DATE,
                        selectedLang),
                    widget.date),
                this.cardItems(
                    Language().getString(Constants.DEPARTMENT, selectedLang),
                    widget.department),
                this.cardItems(
                    Language().getString(Constants.BATCH_NO, selectedLang),
                    widget.batchNumber),
              ],
            ),
          )),
    );
  }

  cardItems(String? title, String? value) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 3.0),
      child: Row(
        children: [
          Expanded(
            child: Text(
              "$title",
              style: TextStyle(
                  color: Color(Constants.APP_COLOR),
                  fontSize: 15.0,
                  fontWeight: FontWeight.w700),
            ),
          ),
          Text("  :   "),
          Expanded(
              flex: 2,
              child: Container(
                child: Text(
                  "$value",
                  style: TextStyle(
                    fontSize: 13.0,
                    color: Color(Constants.APP_COLOR),
                  ),
                ),
              ))
        ],
      ),
    );
  }

  showUserEditableProducts() {
    return Expanded(
      child: Container(
        decoration: BoxDecoration(
            border: Border.all(color: Color(Constants.APP_COLOR))),
        child: Column(
          children: [
            Container(
              child: Padding(
                padding: const EdgeInsets.all(5.0),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        Constants.PRODUCT,
                        style: TextStyle(
                          color: Color(Constants.APP_COLOR),
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Expanded(
                      child: Text(
                        Constants.QUANTITY,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Color(Constants.APP_COLOR),
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Expanded(
                      child: Text(
                        Constants.PRICE_UNIT + " ( $orgCurrencySymbol )",
                        style: TextStyle(
                          color: Color(Constants.APP_COLOR),
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Divider(
              color: Color(Constants.APP_COLOR),
            ),
            Expanded(
              child: Scrollbar(
                thumbVisibility: true,
                thickness: 7.0,
                controller: _scrollController,
                child: ListView.builder(
                  controller: _scrollController,
                  shrinkWrap: true,
                  itemBuilder: (context, index) {
                    return Container(
                      child: this.renderProductDataDesign(index),
                    );
                  },
                  itemCount: selectedProductsList.length,
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  showuserNonEditableProducts() {
    return Expanded(
      child: Scrollbar(
        thumbVisibility: true,
        controller: _scrollController,
        child: ListView.builder(
          controller: _scrollController,
          shrinkWrap: true,
          cacheExtent: 9999,
          physics: const BouncingScrollPhysics(
              parent: AlwaysScrollableScrollPhysics()),
          itemBuilder: (context, index) {
            return ProductCardDesignView(
              strTotalAmount:
                  Language().getString(Constants.TOTAL_AMOUNT, selectedLang),
              strUnitPrice:
                  Language().getString(Constants.PRICE_UNIT, selectedLang),
              strQuantity:
                  Language().getString(Constants.QUANTITY, selectedLang),
              strOfferApplied:
                  Language().getString(Constants.OFFER_APPLIED, selectedLang),
              productImage: widget.productList![index].imageUrl!.length > 0
                  ? widget.productList![index].imageUrl![0].image
                  : "",
              productName: widget.productList![index].productName,
              productPrice: widget.productList![index].productCost,
              productQnty: widget.productList![index].quantity,
              isFromPO: true,
              quantityIn: widget.productList![index].quantityIn,
            );
          },
          itemCount: widget.productList!.length,
        ),
      ),
    );
  }

  rejectRawRequestForm() async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = "Rejecting..";
    });

    Map data = {"bu": buId, "raw_material_id": widget.recordId};
    String body = json.encode(data);

    var response = await _productService
        .rejectRawRequestForm(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          "$onError",
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);

      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          Language().getString(Constants.REQUEST_FORM_REJECTED, selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);

      if (action == DialogAction.yes) {
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) =>
                    ConsumableMaterialTabView(isFromDrawer: true)));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  serviceCallDepartments() async {
    if (await NetworkStatus.getInternetStatus()) {
      getDepartments().then((value) {
        setState(() {
          _departmentList.clear();
          _departmentList.addAll(value);

          for (int i = 0; i < _departmentList.length; i++) {
            if (widget.department == _departmentList[i].name) {
              _departmentDropdownValue = _departmentList[i];
            }
          }
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<DepartmentDAO>> getDepartments() async {
    http.Response response = await _service.get_department();
    List<DepartmentDAO> list = [];

    if (response.statusCode == 200) {
      var data = json.decode(response.body);
      for (var object in data["data"]) {
        list.add(DepartmentDAO.fromJson(object));
      }
    }
    return list;
  }

  buildDepartmentDropdown(StateSetter setState) {
    return Container(
        padding: EdgeInsets.all(1),
        margin: EdgeInsets.symmetric(vertical: 5.0),
        decoration: AppUtills.boxDecoration(),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 5),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                            Language().getString(
                                Constants.CONTACT_DEPT, selectedLang),
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: StyleView.FONT_TITLE))),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5, right: 5),
                  child: DropdownButton<DepartmentDAO>(
                      value: _departmentDropdownValue,
                      isExpanded: true,
                      hint: Text(Language().getString(
                          Constants.SELECT_DEPARTMENT, selectedLang)),
                      underline: SizedBox(),
                      onChanged: (DepartmentDAO? data) {
                        setState(() {
                          _departmentDropdownValue = data;
                        });
                      },
                      onTap: () {
                        CommonMethods.hideKeyboard(context);
                      },
                      items: _departmentList.map((DepartmentDAO model) {
                        return new DropdownMenuItem<DepartmentDAO>(
                          child: new Text(model.name!),
                          value: model,
                        );
                      }).toList())),
            )
          ],
        ));
  }

  void issueRawProductsValidation() async {
    bool isProductSelected = false;
    for (int i = 0; i < selectedProductsList.length; i++) {
      if (selectedProductsList[i].isButton!) {
        isProductSelected = true;
        break;
      }
    }

    /// If select any product if() block will execute.
    if (isProductSelected) {
      bool isQuantityMismatch = false;
      for (int i = 0; i < selectedProductsList.length; i++) {
        if (selectedProductsList[i].isButton!) {
          num selectBatchQuantity = batchPriceDropdown[i]!.quantity!;
          if (selectedProductsList[i].quantity! > selectBatchQuantity) {
            isQuantityMismatch = true;
            break;
          }
        }
      }

      /// If quantity is greater than selected batch quantity if() block will execute.
      if (isQuantityMismatch) {
        final action = await Dialogs.yesCancelDialog(
            context,
            Language().getString(Constants.INFO, selectedLang),
            Language().getString(
                Constants.GENERATE_INVOICE_PRICE_CHANGE, selectedLang),
            Language().getString(Constants.OKAY_STR, selectedLang),
            Language().getString(Constants.STR_CANCEL, selectedLang),
            true);
        if (action == DialogAction.yes) {
          this.showIssueUsersList();
        }
      } else {
        this.showIssueUsersList();
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.INFO, selectedLang),
          Language().getString(
              Constants.PLEASE_SELECT_ATLEAST_ANY_PRODUCT_ALERT_STRING,
              selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          Language().getString(Constants.STR_CANCEL, selectedLang),
          true);
    }
  }
}
