import 'dart:convert';
import 'dart:core';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:custom_searchable_dropdown/custom_searchable_dropdown.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:flutx/flutx.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Reports/DownloadAllReports.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/DateFilterUtil.dart';
import 'package:vyaparlive/components/MyDrawer.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/invoice_view/BatchPriceDropdownView.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/ModelProduct.dart';
import 'package:vyaparlive/model/product_model/BatchPriceDAO.dart';
import 'package:vyaparlive/model/product_model/ProductModel.dart';
import 'package:vyaparlive/model/RawProductsIssueDAO.dart';
import 'package:vyaparlive/model/UserModel.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:vyaparlive/product_consumption_view/raw_material_view/RawProductIssueCardView.dart';
import 'package:vyaparlive/product_consumption_view/raw_material_view/RawProductIssueDetails.dart';
import 'package:vyaparlive/retailer_view/card_view/ProductsCardView.dart';
import 'package:vyaparlive/service/product_services.dart';
import 'package:vyaparlive/service/user_services.dart';
import 'package:vyaparlive/utills/vyapar_info.dart';

class ConsumableProductIssueListPage extends StatefulWidget {
  final String? productName;
  final bool isFromRawproductListPage;
  ConsumableProductIssueListPage(
      {this.productName = "", this.isFromRawproductListPage = false});

  @override
  _ConsumableProductIssueListPageState createState() =>
      _ConsumableProductIssueListPageState();
}

class _ConsumableProductIssueListPageState
    extends State<ConsumableProductIssueListPage> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? buId = "";
  String? buName = "";
  String selectedLang = AppController.instance.getSelectedlanguage;
  SharedPreferences? sharedPreferences;
  bool isLoadingProgress = true;
  String progressMessage = Constants.GETTING_DATA;
  String showLoaderText = Constants.NO_DATA_FOUND;
  List<ModelProduct> _productsList = [];
  List<TextEditingController> _enterProductCount = [];
  bool isSearchForParams = false;
  late ProductService _productService;
  final TextEditingController _searchController = TextEditingController();
  List<ModelProduct> selectedList = [];
  List<UserModel> _usersList = [];
  late UserService _userService;
  UserModel? issuedToDropdownValue;
  final TextEditingController _purposeController = TextEditingController();
  List<RawProductsIssueDAO> _rawIssuesList = [];
  bool isEnableDateFilter = true;
  String fromDate = "";
  String toDate = "";
  DateFormat formatter = DateFormat("yyyy-MM-dd");
  DateTime mnthStartDate =
      DateTime.utc(DateTime.now().year, DateTime.now().month, 1);
  bool isEnableFloatButton = false;
  bool isShowProductName = false;
  ModelProduct? _selectedProductData;
  List<BuProductModal> responseProducts = [];
  String showProductText = "";
  List<BatchPriceDAO?> batchPricingDropdownList = [];
  final TextEditingController productNameController = TextEditingController();
  final TextEditingController quantityController = TextEditingController();
  List<String?> quantityInDropdownValue = [];
  BuProductModal? productNameDropdownValue;
  late ThemeData theme;
  late TextEditingController fromDateController = new TextEditingController();
  late TextEditingController toDateController = new TextEditingController();
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _productService = ProductService();
    _userService = UserService();
    buId = AppController.instance.getMyBuId;
    buName = AppController.instance.getBuName;
    fromDate = formatter.format(mnthStartDate);
    toDate = formatter.format(DateTime.now());
    fromDateController.text = fromDate;
    toDateController.text = toDate;
    this.loadServiceCalls();
    _searchController.text = widget.productName!;
  }

  loadServiceCalls() async {
    await this.loadProductData("", setState);
    this.loadRawListData(
      fromDate: fromDate,
      toDate: toDate,
      productName: widget.productName,
    );
    this.getUsersList();
  }

  loadRawListData(
      {String name = "",
      String fromDate = "",
      String toDate = "",
      String? productName = ""}) async {
    if (await NetworkStatus.getInternetStatus()) {
      if (!isSearchForParams) {
        setState(() {
          isLoadingProgress = true;
        });
      }
      getRawProductsIssuesList(
        name: name,
        fromDate: fromDate,
        toDate: toDate,
        productName: productName,
      ).then((value) {
        if (value.length > 0) {
          setState(() {
            _rawIssuesList.clear();
            _rawIssuesList.addAll(value);
          });
        } else {
          setState(() {
            showLoaderText = Constants.NO_DATA_FOUND;
          });
        }
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () {
        return CommonMethods.onBackPress(context).then((value) => value);
      },
      child: AppBackgroundView(
          body: Stack(
        children: [
          SafeArea(
            child: Scaffold(
                key: _scaffoldkey,
                backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                appBar: (widget.isFromRawproductListPage)
                    ? AppBar(
                        elevation: 0,
                        iconTheme:
                            IconThemeData(color: theme.colorScheme.primary),
                        backgroundColor:
                            Colors.transparent, //(Constants.APP_COLOR),
                        leading: IconButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                            icon: Icon(Icons.arrow_back)),
                        centerTitle: true,
                        title: AppbarName(
                            title: Language().getString(
                                Constants.CONSUMABLE_GOODS_ISSUANCE,
                                selectedLang),
                            buName: "$buName"),
                      )
                    : null,
                floatingActionButton: (isEnableFloatButton)
                    ? FloatingActionButton(
                        backgroundColor: theme.colorScheme.primary,
                        onPressed: () {
                          setState(() {
                            isEnableFloatButton = false;
                            isLoadingProgress = true;
                          });
            
                          fromDate = fromDate;
                          toDate = toDate;
                          loadRawListData(productName: widget.productName);
                        },
                        child: Text(
                          Language()
                              .getString(Constants.CLEAR_FILTERS, selectedLang),
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.white, fontSize: 11.0),
                        ))
                    : null,
                drawer: widget.isFromRawproductListPage ? null : MyDrawer(),
                body: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    children: [
                      FxSpacing.height(10),
                      // (_rawIssuesList.length > 0)
                      //     ? this.showDownloadButton()
                      //     : Container(),
                      buildSearchBarView(),
                      Padding(
                        padding:
                            const EdgeInsets.only(top: 10.0, right: 10, left: 10),
                        child: DateFilterUtill(
                          isShowSearchButton: true,
                          fromDate: "",
                          toDate: "",
                          fromDateController: fromDateController,
                          toDateController: toDateController,
                          onFromDateSelected: (value) {
                            setState(() {
                              fromDateController.text = value;
                            });
                          },
                          onToDateSelected: (value) {
                            setState(() {
                              toDateController.text = value;
                            });
                          },
                          onSearchParms: () {
                            setState(() {
                              isEnableFloatButton = true;
                              isLoadingProgress = true;
                            });
            
                            loadRawListData(productName: widget.productName);
                          },
                        ),
                      ),
                      FxSpacing.height(10),
                      (_rawIssuesList.length > 0)
                          ? Expanded(
                              child: AnimationLimiter(
                              child: ListView.separated(
                                  shrinkWrap: true,
                                  physics: new AlwaysScrollableScrollPhysics(
                                      parent: new BouncingScrollPhysics()),
                                  itemBuilder: (context, index) {
                                    return AnimationConfiguration.staggeredList(
                                        position: index,
                                        duration: Duration(milliseconds: 900),
                                        child: SlideAnimation(
                                            verticalOffset: 50.0,
                                            child: FadeInAnimation(
                                                child: InkWell(
                                              onTap: () {
                                                Navigator.push(
                                                    context,
                                                    PageTransition(
                                                        context: context,
                                                        page:
                                                            RawProductIssueDetailsPage(
                                                                recordId:
                                                                    _rawIssuesList[
                                                                            index]
                                                                        .id)));
                                              },
                                              child: RawProductIsuuesCardPage(
                                                  canShowBatchNumber: false,
                                                  selectedLang: selectedLang,
                                                  modelData:
                                                      _rawIssuesList[index]),
                                            ))));
                                  },
                                  separatorBuilder: (context, index) => Divider(
                                      color: Colors.transparent, height: 5.0),
                                  itemCount: _rawIssuesList.length),
                            ))
                          : Container(
                              child: Text(Language()
                                  .getString(showLoaderText, selectedLang))),
                    ],
                  ),
                )),
          ),
          AppUtills.showLoadingView(
              context: context,
              message: Language().getString(progressMessage, selectedLang),
              isLoading: isLoadingProgress),
        ],
      )),
    );
  }

  showProductsView() {
    return showDialog(
        context: context,
        barrierColor: Colors.black54,
        barrierDismissible: false,
        builder: (context) => StatefulBuilder(
                builder: (BuildContext context, StateSetter setState) {
              return Container(
                margin: EdgeInsets.symmetric(vertical: 20.0, horizontal: 10.0),
                child: Scaffold(
                    bottomNavigationBar: this.bottomView(),
                    backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                    body: Container(
                        margin: EdgeInsets.symmetric(
                            vertical: 10.0, horizontal: 10.0),
                        child: Column(
                          children: [
                            this.showProductSearchView(setState),
                            (_productsList.length > 0 && isShowProductName)
                                ? this.showProductNames(setState)
                                : Container(
                                    margin: EdgeInsets.symmetric(vertical: 5.0),
                                    child: (showProductText ==
                                                Constants.NO_DATA_FOUND ||
                                            showProductText == "")
                                        ? Text(showProductText)
                                        : Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              Text(showProductText),
                                              Container(
                                                height: 10.0,
                                                width: 10.0,
                                                margin: EdgeInsets.symmetric(
                                                    horizontal: 5.0),
                                                child:
                                                    CircularProgressIndicator(
                                                  strokeWidth: 2.0,
                                                ),
                                              )
                                            ],
                                          ),
                                  ),
                            (selectedList.length > 0)
                                ? this.showSelectedProductsView(setState)
                                : Container(),
                          ],
                        ))),
              );
            }));
  }

  Widget bottomView() {
    return Container(
        margin: EdgeInsets.symmetric(horizontal: 10.0),
        child: Row(
          children: [
            Expanded(
              child: Container(
                margin: EdgeInsets.only(right: 1.0),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(Constants.APP_COLOR),
                  ),
                  onPressed: () {
                    clearData();
                    Navigator.of(context).pop();
                  },
                  child: Text(
                    Language().getString(Constants.STR_CANCEL, selectedLang),
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
            Expanded(
              child: Container(
                margin: EdgeInsets.only(left: 1.0),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(Constants.APP_COLOR),
                  ),
                  onPressed: () async {
                    if (selectedList.length == 0) {
                      Dialogs.yesCancelDialog(
                          context,
                          Language().getString(Constants.ERROR, selectedLang),
                          Language().getString(
                              Constants.SELECT_PRODUCTS, selectedLang),
                          Language()
                              .getString(Constants.OKAY_STR, selectedLang),
                          "",
                          false);
                    } else {
                      this.showIssueUsersList();
                    }
                  },
                  child: Text(
                    Language().getString(Constants.CONTINUE, selectedLang),
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
          ],
        ));
  }

  loadProductData(String productName, StateSetter setState) async {
    if (await NetworkStatus.getInternetStatus()) {
      this.getBuProducts(productName: productName).then((onValue) {
        setState(() {
          responseProducts.clear();
          _productsList.clear();
          responseProducts.addAll(onValue);
          if (responseProducts.length > 0) {
            for (int i = 0; i < responseProducts.length; i++) {
              if (responseProducts[i].batchPrice!.length > 0) {
                showProductText = "";

                _productsList.add(ModelProduct(
                    id: responseProducts[i].id,
                    name: responseProducts[i].name,
                    counter: 0,
                    isButton: false,
                    images: responseProducts[i].imageThumbnail!.length > 0
                        ? responseProducts[i].imageThumbnail![0].image
                        : null,
                    price: 0,
                    quantity: responseProducts[i].batchPrice![0].quantity,
                    isItemSelected: false,
                    unitPrice: responseProducts[i].batchPrice![0].price,
                    offerList: responseProducts[i].offers,
                    batchPriceList: responseProducts[i].batchPrice));

                isShowProductName = true;
              } else {
                showProductText = Constants.NO_DATA_FOUND;
              }
            }
          } else {
            showProductText = Constants.NO_DATA_FOUND;
          }
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<BuProductModal>> getBuProducts({String productName = ""}) async {
    String body = json.encode({
      "id": buId,
      "filter": {"name": productName, "is_consumable": true}
    });

    var response = await _productService
        .getProductByBuId_v2(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<BuProductModal> products = [];

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      var data = resObj['results'];
      for (var i in data) {
        products.add(BuProductModal.fromJson(i));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return products;
  }

  buildSearchBarView() {
    return Container(
      height: 50.0,
      child: Card(
        // elevation: 5,
        shadowColor: theme.colorScheme.primary,
        shape: new RoundedRectangleBorder(
            borderRadius: new BorderRadius.circular(15),
            side: new BorderSide(
                color: theme.colorScheme.primary, strokeAlign: 0.02)),
        child: Row(
          children: <Widget>[
            Expanded(
                flex: 5,
                child: Row(
                  children: [
                    Expanded(
                      flex: 5,
                      child: Container(
                        padding: EdgeInsets.only(left: 10),
                        child: TextFormField(
                          controller: _searchController,
                          onChanged: onSearchTextChanged,
                          style: TextStyle(fontWeight: StyleView.fontSemiBold),
                          decoration: InputDecoration(
                              contentPadding: EdgeInsets.only(bottom: 10),
                              border: InputBorder.none,
                              hintText: Language().getString(
                                  Constants.SEARCH_BY_REQUESTER_NAME,
                                  selectedLang),
                              hintStyle: TextStyle(
                                  fontSize: 13.0,
                                  fontFamily: StyleView.FONT_TITLE)),
                        ),
                      ),
                    ),
                    if (_searchController.text.isNotEmpty)
                      Expanded(
                        flex: 1,
                        child: Container(
                          child: IconButton(
                              icon: Icon(Icons.close,
                                  color: Colors.red, size: 20.0),
                              onPressed: () {
                                CommonMethods.hideKeyboard(context);
                                _searchController.clear();
                                onSearchTextChanged('');
                              }),
                        ),
                      ),
                  ],
                )),
            Container(
                child: IconButton(
                    onPressed: () {
                      this.showFilterPopupView();
                    },
                    icon: Icon(
                      Icons.filter_list,
                      color: theme.colorScheme.primary,
                    )))
          ],
        ),
      ),
    );
  }

  onSearchTextChanged(String text) async {
    if (text.isEmpty) {
      setState(() {
        showLoaderText = Constants.LOADING;
        isSearchForParams = false;
      });

      loadRawListData(productName: widget.productName);
    } else {
      setState(() {
        showLoaderText = Constants.LOADING;
        isSearchForParams = true;
      });
      loadRawListData(name: text, productName: widget.productName);
    }
  }

  removeProductsQuantity(int index, StateSetter setState) {
    int? countDecrement = selectedList[index].counter;
    setState(() {
      if (countDecrement! > 1) {
        countDecrement = countDecrement! - 1;
        selectedList[index].counter = countDecrement;

        setState(() {
          selectedList[index].counter = countDecrement;
          _enterProductCount[index] = TextEditingController(
              text: selectedList[index].counter.toString());
          _enterProductCount[index].selection = TextSelection.fromPosition(
              TextPosition(offset: _enterProductCount[index].text.length));
        });
      }
    });
  }

  addProductsQuantity(int index, StateSetter setState) {
    int? countIncrement = selectedList[index].counter;

    if (countIncrement == 1) {
      setState(() {
        countIncrement = countIncrement! + 1;
        selectedList[index].counter = countIncrement;

        _enterProductCount[index] =
            TextEditingController(text: selectedList[index].counter.toString());
        _enterProductCount[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _enterProductCount[index].text.length));
      });
    } else {
      setState(() {
        countIncrement = countIncrement! + 1;
        selectedList[index].counter = countIncrement;

        _enterProductCount[index] =
            TextEditingController(text: selectedList[index].counter.toString());
        _enterProductCount[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _enterProductCount[index].text.length));
      });
    }
  }

  designQuantityInputField(int index, StateSetter setState) {
    return Container(
      height: 60.0,
      width: 60.0,
      child: TextFormField(
        enableInteractiveSelection: false,
        textAlign: TextAlign.center,
        controller: _enterProductCount[index],
        decoration: InputDecoration(
          hintText: "",
          border: InputBorder.none,
        ),
        keyboardType: TextInputType.numberWithOptions(signed: true),
        style: TextStyle(fontSize: 12.0),
        inputFormatters: [
          new LengthLimitingTextInputFormatter(5),
          FilteringTextInputFormatter.digitsOnly
        ],
        onFieldSubmitted: (value) {
          if (value == "0" || value.isEmpty) {
            selectedList[index].counter = 1;
          }
        },
        onChanged: (value) {
          setState(() {
            if (selectedList.length > 0) {
              if (value.isEmpty) {
                selectedList[index].counter = 0;
              } else {
                selectedList[index].counter = int.parse(value);
              }
            }
          });
        },
      ),
    );
  }

  getUsersList({String name = ""}) async {
    if (await NetworkStatus.getInternetStatus()) {
      this.getAllUsers(name: name).then((value) {
        setState(() {
          _usersList.clear();
          _usersList.addAll(value);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  /// Service call for getUsers
  Future<List<UserModel>> getAllUsers({String name = ""}) async {
    setState(() {
      _usersList.clear();
    });
    String body = json.encode({"id": buId, "filters": {}});

    var response = await _userService
        .getUserByBuId_grpc(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    List<UserModel> _users = [];
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      var resultArray = resObj['results'];
      for (var data in resultArray) {
        _users.add(UserModel.fromJson(data));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return _users;
  }

  showIssueUsersList() {
    return showDialog(
        context: context,
        barrierColor: Colors.black54,
        barrierDismissible: false,
        builder: (context) =>
            StatefulBuilder(builder: (context, StateSetter setState) {
              return Container(
                margin: EdgeInsets.symmetric(vertical: 20.0, horizontal: 10.0),
                child: Scaffold(
                    bottomNavigationBar: Container(
                        margin: EdgeInsets.symmetric(horizontal: 10.0),
                        child: Row(
                          children: [
                            Expanded(
                              child: Container(
                                margin: EdgeInsets.only(right: 1.0),
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Color(Constants.APP_COLOR),
                                  ),
                                  onPressed: () {
                                    issuedToDropdownValue = null;
                                    _purposeController.clear();
                                    Navigator.of(context).pop();
                                  },
                                  child: Text(
                                    Language().getString(
                                        Constants.STR_CANCEL, selectedLang),
                                    style: TextStyle(color: Colors.white),
                                  ),
                                ),
                              ),
                            ),
                            Expanded(
                              child: Container(
                                margin: EdgeInsets.only(left: 1.0),
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Color(Constants.APP_COLOR),
                                  ),
                                  onPressed: () async {
                                    if (issuedToDropdownValue == null) {
                                      Dialogs.yesCancelDialog(
                                          context,
                                          Language().getString(
                                              Constants.ERROR, selectedLang),
                                          Language().getString(
                                              Constants.SELECT_USER,
                                              selectedLang),
                                          Language().getString(
                                              Constants.OKAY_STR, selectedLang),
                                          "",
                                          false);
                                    } else {
                                      Navigator.of(context).pop();
                                      Navigator.of(context).pop();
                                      this.createRawProductIssueList();
                                    }
                                  },
                                  child: Text(
                                    Language().getString(
                                        Constants.CONFIRM, selectedLang),
                                    style: TextStyle(color: Colors.white),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        )),
                    backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                    body: Container(
                        margin: EdgeInsets.symmetric(
                            vertical: 10.0, horizontal: 10.0),
                        child: Column(
                          children: [
                            Container(
                              margin: EdgeInsets.symmetric(vertical: 5.0),
                              child: Text(
                                Language().getString(
                                    Constants.ISSUING_DETAILS, selectedLang),
                                style: TextStyle(
                                    color: Color(Constants.APP_COLOR),
                                    fontSize: 15.0,
                                    fontWeight: FontWeight.bold),
                              ),
                            ),
                            this.buildDropdownIssueTo(setState),
                            Expanded(
                              child: Container(
                                margin: EdgeInsets.symmetric(vertical: 5.0),
                                child: TextFormField(
                                    controller: _purposeController,
                                    style: TextStyle(
                                        fontFamily: StyleView.FONT_TITLE),
                                    decoration: StyleView.getInputDecoration(
                                        helper: Language().getString(
                                            Constants.PURPOSE, selectedLang)),
                                    maxLines: 3),
                              ),
                            ),
                          ],
                        ))),
              );
            }));
  }

  buildDropdownIssueTo(StateSetter setState) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 5.0),
      decoration: AppUtills.boxDecoration(),
      child: DropdownButton<UserModel>(
        items: _usersList.map((UserModel model) {
          return new DropdownMenuItem<UserModel>(
            child: new Text(model.name!),
            value: model,
          );
        }).toList(),
        value: issuedToDropdownValue,
        underline: Container(),
        hint: Language().getString(Constants.ISSUED_TO, selectedLang),
        onChanged: (value) {
          setState(() {
            issuedToDropdownValue = value;
          });
        },
        isExpanded: true,
      ),
    );
  }

  createRawProductIssueList() async {
    setState(() {
      isLoadingProgress = true;
    });
    List<Map<String, dynamic>> productsArrayList = [];
    var object;
    if (selectedList.length > 0) {
      for (int i = 0; i < selectedList.length; i++) {
        object = {
          "id": selectedList[i].id,
          "quantity": selectedList[i].counter,
          "batch_no": batchPricingDropdownList[i]!.batchNumber,
          "quantity_in": quantityInDropdownValue[i]
        };
        productsArrayList.add(object);
      }
    }

    String body = json.encode({
      "bu_id": buId,
      "issued_purpose": _purposeController.text,
      "issued_to": issuedToDropdownValue!.name,
      "products": productsArrayList
    });

    var response = await _productService
        .createRawProductIssue(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
    });

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          Language().getString(
              Constants.RAW_MATERIAL_ISSUED_SUCCESSFULLY, selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);

      if (action == DialogAction.yes) {
        this.clearData();
        loadRawListData(productName: widget.productName);
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  Future<List<RawProductsIssueDAO>> getRawProductsIssuesList(
      {String name = "",
      String fromDate = "",
      String toDate = "",
      String? productName = ""}) async {
    setState(() {
      _rawIssuesList.clear();
    });
    String body = json.encode({
      "bu_id": buId,
      "filters": {
        "issued_to": name,
        "DateFrom": fromDateController.text,
        "DateTo": toDateController.text,
        "product_name": productName,
        "is_consumable": true
      }
    });

    print("Issuance note request: ${body}");

    var response = await _productService
        .getIssueNotesByBuId(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<RawProductsIssueDAO> list = [];
    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(resObj)) {
        var data = resObj["results"];
        for (var obj in data) {
          list.add(RawProductsIssueDAO.fromJson(obj));
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return list;
  }

  Widget showProductNames(StateSetter setState) {
    return Container(
        height: 100.0,
        decoration: BoxDecoration(
          color: Colors.grey[400],
          borderRadius: BorderRadius.circular(5.0),
        ),
        child: ListView.builder(
          itemBuilder: (context, index) {
            return InkWell(
              onTap: () {
                CommonMethods.hideKeyboard(context);
                setState(() {
                  quantityController.text = "1";
                  _productsList[index].counter =
                      int.parse(quantityController.text);
                  productNameController.text = _productsList[index].name!;
                  isShowProductName = false;
                  _selectedProductData = _productsList[index];
                });
              },
              child: Card(
                color: Colors.grey[100],
                elevation: 2.5,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(_productsList[index].name!,
                          style: TextStyle(color: Colors.black)),
                      Icon(Icons.arrow_forward, color: Colors.blue, size: 20.0),
                    ],
                  ),
                ),
              ),
            );
          },
          itemCount: _productsList.length,
          shrinkWrap: true,
        ));
  }

  batchPricingDropdownView(
      List<BatchPriceDAO> batchNumberList, int index, StateSetter setState) {
    if (batchNumberList.length > 0 && batchPricingDropdownList.length > 0) {
      if (batchPricingDropdownList[index] == null) {
        batchPricingDropdownList[index] = batchNumberList[0];
      }

      return Expanded(
        child: BatchPriceDropDownView(
            canShowPrice: false,
            canShowDynamicPricing: false,
            currentDropdownIndex: index,
            batchPricingList: batchNumberList,
            batchDropdown: batchPricingDropdownList,
            selectedDropdownValue: (data) {
              setState(() {
                batchPricingDropdownList[index] = data;
              });
            },
            strBatchPricing:
                Language().getString(Constants.BATCH_NO, selectedLang),
            strAvailableQuantity: Language()
                .getString(Constants.AVAILABLE_QUANTITY, selectedLang)),
      );
    }
  }

  batchQuantityUnitsropdownView(int index, StateSetter setState) {
    if (quantityInDropdownValue[index] == null) {
      quantityInDropdownValue[index] = "unit";
    }
    return Expanded(
      child: Row(
        children: [
          Container(
              child: Text(
                  Language().getString(Constants.QUANTITY_IN, selectedLang) +
                      " : ",
                  style: TextStyle(
                    fontSize: 13.0,
                  ))),
          Expanded(
              child: Container(
                  color: Colors.white,
                  padding: EdgeInsets.only(left: 5),
                  child: DropdownButton<String>(
                      onTap: () {
                        FocusScope.of(context).unfocus();
                      },
                      value: quantityInDropdownValue[index],
                      hint: new Text(
                        Language().getString(Constants.SELECT, selectedLang),
                      ),
                      isExpanded: true,
                      underline: SizedBox(),
                      onChanged: (String? data) {
                        setState(() {
                          quantityInDropdownValue[index] = data;
                        });
                      },
                      items: Constants.UNIT_PRICE.map((String model) {
                        return new DropdownMenuItem<String>(
                          child: new Text(model),
                          value: model,
                        );
                      }).toList()))),
        ],
      ),
    );
  }

  addToInvoiceProductsArray(StateSetter setState) {
    setState(() {
      bool isExist = false;
      int index = -1;
      for (int i = 0; i < selectedList.length; i++) {
        if (_selectedProductData!.id == selectedList[i].id) {
          isExist = true;
          index = i;
        }
      }

      if (isExist) {
        selectedList[index].counter =
            selectedList[index].counter! + int.parse(quantityController.text);

        _enterProductCount[index] =
            TextEditingController(text: selectedList[index].counter.toString());
        _enterProductCount[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _enterProductCount[index].text.length));
      } else {
        selectedList.add(ModelProduct(
            name: _selectedProductData!.name,
            id: _selectedProductData!.id,
            price: _selectedProductData!.price,
            counter: int.parse(quantityController.text),
            images: _selectedProductData!.images,
            isButton: _selectedProductData!.isButton,
            isItemSelected: _selectedProductData!.isItemSelected,
            batchPriceList: _selectedProductData!.batchPriceList,
            unitPrice: _selectedProductData!.unitPrice,
            quantity: _selectedProductData!.quantity));

        _enterProductCount.add(new TextEditingController());
        batchPricingDropdownList.add(null);
        quantityInDropdownValue.add(null);
      }

      _selectedProductData = null;
      productNameController.clear();
      quantityController.clear();
    });
  }

  Widget showSelectedProductsView(StateSetter setState) {
    return Expanded(
        child: Container(
      margin: EdgeInsets.only(top: 5.0),
      decoration: AppUtills.boxDecoration(),
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.all(5.0),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    Language().getString(Constants.PRODUCT_NAME, selectedLang),
                    style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                        fontWeight: FontWeight.bold),
                  ),
                ),
                Expanded(
                  child: Text(
                    Language().getString(Constants.QUANTITY, selectedLang),
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
          ),
          Divider(
            color: Color(Constants.APP_COLOR),
          ),
          Expanded(
            child: ListView.separated(
                shrinkWrap: true,
                separatorBuilder: (context, index) => new Divider(
                      color: Colors.transparent,
                      height: 0.0,
                    ),
                itemCount: selectedList.length,
                itemBuilder: (context, index) {
                  _enterProductCount[index] = TextEditingController(
                      text: selectedList[index].counter.toString());
                  _enterProductCount[index].selection =
                      TextSelection.fromPosition(TextPosition(
                          offset: _enterProductCount[index].text.length));
                  return Card(
                    child: Column(
                      children: [
                        ProductsCardView(
                          onRemoveProductQuantit: () {
                            removeProductsQuantity(index, setState);
                          },
                          onAddProductQuantity: () {
                            addProductsQuantity(index, setState);
                          },
                          desingQuntityField: Container(
                            width: 50.0,
                            height: 30.0,
                            alignment: Alignment.bottomCenter,
                            decoration: AppUtills.boxDecoration(),
                            child:
                                this.designQuantityInputField(index, setState),
                          ),
                          productName: selectedList[index].name,
                          removeProduct: () async {
                            final action = await Dialogs.yesCancelDialog(
                                context,
                                Language()
                                    .getString(Constants.WARNING, selectedLang),
                                Language().getString(
                                    Constants.WARNING_TEXT, selectedLang),
                                Language().getString(
                                    Constants.OKAY_STR, selectedLang),
                                "",
                                false);

                            if (action == DialogAction.yes) {
                              setState(() {
                                selectedList.removeAt(index);
                                batchPricingDropdownList.removeAt(index);
                                quantityInDropdownValue.removeAt(index);
                              });
                            }
                          },
                          productTotalPrice: 0,
                          isFromRawProductIssuePage: true,
                        ),
                        Container(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              (batchPricingDropdownList.length > 0)
                                  ? this.batchPricingDropdownView(
                                      selectedList[index].batchPriceList!,
                                      index,
                                      setState)
                                  : Container(),
                            ],
                          ),
                        ),
                        Container(
                          child: Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                (quantityInDropdownValue.length > 0)
                                    ? this.batchQuantityUnitsropdownView(
                                        index, setState)
                                    : Container()
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                }),
          )
        ],
      ),
    ));
  }

  clearData() {
    setState(() {
      _productsList.clear();
      batchPricingDropdownList.clear();
      _enterProductCount.clear();
      productNameController.clear();
      quantityController.clear();
      _selectedProductData = null;
      selectedList.clear();
      showProductText = "";
      _purposeController.clear();
      issuedToDropdownValue = null;
    });
  }

  Widget showProductSearchView(StateSetter setState) {
    return Container(
      decoration: AppUtills.boxDecoration(),
      margin: EdgeInsets.only(top: 5.0),
      height: 40.0,
      alignment: Alignment.centerLeft,
      child: Container(
        color: Colors.grey,
        alignment: Alignment.centerLeft,
        child: Row(
          children: [
            Expanded(
              flex: 2,
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(5.0),
                      bottomLeft: Radius.circular(5.0)),
                  color: Color(Constants.APP_BACKGROUND_COLOR),
                ),
                margin: EdgeInsets.only(right: 1.0),
                child: Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: TextField(
                    controller: productNameController,
                    keyboardType: TextInputType.text,
                    // focusNode: FocusNode(),
                    decoration: InputDecoration(
                        hintText: Language().getString(
                            "Search by product name..", selectedLang),
                        hintStyle: TextStyle(fontSize: 12.0),
                        border: InputBorder.none),
                    onChanged: (_text) {
                      if (_text.isNotEmpty) {
                        setState(() {
                          showProductText = Constants.LOADING;
                        });

                        this.loadProductData(_text, setState);
                      } else {
                        setState(() {
                          showProductText = "";
                          isShowProductName = false;
                          _productsList.clear();
                        });
                      }
                    },
                    style: TextStyle(
                        fontSize: 12.0, decoration: TextDecoration.none),
                  ),
                ),
              ),
            ),
            Expanded(
              child: Container(
                color: Color(Constants.APP_BACKGROUND_COLOR),
                margin: EdgeInsets.only(right: 1.0),
                child: Padding(
                  padding: const EdgeInsets.all(2.0),
                  child: TextFormField(
                    controller: quantityController,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: Constants.QUANTITY,
                      hintStyle: TextStyle(fontSize: 12.0),
                    ),
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 12.0),
                  ),
                ),
              ),
            ),
            SizedBox(
              width: 30.0,
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                      topRight: Radius.circular(5.0),
                      bottomRight: Radius.circular(5.0)),
                  color: Color(Constants.APP_BACKGROUND_COLOR),
                ),
                child: IconButton(
                    padding: EdgeInsets.all(0.0),
                    icon: Icon(
                      Icons.add,
                    ),
                    onPressed: () {
                      CommonMethods.hideKeyboard(context);
                      if (_selectedProductData != null) {
                        if (_selectedProductData!.counter == 0) {
                          Dialogs.yesCancelDialog(
                              context,
                              Language()
                                  .getString(Constants.ERROR, selectedLang),
                              Language().getString(
                                  Constants.ENTER_VALID_QUANTITY, selectedLang),
                              Language()
                                  .getString(Constants.OKAY_STR, selectedLang),
                              "",
                              false);
                        } else {
                          this.addToInvoiceProductsArray(setState);
                        }
                      }
                    }),
              ),
            )
          ],
        ),
      ),
    );
  }

  showFilterPopupView() {
    return showDialog(
        barrierDismissible: false,
        context: context,
        builder: (context) =>
            StatefulBuilder(builder: (context, StateSetter setState) {
              return Container(
                margin: EdgeInsets.symmetric(vertical: 50.0, horizontal: 20.0),
                child: Scaffold(
                  bottomNavigationBar: Container(
                      padding:
                          EdgeInsets.symmetric(vertical: 20, horizontal: 10),
                      child: CommonButtonsView(
                        context: context,
                        b1Text: Language()
                            .getString(Constants.STR_CANCEL, selectedLang),
                        b2Text: Language()
                            .getString(Constants.APPLY_FILTER, selectedLang),
                        onb1Action: () {
                          setState(() {
                            productNameDropdownValue = null;
                          });
                          Navigator.of(context).pop();
                        },
                        onb2Action: () {
                          setState(() {
                            isEnableFloatButton = true;
                          });
                          Navigator.of(context).pop();
                          this.loadRawListData(
                              productName: productNameDropdownValue != null
                                  ? productNameDropdownValue!.name
                                  : "");
                        },
                      )),
                  body: Container(
                    margin:
                        EdgeInsets.symmetric(vertical: 5.0, horizontal: 10.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          margin: EdgeInsets.symmetric(vertical: 5.0),
                          alignment: Alignment.center,
                          child: Text(
                            Language()
                                .getString(Constants.SORT_BY_STR, selectedLang),
                            style: TextStyle(
                                color: theme.colorScheme.primary,
                                fontSize: 15.0,
                                fontWeight: StyleView.fontSemiBold,
                                fontFamily: StyleView.FONT_TITLE),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.symmetric(vertical: 5.0),
                          child: Text(
                            Language().getString(
                                Constants.PRODUCT_NAME, selectedLang),
                            style: TextStyle(
                                color: Color(Constants.APP_COLOR),
                                fontSize: 15.0,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                        this.buildDropdownProductName(setState),
                      ],
                    ),
                  ),
                ),
              );
            }));
  }

  buildDropdownProductName(StateSetter setState) {
    return Container(
        margin: EdgeInsets.symmetric(vertical: 5.0),
        decoration: AppUtills.boxDecoration(),
        child: CustomSearchableDropDown(
          items: responseProducts.toList(),
          label: productNameDropdownValue == null
              ? Language().getString(Constants.SEARCH_BY_PRODUCT, selectedLang)
              : productNameDropdownValue!.name,
          dropdownItemStyle: TextStyle(color: Colors.black),
          labelStyle: TextStyle(
              fontWeight: StyleView.fontMedium,
              color: Colors.black,
              fontSize: 14.0),
          suffixIcon: Padding(
            padding: const EdgeInsets.all(0.0),
            child: Icon(Icons.search),
          ),
          dropDownMenuItems: responseProducts.map((item) {
            return item.name;
          }).toList(),
          onChanged: (value) {
            if (value != null) {
              // setState(() {
              productNameDropdownValue = value;

              // });
            }
          },
        )
        // SearchableDropdown.single(
        //   items: responseProducts.map((BuProductModal model) {
        //     return new DropdownMenuItem<BuProductModal>(
        //       child: new Text(model.name),
        //       value: model,
        //     );
        //   }).toList(),
        //   value: productNameDropdownValue,
        //   underline: Container(),
        //   hint: Language().getString(Constants.SEARCH_BY_PRODUCT, selectedLang),
        //   searchHint:
        //       Language().getString(Constants.SEARCH_BY_PRODUCT, selectedLang),
        //   onChanged: (value) {
        //     setState(() {
        //       productNameDropdownValue = value;
        //     });
        //   },
        //   isExpanded: true,
        // ),
        );
  }

  Widget showDownloadButton() {
    String reqBody = "";
    String reqUrl = "";
    reqUrl = Constants.NEW_BASE_URL + "http-utils/reports/rawIssueNotes";
    reqBody = json.encode({
      "bu_id": buId,
      "filters": {
        "issued_to":
            issuedToDropdownValue != null ? issuedToDropdownValue!.name : "",
        "DateFrom": fromDate,
        "DateTo": toDate,
        "product_name": productNameDropdownValue != null
            ? productNameDropdownValue!.name
            : ""
      }
    });

    var encryptedData = VyaparInfo.encryptData(reqBody);
    Map map = {
      "data": encryptedData,
      "Authorization": AppController.instance.getAuthorizationKey
    };
    return DownloadAllReportsPage(
        isApiCallComplete: (apiCallCompleted) {
          if (apiCallCompleted) {
            setState(() {
              isLoadingProgress = false;
            });
          } else {
            setState(() {
              isLoadingProgress = true;
            });
          }
        },
        url: reqUrl,
        mapData: map,
        fileName: Constants.RAW_MARETIAL_ISSUE,
        strDownload: Language().getString(Constants.DOWNLOAD, selectedLang));
  }
}
