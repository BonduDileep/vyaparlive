import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:flutx/flutx.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/DateFilterUtil.dart';
import 'package:vyaparlive/components/MyDrawer.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/DepartmentDAO.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/ModelProduct.dart';
import 'package:vyaparlive/model/RawRequestFormDAO.dart';
import 'package:vyaparlive/model/UserModel.dart';
import 'package:vyaparlive/model/product_model/BatchPriceDAO.dart';
import 'package:vyaparlive/model/product_model/ProductModel.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:vyaparlive/product_consumption_view/raw_material_view/RawRequestFormCardView.dart';
import 'package:vyaparlive/retailer_view/card_view/ProductsCardView.dart';
import 'package:vyaparlive/service/Service.dart';
import 'package:vyaparlive/service/product_services.dart';
import 'package:vyaparlive/service/user_services.dart';
import 'package:vyaparlive/utills/SharePref.dart';
import 'package:http/http.dart' as http;

import '../../../core/enums/privilleges_enum.dart';
import '../EditConsumableRequestPage.dart';

class ConsumableFormPage extends StatefulWidget {
  @override
  _ConsumableFormPageState createState() => _ConsumableFormPageState();
}

class _ConsumableFormPageState extends State<ConsumableFormPage> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? buId = '';
  String? buName = '';
  List<BuProductModal> resProducts = [];
  String selectedLang = AppController.instance.getSelectedlanguage;
  SharedPreferences? sharedPreferences;
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  late ProductService _productService;
  bool isSearchForParams = false;
  num totalBatchQuantity = 0;
  List<num> batchQuantityList = [];
  static String showLoaderText = Constants.NO_DATA_FOUND;
  String? orgCurrencySymbol = "";

  List<TextEditingController> _enterProductCount = [];
  List<ModelProduct> _productsList = [];
  final _searchController = TextEditingController();
  UserModel? issuedToDropdownValue;
  final TextEditingController _purposeController = TextEditingController();
  String? loginUserId = "";
  List<RawRequestFormDAO> formList = [];
  String startDate = "";
  String endDate = "";
  DateFormat formatter = DateFormat("yyyy-MM-dd");
  DateTime mnthStartDate =
      DateTime.utc(DateTime.now().year, DateTime.now().month, 1);
  String showProductText = "";
  List<BatchPriceDAO?> batchPricingDropdownList = [];
  final TextEditingController productNameController = TextEditingController();
  final TextEditingController quantityController = TextEditingController();
  bool isShowProductName = false;
  ModelProduct? _selectedProductData;
  List<ModelProduct> selectedList = [];
  List<ModelProduct> selectedProducts = [];
  List<String?> quantityInDropdownValue = [];
  List<BuProductModal> responseProducts = [];
  bool isEnableDateFilter = true;
  bool isShowFloatButton = false;
  List<Map> _mapData = [];
  String? userName = "";
  final TextEditingController _issueBatchNumberController =
      new TextEditingController();
  DepartmentDAO? _departmentDropdownValue;
  List<DepartmentDAO> _departmentList = [];
  late Service _service;
  late UserService _userService;
  UserModel? _userModel;
  ScrollController? _scrollController;
  late ThemeData theme;
  late TextEditingController fromDateController = new TextEditingController();
  late TextEditingController toDateController = new TextEditingController();

  late List<TextEditingController> quantityControllerList = [];

  @override
  void initState() {
    super.initState();
    this.getLoadLanguage();
    _scrollController = new ScrollController();
    theme = AppTheme.vyaparTheme;
    _userService = UserService();
    _productService = ProductService();
    _service = Service();
    buId = AppController.instance.getMyBuId;
    buName = AppController.instance.buName;
    // orgCurrencySymbol = AppController.instance.getBuCurrencySymbol;
    String? symbol = AppController.instance.getBuCurrencySymbol;
    orgCurrencySymbol = (symbol != null && symbol.isNotEmpty && symbol!="-") ? symbol : "\u20B9";
    SharePref().getUserId().then((value) {
      setState(() {
        loginUserId = value;
      });
    });
    startDate = formatter.format(mnthStartDate);
    endDate = formatter.format(DateTime.now());
    fromDateController.text = startDate;
    toDateController.text = endDate;
    loadFormListData();
    SharePref().getUserName().then((value) {
      setState(() {
        userName = value;
      });
    });
    this.serviceCallDepartment();
    // loadProductData("");
  }

  serviceCallDepartment() async {
    if (await NetworkStatus.getInternetStatus()) {
      await this.getUserDataById().then((value) {
        setState(() {
          _userModel = value;
        });
      });
      await getDepartments().then((value) {
        setState(() {
          _departmentList.clear();
          _departmentList.addAll(value);
          for (int i = 0; i < _departmentList.length; i++) {
            if (_userModel != null &&
                _userModel!.businessUnits![0].departmentName ==
                    _departmentList[i].name) {
              _departmentDropdownValue = _departmentList[i];
            }
          }
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
      body: WillPopScope(
        onWillPop: () {
          return CommonMethods.onBackPress(context).then((value) => value);
        },
        child: Stack(
          children: [
            SafeArea(
              child: Scaffold(
                key: _scaffoldkey,
                backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                appBar: AppBar(
                  elevation: 0,
                  iconTheme: IconThemeData(color: theme.colorScheme.primary),
                  backgroundColor: Colors.transparent, //(Constants.APP_COLOR),
                  centerTitle: true,
                  title: AppbarName(
                      title: Language().getString(
                          Constants.CONSUMABLE_REQUEST_FORM, selectedLang),
                      buName: "$buName"),
                  actions: [
                    // IconButton(onPressed: (), icon: Icon(Icons.filter_list)),
                    if (CommonMethods.isPrivillegeExist(
                        context,
                        PrivillegesActions
                            .CONSUMABLE_MATERIAL_MENU_CONSUMABLE_MATERIAL_REQUEST_FORM_ADD))
                      IconButton(
                          onPressed: () {
                            setState(() {
                              selectedList.clear();
                              _issueBatchNumberController.clear();
                              // _departmentDropdownValue = null;
                              _purposeController.clear();
                              for (int i = 0; i < _departmentList.length; i++) {
                                if (_userModel != null &&
                                    _userModel!
                                            .businessUnits![0].departmentName ==
                                        _departmentList[i].name) {
                                  _departmentDropdownValue = _departmentList[i];
                                }
                              }
                            });
                            // showRequestDialog(context);
                            this.showProductsView();
                          },
                          icon: Icon(Icons.add))
                  ],
                ),
                drawer: MyDrawer(),
                body: Container(
                  margin: EdgeInsets.symmetric(horizontal: 10.0, vertical: 5.0),
                  child: Column(
                    children: [
                      FxSpacing.height(10),
                      buildSearchFilterView(),
                      // (isEnableDateFilter)?
                      Padding(
                        padding:
                            const EdgeInsets.only(top: 10.0, left: 5, right: 5),
                        child: DateFilterUtill(
                          isShowSearchButton: true,
                          fromDate: "",
                          toDate: "",
                          fromDateController: fromDateController,
                          toDateController: toDateController,
                          onFromDateSelected: (value) {
                            setState(() {
                              fromDateController.text = value;
                            });
                          },
                          onToDateSelected: (value) {
                            setState(() {
                              toDateController.text = value;
                            });
                          },
                          onSearchParms: () {
                            setState(() {
                              isShowFloatButton = true;
                              isLoadingProgress = true;
                            });
                            loadFormListData();
                          },
                        ),
                      ),
                      //     : Container(),
                      FxSpacing.height(10),
                      (formList.length > 0 && _mapData.length > 0)
                          ? Expanded(
                              child: AnimationLimiter(
                                child: ListView.separated(
                                  shrinkWrap: true,
                                  separatorBuilder: (context, index) =>
                                      new Divider(
                                    height: 5,
                                    color: Colors.transparent,
                                  ),
                                  physics: BouncingScrollPhysics(
                                      parent: AlwaysScrollableScrollPhysics()),
                                  itemBuilder: (context, index) {
                                    return AnimationConfiguration.staggeredList(
                                        position: index,
                                        duration: Duration(milliseconds: 900),
                                        child: SlideAnimation(
                                            verticalOffset: 50.0,
                                            child: FadeInAnimation(
                                                child: showRequestFormList(
                                                    formList[index]))));
                                  },
                                  itemCount: formList.length,
                                ),
                              ),
                            )
                          : Center(
                              child: Text(Language()
                                  .getString(showLoaderText, selectedLang)),
                            )
                    ],
                  ),
                ),
              ),
            ),
            AppUtills.showLoadingView(
                context: context,
                message: Language().getString(progressMessage, selectedLang),
                isLoading: isLoadingProgress)
          ],
        ),
      ),
    );
  }

  showRequestDialog(context) {
    return showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
            contentPadding: EdgeInsets.fromLTRB(0, 20, 0, 0),
            titlePadding: EdgeInsets.zero,
            title: Container(
              padding: EdgeInsets.symmetric(horizontal: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                      child: Text(
                          Language()
                              .getString(Constants.CHOOSE_ONE, selectedLang),
                          style: TextStyle(
                              color: theme.colorScheme.primary,
                              fontSize: 18.0,
                              fontWeight: StyleView.fontMedium))),
                  IconButton(
                      padding: EdgeInsets.zero,
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      icon: Icon(Icons.close, color: Colors.red)),
                ],
              ),
            ),
            content: Container(
              padding: EdgeInsets.only(bottom: 20),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                if (CommonMethods.isPrivillegeExist(
                    context,
                    PrivillegesActions
                        .CONSUMABLE_MATERIAL_MENU_CONSUMABLE_MATERIAL_REQUEST_FORM_ADD_REQUEST_FORM))
                  Container(
                    width: MediaQuery.of(context).size.width / 1.5,
                    child: CommonButtonsView(
                      context: context,
                      b1Text: "",
                      b2Text: Language()
                          .getString(Constants.NEW_REQUEST_FORM, selectedLang),
                      onb2Action: () {
                        Navigator.of(context).pop();
                        this.showProductsView();
                      },
                    ),
                  ),
                FxSpacing.height(10),
                // if (CommonMethods.isPrivillegeExist(context,
                //     PrivillegesActions.RAW_MATERIAL_MENU_RAW_MATERIAL_REQUEST_FORM_ADD_REQUEST_FORM_SELECT_FROM_TEMPLATE))
                //   Container(
                //     width: MediaQuery.of(context).size.width / 1.5,
                //     child: CommonButtonsView(
                //       context: context,
                //       b1Text: "",
                //       b2Text: Language().getString(
                //           Constants.SELECT_FROM_TEMPLATE, selectedLang),
                //       onb2Action: () {
                //         Navigator.of(context).pop();
                //         Navigator.push(
                //             context,
                //             PageTransition(
                //                 context: context,
                //                 page: CreateTemplatePgae(
                //                   isFromRawRequestForm: true,
                //                 ))).then((value) => this.loadFormListData(
                //             fromDate: startDate, toDate: endDate));
                //       },
                //     ),
                //   )
              ]),
            )));
  }

  showProductNameAndPrice(int index) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        new Text(
          _productsList[index].name!,
          style: TextStyle(
            color: Color(Constants.APP_COLOR),
            fontWeight: FontWeight.bold,
            fontSize: 17.0,
          ),
        ),
        SizedBox(height: 5),
        Text(
          Constants.PRICE +
              ' : $orgCurrencySymbol' +
              CommonMethods.getCurrencyValues(_productsList[index].price),
          style: TextStyle(fontSize: 11.0, color: Color(Constants.APP_COLOR)),
        ),
      ],
    );
  }

  showProductImage(int index) {
    return Image.memory(
      base64.decode(_productsList[index]
          .images!
          .replaceFirst(RegExp(r'data:image/[^;]+;base64,'), '')
          .toString()),
      width: 30,
      height: 30,
      gaplessPlayback: true,
    );
  }

  addProductQuantity(int index, StateSetter setState) {
    int? countIncrement = selectedList[index].counter;

    /// if response products counter == 0 adding to selected Product list and incrementing the count
    if (countIncrement == 1) {
      setState(() {
        countIncrement = countIncrement! + 1;
        selectedList[index].counter = countIncrement;
        _enterProductCount[index] =
            TextEditingController(text: selectedList[index].counter.toString());
        _enterProductCount[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _enterProductCount[index].text.length));
      });
    } else {
      /// if response products counter !=0 updating the counter to selected products counter by index and id comparing
      setState(() {
        countIncrement = countIncrement! + 1;
        selectedList[index].counter = countIncrement;
        _enterProductCount[index] =
            TextEditingController(text: selectedList[index].counter.toString());
        _enterProductCount[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _enterProductCount[index].text.length));
      });
    }
  }

  removeProductQuantity(int index, StateSetter setState) {
    int? countDecrement = selectedList[index].counter;
    setState(() {
      // /// if response products counter == 0 removing product from selected product list
      if (countDecrement == 1) {
        selectedList[index].counter = countDecrement;
        _enterProductCount[index] =
            TextEditingController(text: selectedList[index].counter.toString());
        _enterProductCount[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _enterProductCount[index].text.length));
      } else {
        /// if response products counter !=0 updaing counter to response proudcts and selected products list by comparing id
        // if (countDecrement > 0) {
        // _productsList[index].counter = countDecrement;
        // for (int i = 0; i < selectedList.length; i++) {
        //   if (_productsList[index].id == selectedList[i].id) {
        // setState(() {
        countDecrement = countDecrement! - 1;
        selectedList[index].counter = countDecrement;
        _enterProductCount[index] =
            TextEditingController(text: selectedList[index].counter.toString());
        _enterProductCount[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _enterProductCount[index].text.length));
        // });
        //   }
        // }
      }
      // }
    });
  }

  loadProductData(String productName, StateSetter setState) async {
    if (await NetworkStatus.getInternetStatus()) {
      this.getBuProducts(productName: productName).then((onValue) {
        setState(() {
          responseProducts.clear();
          _productsList.clear();
          quantityControllerList.clear();
          responseProducts.addAll(onValue);
          if (responseProducts.length > 0) {
            for (int i = 0; i < responseProducts.length; i++) {
              if (responseProducts[i].batchPrice!.length > 0) {
                showProductText = "";

                _productsList.add(ModelProduct(
                    id: responseProducts[i].id,
                    name: responseProducts[i].name,
                    counter: 0,
                    isButton: false,
                    images: responseProducts[i].imageThumbnail!.length > 0
                        ? responseProducts[i].imageThumbnail![0].image
                        : null,
                    price: 0,
                    quantity: responseProducts[i].batchPrice![0].quantity,
                    isItemSelected: false,
                    unitPrice: responseProducts[i].batchPrice![0].price,
                    offerList: responseProducts[i].offers,
                    batchPriceList: responseProducts[i].batchPrice));

                isShowProductName = true;
              } else {
                showProductText = Constants.NO_DATA_FOUND;
              }
            }

            for (int i = 0; i < _productsList.length; i++) {
              quantityControllerList.add(new TextEditingController());
            }

            for (int i = 0; i < selectedProducts.length; i++) {
              final findIndex = _productsList.indexWhere(
                  (element) => element.id == selectedProducts[i].id);
              if (findIndex != -1) {
                quantityControllerList[findIndex].text =
                    "${selectedProducts[i].quantity}";
              }
            }
          } else {
            showProductText = Constants.NO_DATA_FOUND;
          }
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<BuProductModal>> getBuProducts({String? productName}) async {
    setState(() {
      _productsList.clear();
    });
    String body = json.encode({
      "id": buId,
      "filter": {"name": productName, 'is_consumable': true}
    });

    var response = await _productService
        .getProductByBuId_v2(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<BuProductModal> products = [];

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      var data = resObj['results'];
      for (var i in data) {
        products.add(BuProductModal.fromJson(i));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return products;
  }

  getLoadLanguage() async {
    _mapData = [
      {'name': Language().getString(Constants.REQUESTED_ID, selectedLang)},
      {'name': Language().getString(Constants.REQUESTED_BY, selectedLang)},
      {'name': Language().getString(Constants.REQUEST_DATE, selectedLang)},
      {'name': Language().getString(Constants.PURPOSE, selectedLang)},
      {'name': Language().getString(Constants.STATUS_STRING, selectedLang)},
      {'name': Language().getString(Constants.DEPARTMENT, selectedLang)},
      {'name': Language().getString(Constants.BATCH_NO, selectedLang)},
    ];
  }

  Widget buildSearchFilterView() {
    return Container(
      height: 50.0,
      child: Card(
        // elevation: 5,
        shape: new RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
            side: new BorderSide(
                color: theme.colorScheme.primary, strokeAlign: 0.02)),
        child: Row(
          children: [
            Expanded(
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: TextFormField(
                  style: TextStyle(fontWeight: StyleView.fontSemiBold),
                  controller: _searchController,
                  decoration: InputDecoration(
                      contentPadding: EdgeInsets.only(bottom: 10),
                      border: InputBorder.none,
                      hintText: Language().getString(
                          Constants.SEARCH_BY_REQUESTER_NAME, selectedLang),
                      hintStyle: TextStyle(
                          fontSize: 13.0, fontWeight: StyleView.fontSemiBold)),
                  onChanged: onChangeText,
                ),
              ),
            ),
            (_searchController.text.isNotEmpty)
                ? Container(
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                          topRight: Radius.circular(5.0),
                          bottomRight: Radius.circular(5.0),
                        )),
                    child: IconButton(
                        icon: Icon(
                          Icons.close,
                          color: Colors.red,
                        ),
                        onPressed: () {
                          _searchController.clear();
                          onChangeText(_searchController.text);
                        }),
                  )
                : Container()
          ],
        ),
      ),
    );
  }

  onChangeText(String text) {
    if (text.isEmpty) {
      setState(() {
        showLoaderText = Constants.LOADING;
        isSearchForParams = false;
      });
      loadFormListData();
    } else {
      setState(() {
        showLoaderText = Constants.LOADING;
        isSearchForParams = true;
      });

      loadFormListData(name: text);
    }
  }

  showPurposeTextField() {
    return showDialog(
        context: context,
        barrierColor: Colors.black54,
        barrierDismissible: false,
        builder: (context) =>
            StatefulBuilder(builder: (context, StateSetter setState) {
              return Container(
                margin: EdgeInsets.symmetric(vertical: 20.0, horizontal: 20.0),
                child: AppBackgroundView(
                    body: Scaffold(
                        bottomNavigationBar: Container(
                            margin: EdgeInsets.symmetric(horizontal: 10.0),
                            padding: EdgeInsets.symmetric(vertical: 10),
                            child: CommonButtonsView(
                              context: context,
                              b1Text: Language().getString(
                                  Constants.STR_CANCEL, selectedLang),
                              b2Text: Language()
                                  .getString(Constants.CONFIRM, selectedLang),
                              onb1Action: () {
                                Navigator.of(context).pop();
                              },
                              onb2Action: () async {
                                if (await NetworkStatus.getInternetStatus()) {
                                  Navigator.of(context).pop();
                                  Navigator.of(context).pop();
                                  this.createRequestForm();
                                } else {
                                  AppUtills.showSnackBar(
                                      _scaffoldkey,
                                      Language().getString(
                                          Constants.NO_INTERNET, selectedLang),
                                      snackBarBgColor: Colors.black,
                                      messageColor: Colors.white,
                                      buttonColor: Colors.white);
                                }
                              },
                            )),
                        backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                        body: Container(
                            margin: EdgeInsets.symmetric(
                                vertical: 10.0, horizontal: 10.0),
                            child: Column(
                              children: [
                                Container(
                                  margin: EdgeInsets.symmetric(vertical: 5.0),
                                  child: Text(
                                    Language().getString(
                                        "Purpose Details", selectedLang),
                                    style: TextStyle(
                                        color: theme.colorScheme.primary,
                                        fontSize: 15.0,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.symmetric(vertical: 10.0),
                                  child: TextFormField(
                                      controller: _purposeController,
                                      style: TextStyle(
                                          fontFamily: StyleView.FONT_TITLE),
                                      decoration: StyleView.getInputDecoration(
                                          helper: Language().getString(
                                              Constants.PURPOSE, selectedLang)),
                                      maxLines: 3),
                                ),
                                // Container(
                                //   margin: EdgeInsets.symmetric(vertical: 10.0),
                                //   child: TextFormField(
                                //     controller: _issueBatchNumberController,
                                //     style: TextStyle(
                                //         fontFamily: StyleView.FONT_TITLE),
                                //     decoration: StyleView.getInputDecoration(
                                //         helper: Language().getString(
                                //             Constants.BATCH_NO, selectedLang)),
                                //   ),
                                // ),
                                this.buildDepartmentDropdown(setState)
                              ],
                            )))),
              );
            }));
  }

  createRequestForm() async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = Constants.CREATING;
    });
    List<Map<String, dynamic>?> finalProducts = [];
    var productsObj;
    for (int i = 0; i < selectedProducts.length; i++) {
      //selectedList.length; i++) {
      if (selectedProducts[i].counter != 0) {
        //selectedList[i].counter != 0) {

        String unit = Constants.UNIT_PRICE[0];
        for (var j = 0; j < Constants.UNIT_PRICE.length; j++) {
          if (selectedProducts[i].batchPriceList!.isNotEmpty &&
              selectedProducts[i].batchPriceList![0].quantityIn ==
                  Constants.UNIT_PRICE[j]) {
            unit = Constants.UNIT_PRICE[j];
          }
        }

        productsObj = {
          "id": selectedProducts[i].id,
          "quantity": selectedProducts[i].quantity,
          "quantity_in": unit,
          "product_name": selectedProducts[i].name
        };
      }

      finalProducts.add(productsObj);
    }

    Map data = {
      "bu": buId,
      "products": finalProducts,
      "issued_purpose": _purposeController.text,
      "issued_to": loginUserId,
      "requested_by": {"user_id": loginUserId, "user_name": userName},
      "issue_batch_number": "", //_issueBatchNumberController.text,
      "department": _departmentDropdownValue!.name,
      "is_consumable": true
    };

    String body = json.encode(data);

    var response = await _productService
        .rawRequestForm(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      setState(() {
        _productsList.clear();
        batchPricingDropdownList.clear();
        _enterProductCount.clear();
        productNameController.clear();
        quantityController.clear();
        _selectedProductData = null;
        showProductText = "";
        _purposeController.clear();
        issuedToDropdownValue = null;
        selectedList.clear();
        _issueBatchNumberController.clear();
        _departmentDropdownValue = null;
      });
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
      if (action == DialogAction.yes) {
        this.loadFormListData(fromDate: startDate, toDate: endDate);
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  loadFormListData(
      {String fromDate = "",
      String toDate = "",
      String name = "",
      String status = ""}) async {
    if (await NetworkStatus.getInternetStatus()) {
      if (!isSearchForParams) {
        setState(() {
          isLoadingProgress = true;
        });
      }
      getRawRequestFormList(status: status, name: name).then((value) {
        formList.clear();
        if (value.length > 0) {
          // setState(() {
          formList.addAll(value);
          // });
        } else {
          showLoaderText = Constants.NO_DATAFOUND_STRING;
        }
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<RawRequestFormDAO>> getRawRequestFormList(
      {String fromDate = "",
      String toDate = "",
      String status = "",
      String name = ""}) async {
    String body = json.encode({
      "bu": buId,
      "filters": {
        "DateFrom": fromDateController.text,
        "DateTo": toDateController.text,
        "status": status,
        "name": name,
        "is_consumable": true
      }
    });

    var response = await _productService
        .getRawRequestFormList(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    List<RawRequestFormDAO> _list = [];

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var reqData = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(reqData)) {
        var arrayData = reqData['results'];

        for (var obj in arrayData) {
          _list.add(RawRequestFormDAO.fromJson(obj));
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return _list;
  }

  Widget showRequestFormList(RawRequestFormDAO modelData) {
    return InkWell(
      onTap: () {
        Navigator.push(
            context,
            PageTransition(
                context: context,
                page: EditConsumableRequestPage(
                  isFromCreateRequestForm: true,
                  recordId: modelData.id,
                  productList: modelData.productList,
                  formStatus: requestFormStatus(modelData.status),
                  date: AppUtills.getDateFormate(
                      modelData.createdDate.toString()),
                  requestedBy: modelData.requestedBy != null
                      ? modelData.requestedBy!.userName
                      : "",
                  userId: modelData.issuedTo != null
                      ? modelData.issuedTo!.userId
                      : "",
                  purpose: modelData.purpose,
                  requestNumber: modelData.requestNumber,
                  department: modelData.department,
                  batchNumber: modelData.batchNumber,
                ))).then((value) => loadFormListData());
      },
      child: RawRequestFormCardView(
        modelData: modelData,
        mapData: _mapData,
        canShowBatchNumber: false,
      ),
    );
  }

  String requestFormStatus(num? statusCode) {
    if (statusCode == 1) {
      return "accepted";
    } else if (statusCode == 2) {
      return "rejected";
    } else {
      return "pending";
    }
  }

  showProductsView() {
    int requestCounter = 0;
    return showDialog(
        context: context,
        barrierColor: Colors.black54,
        barrierDismissible: false,
        builder: (context) => StatefulBuilder(
                builder: (BuildContext context, StateSetter setState) {
              if (requestCounter++ == 0) {
                loadProductData("", setState);
              }
              return Container(
                margin: EdgeInsets.symmetric(vertical: 20.0, horizontal: 20.0),
                child: AppBackgroundView(
                  body: Scaffold(
                    bottomNavigationBar: this.bottomView(),
                    backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                    body: Container(
                      padding: EdgeInsets.all(16),
                      child: Column(
                        children: [
                          Container(
                              padding: EdgeInsets.only(bottom: 20),
                              child: buildSearchBarView(setState)),
                          (_productsList.length > 0)
                              ? Expanded(
                                  child: Column(
                                    children: [
                                      Expanded(
                                        child: SingleChildScrollView(
                                          controller: _scrollController,
                                          scrollDirection: Axis.vertical,
                                          child: SingleChildScrollView(
                                            scrollDirection: Axis.horizontal,
                                            child: Table(
                                              defaultVerticalAlignment:
                                                  TableCellVerticalAlignment
                                                      .middle,
                                              border: TableBorder.all(
                                                  color: Colors.black,
                                                  borderRadius:
                                                      BorderRadius.circular(5)),
                                              defaultColumnWidth:
                                                  FixedColumnWidth(150),
                                              children: [
                                                TableRow(children: [
                                                  renderTableHeaders(Language()
                                                      .getString(
                                                          Constants
                                                              .PRODUCT_NAME,
                                                          selectedLang)),
                                                  renderTableHeaders(Language()
                                                      .getString(
                                                          Constants
                                                              .AVAILABLE_QUANTITY,
                                                          selectedLang)),
                                                  renderTableHeaders(Language()
                                                      .getString(
                                                          "Request Quantity",
                                                          selectedLang)),
                                                ]),
                                                for (int i = 0;
                                                    i < _productsList.length;
                                                    i++)
                                                  renderTableRowText(
                                                      i, setState)
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                )
                              : Expanded(
                                  child: Center(
                                    child: Text(
                                      showLoaderText,
                                      style: TextStyle(
                                          color: theme.colorScheme.primary,
                                          fontSize: 15,
                                          fontWeight: StyleView.fontMedium),
                                    ),
                                  ),
                                ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            }));
  }

  Widget renderTableHeaders(String? headerText) {
    return Container(
      alignment: Alignment.center,
      padding: EdgeInsets.all(8.0),
      child: Text(
        Language().getString(headerText, selectedLang),
        textAlign: TextAlign.center,
        style: TextStyle(
            color: Colors.black,
            fontWeight: StyleView.fontMedium,
            fontSize: 15.0),
      ),
    );
  }

  Widget renderTableData(String value) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          child: Text("$value",
              style: TextStyle(
                  fontSize: 13,
                  color: Colors.black,
                  fontWeight: StyleView.fontRegular)),
        ),
      ),
    );
  }

  onUpdateTextFormPosition(int index, String value) {
    quantityControllerList[index] = TextEditingController(text: value);
    quantityControllerList[index].selection = TextSelection.fromPosition(
        TextPosition(offset: quantityControllerList[index].text.length));
  }

  onIncrease(int index, StateSetter setState) {
    int findIndex = selectedProducts
        .indexWhere((element) => element.id == _productsList[index].id);
    if (findIndex != -1) {
      num? count = selectedProducts[findIndex].quantity;
      count = count! + 1;
      setState(() {
        quantityControllerList[index].text = "$count";
        selectedProducts[findIndex].quantity = count;
        onUpdateTextFormPosition(index, "$count");
      });
      return;
    }
    num? count = 0;
    if (quantityControllerList[index].text.isNotEmpty) {
      count = int.parse(quantityControllerList[index].text);
    }
    count = count + 1;
    setState(() {
      quantityControllerList[index].text = "$count";
      selectedProducts.add(ModelProduct(
          batchPriceList: _productsList[index].batchPriceList,
          id: _productsList[index].id,
          name: _productsList[index].name,
          counter: _productsList[index].quantity!.toInt(),
          counterNew: _productsList[index].quantity,
          quantity: count));
    });
  }

  onDecrease(int index, StateSetter setState) {
    num count = 0;
    if (quantityControllerList[index].text.isEmpty) {
      return;
    }
    count = int.parse(quantityControllerList[index].text);
    count = count - 1;
    if (count == 0) {
      int findIndex = selectedProducts
          .indexWhere((element) => element.id == _productsList[index].id);
      if (findIndex != -1) {
        setState(() {
          selectedProducts.removeAt(findIndex);
          quantityControllerList[index].clear();
        });
      }
    } else {
      int findIndex = selectedProducts
          .indexWhere((element) => element.id == _productsList[index].id);
      if (findIndex != -1) {
        setState(() {
          selectedProducts[findIndex].quantity = count;
          quantityControllerList[index].text = "$count";
          onUpdateTextFormPosition(index, "$count");
        });
      }
    }
  }

  Widget dynamicTextFormField(int index, StateSetter setState) {
    return Container(
      child: Row(
        children: [
          IconButton(
              padding: EdgeInsets.zero,
              onPressed: () => onDecrease(index, setState),
              icon: Icon(Icons.remove, color: Colors.black)),
          Container(
            width: 50.0,
            height: 25.0,
            decoration: AppUtills.boxDecoration(),
            child: TextFormField(
              controller: quantityControllerList[index],
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 14, fontWeight: StyleView.fontRegular),
              keyboardType: TextInputType.numberWithOptions(signed: true),
              textInputAction: TextInputAction.done,
              decoration: InputDecoration(
                  hintText: "0",
                  contentPadding:
                      EdgeInsets.only(bottom: Constants.CONTENT_PADDING_18_13),
                  hintStyle: TextStyle(
                      fontSize: 14, fontWeight: StyleView.fontRegular),
                  border: InputBorder.none),
              inputFormatters: [
                new LengthLimitingTextInputFormatter(5),
                CommonMethods.inputTextFormatter(isNumber: true)
              ],
              onChanged: (value) {
                if (value.isEmpty) {
                  int findIndex = selectedProducts.indexWhere(
                      (element) => element.id == _productsList[index].id);
                  if (findIndex != -1) {
                    selectedProducts.removeAt(findIndex);
                    quantityControllerList[index].clear();
                  }
                } else {
                  if (value != '0') {
                    int findIndex = selectedProducts.indexWhere(
                        (element) => element.id == _productsList[index].id);
                    if (findIndex != -1) {
                      selectedProducts[findIndex].quantity = int.parse(value);
                      onUpdateTextFormPosition(index, value);
                    } else {
                      selectedProducts.add(ModelProduct(
                          batchPriceList: _productsList[index].batchPriceList,
                          quantity: int.parse(value),
                          id: _productsList[index].id,
                          counter: _productsList[index].quantity!.toInt(),
                          counterNew: _productsList[index].quantity,
                          name: _productsList[index].name));
                      onUpdateTextFormPosition(index, value);
                    }
                  }
                }
              },
            ),
          ),
          IconButton(
              padding: EdgeInsets.zero,
              onPressed: () => onIncrease(index, setState),
              icon: Icon(Icons.add, color: Colors.black))
        ],
      ),
    );
  }

  TableRow renderTableRowText(int index, StateSetter setState) {
    num availableQuantity = 0;

    for (var i = 0; i < _productsList[index].batchPriceList!.length; i++) {
      availableQuantity =
          availableQuantity + _productsList[index].batchPriceList![i].quantity!;
    }
    return TableRow(
      children: [
        renderTableData(_productsList[index].name!),
        renderTableData('$availableQuantity'),
        // renderTableData('0'),
        dynamicTextFormField(index, setState)
      ],
    );
  }

  Widget buildSearchBarView(StateSetter setState) {
    return Container(
      height: 50.0,
      child: Padding(
        padding: const EdgeInsets.only(left: 10),
        child: Card(
          elevation: 2.5,
          shadowColor: theme.colorScheme.primary,
          shape: new RoundedRectangleBorder(
              borderRadius: new BorderRadius.circular(15),
              side: new BorderSide(
                  color: theme.colorScheme.primary, strokeAlign: 0.01)),
          child: Row(
            children: <Widget>[
              Expanded(
                child: Container(
                  padding: EdgeInsets.only(left: 15),
                  child: TextFormField(
                    controller: _searchController,
                    onChanged: (text) {
                      onSearchTextChanged(text, setState);
                    },
                    style: TextStyle(fontWeight: StyleView.fontSemiBold),
                    decoration: InputDecoration(
                        contentPadding: EdgeInsets.only(bottom: 10),
                        border: InputBorder.none,
                        hintText: Language()
                            .getString(Constants.SEARCH_BY_NAME, selectedLang),
                        hintStyle: TextStyle(
                            fontSize: 13.0,
                            fontWeight: StyleView.fontSemiBold)),
                  ),
                ),
              ),
              (_searchController.text.length > 0)
                  ? Container(
                      color: Colors.white,
                      child: IconButton(
                          icon: Icon(
                            Icons.close,
                            color: Colors.red,
                            size: 20.0,
                          ),
                          onPressed: () {
                            _searchController.clear();
                            CommonMethods.hideKeyboard(context);
                            onSearchTextChanged(
                                _searchController.text, setState);
                          }),
                    )
                  : Container(),
            ],
          ),
        ),
      ),
    );
  }

  String? selectedFilter;

  onSearchTextChanged(String text, StateSetter setState) async {
    if (text.isEmpty) {
      isSearchForParams = false;
      _productsList.clear();
      loadProductData("", setState);
    } else {
      setState(() {
        isSearchForParams = true;
        _productsList.clear();
        showLoaderText = Constants.LOADING;
      });
      loadProductData(text, setState);
    }
  }

  _showProductsView() {
    return showDialog(
        context: context,
        barrierColor: Colors.black54,
        barrierDismissible: false,
        builder: (context) => StatefulBuilder(
                builder: (BuildContext context, StateSetter setState) {
              return Container(
                margin: EdgeInsets.symmetric(vertical: 20.0, horizontal: 20.0),
                child: AppBackgroundView(
                    body: Scaffold(
                        bottomNavigationBar: this.bottomView(),
                        backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                        body: Container(
                            margin: EdgeInsets.symmetric(
                                vertical: 10.0, horizontal: 10.0),
                            child: Column(
                              children: [
                                Container(
                                    margin: EdgeInsets.symmetric(vertical: 5.0),
                                    child: Center(
                                        child: Text(
                                      Language().getString(
                                          Constants.NEW_REQUEST_FORM,
                                          selectedLang),
                                      style: TextStyle(
                                          color: theme.colorScheme.primary,
                                          fontSize: 15.0,
                                          fontWeight: StyleView.fontMedium),
                                    ))),
                                this.showProductSearchView(setState),
                                (_productsList.length > 0 && isShowProductName)
                                    ? this.showProductNames(setState)
                                    : Container(
                                        margin:
                                            EdgeInsets.symmetric(vertical: 5.0),
                                        child: (showProductText ==
                                                    Constants.NO_DATA_FOUND ||
                                                showProductText == "")
                                            ? Text(Language().getString(
                                                showProductText, selectedLang))
                                            : Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: [
                                                  Text(Language().getString(
                                                      showProductText,
                                                      selectedLang)),
                                                  Container(
                                                    height: 10.0,
                                                    width: 10.0,
                                                    margin:
                                                        EdgeInsets.symmetric(
                                                            horizontal: 5.0),
                                                    child:
                                                        CircularProgressIndicator(
                                                      strokeWidth: 2.0,
                                                    ),
                                                  )
                                                ],
                                              ),
                                      ),
                                (selectedList.length > 0)
                                    ? this.showSelectedProductsView(setState)
                                    : Container(),
                              ],
                            )))),
              );
            }));
  }

  Widget showSelectedProductsView(StateSetter setState) {
    return Expanded(
        child: Container(
      margin: EdgeInsets.only(top: 5.0),
      decoration: AppUtills.boxDecoration(),
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.all(5.0),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    Language().getString(Constants.PRODUCT_NAME, selectedLang),
                    style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                        fontWeight: FontWeight.bold),
                  ),
                ),
                Expanded(
                  child: Text(
                    Language().getString(Constants.QUANTITY, selectedLang),
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
          ),
          Divider(
            color: Color(Constants.APP_COLOR),
          ),
          Expanded(
            child: ListView.separated(
                shrinkWrap: true,
                separatorBuilder: (context, index) => new Divider(
                      color: Colors.transparent,
                      height: 0.0,
                    ),
                itemCount: selectedList.length,
                itemBuilder: (context, index) {
                  _enterProductCount[index] = TextEditingController(
                      text: selectedList[index].counter.toString());
                  _enterProductCount[index].selection =
                      TextSelection.fromPosition(TextPosition(
                          offset: _enterProductCount[index].text.length));
                  return Card(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        ProductsCardView(
                          onRemoveProductQuantit: () {
                            removeProductQuantity(index, setState);
                          },
                          onAddProductQuantity: () {
                            addProductQuantity(index, setState);
                          },
                          desingQuntityField: Container(
                            width: 50.0,
                            height: 30.0,
                            alignment: Alignment.bottomCenter,
                            decoration: AppUtills.boxDecoration(),
                            child:
                                this.designQuantityInputField(index, setState),
                          ),
                          productName: selectedList[index].name,
                          removeProduct: () async {
                            final action = await Dialogs.yesCancelDialog(
                                context,
                                Language()
                                    .getString(Constants.WARNING, selectedLang),
                                Language().getString(
                                    Constants.WARNING_TEXT, selectedLang),
                                Language().getString(
                                    Constants.OKAY_STR, selectedLang),
                                Language().getString(
                                    Constants.STR_CANCEL, selectedLang),
                                true);

                            if (action == DialogAction.yes) {
                              setState(() {
                                selectedList.removeAt(index);
                                batchPricingDropdownList.removeAt(index);
                                quantityInDropdownValue.removeAt(index);
                              });
                            }
                          },
                          productTotalPrice: 0,
                          isFromRawProductIssuePage: true,
                        ),
                        this.buildQuantityInDropdown(index, setState)
                      ],
                    ),
                  );
                }),
          )
        ],
      ),
    ));
  }

  designQuantityInputField(int index, StateSetter setState) {
    return Container(
      height: 60.0,
      width: 60.0,
      child: TextFormField(
        enableInteractiveSelection: false,
        textAlign: TextAlign.center,
        controller: _enterProductCount[index],
        decoration: InputDecoration(
          contentPadding:
              EdgeInsets.only(bottom: Constants.CONTENT_PADDING_18_15),
          hintText: "",
          border: InputBorder.none,
        ),
        keyboardType: TextInputType.number,
        style: TextStyle(fontSize: 12.0),
        inputFormatters: [
          new LengthLimitingTextInputFormatter(5),
          FilteringTextInputFormatter.digitsOnly
        ],
        onFieldSubmitted: (value) {
          if (value == "0" || value.isEmpty) {
            selectedList[index].counter = 1;
          }
        },
        onChanged: (value) {
          setState(() {
            if (selectedList.length > 0) {
              if (value.isEmpty) {
                selectedList[index].counter = 0;
              } else {
                selectedList[index].counter = int.parse(value);
              }
            }
          });
        },
      ),
    );
  }

  Widget showProductNames(StateSetter setState) {
    return Container(
        height: 100.0,
        decoration: BoxDecoration(
          color: Colors.grey[400],
          borderRadius: BorderRadius.circular(5.0),
        ),
        child: ListView.builder(
          itemBuilder: (context, index) {
            return InkWell(
              onTap: () {
                CommonMethods.hideKeyboard(context);
                setState(() {
                  quantityController.text = "1";
                  _productsList[index].counter =
                      int.parse(quantityController.text);
                  productNameController.text = _productsList[index].name!;
                  isShowProductName = false;
                  _selectedProductData = _productsList[index];
                });
              },
              child: Card(
                color: Colors.grey[100],
                elevation: 2.5,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(_productsList[index].name!,
                          style: TextStyle(color: Colors.black)),
                      Icon(Icons.arrow_forward, color: Colors.blue, size: 20.0),
                    ],
                  ),
                ),
              ),
            );
          },
          itemCount: _productsList.length,
          shrinkWrap: true,
        ));
  }

  Widget bottomView() {
    return Container(
        margin: EdgeInsets.symmetric(horizontal: 10.0),
        padding: EdgeInsets.symmetric(vertical: 10),
        child: CommonButtonsView(
          context: context,
          b1Text: Language().getString(Constants.STR_CANCEL, selectedLang),
          b2Text: Language().getString(Constants.CONTINUE, selectedLang),
          onb1Action: () {
            setState(() {
              selectedList.clear();
              selectedProducts.clear();
              // quantityControllerList.clear();
              _issueBatchNumberController.clear();
            });
            Navigator.of(context).pop();
          },
          onb2Action: () async {
            if (selectedProducts.length == 0) {
              //selectedList.length == 0) {
              Dialogs.yesCancelDialog(
                  context,
                  Language().getString(Constants.ERROR, selectedLang),
                  Language().getString(Constants.SELECT_PRODUCTS, selectedLang),
                  Language().getString(Constants.OKAY_STR, selectedLang),
                  "",
                  false);
            } else {
              this.showPurposeTextField();
            }
          },
        ));
  }

  Widget showProductSearchView(StateSetter setState) {
    return Container(
      decoration: AppUtills.boxDecoration(),
      margin: EdgeInsets.only(top: 5.0),
      height: 40.0,
      alignment: Alignment.centerLeft,
      child: Container(
        // color: Colors.white,
        alignment: Alignment.centerLeft,
        child: Row(
          children: [
            Expanded(
              flex: 2,
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(5.0),
                      bottomLeft: Radius.circular(5.0)),
                  color: Color(Constants.APP_BACKGROUND_COLOR),
                ),
                margin: EdgeInsets.only(right: 1.0),
                child: Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: TextField(
                    controller: productNameController,
                    keyboardType: TextInputType.text,
                    // focusNode: FocusNode(),
                    decoration: InputDecoration(
                        contentPadding:
                            EdgeInsets.only(bottom: (kIsWeb || Platform.isWindows) ? 15 : 0),
                        hintText: Language().getString(
                            Constants.SEARCH_BY_PRODUCT, selectedLang),
                        hintStyle: TextStyle(fontSize: 12.0),
                        border: InputBorder.none),
                    onChanged: (_text) {
                      if (_text.isNotEmpty) {
                        setState(() {
                          showProductText = Constants.LOADING;
                        });

                        this.loadProductData(_text, setState);
                      } else {
                        setState(() {
                          showProductText = "";
                          isShowProductName = false;
                          _productsList.clear();
                        });
                      }
                    },
                    style: TextStyle(
                        fontSize: 12.0, decoration: TextDecoration.none),
                  ),
                ),
              ),
            ),
            Expanded(
              child: Container(
                color: Color(Constants.APP_BACKGROUND_COLOR),
                margin: EdgeInsets.only(right: 1.0),
                child: Padding(
                  padding: const EdgeInsets.all(2.0),
                  child: TextFormField(
                    controller: quantityController,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      contentPadding:
                          EdgeInsets.only(bottom: (kIsWeb || Platform.isWindows) ? 15 : 0),
                      border: InputBorder.none,
                      hintText: Language()
                          .getString(Constants.QUANTITY, selectedLang),
                      hintStyle: TextStyle(fontSize: 12.0),
                    ),
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 12.0),
                  ),
                ),
              ),
            ),
            SizedBox(
              width: 30.0,
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                      topRight: Radius.circular(5.0),
                      bottomRight: Radius.circular(5.0)),
                  color: Color(Constants.APP_BACKGROUND_COLOR),
                ),
                child: IconButton(
                    padding: EdgeInsets.all(0.0),
                    icon: Icon(
                      Icons.add,
                    ),
                    onPressed: () {
                      if (_selectedProductData != null) {
                        if (_selectedProductData!.counter == 0) {
                          Dialogs.yesCancelDialog(
                              context,
                              Language()
                                  .getString(Constants.ERROR, selectedLang),
                              Language().getString(
                                  Constants.ENTER_VALID_QUANTITY, selectedLang),
                              Language()
                                  .getString(Constants.OKAY_STR, selectedLang),
                              "",
                              false);
                        } else {
                          this.addToInvoiceProductsArray(setState);
                        }
                      }

                      return CommonMethods.hideKeyboard(context);
                    }),
              ),
            )
          ],
        ),
      ),
    );
  }

  addToInvoiceProductsArray(StateSetter setState) {
    setState(() {
      bool isExist = false;
      int index = -1;
      for (int i = 0; i < selectedList.length; i++) {
        if (_selectedProductData!.id == selectedList[i].id) {
          isExist = true;
          index = i;
        }
      }

      if (isExist) {
        selectedList[index].counter =
            selectedList[index].counter! + int.parse(quantityController.text);

        _enterProductCount[index] =
            TextEditingController(text: selectedList[index].counter.toString());
        _enterProductCount[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _enterProductCount[index].text.length));
      } else {
        selectedList.add(ModelProduct(
            name: _selectedProductData!.name,
            id: _selectedProductData!.id,
            price: _selectedProductData!.price,
            counter: int.parse(quantityController.text),
            images: _selectedProductData!.images,
            isButton: _selectedProductData!.isButton,
            isItemSelected: _selectedProductData!.isItemSelected,
            batchPriceList: _selectedProductData!.batchPriceList,
            unitPrice: _selectedProductData!.unitPrice,
            quantity: _selectedProductData!.quantity));
        _enterProductCount.add(new TextEditingController());
        batchPricingDropdownList.add(null);
        quantityInDropdownValue.add(null);
      }

      _selectedProductData = null;
      productNameController.clear();
      quantityController.clear();
    });
  }

  buildQuantityInDropdown(int index, StateSetter setState) {
    print("Product: ${selectedList[index].toString()}");
    if (quantityInDropdownValue[index] == null) {
      String unit = Constants.UNIT_PRICE[0];
      for (var i = 0; i < Constants.UNIT_PRICE.length; i++) {
        if (selectedList[index].batchPriceList!.isNotEmpty &&
            selectedList[index].batchPriceList![0].quantityIn ==
                Constants.UNIT_PRICE[i]) {
          unit = Constants.UNIT_PRICE[i];
        }
      }
      quantityInDropdownValue[index] = unit; //Constants.UNIT_PRICE[0];
    }
    return Container(
        color: Colors.white,
        padding: EdgeInsets.only(left: 5),
        child: DropdownButton<String>(
            onTap: () {
              FocusScope.of(context).unfocus();
            },
            value: quantityInDropdownValue[index],
            hint: new Text(
              Language().getString(Constants.SELECT, selectedLang),
            ),
            underline: SizedBox(),
            onChanged: (String? data) {
              setState(() {
                quantityInDropdownValue[index] = data;
              });
            },
            items: Constants.UNIT_PRICE.map((String model) {
              return new DropdownMenuItem<String>(
                child: new Text(model),
                value: model,
              );
            }).toList()));
  }

  Future<List<DepartmentDAO>> getDepartments() async {
    http.Response response = await _service.get_department();
    List<DepartmentDAO> list = [];

    if (response.statusCode == 200) {
      var data = json.decode(response.body);
      for (var object in data["data"]) {
        list.add(DepartmentDAO.fromJson(object));
      }
    }
    return list;
  }

  buildDepartmentDropdown(StateSetter setState) {
    return Container(
        padding: EdgeInsets.all(1),
        margin: EdgeInsets.symmetric(vertical: 5.0),
        decoration: AppUtills.boxDecoration(),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 5),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                            Language().getString(
                                Constants.CONTACT_DEPT, selectedLang),
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: StyleView.FONT_TITLE))),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5, right: 5),
                  child: DropdownButton<DepartmentDAO>(
                      value: _departmentDropdownValue,
                      isExpanded: true,
                      hint: Text(Language().getString(
                          Constants.SELECT_DEPARTMENT, selectedLang)),
                      underline: SizedBox(),
                      onChanged: (DepartmentDAO? data) {
                        setState(() {
                          _departmentDropdownValue = data;
                        });
                      },
                      onTap: () {
                        CommonMethods.hideKeyboard(context);
                      },
                      items: _departmentList.map((DepartmentDAO model) {
                        return new DropdownMenuItem<DepartmentDAO>(
                          child: new Text(model.name!),
                          value: model,
                        );
                      }).toList())),
            )
          ],
        ));
  }

  Future<UserModel?> getUserDataById() async {
    String body = json.encode({"id": loginUserId});
    // http.Response
    var response = await _userService
        .getUserById_grpc(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    UserModel? _users;

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(resObj)) {
        _users = UserModel.fromJson(resObj[0]);
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return _users;
  }
}
