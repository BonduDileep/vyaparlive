import 'dart:async';
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Product/price_view/PriceDetailsExpandPage.dart';
import 'package:vyaparlive/Product/attribute_view/AttributeExpandedPage.dart';
import 'package:vyaparlive/Product/inventory_view/InventoryExpandedPage.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/model/CitiesDAO.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/BusinessUnitModel.dart';
import 'package:vyaparlive/model/ProductIssueDetailsModel.dart';
import 'package:vyaparlive/model/CountryDAO.dart';
import 'package:vyaparlive/model/CurrecyNameDAO.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/InventoryManagmentModel.dart';
import 'package:vyaparlive/model/PriceModel.dart';
import 'package:vyaparlive/model/ProductCategoryDAO.dart';
import 'package:vyaparlive/model/ProductConsumptionDAO.dart';
import 'package:vyaparlive/model/ProductSegmentDAO.dart';
import 'package:vyaparlive/model/ProductSubCategoryDAO.dart';
import 'package:vyaparlive/model/StatesDAO.dart';
import 'package:vyaparlive/model/ProductAttributeModel.dart';
import 'package:vyaparlive/model/ProductConditionModel.dart';
import 'package:vyaparlive/model/ProductSubType.dart';
import 'package:vyaparlive/model/UserModel.dart';
import 'package:vyaparlive/model/bu_model/LocationsModel.dart';
import 'package:vyaparlive/product_consumption_view/issue_details_card_view/IssueDetailsCardView.dart';
import 'package:vyaparlive/service/Service.dart';
import 'package:vyaparlive/service/consumable_product_grpc.dart';
import 'package:vyaparlive/service/user_services.dart';

class ConsumableProductPage extends StatefulWidget {
  final String? title;
  final String? buId;
  final String? productId;

  ConsumableProductPage({this.title, this.buId, this.productId});

  @override
  _ConsumableProductPageState createState() => _ConsumableProductPageState();
}

class _ConsumableProductPageState extends State<ConsumableProductPage> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? priceUnitDropdownValue;
  String? quantityDropdownValue;
  String? taxDropdownValue;
  String? taxValueDropdownValue;
  String connectionBuName = "";
  String connectionBuId = "";
  bool isCameraReady = false;
  bool showCapturedPhoto = false;
  String? currencySymbol = "";
  var imagePath;
  bool cameraPriviewShow = false;
  EdgeInsetsGeometry dialogTitlePadding =
      EdgeInsets.fromLTRB(17.0, 24.0, 24.0, 5.0);
  bool isSelectCaptureChoice = false;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  DateTime selectedDate = DateTime.now();
  late File imageFile;
  String imageBlob = '';
  String? buId = "";
  late Service _service;
  bool isLoading = false;
  String consumableProductRadioValue = Constants.YES_STRING;
  String strHeight = "";
  String strVolume = "";
  String strWeight = "";
  String strWidth = "";
  int strQuantity = 0;
  String strDepth = "";
  int productPrice = 0;
  String? maxOrderDropdownValue;
  String? minOrderDropdownValue;
  bool isOfferActive = false;
  String? offerRadioValue;
  String? offerChooice;

  List<String> _citiesList = [];
  String? citiesDropDownValue;

  /// Product Details Fiellds

  final _productNameController = TextEditingController();
  final _brandController = new TextEditingController();
  final _descriptionController = new TextEditingController();

  final _batchNumController = new TextEditingController();
  ProductSubType? _productType;
  ProductSubType? _productSubType;
  ProductSegmentDAO? _productSegment;
  ProductCategoryDAO? _productCategory;

  ProductSubCategoryDAO? _productSubCategory;
  CountryDAO? _countryName;
  StatesDAO? _stateName;
  CurrencyNameDAO? currencyNameDropdown;
  List<CurrencyNameDAO> _currencyNameList = [];

  /// Manufacture Fields

  final _modelNumberController = new TextEditingController();
  final _manufactureNameController = new TextEditingController();
  final _buildingNumController = new TextEditingController();
  final _streetNameController = new TextEditingController();
  final _areaController = new TextEditingController();
  final _pinController = new TextEditingController();

  /// Shipping Details

  final _weightController = new TextEditingController();
  final _widthController = new TextEditingController();
  final _heightController = new TextEditingController();
  final _depthController = new TextEditingController();
  final _qntyController = new TextEditingController();

  /// Price Details

  final _priceController = new TextEditingController();
  final _netRateController = new TextEditingController();
  final _mrpController = new TextEditingController();
  List<ProductSubType> productSubTypes = [];

  List<ProductSegmentDAO> productsSegments = [];

  List<ProductCategoryDAO> productCategories = [];
  List<ProductSubCategoryDAO> productSubCategories = [];
  List<ProductSubType> productTypeList = [];

  List<ProductConditionModel> productConditions = [];
  List<CountryDAO> countryList = [];
  List<StatesDAO> stateList = [];
  List<String> _districtList = [];
  String? districtDropdownValue;
  final _attributeKeyController = new TextEditingController();
  final _attributeValueController = new TextEditingController();

  final _locationQuantityController = new TextEditingController();
  final hsnCodeController = TextEditingController();

  List<ProductAttributeModel> attributesList = [];
  List<InventoryManagementModel> inventoryList = [];
  DateTime manifactureDate = DateTime.now();
  DateTime expireDate = DateTime.now();
  DateTime offerStartDate = DateTime.now();
  DateTime offerEndDate = DateTime.now();
  DateTime offerSupplyTime = DateTime.now();
  DateTime releaseDate = DateTime.now();
  DateFormat formatter = DateFormat("yyyy-MM-dd");
  String formatttedOfferStartDate = "";
  String formattedOfferEndDate = "";
  String? formattedManufactureDate = "";
  String formattedOfferSupplyDate = "";
  String? formattedExpireDate = "";
  String formattedReleaseDate = "";

  List<BusinessUnitModel> _buList = [];
  List<Locations> locationsList = [];
  Locations? locationDropdownValue;
  int productTotalQuantity = 0;
  int inventoryQuantity = 0;

  String? heightDropdownValue;
  String? weightDropdownValue;
  String? widthDropdownValue;
  String? volumeDropdownValue;
  String? depthDropdownValue;
  final volumeController = TextEditingController();
  String? offerInPercentage;
  bool isImageUpdated = false;
  bool isLoadingProgress = true;
  String progressMessage = Constants.GETTING_DATA;
  double finalAngle = 0.0;
  List<PriceModel> _priceList = [];
  num batchPricingTotalQuantity = 0;
  PriceModel? inventoryQuantityDropdown;
  String? remainingBatchQuantity = "0";
  num? quantityForUpdate = 0;
  List<ProductIssueDetailsModel> issuedDetailsList = [];
  String? issueDate = "";
  TextEditingController issueToController = TextEditingController();
  TextEditingController purposeController = TextEditingController();
  TextEditingController approvedByController = TextEditingController();
  TextEditingController issuedQuantityController = TextEditingController();
  List<UserModel> _usersList = [];
  UserModel? approvedByDropdownValue;
  UserModel? issuedToDropdownValue;
  late UserService _userService;
  final _talukController = new TextEditingController();
  final _landMarkController = new TextEditingController();
  final _manufactureAddressController = new TextEditingController();
  late ConsumableGrpcService _consumableGrpcService;
  ProductConsumptionDAO? productData;
  PriceModel? issueDetailsQuantityDropdown;
  num remaingIssuedDetailsBatchQuantity = 0;
  num totalIssuedQuantity = 0;
  TextEditingController departmentController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _service = Service();
    _consumableGrpcService = ConsumableGrpcService();
    buId = AppController.instance.getMyBuId;
    if (widget.title == Constants.UPDATE_CONSUMABLE_PRODUCTS) {
      loadProductData();
    } else {
      loadDropdowns();
    }
    _userService = UserService();
  }

  loadProductData() async {
    if (await NetworkStatus.getInternetStatus()) {
      this.getProductDataById().then((value) {
        setState(() {
          productData = value;
          if (productData != null) {
            this.bindingProductData();
          }
        });
        this.loadDropdowns();
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  loadDropdowns() async {
    /// Service call get product segment
    await this.getProductSegments().then((onValue) {
      setState(() {
        productsSegments.addAll(onValue);
      });
    });

    await this.getBuData().then((value) {
      _buList.addAll(value);
      if (_buList.length > 0) {
        /// Getting bu locations
        setState(() {
          locationsList.addAll(_buList[0].locationsList!);
        });
      }
    });

    await this.getCurrencyNames().then((value) {
      _currencyNameList.addAll(value);
    });

    await this.getCountryTypes().then((onValue) {
      countryList.addAll(onValue);
      if (countryList.length > 0) {
        for (int i = 0; i < countryList.length; i++) {
          if (countryList[i].name == "India") {
            setState(() {
              _countryName = countryList[i];
            });
            getStates(_countryName!.name!).then((onValue) {
              setState(() {
                stateList.addAll(onValue);
              });
            });
          }
        }
      }
    });

    loadUsersData("");
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        SafeArea(
          child: Scaffold(
            key: _scaffoldkey,
            backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
            appBar: AppBar(
              leading: (widget.title == Constants.UPDATE_CONSUMABLE_PRODUCTS)
                  ? IconButton(
                      icon: Icon(Icons.arrow_back, color: Colors.white),
                      onPressed: () async {
                        final action = await Dialogs.yesCancelDialog(
                            context,
                            Language().getString(Constants.INFO, selectedLang),
                            Language().getString(
                                Constants.BACK_BUTTION_MESSAGE, selectedLang),
                            Language()
                                .getString(Constants.YES_STRING, selectedLang),
                            Language()
                                .getString(Constants.NO_STRING, selectedLang),
                            true);
                        if (action == DialogAction.yes) {
                          Navigator.pop(context);
                        }
                      })
                  : null,
              centerTitle: true,
              title: Column(children: <Widget>[
                Text(
                  Language().getString(
                    "${widget.title}",
                    selectedLang,
                  ),
                  style: TextStyle(fontSize: 14.0),
                ),
                Text(
                  AppController.instance.getBuName,
                  style: TextStyle(fontSize: 13.0),
                )
              ]),
              backgroundColor: Color(0xFF083e64),
              actions: [
                AppUtills.homeButton(context),
              ],
            ),
            bottomNavigationBar: Container(
              margin: EdgeInsets.symmetric(
                horizontal: 10.0,
              ),
              child: ElevatedButton(
                onPressed: () => {this.submitInputData()},
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(Constants.APP_COLOR),
                  textStyle: TextStyle(color: Colors.white),
                  elevation: 3.0,
                ),
                child: Padding(
                  padding: EdgeInsets.symmetric(vertical: 10),
                  child: Text(
                    Language().getString(widget.title, selectedLang),
                  ),
                ),
              ),
            ),
            body: Container(
              margin: EdgeInsets.symmetric(
                horizontal: 10.0,
                vertical: 5.0,
              ),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Container(
                      margin: EdgeInsets.symmetric(
                        vertical: 5.0,
                      ),
                      child: Text(
                        Language()
                            .getString(Constants.PRODUCTDETAILS, selectedLang),
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_15,
                            fontFamily: StyleView.FONT_TITLE,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.symmetric(
                        vertical: 5.0,
                      ),
                      decoration: AppUtills.boxDecoration(),
                      child: Column(children: <Widget>[
                        buildAddProductImage(Language().getString(
                            Constants.PRODUCT_PHOTO_STRING, selectedLang)),
                        SizedBox(
                          height: 1,
                          child:
                              new Container(color: Color(Constants.GREY_COLOR)),
                        ),
                        buildAddProduct(),
                      ]),
                    ),
                    Container(
                        margin: EdgeInsets.symmetric(
                          vertical: 5.0,
                        ),
                        decoration: AppUtills.boxDecoration(),
                        child: ExpansionTile(
                            initiallyExpanded: true,
                            title: Text(Language().getString(
                                Constants.PRODUCT_BASIC_DETAILS, selectedLang)),
                            children: <Widget>[
                              Column(
                                children: <Widget>[
                                  buildTableContent(Constants.NAME_STRING,
                                      _productNameController, false, true),
                                  SizedBox(
                                    height: 1,
                                    child: new Container(
                                        color: Color(Constants.GREY_COLOR)),
                                  ),
                                  buildTableContent(Constants.BRAND,
                                      _brandController, false, false),
                                  SizedBox(
                                    height: 1,
                                    child: new Container(
                                        color: Color(Constants.GREY_COLOR)),
                                  ),
                                  buildTableContent(Constants.DESCRIPTION_STRING,
                                      _descriptionController, false, false),
                                  SizedBox(
                                    height: 1,
                                    child: new Container(
                                        color: Color(Constants.GREY_COLOR)),
                                  ),
                                  buildDropDownSigment(Constants.PRODUCT_SEGMENT),
                                  SizedBox(
                                    height: 1,
                                    child: new Container(
                                      color: Color(Constants.GREY_COLOR),
                                    ),
                                  ),
                                  buildDropDownCategory(
                                      Constants.PRODUCT_CATEGORY),
                                  SizedBox(
                                    height: 1,
                                    child: new Container(
                                        color: Color(Constants.GREY_COLOR)),
                                  ),
                                  buildDropDownSubCategory(
                                      Constants.PRODUCT_SUB_CATEGORY),
                                  SizedBox(
                                    height: 1,
                                    child: new Container(
                                        color: Color(Constants.GREY_COLOR)),
                                  ),
                                  Container(
                                    child: Row(
                                      children: [
                                        Expanded(
                                          child: Container(
                                              padding: EdgeInsets.only(
                                                left: 10.0,
                                              ),
                                              height: 50,
                                              alignment: Alignment.centerLeft,
                                              color: Color(
                                                  Constants.GREY_COLOR_LIGHT),
                                              child: Text(
                                                Language().getString(
                                                    Constants.CONSUMABLE,
                                                    selectedLang),
                                                style: TextStyle(
                                                  color: Colors.black,
                                                  fontSize: 15.0,
                                                ),
                                              )),
                                        ),
                                        Expanded(
                                          flex: 2,
                                          child: Container(
                                            color: Colors.white,
                                            height: 50,
                                            child:
                                                consumableProductRadioButtonView(),
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                ],
                              )
                            ])),
                    Container(
                      margin: EdgeInsets.symmetric(
                        vertical: 5.0,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          buildTextField(Language()
                              .getString(Constants.FEATURES, selectedLang)),
                          addNewAttribute()
                        ],
                      ),
                    ),
                    Container(
                      child: attributesList.length == 0
                          ? Container(margin: EdgeInsets.symmetric(vertical: 5.0))
                          : onCreateDynamicAttributes(),
                    ),
                    // Container(
          
                    this.showTotalQuantity(),
          
                    this.priceDetailsView(),
                    (_priceList.length > 0)
                        ? createPriceDetailsDynamic()
                        : Container(margin: EdgeInsets.symmetric(vertical: 5.0)),
          
                    Container(
                        margin: EdgeInsets.symmetric(
                          vertical: 5.0,
                        ),
                        decoration: AppUtills.boxDecoration(),
                        child: ExpansionTile(
                          title: Text(Language().getString(
                              Constants.MANUFACTURER_DETAILS, selectedLang)),
                          children: <Widget>[
                            Column(children: <Widget>[
                              buildTableContent(Constants.MOBILE_NUMBER,
                                  _modelNumberController, false, false),
                              SizedBox(
                                height: 1,
                                child: new Container(
                                    color: Color(Constants.GREY_COLOR)),
                              ),
                              buildDateFieldRelease(Constants.RELEASE_DATE),
                              SizedBox(
                                height: 1,
                                child: new Container(
                                    color: Color(Constants.GREY_COLOR)),
                              ),
                              buildTableContent(Constants.NAME_STRING,
                                  _manufactureNameController, false, false),
                              SizedBox(
                                height: 1,
                                child: new Container(
                                    color: Color(Constants.GREY_COLOR)),
                              ),
                              buildTableContent(Constants.PLOT_NO,
                                  _areaController, false, false),
                              SizedBox(
                                height: 1,
                                child: new Container(
                                    color: Color(Constants.GREY_COLOR)),
                              ),
                              buildTableContent(Constants.BULIDING,
                                  _buildingNumController, false, false),
                              SizedBox(
                                height: 1,
                                child: new Container(
                                    color: Color(Constants.GREY_COLOR)),
                              ),
                              buildTableContent(
                                  Constants.BUILDING_STREET_NAME_STRING,
                                  _streetNameController,
                                  false,
                                  false),
                              SizedBox(
                                height: 1,
                                child: new Container(
                                    color: Color(Constants.GREY_COLOR)),
                              ),
                              buildDropDownCountry(Constants.COUNTRY_NAME_STRING),
                              SizedBox(
                                height: 1,
                                child: new Container(
                                    color: Color(Constants.GREY_COLOR)),
                              ),
                              buildDropDownState(Constants.STATE_NAME_STRING),
                              SizedBox(
                                height: 1,
                                child: new Container(
                                    color: Color(Constants.GREY_COLOR)),
                              ),
                              buildDropDownDistrict(Constants.DISTRICT_STRING),
                              SizedBox(
                                height: 1,
                                child: new Container(
                                    color: Color(Constants.GREY_COLOR)),
                              ),
                              // buildTableContent(
                              //     "City", _cityController, false, false),
          
                              buildCityDropdown(Constants.CITY_NAME_STRING),
                              SizedBox(
                                height: 1,
                                child: new Container(
                                    color: Color(Constants.GREY_COLOR)),
                              ),
                              // buildTableContent(
                              //     "Pin", _pinController, false, false),
          
                              buildPincodeView()
                            ])
                          ],
                        )),
                    Container(
                        margin: EdgeInsets.symmetric(
                          vertical: 5.0,
                        ),
                        decoration: AppUtills.boxDecoration(),
                        child: ExpansionTile(
                            title: Text(Language()
                                .getString(Constants.ITEM_DETAILS, selectedLang)),
                            children: <Widget>[
                              Column(children: <Widget>[
                                buildHeightView(Constants.HEIGHT, ""),
                                SizedBox(
                                    height: 1.0,
                                    child: Container(
                                        color: Color(Constants.GREY_COLOR))),
                                buildWidthView(Constants.WIDTH, ""),
                                SizedBox(
                                    height: 1.0,
                                    child: Container(
                                        color: Color(Constants.GREY_COLOR))),
                                buildDepthView(Constants.DEPTH, ""),
                                SizedBox(
                                    height: 1.0,
                                    child: Container(
                                        color: Color(Constants.GREY_COLOR))),
                                buildVolumeView(Constants.VOLUME, ""),
                                SizedBox(
                                    height: 1.0,
                                    child: Container(
                                        color: Color(Constants.GREY_COLOR))),
                                buildWeightView(Constants.WEIGHT, ""),
                              ])
                            ])),
          
                    Container(
                      margin: EdgeInsets.symmetric(
                        vertical: 10.0,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          buildTextField(Language()
                              .getString(Constants.INVENTORY, selectedLang)),
                          addNewInventory()
                        ],
                      ),
                    ),
                    Container(
                      child: (inventoryList.length == 0)
                          ? null
                          : onCreateDynamicInventory(),
                    ),
                    Container(
                      margin: EdgeInsets.symmetric(
                        vertical: 10.0,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          buildTextField(Language()
                              .getString(Constants.ISSUE_DETAILS, selectedLang)),
                          addProductIssueDetails()
                        ],
                      ),
                    ),
                    Container(
                      child: (issuedDetailsList.length == 0)
                          ? null
                          : onCreateDynamicProductIssueList(),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    );
  }

  showTotalQuantity() {
    if (_priceList.length > 0) {
      batchPricingTotalQuantity = 0;
      productTotalQuantity = 0;
      for (int i = 0; i < _priceList.length; i++) {
        setState(() {
          batchPricingTotalQuantity =
              batchPricingTotalQuantity + int.parse(_priceList[i].quantity!);
          productTotalQuantity = batchPricingTotalQuantity as int;
        });
      }

      return Container(
          margin: EdgeInsets.symmetric(vertical: 10.0),
          child: Row(
            children: [
              Container(
                  child: Text(
                Language()
                    .getString(Constants.TOTAL_QUANTITY_STRING, selectedLang),
                style: TextStyle(fontSize: 15.0, fontWeight: FontWeight.bold),
              )),
              Expanded(
                  child: Container(
                child: Text(" : $batchPricingTotalQuantity"),
              ))
            ],
          ));
    } else {
      return Container();
    }
  }

  Future<List<BusinessUnitModel>> getBuData() async {
    _buList.clear();
    locationsList.clear();
    if (!isLoadingProgress) {
      setState(() {
        isLoadingProgress = true;
      });
    }

    http.Response response = await _service
        .get_organization("", AppController.instance.getMyBuId)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<BusinessUnitModel> _list = [];
    setState(() {
      isLoadingProgress = false;
    });
    if (response.statusCode == 200) {
      var object = json.decode(response.body);
      for (var data in object['data']) {
        _list.add(BusinessUnitModel.fromJson(data));
      }
    } else if (response.statusCode == 401) {
      CommonMethods.handleUnauthorizedAccess(context);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          response.body,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    return _list;
  }

  Future<List<CurrencyNameDAO>> getCurrencyNames() async {
    http.Response response = await _service.getCurrencyName();
    List<CurrencyNameDAO> list = [];
    if (response.statusCode == 200) {
      var data = json.decode(response.body);
      for (var objectData in data["data"]) {
        list.add(CurrencyNameDAO.fromJson(objectData));
      }
    } else {}
    return list;
  }

  Future<List<CountryDAO>> getCountryTypes() async {
    http.Response response = await _service.getDropDownType("lookup/country");
    List<CountryDAO> _list = [];

    if (response.statusCode == 200) {
      var responseBody = json.decode(response.body);
      for (var data in responseBody['data']) {
        _list.add(CountryDAO.fromJaon(data));
      }

      if (_list.length > 0 &&
          widget.title == Constants.UPDATE_CONSUMABLE_PRODUCTS &&
          productData != null) {
        for (int i = 0; i < _list.length; i++) {
          if (productData!.manufactureDetails!.country == _list[i].name) {
            setState(() {
              _countryName = _list[i];
            });

            getStates(_countryName!.name!).then((value) {
              setState(() {
                stateList.addAll(value);
              });
            });
          }
        }
      }
    } else {}

    return _list;
  }

  Future<List<CitiesDAO>> getCitiesList(
      String? countryName, String? stateId) async {
    setState(() {
      _citiesList.clear();
      isLoadingProgress = true;
      progressMessage = "Getting Cities..";
    });

    var resposne = await _service.getCities(countryName, stateId);
    List<CitiesDAO> _list = [];
    setState(() {
      isLoadingProgress = false;
    });

    if (resposne.statusCode == 200) {
      var data = json.decode(resposne.body);

      bool isString = false;

      if (data['data'] is String) {
        isString = true;
      }

      if (!isString) {
        for (var object in data['data']) {
          _list.add(CitiesDAO.fromJson(object));
        }
      }
    }

    return _list;
  }

  Future<List<StatesDAO>> getStates(String countryName) async {
    stateList.clear();
    http.Response response = await _service.getStatesByCountry(countryName);
    List<StatesDAO> _list = [];
    if (response.statusCode == 200) {
      var responseBody = json.decode(response.body);
      for (var data in responseBody['data']) {
        for (var statesObject in data["states"])
          _list.add(StatesDAO.fromJson(statesObject));
      }

      if (_list.length > 0 &&
          widget.title == Constants.UPDATE_CONSUMABLE_PRODUCTS &&
          productData != null) {
        if (productData!.manufactureDetails!.state != null) {
          for (int i = 0; i < _list.length; i++) {
            if (productData!.manufactureDetails!.state == _list[i].state) {
              setState(() {
                _districtList.clear();
                _stateName = _list[i];
                _districtList.addAll(_stateName!.cities!);
              });
              if (productData!.manufactureDetails!.district != null) {
                if (_districtList.length > 0) {
                  for (int j = 0; j < _districtList.length; j++) {
                    if (productData!.manufactureDetails!.district ==
                        _districtList[j]) {
                      setState(() {
                        districtDropdownValue = _districtList[j];
                      });
                    }
                  }
                }
              }
            }
          }

          if (_stateName != null) {
            this.getCitiesList(countryName, _stateName!.id).then((value) {
              if (value.length > 0) {
                setState(() {
                  _citiesList.clear();
                  _citiesList.addAll(value[0].cities!);
                });

                if (productData!.manufactureDetails!.city != null) {
                  for (int k = 0; k < _citiesList.length; k++) {
                    if (productData!.manufactureDetails!.city ==
                        _citiesList[k]) {
                      setState(() {
                        citiesDropDownValue = _citiesList[k];
                      });
                    }
                  }
                }
              }
            });
          }
        }
      }
    } else {}

    return _list;
  }

  Future<List<ProductSubType>> getProductTypes() async {
    http.Response response =
        await _service.getDropDownType("lookup/productCategory");
    List<ProductSubType> _list = [];

    if (response.statusCode == 200) {
      var responseBody = json.decode(response.body);
      for (var data in responseBody['data']) {
        _list.add(ProductSubType.fromJson(data));
      }
    } else {}

    return _list;
  }

  Future<List<ProductSubType>> getProductSubTypes() async {
    http.Response response =
        await _service.getDropDownType("lookup/productCategory");
    List<ProductSubType> _list = [];

    if (response.statusCode == 200) {
      var responseBody = json.decode(response.body);
      for (var data in responseBody['data']) {
        _list.add(ProductSubType.fromJson(data));
      }
    } else {}

    return _list;
  }

  Future<List<ProductCategoryDAO>> getProductCategories(int parentCode) async {
    http.Response response = await _service
        .getDropDownType("lookup/productCategory/parent/$parentCode");
    List<ProductCategoryDAO> _list = [];

    setState(() {
      isLoadingProgress = false;
    });
    if (response.statusCode == 200) {
      var responseBody = json.decode(response.body);
      for (var data in responseBody['data']) {
        _list.add(ProductCategoryDAO.fromJson(data));
      }

      if (_list.length > 0 &&
          widget.title == Constants.UPDATE_CONSUMABLE_PRODUCTS &&
          productData != null) {
        for (int i = 0; i < _list.length; i++) {
          if (productData!.productCategory == _list[i].type) {
            setState(() {
              _productCategory = _list[i];
            });
            loadProductSubCategory(_productCategory!.code!);
          }
        }
      }
    }

    return _list;
  }

  Future<List<ProductSubCategoryDAO>> getProductSubCategories(
      int parentCode) async {
    http.Response response = await _service
        .getDropDownType("lookup/productSubCategory/parent/$parentCode");
    List<ProductSubCategoryDAO> _list = [];
    setState(() {
      isLoadingProgress = false;
    });
    if (response.statusCode == 200) {
      var responseBody = json.decode(response.body);
      for (var data in responseBody['data']) {
        _list.add(ProductSubCategoryDAO.fromJson(data));
      }

      if (_list.length > 0 &&
          widget.title == Constants.UPDATE_CONSUMABLE_PRODUCTS &&
          productData != null) {
        for (int i = 0; i < _list.length; i++) {
          if (productData!.productSubCategory == _list[i].type) {
            setState(() {
              _productSubCategory = _list[i];
            });
          }
        }
      }
    }

    return _list;
  }

  Future<List<ProductSegmentDAO>> getProductSegments() async {
    http.Response response =
        await _service.getDropDownType("lookup/productSegment");
    List<ProductSegmentDAO> _list = [];

    if (response.statusCode == 200) {
      var responseBody = json.decode(response.body);

      for (var data in responseBody['data']) {
        _list.add(ProductSegmentDAO.fromJson(data));
      }

      if (_list.length > 0 &&
          widget.title == Constants.UPDATE_CONSUMABLE_PRODUCTS &&
          productData != null) {
        for (int i = 0; i < _list.length; i++) {
          if (productData!.productSegment == _list[i].type) {
            setState(() {
              _productSegment = _list[i];
            });

            loadProductCategories(_productSegment!.code!);
          }
        }
      }
    } else {}

    return _list;
  }

  submitInputData() async {
    String validationError = onValuesValidation();
    // String itemDetailsError = validatingItemDetails();
    if (validationError.isEmpty) {
      if (widget.title == Constants.CREATE_CONSUMABLE_PRODUCTS) {
        setState(() {
          isLoadingProgress = true;
          progressMessage = Constants.GETTING_DATA;
        });
        if (await NetworkStatus.getInternetStatus()) {
          setState(() {
            isLoadingProgress = true;
            progressMessage = Constants.CREATING;
          });
          this.createConsumableProduct();
        } else {
          AppUtills.showSnackBar(_scaffoldkey,
              Language().getString(Constants.NO_INTERNET, selectedLang),
              snackBarBgColor: Colors.black,
              messageColor: Colors.white,
              buttonColor: Colors.white);
        }
      } else {
        if (await NetworkStatus.getInternetStatus()) {
          setState(() {
            isLoadingProgress = true;
            progressMessage = Constants.UPDATING;
          });
          this.updateConsumableProduct();
        } else {
          AppUtills.showSnackBar(_scaffoldkey,
              Language().getString(Constants.NO_INTERNET, selectedLang),
              snackBarBgColor: Colors.black,
              messageColor: Colors.white,
              buttonColor: Colors.white);
        }
      }
    } else {
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          Language().getString(validationError, selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  buildTableContent(String textName, TextEditingController _controller,
      bool _isKeyboard, bool isMandatory) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: isMandatory
                          ? RichText(
                              text: TextSpan(children: [
                                TextSpan(
                                  text: Language()
                                      .getString(textName, selectedLang),
                                  style: TextStyle(
                                      fontSize: StyleView.FONT_SIZE_15,
                                      fontFamily: StyleView.FONT_TITLE,
                                      color: Colors.black),
                                ),
                                TextSpan(
                                    text: "\*",
                                    style: TextStyle(
                                        fontSize: StyleView.FONT_SIZE_15,
                                        color: Colors.red))
                              ]),
                            )
                          : Text(
                              Language().getString(textName, selectedLang),
                              style: TextStyle(
                                  fontSize: StyleView.FONT_SIZE_15,
                                  fontFamily: 'IndianRupee'),
                            ),
                    ),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                color: Colors.white,
                padding: EdgeInsets.only(left: 5),
                child: TextField(
                    keyboardType:
                        _isKeyboard ? TextInputType.number : TextInputType.text,
                    controller: _controller,
                    style: TextStyle(
                      fontFamily: 'IndianRupee',
                    ),
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: Language().getString(textName, selectedLang),
                    )
                    // focusNode: FocusNode(
                    //   canRequestFocus: false,
                    // ),
                    ),
              ),
            )
          ],
        ));
  }

  String onValuesValidation() {
    if (_productNameController.text.isEmpty) {
      return Constants.PLEASE_ENTER_PRODUCT_NAME;
    } else if (_priceList.length == 0) {
      return "Please add price details";
    } else {
      return "";
    }
  }

  buildAddProductImage(String? textName) {
    return Container(
        child: Center(
      child: Container(
          height: 50,
          padding: EdgeInsets.symmetric(vertical: 10),
          color: Colors.white70,
          child: Container(
            padding: EdgeInsets.only(left: 10),
            child: Align(
                alignment: Alignment.center,
                child: InkWell(
                  onTap: () {
                    // showChoiceDialog(context),
                    this.openBottomSheet(context);
                  },
                  child: Icon(
                    Icons.camera_alt,
                    color: Color(0xFF083e64),
                    size: 30.0,
                  ),
                )),
          )),
    ));
  }

  openBottomSheet(BuildContext context) {
    return Dialogs.openBottomSheet(
        context: context,
        openCamera: (myPicture) async {
          this.updateProductImage(myPicture);
        },
        openGallery: (myPicture) async {
          this.updateProductImage(myPicture);
        });
  }

  updateProductImage(File fileImage) {
    Navigator.of(context).pop();
    setState(() {
      imageFile = fileImage;
      isSelectCaptureChoice = true;
      isImageUpdated = true;
      imageBlob = AppUtills.getBase64Image(fileImage, context);
    });
  }

  buildQuantityView(String? _title, StateSetter setState) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: RichText(
                    text: TextSpan(children: [
                      TextSpan(
                        text: Language().getString(_title, selectedLang),
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_15,
                            fontFamily: StyleView.FONT_TITLE,
                            color: Colors.black),
                      ),
                      TextSpan(
                          text: "\*",
                          style: TextStyle(
                              fontSize: StyleView.FONT_SIZE_15,
                              color: Colors.red))
                    ]),
                  ),
                ),
              )),
        ),
        Expanded(
            flex: 2,
            child: Container(
              color: Colors.grey,
              alignment: Alignment.centerLeft,
              child: Row(children: <Widget>[
                Expanded(
                    child: Container(
                  padding: EdgeInsets.only(left: 5),
                  margin: EdgeInsets.only(right: 1),
                  color: Colors.white,
                  child: TextFormField(
                    keyboardType: TextInputType.number,
                    controller: _qntyController,
                    style: TextStyle(fontFamily: 'IndianRupee'),
                    decoration: InputDecoration(
                        border: InputBorder.none, hintText: _title),
                    inputFormatters: [
                      new LengthLimitingTextInputFormatter(6),
                      CommonMethods.inputTextFormatter(isNumber: true)
                    ],
                    onChanged: (value) {
                      productTotalQuantity = int.parse(value);
                    },
                  ),
                )),
                Expanded(
                    child: Container(
                        color: Colors.white,
                        padding: EdgeInsets.only(left: 5),
                        child: DropdownButton<String>(
                            onTap: () {
                              FocusScope.of(context).unfocus();
                            },
                            value: quantityDropdownValue,
                            hint: new Text(
                              Language()
                                  .getString(Constants.SELECT, selectedLang),
                            ),
                            isExpanded: true,
                            underline: SizedBox(),
                            onChanged: (String? data) {
                              setState(() {
                                quantityDropdownValue = data;
                              });
                            },
                            items: Constants.UNIT_PRICE.map((String model) {
                              return new DropdownMenuItem<String>(
                                child: new Text(model),
                                value: model,
                              );
                            }).toList()))),
              ]),
            ))
      ],
    );
  }

  Future<void> showChoiceDialog(BuildContext context) {
    return showDialog(
        barrierDismissible: false,
        context: context,
        barrierColor: Colors.black54,
        builder: (BuildContext context) {
          return AlertDialog(
            elevation: 100.0,
            contentPadding: EdgeInsets.fromLTRB(15.0, 0, 15.0, 0),
            backgroundColor: Color(0XFFE0E0E0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(
                Radius.circular(
                  7.0,
                ),
              ),
            ),
            titlePadding: EdgeInsets.fromLTRB(24.0, 10.0, 10.0, 10.0),
            title: Column(
              children: <Widget>[
                Align(
                  alignment: Alignment.topRight,
                  child: GestureDetector(
                    onTap: () {
                      Navigator.of(context).pop();
                    },
                    child: Icon(
                      Icons.close,
                      color: Colors.red,
                    ),
                  ),
                ),
                SizedBox(
                  height: 2.5,
                ),
              ],
            ),
            content: Container(
              height: 110.0,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Container(
                    margin: EdgeInsets.symmetric(
                      vertical: 5.0,
                    ),
                    height: 40.0,
                    child: ButtonTheme(
                      minWidth: MediaQuery.of(context).size.width,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                            borderRadius: new BorderRadius.circular(30.0),
                          ),
                          backgroundColor: Color(0xFF083e64),
                          textStyle: TextStyle(color: Colors.white),
                          elevation: 3.0,
                        ),
                        onPressed: () async {
                          Navigator.of(context).pop();
                          // var resultImage = await _picker.getImage(
                          //     source: ImageSource.camera);

                          File picture = await AppUtills.getCameraImage(
                              Constants.CAMERA, context);
                          setState(() {
                            imageFile = picture;
                            isSelectCaptureChoice = true;
                            imageBlob =
                                AppUtills.getBase64Image(picture, context);
                          });
                        },
                        child: Padding(
                            padding: EdgeInsets.symmetric(vertical: 5),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                Expanded(
                                  flex: 1,
                                  child: Icon(Icons.camera_alt),
                                ),
                                Expanded(
                                    flex: 2,
                                    child: Text(Language().getString(
                                        Constants.OPEN_CAMERA, selectedLang)))
                              ],
                            )),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.symmetric(
                      vertical: 5.0,
                    ),
                    height: 40.0,
                    child: ButtonTheme(
                      minWidth: MediaQuery.of(context).size.width,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                            borderRadius: new BorderRadius.circular(30.0),
                          ),
                          backgroundColor: Color(0xFF083e64),
                          textStyle: TextStyle(color: Colors.white),
                          elevation: 3.0,
                        ),
                        onPressed: () => {_openGallery()},
                        child: Padding(
                            padding: EdgeInsets.symmetric(vertical: 5),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                Expanded(
                                  flex: 1,
                                  child: Icon(Icons.photo_library),
                                ),
                                Expanded(
                                    flex: 2,
                                    child: Text(Language().getString(
                                        Constants.GALLERY_STRING,
                                        selectedLang)))
                              ],
                            )),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        });
  }

  _openGallery() async {
    File picture = await AppUtills.getCameraImage(Constants.GALLERY, context);
    // String base64Image = base64Encode(picture.readAsBytesSync());
    setState(() {
      imageFile = picture;
      isSelectCaptureChoice = true;
      imageBlob = AppUtills.getBase64Image(picture, context);
      // 'data:image/jpeg;base64,' + base64Image.toString();
    });
    Navigator.of(context).pop();
  }

  buildAddProduct() {
    return Container(
        child: Row(
      children: <Widget>[
        Expanded(
          flex: 1,
          child: Container(
              padding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
              color: Colors.white,
              child: Container(
                width: MediaQuery.of(context).size.width,
                child: Align(
                    alignment: Alignment.centerLeft, child: displayImageView()),
              )),
        ),
      ],
    ));
  }

  displayImageView() {
    if (isSelectCaptureChoice) {
      return Transform.rotate(
        angle: finalAngle,
        origin: Offset(0, 0),
        child: Image.file(
          imageFile,
          fit: BoxFit.fill,
          gaplessPlayback: true,
        ),
      );
    } else {
      if (productData != null && productData!.imageThumbnail!.length > 0) {
        return Image.network(
          Constants.NEW_BASE_URL +
              "assets/consumableProduct/buImage/" +
              productData!.imageThumbnail![0].image!,
          fit: BoxFit.fill,
          gaplessPlayback: true,
          errorBuilder:
              (BuildContext context, Object exception, StackTrace? stackTrace) {
            return Image.asset(
              'assets/images/empty.jpg',
              fit: BoxFit.fill,
              gaplessPlayback: true,
            );
          },
        );
      } else {
        return Image.asset(
          'assets/images/empty.jpg',
          fit: BoxFit.fill,
          gaplessPlayback: true,
        );
      }
    }
  }

  buildDropDownCurrencyName(String _title, StateSetter setState) {
    return Container(
        child: Column(children: <Widget>[
      Container(
          padding: EdgeInsets.all(1),
          child: Row(
            children: <Widget>[
              Expanded(
                child: Container(
                    height: 50,
                    color: Color(Constants.GREY_COLOR_LIGHT),
                    child: Container(
                      padding: EdgeInsets.only(left: 10),
                      child: Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                              Language().getString(_title, selectedLang),
                              style: TextStyle(
                                  fontSize: StyleView.FONT_SIZE_15,
                                  fontFamily: StyleView.FONT_TITLE))),
                    )),
              ),
              Expanded(
                flex: 2,
                child: Container(
                    color: Colors.white70,
                    padding: EdgeInsets.only(left: 5, right: 5),
                    child: DropdownButton<CurrencyNameDAO>(
                        onTap: () {
                          FocusScope.of(context).unfocus();
                        },
                        isExpanded: true,
                        hint: Text(_title),
                        underline: SizedBox(),
                        items: _currencyNameList
                            .map((CurrencyNameDAO _currencyNameValue) {
                          return DropdownMenuItem<CurrencyNameDAO>(
                            value: _currencyNameValue,
                            child: new Text(
                              _currencyNameValue.name!,
                              style:
                                  TextStyle(fontFamily: StyleView.FONT_TITLE),
                            ),
                          );
                        }).toList(),
                        value: currencyNameDropdown,
                        onChanged: (CurrencyNameDAO? _currency) {
                          setState(() {
                            currencyNameDropdown = _currency;
                            currencySymbol = currencyNameDropdown!.htmlSymbol;
                          });
                        })),
              )
            ],
          ))
    ]));
  }

  buildUnitDropdown(String _title, StateSetter setState) {
    return Container(
        child: Column(children: <Widget>[
      Container(
          color: Colors.white,
          padding: EdgeInsets.all(1),
          child: Row(
            children: <Widget>[
              Expanded(
                child: Container(
                    height: 50,
                    color: Color(Constants.GREY_COLOR_LIGHT),
                    child: Container(
                      padding: EdgeInsets.only(left: 10),
                      child: Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                              Language().getString(_title, selectedLang),
                              style: TextStyle(
                                  fontSize: StyleView.FONT_SIZE_15,
                                  fontFamily: StyleView.FONT_TITLE))),
                    )),
              ),
              Expanded(
                flex: 2,
                child: Row(
                  children: [
                    (priceUnitDropdownValue != null)
                        ? Expanded(
                            child: Container(
                                padding: EdgeInsets.only(
                                  left: 5,
                                ),
                                child: Text(
                                  "Per:",
                                  style: TextStyle(fontSize: 15.0),
                                )),
                          )
                        : Container(),
                    Expanded(
                      flex: 5,
                      child: Container(
                          color: Colors.white70,
                          padding: EdgeInsets.only(
                              left:
                                  (priceUnitDropdownValue != null) ? 0.0 : 5.0),
                          child: DropdownButton<String>(
                              onTap: () {
                                FocusScope.of(context).unfocus();
                              },
                              isExpanded: true,
                              hint: Text(
                                Language().getString(
                                    Constants.SELECT_UNIT, selectedLang),
                              ),
                              underline: SizedBox(),
                              items:
                                  Constants.UNIT_PRICE.map((String priceUnit) {
                                return DropdownMenuItem<String>(
                                  value: priceUnit,
                                  child: new Text(
                                    priceUnit,
                                    style: TextStyle(
                                        fontFamily: StyleView.FONT_TITLE),
                                  ),
                                );
                              }).toList(),
                              value: priceUnitDropdownValue,
                              onChanged: (String? _currency) {
                                setState(() {
                                  priceUnitDropdownValue = _currency;
                                });
                              })),
                    ),
                  ],
                ),
              )
            ],
          ))
    ]));
  }

  buildText(String title, String _offerValue) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(title,
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_15,
                            fontFamily: StyleView.FONT_TITLE))),
              )),
        ),
        Expanded(
          flex: 2,
          child: Container(
              color: Colors.white70,
              height: 50,
              padding: EdgeInsets.only(left: 5),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  _offerValue,
                  style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                ),
              )),
        )
      ],
    );
  }

  buildDropDownState(String _title) {
    return Container(
        child: Column(children: <Widget>[
      Container(
          padding: EdgeInsets.all(1),
          child: Row(
            children: <Widget>[
              Expanded(
                child: Container(
                    height: 50,
                    color: Color(Constants.GREY_COLOR_LIGHT),
                    child: Container(
                      padding: EdgeInsets.only(left: 10),
                      child: Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                              Language().getString(_title, selectedLang),
                              style: TextStyle(
                                  fontSize: StyleView.FONT_SIZE_15,
                                  fontFamily: StyleView.FONT_TITLE))),
                    )),
              ),
              Expanded(
                flex: 2,
                child: Container(
                    color: Colors.white,
                    padding: EdgeInsets.only(left: 5, right: 5),
                    child: DropdownButton<StatesDAO>(
                        onTap: () {
                          FocusScope.of(context).unfocus();
                        },
                        value: _stateName,
                        hint: new Text(Language()
                            .getString(Constants.SELECT_STATE, selectedLang)),
                        isExpanded: true,
                        underline: SizedBox(),
                        onChanged: (StatesDAO? data) {
                          _districtList.clear();
                          districtDropdownValue = null;
                          citiesDropDownValue = null;
                          _citiesList.clear();
                          setState(() {
                            _stateName = data;
                            _districtList.addAll(_stateName!.cities!);
                          });

                          this
                              .getCitiesList(_countryName!.name, _stateName!.id)
                              .then((value) {
                            if (value.length > 0) {
                              setState(() {
                                _citiesList.clear();
                                _citiesList.addAll(value[0].cities!);
                              });
                            }
                          });
                        },
                        items: stateList.map((StatesDAO model) {
                          return new DropdownMenuItem<StatesDAO>(
                            child: new Text(model.state!),
                            value: model,
                          );
                        }).toList())),
              )
            ],
          ))
    ]));
  }

  /// City Dropdown
  buildCityDropdown(String text) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(Language().getString(text, selectedLang),
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: StyleView.FONT_TITLE))),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5, right: 5),
                  child: DropdownButton<String>(
                      value: citiesDropDownValue,
                      isExpanded: true,
                      hint: Text(Language()
                          .getString(Constants.SELECT_CITY, selectedLang)),
                      underline: SizedBox(),
                      onChanged: (String? data) {
                        setState(() {
                          citiesDropDownValue = data;
                        });
                      },
                      onTap: () {
                        FocusScope.of(context).unfocus();
                      },
                      items: _citiesList.map((String model) {
                        return new DropdownMenuItem<String>(
                          child: new Text(model),
                          value: model,
                        );
                      }).toList())),
            )
          ],
        ));
  }

  buildDropDownDistrict(String _title) {
    return Container(
        child: Column(children: <Widget>[
      Container(
          padding: EdgeInsets.all(1),
          child: Row(
            children: <Widget>[
              Expanded(
                child: Container(
                    height: 50,
                    color: Color(Constants.GREY_COLOR_LIGHT),
                    child: Container(
                      padding: EdgeInsets.only(left: 10),
                      child: Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                              Language().getString(_title, selectedLang),
                              style: TextStyle(
                                  fontSize: StyleView.FONT_SIZE_15,
                                  fontFamily: StyleView.FONT_TITLE))),
                    )),
              ),
              Expanded(
                flex: 2,
                child: Container(
                    color: Colors.white,
                    padding: EdgeInsets.only(left: 5, right: 5),
                    child: DropdownButton<String>(
                        onTap: () {
                          FocusScope.of(context).unfocus();
                        },
                        value: districtDropdownValue,
                        hint: new Text(Language().getString(
                            Constants.SELECT_DISTRICT, selectedLang)),
                        isExpanded: true,
                        underline: SizedBox(),
                        onChanged: (String? data) {
                          setState(() {
                            districtDropdownValue = data;
                          });
                        },
                        items: _districtList.map((String model) {
                          return new DropdownMenuItem<String>(
                            child: new Text(model),
                            value: model,
                          );
                        }).toList())),
              )
            ],
          ))
    ]));
  }

  buildDropDownCountry(String _title) {
    return Container(
        child: Column(children: <Widget>[
      Container(
          padding: EdgeInsets.all(1),
          child: Row(
            children: <Widget>[
              Expanded(
                child: Container(
                    height: 50,
                    color: Color(Constants.GREY_COLOR_LIGHT),
                    child: Container(
                      padding: EdgeInsets.only(left: 10),
                      child: Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                              Language().getString(_title, selectedLang),
                              style: TextStyle(
                                  fontSize: StyleView.FONT_SIZE_15,
                                  fontFamily: StyleView.FONT_TITLE))),
                    )),
              ),
              Expanded(
                flex: 2,
                child: Container(
                    color: Colors.white,
                    padding: EdgeInsets.only(left: 5, right: 5),
                    child: DropdownButton<CountryDAO>(
                        onTap: () {
                          FocusScope.of(context).unfocus();
                        },
                        value: _countryName,
                        hint: new Text(Language()
                            .getString(Constants.SELECT_COUNTRY, selectedLang)),
                        isExpanded: true,
                        underline: SizedBox(),
                        onChanged: (CountryDAO? data) {
                          _countryName = data;
                          getStates(_countryName!.name!).then((onValue) {
                            setState(() {
                              stateList.addAll(onValue);
                            });
                          });
                        },
                        items: countryList.map((CountryDAO model) {
                          return new DropdownMenuItem<CountryDAO>(
                            child: new Text(model.name!),
                            value: model,
                          );
                        }).toList())),
              )
            ],
          ))
    ]));
  }

  buildPincodeView() {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                height: 50,
                color: Color(Constants.GREY_COLOR_LIGHT),
                child: Container(
                  padding: EdgeInsets.only(left: 10),
                  child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                          Language()
                              .getString(Constants.PIN_CODE, selectedLang),
                          style: TextStyle(
                              fontSize: StyleView.FONT_SIZE_15,
                              fontFamily: StyleView.FONT_TITLE))),
                ),
              ),
            ),
            Expanded(
                flex: 2,
                child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5),
                  child: TextFormField(
                    controller: _pinController,
                    keyboardType: TextInputType.number,
                    style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                    decoration: InputDecoration(
                      hintText: Language()
                          .getString(Constants.PIN_CODE, selectedLang),
                      border: InputBorder.none,
                    ),
                    inputFormatters: [
                      new LengthLimitingTextInputFormatter(6),
                      FilteringTextInputFormatter.digitsOnly
                    ],
                  ),
                ))
          ],
        ));
  }

  buildDropDownSigment(String _title) {
    return Container(
      child: Column(
        children: <Widget>[
          Container(
              padding: EdgeInsets.all(1),
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: Container(
                        height: 50,
                        color: Color(Constants.GREY_COLOR_LIGHT),
                        child: Container(
                          padding: EdgeInsets.only(left: 10),
                          child: Align(
                              alignment: Alignment.centerLeft,
                              child: RichText(
                                text: TextSpan(children: [
                                  TextSpan(
                                    text: Language()
                                        .getString(_title, selectedLang),
                                    style: TextStyle(
                                        fontSize: StyleView.FONT_SIZE_15,
                                        fontFamily: StyleView.FONT_TITLE,
                                        color: Colors.black),
                                  ),
                                ]),
                              )),
                        )),
                  ),
                  Expanded(
                    flex: 2,
                    child: InkWell(
                      onTap: () {
                        FocusScope.of(context).unfocus();
                        if (productsSegments.length > 0) {
                          this.showProductSegmentData();
                        } else {
                          print("Product Segment Data Loading");
                        }
                      },
                      child: Container(
                          height: 50,
                          color: Colors.white70,
                          padding: EdgeInsets.only(left: 5, right: 5),
                          child: Row(
                            children: [
                              Expanded(
                                flex: 4,
                                child: Container(
                                  child: Text((_productSegment == null)
                                      ? Language().getString(
                                          Constants.SELECT_SEGMENT,
                                          selectedLang)
                                      : _productSegment!.type!),
                                ),
                              ),
                              Expanded(
                                child: Container(
                                  child: Icon(Icons.expand_more),
                                ),
                              ),
                            ],
                          )),
                    ),
                  )
                ],
              ))
        ],
      ),
    );
  }

  showProductSegmentData() {
    return showDialog(
      context: context,
      builder: (context) => AlertDialog(
        contentPadding: EdgeInsets.fromLTRB(0.0, 24.0, 0.0, 24.0),
        content: Container(
            child: Column(
          children: [
            // Container(
            //   margin: EdgeInsets.symmetric(horizontal: 5.0, vertical: 5.0),
            //   decoration: AppUtills.boxDecoration(),
            //   child: SearchableDropdown.single(
            //     items: productsSegments.map((ProductSegmentDAO model) {
            //       return new DropdownMenuItem<ProductSegmentDAO>(
            //         child: new Text(model.type),
            //         value: model,
            //       );
            //     }).toList(),
            //     value: _productSegment,
            //     underline: Container(),
            //     hint: Language().getString(Constants.SEARCH, selectedLang),
            //     searchHint:
            //         Language().getString(Constants.SEARCH, selectedLang),
            //     onChanged: (value) {
            //       Navigator.pop(context);
            //       setState(() {
            //         _productSegment = value;

            //         /// Clearing product categorie Values
            //         _productCategory = null;
            //         productCategories.clear();

            //         /// Clearing Product Sub Categorie Values
            //         productSubCategories.clear();
            //         _productSubCategory = null;
            //       });
            //       loadProductCategories(_productSegment.code);
            //     },
            //     isExpanded: true,
            //   ),
            // ),
            Expanded(
              child: Container(
                child: ListView.builder(
                  shrinkWrap: true,
                  itemBuilder: (context, index) {
                    return InkWell(
                      onTap: () {
                        Navigator.of(context).pop();
                        setState(() {
                          _productSegment = productsSegments[index];

                          /// Clearing product categorie Values
                          _productCategory = null;
                          productCategories.clear();

                          /// Clearing Product Sub Categorie Values
                          productSubCategories.clear();
                          _productSubCategory = null;
                        });

                        loadProductCategories(_productSegment!.code!);
                      },
                      child: Container(
                        margin: EdgeInsets.symmetric(
                          horizontal: 5.0,
                          vertical: 2.0,
                        ),
                        padding: EdgeInsets.all(8.0),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(5.0),
                            color: Colors.white,
                            boxShadow: [
                              BoxShadow(
                                  offset: Offset(0.0, 1.0),
                                  blurRadius: 2.5,
                                  color: Colors.grey)
                            ]),
                        alignment: Alignment.centerLeft,
                        child: Text("${productsSegments[index].type}",
                            textAlign: TextAlign.start),
                      ),
                    );
                  },
                  itemCount: productsSegments.length,
                ),
              ),
            )
          ],
        )),
      ),
    );
  }

  createConsumableProduct() async {
    this.renderItemDetails();
    List<Map<String, dynamic>> attributesArray = [];
    var attributesObject;

    for (int i = 0; i < attributesList.length; i++) {
      attributesObject = {
        "${attributesList[i].attributeKey}":
            "${attributesList[i].attributeValue}"
      };
      attributesArray.add(attributesObject);
    }

    List<Map<String, dynamic>> inventoryArrayList = [];
    var inventoryObject;
    for (int i = 0; i < inventoryList.length; i++) {
      inventoryObject = {
        "location_name": inventoryList[i].locationName,
        "quantity": inventoryList[i].quantity,
        "batch_no": inventoryList[i].batchNumber
      };
      inventoryArrayList.add(inventoryObject);
    }

    List<Map<String, dynamic>> batchPriceArrayList = [];
    var batchPriceObject;

    for (int p = 0; p < _priceList.length; p++) {
      batchPriceObject = {
        "price": double.parse(_priceList[p].price!),
        "unit": _priceList[p].priceIn,
        "currency_code": "",
        "currency_name": _priceList[p].currencyName,
        "slab_pricing_tiers": "Quantity and Price combinations",
        "batch_number": _priceList[p].batchNumber,
        "quantity": int.parse(_priceList[p].quantity!),
        "quantity_in": _priceList[p].quantityIn,
        "net_rate": double.parse(_priceList[p].netRate!),
        "mrp": double.parse(_priceList[p].mrp!),
        "manufacture_date_time": _priceList[p].manufacturDate,
        "expiry_date": _priceList[p].expireDate,
      };

      batchPriceArrayList.add(batchPriceObject);
    }

    List<Map<String, dynamic>> issueDetailsList = [];
    var issueDetailsObject;

    for (int m = 0; m < issuedDetailsList.length; m++) {
      issueDetailsObject = {
        "issued_date": issuedDetailsList[m].issuedDate,
        "issued_to": issuedDetailsList[m].issuedTo,
        "purpose": issuedDetailsList[m].purpose,
        "approved_by": issuedDetailsList[m].approvedBy,
        "issued_quantity": double.parse(issuedDetailsList[m].issuedQuantity!),
        "batch_no": issuedDetailsList[m].batchNumber,
        "remaining_quantity": issuedDetailsList[m].remaingQuantity,
        "department": issuedDetailsList[m].department
      };

      issueDetailsList.add(issueDetailsObject);
    }
    Map reqBody = {
      "bu_id": buId,
      "name": _productNameController.text,
      "brand": _brandController.text,
      "description": _descriptionController.text,
      "product_segment": _productSegment != null ? _productSegment!.type : "",
      "product_category":
          _productCategory != null ? _productCategory!.type : "",
      "product_sub_category":
          _productSubCategory != null ? _productSubCategory!.type : "",
      // "images": "",
      "consumable":
          consumableProductRadioValue == Constants.YES_STRING ? true : false,
      "attributes": attributesArray,
      "manufacture_details": {
        "model_number": _modelNumberController.text,
        "release_date": formattedReleaseDate.isEmpty
            ? formatter.format(DateTime.now())
            : formattedReleaseDate,
        "name": _manufactureNameController.text,
        "manufacturer_Address": _manufactureAddressController.text,
        "building_name": _buildingNumController.text,
        "area": _areaController.text,
        "city": citiesDropDownValue != null ? citiesDropDownValue : "",
        "taluka": _talukController.text,
        "landmark": _landMarkController.text,
        "state": _stateName != null ? _stateName!.state : "",
        "district": districtDropdownValue != null ? districtDropdownValue : "",
        "pin": _pinController.text,
        "country": _countryName != null ? _countryName!.name : ""
      },
      "shipping_details": {
        "weight": strWeight,
        "width": strWidth,
        "height": strHeight,
        "depth": strDepth,
        "volume": strVolume
      },
      "batch_pricing": batchPriceArrayList,
      "inventory_management": inventoryArrayList,
      "issues": issueDetailsList
    };
    String body = json.encode(reqBody);

    var response = await _consumableGrpcService
        .createConsumableProduct(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    // setState(() {
    //   isLoadingProgress = false;
    // });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);
      if (imageBlob.isNotEmpty) {
        this._uploadAssetImage(data);
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  updateConsumableProduct() async {
    this.renderItemDetails();
    List<Map<String, dynamic>> attributesArray = [];
    var attributesObject;

    for (int i = 0; i < attributesList.length; i++) {
      attributesObject = {
        "${attributesList[i].attributeKey}":
            "${attributesList[i].attributeValue}"
      };
      attributesArray.add(attributesObject);
    }

    List<Map<String, dynamic>> inventoryArrayList = [];
    var inventoryObject;
    for (int i = 0; i < inventoryList.length; i++) {
      inventoryObject = {
        "location_name": inventoryList[i].locationName,
        "quantity": inventoryList[i].quantity,
        "batch_no": inventoryList[i].batchNumber
      };
      inventoryArrayList.add(inventoryObject);
    }

    List<Map<String, dynamic>> batchPriceArrayList = [];
    var batchPriceObject;

    for (int p = 0; p < _priceList.length; p++) {
      batchPriceObject = {
        "price": double.parse(_priceList[p].price!),
        "unit": _priceList[p].priceIn,
        "currency_code": "",
        "currency_name": _priceList[p].currencyName,
        "slab_pricing_tiers": "Quantity and Price combinations",
        "batch_number": _priceList[p].batchNumber,
        "quantity": int.parse(_priceList[p].quantity!),
        "quantity_in": _priceList[p].quantityIn,
        "net_rate": double.parse(_priceList[p].netRate!),
        "mrp": double.parse(_priceList[p].mrp!),
        "manufacture_date_time": _priceList[p].manufacturDate,
        "expiry_date": _priceList[p].expireDate,
      };

      batchPriceArrayList.add(batchPriceObject);
    }
    List<Map<String, dynamic>> issueDetailsList = [];
    var issueDetailsObject;

    for (int m = 0; m < issuedDetailsList.length; m++) {
      issueDetailsObject = {
        "issued_date": issuedDetailsList[m].issuedDate,
        "issued_to": issuedDetailsList[m].issuedTo,
        "purpose": issuedDetailsList[m].purpose,
        "approved_by": issuedDetailsList[m].approvedBy,
        "issued_quantity": double.parse(issuedDetailsList[m].issuedQuantity!),
        "batch_no": issuedDetailsList[m].batchNumber,
        "remaining_quantity": issuedDetailsList[m].remaingQuantity
      };

      issueDetailsList.add(issueDetailsObject);
    }
    Map reqBody = {
      "id": widget.productId,
      "bu_id": buId,
      "name": _productNameController.text,
      "brand": _brandController.text,
      "description": _descriptionController.text,
      "product_segment": _productSegment != null ? _productSegment!.type : "",
      "product_category":
          _productCategory != null ? _productCategory!.type : "",
      "product_sub_category":
          _productSubCategory != null ? _productSubCategory!.type : "",
      "images": "",
      "consumable":
          consumableProductRadioValue == Constants.YES_STRING ? true : false,
      "attributes": attributesArray,
      "manufacture_details": {
        "model_number": _modelNumberController.text,
        "release_date": formattedReleaseDate.isEmpty
            ? formatter.format(DateTime.now())
            : formattedReleaseDate,
        "name": _manufactureNameController.text,
        "manufacturer_Address": _manufactureAddressController.text,
        "building_name": _buildingNumController.text,
        "area": _areaController.text,
        "city": citiesDropDownValue != null ? citiesDropDownValue : "",
        "taluka": _talukController.text,
        "landmark": _landMarkController.text,
        "state": _stateName != null ? _stateName!.state : "",
        "district": districtDropdownValue != null ? districtDropdownValue : "",
        "pin": _pinController.text,
        "country": _countryName != null ? _countryName!.name : ""
      },
      "shipping_details": {
        "weight": strWeight,
        "width": strWidth,
        "height": strHeight,
        "depth": strDepth,
        "volume": strVolume
      },
      "batch_pricing": batchPriceArrayList,
      "inventory_management": inventoryArrayList,
      "issues": issueDetailsList
    };

    String body = json.encode(reqBody);

    var response = await _consumableGrpcService
        .updateConsumableProduct(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);

      if (isImageUpdated) {
        this._uploadAssetImage(widget.productId);
      } else {
        final action = await Dialogs.yesCancelDialog(
            context,
            Language().getString(Constants.SUCCESS, selectedLang),
            data,
            Language().getString(Constants.OKAY_STR, selectedLang),
            "",
            false);

        if (action == DialogAction.yes) {
          Navigator.pop(context);
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  renderItemDetails() {
    strHeight = _heightController.text +
        " " +
        (heightDropdownValue != null ? heightDropdownValue! : "");
    strWeight = _weightController.text +
        " " +
        (weightDropdownValue != null ? weightDropdownValue! : "");
    strWidth = _widthController.text +
        " " +
        (widthDropdownValue != null ? widthDropdownValue! : "");
    strVolume = volumeController.text +
        " " +
        (volumeDropdownValue != null ? volumeDropdownValue! : "");
    strDepth = _depthController.text +
        " " +
        (depthDropdownValue != null ? depthDropdownValue! : "");
  }

  alertmessageDisplay(message) {
    return showDialog(
        context: context,
        barrierColor: Colors.black54,
        barrierDismissible: false,
        builder: (context) {
          return AlertDialog(
            elevation: 100.0,
            title: Text(Language().getString(Constants.SUCCESS, selectedLang)),
            content: new Text(Language().getString(message, selectedLang)),
            actions: <Widget>[
              TextButton(
                child: new Text(
                    Language().getString(Constants.OKAY_STR, selectedLang),
                    style: TextStyle(
                      color: Color(Constants.APP_COLOR),
                      fontSize: 18.0,
                    )),
                onPressed: () {
                  Navigator.of(context).pop();
                  Navigator.pop(context);
                },
              ),
            ],
          );
        });
  }

  buildTextField(String _text) {
    return Row(
      children: <Widget>[
        Align(
            child: Text(_text,
                style: TextStyle(
                    fontFamily: StyleView.FONT_TITLE,
                    fontWeight: FontWeight.bold,
                    fontSize: StyleView.FONT_SIZE_15)))
      ],
    );
  }

  buildDropDownTax(String _title) {
    return Container(
        child: Column(children: <Widget>[
      Container(
          padding: EdgeInsets.all(1),
          child: Row(
            children: <Widget>[
              Expanded(
                child: Container(
                    height: 50,
                    color: Color(Constants.GREY_COLOR_LIGHT),
                    child: Container(
                      padding: EdgeInsets.only(left: 10),
                      child: Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                              Language().getString(_title, selectedLang),
                              style: TextStyle(
                                  fontSize: StyleView.FONT_SIZE_15,
                                  fontFamily: StyleView.FONT_TITLE))),
                    )),
              ),
              Expanded(
                flex: 2,
                child: Container(
                    color: Colors.white70,
                    padding: EdgeInsets.only(left: 5, right: 5),
                    child: DropdownButton<String>(
                        onTap: () {
                          FocusScope.of(context).unfocus();
                        },
                        value: taxDropdownValue,
                        hint: new Text(
                          Language().getString(Constants.SELECT, selectedLang),
                        ),
                        isExpanded: true,
                        underline: SizedBox(),
                        onChanged: (String? data) {
                          setState(() {
                            taxDropdownValue = data;
                          });
                        },
                        items: Constants.taxTypes.map((String model) {
                          return new DropdownMenuItem<String>(
                            child: new Text(model),
                            value: model,
                          );
                        }).toList())),
              )
            ],
          ))
    ]));
  }

  buildDropdownTaxValue(String _title) {
    return Container(
        child: Column(children: <Widget>[
      Container(
          padding: EdgeInsets.all(1),
          child: Row(
            children: <Widget>[
              Expanded(
                child: Container(
                    height: 50,
                    color: Color(Constants.GREY_COLOR_LIGHT),
                    child: Container(
                      padding: EdgeInsets.only(left: 10),
                      child: Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                              Language().getString(_title, selectedLang),
                              style: TextStyle(
                                  fontSize: StyleView.FONT_SIZE_15,
                                  fontFamily: StyleView.FONT_TITLE))),
                    )),
              ),
              Expanded(
                flex: 2,
                child: Container(
                    color: Colors.white70,
                    padding: EdgeInsets.only(left: 5, right: 5),
                    child: DropdownButton<String>(
                        onTap: () {
                          FocusScope.of(context).unfocus();
                        },
                        value: taxValueDropdownValue,
                        hint: new Text("%"),
                        isExpanded: true,
                        underline: SizedBox(),
                        onChanged: (String? data) {
                          // onChangeProductTax(data);
                          setState(() {
                            taxValueDropdownValue = data;
                            // _valueControllr.text = data.value;
                          });
                        },
                        items: Constants.taxRateValues.map((String model) {
                          return new DropdownMenuItem<String>(
                            child: new Text(model),
                            value: model,
                          );
                        }).toList())),
              )
            ],
          ))
    ]));
  }

  buildDropDownProductType(String _title) {
    return Container(
        child: Column(children: <Widget>[
      Container(
          padding: EdgeInsets.all(1),
          child: Row(
            children: <Widget>[
              Expanded(
                child: Container(
                    height: 50,
                    color: Color(Constants.GREY_COLOR_LIGHT),
                    child: Container(
                      padding: EdgeInsets.only(left: 10),
                      child: Align(
                          alignment: Alignment.centerLeft,
                          child: RichText(
                            text: TextSpan(children: [
                              TextSpan(
                                text: _title,
                                style: TextStyle(
                                    fontSize: StyleView.FONT_SIZE_15,
                                    fontFamily: StyleView.FONT_TITLE,
                                    color: Colors.black),
                              ),
                            ]),
                          )),
                    )),
              ),
              Expanded(
                flex: 2,
                child: InkWell(
                  onTap: () {
                    FocusScope.of(context).unfocus();
                    showProductsTypeDialog(context);
                  },
                  child: Container(
                      height: 50,
                      color: Colors.white70,
                      padding: EdgeInsets.only(left: 5, right: 5),
                      child: Row(
                        children: [
                          Expanded(
                            flex: 4,
                            child: Container(
                              child: Text((_productType == null)
                                  ? "Select product type"
                                  : _productType!.type!),
                            ),
                          ),
                          Expanded(
                            child: Container(
                              child: Icon(Icons.expand_more),
                            ),
                          ),
                        ],
                      )),
                ),
              )
            ],
          ))
    ]));
  }

  showProductsTypeDialog(context) {
    return showDialog(
      context: context,
      builder: (context) => AlertDialog(
        contentPadding: EdgeInsets.fromLTRB(0.0, 24.0, 0.0, 24.0),
        content: Container(
          child: SingleChildScrollView(
            child: Column(
              children: [
                for (int i = 0; i < productTypeList.length; i++)
                  InkWell(
                    onTap: () {
                      Navigator.of(context).pop();
                      setState(() {
                        _productType = productTypeList[i];
                      });
                    },
                    child: Container(
                      margin: EdgeInsets.symmetric(
                        horizontal: 5.0,
                        vertical: 2.0,
                      ),
                      padding: EdgeInsets.all(8.0),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5.0),
                          color: Colors.white,
                          boxShadow: [
                            BoxShadow(
                                offset: Offset(0.0, 1.0),
                                blurRadius: 2.5,
                                color: Colors.grey)
                          ]),
                      alignment: Alignment.centerLeft,
                      child: Text("${productTypeList[i].type}",
                          textAlign: TextAlign.start),
                    ),
                  )
              ],
            ),
          ),
        ),
      ),
    );
  }

  buildDateFieldRelease(String _title) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: RichText(
                          text: TextSpan(children: [
                            TextSpan(
                              text: Language().getString(_title, selectedLang),
                              style: TextStyle(
                                  fontSize: StyleView.FONT_SIZE_15,
                                  fontFamily: StyleView.FONT_TITLE,
                                  color: Colors.black),
                            ),
                          ]),
                        )),
                  )),
            ),
            Expanded(
                flex: 2,
                child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5),
                  alignment: Alignment.topLeft,
                  child: ElevatedButton(
                      onPressed: () async {
                        FocusScope.of(context).unfocus();
                        // pickCustomDate(context, _title);
                        String value = await AppUtills.getSelectedDate(context);
                        setState(() {
                          formattedReleaseDate = value;
                        });
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        elevation: 0.0,
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Text(formattedReleaseDate),
                          Image.asset(
                            'assets/images/calander.png',
                            height: 30,
                          )
                        ],
                      )),
                )),
          ],
        ));
  }

  buildDateFieldManufacture(String _title, StateSetter setState) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: RichText(
                          text: TextSpan(children: [
                            TextSpan(
                              text: Language().getString(_title, selectedLang),
                              style: TextStyle(
                                  fontSize: StyleView.FONT_SIZE_15,
                                  fontFamily: StyleView.FONT_TITLE,
                                  color: Colors.black),
                            ),
                          ]),
                        )),
                  )),
            ),
            Expanded(
                flex: 2,
                child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5),
                  alignment: Alignment.topLeft,
                  child: ElevatedButton(
                      onPressed: () async {
                        CommonMethods.hideKeyboard(context);
                        // FocusScope.of(context).unfocus();
                        // // pickCustomDate(context, _title);
                        String value = await AppUtills.getSelectedDate(context);
                        setState(() {
                          formattedManufactureDate = value;
                        });
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        elevation: 0.0,
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Text(formattedManufactureDate!),
                          Image.asset(
                            'assets/images/calander.png',
                            height: 30,
                          )
                        ],
                      )),
                )),
          ],
        ));
  }

  buildDateFieldExpaire(String _title, StateSetter setState) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: RichText(
                          text: TextSpan(children: [
                            TextSpan(
                              text: Language().getString(_title, selectedLang),
                              style: TextStyle(
                                  fontSize: StyleView.FONT_SIZE_15,
                                  fontFamily: StyleView.FONT_TITLE,
                                  color: Colors.black),
                            ),
                          ]),
                        )),
                  )),
            ),
            Expanded(
                flex: 2,
                child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5),
                  alignment: Alignment.topLeft,
                  child: ElevatedButton(
                      onPressed: () async {
                        CommonMethods.hideKeyboard(context);
                        String value = await AppUtills.getSelectedDate(context);
                        setState(() {
                          formattedExpireDate = value;
                        });
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        elevation: 0.0,
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Text(formattedExpireDate!),
                          Image.asset(
                            'assets/images/calander.png',
                            height: 30,
                          )
                        ],
                      )),
                )),
          ],
        ));
  }

  buildDropDownSubtype(String _title) {
    return Container(
        child: Column(children: <Widget>[
      Container(
          padding: EdgeInsets.all(1),
          child: Row(
            children: <Widget>[
              Expanded(
                child: Container(
                    height: 50,
                    color: Color(Constants.GREY_COLOR_LIGHT),
                    child: Container(
                      padding: EdgeInsets.only(left: 10),
                      child: Align(
                          alignment: Alignment.centerLeft,
                          child: RichText(
                            text: TextSpan(children: [
                              TextSpan(
                                text: _title,
                                style: TextStyle(
                                    fontSize: StyleView.FONT_SIZE_15,
                                    fontFamily: StyleView.FONT_TITLE,
                                    color: Colors.black),
                              ),
                            ]),
                          )),
                    )),
              ),
              Expanded(
                flex: 2,
                child: InkWell(
                  onTap: () {
                    FocusScope.of(context).unfocus();
                    showProductsSubTypeDialog();
                  },
                  child: Container(
                      height: 50,
                      color: Colors.white70,
                      padding: EdgeInsets.only(left: 5, right: 5),
                      child: Row(
                        children: [
                          Expanded(
                            flex: 4,
                            child: Container(
                              child: Text((_productSubType == null)
                                  ? "Select sub-type"
                                  : _productSubType!.type!),
                            ),
                          ),
                          Expanded(
                            child: Container(
                              child: Icon(Icons.expand_more),
                            ),
                          ),
                        ],
                      )),
                ),
              )
            ],
          ))
    ]));
  }

  showProductsSubTypeDialog() {
    return showDialog(
      context: context,
      builder: (context) => AlertDialog(
        contentPadding: EdgeInsets.fromLTRB(0.0, 24.0, 0.0, 24.0),
        content: Container(
          child: SingleChildScrollView(
            child: Column(
              children: [
                for (int i = 0; i < productSubTypes.length; i++)
                  InkWell(
                    onTap: () {
                      Navigator.of(context).pop();
                      setState(() {
                        _productSubType = productSubTypes[i];
                      });
                    },
                    child: Container(
                      margin: EdgeInsets.symmetric(
                        horizontal: 5.0,
                        vertical: 2.0,
                      ),
                      padding: EdgeInsets.all(8.0),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5.0),
                          color: Colors.white,
                          boxShadow: [
                            BoxShadow(
                                offset: Offset(0.0, 1.0),
                                blurRadius: 2.5,
                                color: Colors.grey)
                          ]),
                      alignment: Alignment.centerLeft,
                      child: Text("${productSubTypes[i].type}",
                          textAlign: TextAlign.start),
                    ),
                  )
              ],
            ),
          ),
        ),
      ),
    );
  }

  buildDropDownSubCategory(String _title) {
    return Container(
        child: Column(children: <Widget>[
      Container(
          padding: EdgeInsets.all(1),
          child: Row(
            children: <Widget>[
              Expanded(
                child: Container(
                    height: 50,
                    color: Color(Constants.GREY_COLOR_LIGHT),
                    child: Container(
                      padding: EdgeInsets.only(left: 10),
                      child: Align(
                          alignment: Alignment.centerLeft,
                          child: RichText(
                            text: TextSpan(children: [
                              TextSpan(
                                text:
                                    Language().getString(_title, selectedLang),
                                style: TextStyle(
                                    fontSize: StyleView.FONT_SIZE_15,
                                    fontFamily: StyleView.FONT_TITLE,
                                    color: Colors.black),
                              ),
                            ]),
                          )),
                    )),
              ),
              Expanded(
                flex: 2,
                child: InkWell(
                  onTap: () {
                    FocusScope.of(context).unfocus();
                    if (productSubCategories.length > 0) {
                      this.showProductSubCategorieData();
                    } else {
                      print("Product Sub Categorie Data Loading");
                    }
                  },
                  child: Container(
                      height: 50,
                      color: Colors.white70,
                      padding: EdgeInsets.only(left: 5, right: 5),
                      child: Row(
                        children: [
                          Expanded(
                            flex: 4,
                            child: Container(
                              child: Text((_productSubCategory == null)
                                  ? Language().getString(
                                      Constants.SELECT_SUB_CATEGORY,
                                      selectedLang)
                                  : _productSubCategory!.type!),
                            ),
                          ),
                          Expanded(
                            child: Container(
                              child: Icon(Icons.expand_more),
                            ),
                          ),
                        ],
                      )),
                ),
              )
            ],
          ))
    ]));
  }

  showProductSubCategorieData() {
    return showDialog(
      context: context,
      builder: (context) => AlertDialog(
        contentPadding: EdgeInsets.fromLTRB(0.0, 24.0, 0.0, 24.0),
        content: Container(
          child: Column(
            children: [
              // Container(
              //   margin: EdgeInsets.symmetric(horizontal: 5.0, vertical: 5.0),
              //   decoration: AppUtills.boxDecoration(),
              //   child: SearchableDropdown.single(
              //     items:
              //         productSubCategories.map((ProductSubCategoryDAO model) {
              //       return new DropdownMenuItem<ProductSubCategoryDAO>(
              //         child: new Text(model.type),
              //         value: model,
              //       );
              //     }).toList(),
              //     value: _productSubCategory,
              //     underline: Container(),
              //     hint: "Search...",
              //     searchHint: "Search...",
              //     onChanged: (value) {
              //       Navigator.pop(context);
              //       setState(() {
              //         _productSubCategory = value;
              //       });
              //     },
              //     isExpanded: true,
              //   ),
              // ),
              Expanded(
                child: Container(
                  child: ListView.builder(
                    shrinkWrap: true,
                    itemBuilder: (context, index) {
                      return InkWell(
                        onTap: () {
                          Navigator.of(context).pop();
                          setState(() {
                            _productSubCategory = productSubCategories[index];
                          });
                        },
                        child: Container(
                          margin: EdgeInsets.symmetric(
                            horizontal: 5.0,
                            vertical: 2.0,
                          ),
                          padding: EdgeInsets.all(8.0),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5.0),
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                    offset: Offset(0.0, 1.0),
                                    blurRadius: 2.5,
                                    color: Colors.grey)
                              ]),
                          alignment: Alignment.centerLeft,
                          child: Text("${productSubCategories[index].type}",
                              textAlign: TextAlign.start),
                        ),
                      );
                    },
                    itemCount: productSubCategories.length,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  buildDropDownCategory(String _title) {
    return Container(
        child: Column(children: <Widget>[
      Container(
          padding: EdgeInsets.all(1),
          child: Row(
            children: <Widget>[
              Expanded(
                child: Container(
                    height: 50,
                    color: Color(Constants.GREY_COLOR_LIGHT),
                    child: Container(
                      padding: EdgeInsets.only(left: 10),
                      child: Align(
                          alignment: Alignment.centerLeft,
                          child: RichText(
                            text: TextSpan(children: [
                              TextSpan(
                                text:
                                    Language().getString(_title, selectedLang),
                                style: TextStyle(
                                    fontSize: StyleView.FONT_SIZE_15,
                                    fontFamily: StyleView.FONT_TITLE,
                                    color: Colors.black),
                              ),
                            ]),
                          )),
                    )),
              ),
              Expanded(
                flex: 2,
                child: Container(
                  height: 50.0,
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5, right: 5),
                  child: InkWell(
                    onTap: () {
                      FocusScope.of(context).unfocus();
                      if (productCategories.length > 0) {
                        this.showProductCategorieData();
                      } else {
                        print("Product categorie Data Loading");
                      }
                    },
                    child: Container(
                        height: 50,
                        color: Colors.white70,
                        padding: EdgeInsets.only(left: 5, right: 5),
                        child: Row(
                          children: [
                            Expanded(
                              flex: 4,
                              child: Container(
                                child: Text((_productCategory == null)
                                    ? Language().getString(
                                        Constants.SELECT_CATEGORY, selectedLang)
                                    : _productCategory!.type!),
                              ),
                            ),
                            Expanded(
                              child: Container(
                                child: Icon(Icons.expand_more),
                              ),
                            ),
                          ],
                        )),
                  ),
                ),
              )
            ],
          ))
    ]));
  }

  showProductCategorieData() {
    return showDialog(
      context: context,
      builder: (context) => AlertDialog(
        contentPadding: EdgeInsets.fromLTRB(0.0, 24.0, 0.0, 24.0),
        content: Container(
          child: Column(
            children: [
              // Container(
              //   margin: EdgeInsets.symmetric(horizontal: 5.0, vertical: 5.0),
              //   decoration: AppUtills.boxDecoration(),
              //   child: SearchableDropdown.single(
              //     items: productCategories.map((ProductCategoryDAO model) {
              //       return new DropdownMenuItem<ProductCategoryDAO>(
              //         child: new Text(model.type),
              //         value: model,
              //       );
              //     }).toList(),
              //     value: _productCategory,
              //     underline: Container(),
              //     hint: "Search...",
              //     searchHint: "Search...",
              //     onChanged: (value) {
              //       Navigator.pop(context);
              //       setState(() {
              //         _productCategory = value;

              //         /// Clearing Product Sun Categorie Values
              //         productSubCategories.clear();
              //         _productSubCategory = null;
              //       });
              //       loadProductSubCategory(_productCategory.code);
              //     },
              //     isExpanded: true,
              //   ),
              // ),
              Expanded(
                child: Container(
                    child: ListView.builder(
                  shrinkWrap: true,
                  itemBuilder: (context, index) {
                    return InkWell(
                      onTap: () {
                        Navigator.of(context).pop();
                        setState(() {
                          _productCategory = productCategories[index];

                          /// Clearing Product Sun Categorie Values
                          productSubCategories.clear();
                          _productSubCategory = null;
                        });
                        loadProductSubCategory(_productCategory!.code!);
                      },
                      child: Container(
                        margin: EdgeInsets.symmetric(
                          horizontal: 5.0,
                          vertical: 2.0,
                        ),
                        padding: EdgeInsets.all(8.0),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(5.0),
                            color: Colors.white,
                            boxShadow: [
                              BoxShadow(
                                  offset: Offset(0.0, 1.0),
                                  blurRadius: 2.5,
                                  color: Colors.grey)
                            ]),
                        alignment: Alignment.centerLeft,
                        child: Text("${productCategories[index].type}",
                            textAlign: TextAlign.start),
                      ),
                    );
                  },
                  itemCount: productCategories.length,
                )),
              )
            ],
          ),
        ),
      ),
    );
  }

  addNewAttribute() {
    return SizedBox(
        height: 25.0,
        width: 25.0,
        child: FloatingActionButton(
          onPressed: () {
            FocusScope.of(context).unfocus();

            buildAttributeFieldsTable(new ProductAttributeModel(), -1, false);
          },
          child: Icon(
            Icons.add,
            size: 15,
          ),
          backgroundColor: Color(0xFF083e64),
        ));
  }

  addNewInventory() {
    return SizedBox(
        height: 25.0,
        width: 25.0,
        child: FloatingActionButton(
          heroTag: "bt1",
          onPressed: () {
            FocusScope.of(context).unfocus();
            buildInventoryFieldsTable(
                new InventoryManagementModel(), -1, false);
          },
          child: Icon(
            Icons.add,
            size: 15,
          ),
          backgroundColor: Color(0xFF083e64),
        ));
  }

  buildInventoryFieldsTable(
    InventoryManagementModel _inventoryData,
    int index,
    bool isUpdateInventory,
  ) {
    if (isUpdateInventory) {
      quantityForUpdate = _inventoryData.quantity;
      locationDropdownValue = locationsList[index];
      _locationQuantityController.text = _inventoryData.quantity.toString();
      for (int i = 0; i < _priceList.length; i++) {
        if (_inventoryData.batchNumber == _priceList[i].batchNumber) {
          inventoryQuantityDropdown = _priceList[i];
          remainingBatchQuantity = _priceList[i].quantity;
        }
      }
    } else {
      locationDropdownValue = null;
      _locationQuantityController.clear();
      inventoryQuantityDropdown = null;
      remainingBatchQuantity = "0";
    }

    return showDialog(
        barrierDismissible: false,
        context: context,
        barrierColor: Colors.black54,
        builder: (BuildContext context) {
          return AlertDialog(
              elevation: 100.0,
              backgroundColor: Color(0XFFE0E0E0),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(
                  Radius.circular(
                    7.0,
                  ),
                ),
              ),
              title: Text(
                Language().getString(
                    isUpdateInventory
                        ? Constants.UPDATE_INVENTORY
                        : Constants.ADD_INVENTORY,
                    selectedLang),
                style: TextStyle(
                    fontSize: StyleView.FONT_SIZE_18,
                    fontFamily: StyleView.FONT_TITLE,
                    color: Color(Constants.APP_COLOR)),
              ),
              titlePadding: dialogTitlePadding,
              content: StatefulBuilder(
                  builder: (BuildContext context, StateSetter setState) {
                return Container(
                  margin: EdgeInsets.symmetric(
                    vertical: 5.0,
                  ),
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        new Text(Language()
                            .getString(Constants.LOCATION, selectedLang)),
                        SizedBox(height: 5.0),
                        this.inventoryLocations(setState),
                        Container(
                            child: Row(
                          children: <Widget>[
                            new Text(Language()
                                .getString(Constants.BATCH_NO, selectedLang)),
                            SizedBox(
                              width: 3.0,
                            ),
                            Text(
                                Language().getString(
                                        Constants.TOTAL_QUANTITY_STRING,
                                        selectedLang) +
                                    " : $remainingBatchQuantity",
                                style: TextStyle(
                                    fontSize: 10.0,
                                    color: Colors.deepOrange[300]))
                          ],
                        )),
                        this.inventoryBatchQuantity(setState),
                        new Text(Language()
                            .getString(Constants.QUANTITY, selectedLang)),
                        SizedBox(height: 5.0),
                        SizedBox(
                          height: 70,
                          child: new TextFormField(
                              keyboardType: TextInputType.number,
                              style:
                                  TextStyle(fontFamily: StyleView.FONT_TITLE),
                              controller: _locationQuantityController,
                              decoration: StyleView.getInputDecoration(
                                  helper: Language().getString(
                                      Constants.ENTER_QUANTITY, selectedLang)),
                              inputFormatters: [
                                new LengthLimitingTextInputFormatter(6),
                                CommonMethods.inputTextFormatter(isNumber: true)
                              ]),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            TextButton(
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                              child: Text(
                                Language().getString(
                                    Constants.STR_CANCEL, selectedLang),
                                style: TextStyle(
                                    color: Color(Constants.APP_COLOR),
                                    fontFamily: StyleView.FONT_TITLE),
                              ),
                            ),
                            TextButton(
                              onPressed: () {
                                String errorMessage =
                                    this.validateInventoryFields();

                                if (errorMessage.isNotEmpty) {
                                  Dialogs.yesCancelDialog(
                                      context,
                                      Language().getString(
                                          Constants.ERROR, selectedLang),
                                      errorMessage,
                                      Language().getString(
                                          Constants.OKAY_STR, selectedLang),
                                      "",
                                      false);
                                } else {
                                  if (int.parse(
                                          _locationQuantityController.text) >
                                      int.parse(inventoryQuantityDropdown!
                                          .quantity!)) {
                                    Dialogs.yesCancelDialog(
                                        context,
                                        Language().getString(
                                            Constants.ERROR, selectedLang),
                                        Language().getString(
                                            Constants.INVALID_QUANTITY,
                                            selectedLang),
                                        Language().getString(
                                            Constants.OKAY_STR, selectedLang),
                                        "",
                                        false);
                                  } else {
                                    setState(() {
                                      isLoadingProgress = true;
                                      progressMessage = "Updating quantity";
                                    });

                                    this.updatingBatchQuantity(
                                        index, isUpdateInventory, setState);
                                  }
                                }
                              },
                              child: Text(
                                Language().getString(
                                    Constants.STR_SAVE, selectedLang),
                                style: TextStyle(
                                    color: Color(Constants.APP_COLOR),
                                    fontFamily: StyleView.FONT_TITLE),
                              ),
                            )
                          ],
                        )
                      ],
                    ),
                  ),
                );
              }));
        });
  }

  validatingSelectedBatchQuantity(setState) {
    num priceQuanity = 0;
    num enteredQuantity = int.parse(_locationQuantityController.text);
    for (int i = 0; i < _priceList.length; i++) {
      if (inventoryQuantityDropdown!.batchNumber == _priceList[i].batchNumber) {
        setState(() {
          priceQuanity = int.parse(_priceList[i].quantity!);
          _priceList[i].quantity = (priceQuanity - enteredQuantity).toString();
          isLoadingProgress = false;
        });
      }
    }
  }

  updatingBatchQuantity(
      int index, bool isUpdateInventory, StateSetter setState) {
    if (isUpdateInventory) {
      if (quantityForUpdate! < int.parse(_locationQuantityController.text)) {
        this.validatingSelectedBatchQuantity(setState);
      } else {
        num priceQuanity = 0;
        num enteredQuantity = int.parse(_locationQuantityController.text);
        for (int i = 0; i < _priceList.length; i++) {
          if (inventoryQuantityDropdown!.batchNumber ==
              _priceList[i].batchNumber) {
            setState(() {
              priceQuanity = quantityForUpdate! - enteredQuantity;
              _priceList[i].quantity =
                  (priceQuanity + int.parse(_priceList[i].quantity!))
                      .toString();
              isLoadingProgress = false;
            });
          }
        }
      }
    } else {
      if (inventoryQuantityDropdown != null) {
        this.validatingSelectedBatchQuantity(setState);
      }
    }

    this.onSaveInventoryDetails(isUpdateInventory, index);
  }

  Widget inventoryLocations(StateSetter setState) {
    return Container(
        margin: EdgeInsets.symmetric(
          vertical: 5.0,
        ),
        decoration: AppUtills.boxDecoration(),
        padding: EdgeInsets.all(1),
        child: Container(
            color: Colors.white70,
            padding: EdgeInsets.only(left: 5, right: 5),
            child: DropdownButton<Locations>(
                onTap: () {
                  FocusScope.of(context).unfocus();
                },
                isExpanded: true,
                hint: Text(
                    Language().getString(Constants.LOCATION, selectedLang)),
                underline: SizedBox(),
                items: locationsList.map((Locations locationData) {
                  return DropdownMenuItem<Locations>(
                    value: locationData,
                    child: new Text(
                      locationData.locationName!,
                      style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                    ),
                  );
                }).toList(),
                value: locationDropdownValue,
                onChanged: (Locations? location) {
                  setState(() {
                    locationDropdownValue = location;
                  });
                })));
  }

  Widget inventoryBatchQuantity(StateSetter setState) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 5.0),
      decoration: AppUtills.boxDecoration(),
      padding: EdgeInsets.all(1),
      child: DropdownButton<PriceModel>(
        onTap: () {
          FocusScope.of(context).unfocus();
        },
        isExpanded: true,
        hint: Text(Language().getString(Constants.BATCH_NO, selectedLang)),
        underline: SizedBox(),
        items: _priceList.map((PriceModel batchPrice) {
          return DropdownMenuItem<PriceModel>(
            value: batchPrice,
            child: new Text(
              batchPrice.batchNumber!,
              style: TextStyle(fontFamily: StyleView.FONT_TITLE),
            ),
          );
        }).toList(),
        value: inventoryQuantityDropdown,
        onChanged: (PriceModel? model) {
          setState(() {
            inventoryQuantityDropdown = model;
            remainingBatchQuantity = model!.quantity;
          });
        },
      ),
    );
  }

  String validateInventoryFields() {
    if (locationDropdownValue == null) {
      return "Please select location";
    } else {
      return "";
    }
  }

  buildAttributeFieldsTable(
    ProductAttributeModel _attributesData,
    int index,
    bool isUpdateAttribute,
  ) {
    if (isUpdateAttribute) {
      _attributeKeyController.text = _attributesData.attributeKey!;
      _attributeValueController.text = _attributesData.attributeValue!;
    } else {
      _attributeKeyController.clear();
      _attributeValueController.clear();
    }

    return showDialog(
        barrierDismissible: false,
        context: context,
        barrierColor: Colors.black54,
        builder: (BuildContext context) {
          return AlertDialog(
            elevation: 100.0,
            contentPadding: EdgeInsets.fromLTRB(15.0, 0, 15.0, 0),
            backgroundColor: Color(0XFFE0E0E0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(
                Radius.circular(
                  7.0,
                ),
              ),
            ),
            title: Text(
              Language().getString(Constants.ADD_NEW_FEATURE, selectedLang),
              style: TextStyle(
                fontSize: StyleView.FONT_SIZE_18,
                fontFamily: StyleView.FONT_TITLE,
                color: Color(Constants.APP_COLOR),
              ),
            ),
            titlePadding: dialogTitlePadding,
            content: Container(
              margin: EdgeInsets.symmetric(
                vertical: 5.0,
              ),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    new Text(Language()
                        .getString(Constants.FEATURE_NAME, selectedLang)),
                    SizedBox(height: 5.0),
                    buildTextFormFieldsDialog(
                      Language()
                          .getString(Constants.FEATURE_NAME, selectedLang),
                      _attributeKeyController,
                    ),
                    new Text(Language()
                        .getString(Constants.FEATURE_DETAILS, selectedLang)),
                    SizedBox(height: 5.0),
                    buildTextFormFieldsDialog(
                      Language()
                          .getString(Constants.FEATURE_DETAILS, selectedLang),
                      _attributeValueController,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        TextButton(
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                          child: Text(
                            Language()
                                .getString(Constants.STR_CANCEL, selectedLang),
                            style: TextStyle(
                                color: Color(Constants.APP_COLOR),
                                fontFamily: StyleView.FONT_TITLE),
                          ),
                        ),
                        TextButton(
                          onPressed: () {
                            onSaveAttributeDetails(isUpdateAttribute, index);
                          },
                          child: Text(
                            Language()
                                .getString(Constants.STR_SAVE, selectedLang),
                            style: TextStyle(
                                color: Color(Constants.APP_COLOR),
                                fontFamily: StyleView.FONT_TITLE),
                          ),
                        )
                      ],
                    )
                  ],
                ),
              ),
            ),
          );
        });
  }

  buildTextFormFieldsDialog(
    String? _labelText,
    TextEditingController controller,
  ) {
    return SizedBox(
        height: 70,
        child: new TextFormField(
            style: TextStyle(fontFamily: StyleView.FONT_TITLE),
            controller: controller,
            decoration: StyleView.getInputDecoration(
              helper: _labelText,
            ),
            onChanged: (text) => {}));
  }

  onSaveAttributeDetails(bool isUpdateAttribute, int index) {
    if (isUpdateAttribute) {
      attributesList[index] = ProductAttributeModel(
          attributeValue: _attributeValueController.text,
          attributeKey: _attributeKeyController.text);
      setState(() {
        attributesList.reversed;
      });
      Navigator.of(context).pop();
        } else {
      attributesList.add(ProductAttributeModel(
          attributeValue: _attributeValueController.text,
          attributeKey: _attributeKeyController.text));
      setState(() {
        attributesList.reversed;
      });
      Navigator.of(context).pop();
        }
  }

  onSaveInventoryDetails(bool isUpdateInventory, int index) {
    if (isUpdateInventory) {
      if (locationDropdownValue != null && inventoryQuantityDropdown != null) {
        inventoryList[index] = InventoryManagementModel(
            locationName: locationDropdownValue!.locationName,
            quantity: int.parse(_locationQuantityController.text),
            batchNumber: inventoryQuantityDropdown!.batchNumber);
        setState(() {
          inventoryList.reversed;
        });
        Navigator.of(context).pop();
      } else {
        Navigator.of(context).pop();
      }
    } else {
      if (locationDropdownValue != null && inventoryQuantityDropdown != null) {
        bool isExistLocationName = false;
        int existIndex = -1;
        for (int i = 0; i < inventoryList.length; i++) {
          if (locationDropdownValue!.locationName ==
              inventoryList[i].locationName) {
            isExistLocationName = true;
            existIndex = i;
          }
        }

        if (isExistLocationName) {
          int updateQuantity = inventoryList[existIndex].quantity! +
              int.parse(_locationQuantityController.text) as int;
          inventoryList[existIndex] = InventoryManagementModel(
              locationName: locationDropdownValue!.locationName,
              quantity: updateQuantity,
              batchNumber: inventoryQuantityDropdown!.batchNumber);
        } else {
          inventoryList.add(InventoryManagementModel(
              locationName: locationDropdownValue!.locationName,
              quantity: int.parse(_locationQuantityController.text),
              batchNumber: inventoryQuantityDropdown!.batchNumber));
        }

        setState(() {
          inventoryList.reversed;
        });
        Navigator.of(context).pop();
      } else {
        Navigator.of(context).pop();
      }
    }
  }

  Widget onCreateDynamicAttributes() {
    return Column(children: <Widget>[
      for (int i = 0; i < attributesList.length; i++)
        Container(
          margin: EdgeInsets.symmetric(
            vertical: 5.0,
          ),
          child: Column(
            children: <Widget>[
              AttributeExpandedPage(
                attributeKey: attributesList[i].attributeKey,
                attributeValue: attributesList[i].attributeValue,
                editPage: () {
                  buildAttributeFieldsTable(attributesList[i], i, true);
                },
                removeItem: () async {
                  final action = await Dialogs.removeItem(
                    context,
                    attributesList[i].attributeKey,
                    Language().getString(Constants.WARNING, selectedLang),
                    Language().getString(Constants.WARNING_TEXT, selectedLang),
                    cancel: Language()
                        .getString(Constants.STR_CANCEL, selectedLang),
                    yes: Language()
                        .getString(Constants.YES_STRING, selectedLang),
                  );
                  if (action == DialogAction.yes) {
                    setState(() {
                      attributesList.removeAt(i);
                    });
                  }
                },
              ),
            ],
          ),
        )
    ]);
  }

  Widget createPriceDetailsDynamic() {
    return Column(children: <Widget>[
      for (int i = 0; i < _priceList.length; i++) this.showPriceExpandView(i)
    ]);
  }

  Widget showPriceExpandView(int index) {
    return Container(
      margin: EdgeInsets.symmetric(
        vertical: 5.0,
      ),
      child: Column(
        children: <Widget>[
          PriceDetailsExpandPage(
            priceModel: _priceList[index],
            strQuantity: Constants.QUANTITY,
            strQuantityIn: Constants.QUANTITY_IN,
            strBatchNumber: Constants.BATCH_NO,
            strCurrencyName: Constants.CURRENCY_NAME,
            strExpireDate: Constants.EXPIRE_DATE_STR,
            strManufactureDate: Constants.MANUFACTURE_DATE,
            strMrp: Constants.MRP,
            strNetRate: Constants.NET_RATE,
            strPrice: Constants.PRICE,
            strUnitPrice: Constants.PRICE_UNIT,
            title: _priceList[index].batchNumber,
            isEdit: true,
            editPage: () {
              priceFieldsPopup(_priceList[index], index, true);
            },
            removeItem: () async {
              final action = await Dialogs.removeItem(
                context,
                " ${_priceList[index].batchNumber}",
                Language().getString(Constants.WARNING, selectedLang),
                Language().getString(Constants.WARNING_TEXT, selectedLang),
                cancel:
                    Language().getString(Constants.STR_CANCEL, selectedLang),
                yes: Language().getString(Constants.YES_STRING, selectedLang),
              );
              if (action == DialogAction.yes) {
                setState(() {
                  _priceList.removeAt(index);
                });
              }
            },
          ),
        ],
      ),
    );
  }

  Widget onCreateDynamicInventory() {
    return Column(children: <Widget>[
      for (int i = 0; i < inventoryList.length; i++)
        Container(
          margin: EdgeInsets.symmetric(
            vertical: 5.0,
          ),
          child: Column(children: <Widget>[
            InventoryExpandedPage(
              title: Language().getString(Constants.LOCATION, selectedLang) +
                  " : ${inventoryList[i].locationName}",
              managementModel: inventoryList[i],
              editPage: () {
                buildInventoryFieldsTable(inventoryList[i], i, true);
              },
              strBatchNumber:
                  Language().getString(Constants.BATCH_NO, selectedLang),
              strLocation:
                  Language().getString(Constants.LOCATION, selectedLang),
              strTotalAtLocation: Language()
                  .getString(Constants.TOTAL_AT_LOCATION, selectedLang),
              removeItem: () async {
                final action = await Dialogs.removeItem(
                  context,
                  inventoryList[i].locationName,
                  Language().getString(Constants.WARNING, selectedLang),
                  Language().getString(Constants.WARNING_TEXT, selectedLang),
                  cancel:
                      Language().getString(Constants.STR_CANCEL, selectedLang),
                  yes: Language().getString(Constants.YES_STRING, selectedLang),
                );
                if (action == DialogAction.yes) {
                  for (int i = 0; i < _priceList.length; i++) {
                    if (inventoryList[i].batchNumber ==
                        _priceList[i].batchNumber) {
                      setState(() {
                        _priceList[i].quantity =
                            (int.parse(_priceList[i].quantity!) +
                                    inventoryList[i].quantity!)
                                .toString();
                        inventoryList.removeAt(i);
                      });
                    }
                  }
                }
              },
            )
          ]),
        ),
    ]);
  }

  buildHeightView(String title, String value) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      Language().getString(title, selectedLang),
                      style: TextStyle(
                          fontSize: StyleView.FONT_SIZE_15,
                          fontFamily: StyleView.FONT_TITLE,
                          color: Colors.black),
                    )),
              )),
        ),
        Expanded(
            flex: 2,
            child: Container(
              color: Colors.grey,
              child: Row(children: <Widget>[
                Expanded(
                    child: Container(
                  padding: EdgeInsets.only(left: 5),
                  margin: EdgeInsets.only(right: 1),
                  color: Colors.white,
                  child: TextField(
                    keyboardType: TextInputType.number,
                    controller: _heightController,
                    style: TextStyle(fontFamily: 'IndianRupee'),
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: Language().getString(title, selectedLang),
                    ),
                  ),
                )),
                Expanded(
                    child: Container(
                        color: Colors.white,
                        padding: EdgeInsets.only(left: 5),
                        child: DropdownButton<String>(
                            onTap: () {
                              FocusScope.of(context).unfocus();
                            },
                            value: heightDropdownValue,
                            hint: new Text(
                              Language()
                                  .getString(Constants.SELECT, selectedLang),
                            ),
                            isExpanded: true,
                            underline: SizedBox(),
                            onChanged: (String? data) {
                              setState(() {
                                heightDropdownValue = data;
                              });
                            },
                            items:
                                Constants.measurementsList.map((String model) {
                              return new DropdownMenuItem<String>(
                                child: new Text(model),
                                value: model,
                              );
                            }).toList()))),
              ]),
            ))
      ],
    );
  }

  buildDepthView(String title, String value) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      Language().getString(title, selectedLang),
                      style: TextStyle(
                          fontSize: StyleView.FONT_SIZE_15,
                          fontFamily: StyleView.FONT_TITLE,
                          color: Colors.black),
                    )),
              )),
        ),
        Expanded(
            flex: 2,
            child: Container(
              color: Colors.grey,
              child: Row(children: <Widget>[
                Expanded(
                    child: Container(
                  padding: EdgeInsets.only(left: 5),
                  margin: EdgeInsets.only(right: 1),
                  color: Colors.white,
                  child: TextField(
                    keyboardType: TextInputType.number,
                    controller: _depthController,
                    style: TextStyle(fontFamily: 'IndianRupee'),
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: Language().getString(title, selectedLang),
                    ),
                  ),
                )),
                Expanded(
                    child: Container(
                        color: Colors.white,
                        padding: EdgeInsets.only(left: 5),
                        child: DropdownButton<String>(
                            onTap: () {
                              FocusScope.of(context).unfocus();
                            },
                            value: depthDropdownValue,
                            hint: new Text(
                              Language()
                                  .getString(Constants.SELECT, selectedLang),
                            ),
                            isExpanded: true,
                            underline: SizedBox(),
                            onChanged: (String? data) {
                              setState(() {
                                depthDropdownValue = data;
                              });
                            },
                            items:
                                Constants.measurementsList.map((String model) {
                              return new DropdownMenuItem<String>(
                                child: new Text(model),
                                value: model,
                              );
                            }).toList()))),
              ]),
            ))
      ],
    );
  }

  buildVolumeView(String title, String value) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      Language().getString(title, selectedLang),
                      style: TextStyle(
                          fontSize: StyleView.FONT_SIZE_15,
                          fontFamily: StyleView.FONT_TITLE,
                          color: Colors.black),
                    )),
              )),
        ),
        Expanded(
            flex: 2,
            child: Container(
              color: Colors.grey,
              child: Row(children: <Widget>[
                Expanded(
                    child: Container(
                  padding: EdgeInsets.only(left: 5),
                  margin: EdgeInsets.only(right: 1),
                  color: Colors.white,
                  child: TextField(
                    keyboardType: TextInputType.number,
                    controller: volumeController,
                    style: TextStyle(fontFamily: 'IndianRupee'),
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: Language().getString(title, selectedLang),
                    ),
                  ),
                )),
                Expanded(
                    child: Container(
                        color: Colors.white,
                        padding: EdgeInsets.only(left: 5),
                        child: DropdownButton<String>(
                            onTap: () {
                              FocusScope.of(context).unfocus();
                            },
                            value: volumeDropdownValue,
                            hint: new Text(
                              Language()
                                  .getString(Constants.SELECT, selectedLang),
                            ),
                            isExpanded: true,
                            underline: SizedBox(),
                            onChanged: (String? data) {
                              setState(() {
                                volumeDropdownValue = data;
                              });
                            },
                            items: Constants.volumeMeasurementsList
                                .map((String model) {
                              return new DropdownMenuItem<String>(
                                child: new Text(model),
                                value: model,
                              );
                            }).toList()))),
              ]),
            ))
      ],
    );
  }

  buildWeightView(String title, String value) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      Language().getString(title, selectedLang),
                      style: TextStyle(
                          fontSize: StyleView.FONT_SIZE_15,
                          fontFamily: StyleView.FONT_TITLE,
                          color: Colors.black),
                    )),
              )),
        ),
        Expanded(
            flex: 2,
            child: Container(
              color: Colors.grey,
              child: Row(children: <Widget>[
                Expanded(
                    child: Container(
                  padding: EdgeInsets.only(left: 5),
                  margin: EdgeInsets.only(right: 1),
                  color: Colors.white,
                  child: TextField(
                    keyboardType: TextInputType.number,
                    controller: _weightController,
                    style: TextStyle(fontFamily: 'IndianRupee'),
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: Language().getString(title, selectedLang),
                    ),
                  ),
                )),
                Expanded(
                    child: Container(
                        color: Colors.white,
                        padding: EdgeInsets.only(left: 5),
                        child: DropdownButton<String>(
                            onTap: () {
                              FocusScope.of(context).unfocus();
                            },
                            value: weightDropdownValue,
                            hint: new Text(
                              Language()
                                  .getString(Constants.SELECT, selectedLang),
                            ),
                            isExpanded: true,
                            underline: SizedBox(),
                            onChanged: (String? data) {
                              setState(() {
                                weightDropdownValue = data;
                              });
                            },
                            items: Constants.weightMeasurementsList
                                .map((String model) {
                              return new DropdownMenuItem<String>(
                                child: new Text(model),
                                value: model,
                              );
                            }).toList()))),
              ]),
            ))
      ],
    );
  }

  buildWidthView(String title, String value) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      Language().getString(title, selectedLang),
                      style: TextStyle(
                          fontSize: StyleView.FONT_SIZE_15,
                          fontFamily: StyleView.FONT_TITLE,
                          color: Colors.black),
                    )),
              )),
        ),
        Expanded(
            flex: 2,
            child: Container(
              color: Colors.grey,
              child: Row(children: <Widget>[
                Expanded(
                    child: Container(
                  padding: EdgeInsets.only(left: 5),
                  margin: EdgeInsets.only(right: 1),
                  color: Colors.white,
                  child: TextField(
                    keyboardType: TextInputType.number,
                    controller: _widthController,
                    style: TextStyle(fontFamily: 'IndianRupee'),
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: Language().getString(title, selectedLang),
                    ),
                  ),
                )),
                Expanded(
                    child: Container(
                        color: Colors.white,
                        padding: EdgeInsets.only(left: 5),
                        child: DropdownButton<String>(
                            onTap: () {
                              FocusScope.of(context).unfocus();
                            },
                            value: widthDropdownValue,
                            hint: new Text(
                              Language()
                                  .getString(Constants.SELECT, selectedLang),
                            ),
                            isExpanded: true,
                            underline: SizedBox(),
                            onChanged: (String? data) {
                              setState(() {
                                widthDropdownValue = data;
                              });
                            },
                            items:
                                Constants.measurementsList.map((String model) {
                              return new DropdownMenuItem<String>(
                                child: new Text(model),
                                value: model,
                              );
                            }).toList()))),
              ]),
            ))
      ],
    );
  }

  consumableProductRadioButtonView() {
    return Row(
      children: [
        Radio(
          value: Constants.YES_STRING,
          activeColor: Color(Constants.APP_COLOR),
          groupValue: consumableProductRadioValue,
          onChanged: (dynamic value) {
            setState(() {
              consumableProductRadioValue = Constants.YES_STRING;
            });
          },
        ),
        Text(Language().getString(Constants.YES_STRING, selectedLang)),
        Radio(
          value: Constants.NO_STRING,
          activeColor: Color(Constants.APP_COLOR),
          groupValue: consumableProductRadioValue,
          onChanged: (dynamic value) {
            setState(() {
              consumableProductRadioValue = Constants.YES_STRING;
            });
          },
        ),
        Text(
          Language().getString(Constants.NO_STRING, selectedLang),
        ),
      ],
    );
  }

  validatingItemDetails() {
    if (_heightController.text.isNotEmpty && heightDropdownValue == null) {
      return Constants.PLEASE_SELECT_HEIGHT;
    } else if (heightDropdownValue != null && _heightController.text.isEmpty) {
      return Constants.PLEASE_ENTER_HEIGHT;
    } else if (volumeController.text.isEmpty && volumeDropdownValue != null) {
      return Constants.PLEASE_ENTER_VOLUM;
    } else if (volumeController.text.isNotEmpty &&
        volumeDropdownValue == null) {
      return Constants.PLEASE_SELECT_VOLUM;
    } else if (_weightController.text.isEmpty && weightDropdownValue != null) {
      return Constants.PLEASE_ENTER_WEIGHT;
    } else if (_weightController.text.isNotEmpty &&
        weightDropdownValue == null) {
      return Constants.PLEASE_SELECT_WEIGHT;
    } else if (_widthController.text.isEmpty && widthDropdownValue != null) {
      return Constants.PLEASE_ENTER_WIDTH;
    } else if (_widthController.text.isNotEmpty && widthDropdownValue == null) {
      return Constants.PLEASE_SELECT_WIDTH;
    } else if (_depthController.text.isEmpty && depthDropdownValue != null) {
      return Constants.PLEASE_ENTER_DEPTH;
    } else if (_depthController.text.isNotEmpty && depthDropdownValue == null) {
      return Constants.PLEASE_SELECT_DEPTH;
    } else {
      return "";
    }
  }

  loadProductCategories(int parentCode) async {
    if (!isLoadingProgress) {
      setState(() {
        isLoadingProgress = true;
      });
    }

    getProductCategories(parentCode).then((categoryList) {
      setState(() {
        productCategories.addAll(categoryList);
      });
    });
  }

  loadProductSubCategory(int parentCode) async {
    getProductSubCategories(parentCode).then((subCategoryList) {
      setState(() {
        productSubCategories.addAll(subCategoryList);
      });
    });
  }

  Widget priceDetailsView() {
    return Container(
      child: Column(
        children: [
          Container(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                this.buildTextField(Language()
                    .getString(Constants.PRICE_DETAILS, selectedLang)),
                SizedBox(
                    height: 25.0,
                    width: 25.0,
                    child: FloatingActionButton(
                      heroTag: null,
                      onPressed: () {
                        FocusScope.of(context).unfocus();

                        this.priceFieldsPopup(new PriceModel(), -1, false);
                      },
                      child: Icon(
                        Icons.add,
                        size: 15,
                      ),
                      backgroundColor: Color(0xFF083e64),
                    ))
              ],
            ),
          )
        ],
      ),
    );
  }

  priceFieldsPopup(
      PriceModel priceModel, int index, bool isPriceDetailsUpdate) {
    if (isPriceDetailsUpdate) {
      this.updatePriceDetialsData(priceModel);
    } else {
      this.clearPriceData();
    }

    return showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) =>
            StatefulBuilder(builder: (context, StateSetter setState) {
              return Container(
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(
                        Radius.circular(10.0),
                      ),
                      color: Colors.white),
                  margin:
                      EdgeInsets.symmetric(horizontal: 10.0, vertical: 20.0),
                  child: Scaffold(
                    backgroundColor: Colors.transparent,
                    bottomNavigationBar: Container(
                      margin: EdgeInsets.symmetric(
                        horizontal: 5.0,
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Container(
                              margin: EdgeInsets.only(right: 1.0),
                              child: ElevatedButton(
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                                style: ElevatedButton.styleFrom(
                                    backgroundColor:
                                        Color(Constants.APP_COLOR)),
                                child: Text(
                                    Language().getString(
                                        Constants.STR_CANCEL, selectedLang),
                                    style: TextStyle(color: Colors.white)),
                              ),
                            ),
                          ),
                          Expanded(
                            child: Container(
                              margin: EdgeInsets.only(left: 1.0),
                              child: ElevatedButton(
                                onPressed: () {
                                  String errorMessage =
                                      validatePriceMandatoryFields();

                                  if (errorMessage.isNotEmpty) {
                                    Dialogs.yesCancelDialog(
                                        context,
                                        Language().getString(
                                            Constants.ERROR, selectedLang),
                                        Language().getString(
                                            errorMessage, selectedLang),
                                        Language().getString(
                                            Constants.OKAY_STR, selectedLang),
                                        "",
                                        false);
                                  } else {
                                    this.onSavePriceDetails(
                                        index, isPriceDetailsUpdate);
                                  }
                                },
                                style: ElevatedButton.styleFrom(
                                    backgroundColor:
                                        Color(Constants.APP_COLOR)),
                                child: Text(
                                    (isPriceDetailsUpdate)
                                        ? Language().getString(
                                            Constants.UPDATE_STRING,
                                            selectedLang)
                                        : Language().getString(
                                            Constants.ADD, selectedLang),
                                    style: TextStyle(color: Colors.white)),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                    body: SingleChildScrollView(
                      child: Container(
                        decoration: AppUtills.boxDecoration(),
                        margin: EdgeInsets.symmetric(
                            vertical: 5.0, horizontal: 5.0),
                        child: Column(
                          children: [
                            this.buildQuantityView(
                                Language().getString(
                                    Constants.QUANTITY, selectedLang),
                                setState),
                            SizedBox(
                              height: 1,
                              child: new Container(
                                  color: Color(Constants.GREY_COLOR)),
                            ),
                            this.buildDateFieldManufacture(
                                Constants.MANUFACTURE_DATE, setState),
                            SizedBox(
                              height: 1,
                              child: new Container(
                                  color: Color(Constants.GREY_COLOR)),
                            ),
                            this.buildDateFieldExpaire(
                                Constants.EXPIRE_DATE_STR, setState),
                            SizedBox(
                              height: 1,
                              child: new Container(
                                  color: Color(Constants.GREY_COLOR)),
                            ),
                            this.buildTableContent(Constants.BATCH_NO,
                                _batchNumController, false, false),
                            SizedBox(
                              height: 1,
                              child: new Container(
                                  color: Color(Constants.GREY_COLOR)),
                            ),
                            this.priceInputFieldView(),
                            SizedBox(
                              height: 1,
                              child: new Container(
                                  color: Color(Constants.GREY_COLOR)),
                            ),
                            this.buildTableContent(Constants.NET_RATE,
                                _netRateController, true, true),
                            SizedBox(
                              height: 1,
                              child: new Container(
                                  color: Color(Constants.GREY_COLOR)),
                            ),
                            this.buildTableContent(
                                Constants.MRP, _mrpController, true, true),
                            SizedBox(
                              height: 1,
                              child: new Container(
                                  color: Color(Constants.GREY_COLOR)),
                            ),
                            this.buildUnitDropdown(
                                Constants.PRICE_UNIT, setState),
                            SizedBox(
                              height: 1,
                              child: new Container(
                                  color: Color(Constants.GREY_COLOR)),
                            ),
                            this.buildDropDownCurrencyName(
                                Constants.CURRENCY_NAME, setState),
                          ],
                        ),
                      ),
                    ),
                  ));
            }));
  }

  String validatePriceMandatoryFields() {
    if (_qntyController.text.isEmpty) {
      return Constants.PLEASE_ENTER_QUANTITY;
    } else if (_priceController.text.isEmpty) {
      return Constants.PLEASE_ENTER_PRICE;
    } else if (_netRateController.text.isEmpty) {
      return Constants.PLEASE_ENTER_NET_RATE;
    } else if (_mrpController.text.isEmpty) {
      return Constants.PLEASE_ENTER_MRP;
    } else if (_batchNumController.text.isEmpty) {
      return Constants.PLEASE_ENTER_BATCH_NO;
    } else {
      return "";
    }
  }

  onSavePriceDetails(int index, bool isPriceDetailsUpdate) {
    if (isPriceDetailsUpdate) {
      _priceList[index] = PriceModel(
          batchNumber: _batchNumController.text,
          manufacturDate: formattedManufactureDate,
          expireDate: formattedExpireDate,
          price: _priceController.text,
          priceIn: priceUnitDropdownValue != null ? priceUnitDropdownValue : "",
          quantity: _qntyController.text,
          quantityIn:
              quantityDropdownValue != null ? quantityDropdownValue : "",
          netRate: _netRateController.text,
          mrp: _mrpController.text,
          currencyName:
              currencyNameDropdown != null ? currencyNameDropdown!.name : "");
      setState(() {
        _priceList.reversed;
      });
      Navigator.of(context).pop();
    } else {
      _priceList.add(PriceModel(
          batchNumber: _batchNumController.text,
          manufacturDate: formattedManufactureDate,
          expireDate: formattedExpireDate,
          price: _priceController.text,
          priceIn: priceUnitDropdownValue != null ? priceUnitDropdownValue : "",
          quantity: _qntyController.text,
          quantityIn:
              quantityDropdownValue != null ? quantityDropdownValue : "",
          netRate: _netRateController.text,
          mrp: _mrpController.text,
          currencyName:
              currencyNameDropdown != null ? currencyNameDropdown!.name : ""));

      setState(() {
        _priceList.reversed;
      });

      Navigator.of(context).pop();
    }
  }

  Widget priceInputFieldView() {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Row(
                          children: [
                            Expanded(
                              flex: 2,
                              child: RichText(
                                text: TextSpan(children: [
                                  TextSpan(
                                    text: Language().getString(
                                        Constants.PRICE, selectedLang),
                                    style: TextStyle(
                                        fontSize: StyleView.FONT_SIZE_15,
                                        fontFamily: StyleView.FONT_TITLE,
                                        color: Colors.black),
                                  ),
                                  TextSpan(
                                      text: "\*",
                                      style: TextStyle(
                                          fontSize: StyleView.FONT_SIZE_15,
                                          color: Colors.red))
                                ]),
                              ),
                            ),
                            Expanded(
                              child: Container(
                                height: 50,
                                color: Color(Constants.GREY_COLOR_LIGHT),
                                alignment: Alignment.center,
                                child: Text(
                                  "$currencySymbol",
                                  style: TextStyle(
                                    fontSize: 13.0,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        )),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                color: Colors.white,
                padding: EdgeInsets.only(left: 5.0),
                child: TextField(
                  keyboardType: TextInputType.number,
                  controller: _priceController,
                  style: TextStyle(
                    fontFamily: 'IndianRupee',
                  ),
                  decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText:
                          Language().getString(Constants.PRICE, selectedLang)),
                ),
              ),
            )
          ],
        ));
  }

  updatePriceDetialsData(PriceModel priceModel) {
    setState(() {
      _qntyController.text = priceModel.quantity!;
      for (int i = 0; i < Constants.UNIT_PRICE.length; i++) {
        if (Constants.UNIT_PRICE[i] == priceModel.quantityIn) {
          quantityDropdownValue = Constants.UNIT_PRICE[i];
        }
      }

      formattedExpireDate = priceModel.expireDate;
      formattedManufactureDate = priceModel.manufacturDate;
      _batchNumController.text = priceModel.batchNumber!;
      _mrpController.text = priceModel.mrp!;
      _netRateController.text = priceModel.netRate!;
      for (int i = 0; i < Constants.UNIT_PRICE.length; i++) {
        if (Constants.UNIT_PRICE[i] == priceModel.priceIn) {
          priceUnitDropdownValue = Constants.UNIT_PRICE[i];
        }
      }
      _priceController.text = priceModel.price!;
      if (_currencyNameList.length > 0) {
        for (int i = 0; i < _currencyNameList.length; i++) {
          if (_currencyNameList[i].name == priceModel.currencyName) {
            currencyNameDropdown = _currencyNameList[i];
          }
        }
      }
    });
  }

  clearPriceData() {
    setState(() {
      _qntyController.clear();
      quantityDropdownValue = null;
      formattedExpireDate = "";
      formattedManufactureDate = "";
      _batchNumController.clear();
      _mrpController.clear();
      _netRateController.clear();

      _priceController.clear();
      for (int i = 0; i < _currencyNameList.length; i++) {
        /// Comparing currency name
        if (_currencyNameList[i].name == "Indian Rupee") {
          setState(() {
            currencyNameDropdown = _currencyNameList[i];
            currencySymbol = currencyNameDropdown!.htmlSymbol;
          });
        }
      }
      for (int i = 0; i < Constants.UNIT_PRICE.length; i++) {
        if (Constants.UNIT_PRICE[i] == "unit") {
          quantityDropdownValue = Constants.UNIT_PRICE[i];
          priceUnitDropdownValue = Constants.UNIT_PRICE[i];
        }
      }
    });
  }

  SizedBox addProductIssueDetails() {
    return SizedBox(
        height: 25.0,
        width: 25.0,
        child: FloatingActionButton(
          heroTag: "Issue",
          onPressed: () {
            FocusScope.of(context).unfocus();
            showProductIssuesDetailsFields();
          },
          child: Icon(
            Icons.add,
            size: 15,
          ),
          backgroundColor: Color(0xFF083e64),
        ));
  }

  showProductIssuesDetailsFields(
      {bool isForEdit = false,
      ProductIssueDetailsModel? modelData,
      int currentIndex = -1}) {
    if (isForEdit) {
      totalIssuedQuantity = int.parse(modelData!.issuedQuantity!);
      issueDate = modelData.issuedDate;
      purposeController.text = modelData.purpose!;
      issuedQuantityController.text = modelData.issuedQuantity!;
      departmentController.text = modelData.department!;

      for (int i = 0; i < _usersList.length; i++) {
        if (modelData.approvedBy == _usersList[i].name) {
          setState(() {
            approvedByDropdownValue = _usersList[i];
          });
        }
      }
      for (int j = 0; j < _usersList.length; j++) {
        if (modelData.issuedTo == _usersList[j].name) {
          setState(() {
            issuedToDropdownValue = _usersList[j];
          });
        }
      }

      for (int i = 0; i < _priceList.length; i++) {
        if (modelData.batchNumber == _priceList[i].batchNumber) {
          issueDetailsQuantityDropdown = _priceList[i];
        }
      }
    } else {
      issueDate = "";
      purposeController.clear();
      issuedQuantityController.clear();
      approvedByDropdownValue = null;
      issuedToDropdownValue = null;
      issueDetailsQuantityDropdown = null;
      departmentController.clear();
    }
    return showDialog(
        barrierDismissible: false,
        context: context,
        barrierColor: Colors.black54,
        builder: (BuildContext context) {
          return AlertDialog(
              elevation: 100.0,
              backgroundColor: Color(0XFFE0E0E0),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(
                  Radius.circular(
                    7.0,
                  ),
                ),
              ),
              actions: [
                Container(
                  width: MediaQuery.of(context).size.width,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      TextButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                        child: Text(
                          Language()
                              .getString(Constants.STR_CANCEL, selectedLang),
                          style: TextStyle(
                              color: Color(Constants.APP_COLOR),
                              fontFamily: StyleView.FONT_TITLE),
                        ),
                      ),
                      TextButton(
                        onPressed: () {
                          String errorMessage =
                              this.validateIssuedDetailFields();

                          if (errorMessage.isNotEmpty) {
                            Dialogs.yesCancelDialog(
                                context,
                                Language()
                                    .getString(Constants.ERROR, selectedLang),
                                errorMessage,
                                Language().getString(
                                    Constants.OKAY_STR, selectedLang),
                                "",
                                false);
                          } else {
                            if (int.parse(issuedQuantityController.text) >
                                int.parse(
                                    issueDetailsQuantityDropdown!.quantity!)) {
                              Dialogs.yesCancelDialog(
                                  context,
                                  Language()
                                      .getString(Constants.ERROR, selectedLang),
                                  Language().getString(
                                      Constants.INVALID_QUANTITY, selectedLang),
                                  Language().getString(
                                      Constants.OKAY_STR, selectedLang),
                                  "",
                                  false);
                            } else {
                              setState(() {
                                isLoadingProgress = true;
                                progressMessage = "Updating quantity";
                              });

                              this.updatingIssuedDetailsBatchQuantity(
                                  currentIndex, isForEdit, setState);
                            }
                          }
                        },
                        child: Text(
                          Language()
                              .getString(Constants.STR_SAVE, selectedLang),
                          style: TextStyle(
                              color: Color(Constants.APP_COLOR),
                              fontFamily: StyleView.FONT_TITLE),
                        ),
                      )
                    ],
                  ),
                )
              ],
              title: Text(
                Language().getString(
                    isForEdit
                        ? Constants.UPDATE_ISSUE_DETAILS
                        : Constants.ADD_ISSUE_DETAILS,
                    selectedLang),
                style: TextStyle(
                    fontSize: StyleView.FONT_SIZE_18,
                    fontFamily: StyleView.FONT_TITLE,
                    color: Color(Constants.APP_COLOR)),
              ),
              titlePadding: dialogTitlePadding,
              content: StatefulBuilder(
                  builder: (BuildContext context, StateSetter setState) {
                return Container(
                  margin: EdgeInsets.symmetric(
                    vertical: 5.0,
                  ),
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Container(
                          child: Text(
                              Language().getString(
                                  Constants.ISSUED_QUANTITY, selectedLang),
                              style: TextStyle(
                                color: Color(Constants.APP_COLOR),
                                fontSize: 15.0,
                                fontWeight: FontWeight.bold,
                              )),
                        ),
                        Container(
                          margin: EdgeInsets.symmetric(vertical: 5.0),
                          decoration: AppUtills.boxDecoration(),
                          padding: EdgeInsets.only(left: 5),
                          child: TextField(
                              keyboardType: TextInputType.number,
                              controller: issuedQuantityController,
                              style: TextStyle(
                                fontFamily: 'IndianRupee',
                              ),
                              decoration: InputDecoration(
                                border: InputBorder.none,
                                hintText: Language().getString(
                                    Constants.ISSUED_QUANTITY, selectedLang),
                              ),
                              inputFormatters: [
                                new LengthLimitingTextInputFormatter(6),
                                CommonMethods.inputTextFormatter(isNumber: true)
                              ]),
                        ),
                        Container(
                          child: Text(
                              Language()
                                  .getString(Constants.BATCH_NO, selectedLang),
                              style: TextStyle(
                                color: Color(Constants.APP_COLOR),
                                fontSize: 15.0,
                                fontWeight: FontWeight.bold,
                              )),
                        ),
                        this.issueDetailsBatchQuantity(setState),
                        Container(
                          child: Text(
                              Language().getString(
                                  Constants.ISSUED_DATE, selectedLang),
                              style: TextStyle(
                                color: Color(Constants.APP_COLOR),
                                fontSize: 15.0,
                                fontWeight: FontWeight.bold,
                              )),
                        ),
                        this.buildIssuedDate(setState),
                        Container(
                          child: Text(
                              Language()
                                  .getString(Constants.ISSUED_TO, selectedLang),
                              style: TextStyle(
                                color: Color(Constants.APP_COLOR),
                                fontSize: 15.0,
                                fontWeight: FontWeight.bold,
                              )),
                        ),
                        // this.buildDropdownIssueTo(setState),
                        Container(
                          child: Text(
                              Language()
                                  .getString(Constants.PURPOSE, selectedLang),
                              style: TextStyle(
                                color: Color(Constants.APP_COLOR),
                                fontSize: 15.0,
                                fontWeight: FontWeight.bold,
                              )),
                        ),
                        Container(
                          margin: EdgeInsets.symmetric(vertical: 5.0),
                          decoration: AppUtills.boxDecoration(),
                          padding: EdgeInsets.only(left: 5),
                          child: TextField(
                              keyboardType: TextInputType.text,
                              controller: purposeController,
                              style: TextStyle(
                                fontFamily: 'IndianRupee',
                              ),
                              decoration: InputDecoration(
                                border: InputBorder.none,
                                hintText: Language()
                                    .getString(Constants.PURPOSE, selectedLang),
                              )),
                        ),
                        Container(
                          child: Text(
                              Language().getString(
                                  Constants.APPROVED_BY, selectedLang),
                              style: TextStyle(
                                color: Color(Constants.APP_COLOR),
                                fontSize: 15.0,
                                fontWeight: FontWeight.bold,
                              )),
                        ),
                        // this.buildDropdownApprovedBy(setState),
                        Container(
                          child: Text(
                              Language().getString(
                                  Constants.DEPARTMENT, selectedLang),
                              style: TextStyle(
                                color: Color(Constants.APP_COLOR),
                                fontSize: 15.0,
                                fontWeight: FontWeight.bold,
                              )),
                        ),
                        Container(
                          margin: EdgeInsets.symmetric(vertical: 5.0),
                          decoration: AppUtills.boxDecoration(),
                          padding: EdgeInsets.only(left: 5),
                          child: TextField(
                              keyboardType: TextInputType.text,
                              controller: departmentController,
                              style: TextStyle(
                                fontFamily: 'IndianRupee',
                              ),
                              decoration: InputDecoration(
                                border: InputBorder.none,
                                hintText: Language().getString(
                                    Constants.DEPARTMENT, selectedLang),
                              )),
                        ),
                      ],
                    ),
                  ),
                );
              }));
        });
  }

  saveProductIssueData(
      {bool isForUpdate = false,
      int currentIndex = -1,
      required StateSetter setState}) {
    if (isForUpdate) {
      issuedDetailsList[currentIndex] = ProductIssueDetailsModel(
          issuedDate: issueDate,
          issuedTo: issuedToDropdownValue!.name,
          purpose: purposeController.text,
          approvedBy: approvedByDropdownValue!.name,
          issuedQuantity: issuedQuantityController.text,
          batchNumber: issueDetailsQuantityDropdown!.batchNumber,
          remaingQuantity: remaingIssuedDetailsBatchQuantity,
          department: departmentController.text);
    } else {
      issuedDetailsList.add(ProductIssueDetailsModel(
          issuedDate: issueDate,
          issuedTo: issuedToDropdownValue!.name,
          purpose: purposeController.text,
          approvedBy: approvedByDropdownValue!.name,
          issuedQuantity: issuedQuantityController.text,
          batchNumber: issueDetailsQuantityDropdown!.batchNumber,
          remaingQuantity: remaingIssuedDetailsBatchQuantity,
          department: departmentController.text));
    }

    setState(() {
      issuedDetailsList.reversed;
    });

    Navigator.of(context).pop();
  }

  buildIssuedDate(StateSetter setState) {
    return Container(
        margin: EdgeInsets.symmetric(vertical: 5.0),
        decoration: AppUtills.boxDecoration(),
        padding: EdgeInsets.all(1),
        child: ElevatedButton(
            onPressed: () async {
              FocusScope.of(context).unfocus();

              String value = await AppUtills.getSelectedDate(context);
              setState(() {
                issueDate = value;
              });
            },
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Text(issueDate!),
                Image.asset(
                  'assets/images/calander.png',
                  height: 30,
                )
              ],
            )));
  }

  onCreateDynamicProductIssueList() {
    return Column(children: <Widget>[
      for (int i = 0; i < issuedDetailsList.length; i++)
        Container(
          margin: EdgeInsets.symmetric(
            vertical: 5.0,
          ),
          child: Column(children: <Widget>[
            IssueDetailsCardPage(
              title: Language().getString(Constants.APPROVED_BY, selectedLang) +
                  " : ${issuedDetailsList[i].approvedBy}",
              modelDate: issuedDetailsList[i],
              onEditDetails: () {
                showProductIssuesDetailsFields(
                    isForEdit: true,
                    modelData: issuedDetailsList[i],
                    currentIndex: i);
              },
              onRemoveItem: () async {
                final action = await Dialogs.removeItem(
                  context,
                  issuedDetailsList[i].approvedBy,
                  Language().getString(Constants.WARNING, selectedLang),
                  Language().getString(Constants.WARNING_TEXT, selectedLang),
                  cancel:
                      Language().getString(Constants.STR_CANCEL, selectedLang),
                  yes: Language().getString(Constants.YES_STRING, selectedLang),
                );
                if (action == DialogAction.yes) {
                  setState(() {
                    issuedDetailsList.removeAt(i);
                  });
                }
              },
              isFromDetailsPage: true,
            )
          ]),
        ),
    ]);
  }

  loadUsersData(String parms) async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
      });

      this.getAllUsers(parms).then((value) {
        setState(() {
          _usersList.clear();
          _usersList.addAll(value);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<UserModel>> getAllUsers(String parms) async {
    setState(() {
      _usersList.clear();
    });
    String body = json.encode({"id": buId, "filters": {}});

    var response = await _userService
        .getUserByBuId_grpc(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    isLoading = true;
    setState(() {
      isLoadingProgress = false;
    });

    List<UserModel> _users = [];
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      var resultArray = resObj['results'];
      for (var data in resultArray) {
        _users.add(UserModel.fromJson(data));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return _users;
  }

  // buildDropdownApprovedBy(StateSetter setState) {
  //   return Container(
  //     margin: EdgeInsets.symmetric(vertical: 5.0),
  //     decoration: AppUtills.boxDecoration(),
  //     child: Container(
  //       child: SearchableDropdown.single(
  //         items: _usersList.map((UserModel model) {
  //           return new DropdownMenuItem<UserModel>(
  //             child: new Text(model.name),
  //             value: model,
  //           );
  //         }).toList(),
  //         value: approvedByDropdownValue,
  //         underline: Container(),
  //         hint: Language().getString(Constants.APPROVED_BY, selectedLang),
  //         searchHint:
  //             Language().getString(Constants.SEARCH_BY_USER, selectedLang),
  //         onChanged: (value) {
  //           setState(() {
  //             approvedByDropdownValue = value;
  //           });
  //         },
  //         isExpanded: true,
  //       ),
  //     ),
  //   );
  // }

  // buildDropdownIssueTo(StateSetter setState) {
  //   return Container(
  //     margin: EdgeInsets.symmetric(vertical: 5.0),
  //     decoration: AppUtills.boxDecoration(),
  //     child: SearchableDropdown.single(
  //       items: _usersList.map((UserModel model) {
  //         return new DropdownMenuItem<UserModel>(
  //           child: new Text(model.name),
  //           value: model,
  //         );
  //       }).toList(),
  //       value: issuedToDropdownValue,
  //       underline: Container(),
  //       hint: Language().getString(Constants.ISSUED_TO, selectedLang),
  //       searchHint:
  //           Language().getString(Constants.SEARCH_BY_USER, selectedLang),
  //       onChanged: (value) {
  //         setState(() {
  //           issuedToDropdownValue = value;
  //         });
  //       },
  //       isExpanded: true,
  //     ),
  //   );
  // }

  Future<ProductConsumptionDAO> getProductDataById() async {
    setState(() {
      isLoadingProgress = true;
    });
    String body = json.encode({"bu_id": buId, "id": widget.productId});
    var response = await _consumableGrpcService
        .getProductListById(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    ProductConsumptionDAO modelData = ProductConsumptionDAO();
    GRPCResponse _grpcRespone = response;
    if (!_grpcRespone.getIsError! && !_grpcRespone.getIsException!) {
      var reqData = json.decode(_grpcRespone.message!);

      modelData = ProductConsumptionDAO.fromJson(reqData[0]);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcRespone.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return modelData;
  }

  bindingProductData() {
    _productNameController.text = productData!.name!;
    _brandController.text = productData!.brand!;

    _descriptionController.text = productData!.description!;
    if (productData!.isConsumable!) {
      consumableProductRadioValue = Constants.YES_STRING;
    }

    if (productData!.attributesList != null) {
      for (int j = 0; j < productData!.attributesList!.length; j++) {
        attributesList.add(ProductAttributeModel(
            attributeKey:
                productData!.attributesList![j].entries.toList()[0].key,
            attributeValue:
                productData!.attributesList![j].entries.toList()[0].value));
      }
    }

    if (productData!.manufactureDetails != null) {
      _modelNumberController.text =
          productData!.manufactureDetails!.modelNumber!;

      _manufactureNameController.text = productData!.manufactureDetails!.name!;
      _manufactureAddressController.text = _manufactureAddressController.text =
          productData!.manufactureDetails!.manufacturerAddress!;
      _buildingNumController.text =
          productData!.manufactureDetails!.buildiName!;
      _areaController.text = productData!.manufactureDetails!.area!;

      _talukController.text = productData!.manufactureDetails!.taluka!;
      formattedReleaseDate =
          formatter.format(productData!.manufactureDetails!.releaseDate!);
      _landMarkController.text = productData!.manufactureDetails!.landmark!;

      _pinController.text = productData!.manufactureDetails!.pin!;
    }

    /// Item Details
    if (productData!.shippingDetails != null) {
      /// Spilt weight value
      if (productData!.shippingDetails!.weight!.isNotEmpty) {
        List weightSplitText = productData!.shippingDetails!.weight!.split(" ");
        _weightController.text = weightSplitText[0];
        for (int i = 0; i < Constants.weightMeasurementsList.length; i++) {
          if (Constants.weightMeasurementsList[i] == weightSplitText[1]) {
            setState(() {
              weightDropdownValue = Constants.weightMeasurementsList[i];
            });
          }
        }
      }
    }

    if (productData!.batchPrice != null) {
      for (int p = 0; p < productData!.batchPrice!.length; p++) {
        _priceList.add(PriceModel(
            batchNumber: productData!.batchPrice![p].batchNumber,
            currencyName: productData!.batchPrice![p].currencyName,
            expireDate: productData!.batchPrice![p].expiryDate,
            manufacturDate: productData!.batchPrice![p].manufactureDate,
            mrp: productData!.batchPrice![p].mrp.toString(),
            netRate: productData!.batchPrice![p].netRate.toString(),
            price: productData!.batchPrice![p].price.toString(),
            priceIn: productData!.batchPrice![p].unitPrice,
            quantity: productData!.batchPrice![p].quantity.toString(),
            quantityIn: productData!.batchPrice![p].quantityIn));
      }
    }
    if (productData!.inventoryData != null) {
      int totalInventoryCount = 0;
      for (int k = 0; k < productData!.inventoryData!.length; k++) {
        totalInventoryCount = totalInventoryCount +
            (productData!.inventoryData![k].quantity as int);

        inventoryList.add(InventoryManagementModel(
            locationName: productData!.inventoryData![k].locationName,
            quantity: productData!.inventoryData![k].quantity,
            batchNumber: productData!.inventoryData![k].batchNumber));

        productTotalQuantity = productTotalQuantity - totalInventoryCount;
      }
    }

    if (productData!.issueDetailsData != null) {
      for (int d = 0; d < productData!.issueDetailsData!.length; d++) {
        issuedDetailsList.add(ProductIssueDetailsModel(
            issuedDate: productData!.issueDetailsData![d].issuedDate,
            issuedQuantity:
                productData!.issueDetailsData![d].issuedQuantity.toString(),
            issuedTo: productData!.issueDetailsData![d].issuedTo,
            purpose: productData!.issueDetailsData![d].purpose,
            batchNumber: productData!.issueDetailsData![d].batchNumber,
            approvedBy: productData!.issueDetailsData![d].approvedBy,
            remaingQuantity:
                productData!.issueDetailsData![d].remaingQuantity));
      }
    }
  }

  Widget issueDetailsBatchQuantity(StateSetter setState) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 5.0),
      decoration: AppUtills.boxDecoration(),
      padding: EdgeInsets.all(1),
      child: DropdownButton<PriceModel>(
        onTap: () {
          FocusScope.of(context).unfocus();
        },
        isExpanded: true,
        hint: Text(Language().getString(Constants.BATCH_NO, selectedLang)),
        underline: SizedBox(),
        items: _priceList.map((PriceModel batchPrice) {
          return DropdownMenuItem<PriceModel>(
            value: batchPrice,
            child: new Text(
              batchPrice.batchNumber!,
              style: TextStyle(fontFamily: StyleView.FONT_TITLE),
            ),
          );
        }).toList(),
        value: issueDetailsQuantityDropdown,
        onChanged: (PriceModel? model) {
          setState(() {
            issueDetailsQuantityDropdown = model;
            remainingBatchQuantity = model!.quantity;
          });
        },
      ),
    );
  }

  String validateIssuedDetailFields() {
    if (issueDetailsQuantityDropdown == null) {
      return "Please select batch";
    } else if (issuedQuantityController.text.isEmpty) {
      return "Please enter quantity";
    } else {
      return "";
    }
  }

  updatingIssuedDetailsBatchQuantity(
      int index, bool isUpdateInventory, StateSetter setState) {
    if (isUpdateInventory) {
      if (totalIssuedQuantity < int.parse(issuedQuantityController.text)) {
        this.validatingSelectedIssuedDetailsBatchQuantity(setState);
      } else {
        num priceQuanity = 0;
        num enteredQuantity = int.parse(issuedQuantityController.text);
        for (int i = 0; i < _priceList.length; i++) {
          if (issueDetailsQuantityDropdown!.batchNumber ==
              _priceList[i].batchNumber) {
            setState(() {
              priceQuanity = totalIssuedQuantity - enteredQuantity;
              _priceList[i].quantity =
                  (priceQuanity + int.parse(_priceList[i].quantity!))
                      .toString();
              isLoadingProgress = false;
              remaingIssuedDetailsBatchQuantity =
                  int.parse(_priceList[i].quantity!);
              print("RE QUA $remaingIssuedDetailsBatchQuantity");
            });
          }
        }
      }
    } else {
      if (issueDetailsQuantityDropdown != null) {
        this.validatingSelectedIssuedDetailsBatchQuantity(setState);
      }
    }

    this.saveProductIssueData(
        isForUpdate: isUpdateInventory,
        currentIndex: index,
        setState: setState);
  }

  validatingSelectedIssuedDetailsBatchQuantity(setState) {
    num priceQuanity = 0;
    num enteredQuantity = int.parse(issuedQuantityController.text);
    for (int i = 0; i < _priceList.length; i++) {
      if (issueDetailsQuantityDropdown!.batchNumber ==
          _priceList[i].batchNumber) {
        setState(() {
          priceQuanity = int.parse(_priceList[i].quantity!);
          _priceList[i].quantity = (priceQuanity - enteredQuantity).toString();
          isLoadingProgress = false;
          remaingIssuedDetailsBatchQuantity =
              int.parse(_priceList[i].quantity!);

          print("REM QU $remaingIssuedDetailsBatchQuantity");
        });
      }
    }
  }

  _uploadAssetImage(String? consumptionId) async {
    String body =
        json.encode({"id": consumptionId, "bu_id": buId, "image": imageBlob});

    http.Response response =
        await _service.uploadConsumptionImage(body).catchError((onError) {
      setState(() {
        isLoadingProgress = true;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    setState(() {
      isLoadingProgress = false;
    });

    if (response.statusCode == 200) {
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          Language().getString(Constants.SUCCESS, selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);

      if (action == DialogAction.yes) {
        Navigator.pop(context);
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          response.body,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }
}
