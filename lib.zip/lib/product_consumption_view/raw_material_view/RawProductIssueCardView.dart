import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/model/RawProductsIssueDAO.dart';

class RawProductIsuuesCardPage extends StatelessWidget {
  final RawProductsIssueDAO? modelData;
  final String selectedLang;
  final bool canShowBatchNumber;
  RawProductIsuuesCardPage(
      {this.modelData,
      required this.selectedLang,
      this.canShowBatchNumber = true});
  @override
  Widget build(BuildContext context) {
    return Card(
        elevation: 5.0,
        shadowColor: AppTheme.vyaparTheme.colorScheme.primary,
        shape: new RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(5),
            side: new BorderSide(
                color: AppTheme.vyaparTheme.colorScheme.primaryContainer,
                strokeAlign: 1)),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                this.caardItemView(
                    Language().getString(Constants.ISSUED_TO, selectedLang),
                    modelData!.issuedTo != null
                        ? modelData!.issuedTo!.userName
                        : ""),
                this.caardItemView(
                    Language().getString(Constants.APPROVED_BY, selectedLang),
                    modelData!.approvedBy != null
                        ? modelData!.approvedBy!.userName
                        : ""),
                this.caardItemView(
                    Language().getString(Constants.REQUESTED_BY, selectedLang),
                    modelData!.requestedBy != null
                        ? modelData!.requestedBy!.userName
                        : ""),
                this.caardItemView(
                    Language().getString(Constants.ISSUANCE_ID, selectedLang),
                    "${modelData!.issueNumber}"),
                this.caardItemView(
                    Language().getString(Constants.REQUESTED_ID, selectedLang),
                    "${modelData!.requestNumber}"),
                this.caardItemView(
                    Language().getString(Constants.PURPOSE, selectedLang),
                    "${modelData!.issuedPurpose}"),
                this.caardItemView(
                    Language().getString(Constants.DEPARTMENT, selectedLang),
                    "${modelData!.department}"),
                if (canShowBatchNumber)
                  this.caardItemView(
                      Language().getString(Constants.BATCH_NO, selectedLang),
                      "${modelData!.issueBatchNumber}"),
                this.caardItemView(
                    Language().getString(Constants.APPROVAL_DATE, selectedLang),
                    AppUtills.getDateFormate("${modelData!.createdDate}"))
              ],
            ),
          ),
        ));
  }

  caardItemView(String title, String? value) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 3.0),
      child: Row(
        children: <Widget>[
          new Expanded(
            child: Text(
              title,
              style: TextStyle(
                  color: Colors.black,
                  fontSize: 15.0,
                  fontWeight: StyleView.fontSemiBold),
            ),
          ),
          Text(
            " : ",
          ),
          Expanded(
            flex: 2,
            child: new Container(
              child: Text(
                "$value",
                style: TextStyle(
                    color: Colors.black,
                    fontSize: 13.0,
                    fontWeight: StyleView.fontMedium),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
