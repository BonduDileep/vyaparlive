import 'dart:convert';
import 'dart:io';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:flutx/flutx.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Product/CategorySearchPage.dart';
import 'package:vyaparlive/Product/EditMyProduct.dart';
import 'package:vyaparlive/Product/ProductDetailsPage.dart';
import 'package:vyaparlive/Product/products_widget/PopupMenuItemDesign.dart';
import 'package:vyaparlive/Product/quantity_adjust_view/QuantityAdjustmentView.dart';
import 'package:vyaparlive/Product/suppliers_view/SupplierPage.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/MyDrawer.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/product_model/ProductModel.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:vyaparlive/product_consumption_view/raw_material_view/RawProductIssueList.dart';
import 'package:vyaparlive/service/product_services.dart';

import '../../core/enums/privilleges_enum.dart';

class RawProductsListPage extends StatefulWidget {
  @override
  _RawProductsListPageState createState() => _RawProductsListPageState();
}

class _RawProductsListPageState extends State<RawProductsListPage> {
  String? buId = "";
  String? buName = "";
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  List<BuProductModal> _productsList = [];
  late ProductService _productService;
  bool isSearchForParams = false;
  num totalBatchQuantity = 0;
  List<num> batchQuantityList = [];
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  TextEditingController _searchController = TextEditingController();
  String? orgCurrencySymbol = "";
  bool isShowFloatButton = false;
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    _productService = ProductService();
    theme = AppTheme.vyaparTheme;
    buId = AppController.instance.getMyBuId;
    buName = AppController.instance.getBuName;
    this.loadProductData();
    // orgCurrencySymbol = AppController.instance.getBuCurrencySymbol;
    String? symbol = AppController.instance.getBuCurrencySymbol;
    orgCurrencySymbol = (symbol != null && symbol.isNotEmpty && symbol!="-") ? symbol : "\u20B9";
  }

  onAlignGridItems(BoxConstraints boxConstrainst) {
    if (kIsWeb || Platform.isWindows) {
      if (boxConstrainst.maxWidth > 800) {
        return 7;
      }

      if (boxConstrainst.maxWidth < 500 ||
          boxConstrainst.maxWidth < 600 ||
          boxConstrainst.maxWidth < 700) {
        return 2;
      }
      return 3;
    } else {
      return 2;
    }
  }

  double findAspectRatio(double width, BoxConstraints boxConstraints) {
    // print("boxConstraint $boxConstraints");
    //Logic for aspect ratio of grid view
    if (kIsWeb || Platform.isWindows) {
      if (boxConstraints.maxWidth < 500 ||
          boxConstraints.maxWidth < 600 ||
          boxConstraints.maxWidth < 700) {
        if (boxConstraints.maxHeight < 500) {
          // print("boxConstraint height $boxConstraints");
          return MediaQuery.of(context).size.width /
              (MediaQuery.of(context).size.height / 1);
        } else {
          print("boxConstraint width $boxConstraints");
          return MediaQuery.of(context).size.width /
              (MediaQuery.of(context).size.height / 1.4);
        }

        // (width / 2 - 24) /
        //     ((width / 2 - 10) + MediaQuery.of(context).size.height * 0.5);
      } else {
        return (width / 2 - 24) /
            ((width / 2 - 20) + MediaQuery.of(context).size.height * 0.10);
      }
    } else {
      return (width / 2 - 24) /
          ((width / 2 - 20) + MediaQuery.of(context).size.height * 0.10);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
      body: WillPopScope(
        onWillPop: () {
          return CommonMethods.onBackPress(context).then((value) => value);
        },
        child: Stack(
          children: [
            SafeArea(
              child: Scaffold(
                backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                appBar: AppBar(
                  backgroundColor: Colors.transparent, //(Constants.APP_COLOR),
                  centerTitle: true,
                  elevation: 0,
                  iconTheme: IconThemeData(color: theme.colorScheme.primary),
                  title: AppbarName(
                      title: Language()
                          .getString(Constants.RAW_MATERIAL_LIST, selectedLang),
                      buName: "$buName"),
                  actions: [
                    if (CommonMethods.isPrivillegeExist(
                        context, PrivillegesActions.RAW_MATERIAL_MENU_RAW_MATERIALS_NEW))
                      (kIsWeb)
                          ? this.showCreateProductOptionsWebView()
                          : TextButton(
                              onPressed: () {
                                CommonMethods.hideKeyboard(context);
                                this.buildBussinessLeveltype();
                              },
                              child: Icon(Icons.add))
                  ],
                ),
                floatingActionButton: (isShowFloatButton)
                    ? FloatingActionButton(
                        backgroundColor: theme.colorScheme.primary,
                        onPressed: () {
                          CommonMethods.hideKeyboard(context);
                          _searchController.clear();
                          isShowFloatButton = false;
                          isLoadingProgress = true;
                          this.loadProductData();
                        },
                        child: Text(
                          Language()
                              .getString(Constants.CLEAR_FILTERS, selectedLang),
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 10.0, color: Colors.white),
                        ),
                      )
                    : null,
                drawer: MyDrawer(),
                body: Container(
                  margin: EdgeInsets.symmetric(vertical: 5.0, horizontal: 5.0),
                  child: Column(
                    children: [
                      FxSpacing.height(10),
                      this.buildSearchBarView(),
                      FxSpacing.height(10),
                      (_productsList.length > 0)
                          ? Expanded(child: AnimationLimiter(child:
                              LayoutBuilder(builder: (context, boxConstraints) {
                              return GridView.builder(
                                  padding: FxSpacing.nTop(5),
                                  shrinkWrap: true,
                                  physics: new AlwaysScrollableScrollPhysics(
                                      parent: BouncingScrollPhysics()),
                                  gridDelegate:
                                      SliverGridDelegateWithFixedCrossAxisCount(
                                    crossAxisCount:
                                        onAlignGridItems(boxConstraints),
                                    childAspectRatio: findAspectRatio(
                                        MediaQuery.of(context).size.width,
                                        boxConstraints),
                                  ),
                                  itemBuilder: (context, index) {
                                    return AnimationConfiguration.staggeredGrid(
                                      columnCount: 2,
                                      position: index,
                                      duration: Duration(milliseconds: 900),
                                      child: SlideAnimation(
                                        verticalOffset: 50.0,
                                        child: FadeInAnimation(
                                          child: listRowEditUpdate(
                                              _productsList[index],
                                              batchQuantityList[index],
                                              index),
                                        ),
                                      ),
                                    );
                                  },
                                  itemCount: _productsList.length);
                            })))
                          : Container(
                              child: Text(Language().getString(
                                  Constants.NO_DATA_FOUND, selectedLang)),
                            )
                    ],
                  ),
                ),
              ),
            ),
            AppUtills.showLoadingView(
                context: context,
                message: Language().getString(progressMessage, selectedLang),
                isLoading: isLoadingProgress),
          ],
        ),
      ),
    );
  }

  bool canShowPopupMenu() {
    return (CommonMethods.isPrivillegeExist(
            context, PrivillegesActions.RAW_MATERIAL_MENU_RAW_MATERIALS_PRODUCT_SUPPLIERS) ||
        CommonMethods.isPrivillegeExist(
            context, PrivillegesActions.RAW_MATERIAL_MENU_RAW_MATERIALS_PRODUCT_ISSUE_NOTES) ||
        CommonMethods.isPrivillegeExist(
            context, PrivillegesActions.RAW_MATERIAL_MENU_RAW_MATERIALS_PRODUCT_VIEW) ||
        CommonMethods.isPrivillegeExist(
            context, PrivillegesActions.RAW_MATERIAL_MENU_RAW_MATERIALS_PRODUCT_EDIT) ||
        CommonMethods.isPrivillegeExist(context,
            PrivillegesActions.RAW_MATERIAL_MENU_RAW_MATERIALS_PRODUCT_MOVE_TO_BUSINESS_UNIT) ||
        CommonMethods.isPrivillegeExist(context,
            PrivillegesActions.RAW_MATERIAL_MENU_RAW_MATERIALS_PRODUCT_QUANTITY_ADJUSTMENT));
  }

  Widget listRowEditUpdate(
      BuProductModal modelData, num batchQuantityTotal, int index) {
    return Card(
        elevation: 10,
        shadowColor: theme.colorScheme.primary,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
            side: new BorderSide(
                color: theme.colorScheme.primaryContainer, strokeAlign: 1)),
        child: Container(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              ClipRRect(
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(10.0),
                    topRight: Radius.circular(10.0)),
                child: (modelData.images != null && modelData.images != '')
                    ? Image.network(
                        '${Constants.IAMGE_BUCKET_URL}${modelData.images}',
                        width: MediaQuery.of(context).size.width,
                        height: MediaQuery.of(context).size.height / 6,
                        fit: BoxFit.contain,
                      )
                    : Image.asset(
                        'assets/images/no_image.jpg',
                        width: MediaQuery.of(context).size.width,
                        height: MediaQuery.of(context).size.height / 6,
                        fit: BoxFit.contain,
                      ),
              ),
              //  AppUtills.displayImage(
              //               //         modelData.imageThumbnail![0].image)
              Container(
                padding: FxSpacing.nBottom(8),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      children: [
                        new Expanded(
                          flex: 5,
                          child: Text(
                            "${modelData.name}",
                            style: TextStyle(
                              color: Colors.black,
                              overflow: TextOverflow.ellipsis,
                              fontWeight: StyleView.fontBold,
                            ),
                          ),
                        ),
                        if (canShowPopupMenu())
                          Expanded(
                            child: Container(
                              child: PopupMenuButton(
                                  elevation: 5,
                                  shadowColor: theme.colorScheme.primary,
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(10.0)),
                                      side: new BorderSide(
                                          color: theme
                                              .colorScheme.primaryContainer,
                                          strokeAlign: 1)),
                                  onSelected: (dynamic value) {
                                    CommonMethods.hideKeyboard(context);
                                    switch (value) {
                                      case Constants.VIEW:
                                        this.onCartDetails(modelData.id);

                                        break;
                                      case Constants.SUPPLIERS:
                                        this.navigationToSuppliers(modelData);
                                        break;
                                      case Constants.ISSUANCE_NOTES:
                                        this.navigationToIssueNotes(modelData);

                                        break;
                                      case Constants.EDIT:
                                        this.navigationToEditPage(
                                            modelData.id, modelData.buId);

                                        break;
                                      case Constants.MOVE_TO_PRODUCT:
                                        this.moveRawMaterialToProduct(
                                            modelData.id);
                                        break;
                                      case Constants.QUANTITY_ADJUSTMENT:
                                        this.navigationToQuantityAdjustmentPage(
                                            modelData);

                                        break;
                                      default:
                                    }
                                  },
                                  icon: Icon(Icons.more_vert),
                                  itemBuilder: (context) => [
                                        if (CommonMethods.isPrivillegeExist(
                                            context,
                                            PrivillegesActions
                                                .RAW_MATERIAL_MENU_RAW_MATERIALS_PRODUCT_SUPPLIERS))
                                          PopupMenuItem(
                                            child: PopupMenuItemDesingView(
                                              assetPath:
                                                  "assets/images/supplier_icon.png",
                                              itemName: Language().getString(
                                                  Constants.SUPPLIERS,
                                                  selectedLang),
                                            ),
                                            value: Constants.SUPPLIERS,
                                          ),
                                        if (CommonMethods.isPrivillegeExist(
                                            context,
                                            PrivillegesActions
                                                .RAW_MATERIAL_MENU_RAW_MATERIALS_PRODUCT_ISSUE_NOTES))
                                          PopupMenuItem(
                                            child: PopupMenuItemDesingView(
                                              assetPath:
                                                  "assets/images/transaction_icon_product.png",
                                              itemName: Language().getString(
                                                  Constants.ISSUANCE_NOTES,
                                                  selectedLang),
                                            ),
                                            value: Constants.ISSUANCE_NOTES,
                                          ),
                                        if (CommonMethods.isPrivillegeExist(
                                            context,
                                            PrivillegesActions
                                                .RAW_MATERIAL_MENU_RAW_MATERIALS_PRODUCT_VIEW))
                                          PopupMenuItem(
                                            child: PopupMenuItemDesingView(
                                              assetPath:
                                                  "assets/images/product_details_icon.png",
                                              itemName: Language().getString(
                                                  Constants.VIEW, selectedLang),
                                            ),
                                            value: Constants.VIEW,
                                          ),
                                        if (CommonMethods.isPrivillegeExist(
                                            context,
                                            PrivillegesActions
                                                .RAW_MATERIAL_MENU_RAW_MATERIALS_PRODUCT_EDIT))
                                          PopupMenuItem(
                                              child: PopupMenuItemDesingView(
                                                assetPath:
                                                    "assets/images/edit_image.png",
                                                itemName: Language().getString(
                                                    Constants.EDIT,
                                                    selectedLang),
                                              ),
                                              value: Constants.EDIT),
                                        if (CommonMethods.isPrivillegeExist(
                                            context,
                                            PrivillegesActions
                                                .RAW_MATERIAL_MENU_RAW_MATERIALS_PRODUCT_MOVE_TO_BUSINESS_UNIT))
                                          PopupMenuItem(
                                              child: PopupMenuItemDesingView(
                                                assetPath:
                                                    "assets/images/move_icon.png",
                                                itemName: Language().getString(
                                                    Constants.MOVE_TO_PRODUCT,
                                                    selectedLang),
                                              ),
                                              value: Constants.MOVE_TO_PRODUCT),
                                        if (CommonMethods.isPrivillegeExist(
                                            context,
                                            PrivillegesActions
                                                .RAW_MATERIAL_MENU_RAW_MATERIALS_PRODUCT_QUANTITY_ADJUSTMENT))
                                          PopupMenuItem(
                                              child: PopupMenuItemDesingView(
                                                assetPath:
                                                    "assets/images/move_icon.png",
                                                itemName: Language().getString(
                                                    Constants
                                                        .QUANTITY_ADJUSTMENT,
                                                    selectedLang),
                                              ),
                                              value:
                                                  Constants.QUANTITY_ADJUSTMENT)
                                      ]),
                            ),
                          )
                      ],
                    ),
                    Row(
                      children: [
                        Text(
                          Language().getString(Constants.PRICE, selectedLang),
                          style: TextStyle(
                              color: Colors.black,
                              fontWeight: StyleView.fontMedium),
                        ),
                        Text("  : "),
                        Expanded(
                          child: Text(
                            "$orgCurrencySymbol ${CommonMethods.getAvailablePrice(modelData.batchPrice!)}",
                            style: TextStyle(
                                color: Colors.black,
                                fontSize: 12,
                                fontWeight: StyleView.fontRegular),
                          ),
                        )
                      ],
                    ),
                    Row(
                      children: [
                        Text(
                          Language()
                              .getString(Constants.QUANTITY, selectedLang),
                          style: TextStyle(
                              color: Colors.black,
                              fontWeight: StyleView.fontMedium),
                        ),
                        Text("  : "),
                        Expanded(
                          child: Text(
                            ("${batchQuantityList[index]} ${_productsList[index].batchPrice![0].quantityIn}"),
                            style: TextStyle(
                                color: Colors.black,
                                fontSize: 12,
                                fontWeight: StyleView.fontRegular),
                          ),
                        )
                      ],
                    )
                  ],
                ),
              ),
            ],
          ),
        ));
  }

  onCartDetails(String? productId) {
    Navigator.push(
        context,
        PageTransition(
          context: context,
          page: ProductDetailsPage(
            productId: productId,
            currentBuId: buId,
            isFromRawProductsPage: true,
          ),
        )); //.then((value) => loadProductData());
  }

  navigationToEditPage(String? productId, String? buId) {
    Navigator.push(
        context,
        PageTransition(
          context: context,
          page: EditMyProductPage(
            title: Constants.UPDATE_PRODUCT,
            buId: buId!,
            isFromRawMaterialPage: true,
            productId: productId!,
            rawMaterialTitle: Constants.UPDATE_RAW_MATERIAL,
          ),
        )).then((value) => loadProductData());
  }

  navigationToIssueNotes(BuProductModal productData) {
    Navigator.push(
        context,
        PageTransition(
            context: context,
            page: RawProductIssueListPage(
              productName: productData.name,
              isFromRawproductListPage: true,
            )));
  }

  navigationToSuppliers(BuProductModal data) {
    Navigator.push(
        context,
        PageTransition(
            context: context,
            page: SupplierPage(
              productName: data.name,
              productImage: data.images,
              buId: buId,
              productId: data.id,
            )));
  }

  loadProductData(
      {String productName = "",
      String? sector = "",
      String? category = "",
      String? segment = "",
      String? subCategory = ""}) async {
    if (await NetworkStatus.getInternetStatus()) {
      if (!isSearchForParams) {
        setState(() {
          isLoadingProgress = true;
        });
      }
      getBuProducts(
              productName: productName,
              sector: sector,
              category: category,
              subCategory: subCategory,
              segment: segment)
          .then((onValue) {
        setState(() {
          if (onValue.length > 0) {
            _productsList.clear();
            batchQuantityList.clear();
            _productsList.addAll(onValue);

            /// Adding all batch items quantity
            for (int i = 0; i < _productsList.length; i++) {
              if (_productsList[i].batchPrice!.length > 0) {
                totalBatchQuantity = 0;
                for (int j = 0; j < _productsList[i].batchPrice!.length; j++) {
                  totalBatchQuantity = totalBatchQuantity +
                      _productsList[i].batchPrice![j].quantity!;
                }
                batchQuantityList.add(totalBatchQuantity);
              } else {
                batchQuantityList.add(0);
              }
            }
          } else {}
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<BuProductModal>> getBuProducts(
      {String productName = "",
      String? sector = "",
      String? segment = "",
      String? category = "",
      String? subCategory = ""}) async {
    setState(() {
      _productsList.clear();
    });
    String body = json.encode({
      "id": buId,
      "filter": {
        "name": productName,
        "raw_material": true,
        "product_sector": sector,
        "product_segment": segment,
        "product_category": category,
        "product_sub_category": subCategory
      }
    });

    var response = await _productService
        .getProductByBuId_v2(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<BuProductModal> products = [];

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      var data = resObj['results'];
      for (var i in data) {
        products.add(BuProductModal.fromJson(i));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return products;
  }

  buildSearchBarView() {
    return Container(
      height: 50.0,
      child: Card(
        elevation: 5,
        shadowColor: theme.colorScheme.primary,
        shape: new RoundedRectangleBorder(
            borderRadius: new BorderRadius.circular(15),
            side: new BorderSide(
                color: theme.colorScheme.primary, strokeAlign: 0.02)),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: TextFormField(
                  controller: _searchController,
                  onChanged: onSearchTextChanged,
                  style: TextStyle(fontWeight: StyleView.fontSemiBold),
                  decoration: InputDecoration(
                      contentPadding: EdgeInsets.only(bottom: 10),
                      border: InputBorder.none,
                      hintText: Language().getString(
                          Constants.SEARCH_BY_REQUESTER_NAME, selectedLang),
                      hintStyle: TextStyle(
                          fontSize: 13.0, fontWeight: StyleView.fontSemiBold)),
                ),
              ),
            ),
            (_searchController.text.length > 0)
                ? Container(
                    color: Colors.white,
                    child: IconButton(
                        icon: Icon(
                          Icons.close,
                          color: Colors.red,
                          size: 20.0,
                        ),
                        onPressed: () {
                          CommonMethods.hideKeyboard(context);
                          _searchController.clear();
                          onSearchTextChanged(_searchController.text);
                        }),
                  )
                : Container(),
            if (CommonMethods.isPrivillegeExist(
                context, PrivillegesActions.RAW_MATERIAL_MENU_RAW_MATERIALS_FILTER_BY_CATEGORY))
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                    topRight: Radius.circular(10.0),
                    bottomRight: Radius.circular(10.0),
                  ),
                  color: Colors.white,
                ),
                child: IconButton(
                    icon: Icon(Icons.filter_list),
                    onPressed: () async {
                      CommonMethods.hideKeyboard(context);
                      final result = await Navigator.push(
                          context,
                          PageTransition(
                              context: context,
                              page: CategorySearchPage(
                                buName: buName,
                              )));
                      if (result != null) {
                        isShowFloatButton = true;
                        loadProductData(
                            sector: result["product_sector"],
                            segment: result["product_segment"],
                            category: result["product_category"],
                            subCategory: result["product_sub_category"]);
                      }
                    }),
              )
          ],
        ),
      ),
    );
  }

  onSearchTextChanged(String text) async {
    if (text.isEmpty) {
      isSearchForParams = false;
      loadProductData();
    } else {
      isSearchForParams = true;
      // isShowFloatButton = true;

      loadProductData(productName: text);
    }
  }

  moveRawMaterialToProduct(String? productId) async {
    final action = await Dialogs.yesCancelDialog(
        context,
        Language().getString(Constants.INFO, selectedLang),
        Language().getString(
            Constants.ARE_YOU_SURE_ADD_RAW_MATERIAL_TO_BU_PRODUCT,
            selectedLang),
        Language().getString(Constants.OKAY_STR, selectedLang),
        Language().getString(Constants.STR_CANCEL, selectedLang),
        true);

    if (action == DialogAction.yes) {
      if (await NetworkStatus.getInternetStatus()) {
        setState(() {
          isLoadingProgress = true;
          progressMessage = Constants.SENDING_PRODUCTS;
        });
        this.serviceCallMoveProductsToRaw(productId);
      } else {
        AppUtills.showSnackBar(_scaffoldkey,
            Language().getString(Constants.NO_INTERNET, selectedLang),
            snackBarBgColor: Colors.black,
            messageColor: Colors.white,
            buttonColor: Colors.white);
      }
    }
  }

  serviceCallMoveProductsToRaw(String? productId) async {
    String body = json.encode({"bu": buId, "id": productId, "type": 1});

    var response = await _productService
        .productConvert(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          Language().getString(
              Constants.PRODUCT_ADDED_SUCCESSFULY_TO_RAW_MATERIAL,
              selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);

      if (action == DialogAction.yes) {
        this.loadProductData();
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  navigationToQuantityAdjustmentPage(BuProductModal modelData) {
    Navigator.push(
        context,
        PageTransition(
          context: context,
          page: QuantityAdjustmentView(
              isFromRawMaterial: true,
              productName: modelData.name,
              buName: buName,
              buId: modelData.buId,
              productId: modelData.id),
        )).then((value) => this.loadProductData());
  }

  showCreateProductOptionsWebView() {
    return Container(
      child: PopupMenuButton(
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(10.0))),
          onSelected: (dynamic value) async {
            CommonMethods.hideKeyboard(context);
            switch (value) {
              case Constants.CREATE_FOR:
                Navigator.push(
                    context,
                    PageTransition(
                      context: context,
                      page: EditMyProductPage(
                        title: Constants.ADD_PRODUCT,
                        buId: buId!,
                        isFromRawMaterialPage: true,
                        rawMaterialTitle: Constants.ADD_RAW_MATERIAL,
                        productId: '',
                      ),
                    )).then((value) => loadProductData());

                break;
              case Constants.PRODUCTS_IN_BUILK:
                if (kIsWeb) {
                  AppUtills.launchURL(Constants.BULK_RAW_PRODUCT_UPLOAD_URL +
                      "$buId/${AppController.instance.authorizationKey}");
                } else {
                  AppUtills.launchURL(Constants.BULK_RAW_PRODUCT_UPLOAD_URL +
                      "$buId/${AppController.instance.authorizationKey}");
                }
                break;

              default:
            }
          },
          icon: Icon(Icons.add),
          itemBuilder: (context) => [
                PopupMenuItem(
                  child: Row(
                    children: [
                      Icon(
                        Icons.add,
                        color: Color(
                          Constants.APP_COLOR,
                        ),
                      ),
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.all(5.0),
                          child: Text(
                            Language().getString(
                                    Constants.CREATE_FOR, selectedLang) +
                                " ${AppController.instance.getBuName}",
                            style: TextStyle(
                                fontSize: 14.0,
                                color: Color(Constants.APP_COLOR)),
                          ),
                        ),
                      ),
                    ],
                  ),
                  value: Constants.CREATE_FOR,
                ),
                PopupMenuItem(
                  child: Row(
                    children: [
                      Icon(
                        Icons.import_export,
                        color: Color(
                          Constants.APP_COLOR,
                        ),
                      ),
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.all(5.0),
                          child: Text(
                            Language().getString(
                                Constants.PRODUCTS_IN_BUILK, selectedLang),
                            style: TextStyle(
                                fontSize: 14.0,
                                color: Color(Constants.APP_COLOR)),
                          ),
                        ),
                      ),
                    ],
                  ),
                  value: Constants.PRODUCTS_IN_BUILK,
                ),
              ]),
    );
  }

  buildBussinessLeveltype() {
    return showDialog(
        barrierDismissible: false,
        context: context,
        barrierColor: Colors.black54,
        builder: (context) {
          return Container(
            margin: EdgeInsets.symmetric(horizontal: 50.0, vertical: 220.0),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20.0), color: Colors.white),
            child: Scaffold(
              backgroundColor: Colors.transparent,
              body: Container(
                  margin:
                      EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          margin: EdgeInsets.symmetric(vertical: 10.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Text(
                                Language().getString(
                                    Constants.ADD_RAW_MATERIAL, selectedLang),
                                style: TextStyle(
                                    color: theme.colorScheme.primary,
                                    fontSize: 15.0,
                                    fontWeight: FontWeight.bold),
                              ),
                              GestureDetector(
                                onTap: () {
                                  Navigator.of(context).pop();
                                },
                                child: Icon(
                                  Icons.close,
                                  color: Colors.red,
                                ),
                              ),
                            ],
                          ),
                        ),
                        if (CommonMethods.isPrivillegeExist(context,
                            PrivillegesActions.RAW_MATERIAL_MENU_RAW_MATERIALS_ADD_PRODUCT_TO_BU))
                          Container(
                            margin: EdgeInsets.symmetric(vertical: 5.0),
                            child: Container(
                              width: MediaQuery.of(context).size.width,
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  shape: RoundedRectangleBorder(
                                    borderRadius:
                                        new BorderRadius.circular(10.0),
                                  ),
                                  backgroundColor: theme.colorScheme.primary,
                                  textStyle: TextStyle(
                                      color: Colors.white,
                                      fontFamily: StyleView.FONT_TITLE,
                                      fontWeight: StyleView.fontMedium),

                                  // elevation: 3.0,
                                ),
                                onPressed: () {
                                  Navigator.of(context).pop();
                                  Navigator.push(
                                      context,
                                      PageTransition(
                                        context: context,
                                        page: EditMyProductPage(
                                            title: Constants.ADD_PRODUCT,
                                            buId: buId,
                                            isFromRawMaterialPage: true,
                                            rawMaterialTitle:
                                                Constants.ADD_RAW_MATERIAL),
                                      )).then((value) => loadProductData());
                                },
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Text(
                                    Language().getString(Constants.CREATE_FOR,
                                            selectedLang) +
                                        " " +
                                        AppController.instance.getBuName,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        if (CommonMethods.isPrivillegeExist(
                            context,
                            PrivillegesActions
                                .RAW_MATERIAL_MENU_RAW_MATERIALS_ADD_PRODUCTS_BY_BULK_UPLOAD))
                          Container(
                            width: MediaQuery.of(context).size.width,
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                shape: RoundedRectangleBorder(
                                  borderRadius: new BorderRadius.circular(10.0),
                                ),
                                backgroundColor: theme.colorScheme.primary,
                                textStyle: TextStyle(
                                    color: Colors.white,
                                    fontFamily: StyleView.FONT_TITLE,
                                    fontWeight: StyleView.fontMedium),
                                // elevation: 3.0,
                              ),
                              onPressed: () async {
                                Navigator.of(context).pop();
                                // if (kIsWeb) {
                                //   _launchURL(Constants
                                //           .BULK_RAW_PRODUCT_UPLOAD_URL +
                                //       "$buId/${AppController.instance.authorizationKey}");
                                // } else {
                                //   await launch(Constants
                                //           .BULK_RAW_PRODUCT_UPLOAD_URL +
                                //       "$buId/${AppController.instance.authorizationKey}");
                                // }
                              },
                              child: Padding(
                                padding: EdgeInsets.symmetric(vertical: 15),
                                child: Text(
                                  Language().getString(
                                      Constants.PRODUCTS_IN_BUILK,
                                      selectedLang),
                                ),
                              ),
                            ),
                          ),
                      ])),
            ),
          );
        });
  }
}
