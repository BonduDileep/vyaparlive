import 'dart:convert';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:flutter/material.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:flutx/flutx.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/DateFilterUtil.dart';
import 'package:vyaparlive/components/MyDrawer.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/RawMaterialTemplateDAO.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:vyaparlive/product_consumption_view/raw_material_view/CreateTemplate.dart';
import 'package:vyaparlive/service/product_services.dart';

import '../../core/enums/privilleges_enum.dart';

class ConfigureRawTemplate extends StatefulWidget {
  @override
  _ConfigureRawTemplateState createState() => _ConfigureRawTemplateState();
}

class _ConfigureRawTemplateState extends State<ConfigureRawTemplate> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? buName = "", buId = "", userName = "", userId = "";
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  late ProductService _productService;
  List<RawMaterialTemplateDAO> _templatesList = [];
  String startDate = "";
  String endDate = "";
  DateFormat formatter = DateFormat("yyyy-MM-dd");
  DateTime mnthStartDate =
      DateTime.utc(DateTime.now().year, DateTime.now().month, 1);
  final _searchController = TextEditingController();
  bool isEnableDateFilter = true;
  bool isShowFloatButton = false;
  static String showLoaderText = Constants.NO_DATA_FOUND;
  bool isSearchForParams = false;
  late ThemeData theme;
  late TextEditingController fromDateController = TextEditingController();
  late TextEditingController toDateController = TextEditingController();
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _productService = ProductService();
    buName = AppController.instance.getBuName;
    buId = AppController.instance.getMyBuId;
    startDate = formatter.format(mnthStartDate);
    endDate = formatter.format(DateTime.now());
    fromDateController.text = startDate;
    toDateController.text = endDate;
    loadTemplateData();
  }

  loadTemplateData(
      {String startDate = "", String endDate = "", String name = ""}) async {
    if (await NetworkStatus.getInternetStatus()) {
      if (!isSearchForParams) {
        setState(() {
          isLoadingProgress = true;
        });
      }
      getAllTemplatesData(name: name).then((value) {
        if (value.length > 0) {
          _templatesList.clear();
          _templatesList.addAll(value);
        } else {
          showLoaderText = Constants.NO_DATA_FOUND;
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
      body: WillPopScope(
          child: Stack(
            children: [
              SafeArea(
                child: Scaffold(
                    key: _scaffoldkey,
                    backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                    appBar: AppBar(
                      centerTitle: true,
                      elevation: 0,
                      iconTheme: IconThemeData(color: theme.colorScheme.primary),
                      backgroundColor:
                          Colors.transparent, //(Constants.APP_COLOR),
                      title: AppbarName(
                          title: Language().getString(
                              Constants.REQUEST_FORM_TEMPLATE, selectedLang),
                          buName: buName),
                      actions: [
                        if (CommonMethods.isPrivillegeExist(
                            context,
                            PrivillegesActions
                                .RAW_MATERIAL_MENU_RAW_MATERIAL_CONFIGURE_REQUEST_FORM_ADD))
                          IconButton(
                              onPressed: () {
                                Navigator.push(
                                        context,
                                        PageTransition(
                                            context: context,
                                            page: CreateTemplatePgae()))
                                    .then((value) => this.loadTemplateData(
                                        startDate: startDate, endDate: endDate));
                              },
                              icon: Icon(Icons.add))
                      ],
                    ),
                    floatingActionButton: (isShowFloatButton)
                        ? FloatingActionButton(
                            backgroundColor: theme.colorScheme.primary,
                            onPressed: () {
                              setState(() {
                                isShowFloatButton = false;
                                isLoadingProgress = true;
                              });
                
                              fromDateController.text = startDate;
                              toDateController.text = endDate;
                              loadTemplateData();
                            },
                            child: Text(
                              Language().getString(
                                  Constants.CLEAR_FILTERS, selectedLang),
                              textAlign: TextAlign.center,
                              style:
                                  TextStyle(color: Colors.white, fontSize: 11.0),
                            ))
                        : null,
                    drawer: MyDrawer(),
                    body: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        children: [
                          FxSpacing.height(10),
                          buildSearchFilterView(),
                          // (isEnableDateFilter)
                          //     ?
                          Padding(
                            padding:
                                const EdgeInsets.only(top: 10, left: 5, right: 5),
                            child: DateFilterUtill(
                              isShowSearchButton: true,
                              fromDate: "",
                              toDate: "",
                              fromDateController: fromDateController,
                              toDateController: toDateController,
                              onFromDateSelected: (value) {
                                setState(() {
                                  fromDateController.text = value;
                                });
                              },
                              onToDateSelected: (value) {
                                setState(() {
                                  toDateController.text = value;
                                });
                              },
                              onSearchParms: () {
                                setState(() {
                                  isShowFloatButton = true;
                                  isLoadingProgress = true;
                                });
                
                                loadTemplateData();
                              },
                            ),
                          ),
                          // : Container(),
                          FxSpacing.height(10),
                          (_templatesList.length > 0)
                              ? Expanded(
                                  child: AnimationLimiter(
                                    child: ListView.separated(
                                      shrinkWrap: true,
                                      physics: new AlwaysScrollableScrollPhysics(
                                          parent: new BouncingScrollPhysics()),
                                      separatorBuilder: (context, index) =>
                                          new Divider(
                                        height: 10,
                                        color: Colors.transparent,
                                      ),
                                      itemBuilder: (context, index) =>
                                          AnimationConfiguration.staggeredList(
                                              position: index,
                                              duration:
                                                  Duration(milliseconds: 900),
                                              child: SlideAnimation(
                                                  verticalOffset: 50.0,
                                                  child: FadeInAnimation(
                                                      child:
                                                          buildCardView(index)))),
                                      itemCount: _templatesList.length,
                                    ),
                                  ),
                                )
                              : Container(
                                  child: Center(
                                    child: Text(Language()
                                        .getString(showLoaderText, selectedLang)),
                                  ),
                                ),
                        ],
                      ),
                    )),
              ),
              AppUtills.showLoadingView(
                  context: context,
                  message: Language().getString(progressMessage, selectedLang),
                  isLoading: isLoadingProgress),
            ],
          ),
          onWillPop: () {
            return CommonMethods.onBackPress(context).then((value) => value);
          }),
    );
  }

  Future<List<RawMaterialTemplateDAO>> getAllTemplatesData(
      {String startDate = "", String endDate = "", String name = ""}) async {
    setState(() {
      _templatesList.clear();
    });
    String body = json.encode({
      "bu": buId,
      "filters": {
        "DateFrom": fromDateController.text,
        "DateTo": toDateController.text,
        "name": name
      }
    });
    var response = await _productService
        .getRawTemplatesByBuId(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    List<RawMaterialTemplateDAO> _list = [];
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(resObj)) {
        var resultArray = resObj['results'];
        if (resultArray.length > 0) {
          for (var obj in resultArray) {
            _list.add(RawMaterialTemplateDAO.fromJson(obj));
          }
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return _list;
  }

  Widget buildCardView(int index) {
    return Container(
      child: Card(
          elevation: 5,
          shadowColor: theme.colorScheme.primary,
          shape: new RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(5),
              side: new BorderSide(
                  color: theme.colorScheme.primary, strokeAlign: 0.02)),
          child: Padding(
            padding: const EdgeInsets.only(bottom: 10,top: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.only(left: 8),
                    child: Text(
                      _templatesList[index].templateName!,
                      style: TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                          fontWeight: StyleView.fontMedium),
                    ),
                  ),
                ),
                if (CommonMethods.isPrivillegeExist(
                    context,
                    PrivillegesActions
                        .RAW_MATERIAL_MENU_RAW_MATERIAL_CONFIGURE_REQUEST_FORM_TEMPLATE_EDIT))
                  IconButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            PageTransition(
                                context: context,
                                page: CreateTemplatePgae(
                                  modelData: _templatesList[index],
                                  updateTemplate: true,
                                  templateId: _templatesList[index].templateId,
                                )));
                      },
                      icon: Icon(
                        FeatherIcons.edit,
                        color: theme.colorScheme.primary,
                      ))
              ],
            ),
          )),
    );
  }

  Widget buildSearchFilterView() {
    return Container(
      height: 50,
      child: Card(
        elevation: 5,
        shape: new RoundedRectangleBorder(
            borderRadius: new BorderRadius.circular(15),
            side: new BorderSide(
                color: theme.colorScheme.primary, strokeAlign: 0.02)),
        child: Row(
          children: [
            Expanded(
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: TextFormField(
                  style: TextStyle(fontWeight: StyleView.fontSemiBold),
                  controller: _searchController,
                  decoration: InputDecoration(
                      contentPadding: EdgeInsets.only(bottom: 10),
                      border: InputBorder.none,
                      hintText: Language()
                          .getString(Constants.SEARCH_BY_NAME, selectedLang),
                      hintStyle: TextStyle(
                          fontSize: 13.0, fontWeight: StyleView.fontSemiBold)),
                  onChanged: onChangeText,
                ),
              ),
            ),
            (_searchController.text.isNotEmpty)
                ? Container(
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                          topRight: Radius.circular(5.0),
                          bottomRight: Radius.circular(5.0),
                        )),
                    child: IconButton(
                        icon: Icon(
                          Icons.close,
                          color: Colors.red,
                        ),
                        onPressed: () {
                          CommonMethods.hideKeyboard(context);
                          _searchController.clear();
                          onChangeText(_searchController.text);
                        }),
                  )
                : Container()
          ],
        ),
      ),
    );
  }

  onChangeText(String text) {
    showLoaderText = Constants.LOADING;
    if (text.isEmpty) {
      isSearchForParams = false;
      loadTemplateData(startDate: startDate, endDate: endDate);
    } else {
      isSearchForParams = true;
      loadTemplateData(name: text, startDate: startDate, endDate: endDate);
    }
  }
}
