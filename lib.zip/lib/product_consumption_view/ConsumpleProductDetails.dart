import 'dart:async';
import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Product/TransitDesign.dart';
import 'package:vyaparlive/Product/price_view/PriceDetailsExpandPage.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/TextView.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/PriceModel.dart';
import 'package:vyaparlive/model/ProductAttributeModel.dart';
import 'package:vyaparlive/model/ProductConsumptionDAO.dart';
import 'package:vyaparlive/model/ProductIssueDetailsModel.dart';
import 'package:vyaparlive/model/product_model/InventoryDetailsDAO.dart';
import 'package:vyaparlive/product_consumption_view/issue_details_card_view/IssueDetailsCardView.dart';
import 'package:vyaparlive/service/consumable_product_grpc.dart';

class ConsumableProductDetails extends StatefulWidget {
  final String? productId;

  ConsumableProductDetails({
    this.productId,
  });
  @override
  _ConsumableProductDetailsState createState() =>
      _ConsumableProductDetailsState();
}

class _ConsumableProductDetailsState extends State<ConsumableProductDetails>
    with SingleTickerProviderStateMixin {
  List<ProductAttributeModel> attributesList = [];
  late AnimationController _animationController;
  late Animation _animation;
  String? selectedLang = AppController.instance.getSelectedlanguage; // 'en';
  late SharedPreferences sharedPreferences;
  String? buId = "";
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  List<PriceModel> _priceList = [];
  num totalBatchQuantity = 0;
  late ConsumableGrpcService _consumableGrpcService;
  ProductConsumptionDAO? productData;
  List<ProductIssueDetailsModel> issuedDetailsList = [];
  String? orgCurrencySymbol = "";

  @override
  void initState() {
    super.initState();
    _consumableGrpcService = ConsumableGrpcService();
    buId = AppController.instance.getMyBuId;
    _animationController =
        AnimationController(vsync: this, duration: Duration(seconds: 2));
    _animation = Tween(begin: 50.0, end: 200.0).animate(_animationController)
      ..addStatusListener((state) {
        if (state == AnimationStatus.completed) {
        } else if (state == AnimationStatus.dismissed) {}
      })
      ..addListener(() {
        setState(() {});
      });
    _animationController.forward();
    loadProductData();
    // orgCurrencySymbol = AppController.instance.getBuCurrencySymbol;
    String? symbol = AppController.instance.getBuCurrencySymbol;
    orgCurrencySymbol = (symbol != null && symbol.isNotEmpty && symbol!="-") ? symbol : "\u20B9";
  }

  loadProductData() async {
    if (await NetworkStatus.getInternetStatus()) {
      this.getProductDataById().then((value) {
        setState(() {
          productData = value;
          if (productData != null) {
            for (int p = 0; p < productData!.batchPrice!.length; p++) {
              totalBatchQuantity =
                  totalBatchQuantity + productData!.batchPrice![p].quantity!;
              _priceList.add(PriceModel(
                  batchNumber: productData!.batchPrice![p].batchNumber,
                  currencyName: productData!.batchPrice![p].currencyName,
                  expireDate: productData!.batchPrice![p].expiryDate,
                  manufacturDate: productData!.batchPrice![p].manufactureDate,
                  mrp: productData!.batchPrice![p].mrp.toString(),
                  netRate: productData!.batchPrice![p].netRate.toString(),
                  price: productData!.batchPrice![p].price.toString(),
                  priceIn: productData!.batchPrice![p].unitPrice,
                  quantity: productData!.batchPrice![p].quantity.toString(),
                  quantityIn: productData!.batchPrice![p].quantityIn));
            }

            for (int d = 0; d < productData!.issueDetailsData!.length; d++) {
              issuedDetailsList.add(ProductIssueDetailsModel(
                  issuedDate: productData!.issueDetailsData![d].issuedDate,
                  issuedQuantity: productData!
                      .issueDetailsData![d].issuedQuantity
                      .toString(),
                  issuedTo: productData!.issueDetailsData![d].issuedTo,
                  purpose: productData!.issueDetailsData![d].purpose,
                  batchNumber: productData!.issueDetailsData![d].batchNumber,
                  approvedBy: productData!.issueDetailsData![d].approvedBy,
                  remaingQuantity:
                      productData!.issueDetailsData![d].remaingQuantity));
            }
          }
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        SafeArea(
          child: Scaffold(
              key: _scaffoldkey,
              backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
              appBar: AppBar(
                centerTitle: true,
                title: Column(children: <Widget>[
                  Text(
                    Language().getString(Constants.PRODUCT_DETAILS, selectedLang),
                    style: TextStyle(fontSize: 16.0),
                  ),
                  Text(
                    AppController.instance.getBuName,
                    style: TextStyle(fontSize: 15.0),
                  )
                ]),
                actions: <Widget>[
                  AppUtills.homeButton(context),
                ],
                backgroundColor: Color(0xFF083e64),
              ),
              body: (productData == null)
                  ? Text(
                      Language().getString(Constants.NO_DATA_FOUND, selectedLang))
                  : SingleChildScrollView(
                      padding: EdgeInsets.symmetric(horizontal: 5.0),
                      child: Container(
                        color: Colors.white,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Container(
                              width: MediaQuery.of(context).size.width,
                              padding: EdgeInsets.all(10.5),
                              margin: EdgeInsets.symmetric(vertical: 10.5),
                              child: (productData != null &&
                                      productData!.imageThumbnail!.length > 0)
                                  ? Image.network(
                                      Constants.NEW_BASE_URL +
                                          "assets/consumableProduct/buImage/" +
                                          productData!.imageThumbnail![0].image!,
                                      width: _animation.value,
                                      height: _animation.value,
                                      errorBuilder: (BuildContext context,
                                          Object exception,
                                          StackTrace? stackTrace) {
                                        return Image.asset(
                                          'assets/images/empty.jpg',
                                          width: _animation.value,
                                          height: _animation.value,
                                          gaplessPlayback: true,
                                        );
                                      },
                                    )
                                  : Image.asset(
                                      'assets/images/empty.jpg',
                                      width: _animation.value,
                                      height: _animation.value,
                                    ),
                            ),
                            SingleChildScrollView(
                              padding: EdgeInsets.symmetric(horizontal: 5.5),
                              child: Container(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    SizedBox(
                                      height: StyleView.HEIGHT_5,
                                    ),
                                    SizedBox(
                                      height: 10.0,
                                    ),
                                    Container(
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: <Widget>[
                                          Container(
                                            child: Row(children: <Widget>[
                                              Container(
                                                child: Text(
                                                  productData!.name!,
                                                  style: TextStyle(
                                                      fontSize: 17.0,
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),
                                              ),
                                            ]),
                                          ),
                                          Container(
                                            child: Column(children: <Widget>[
                                              Container(
                                                  child: Text(
                                                "$orgCurrencySymbol " +
                                                    "${productData != null && productData!.batchPrice!.length > 0 ? productData!.batchPrice![0].price : 0}",
                                                style: TextStyle(
                                                    fontSize: 14.0,
                                                    fontWeight: FontWeight.bold),
                                              )),
                                            ]),
                                          )
                                        ],
                                      ),
                                    ),
                                    SizedBox(height: 20.0),
                                    Container(
                                        child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: <Widget>[
                                          this.mainText(Constants.ATTRIBUTES),
                                          Container(
                                            margin: EdgeInsets.symmetric(
                                                vertical: 5.0),
                                            child: SingleChildScrollView(
                                              scrollDirection: Axis.horizontal,
                                              child: Row(
                                                children: <Widget>[
                                                  for (int i = 0;
                                                      i <
                                                          productData!
                                                              .attributesList!
                                                              .length;
                                                      i++)
                                                    Container(
                                                        margin:
                                                            EdgeInsets.symmetric(
                                                                horizontal: 5.0),
                                                        child: Card(
                                                          elevation: 3.0,
                                                          shape:
                                                              RoundedRectangleBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        50.0),
                                                          ),
                                                          child: Container(
                                                            decoration: BoxDecoration(
                                                                border: Border.all(
                                                                    color: Colors
                                                                            .grey[
                                                                        400]!),
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            50.0)),
                                                            padding:
                                                                EdgeInsets.all(
                                                                    8.0),
                                                            child: Text(
                                                              "${productData!.attributesList![i].entries.toList()[0].key} : " +
                                                                  "${productData!.attributesList![i].entries.toList()[0].value}",
                                                              style: TextStyle(
                                                                  fontSize: 14.0,
                                                                  color: Colors
                                                                      .grey[700]),
                                                            ),
                                                          ),
                                                        )),
                                                ],
                                              ),
                                            ),
                                          )
                                        ])),
                                    SizedBox(height: 10.0),
                                    mainText(Constants.PRODUCTDETAILS),
                                    SizedBox(height: 10),
                                    Container(
                                        child: Column(
                                      children: <Widget>[
                                        productDetilsNewDesign(
                                            Constants.BRAND, productData!.brand!),
                                        productDetilsNewDesign(
                                            Constants.MODEL,
                                            productData!.manufactureDetails!
                                                .modelNumber!),
                                        productDetilsNewDesign(
                                            Constants.DESCRIPTION_STRING,
                                            productData!.description!),
                                        productDetilsNewDesign(
                                            Constants.PRODUCT_SEGMENT,
                                            productData!.productSegment != null
                                                ? productData!.productSegment!
                                                : ""),
                                        productDetilsNewDesign(
                                            Constants.PRODUCT_CATEGORY,
                                            productData!.productCategory != null
                                                ? productData!.productCategory!
                                                : ""),
                                        productDetilsNewDesign(
                                            Constants.PRODUCT_SUB_CATEGORY,
                                            productData!.productSubCategory !=
                                                    null
                                                ? productData!.productSubCategory!
                                                : "")
                                      ],
                                    )),
                                    SizedBox(
                                      height: StyleView.HEIGHT_20,
                                    ),
                                    mainText(Constants.MANUFACTURER_DETAILS),
                                    SizedBox(
                                      height: StyleView.HEIGHT_5,
                                    ),
                                    Container(
                                        // margin: EdgeInsets.only(left: 15.0),
                                        child: Column(children: <Widget>[
                                      productDetilsNewDesign(
                                        Constants.MANUFACTURER_NAME,
                                        productData!.manufactureDetails!.name !=
                                                null
                                            ? productData!
                                                .manufactureDetails!.name!
                                            : "",
                                      ),
                                      productDetilsNewDesign(
                                          Constants.MANUFACTURER_ADDRESS,
                                          productData!.manufactureDetails!
                                              .manufacturerAddress!),
                                      productDetilsNewDesign(Constants.PLOT_NO,
                                          productData!.manufactureDetails!.area!),
                                      productDetilsNewDesign(
                                          Constants.BULIDING,
                                          productData!
                                              .manufactureDetails!.buildiName!),
                                      productDetilsNewDesign(
                                          Constants.BUILDING_STREET_NAME_STRING,
                                          productData!
                                              .manufactureDetails!.landmark!),
                                      productDetilsNewDesign(
                                          Constants.COUNTRY_NAME_STRING,
                                          productData!
                                              .manufactureDetails!.country!),
                                      productDetilsNewDesign(
                                          Constants.STATE_NAME_STRING,
                                          productData!
                                              .manufactureDetails!.state!),
                                      productDetilsNewDesign(
                                          Constants.DISTRICT_STRING,
                                          productData!
                                              .manufactureDetails!.district!),
                                      productDetilsNewDesign(
                                          Constants.CITY_NAME_STRING,
                                          productData!.manufactureDetails!.city!),
                                      productDetilsNewDesign(Constants.PIN_CODE,
                                          productData!.manufactureDetails!.pin!),
                                    ])),
                                    SizedBox(height: 10.0),
                                    mainText(Constants.ITEM_DETAILS),
                                    SizedBox(
                                      height: StyleView.HEIGHT_5,
                                    ),
                                    Container(
                                        // margin: EdgeInsets.only(left: 15.0),
                                        child: Column(children: <Widget>[
                                      productDetilsNewDesign(Constants.HEIGHT,
                                          productData!.shippingDetails!.height!),
                                      productDetilsNewDesign(Constants.WIDTH,
                                          productData!.shippingDetails!.width!),
                                      productDetilsNewDesign(Constants.DEPTH,
                                          productData!.shippingDetails!.depth!),
                                      productDetilsNewDesign(Constants.VOLUME,
                                          productData!.shippingDetails!.volume!),
                                      productDetilsNewDesign(Constants.WEIGHT,
                                          productData!.shippingDetails!.weight!),
                                    ])),
                                    SizedBox(height: 10.0),
                                    mainText(Constants.TOTAL_QUANTITY_STRING),
                                    productDetilsNewDesign(
                                        Constants.TOTAL_QUANTITY_STRING,
                                        "$totalBatchQuantity"),
                                    mainText(Constants.PRICE_DETAILS),
                                    (_priceList.length > 0)
                                        ? createPriceDetailsDynamic()
                                        : Container(
                                            margin: EdgeInsets.symmetric(
                                                vertical: 5.0)),
                                    SizedBox(
                                      height: StyleView.HEIGHT_20,
                                    ),
                                    SizedBox(
                                      height: StyleView.HEIGHT_20,
                                    ),
                                    Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceBetween,
                                              children: <Widget>[
                                                mainText(Constants
                                                    .AVAILABLE_LOCATIONS),
                                              ],
                                            ),
                                          ),
                                          SizedBox(
                                            height: StyleView.HEIGHT_10,
                                          ),
                                          Container(
                                            child: productData!
                                                        .inventoryData!.length ==
                                                    0
                                                ? new Container(
                                                    child: Center(
                                                      child: Text(Language()
                                                          .getString(
                                                              Constants
                                                                  .NO_DETAILS,
                                                              selectedLang)),
                                                    ),
                                                  )
                                                : _createDynamicInventoryTable(),
                                          ),
                                        ]),
                                    SizedBox(
                                      height: StyleView.HEIGHT_10,
                                    ),
                                    Container(
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: <Widget>[
                                          mainText(Constants.AVAILABLE_LOCATIONS),
                                        ],
                                      ),
                                    ),
                                    SizedBox(
                                      height: StyleView.HEIGHT_10,
                                    ),
                                    Container(
                                      child: (issuedDetailsList.length == 0)
                                          ? null
                                          : onCreateDynamicProductIssueList(),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            SizedBox(
                              height: StyleView.HEIGHT_5,
                            ),
                          ],
                        ),
                      ))),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    );
  }

  Widget createPriceDetailsDynamic() {
    return Column(children: <Widget>[
      for (int i = 0; i < _priceList.length; i++) this.showPriceExpandView(i)
    ]);
  }

  Widget showPriceExpandView(int index) {
    return Container(
      margin: EdgeInsets.symmetric(
        vertical: 5.0,
      ),
      child: Column(
        children: <Widget>[
          PriceDetailsExpandPage(
            priceModel: _priceList[index],
            strQuantity: Language().getString(Constants.QUANTITY, selectedLang),
            strQuantityIn:
                Language().getString(Constants.QUANTITY_IN, selectedLang),
            strBatchNumber:
                Language().getString(Constants.BATCH_NO, selectedLang),
            strCurrencyName:
                Language().getString(Constants.CURRENCY_NAME, selectedLang),
            strExpireDate:
                Language().getString(Constants.EXPIRE_DATE_STR, selectedLang),
            strManufactureDate:
                Language().getString(Constants.MANUFACTURE_DATE, selectedLang),
            strMrp: Language().getString(Constants.MRP, selectedLang),
            strNetRate: Language().getString(Constants.NET_RATE, selectedLang),
            strPrice: Language().getString(Constants.PRICE, selectedLang),
            strUnitPrice:
                Language().getString(Constants.PRICE_UNIT, selectedLang),
            title: _priceList[index].batchNumber,
            isEdit: false,
            editPage: () {},
            removeItem: () async {
              final action = await Dialogs.removeItem(
                context,
                " ${_priceList[index].batchNumber}",
                Language().getString(Constants.WARNING, selectedLang),
                Language().getString(Constants.WARNING_TEXT, selectedLang),
                cancel:
                    Language().getString(Constants.STR_CANCEL, selectedLang),
                yes: Language().getString(Constants.YES_STRING, selectedLang),
              );

              if (action == DialogAction.yes) {
                setState(() {
                  _priceList.removeAt(index);
                });
              }
            },
          ),
        ],
      ),
    );
  }

  mainText(String text) {
    return Container(
        child: Text(
      Language().getString(text, selectedLang),
      style: TextStyle(
          fontSize: 15.0,
          letterSpacing: 2.0,
          fontFamily: "Montserrat",
          color: Colors.grey[800],
          fontWeight: FontWeight.bold),
    ));
  }

  productDetilsNewDesign(String text, String content) {
    return Container(
        margin: EdgeInsets.symmetric(vertical: 7.0),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                child: Text(
                  Language().getString(text, selectedLang),
                  style: TextStyle(fontSize: 14.0, color: Colors.grey[800]),
                ),
              ),
            ),
            Expanded(
              child: Container(
                  margin: EdgeInsets.symmetric(horizontal: 10.0),
                  child: Text(
                    ":  " + content,
                    style: TextStyle(fontSize: 14.0, color: Colors.grey[800]),
                  )),
            )
          ],
        ));
  }

  _createDynamicInventoryTable() {
    return Column(children: <Widget>[
      for (int i = 0; i < productData!.inventoryData!.length; i++)
        Column(
          children: <Widget>[
            SizedBox(height: 5.0),
            Container(
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    border: Border.all(color: Colors.grey)),
                child: ExpansionTile(
                  title: Text(
                    Language().getString(Constants.LOCATION, selectedLang) +
                        " : ${i + 1}",
                    style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                        fontFamily: StyleView.FONT_TITLE),
                  ),
                  children: <Widget>[
                    _buildListInventoryItem(productData!.inventoryData![i]),
                    for (int j = 0;
                        j < productData!.inventoryData![i].transitData!.length;
                        j++)
                      TransitCardDesign(
                        invoiceNo: productData!
                            .inventoryData![i].transitData![j].billNo
                            .toString(),
                        quantity: productData!
                            .inventoryData![i].transitData![j].quantity
                            .toString(),
                        onPress: () {},
                      )
                  ],
                ))
          ],
        )
    ]);
  }

  _buildListInventoryItem(InventoryDetailsDAO inventoryModel) {
    return Container(
        child: Container(
            padding: EdgeInsets.all(1),
            child: Column(
              children: <Widget>[
                TextView(
                  title: Constants.LOCATION_NAME,
                  value: inventoryModel.locationName,
                ),
                SizedBox(
                    height: 1,
                    child: new Container(color: Color(Constants.GREY_COLOR))),
                TextView(
                  title: Constants.QUANTITY,
                  value: "${inventoryModel.quantity}",
                )
              ],
            )));
  }

  buildTableListRowContent(String textName, textFormName) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Expanded(
              flex: 3,
              child: Container(
                  child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(textName,
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_15,
                            fontFamily: 'IndianRupee'))),
              )),
            ),
            Container(
              child: Text(':'),
            ),
            Expanded(
                flex: 5,
                child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5),
                  child: Text(
                    textFormName,
                  ),
                ))
          ],
        ));
  }

  Future<ProductConsumptionDAO> getProductDataById() async {
    setState(() {
      isLoadingProgress = true;
    });
    String body = json.encode({"bu_id": buId, "id": widget.productId});
    var response = await _consumableGrpcService
        .getProductListById(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    ProductConsumptionDAO modelData = ProductConsumptionDAO();
    GRPCResponse _grpcRespone = response;
    if (!_grpcRespone.getIsError! && !_grpcRespone.getIsException!) {
      var reqData = json.decode(_grpcRespone.message!);

      modelData = ProductConsumptionDAO.fromJson(reqData[0]);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcRespone.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return modelData;
  }

  onCreateDynamicProductIssueList() {
    return Column(children: <Widget>[
      for (int i = 0; i < issuedDetailsList.length; i++)
        Container(
          margin: EdgeInsets.symmetric(
            vertical: 5.0,
          ),
          child: Column(children: <Widget>[
            IssueDetailsCardPage(
              title: Language().getString(Constants.APPROVED_BY, selectedLang) +
                  " : ${issuedDetailsList[i].approvedBy}",
              modelDate: issuedDetailsList[i],
              onEditDetails: () {},
              onRemoveItem: () async {
                final action = await Dialogs.removeItem(
                  context,
                  issuedDetailsList[i].approvedBy,
                  Language().getString(Constants.WARNING, selectedLang),
                  Language().getString(Constants.WARNING_TEXT, selectedLang),
                  cancel:
                      Language().getString(Constants.STR_CANCEL, selectedLang),
                  yes: Language().getString(Constants.YES_STRING, selectedLang),
                );
                if (action == DialogAction.yes) {
                  setState(() {
                    issuedDetailsList.removeAt(i);
                  });
                }
              },
            )
          ]),
        ),
    ]);
  }
}
