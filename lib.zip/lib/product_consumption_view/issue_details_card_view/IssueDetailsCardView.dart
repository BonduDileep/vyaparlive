import 'package:flutter/material.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/TextView.dart';
import 'package:vyaparlive/model/ProductIssueDetailsModel.dart';

class IssueDetailsCardPage extends StatelessWidget {
  final String? title;
  final VoidCallback? onEditDetails;
  final ProductIssueDetailsModel? modelDate;
  final VoidCallback? onRemoveItem;
  final bool isFromDetailsPage;
  IssueDetailsCardPage(
      {this.onEditDetails,
      this.title,
      this.modelDate,
      this.onRemoveItem,
      this.isFromDetailsPage = false});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          flex: 10,
          child: Container(
              decoration: AppUtills.boxDecoration(),
              child: ExpansionTile(
                title: Row(children: [
                  Expanded(
                    child: Text(
                      title!,
                      style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                    ),
                  ),
                  (isFromDetailsPage)
                      ? new Container(
                          child: InkWell(
                              child: Icon(Icons.edit,
                                  color: Color(Constants.APP_COLOR)),
                              onTap: () => onEditDetails!()))
                      : Container(),
                ]),
                children: <Widget>[
                  showProductIssuedDetails(modelDate!),
                ],
              )),
        ),
        (isFromDetailsPage)
            ? Expanded(
                child: IconButton(
                    icon: Icon(
                      Icons.remove_circle_outline,
                      color: Colors.red,
                    ),
                    onPressed: () => onRemoveItem!()))
            : Container()
      ],
    );
  }

  showProductIssuedDetails(ProductIssueDetailsModel modelData) {
    return Container(
        child: Container(
            padding: EdgeInsets.all(1),
            child: Column(
              children: <Widget>[
                SizedBox(
                    height: 1,
                    child: new Container(color: Color(Constants.GREY_COLOR))),
                TextView(
                  title: Constants.ISSUED_DATE,
                  value: modelData.issuedDate,
                ),
                SizedBox(
                    height: 1,
                    child: new Container(color: Color(Constants.GREY_COLOR))),
                TextView(
                  title: Constants.ISSUED_TO,
                  value: modelData.issuedTo,
                ),
                SizedBox(
                    height: 1,
                    child: new Container(color: Color(Constants.GREY_COLOR))),
                TextView(
                  title: Constants.PURPOSE,
                  value: modelData.purpose,
                ),
                SizedBox(
                    height: 1,
                    child: new Container(color: Color(Constants.GREY_COLOR))),
                TextView(
                  title: Constants.ISSUED_QUANTITY,
                  value: modelData.issuedQuantity,
                ),
                SizedBox(
                    height: 1,
                    child: new Container(color: Color(Constants.GREY_COLOR))),
                TextView(
                  title: Constants.BATCH_NO,
                  value: modelData.batchNumber,
                ),
                SizedBox(
                    height: 1,
                    child: new Container(color: Color(Constants.GREY_COLOR))),
                TextView(
                  title: Constants.DEPARTMENT,
                  value: modelData.department,
                ),
              ],
            )));
  }
}
