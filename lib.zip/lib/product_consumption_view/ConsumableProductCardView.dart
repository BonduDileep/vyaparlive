import 'package:flutter/material.dart';
import 'package:vyaparlive/Product/products_widget/PopupMenuItemDesign.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/model/ProductConsumptionDAO.dart';

class ConsumableProductCardPage extends StatelessWidget {
  final ProductConsumptionDAO? productData;
  final num? batchQuantity;
  final VoidCallback? onEdit;
  final VoidCallback? onDetails;
  final List<Map>? mapData;
  ConsumableProductCardPage(
      {this.productData,
      this.batchQuantity,
      this.onDetails,
      this.onEdit,
      this.mapData});
  @override
  Widget build(BuildContext context) {
    // String? orgCurrencySymbol = AppController.instance.getBuCurrencySymbol;
    String? symbol = AppController.instance.getBuCurrencySymbol;
    String orgCurrencySymbol = (symbol != null && symbol.isNotEmpty && symbol!="-") ? symbol : "\u20B9";
    return Card(
        child: Container(
      decoration: BoxDecoration(border: Border.all(color: Colors.black26)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Expanded(
              flex: 2,
              child: Row(
                children: <Widget>[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Card(
                        elevation: 1.5,
                        child: Container(
                            padding: EdgeInsets.all(5.5),
                            margin: EdgeInsets.all(2.5),
                            child: (productData!.imageThumbnail!.length > 0)
                                ? Image.network(
                                    Constants.NEW_BASE_URL +
                                        "assets/consumableProduct/buImage/" +
                                        productData!.imageThumbnail![0].image!,
                                    headers: {
                                      'Content-type': 'application/json',
                                      'Accept': 'application/json',
                                      'authorization': AppController
                                          .instance.getAuthorizationKey
                                    },
                                    width: 40,
                                    height: 40,
                                    gaplessPlayback: true,
                                    errorBuilder: (BuildContext context,
                                        Object exception,
                                        StackTrace? stackTrace) {
                                      return Image.asset(
                                        'assets/images/empty.jpg',
                                        width: 40,
                                        height: 40,
                                        gaplessPlayback: true,
                                      );
                                    },
                                  )
                                : Image.asset(
                                    'assets/images/empty.jpg',
                                    width: 40,
                                    height: 40,
                                  )),
                      ),
                    ],
                  ),
                ],
              )),
          Expanded(
            flex: 5,
            child: Column(
              // mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                new Container(
                  margin: EdgeInsets.symmetric(
                    vertical: 5.0,
                  ),
                  child: Text(
                    "${productData!.name}",
                    style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                        fontWeight: FontWeight.bold,
                        fontSize: 17),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Row(
                  children: <Widget>[
                    Expanded(
                      flex: 1,
                      child: new Container(
                        child: Text(
                          mapData![0]['name'] +
                              (" : $orgCurrencySymbol ${productData!.batchPrice!.length > 0 ? productData!.batchPrice![0].price : 0}") +
                              " | " +
                              mapData![1]['name'] +
                              (" : $batchQuantity") +
                              ("  ${productData!.batchPrice!.length > 0 ? productData!.batchPrice![0].quantityIn : ""}"),
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 13,
                              fontWeight: FontWeight.w600),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Expanded(child: this.showPopupMenuItems())
        ],
      ),
    ));
  }

  Widget showPopupMenuItems() {
    return Container(
      child: PopupMenuButton(
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(10.0))),
          onSelected: (dynamic value) {
            switch (value) {
              case Constants.DETAILS:
                onDetails!();
                break;
              case Constants.EDIT:
                onEdit!();

                break;
              default:
            }
          },
          icon: Icon(Icons.more_vert),
          itemBuilder: (context) => [
                PopupMenuItem(
                    child: PopupMenuItemDesingView(
                      assetPath: "assets/images/edit_image.png",
                      itemName: mapData![2]['name'],
                    ),
                    value: Constants.EDIT),
                PopupMenuItem(
                  child: PopupMenuItemDesingView(
                    assetPath: "assets/images/product_details_icon.png",
                    itemName: mapData![3]['name'],
                  ),
                  value: Constants.DETAILS,
                ),
              ]),
    );
  }
}
