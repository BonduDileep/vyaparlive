import 'dart:convert';

import 'package:vyaparlive/animations/SvgIcons.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/login_view/controller/invitation_code_accept_controller.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/service/invitation_services.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutx/flutx.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../components/AppController.dart';

class InvitationCodeAccept extends StatefulWidget {
  const InvitationCodeAccept({super.key});

  @override
  State<InvitationCodeAccept> createState() => _InvitationCodeAcceptState();
}

class _InvitationCodeAcceptState extends State<InvitationCodeAccept> {
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  late ThemeData theme;
  late InvitationCodeAcceptController _invitationCodeAcceptController;
  late InvitationService _invitationService;
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _invitationCodeAcceptController =
        FxControllerStore.putOrFind(InvitationCodeAcceptController());
    _invitationService = InvitationService();
  }

  Widget renderAcceptInvitation() {
    return Center(
      child: Text(
        Constants.ACCEPT_INVITATION,
        style: TextStyle(
          fontWeight: StyleView.fontRegular,
          fontSize: 17.0,
          color: theme.colorScheme.primary,
        ),
      ),
    );
  }

  Widget renderMobileNumberInputField() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10.0),
      child: new TextFormField(
          controller: _invitationCodeAcceptController.mobileNumber,
          keyboardType: (defaultTargetPlatform == TargetPlatform.iOS)
              ? TextInputType.numberWithOptions(signed: true, decimal: false)
              : TextInputType.number,
          style: TextStyle(fontWeight: StyleView.fontMedium, fontSize: 15.0),
          textInputAction: TextInputAction.next,
          decoration: CommonMethods.textFieldDecorationTheme(
              Language().getString(Constants.MOBILE_NUMBER, selectedLang),
              prefixIcon: FeatherIcons.phone),
          maxLines: 1,
          onChanged: (text) =>
              _invitationCodeAcceptController.mobileNumber.text,
          inputFormatters: [
            new LengthLimitingTextInputFormatter(10),
            CommonMethods.inputTextFormatter(isNumber: true)
          ]),
    );
  }

  Widget renderInvitationCodeInputField() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10.0),
      child: new TextFormField(
        controller: _invitationCodeAcceptController.invitationCode,
        style: TextStyle(fontWeight: StyleView.fontMedium, fontSize: 15.0),
        keyboardType: (defaultTargetPlatform == TargetPlatform.iOS)
            ? TextInputType.numberWithOptions(signed: true, decimal: false)
            : TextInputType.number,
        textInputAction: TextInputAction.done,
        decoration: CommonMethods.textFieldDecorationTheme(
            Language()
                .getString(Constants.INVITATION_CODE_STRING, selectedLang),
            prefixIcon: FeatherIcons.pieChart),
        onChanged: (text) =>
            _invitationCodeAcceptController.invitationCode.text,
        inputFormatters: [
          // LengthLimitingTextInputFormatter(10),
          CommonMethods.inputTextFormatter(isNumber: true)
        ],
      ),
    );
  }

  Widget renderAlreadyHaveAnAccountString() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10.0),
      child: FxButton.text(
        onPressed: () {
          setState(() {isLoadingProgress = true; progressMessage = Constants.LOADING;});
          Future.delayed(Duration(seconds: 1)).then((value) => {
                isLoadingProgress = false,
                _invitationCodeAcceptController.navigateToLogin(context)
              });
        },
        child: FxText.bodyLarge(
          '${Constants.HAVE_ACCOUNT} ${Constants.CLICK_HERE}',
          style: TextStyle(
              color: Colors.black, //theme.colorScheme.primary,
              // decoration: TextDecoration.underline,
              fontWeight: StyleView.fontRegular),
        ),
      ),
    );
  }

  Widget webLoginUI(BoxConstraints mConstaints) {
    return Center(
      child: Column(
        children: <Widget>[
          Expanded(
            child: Container(
              margin: EdgeInsets.only(top: 20),
              child: SvgPicture.string(
                SvgIcons.app_logo,
                width: MediaQuery.of(context).size.width / 6,
                height: MediaQuery.of(context).size.height * 0.4,
              ),
            ),
          ),
          Expanded(
              child: Container(
            child: Column(
              children: [
                Expanded(
                    child: LayoutBuilder(builder: (context, boxConstraints) {
                  return Container(
                    width: (boxConstraints.maxWidth > 1000)
                        ? MediaQuery.of(context).size.width / 4
                        : MediaQuery.of(context).size.width / 1.5,
                    child: Column(
                      children: <Widget>[
                        renderAcceptInvitation(),
                        FxSpacing.height(10),
                        renderMobileNumberInputField(),
                        FxSpacing.height(10),
                        renderInvitationCodeInputField(),
                        FxSpacing.height(20),
                        renderSubmitInvitationButton(),
                        renderAlreadyHaveAnAccountString(),
                        renderRowWidget()
                      ],
                    ),
                  );
                })),
              ],
            ),
          ))
        ],
      ),
    );
  }

  String validateLoginFields(bool isLogin) {
    if (_invitationCodeAcceptController.mobileNumber.text.isEmpty) {
      return Constants.ENTER_CONTACT_NUMBER;
    }
    // else if (_invitationCodeAcceptController.mobileNumber.text.length != 10) {
    //   return Constants.ENTER_VALID_MOBILE_NUMBER;
    // }

    else if (_invitationCodeAcceptController.invitationCode.text.isEmpty) {
      return Constants.ENTER_INVITATION_CODE;
    } else {
      return "";
    }
  }

  Widget renderSubmitInvitationButton() {
    return CommonButtonsView(
      context: context,
      b1Text: Language().getString(Constants.SUBMIT_STRING, selectedLang),
      b2Text: "",
      // b1Color: Colors.white,
      b1TextColor: Colors.white,
      iconColor: Colors.white,
      onb1Action: () async {
        // _loginController.gotoRegistration(invitationId);

        String message = validateLoginFields(false);
        if (message.isNotEmpty) {
          await Dialogs.yesCancelDialog(
              context,
              Language().getString(Constants.ERROR, selectedLang),
              Language().getString(message, selectedLang),
              Language().getString(Constants.OKAY_STR, selectedLang),
              "",
              false);
        } else {
          if (await NetworkStatus.getInternetStatus()) {
            setState(() {
              isLoadingProgress = true;
              progressMessage = Constants.VALIDATING_INVITATION_CODE;
            });
            onSubmitInvitationCode();
          } else {
            await Dialogs.yesCancelDialog(
                context,
                Language().getString(Constants.NETWORK_ERROR, selectedLang),
                Language().getString(Constants.CHECK_INTERNET, selectedLang),
                Language().getString(Constants.OKAY_STR, selectedLang),
                "",
                false);
          }
        }
      },
    );
  }

  onSubmitInvitationCode() async {
    setState(() {
      isLoadingProgress = true;
    });

    String body = json.encode({
      "contact": _invitationCodeAcceptController.mobileNumber.text,
      "code": _invitationCodeAcceptController.invitationCode.text
    });
    /* service call for validating invitation code */
    var response = await _invitationService
        .acceptInvitationByCode_grpc(body)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var responseBody = json.decode(_grpcResponse.message!);
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          responseBody["message"],
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
      if (action == DialogAction.yes)
        _invitationCodeAcceptController.navigateToRegistration(
            responseBody["id"], context);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message!,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  Widget renderRegistration() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10.0),
      child: FxButton.text(
        onPressed: () {
          setState(() {isLoadingProgress = true; progressMessage = Constants.LOADING;});
          Future.delayed(Duration(seconds: 1)).then((value) {
            setState(() => isLoadingProgress = false);
            _invitationCodeAcceptController.navigateToRegistration("", context);
          });
        },
        child: FxText.bodyLarge(
          Constants.STR_REGISTRATION,
          style:
              TextStyle(color: Colors.black, fontWeight: StyleView.fontMedium),
        ),
      ),
    );
  }

  Widget renderRowWidget() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10),
      alignment: (kIsWeb) ? Alignment.centerRight : Alignment.centerRight,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          renderRegistration(),
          Container(
            color: Colors.black,
            width: 1,
            height: 15,
          ),
          FxButton.text(
              onPressed: () {
                setState(() {
                      isLoadingProgress = true;
                      progressMessage = Constants.LOADING;
                    });
                Future.delayed(Duration(seconds: 1)).then((value) {
                  setState(() => isLoadingProgress = false);
                  _invitationCodeAcceptController.navigateToLogin(context);
                });
              },
              child: Text(
                Constants.LOGIN,
                style: TextStyle(
                    color: Colors.black, fontWeight: StyleView.fontMedium),
              )),
        ],
      ),
    );
  }

  Widget appLoginUI() {
    return Column(
      children: <Widget>[
        Expanded(
            child: Container(
                // color: Colors.yellow,
                child: SvgPicture.string(
          SvgIcons.app_logo,
          alignment: Alignment.bottomCenter,
        ))),
        Expanded(
            child: Container(
          child: Column(
            children: [
              Expanded(
                  child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  renderAcceptInvitation(),
                  FxSpacing.height(10),
                  renderMobileNumberInputField(),
                  FxSpacing.height(15),
                  renderInvitationCodeInputField(),
                  renderAlreadyHaveAnAccountString(),
                  renderSubmitInvitationButton(),
                  renderRowWidget()
                ],
              )),
            ],
          ),
        ))
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
        body: Stack(
      children: [
        SafeArea(
          child: Scaffold(
              extendBodyBehindAppBar: true,
              key: _scaffoldkey,
              backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
              body: (kIsWeb)
                  ? LayoutBuilder(
                      builder:
                          (BuildContext context, BoxConstraints boxConstraints) {
                        return Container(
                            alignment: Alignment.center,
                            height: boxConstraints.maxHeight,
                            child: webLoginUI(boxConstraints));
                      },
                    )
                  : SingleChildScrollView(
                      child: Container(
                          height: MediaQuery.of(context).size.height,
                          margin: EdgeInsets.symmetric(horizontal: 15.0),
                          child: appLoginUI()),
                    )),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    ));
  }
}
