import 'dart:io';

import 'package:vyaparlive/animations/SvgIcons.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/login_view/InvitationCodeAccept.dart';
import 'package:vyaparlive/login_view/controller/login_controller.dart';
import 'package:vyaparlive/login_view/controller/user_roles.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'package:flutx/flutx.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/Dialog.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/core/enums/home_view_enum.dart';
import 'package:vyaparlive/core/locator.dart';
import 'package:vyaparlive/core/view_models/homeview_model.dart';
import 'package:vyaparlive/core/view_models/version_view_model.dart';
import 'package:vyaparlive/login_view/VersionUpdatePage.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:vyaparlive/service/invitation_services.dart';
import 'package:vyaparlive/service/user_services.dart';
import 'dart:convert';
import 'package:vyaparlive/components/privileges/privilege_handler.dart';
import 'package:flutter_svg/flutter_svg.dart';

class LoginPage extends StatefulWidget {
  LoginPage({this.username, this.password, this.isShowBackButton = false});
  final String? username;
  final String? password;
  final bool isShowBackButton;
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  // final _usernamecontroller = TextEditingController();
  // final _passwordcontroller = TextEditingController();
  // final _invitationcodecontroller = TextEditingController();
  // final _contactnumbercontroller = TextEditingController();
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();

  String? username;
  String? password;
  String invitationcode = '';
  String contactnumber = '';
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  String? invitationId = "";

  bool _isHidden = true;
  bool isLoginFieldsVisibility = true;
  bool iscodeFieldsVisibility = false;
  bool isLoading = false;

  late SharedPreferences sharedPreferences;

  HomeViewModel model = HomeViewModel();
  VersionViewModel? _versionViewModel = locator<VersionViewModel>();
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  late UserService _userService;
  late InvitationService _invitationService;
  Color color = const Color(Constants.APP_COLOR);
  late ThemeData theme;
  late LoginController _loginController;
  @override
  void initState() {
    this.clearAppData();
    _userService = UserService();
    _invitationService = InvitationService();
    _loginController = FxControllerStore.putOrFind(LoginController());
    theme = AppTheme.vyaparTheme;
    // this.getLoadLanguage();
  }

  clearAppData() async {
    if (kIsWeb) await CommonMethods.clearAppData(context);
  }

  /// Service call for submit invitation code

  onSubmitInvitationCode() async {
    String contactNumber = _loginController.mobileNumber.text;
    String invitationCode = _loginController.invitationCode.text;

    setState(() {
      isLoading = true;
    });

    String body =
        json.encode({"contact": contactNumber, "code": invitationCode});
    /* service call for validating invitation code */
    var response = await _invitationService
        .acceptInvitationByCode_grpc(body)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoading = false;
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var responseBody = json.decode(_grpcResponse.message!);

      setState(() {
        invitationId = responseBody["id"];
      });

      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          responseBody["message"],
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
      if (action == DialogAction.yes) {
        // this.navigateToRegistration();
        _loginController.gotoRegistration(invitationId);
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message!,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  /// Validating Login fields

  String validateLoginFields(bool isLogin) {
    if (isLogin) {
      if (_loginController.mobileNumber.text.isEmpty) {
        return Constants.ENTER_MOBILE_NUMBER;
      } else if (_loginController.mobileNumber.text.length != 10) {
        return Constants.ENTER_VALID_MOBILE_NUMBER;
      } else if (_loginController.password.text.isEmpty) {
        return Constants.ENTER_PASSWORD;
      } else {
        return "";
      }
    } else {
      if (_loginController.mobileNumber.text.isEmpty) {
        return Constants.ENTER_CONTACT_NUMBER;
      } else if (_loginController.mobileNumber.text.length != 10) {
        return Constants.ENTER_VALID_MOBILE_NUMBER;
      } else if (_loginController.invitationCode.text.isEmpty) {
        return Constants.ENTER_INVITATION_CODE;
      } else {
        return "";
      }
    }
  }

  /// Service call for user login

  onUserLogin(String mobileNumber, String userPassword) async {
    PrivilegeHandler privilegeHandler = PrivilegeHandler();
    String body =
        json.encode({"contact": mobileNumber, "password": userPassword});

    /* Service call for login */
    var response =
        await _userService.login_grpc(body).catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.LOGIN_ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    // await progressDialog.hide();
    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var responseBody = json.decode(_grpcResponse.message!);
      await _loginController.saveLoginUserData(responseBody);
      AppController.instance.setAuthorizationKey = responseBody['auth'];
      try {
        var roles = UserRoles.user_roles; //responseBody["bu"][0]["roles"];
        var role = roles[0];
        AppController.instance.setLoginUserRoleId =
            role['role_id'] as String?;
        AppController.instance.setLoginUserRole = role['name'] as String?;
        Map<String, dynamic>? permissions =
            role['permissions'] as Map<String, dynamic>?;
        privilegeHandler.setPermissions(permissions);
      } catch (e) {
        privilegeHandler.resetPermissions();
      }
      _loginController.gotoHomePage();
    } else {
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.LOGIN_ERROR, selectedLang),
          _grpcResponse.message!,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  /// Navigating to homepage after Login success

  navigateToDashBoard() {
    if (_versionViewModel!.versionCheckState ==
        VersionCheckState.NEW_VERSION_AVAILABLE) {
      Navigator.push(
          context, PageTransition(context: context, page: VersionUpdatePage()));
    } else {
      // Navigator.push(
      //     context, PageTransition(context: context, page: HomePageView()));
    }
  }

  /// Handling password visibility and hiding

  _passwordToggleVisibile() {
    setState(() {
      _isHidden = !_isHidden;
    });
  }

  /// Dynamically creating login input fields
  final focus = FocusNode();
  Widget mobileNumberInputField() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10),
      child: new TextFormField(
        style: TextStyle(
            fontWeight: StyleView.fontMedium,
            fontSize: 15.0), //FxTextStyle.bodyLarge(color: Colors.black),
        keyboardType: (defaultTargetPlatform == TargetPlatform.iOS)
            ? TextInputType.numberWithOptions(signed: true, decimal: false)
            : TextInputType.number,
        textInputAction: TextInputAction.next,
        controller: _loginController.mobileNumber,
        inputFormatters: [
          new LengthLimitingTextInputFormatter(10),
          CommonMethods.inputTextFormatter(isNumber: true)
        ],
        decoration: CommonMethods.textFieldDecorationTheme(
            Language().getString(Constants.MOBILE_NUMBER, selectedLang),
            prefixIcon: FeatherIcons.phone),
        maxLines: 1,
        onChanged: (text) => {username = _loginController.mobileNumber.text},
      ),
    );
  }

  Widget passwordInputField() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10),
      child: new TextFormField(
        keyboardType: TextInputType.text,
        style: TextStyle(fontWeight: StyleView.fontMedium, fontSize: 15.0),
        obscureText: _isHidden,
        textInputAction: TextInputAction.done,
        controller: _loginController.password,
        decoration: CommonMethods.textFieldDecorationTheme(
            Language().getString(Constants.PASSWORD, selectedLang),
            prefixIcon: FeatherIcons.lock,
            sufixIcon: IconButton(
                onPressed: () {
                  CommonMethods.hideKeyboard(context);
                  _passwordToggleVisibile();
                },
                icon: (_isHidden)
                    ? Icon(Icons.visibility_off)
                    : Icon(Icons.visibility))),
        maxLines: 1,
        cursorColor: theme.colorScheme.onPrimaryContainer,
        onChanged: (text) => {password = _loginController.password.text},
      ),
    );
  }

  @override
  void dispose() {
    // _loginController.invitationCode.clear();
    // _loginController.mobileNumber.clear();
    // _loginController.password.clear();
    // _loginController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FxBuilder<LoginController>(
        controller: _loginController,
        builder: (_loginController) => _buildBody());
  }

  Widget _buildBody() {
    return AppBackgroundView(
      body: Stack(
        children: [
          SafeArea(
            child: Scaffold(
                extendBodyBehindAppBar: true,
                key: _scaffoldkey,
                backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                body: (kIsWeb || Platform.isWindows)
                    ? LayoutBuilder(
                        builder: (BuildContext context,
                            BoxConstraints boxConstraints) {
                          return Container(
                              alignment: Alignment.center,
                              height: boxConstraints.maxHeight,
                              child: this.webLoginUI(boxConstraints));
                        },
                      )
                    : SingleChildScrollView(
                        child: Container(
                            height: MediaQuery.of(context).size.height,
                            margin: EdgeInsets.symmetric(horizontal: 15.0),
                            child: appLoginUI()),
                      )),
          ),
          AppUtills.showLoadingView(
              context: context,
              message: Language().getString(progressMessage, selectedLang),
              isLoading: isLoadingProgress),
        ],
      ),
    );
  }

  renderLoginView() {
    return Center(
      child: Text(
        Constants.LOGIN,
        style: TextStyle(
          fontWeight: StyleView.fontRegular,
          fontSize: 17.0,
          color: theme.colorScheme.primary,
        ),
      ),
    );
  }

  renderAcceptInvitation() {
    return Center(
      child: Text(
        Constants.ACCEPT_INVITATION,
        style: TextStyle(
          fontWeight: StyleView.fontRegular,
          fontSize: 17.0,
          color: theme.colorScheme.primary,
        ),
      ),
    );
  }

  renderMobileNumberInputField() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10.0),
      child: new TextFormField(
          controller: _loginController.mobileNumber,
          keyboardType: (defaultTargetPlatform == TargetPlatform.iOS)
              ? TextInputType.numberWithOptions(signed: true, decimal: false)
              : TextInputType.number,
          style: TextStyle(fontWeight: StyleView.fontMedium, fontSize: 15.0),
          textInputAction: TextInputAction.next,
          decoration: CommonMethods.textFieldDecorationTheme(
              Language().getString(Constants.MOBILE_NUMBER, selectedLang),
              prefixIcon: FeatherIcons.phone),
          maxLines: 1,
          onChanged: (text) =>
              {contactnumber = _loginController.mobileNumber.text},
          inputFormatters: [
            new LengthLimitingTextInputFormatter(10),
            CommonMethods.inputTextFormatter(isNumber: true)
          ]),
    );
  }

  renderInvitationCodeInputField() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10.0),
      child: new TextFormField(
        controller: _loginController.invitationCode,
        style: TextStyle(fontWeight: StyleView.fontMedium, fontSize: 15.0),
        keyboardType: (defaultTargetPlatform == TargetPlatform.iOS)
            ? TextInputType.numberWithOptions(signed: true, decimal: false)
            : TextInputType.number,
        textInputAction: TextInputAction.done,
        decoration: CommonMethods.textFieldDecorationTheme(
            Language()
                .getString(Constants.INVITATION_CODE_STRING, selectedLang),
            prefixIcon: FeatherIcons.pieChart),
        onChanged: (text) =>
            {invitationcode = _loginController.invitationCode.text},
        inputFormatters: [
          // LengthLimitingTextInputFormatter(10),
          CommonMethods.inputTextFormatter(isNumber: true)
        ],
      ),
    );
  }

  renderAlreadyHaveAnAccountString() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10.0),
      child: FxButton.text(
        onPressed: () {
          setState(() {
            isLoadingProgress = true;
            progressMessage = Constants.LOADING;
            _loginController.mobileNumber.clear();
            _loginController.password.clear();
          });
          Future.delayed(Duration(seconds: 2)).then((value) {
            setState(() {
              isLoginFieldsVisibility = true;
              iscodeFieldsVisibility = false;
              isLoadingProgress = false;
            });
          });
        },
        child: FxText.bodyLarge(
          '${Constants.HAVE_ACCOUNT} ${Constants.CLICK_HERE}',
          style: TextStyle(
              color: Colors.black, //theme.colorScheme.primary,
              // decoration: TextDecoration.underline,
              fontWeight: StyleView.fontRegular),
        ),
      ),
    );
  }

  renderDirectRegistration() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10.0),
      child: FxButton.text(
        onPressed: () {
          setState(() {isLoadingProgress = true; progressMessage = Constants.LOADING;});
          Future.delayed(Duration(seconds: 1))
              .then((value) => _loginController.gotoRegistration(""));
        },
        child: FxText.bodyLarge(
          Constants.STR_REGISTRATION,
          style: TextStyle(
              color: Colors.black, //theme.colorScheme.primary,
              // decoration: TextDecoration.underline,
              fontWeight: StyleView.fontMedium),
        ),
      ),
    );
  }

  renderSubmitInvitationButton() {
    return CommonButtonsView(
      context: context,
      b1Text: Language().getString(Constants.SUBMIT_STRING, selectedLang),
      b2Text: "",
      // b1Color: Colors.white,
      b1TextColor: Colors.white,
      iconColor: Colors.white,
      onb1Action: () async {
        // _loginController.gotoRegistration(invitationId);

        String message = validateLoginFields(false);
        if (message.isNotEmpty) {
          await Dialogs.yesCancelDialog(
              context,
              Language().getString(Constants.ERROR, selectedLang),
              Language().getString(message, selectedLang),
              Language().getString(Constants.OKAY_STR, selectedLang),
              "",
              false);
        } else {
          if (await NetworkStatus.getInternetStatus()) {
            setState(() {
              isLoadingProgress = true;
              progressMessage = Constants.VALIDATING_INVITATION_CODE;
            });
            this.onSubmitInvitationCode();
          } else {
            await Dialogs.yesCancelDialog(
                context,
                Language().getString(Constants.NETWORK_ERROR, selectedLang),
                Language().getString(Constants.CHECK_INTERNET, selectedLang),
                Language().getString(Constants.OKAY_STR, selectedLang),
                "",
                false);
          }
        }
      },
    );
  }

  renderSignInButton(Color color) {
    return Container(
        // margin: EdgeInsets.symmetric(vertical: 10.0),
        // alignment: Alignment.center,
        child: CommonButtonsView(
      context: context,
      b1Text: Language().getString(Constants.SIGN_IN_STRING, selectedLang),
      b2Text: "",
      // b1Color: Colors.white,
      b1TextColor: Colors.white,
      iconColor: Colors.white,
      onb1Action: () async {
        String message = validateLoginFields(true);
        if (message.isNotEmpty) {
          await Dialogs.yesCancelDialog(
              context,
              Language().getString(Constants.LOGIN_ERROR, selectedLang),
              message,
              Language().getString(Constants.OKAY_STR, selectedLang),
              "",
              false);
        } else {
          // if (await NetworkStatus.getInternetStatus()) {
            setState(() {
              isLoadingProgress = true;
              progressMessage = Constants.LOGGING_IN;
            });
            this.onUserLogin(_loginController.mobileNumber.text,
                _loginController.password.text);
          // } else {
          //   AppUtills.showSnackBar(_scaffoldkey,
          //       Language().getString(Constants.NO_INTERNET, selectedLang),
          //       snackBarBgColor: Colors.black,
          //       messageColor: Colors.white,
          //       buttonColor: Colors.white);
          // }
        }
      },
    ));
  }

  renderHaveAnInvitationCodeString(Color color) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10.0),
      child: FxButton.text(
        onPressed: () {
          setState(() {isLoadingProgress = true; progressMessage = Constants.LOADING;});
          Future.delayed(Duration(seconds: 1)).then((value) {
            setState(() => isLoadingProgress = false);
            Navigator.push(
                context,
                new MaterialPageRoute(
                    builder: (context) => InvitationCodeAccept()));
          });
        },
        child: Text(
          '${Constants.HAVE_INVITATION} ${Constants.CLICK_HERE}',
          style: TextStyle(
            fontWeight: StyleView.fontRegular,
            color: Colors.black, //theme.colorScheme.primary,
            // decoration: TextDecoration.underline,
          ),
        ),
      ),
    );
  }

  Widget renderForgotPassword() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10),
      alignment: (kIsWeb) ? Alignment.centerRight : Alignment.centerRight,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          renderDirectRegistration(),
          Container(
            color: Colors.black,
            width: 1,
            height: 15,
            margin: EdgeInsets.only(right: 10),
          ),
          FxButton.text(
              onPressed: () {
                _loginController.invitationCode.clear();
                _loginController.mobileNumber.clear();
                _loginController.password.clear();
                _loginController.dispose();
                _loginController.gotoForgotPassword();
              },
              child: Text(
                Constants.FORGOT_PASSWORD_STRING,
                style: TextStyle(
                    color: Colors.black, //theme.colorScheme.primary,
                    // decoration: TextDecoration.underline,
                    fontWeight: StyleView.fontMedium),
              )),
        ],
      ),
    );
  }

  Widget webLoginUI(BoxConstraints mConstaints) {
    return Center(
      child: Column(
        children: <Widget>[
          Expanded(
            child: Container(
              margin: EdgeInsets.only(top: 20),
              child: SvgPicture.string(
                SvgIcons.app_logo,
                width: MediaQuery.of(context).size.width / 6,
                height: MediaQuery.of(context).size.height * 0.4,
              ),
            ),
          ),
          Expanded(
              child: Container(
            child: Column(
              children: [
                if (iscodeFieldsVisibility)
                  Expanded(
                      child: LayoutBuilder(builder: (context, boxConstraints) {
                    return Container(
                      width: (boxConstraints.maxWidth > 1000)
                          ? MediaQuery.of(context).size.width / 4
                          : MediaQuery.of(context).size.width / 1.5,
                      child: Column(
                        children: <Widget>[
                          this.renderAcceptInvitation(),
                          FxSpacing.height(10),
                          this.renderMobileNumberInputField(),
                          FxSpacing.height(10),
                          this.renderInvitationCodeInputField(),
                          FxSpacing.height(20),
                          this.renderSubmitInvitationButton(),
                          this.renderAlreadyHaveAnAccountString(),
                        ],
                      ),
                    );
                  })),
                if (isLoginFieldsVisibility)
                  Expanded(
                      child: LayoutBuilder(builder: (context, boxConstraints) {
                    return Container(
                        width: (boxConstraints.maxWidth > 1000)
                            ? MediaQuery.of(context).size.width / 4
                            : MediaQuery.of(context).size.width / 1.5,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            this.renderLoginView(),
                            FxSpacing.height(10),
                            this.mobileNumberInputField(),
                            FxSpacing.height(10),
                            this.passwordInputField(),
                            FxSpacing.height(20),
                            this.renderSignInButton(color),
                            Container(
                                child: Padding(
                              padding: EdgeInsets.all(10.0),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  // renderHaveAnInvitationCodeString(color),
                                  renderForgotPassword(),
                                ],
                              ),
                            ))
                          ],
                        ));
                  })),
              ],
            ),
          ))
        ],
      ),
    );
  }

  Widget appLoginUI() {
    return Column(
      children: <Widget>[
        Expanded(
            child: Container(
                // color: Colors.yellow,
                child: SvgPicture.string(
          SvgIcons.app_logo,
          alignment: Alignment.bottomCenter,
        ))),
        Expanded(
            child: Container(
          child: Column(
            children: [
              if (iscodeFieldsVisibility)
                Expanded(
                    child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    // FxSpacing.height(30),
                    this.renderAcceptInvitation(),
                    FxSpacing.height(10),
                    this.renderMobileNumberInputField(),
                    FxSpacing.height(15),
                    this.renderInvitationCodeInputField(),
                    this.renderAlreadyHaveAnAccountString(),
                    this.renderSubmitInvitationButton(),
                  ],
                )),
              if (isLoginFieldsVisibility)
                Expanded(
                    child: Container(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      this.renderLoginView(),
                      FxSpacing.height(10),
                      this.mobileNumberInputField(),
                      FxSpacing.height(15),
                      this.passwordInputField(),
                      this.renderHaveAnInvitationCodeString(color),
                      this.renderSignInButton(color),
                      renderForgotPassword(),
                    ],
                  ),
                ))
            ],
          ),
        ))
      ],
    );
  }
}
