import 'package:vyaparlive/animations/SvgIcons.dart';
import 'package:vyaparlive/login_view/controller/registration_controller.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutx/flutx.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/Dialog.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/privileges/privilege_handler.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/login_view/TermsAndConditionsPage.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:vyaparlive/service/user_services.dart';
import 'dart:convert';
import 'package:vyaparlive/utills/SharePref.dart';


// ignore: must_be_immutable
class RegistrationPage extends StatefulWidget {
  RegistrationPage({this.code, this.contact});
  String? code;
  String? contact;
  @override
  _RegistrationPageState createState() => _RegistrationPageState();
}

class _RegistrationPageState extends State<RegistrationPage> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  final GlobalKey<FormState> _formkey = new GlobalKey<FormState>();
  String? username;
  String? password;
  bool _isHidden = true;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  bool? isConditionsAccepted = false;
  bool isLoadingProgress = false;
  String progressMessage = Constants.PLEASE_WAIT;
  late UserService _userService;
  late RegistrationController _controller;
  late ThemeData theme;
  late FocusNode _passwordFocusNode;
  late FocusNode _nameFocusNode;
  @override
  void initState() {
    super.initState();
    _passwordFocusNode = FocusNode();
    _nameFocusNode = FocusNode();
    theme = AppTheme.vyaparTheme;
    _controller = FxControllerStore.putOrFind(RegistrationController());
    _userService = UserService();
    setState(() {
      _controller.mobileNumber.text = widget.contact!;
    });
  }

  /// Validating User fields

  String validateUserCreationFields() {
    if (_controller.password.text.isEmpty) {
      return Constants.ENTER_PASSWORD;
    } else if (_controller.password.text.length < 4) {
      return Constants.PASS_MUST_BE;
    } else if (_controller.userName.text.isEmpty) {
      return Constants.ENTER_USER_NAME;
    } else {
      return "";
    }
  }

  /// Handling password visibility and hide

  _passwordToggleVisibile() {
    setState(() {
      _isHidden = !_isHidden;
    });
  }

  /// Dynamically creating input fields

  buildMobileTextFields() {
    return new TextFormField(
      style: TextStyle(fontWeight: StyleView.fontMedium, fontSize: 15.0),
      controller: _controller.mobileNumber,
      keyboardType: TextInputType.number,
      textInputAction: TextInputAction.next,
      decoration: CommonMethods.textFieldDecorationTheme(
        Constants.MOBILE_NUMBER,
        prefixIcon: FeatherIcons.phone,
      ),
      onChanged: (text) => {},
    );
  }

  Widget passwordTextField() {
    return new TextFormField(
      style: TextStyle(fontWeight: StyleView.fontMedium, fontSize: 15.0),
      focusNode: _passwordFocusNode,
      controller: _controller.password,
      keyboardType: TextInputType.text,
      textInputAction: TextInputAction.next,
      obscureText: _isHidden,
      decoration: CommonMethods.textFieldDecorationTheme('Set Password',
          prefixIcon: FeatherIcons.lock,
          sufixIcon: IconButton(
            icon:
                _isHidden ? Icon(Icons.visibility_off) : Icon(Icons.visibility),
            onPressed: () {
              _passwordToggleVisibile();
            },
          )),
      onEditingComplete: () => {
        _passwordFocusNode.unfocus(),
        FocusScope.of(context).requestFocus(_nameFocusNode)
      },
      onChanged: (text) => {},
    );
  }

  Widget userNameTextField() {
    return new TextFormField(
      style: TextStyle(fontWeight: StyleView.fontMedium, fontSize: 15.0),
      focusNode: _nameFocusNode,
      controller: _controller.userName,
      keyboardType: TextInputType.text,
      textInputAction: TextInputAction.done,
      decoration: CommonMethods.textFieldDecorationTheme(Constants.FULL_NAME,
          prefixIcon: FeatherIcons.user),
      onEditingComplete: () =>
          {_nameFocusNode.unfocus(), FocusScope.of(context).unfocus()},
      onChanged: (text) => {},
    );
  }

  Widget registrationFields() {
    return Column(
      children: [
        Center(
          child: Text(
            Constants.STR_REGISTRATION,
            style: TextStyle(
              fontWeight: StyleView.fontSemiBold,
              fontSize: 17.0,
              color: theme.colorScheme.primary,
            ),
          ),
        ),
        FxSpacing.height(10),
        FxText.displayLarge(
            Language().getString(Constants.SET_PASSWORD, selectedLang),
            style: TextStyle(
                fontWeight: StyleView.fontBold,
                color: Colors.black //theme.colorScheme.primary,
                )),
        FxSpacing.height(20),
        buildMobileTextFields(),
        FxSpacing.height(10),
        passwordTextField(),
        FxSpacing.height(10),
        userNameTextField(),
        FxSpacing.height(10),
        buildTermsConditionsView(),
        FxSpacing.height(10),
        new Container(
          child: CommonButtonsView(
            context: context,
            b1Text: Language().getString(Constants.CONTINUE, selectedLang),
            b2Text: "",
            b1TextColor: Colors.white,
            iconColor: Colors.white,
            onb1Action: () async {
              String validationError = validateUserCreationFields();
              if (validationError.isNotEmpty) {
                Dialogs.yesCancelDialog(
                    context,
                    Language().getString(Constants.ERROR, selectedLang),
                    Language().getString(validationError, selectedLang),
                    Language().getString(Constants.OKAY_STR, selectedLang),
                    "",
                    false);
              } else {
                if (isConditionsAccepted!) {
                  if (await NetworkStatus.getInternetStatus()) {
                    postUserRegistration();
                  } else {
                    AppUtills.showSnackBar(
                        _scaffoldkey,
                        Language()
                            .getString(Constants.NO_INTERNET, selectedLang),
                        snackBarBgColor: Colors.black,
                        messageColor: Colors.white,
                        buttonColor: Colors.white);
                  }
                } else {
                  Dialogs.yesCancelDialog(
                      context,
                      Language().getString(Constants.WARNING, selectedLang),
                      Language()
                          .getString(Constants.ACCEPT_TERMS, selectedLang),
                      Language().getString(Constants.OKAY_STR, selectedLang),
                      "",
                      false);
                }
              }
            },
          ),
        ),
        renderRowWidget()
      ],
    );
  }

  Widget renderInvitationCode() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10.0),
      child: FxButton.text(
        onPressed: () {
          _controller.navigateToAcceptInvitation();
          // setState(() =>
          //     {isLoadingProgress = true, progressMessage = Constants.LOADING});
          // Future.delayed(Duration(seconds: 1))
          //     .then((value) => _loginController.gotoRegistration(""));
        },
        child: FxText.bodyLarge(
          Constants.ACCEPT_INVITATION,
          style: TextStyle(
              color: Colors.black, //theme.colorScheme.primary,
              // decoration: TextDecoration.underline,
              fontWeight: StyleView.fontMedium),
        ),
      ),
    );
  }

  Widget renderRowWidget() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10),
      alignment: (kIsWeb) ? Alignment.centerRight : Alignment.centerRight,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // renderInvitationCode(),
          Container(
            color: Colors.black,
            width: 1,
            height: 15,
            // margin: EdgeInsets.only(right: 10),
          ),
          FxButton.text(
              onPressed: () {
                _controller.navigateToLogin();
              },
              child: Text(
                Constants.LOGIN,
                style: TextStyle(
                    color: Colors.black, //theme.colorScheme.primary,
                    // decoration: TextDecoration.underline,
                    fontWeight: StyleView.fontMedium),
              )),
        ],
      ),
    );
  }

  Widget _buildBody() {
    return AppBackgroundView(
      body: Stack(
        children: [
          SafeArea(
            child: Scaffold(
                key: _scaffoldkey,
                backgroundColor: Colors.transparent,
                body: SingleChildScrollView(
                    child: Center(
                  child: Container(
                    margin: EdgeInsets.symmetric(horizontal: 15.0),
                    child: Column(
                      children: <Widget>[
                        Container(
                          child: SvgPicture.string(
                            SvgIcons.app_logo,
                            width: MediaQuery.of(context).size.width / 6,
                            height: MediaQuery.of(context).size.height * 0.35,
                          ),
                        ),
                        Container(child:
                            LayoutBuilder(builder: (context, boxConstraints) {
                          if (kIsWeb) {
                            return Container(
                              alignment: Alignment.center,
                              width: (boxConstraints.maxWidth > 1000)
                                  ? boxConstraints.maxWidth * 0.3
                                  : boxConstraints.maxWidth * 0.7,
                              child: registrationFields(),
                            );
                          } else {
                            return Container(
                              padding: EdgeInsets.symmetric(horizontal: 15),
                              child: registrationFields(),
                            );
                          }
                        }))
                      ],
                    ),
                  ),
                ))),
          ),
          AppUtills.showLoadingView(
              context: context,
              message: Language().getString(progressMessage, selectedLang),
              isLoading: isLoadingProgress),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _controller.mobileNumber.clear();
    _controller.password.clear();
    _controller.userName.clear();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FxBuilder(
        controller: _controller, builder: (_controller) => _buildBody());
  }

  buildTermsConditionsView() {
    return Container(
        child: Row(
      children: <Widget>[
        Container(
          child: Checkbox(
            activeColor: Color(Constants.APP_COLOR),
            value: isConditionsAccepted,
            onChanged: (value) {
              setState(
                () {
                  isConditionsAccepted = value;
                },
              );
            },
          ),
        ),
        Container(
          child: InkWell(
            onTap: () {
              if (kIsWeb) {
                AppUtills.launchURL(
                    '${Constants.ASSETS_BASE_URL}http-utils/assets/public/views/terms.html');
              } else {
                Navigator.push(context,
                    PageTransition(context: context, page: TermsPage()));
              }
            },
            child: RichText(
              text: TextSpan(
                children: <TextSpan>[
                  TextSpan(
                    text: Language().getString(
                        Constants.ACCEPT_STRING + "  ", selectedLang),
                    style: TextStyle(
                        fontWeight: StyleView.fontBold,
                        fontSize: 16,
                        color: Colors.black //Color(Constants.APP_COLOR),
                        ),
                  ),
                  TextSpan(
                    text: Language().getString(
                        Constants.TERMS_AND_CONDITIONS, selectedLang),
                    style: TextStyle(
                        fontWeight: StyleView.fontBold,
                        color: Colors.black,
                        fontSize: 16,
                        decoration: TextDecoration.underline),
                  ),
                ],
              ),
            ),
          ),
        )
      ],
    ));
  }

  /// Sending user registration data to server

  void postUserRegistration() async {
    PrivilegeHandler privilegeHandler = PrivilegeHandler();
    setState(() {
      isLoadingProgress = true;
    });
    Map bodyParams = {
      "contact": _controller.mobileNumber.text,
      "name": _controller.userName.text,
      "invitation_id": widget.code,
      "password": _controller.password.text,
      "documents": []
    };
    String body = json.encode(bodyParams);
    var response =
        await _userService.create_user_grpc(body).catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          Language().getString(Constants.USER_REG_MESSAGE, selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);

      if (action == DialogAction.yes) {
        CommonMethods.hideKeyboard(context);
        // privilegeHandler.resetPermissions();
        SharePref()
            .saveUserMobileNUmber(_controller.mobileNumber.text.trim());
        if (await NetworkStatus.getInternetStatus()) {
          this.onUserLogin(_controller.mobileNumber.text.trim(),
              _controller.password.text.trim());
        } else {
          AppUtills.showSnackBar(_scaffoldkey,
              Language().getString(Constants.NO_INTERNET, selectedLang),
              snackBarBgColor: Colors.black,
              messageColor: Colors.white,
              buttonColor: Colors.white);
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message!,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  /// Service call for user login

  onUserLogin(String mobileNumber, String userPassword) async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = Constants.CREATING;
    });
    PrivilegeHandler privilegeHandler = PrivilegeHandler();

    String body =
        json.encode({"contact": mobileNumber, "password": userPassword});

    /* Service call for login */
    var response = await
        // _service.login(body)
        _userService.login_grpc(body).catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var responseBody = json.decode(_grpcResponse.message!);
      _controller.saveUserData(responseBody);
      AppController.instance.setAuthorizationKey = responseBody['auth'];
      try {
        var roles = responseBody["bu"][0]["roles"];
        var role = roles[0];
        AppController.instance.setLoginUserRoleId = role['role_id'];
        AppController.instance.setLoginUserRole = role['name'];
        // Map<String, dynamic>? permissions = role['permissions'];
        // privilegeHandler.setPermissions(permissions);
      } catch (e) {
        // privilegeHandler.resetPermissions();
      }
      _controller.goToDashboard();
    } else {
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message!,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }
}
