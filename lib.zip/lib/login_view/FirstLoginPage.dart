import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutx/flutx.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/login_view/LoginPage.dart';
import 'package:vyaparlive/login_view/RegistrationPage.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/service/invitation_services.dart';
import 'package:vyaparlive/utills/SharePref.dart';

import '../animations/SvgIcons.dart';

class FirstLoginPage extends StatefulWidget {
  // const FirstLoginPage({ Key? key }) : super(key: key);

  @override
  _FirstLoginPageState createState() => _FirstLoginPageState();
}

class _FirstLoginPageState extends State<FirstLoginPage> {
  String? selectedLang = 'en';
  late SharedPreferences sharedPreferences;
  String? userName = '';
  String? password = '';
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  final _invitationcodecontroller = TextEditingController();
  final _contactnumbercontroller = TextEditingController();
  String invitationcode = '';
  String contactnumber = '';
  bool isLoading = false;
  String? invitationId = "";
  late InvitationService _invitationService;
  bool isLoginFieldsVisibility = true;
  bool iscodeFieldsVisibility = false;
  late ThemeData theme;
  bool downloading = false;
  var progressString = "";
  @override
  void initState() {
    super.initState();

    downloadFile();
    theme = AppTheme.vyaparTheme;
    _invitationService = InvitationService();
    SharePref().getPhoneNumber().then((value) {
      userName = value;
    });
    SharePref().getPassword().then((value) {
      password = value;
    });
  }

  Future<void> downloadFile() async {
    if (kIsWeb) {
      return;
    }
    Dio dio = Dio();

    try {
      var dir = await getApplicationDocumentsDirectory();
      print("Language file url ${Constants.LANGUAGE_FILE_URL}");
      await dio.download(Constants.LANGUAGE_FILE_URL,
          "${dir.path}/language_strings_vyapar_live.xlsx",
          onReceiveProgress: (rec, total) {
        setState(() {
          downloading = true;
          progressString = ((rec / total) * 100).toStringAsFixed(0) + "%";
        });
      });
    } catch (e) {
      print("Language exception : " + e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
        body: SafeArea(
            child: Stack(
      children: [
        SafeArea(
          child: Scaffold(
            backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
            body: Center(
              child: Column(
                children: [
                  Expanded(
                    flex: 2,
                    child: Container(
                        margin: EdgeInsets.only(top: 20),
                        child: SvgPicture.string(
                          SvgIcons.app_logo,
                          width: MediaQuery.of(context).size.width / 6,
                          height: MediaQuery.of(context).size.height * 0.4,
                          // height: 35,
                        )),
                  ),
                  Expanded(
                      flex: 2,
                      child: Container(
                        child: LayoutBuilder(builder: (context, boxConstrainst) {
                          if (isLoginFieldsVisibility) {
                            return this.showButtonsView(boxConstrainst);
                          } else {
                            return this.showHaveInvitationCode(boxConstrainst);
                          }
                        }),
                      )),
                  Container(
                    margin: EdgeInsets.symmetric(vertical: 16.0),
                    alignment: Alignment.bottomCenter,
                    child: Text(
                      Language().getString("Version", selectedLang) +
                          " ${Constants.APP_VERSION}",
                      style: TextStyle(
                          color: Colors.black, fontWeight: StyleView.fontMedium),
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    )));
  }

  Widget showButtonsView(BoxConstraints boxConstraints) {
    return Column(
      children: [
        Container(
          width: (boxConstraints.maxWidth > 1000)
              ? MediaQuery.of(context).size.width / 6
              : MediaQuery.of(context).size.width / 2,
          child: CommonButtonsView(
            context: context,
            b1Text: Language().getString(Constants.LOGIN, selectedLang),
            b2Text: "",
            onb1Action: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => LoginPage(
                            username: userName,
                            password: password,
                            isShowBackButton: true,
                          ),
                      maintainState: false));
            },
          ),
        ),
        Container(
          width: (boxConstraints.maxWidth > 800)
              ? MediaQuery.of(context).size.width / 6
              : MediaQuery.of(context).size.width / 2,
          padding: EdgeInsets.symmetric(vertical: 10),
          child: CommonButtonsView(
            context: context,
            b1Text:
                Language().getString(Constants.STR_REGISTRATION, selectedLang),
            b2Text: "",
            onb1Action: () {
              Navigator.push(
                  context,
                  new MaterialPageRoute(
                      builder: (context) =>
                          RegistrationPage(code: "", contact: "")));
            },
          ),
        ),
      ],
    );
  }

  Widget showHaveInvitationCode(BoxConstraints boxConstraints) {
    return Container(
      width: (boxConstraints.maxWidth > 1000)
          ? boxConstraints.maxWidth * 0.3
          : boxConstraints.maxWidth * 0.7,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          this.renderAcceptInvitation(),
          FxSpacing.height(10),
          this.renderMobileNumberInputField(),
          FxSpacing.height(10),
          this.renderInvitationCodeInputField(),
          FxSpacing.height(20),
          this.renderSubmitInvitationButton(),
          this.renderAlreadyHaveAnAccountString(),
        ],
      ),
    );
  }

  renderAcceptInvitation() {
    return Center(
      child: Text(
        Constants.ACCEPT_INVITATION,
        style: TextStyle(
          fontWeight: StyleView.fontRegular,
          fontSize: 17.0,
          color: theme.colorScheme.primary,
        ),
      ),
    );
  }

  renderMobileNumberInputField() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10.0),
      child: new TextFormField(
          controller: _contactnumbercontroller,
          keyboardType: TextInputType.number,
          style: TextStyle(fontWeight: StyleView.fontMedium, fontSize: 15.0),
          textInputAction: TextInputAction.next,
          decoration: CommonMethods.textFieldDecorationTheme(
              Language().getString(Constants.MOBILE_NUMBER, selectedLang),
              prefixIcon: FeatherIcons.phone),
          maxLines: 1,
          onChanged: (text) => {contactnumber = _contactnumbercontroller.text},
          inputFormatters: [
            new LengthLimitingTextInputFormatter(10),
            CommonMethods.inputTextFormatter(isNumber: true)
          ]),
    );
  }

  renderInvitationCodeInputField() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10.0),
      child: new TextFormField(
          controller: _invitationcodecontroller,
          keyboardType: TextInputType.number,
          style: TextStyle(fontWeight: StyleView.fontMedium, fontSize: 15.0),
          textInputAction: TextInputAction.next,
          decoration: CommonMethods.textFieldDecorationTheme(
              Language()
                  .getString(Constants.INVITATION_CODE_STRING, selectedLang),
              prefixIcon: FeatherIcons.codesandbox),
          maxLines: 1,
          onChanged: (text) =>
              {invitationcode = _invitationcodecontroller.text},
          inputFormatters: [
            new LengthLimitingTextInputFormatter(10),
            CommonMethods.inputTextFormatter(isNumber: true)
          ]),
    );
  }

  renderAlreadyHaveAnAccountString() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 8.0),
      alignment: Alignment.centerLeft,
      child: InkWell(
        onTap: () {
          setState(() {
            isLoadingProgress = true;
            progressMessage = Constants.GETTING_DATA;
          });
          Future.delayed(Duration(seconds: 2)).then((value) {
            setState(() {
              isLoadingProgress = false;
              isLoginFieldsVisibility = true;
              iscodeFieldsVisibility = false;
            });
          });
        },
        child: RichText(
          text: TextSpan(
            children: [
              TextSpan(
                text:
                    Language().getString(Constants.HAVE_ACCOUNT, selectedLang),
                style: TextStyle(
                    fontSize: 15.0,
                    color: theme.colorScheme.primary,
                    fontFamily: StyleView.FONT_TITLE),
              ),
              TextSpan(
                text: " ",
              ),
              TextSpan(
                text: Language().getString(Constants.CLICK_HERE, selectedLang),
                style: TextStyle(
                    fontSize: 18.0,
                    fontFamily: StyleView.FONT_TITLE,
                    color: theme.colorScheme.primary),
              ),
            ],
          ),
        ),
      ),
    );
  }

  renderSubmitInvitationButton() {
    return CommonButtonsView(
      context: context,
      b1Text: "",
      b2Text: Language().getString(Constants.SUBMIT_STRING, selectedLang),
      onb2Action: () async {
        String message = validateLoginFields(false);
        if (message.isNotEmpty) {
          await Dialogs.yesCancelDialog(
              context,
              Language().getString(Constants.ERROR, selectedLang),
              Language().getString(message, selectedLang),
              Language().getString(Constants.OKAY_STR, selectedLang),
              "",
              false);
        } else {
          if (await NetworkStatus.getInternetStatus()) {
            setState(() {
              isLoadingProgress = true;
              progressMessage = Constants.VALIDATING_INVITATION_CODE;
            });
            this.onSubmitInvitationCode();
          } else {
            await Dialogs.yesCancelDialog(
                context,
                Language().getString(Constants.NETWORK_ERROR, selectedLang),
                Language().getString(Constants.CHECK_INTERNET, selectedLang),
                Language().getString(Constants.OKAY_STR, selectedLang),
                "",
                false);
          }
        }
      },
    );
  }

  String validateLoginFields(bool isLogin) {
    if (_contactnumbercontroller.text.isEmpty) {
      return Constants.ENTER_CONTACT_NUMBER;
    } else if (_contactnumbercontroller.text.length != 10) {
      return Constants.ENTER_VALID_MOBILE_NUMBER;
    } else if (_invitationcodecontroller.text.isEmpty) {
      return Constants.ENTER_INVITATION_CODE;
    } else {
      return "";
    }
  }

  onSubmitInvitationCode() async {
    String contactNumber = _contactnumbercontroller.text;
    String invitationCode = _invitationcodecontroller.text;

    setState(() {
      isLoading = true;
    });

    String body =
        json.encode({"contact": contactNumber, "code": invitationCode});
    /* service call for validating invitation code */
    var response = await _invitationService
        .acceptInvitationByCode_grpc(body)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoading = false;
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var responseBody = json.decode(_grpcResponse.message!);

      setState(() {
        invitationId = responseBody["id"];
      });

      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          responseBody["message"],
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
      if (action == DialogAction.yes) {
        // this.navigateToLogin();
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (contex) => RegistrationPage(
                      code: this.invitationId,
                      contact: _contactnumbercontroller.text,
                    ),
                maintainState: false));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }
}
