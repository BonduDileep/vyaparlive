import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/core/enums/home_view_enum.dart';
import 'package:vyaparlive/core/locator.dart';

import 'package:vyaparlive/core/view_models/version_view_model.dart';

class VersionUpdatePage extends StatefulWidget {
  @override
  _VersionUpdatePageState createState() => _VersionUpdatePageState();
}

class _VersionUpdatePageState extends State<VersionUpdatePage> {
  VersionViewModel? _versionViewModel = locator<VersionViewModel>();
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<VersionViewModel?>.value(
      value: _versionViewModel,
      child: Consumer<VersionViewModel>(
        builder: (context, model, child) => WillPopScope(
          onWillPop: () => Future.value(false),
          child: SafeArea(
            child: Scaffold(
              backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
              appBar: AppBar(
                automaticallyImplyLeading: false,
                // leading: IconButton(
                //     icon: Icon(Icons.arrow_back, color: Colors.white),
                //     onPressed: () {
                //       if (Platform.isAndroid) {
                //         SystemNavigator.pop();
                //       } else if (Platform.isIOS) {
                //         exit(0);
                //       }
                //     }),
                centerTitle: true,
                backgroundColor: Color(Constants.APP_COLOR),
                title: Text("App Update"),
              ),
              body: Center(
                child: Container(
                  height: 150.0,
                  child: Card(
                    margin:
                        EdgeInsets.only(left: 14, right: 14, bottom: 5, top: 5),
                    elevation: 5.0,
                    color: Colors.blue[50],
                    child: Container(
                      decoration: BoxDecoration(
                          gradient: AppUtills.getLinearGradient(colors: [
                        Colors.white,
                        Colors.grey[50],
                        Colors.blue[100],
                        Colors.blue[300],
                        Colors.blue[400]
                      ])),
                      child: Padding(
                        padding: EdgeInsets.all(8.0),
                        child: Column(
                          children: [
                            Align(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                'Get more with the new update',
                                style: TextStyle(
                                  fontSize: Constants.HEADER_FONT_SIZE,
                                  color: Color(Constants.APP_COLOR),
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 8,
                            ),
                            Center(
                              child: Text(
                                'We\'ve enhanced the app, and added some new and exciting features!',
                                style: TextStyle(
                                    color: Colors.black87,
                                    fontWeight: FontWeight.w500,
                                    fontSize: Constants.REGULAR_FONT_SIZE),
                              ),
                            ),
                            SizedBox(
                              height: 15,
                            ),
                            if (model.apkDownloadingState ==
                                ApkDownloadingState.DOWNLOAD_IDLE)
                              InkWell(
                                onTap: () {
                                  model.setApkDownloadingState(ApkDownloadingState
                                      .DOWNLOAD_BUTTON_CLICKED);
                                  model.downloadApkFile();
                                },
                                child: Container(
                                  margin: EdgeInsets.only(right: 10, top: 30),
                                  alignment: Alignment.bottomRight,
                                  child: Text(
                                    'DOWNLOAD',
                                    style: TextStyle(
                                        color: Color(Constants.APP_COLOR),
                                        fontSize: Constants.SUB_HEADER_FONT_SIZE,
                                        fontWeight: FontWeight.w800),
                                  ),
                                ),
                              ),
                            if (model.apkDownloadingState ==
                                ApkDownloadingState.DOWNLOAD_BUTTON_CLICKED)
                              Container(
                                child: Text(
                                  Constants.PLEASE_WAIT,
                                  style: TextStyle(
                                      color: Color(Constants.APP_COLOR),
                                      fontSize: Constants.REGULAR_FONT_SIZE),
                                ),
                              ),
                            if (model.apkDownloadingState ==
                                ApkDownloadingState.DOWNLOAD_IN_PROGRESS)
                              Container(
                                child: Text(
                                  'Downloading apk, ${_versionViewModel!.downloadedPercentage}',
                                  style: TextStyle(
                                      color: Color(Constants.APP_COLOR),
                                      fontSize: Constants.REGULAR_FONT_SIZE),
                                ),
                              ),
                            if (model.apkDownloadingState ==
                                ApkDownloadingState.DOWNLOAD_COMPLETED)
                              InkWell(
                                onTap: () {
                                  model.onClickInstallApk();
                                },
                                child: Container(
                                  margin: EdgeInsets.only(right: 10, top: 30.0),
                                  child: Align(
                                    alignment: Alignment.centerRight,
                                    child: Text(
                                      'INSTALL',
                                      style: TextStyle(
                                          color: Color(Constants.APP_COLOR),
                                          fontSize:
                                              Constants.SUB_HEADER_FONT_SIZE,
                                          fontWeight: FontWeight.w800),
                                    ),
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
