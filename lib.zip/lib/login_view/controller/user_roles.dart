class UserRoles {
  static const dynamic user_roles = [
    {
      "role_id": "1f337a8e-a454-454a-a018-092c6521117b",
      "name": "ADMIN",
      "code": "ADMIN",
      "permissions": {
        "TRANSACTION": [
          {
            "id": "d84c2761-b905-4b06-989a-0b3f7f7f8761",
            "name": "View Transaction",
            "code": "view_transaction",
            "feature_group": "transactions",
            "description": "view transaction"
          },
          {
            "id": "fd550a3c-e57c-40ee-a6fb-88d9310cd681",
            "name": "View Payment Details",
            "code": "view_payment_details",
            "feature_group": "transactions",
            "description": "view payment details"
          },
          {
            "id": "876e8556-4db3-429c-a9c9-e2465555c1b1",
            "name": "Stock Add Update Resolution",
            "code": "stock_add_update_resolution",
            "feature_group": "transactions",
            "description": "business unit editing"
          },
          {
            "id": "27b6e7b1-0e2d-418d-b220-aa322aa46e1e",
            "name": "View Resolution",
            "code": "view_resolution",
            "feature_group": "transactions",
            "description": "view resolution"
          },
          {
            "id": "387bfa05-48ac-4497-b3cc-5e5ddb2b8bac",
            "name": "Receive Stocks",
            "code": "receive_stocks",
            "feature_group": "transactions",
            "description": "receive stocks"
          },
          {
            "id": "76040890-45f1-4654-803f-4b8c783099e5",
            "name": "View Payment Reconciliation",
            "code": "view_payment_reconciliation",
            "feature_group": "transactions",
            "description": "view payment reconciliation"
          },
          {
            "id": "4281baef-9f95-4d2c-963d-33651b677eb4",
            "name": "View Stock Reconciliation",
            "code": "view_stock_reconciliation",
            "feature_group": "transactions",
            "description": "view stock reconciliation"
          },
          {
            "id": "98c355ea-de0e-48fd-9e4b-6e53ffd67d10",
            "name": "View Reconciliation",
            "code": "view_reconciliation",
            "feature_group": "transactions",
            "description": "view reconciliation"
          },
          {
            "id": "5d4846af-931f-416d-ae4e-7e31089ff3bc",
            "name": "In Direct Delivery",
            "code": "in_direct_delivery",
            "feature_group": "transactions",
            "description": "in direct delivery"
          },
          {
            "id": "2abde7d2-8094-4e8b-acc6-e2dc83131eff",
            "name": "Direct Delivery",
            "code": "direct_delivery",
            "feature_group": "transactions",
            "description": "direct delivery"
          },
          {
            "id": "05e47ab0-d55f-41a2-9ac2-49911def68f5",
            "name": "Add Edit Delivery",
            "code": "add_edit_delivery",
            "feature_group": "transactions",
            "description": "add edit delivery"
          },
          {
            "id": "6ccd2059-78c4-41f8-af2c-bcb510c2e55b",
            "name": "View Delivery",
            "code": "view_delivery",
            "feature_group": "transactions",
            "description": "view delivery"
          },
          {
            "id": "c03785a6-9640-4b6b-885f-641a839571b7",
            "name": "Self Packing",
            "code": "self_packing",
            "feature_group": "transactions",
            "description": "self packing"
          },
          {
            "id": "c31c00be-63da-44f4-87bc-8f42eb86e327",
            "name": "Assign User",
            "code": "assign_user",
            "feature_group": "transactions",
            "description": "assign user"
          },
          {
            "id": "fa65f48b-759b-48fa-80b4-b9506d332c48",
            "name": "Update Packing",
            "code": "update_packing",
            "feature_group": "transactions",
            "description": "update packing"
          },
          {
            "id": "bc12b6ca-daba-4996-b575-54efe8a5bf5e",
            "name": "Add Edit Packing",
            "code": "add_edit_packing",
            "feature_group": "transactions",
            "description": "add edit packing"
          },
          {
            "id": "88aa32de-442d-480b-a4a1-4ec973284616",
            "name": "View Packing",
            "code": "view_packing",
            "feature_group": "transactions",
            "description": "view packing"
          },
          {
            "id": "ee601e22-f669-4f5a-8f14-c51802667943",
            "name": "View Invoice",
            "code": "view_invoice",
            "feature_group": "transactions",
            "description": "view invoice"
          },
          {
            "id": "25c84e53-03b2-40e0-95e5-60cf6c420736",
            "name": "Generate Invoice",
            "code": "generate_invoice",
            "feature_group": "transactions",
            "description": "generate invoice"
          },
          {
            "id": "979d0d65-426f-4889-acd3-84f307935a50",
            "name": "Reject PO",
            "code": "reject_po",
            "feature_group": "transactions",
            "description": "reject po"
          },
          {
            "id": "d0b2c740-e8df-43ab-9441-33f258aa8604",
            "name": "Accept PO",
            "code": "accept_po",
            "feature_group": "transactions",
            "description": "accept po"
          },
          {
            "id": "5c9321d0-a2c0-48e7-b2c2-c0c578a49d84",
            "name": "View PO",
            "code": "view_po",
            "feature_group": "transactions",
            "description": "view po"
          },
          {
            "id": "c78a00de-eb4f-4b58-b9df-df731b6d689a",
            "name": "Accept Confirmation Message",
            "code": "accept_confirmation_message",
            "feature_group": "transactions",
            "description": "accept confirmation message"
          },
          {
            "id": "c4f6c283-84eb-4481-8e41-85751c9dbc52",
            "name": "Update Confirmation Order",
            "code": "update_confirmation_order",
            "feature_group": "transactions",
            "description": "update confirmation order"
          },
          {
            "id": "75d3fc72-4a59-4c63-b78b-8935761d7b59",
            "name": "Edit Confirmation Message",
            "code": "edit_confirmation_message",
            "feature_group": "transactions",
            "description": "edit confirmation message"
          },
          {
            "id": "c9435256-15e3-4905-bbc0-b2620d5f5a34",
            "name": "View Confirmation Message",
            "code": "view_confirmation_message",
            "feature_group": "transactions",
            "description": "view confirmation message"
          },
          {
            "id": "f8b01094-cd65-4b73-93ae-7fd060ade687",
            "name": "Add Discussion",
            "code": "add_discussion",
            "feature_group": "transactions",
            "description": "add discussion"
          },
          {
            "id": "df6d8238-7a08-47a4-865e-5d6021591502",
            "name": "View Discussion",
            "code": "view_discussion",
            "feature_group": "transactions",
            "description": "view discussion"
          },
          {
            "id": "016c9e13-e757-406d-8281-c93d72627698",
            "name": "Start Connection Discussion",
            "code": "connection_start_discussion",
            "feature_group": "transactions",
            "description": "start connection discussion"
          },
          {
            "id": "dc22a06a-cf5e-4217-91a6-3984a212d540",
            "name": "Place Order Connection",
            "code": "connection_place_order",
            "feature_group": "transactions",
            "description": "place order connection"
          }
        ],
        "CONNECTIONS": [
          {
            "id": "941de4db-d053-48e6-a64f-a549a726cabd",
            "name": "Place Order To Connections",
            "code": "place_order_to_connections",
            "feature_group": "connections",
            "description": "place order to connections"
          },
          {
            "id": "3dd7aaf9-f9b4-4383-a944-3605dc3e7799",
            "name": "Add Connection Products To Catalogue",
            "code": "add_connection_products_to_catalogue",
            "feature_group": "connections",
            "description": "add connection products to catalogue"
          },
          {
            "id": "3b2aae27-76e2-401b-8ff5-81acd1b3f0eb",
            "name": "Add Edit Connection Sales Terms",
            "code": "add_edit_connection_sales_terms",
            "feature_group": "connections",
            "description": "add edit connection sale terms"
          },
          {
            "id": "60db557b-ac32-4e81-a99b-f7ae40b2659b",
            "name": "View Connection Product",
            "code": "connection_product_view",
            "feature_group": "connections",
            "description": "view connection product"
          },
          {
            "id": "a34b0bc4-44a4-4ea3-a1b8-e4ecefbf2193",
            "name": "View Connection",
            "code": "view_connection",
            "feature_group": "connections",
            "description": "view connection"
          },
          {
            "id": "015b5433-44ab-4a2a-9fde-86958f33f6cf",
            "name": "View Connection Details",
            "code": "connection_details_view",
            "feature_group": "connections",
            "description": "view connection details"
          },
          {
            "id": "ab0a0cb0-299b-4e13-bfad-ad24c1691b40",
            "name": "View Offline Connection List",
            "code": "connection_offline_list_view",
            "feature_group": "connections",
            "description": "view offline connection list"
          },
          {
            "id": "7671dc95-618d-486b-b084-1f086229ae69",
            "name": "Create Offline Connection",
            "code": "create_offline_connection",
            "feature_group": "connections",
            "description": "create offline connection"
          },
          {
            "id": "184ae224-cb9e-429c-b2a3-c9c8068c3826",
            "name": "Edit Offline Connection",
            "code": "edit_offline_connection",
            "feature_group": "connections",
            "description": "edit offline connection"
          },
          {
            "id": "cc8c4c20-f86f-4d05-8509-274e30e13377",
            "name": "Remove Offline Connection",
            "code": "remove_offline_connection",
            "feature_group": "connections",
            "description": "remove offline connection"
          },
          {
            "id": "cbc4601f-6060-420d-a634-54a1c77fb6f1",
            "name": "View Connection Transaction History",
            "code": "view_connection_transactions_history",
            "feature_group": "connections",
            "description": "view connection transaction history"
          },
          {
            "id": "c757a6aa-0d70-41b8-bbe5-069feb6accb6",
            "name": "View Add Assign User",
            "code": "view_add_assign_user",
            "feature_group": "connections",
            "description": "view add assign user"
          },
          {
            "id": "691fb813-cdcb-45cd-a76c-6826d7297763",
            "name": "View Add Distributor",
            "code": "view_add_distributor",
            "feature_group": "connections",
            "description": "view add distributor"
          },
          {
            "id": "dc1496fa-52c8-4d6f-8eae-d28c79c50503",
            "name": "View Direct Order",
            "code": "view_direct_order",
            "feature_group": "connections",
            "description": "view direct order"
          }
        ],
        "PRODUCT": [
          {
            "id": "9c4c177d-0003-458d-bd4c-3194f05a3d91",
            "name": "Import excel",
            "code": "import_excel",
            "feature_group": "product",
            "description": "import products from excel"
          },
          {
            "id": "773d2e5d-8768-461b-88bb-919268070cdb",
            "name": "Get Products From YR",
            "code": "get_products_from_yr",
            "feature_group": "product",
            "description": "get products from yr"
          },
          {
            "id": "5dd5c4d7-3284-4bfe-83b2-8759ad21b6e8",
            "name": "Copy Form Organization",
            "code": "copy_form_organization",
            "feature_group": "product",
            "description": "copy form organization"
          },
          {
            "id": "b833d085-bbd0-494f-96b7-85d67f3facf7",
            "name": "Delete Product",
            "code": "delete_product",
            "feature_group": "product",
            "description": "product deleting"
          },
          {
            "id": "ebd2b63e-ca62-4247-9b32-196c9f7c12e5",
            "name": "Add Product",
            "code": "add_product",
            "feature_group": "product",
            "description": "product adding"
          },
          {
            "id": "ffbe739b-bdee-420c-beb4-2970633f26d8",
            "name": "Edit Product",
            "code": "edit_product",
            "feature_group": "product",
            "description": "edit product"
          },
          {
            "id": "e5e89c1d-aef7-45cb-9455-baee5a49d82e",
            "name": "View Products",
            "code": "products_view",
            "feature_group": "product",
            "description": "view products"
          },
          {
            "id": "fc372b20-7803-457e-91ac-eddfe867999e",
            "name": "Product Transaction",
            "code": "product_transaction",
            "feature_group": "product",
            "description": "product transaction"
          },
          {
            "id": "a2b2f6c8-20f3-4ffe-a8a5-c5b79a71e2ed",
            "name": "Edit Product Location",
            "code": "product_location_edit",
            "feature_group": "product",
            "description": "edit product location"
          },
          {
            "id": "e2ccb9ea-e941-41bd-9570-00705160eff5",
            "name": "Create Product Offer",
            "code": "product_offer_create",
            "feature_group": "product",
            "description": "create product offer"
          },
          {
            "id": "30a39887-07bd-4a28-a17a-01f63e4f92d3",
            "name": "Edit Product Offer",
            "code": "product_offer_edit",
            "feature_group": "product",
            "description": "edit product offer"
          },
          {
            "id": "34dea107-7281-4ae4-ad76-41184a25414f",
            "name": "Delete Product Offer",
            "code": "product_offer_delete",
            "feature_group": "product",
            "description": "delete product offer"
          },
          {
            "id": "e58a6c17-ff04-496e-804f-6b27a6e7609e",
            "name": "Edit Package Offer",
            "code": "package_offer_edit",
            "feature_group": "product",
            "description": "edit package offer"
          },
          {
            "id": "78c5e44b-ea36-42f8-bb30-04e4beb11d1a",
            "name": "Create Package Offer",
            "code": "package_offer_create",
            "feature_group": "product",
            "description": "create package offer"
          },
          {
            "id": "6906cbbd-1bd4-4b5f-86e9-401a0005fe14",
            "name": "Delete Package Offer",
            "code": "package_offer_delete",
            "feature_group": "product",
            "description": "delete package offer"
          },
          {
            "id": "1f14b03c-9874-4b87-88f8-23a26af20536",
            "name": "View Inventory Location",
            "code": "view_inventory_location",
            "feature_group": "product",
            "description": "view inventory location"
          }
        ],
        "SUBSCRIPTION": [
          {
            "id": "ff969d13-b11a-4caf-afbb-877ca0bd2c1c",
            "name": "Edit Update Subscription",
            "code": "edit_update_subscription",
            "feature_group": "subscription",
            "description": "edit update subscription"
          },
          {
            "id": "758fef4c-dec4-4059-b38c-0959d18213e3",
            "name": "View Subscription",
            "code": "view_subscription",
            "feature_group": "subscription",
            "description": "view subscription"
          },
          {
            "id": "15c2b9da-95f0-4207-8b52-2044d574e05f",
            "name": "Edit Subscription",
            "code": "edit_subscription",
            "feature_group": "subscriptions",
            "description": "edit subscriptions"
          }
        ],
        "IN_PERSON_ORDER": [
          {
            "id": "479541ec-940f-4f95-b19a-9ae87a1fde95",
            "name": "Delete in person orders",
            "code": "delete_in_person_order",
            "feature_group": "In Person Order",
            "description": "delete in person order"
          },
          {
            "id": "9ec1873a-f443-48ff-8071-b9c52d29f918",
            "name": "Update in person orders",
            "code": "update_in_person_order",
            "feature_group": "In Person Order",
            "description": "update in person order"
          },
          {
            "id": "0d41ef56-597b-4534-aa02-fcaf817e0ae7",
            "name": "Edit in person orders",
            "code": "edit_in_person_order",
            "feature_group": "In Person Order",
            "description": "edit in person order"
          },
          {
            "id": "f865fa6c-e723-47fa-899a-e214a9da5e86",
            "name": "Add in person orders",
            "code": "add_in_person_order",
            "feature_group": "In Person Order",
            "description": "add in person order"
          },
          {
            "id": "5c19fed2-4d03-421d-bc25-2c83efbdb00b",
            "name": "View in person orders",
            "code": "view_in_person_order",
            "feature_group": "In Person Order",
            "description": "view in person order"
          },
          {
            "id": "1bfd4f38-cf4f-4081-976f-bff37224c481",
            "name": "View buy orders",
            "code": "view_buy_order",
            "feature_group": "In Person Order",
            "description": "view buy order"
          },
          {
            "id": "5e261f0a-abcf-46f2-b223-2bbf33a124be",
            "name": "View sell orders",
            "code": "view_sell_order",
            "feature_group": "In Person Order",
            "description": "view sell order"
          },
          {
            "id": "5b612bce-f404-4792-897f-0aba415d8667",
            "name": "View Distributors orders",
            "code": "view_distributors_order",
            "feature_group": "In Person Order",
            "description": "view distributors order"
          },
          {
            "id": "2ffe5f85-a9bb-41a9-a699-09227bca653d",
            "name": "Create Distributors orders",
            "code": "create_distributors_order",
            "feature_group": "In Person Order",
            "description": "create distributors order"
          }
        ],
        "USERS": [
          {
            "id": "e5305d62-c70a-48ba-b6a1-505e097482aa",
            "name": "View User",
            "code": "user_view",
            "feature_group": "user",
            "description": "view user"
          },
          {
            "id": "0fe26086-ae8b-4c13-802e-16a52d197009",
            "name": "Create User",
            "code": "user_creation",
            "feature_group": "user",
            "description": "user creation"
          },
          {
            "id": "cef88732-d4f1-4a98-976c-10a6cd6e34fb",
            "name": "Edit User",
            "code": "user_edit",
            "feature_group": "user",
            "description": "user edit"
          },
          {
            "id": "966b6e80-4482-455a-96e6-4af74e0d974a",
            "name": "Delete User",
            "code": "user_delete",
            "feature_group": "user",
            "description": "delete user"
          }
        ],
        "INVITATION": [
          {
            "id": "5f8edd14-5688-4978-98f3-1b578aa407e6",
            "name": "Reject Invitation",
            "code": "invitation_reject",
            "feature_group": "invitation",
            "description": "invitation reject"
          },
          {
            "id": "e95690c6-4ffc-47d9-9bbf-52514ddfca22",
            "name": "Accept Invitation",
            "code": "invitation_accept",
            "feature_group": "invitation",
            "description": "accept invitation"
          },
          {
            "id": "bed13cb9-b249-41b1-bfff-91e48931e463",
            "name": "View Invitation",
            "code": "invitation_view",
            "feature_group": "invitation",
            "description": "view invitation"
          },
          {
            "id": "24301835-fb40-42a7-b912-fa2699652832",
            "name": "Create Invitation",
            "code": "invitation_create",
            "feature_group": "invitation",
            "description": "create invitation"
          }
        ],
        "BUSINESS_UNIT": [
          {
            "id": "d172dad5-acd8-4134-b41b-875d73db740c",
            "name": "View Business Unit Package",
            "code": "business_unit_package_view",
            "feature_group": "business_unit",
            "description": "view business unit package"
          },
          {
            "id": "67432cb3-f70e-4859-992c-4f28c321dc9b",
            "name": "View Business Unit Product Offer",
            "code": "bu_product_offer_view",
            "feature_group": "business_unit",
            "description": "view bu product offer"
          },
          {
            "id": "8ff3429a-e24f-478d-8bca-d15c26cdda46",
            "name": "View Business Unit Product",
            "code": "bu_product_view",
            "feature_group": "business_unit",
            "description": "view bu product"
          },
          {
            "id": "a5ad6dd4-8ded-49f6-b215-3a644fe10c36",
            "name": "Delete Business Unit Location",
            "code": "bu_location_delete",
            "feature_group": "business_unit",
            "description": "delete bu location"
          },
          {
            "id": "66d4740c-c050-46c8-8b7a-ff7f6a35e642",
            "name": "Edit Business Unit Location",
            "code": "bu_location_edit",
            "feature_group": "business_unit",
            "description": "edit bu location"
          },
          {
            "id": "dd5eba6d-62e6-4015-9e06-aa0b8b97fdf6",
            "name": "View Business Unit Location",
            "code": "bu_location_view",
            "feature_group": "business_unit",
            "description": "view bu location"
          },
          {
            "id": "1b662f6f-5aea-47a5-9b45-b72d0f4b558f",
            "name": "View Business Unit",
            "code": "business_unit_view",
            "feature_group": "business_unit",
            "description": "view bu"
          },
          {
            "id": "116d18c2-ef6a-41bd-b94e-0b6decc1f122",
            "name": "View Business Unit Role",
            "code": "business_unit_role_view",
            "feature_group": "business_unit",
            "description": "view bu role"
          },
          {
            "id": "6eb95cdc-0468-4013-93ad-650983e210c6",
            "name": "Edit Business Unit Role",
            "code": "business_unit_role_edit",
            "feature_group": "business_unit",
            "description": "edit bu role"
          },
          {
            "id": "46b7affb-1cc4-494f-b43e-7c2e29831f1b",
            "name": "Delete Business Unit Role",
            "code": "business_unit_role_delete",
            "feature_group": "business_unit",
            "description": "delete bu role"
          },
          {
            "id": "b31a02e7-aa81-492f-9460-34927ca61899",
            "name": "Create Business Unit Role",
            "code": "business_unit_role_create",
            "feature_group": "business_unit",
            "description": "create bu role"
          },
          {
            "id": "329aa259-ebf5-4ec1-976d-9db37b350bdf",
            "name": "Create Business Unit Location",
            "code": "business_unit_location_create",
            "feature_group": "business_unit",
            "description": "create bu location"
          },
          {
            "id": "01120ec5-8a97-4b88-9343-0047357fce59",
            "name": "Edit Business Unit",
            "code": "edit_business_unit",
            "feature_group": "business_unit",
            "description": "business unit editing"
          },
          {
            "id": "591dfaaf-b9dc-477a-8b44-db7437844a29",
            "name": "Delete Business Unit",
            "code": "delete_business_unit",
            "feature_group": "business_unit",
            "description": "business unit deleting"
          },
          {
            "id": "ce7a8a2c-a27c-4689-974b-42ae9ffa5e25",
            "name": "Add Business Unit",
            "code": "add_business_unit",
            "feature_group": "business_unit",
            "description": "business unit adding"
          }
        ],
        "ASSETS_MANAGEMENT": [
          {
            "id": "da47e834-0e17-4bd6-adce-622d9bc1227d",
            "name": "View Asset Management",
            "code": "view_asset_management",
            "feature_group": "assets",
            "description": "view asset management"
          },
          {
            "id": "9f483372-19d3-4b9a-b399-2366d1792bd0",
            "name": "View Create Asset Group",
            "code": "view_create_asset_group",
            "feature_group": "assets",
            "description": "view create asset group"
          },
          {
            "id": "40700c64-d78d-4af7-a262-5442efcb9677",
            "name": "View Asset List",
            "code": "view_asset_list",
            "feature_group": "assets",
            "description": "view asset list"
          },
          {
            "id": "bebae81e-efbe-4e3f-a5ac-37c431df43d7",
            "name": "View Disposed List",
            "code": "view_disposed_list",
            "feature_group": "assets",
            "description": "view disposed list"
          },
          {
            "id": "f4904256-e38b-41ab-9889-aea1b0d22d44",
            "name": "View Scrap List",
            "code": "view_scrap_list",
            "feature_group": "assets",
            "description": "view scrap list"
          }
        ],
        "PRODUCTION_CONSUMPTION": [
          {
            "id": "970688cb-8329-437c-87bf-bdad940300a2",
            "name": "View Product Consumption",
            "code": "view_product_consumption",
            "feature_group": "product_consumption",
            "description": "view product consumption"
          },
          {
            "id": "fb6c506b-48e2-43f0-a379-0dd3c815e03a",
            "name": "View Product Consumption Management",
            "code": "view_product_consumption_management",
            "feature_group": "product_consumption",
            "description": "view product consumption management"
          },
          {
            "id": "a3ccb495-1806-4a6c-a61c-1b41693c781b",
            "name": "View Raw Material",
            "code": "view_raw_material",
            "feature_group": "product_consumption",
            "description": "view raw material"
          },
          {
            "id": "c0dc7498-a807-4a91-8828-5c07b8ec868b",
            "name": "View Product Consumption Report",
            "code": "view_product_consumption_report",
            "feature_group": "product_consumption",
            "description": "view product consumption report"
          },
          {
            "id": "86231664-3d64-4f00-81c5-79ee5f68381d",
            "name": "View Raw Material Issue List",
            "code": "view_raw_material_issue_list",
            "feature_group": "product_consumption",
            "description": "view raw material issue list"
          },
          {
            "id": "d1c84394-b00b-4464-8d29-a4d3bd4c83dd",
            "name": "View Raw Finished Product Reports",
            "code": "view_raw_finished_product_reports",
            "feature_group": "product_consumption",
            "description": "view raw finished product reports"
          },
          {
            "id": "0315b69a-101f-4f17-bc41-266339087c84",
            "name": "View From Raw Material",
            "code": "view_from_raw_material",
            "feature_group": "product_consumption",
            "description": "view from raw material"
          },
          {
            "id": "7fe91112-77be-4346-abc0-701d20761507",
            "name": "View Create Raw Issue Note",
            "code": "view_create_raw_issue_note",
            "feature_group": "product_consumption",
            "description": "view create raw issue note"
          },
          {
            "id": "267ace5a-563f-4a80-be45-b8fea2681365",
            "name": "View Raw Material Request Form",
            "code": "view_raw_material_request_form",
            "feature_group": "product_consumption",
            "description": "view raw material request form"
          }
        ],
        "REPORTS": [
          {
            "id": "4ddf2c77-40ab-4f11-bb58-6fb72fa58d3f",
            "name": "View Reports",
            "code": "view_reports",
            "feature_group": "reports",
            "description": "view reports"
          },
          {
            "id": "68084e67-0a09-48ae-bf0a-ed1520666de5",
            "name": "View Sell Reports",
            "code": "view_sell_reports",
            "feature_group": "reports",
            "description": "view sell reports"
          },
          {
            "id": "87f3f616-cf3c-4c9e-9e3b-2a258693d7e6",
            "name": "View Buy Reports",
            "code": "view_buy_reports",
            "feature_group": "reports",
            "description": "view buy reports"
          },
          {
            "id": "3f4d17bd-11c9-4492-aeb7-b0a0f6e864fc",
            "name": "View Field Sales Team Reports",
            "code": "view_fields_sales_team_reports",
            "feature_group": "reports",
            "description": "view fields sales team reports"
          },
          {
            "id": "29a117c7-307c-4208-87fa-440115455779",
            "name": "View Retail Sales Reports",
            "code": "view_retail_sales_reports",
            "feature_group": "reports",
            "description": "view retail sales reports"
          },
          {
            "id": "79e36ae5-f731-41af-abec-4f8c718f6f64",
            "name": "View Product Reports",
            "code": "view_product_reports",
            "feature_group": "reports",
            "description": "view product reports"
          },
          {
            "id": "acc1ccd7-2e5f-4d3d-ba62-b68508cc3ee7",
            "name": "View Product Log Reports",
            "code": "view_product_log_reports",
            "feature_group": "reports",
            "description": "view product log reports"
          },
          {
            "id": "881dd0c0-23d1-487c-b549-a67b833a5a49",
            "name": "View Analysis Reports",
            "code": "view_analysis_reports",
            "feature_group": "reports",
            "description": "view analysis reports"
          }
        ],
        "RETAIL_SALES": [
          {
            "id": "2ee7014b-0ff6-474b-8bbd-cf16a14ac91f",
            "name": "View Retail Sales",
            "code": "view_retail_sales",
            "feature_group": "retail_sales",
            "description": "view retail sales"
          },
          {
            "id": "52545a28-ea3c-45fa-bcb1-b7c0bc547fc5",
            "name": "Create Retail Order",
            "code": "create_retail_order",
            "feature_group": "retail_sales",
            "description": "Create retail order"
          },
          {
            "id": "f453e20b-2838-46ea-a523-4dfab1c46adb",
            "name": "View Retail Customers",
            "code": "view_retail_customers",
            "feature_group": "retail_sales",
            "description": "view retail customers"
          },
          {
            "id": "e39c061e-f7a6-4e62-b5c9-dac5aea2ccec",
            "name": "Create Retail Customers",
            "code": "create_retail_customers",
            "feature_group": "retail_sales",
            "description": "create retail customers"
          },
          {
            "id": "eff48cf3-1172-41f5-942d-9f7e7d7a7bcc",
            "name": "Update Retail Customers",
            "code": "update_retail_customers",
            "feature_group": "retail_sales",
            "description": "update retail customers"
          },
          {
            "id": "fdc0ac14-43f9-47ce-9e96-e398badebc75",
            "name": "Delete Retail Customers",
            "code": "delete_retail_customers",
            "feature_group": "retail_sales",
            "description": "delete retail customers"
          }
        ],
        "NOTIFICATIONS": [
          {
            "id": "0fcb51fc-dd64-4e65-8cf3-09cf5889f764",
            "name": "View Notifications",
            "code": "view_notifications",
            "feature_group": "notifications",
            "description": "view notifications"
          }
        ],
        "EXPENSES": [
          {
            "id": "92302593-a8ba-43db-9fd8-985d1e6dc233",
            "name": "View Expenses",
            "code": "view_expenses",
            "feature_group": "expenses",
            "description": "view expenses"
          },
          {
            "id": "b83f7c22-c5b9-4581-8ac3-449ffdf9d5c9",
            "name": "Add Expenses",
            "code": "add_expenses",
            "feature_group": "expenses",
            "description": "add expenses"
          },
          {
            "id": "589867a0-30f3-44e3-be64-1a2a10ea51ee",
            "name": "Edit Expenses",
            "code": "edit_expenses",
            "feature_group": "expenses",
            "description": "edit expenses"
          },
          {
            "id": "9811841c-f33f-4706-ab66-5e8a9b3d6e9c",
            "name": "Delete Expenses",
            "code": "delete_expenses",
            "feature_group": "expenses",
            "description": "delete expenses"
          }
        ]
      }
    }
  ];
}
