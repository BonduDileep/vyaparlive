import 'package:flutter/material.dart';
import 'package:flutx/flutx.dart';

class ForgotPasswordController extends FxController {
  late TextEditingController mobileNumber,
      password,
      confirmPassword,
      otp,
      currentPassword;

  ForgotPasswordController() {
    mobileNumber = new TextEditingController(text: '');
    password = new TextEditingController(text: '');
    confirmPassword = new TextEditingController(text: '');
    otp = new TextEditingController(text: '');
    currentPassword = new TextEditingController(text: '');
  }

  @override
  String getTag() {
    return 'forgotPassword_controller';
  }
}
