import 'package:vyaparlive/Home/HomePageView.dart';
import 'package:vyaparlive/login_view/InvitationCodeAccept.dart';
import 'package:vyaparlive/login_view/LoginPage.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:vyaparlive/utills/SharePref.dart';
import 'package:flutter/material.dart';
import 'package:flutx/flutx.dart';

class RegistrationController extends FxController {
  late TextEditingController mobileNumber, password, userName;
  RegistrationController() {
    mobileNumber = new TextEditingController(text: '');
    password = new TextEditingController(text: '');
    userName = new TextEditingController(text: '');
  }
  void goToDashboard() {
    Navigator.push(
      context,
      PageTransition(
        context: context,
        page: HomePageView(),
      ),
    );
  }

  void navigateToAcceptInvitation() {
    Navigator.push(context,
        new MaterialPageRoute(builder: (context) => InvitationCodeAccept()));
  }

  void navigateToLogin() {
    Navigator.pushAndRemoveUntil(
        context,
        new MaterialPageRoute(builder: (context) => LoginPage()),
        (route) => false);
  }

  void saveUserData(var userData) {
    SharePref().insertUserId(userData["userId"]);
    SharePref().savePhoneNumber(mobileNumber.text.trim());
    SharePref().savePassword(password.text.trim());
    SharePref().saveUserName(userName.text.trim());
    SharePref().saveProfilePic('');
  }

  @override
  String getTag() {
    return 'registration_controller';
  }
}
