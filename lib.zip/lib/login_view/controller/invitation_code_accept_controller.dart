import 'package:vyaparlive/login_view/LoginPage.dart';
import 'package:vyaparlive/login_view/RegistrationPage.dart';
import 'package:flutter/material.dart';
import 'package:flutx/flutx.dart';

class InvitationCodeAcceptController extends FxController {
  late TextEditingController mobileNumber, invitationCode;

  InvitationCodeAcceptController() {
    mobileNumber = new TextEditingController(text: '');
    invitationCode = new TextEditingController(text: '');
  }

  void navigateToRegistration(String? invitationId, BuildContext mContext) {
    Navigator.pushAndRemoveUntil(
        mContext,
        MaterialPageRoute(
            builder: (mContext) => RegistrationPage(
                code: invitationId, contact: mobileNumber.text),
            maintainState: false),
        (route) => false);
  }

  void navigateToLogin(BuildContext mContext) {
    Navigator.pushAndRemoveUntil(
        mContext,
        MaterialPageRoute(
            builder: (mContext) => LoginPage(), maintainState: false),
        (route) => false);
  }

  @override
  String getTag() {
    // TODO: implement getTag
    return '';
  }
}
