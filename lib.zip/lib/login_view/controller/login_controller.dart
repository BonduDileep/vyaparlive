import 'package:vyaparlive/Home/HomePageView.dart';
import 'package:vyaparlive/login_view/RegistrationPage.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:vyaparlive/password_view/UpdatePasswordPage.dart';
import 'package:vyaparlive/utills/SharePref.dart';
import 'package:flutter/material.dart';
import 'package:flutx/flutx.dart';

class LoginController extends FxController {
  late TextEditingController mobileNumber, password, invitationCode;
  LoginController() {
    mobileNumber = TextEditingController(text: '');
    password = TextEditingController(text: '');
    invitationCode = TextEditingController(text: '');
  }

  void gotoHomePage() {
    Navigator.of(context, rootNavigator: true).pushReplacement(
      MaterialPageRoute(
        builder: (context) => HomePageView(),
      ),
    );
  }

  void gotoForgotPassword() {
    Navigator.push(
        context,
        PageTransition(
            context: context,
            page: UpdatePasswordPage(
              validationText: "Forgot Password",
            )));
  }

  saveLoginUserData(Map<String,dynamic> userData) async {
    SharePref().insertUserId(userData["userId"]);
    SharePref().savePhoneNumber(mobileNumber.text);
    SharePref().savePassword(password.text);
    SharePref().saveUserName(userData['user_name']);
    SharePref().saveProfilePic(userData.containsKey("profile_pic")? userData['profile_pic']:"");

    /// AppController.instance.setBuList = userData['data']['bu'];
  }

  void gotoRegistration(String? invitationId) {
    Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(
            builder: (contex) => RegistrationPage(
                  code: invitationId,
                  contact: mobileNumber.text,
                ),
            maintainState: false),
        (route) => false);
  }

  @override
  String getTag() {
    return 'login_controller';
  }
}
