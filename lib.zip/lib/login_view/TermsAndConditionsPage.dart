
import 'package:vyaparlive/config/Language.dart';
import 'package:flutter/material.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';

class TermsPage extends StatefulWidget {
  final bool isFromAssetPage;
  final String? assetRecordId;
  final String? fileName;

  TermsPage(
      {this.assetRecordId = "",
      this.isFromAssetPage = false,
      this.fileName = ""});
  @override
  _TermsPageState createState() => _TermsPageState();
}

class _TermsPageState extends State<TermsPage> {
  String pdfPath = "";
  bool isLoading = true;
  bool isLoadingProgress = false;
  String progressMessage = "Getting data..";
  String? selectedLang = AppController.instance.getSelectedlanguage; //"en";
  WebViewController? _controller;
  @override
  void initState() {
    super.initState();
    if (widget.isFromAssetPage) {
      pdfPath = Constants.NEW_BASE_URL +
          "assets/attachment/${widget.assetRecordId}/${widget.fileName}";
    } else {
      pdfPath =
          '${Constants.ASSETS_BASE_URL}http-utils/assets/public/views/terms.html'; //Constants.NEW_BASE_URL + "http-utils/viewTerms";
    }

    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Color(Constants.APP_BACKGROUND_COLOR))
      ..setNavigationDelegate(NavigationDelegate(onPageFinished: (finish) {
        setState(() {
          isLoadingProgress = false;
        });
      }, onPageStarted: (start) {
        setState(() {
          isLoadingProgress = true;
          progressMessage = "Getting data..";
        });
      }))
      ..loadRequest(Uri.parse(pdfPath), headers: {
        'Content-type': 'application/pdf',
        'authorization': AppController.instance.getAuthorizationKey
      });
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
      body: Stack(
        children: [
          SafeArea(
            child: Scaffold(
                backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                appBar: AppBar(
                  backgroundColor: Color(Constants.APP_COLOR),
                  centerTitle: true,
                  title: Text(Language()
                      .getString(Constants.TERMS_AND_CONDITIONS, selectedLang)),
                ),
                body: WebViewWidget(controller: _controller!)),
          ),
          AppUtills.showLoadingView(
              context: context,
              message: Language().getString(progressMessage, selectedLang),
              isLoading: isLoadingProgress),
        ],
      ),
    );
  }
}
