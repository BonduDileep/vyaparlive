import 'package:flutter/foundation.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/model/bu_model/AddressDetailsModel.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'package:flutx/flutx.dart';

class LocationCard extends StatelessWidget {
  final String locationName;
  final String contactName;
  final String phoneNumber;
  final Function onPressEdit;
  final Function onPressCall;
  final Address address;
  final List<Map> converssionNames;
  LocationCard(
      {super.key,
      required this.contactName,
      required this.locationName,
      required this.phoneNumber,
      required this.onPressEdit,
      required this.onPressCall,
      required this.address,
      required this.converssionNames});
  final ThemeData theme = AppTheme.vyaparTheme;
  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 5.0,
      shadowColor: theme.colorScheme.primaryContainer,
      shape: new RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
          side: BorderSide(
              color: theme.colorScheme.primaryContainer, strokeAlign: 0.05)),
      child: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              flex: 8,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(locationName,
                      style: TextStyle(
                          fontSize: 15,
                          fontWeight: StyleView.fontBold,
                          color: Colors.black)),
                  FxSpacing.height(8),
                  Text(
                    getAddress(address: address),
                    style: TextStyle(
                      fontWeight: StyleView.fontRegular,
                      fontSize: 13,
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
            ),
            // if (CommonMethods.isPrivillegeExist(context,
            //     PrivillegesActions.KEY_MY_COMPANY_BU_LOCATIONS_OPTIONS))
            Expanded(flex: 1, child: popupView(context))
          ],
        ),
      ),
    );
  }

  String getAddress({required Address? address}) {
    String locationAddress = '';
    if (address?.plotNo != '') {
      locationAddress = "${address?.plotNo}";
    }
    if (address?.buildinghousenumber != '') {
      locationAddress = locationAddress + ",${address?.buildinghousenumber}";
    }
    if (address?.buildingNo != '') {
      locationAddress = locationAddress + ",${address?.buildingNo}";
    }
    if (address?.buildingstreetname != '') {
      locationAddress = locationAddress + ",${address?.buildingstreetname}";
    }
    if (address?.villagetowncity != null && address?.villagetowncity != '') {
      locationAddress = locationAddress + ",${address?.villagetowncity}";
    }
    if (address?.landmark != '') {
      locationAddress = locationAddress + ",${address?.landmark}";
    }
    if (address?.district != null && address?.district != '') {
      locationAddress = locationAddress + ",${address?.district}";
    }
    if (address?.state != null && address?.state != '') {
      locationAddress = locationAddress + ",${address?.state}";
    }
    if (address?.postcode != '') {
      locationAddress = locationAddress + ",${address?.postcode}";
    }
    if (address?.country != null && address?.country != '') {
      locationAddress = locationAddress + ",${address?.country}";
    }
    if (locationAddress.startsWith(',')) {
      locationAddress = locationAddress.substring(1);
    }
    return locationAddress;
  }

  Widget popupView(BuildContext mContext) {
    return PopupMenuButton(
      shadowColor: theme.colorScheme.primary,
      elevation: 10.0,
      padding: EdgeInsets.fromLTRB(0, 0, 0, 20),
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(10.0))),
      onSelected: (dynamic result) {
        switch (result) {
          case Constants.EDIT:
            onPressEdit();
            break;

          case Constants.CALL:
            onPressCall();
            break;
          default:
        }
      },
      icon: Icon(
        FeatherIcons.moreVertical,
        color: theme.colorScheme.primary,
      ),
      itemBuilder: (context) => [
        // if (CommonMethods.isPrivillegeExist(
        //     context, PrivillegesActions.KEY_MY_COMPANY_BU_LOCATIONS_CALL))
        if (!kIsWeb)
          PopupMenuItem(
            child: Row(
              children: [
                Icon(FeatherIcons.phoneCall,
                    size: 18, color: theme.colorScheme.primary),
                FxSpacing.width(10),
                Text(
                  converssionNames[0]['name'],
                  style: TextStyle(
                      color: Colors.black, fontWeight: StyleView.fontMedium),
                ),
              ],
            ),
            value: Constants.CALL,
          ),
        // if (CommonMethods.isPrivillegeExist(
        //     context, PrivillegesActions.KEY_MY_COMPANY_BU_LOCATIONS_EDIT))
        PopupMenuItem(
          child: Row(
            children: [
              Icon(FeatherIcons.edit,
                  size: 18, color: theme.colorScheme.primary),
              FxSpacing.width(10),
              Text(converssionNames[1]['name'],
                  style: TextStyle(
                      color: Colors.black, fontWeight: StyleView.fontMedium)),
            ],
          ),
          value: Constants.EDIT,
        ),
      ],
    );
  }
}
