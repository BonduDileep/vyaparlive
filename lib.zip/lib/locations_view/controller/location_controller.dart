import 'package:vyaparlive/locations_view/AddBuLocations.dart';
import 'package:vyaparlive/locations_view/LocationDetailsView.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:flutter/material.dart';
import 'package:flutx/flutx.dart';

class LocationController extends FxController {
  void navigateEdit(
      {required String orgId,
      required String buName,
      required String locationId,
      required bool isLocationUpdate}) {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => AddBuLocationsPage(
                orgId: orgId,
                buName: buName,
                locationId: locationId,
                isUpdateLocation: isLocationUpdate)));
  }

  void navigateDetails(
      {required String orgId,
      required String buName,
      required String locationId}) {
    Navigator.push(
        context,
        PageTransition(
            context: context,
            page: LocationDetailsView(
              orgId: orgId,
              buName: buName,
              locationId: locationId,
            )));
  }

  @override
  String getTag() {
    return 'location_controller';
  }
}
