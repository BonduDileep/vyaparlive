import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/TextView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/bu_model/LocationsModel.dart';
import 'package:vyaparlive/service/organization_service.dart';

class LocationDetailsView extends StatefulWidget {
  final String? locationId;
  final String? orgId;
  final String? buName;
  LocationDetailsView({this.locationId, this.orgId, this.buName});
  @override
  _LocationDetailsViewState createState() => _LocationDetailsViewState();
}

class _LocationDetailsViewState extends State<LocationDetailsView> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String selectedLang = AppController.instance.getSelectedlanguage;
  late OrganizationService _organizationService;
  Locations? locationData;
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;

  @override
  void initState() {
    super.initState();

    _organizationService = OrganizationService();
    this.serviceCallLoadLocationData();
  }

  serviceCallLoadLocationData() async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
      });
      this.loadLocationData().then((value) {
        setState(() {
          locationData = value;
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<Locations?> loadLocationData() async {
    String body =
        json.encode({"location_id": widget.locationId, "bu_id": widget.orgId});
    var response = await _organizationService
        .getLocationDataById(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    Locations? resData;
    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(data)) {
        resData = Locations.fromJson(data[0]);
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return resData;
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        SafeArea(
          child: Scaffold(
            key: _scaffoldkey,
            backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
            appBar: AppBar(
              centerTitle: true,
              backgroundColor: Color(Constants.APP_COLOR),
              title: Column(
                children: [
                  Text(Language()
                      .getString(Constants.LOCATION_DETAILS, selectedLang)),
                  Text(
                    "${widget.buName}",
                    style: TextStyle(fontSize: 13.0),
                  )
                ],
              ),
            ),
            bottomNavigationBar: Container(
              padding: EdgeInsets.all(5.0),
              child: ElevatedButton(
                  style: CommonMethods.elevatedButtonStyle(),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child:
                      Text(Language().getString(Constants.BACK, selectedLang))),
            ),
            body: Container(
              child: (locationData != null)
                  ? this.scrollviewLocationData()
                  : Center(
                      child: Text(Language()
                          .getString(Constants.NO_DATA_FOUND, selectedLang)),
                    ),
            ),
          ),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    );
  }

  Widget scrollviewLocationData() {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              child: Text(
                Language()
                    .getString(Constants.CONTACT_DETAILS_STRING, selectedLang),
                style: TextStyle(
                    color: Color(Constants.APP_COLOR),
                    fontWeight: FontWeight.bold,
                    fontSize: 15.0),
              ),
            ),
            Container(
              decoration: AppUtills.boxDecoration(),
              margin: EdgeInsets.only(top: 5.0),
              child: Column(
                children: [
                  TextView(
                    title: Language()
                        .getString(Constants.LOCATION_NAME, selectedLang),
                    value: locationData!.locationName,
                  ),
                  SizedBox(
                    height: 1,
                    child: new Container(color: Color(Constants.GREY_COLOR)),
                  ),
                  TextView(
                    title: Language()
                        .getString(Constants.CONTACT_PERSON, selectedLang),
                    value: locationData!.contactPerson,
                  ),
                  SizedBox(
                    height: 1,
                    child: new Container(color: Color(Constants.GREY_COLOR)),
                  ),
                  TextView(
                    title: Language()
                        .getString(Constants.CONTACT_NUMBER, selectedLang),
                    value: locationData!.contactNumber,
                  ),
                ],
              ),
            ),
            Container(
              margin: EdgeInsets.only(top: 20.0),
              child: Text(
                Language().getString(Constants.ADDRESS_DETAILS, selectedLang),
                style: TextStyle(
                    color: Color(Constants.APP_COLOR),
                    fontWeight: FontWeight.bold,
                    fontSize: 15.0),
              ),
            ),
            Container(
              decoration: AppUtills.boxDecoration(),
              margin: EdgeInsets.only(top: 5.0),
              child: Column(
                children: [
                  Visibility(
                      visible: (locationData!.locationType ==
                              Constants.KEY_MAIN_OFFICE)
                          ? true
                          : false,
                      child: Column(
                        children: [
                          TextView(
                            title: Language().getString(
                                Constants.PHONE_NUMBER, selectedLang),
                            value: locationData!
                                .addressDetails!.phoneNumberOnInvoice,
                          ),
                          SizedBox(
                            height: 1,
                            child: new Container(
                                color: Color(Constants.GREY_COLOR)),
                          ),
                          TextView(
                            title: Language()
                                .getString(Constants.EMAIL, selectedLang),
                            value: locationData!.addressDetails!.emailOnInvoice,
                          ),
                          SizedBox(
                            height: 1,
                            child: new Container(
                                color: Color(Constants.GREY_COLOR)),
                          ),
                        ],
                      )),
                  TextView(
                    title:
                        Language().getString(Constants.PLOT_NO, selectedLang),
                    value: locationData!.addressDetails!.plotNo,
                  ),
                  SizedBox(
                    height: 1,
                    child: new Container(color: Color(Constants.GREY_COLOR)),
                  ),
                  TextView(
                    title: Language().getString(
                        Constants.BUILDING_HOUSE_NUMBER_STRING, selectedLang),
                    value: locationData!.addressDetails!.buildinghousenumber,
                  ),
                  SizedBox(
                    height: 1,
                    child: new Container(color: Color(Constants.GREY_COLOR)),
                  ),
                  TextView(
                    title:
                        Language().getString(Constants.BULIDING, selectedLang),
                    value: locationData!.addressDetails!.buildingNo,
                  ),
                  SizedBox(
                    height: 1,
                    child: new Container(color: Color(Constants.GREY_COLOR)),
                  ),
                  TextView(
                    title: Language().getString(
                        Constants.BUILDING_STREET_NAME_STRING, selectedLang),
                    value: locationData!.addressDetails!.buildingstreetname,
                  ),
                  SizedBox(
                    height: 1,
                    child: new Container(color: Color(Constants.GREY_COLOR)),
                  ),
                  TextView(
                    title: Language().getString(
                        Constants.COLONY_SELECTOR_AREA_LOCALITY_STRING,
                        selectedLang),
                    value:
                        locationData!.addressDetails!.colonysectorArealocality,
                  ),
                  SizedBox(
                    height: 1,
                    child: new Container(color: Color(Constants.GREY_COLOR)),
                  ),
                  TextView(
                    title: Language()
                        .getString(Constants.LAND_MARK_STRING, selectedLang),
                    value: locationData!.addressDetails!.landmark,
                  ),
                  SizedBox(
                    height: 1,
                    child: new Container(color: Color(Constants.GREY_COLOR)),
                  ),
                  TextView(
                    title: Language()
                        .getString(Constants.COUNTRY_NAME_STRING, selectedLang),
                    value: locationData!.addressDetails!.country,
                  ),
                  SizedBox(
                    height: 1,
                    child: new Container(color: Color(Constants.GREY_COLOR)),
                  ),
                  TextView(
                    title: Language()
                        .getString(Constants.STATE_NAME_STRING, selectedLang),
                    value: locationData!.addressDetails!.state,
                  ),
                  SizedBox(
                    height: 1,
                    child: new Container(color: Color(Constants.GREY_COLOR)),
                  ),
                  TextView(
                    title: Language()
                        .getString(Constants.DISTRICT_STRING, selectedLang),
                    value: locationData!.addressDetails!.district,
                  ),
                  SizedBox(
                    height: 1,
                    child: new Container(color: Color(Constants.GREY_COLOR)),
                  ),
                  TextView(
                    title: Language()
                        .getString(Constants.CITY_NAME_STRING, selectedLang),
                    value: locationData!.addressDetails!.villagetowncity,
                  ),
                  SizedBox(
                    height: 1,
                    child: new Container(color: Color(Constants.GREY_COLOR)),
                  ),
                  TextView(
                    title:
                        Language().getString(Constants.PIN_CODE, selectedLang),
                    value: locationData!.addressDetails!.postcode,
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
