import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutx/flutx.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/components/privileges/bu_privileges.dart';
import 'package:vyaparlive/model/CitiesDAO.dart';
import 'package:vyaparlive/model/CountryDAO.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/StatesDAO.dart';
import 'package:vyaparlive/model/UserModel.dart';
import 'package:vyaparlive/model/bu_model/AddressDetailsModel.dart';
import 'package:vyaparlive/model/bu_model/LocationsModel.dart';
import 'package:vyaparlive/service/Service.dart';
import 'package:http/http.dart' as http;
import 'package:vyaparlive/config/Language.dart';
import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:vyaparlive/service/organization_service.dart';
import 'package:vyaparlive/service/user_services.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';

class AddBuLocationsPage extends StatefulWidget {
  AddBuLocationsPage(
      {this.isUpdateLocation, this.orgId, this.locationId, this.buName});
  final bool? isUpdateLocation;
  final String? orgId;
  final String? locationId;
  final String? buName;
  @override
  _AddBuLocationsPageState createState() => _AddBuLocationsPageState();
}

class _AddBuLocationsPageState extends State<AddBuLocationsPage> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  final _locationNameController = TextEditingController();

  final _contactNumberController = TextEditingController();

  var _buildinghouseNumberController = TextEditingController();
  final _buildingNoController = TextEditingController();
  var _buildingStreetNameController = TextEditingController();
  var _colonysectorarealocalityController = TextEditingController();
  var _villagetowncityController = TextEditingController();
  var _taluknameController = TextEditingController();
  var _landmarkController = TextEditingController();
  final _postalCodeController = TextEditingController();

  StatesDAO? statesDropdownValue;
  List<String>? _districtList = [];
  List<StatesDAO> _statesList = [];
  String? districtDropdownValue;
  List<CountryDAO> _countryList = [];
  CountryDAO? countryDropdownValue;
  List<String> _citiesList = [];
  String? citiesDropDownValue;
  late Service _service;

  List<UserModel> _usersList = [];
  UserModel? usersDropdownValue;
  List<Locations> locationData = [];

  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  Address? addressData;
  final _plotController = TextEditingController();
  BuPrivileges? _buPrivileges = AppController.instance.getBuPrivileges;
  bool isLoadingProgress = true;
  String progressMessage = Constants.GETTING_DATA;
  late OrganizationService _organizationService;
  late UserService _userService;
  String? locationType = "";
  TextEditingController _phoneNumberController = new TextEditingController();
  TextEditingController _emailController = new TextEditingController();
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _service = Service();
    _organizationService = OrganizationService();
    _userService = UserService();
    if (widget.isUpdateLocation!) {
      this.loadLocationData();
    } else {
      this.loadDropdowns();
    }
  }

  loadLocationData() async {
    if (await NetworkStatus.getInternetStatus()) {
      this.getLocationData().then((value) {
        setState(() {
          locationData.addAll(value);
          if (locationData.length > 0) {
            locationType = locationData[0].locationType;
            _locationNameController.text = locationData[0].locationName!;
            _contactNumberController.text = locationData[0].contactNumber!;
            addressData = locationData[0].addressDetails;
            if (addressData != null) {
              _buildinghouseNumberController.text =
                  addressData!.buildinghousenumber!;
              _buildingNoController.text = addressData!.buildingNo!;
              _buildingStreetNameController.text =
                  addressData!.buildingstreetname!;
              _colonysectorarealocalityController.text =
                  addressData!.colonysectorArealocality!;
              _landmarkController.text = addressData!.landmark!;
              _villagetowncityController.text =
                  addressData!.colonysectorArealocality!;
              _taluknameController.text = addressData!.taluk!;
              _postalCodeController.text = addressData!.postcode!;
              _plotController.text = addressData!.plotNo!;
              _phoneNumberController.text = addressData!.phoneNumberOnInvoice!;
              _emailController.text = addressData!.emailOnInvoice!;
            }
            this.loadDropdowns();
          }
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  loadDropdowns() async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
      });

      this.getAllUsers().then((value) {
        setState(() {
          _usersList.addAll(value);
        });
      });

      this.getCountries().then((value) {
        setState(() {
          _countryList.addAll(value);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
      body: Stack(
        children: [
          SafeArea(
            child: Scaffold(
                key: _scaffoldkey,
                backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                appBar: AppBar(
                  centerTitle: true,
                  elevation: 0,
                  iconTheme: IconThemeData(color: theme.colorScheme.primary),
                  title: AppbarName(
                      title: widget.isUpdateLocation!
                          ? Language()
                              .getString(Constants.UPDATE_LOCATION, selectedLang)
                          : Language()
                              .getString(Constants.ADD_LOCATION, selectedLang),
                      buName: "${widget.buName}"),
                  backgroundColor: Colors.transparent, //(Constants.APP_COLOR),
                ),
                bottomNavigationBar: (_buPrivileges!.bu_location_edit ||
                        _buPrivileges!.business_unit_location_create)
                    ? this.bottomView()
                    : null,
                body: SingleChildScrollView(
                    child: Container(
                  padding: EdgeInsets.all(10.0),
                  child: Column(
                    children: <Widget>[
                      Container(
                        decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey),
                            borderRadius: BorderRadius.circular(5)),
                        child: Column(children: <Widget>[
                          buildTableContent(
                              Language().getString(
                                  Constants.LOCATION_NAME, selectedLang),
                              _locationNameController,
                              false),
                          SizedBox(
                            height: 1,
                            child:
                                new Container(color: Color(Constants.GREY_COLOR)),
                          ),
                          buildUsersDropdown(
                            Language().getString(
                                Constants.CONTACT_PERSON, selectedLang),
                          ),
                          SizedBox(
                            height: 1,
                            child:
                                new Container(color: Color(Constants.GREY_COLOR)),
                          ),
                          buildTableContent(
                            Language().getString(
                                Constants.CONTACT_NUMBER, selectedLang),
                            _contactNumberController,
                            true,
                          ),
                        ]),
                      ),
                      Container(
                          margin: EdgeInsets.symmetric(vertical: 5.0),
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey),
                              borderRadius: BorderRadius.all(Radius.circular(5))),
                          child: ExpansionTile(
                            title: Text(Language().getString(
                                Constants.ADDRESS_DETAILS, selectedLang)),
                            children: <Widget>[
                              Column(children: <Widget>[
                                Visibility(
                                    visible: (locationType ==
                                            Constants.KEY_MAIN_OFFICE)
                                        ? true
                                        : false,
                                    child: Column(
                                      children: [
                                        SizedBox(
                                            height: 1,
                                            child: Container(
                                              color: Color(Constants.GREY_COLOR),
                                            )),
                                        buildTableContent(
                                            Language().getString(
                                                Constants.PHONE_NUMBER,
                                                selectedLang),
                                            _phoneNumberController,
                                            true),
                                        SizedBox(
                                            height: 1,
                                            child: Container(
                                              color: Color(Constants.GREY_COLOR),
                                            )),
                                        buildTableContent(
                                            Language().getString(
                                                Constants.EMAIL, selectedLang),
                                            _emailController,
                                            false),
                                      ],
                                    )),
                                SizedBox(
                                    height: 1,
                                    child: Container(
                                      color: Color(Constants.GREY_COLOR),
                                    )),
                                buildTableContent(
                                    Language().getString(
                                        Constants.PLOT_NO, selectedLang),
                                    _plotController,
                                    false),
                                SizedBox(
                                    height: 1,
                                    child: Container(
                                      color: Color(Constants.GREY_COLOR),
                                    )),
                                buildTableContent(
                                    Language().getString(
                                        Constants.BUILDING_HOUSE_NUMBER_STRING,
                                        selectedLang),
                                    _buildinghouseNumberController,
                                    false),
                                SizedBox(
                                    height: 1,
                                    child: Container(
                                      color: Color(Constants.GREY_COLOR),
                                    )),
                                buildTableContent(
                                    Language().getString(
                                        Constants.BULIDING, selectedLang),
                                    _buildingNoController,
                                    false),
                                SizedBox(
                                    height: 1,
                                    child: Container(
                                      color: Color(Constants.GREY_COLOR),
                                    )),
                                buildTableContent(
                                    Language().getString(
                                        Constants.BUILDING_STREET_NAME_STRING,
                                        selectedLang),
                                    _buildingStreetNameController,
                                    false),
                                SizedBox(
                                    height: 1,
                                    child: Container(
                                      color: Color(Constants.GREY_COLOR),
                                    )),
                                buildTableContent(
                                    Language().getString(
                                        Constants
                                            .COLONY_SELECTOR_AREA_LOCALITY_STRING,
                                        selectedLang),
                                    _colonysectorarealocalityController,
                                    false),
                                SizedBox(
                                    height: 1,
                                    child: Container(
                                      color: Color(Constants.GREY_COLOR),
                                    )),
                                buildTableContent(
                                    Language().getString(
                                        Constants.LAND_MARK_STRING, selectedLang),
                                    _landmarkController,
                                    false),
                                SizedBox(
                                    height: 1,
                                    child: Container(
                                      color: Color(Constants.GREY_COLOR),
                                    )),
                                buildCountryDropdown(
                                  Language().getString(
                                      Constants.COUNTRY_NAME_STRING,
                                      selectedLang),
                                ),
                                SizedBox(
                                    height: 1,
                                    child: Container(
                                      color: Color(Constants.GREY_COLOR),
                                    )),
                                buildStateDropdown(
                                  Language().getString(
                                      Constants.STATE_NAME_STRING, selectedLang),
                                ),
                                SizedBox(
                                    height: 1,
                                    child: Container(
                                      color: Color(Constants.GREY_COLOR),
                                    )),
                                buildDistrictDropdown(
                                  Language().getString(
                                      Constants.DISTRICT_STRING, selectedLang),
                                ),
                                SizedBox(
                                    height: 1,
                                    child: Container(
                                      color: Color(Constants.GREY_COLOR),
                                    )),
                                buildCityDropdown(
                                  Language().getString(
                                      Constants.CITY_NAME_STRING, selectedLang),
                                ),
                                SizedBox(
                                    height: 1,
                                    child: Container(
                                      color: Color(Constants.GREY_COLOR),
                                    )),
                                buildTableContent(
                                    Language().getString(
                                        Constants.PIN_CODE, selectedLang),
                                    _postalCodeController,
                                    true),
                              ])
                            ],
                          )),
                    ],
                  ),
                ))),
          ),
          AppUtills.showLoadingView(
              context: context,
              message: Language().getString(progressMessage, selectedLang),
              isLoading: isLoadingProgress),
        ],
      ),
    );
  }

  String validationgLocationFields() {
    if (_locationNameController.text.isEmpty) {
      return Constants.PLEASE_ENTER_LOCATION_NAME;
    } else if (usersDropdownValue == null) {
      return Constants.PLEASE_SELECT_CONTACT_PERSON;
    } else if (_contactNumberController.text.isEmpty) {
      return Constants.PLEASE_ENTER_CONTACT_PERSON_NUMBER;
    } else {
      return "";
    }
  }

  Future<List<Locations>> getLocationData() async {
    String body =
        json.encode({"location_id": widget.locationId, "bu_id": widget.orgId});
    var response = await _organizationService
        .getLocationDataById(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<Locations> list = [];
    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);

      list.add(Locations.fromJson(data[0]));
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return list;
  }

  serviceCallUpdateLocation() async {
    Map data = {
      "id": widget.orgId,
      "location_id": widget.locationId,
      "location_name": _locationNameController.text,
      "contact_person": usersDropdownValue!.name,
      "contact_number": _contactNumberController.text,
      "location_type": locationType,
      "address": {
        "plot_no": _plotController.text,
        "buildinghousenumber": _buildinghouseNumberController.text,
        "building_no": _buildingNoController.text,
        "buildingstreetname": _buildingStreetNameController.text,
        "colonysector_arealocality": _colonysectorarealocalityController.text,
        "villagetowncity":
            citiesDropDownValue != null ? citiesDropDownValue : "",
        "taluk": _taluknameController.text,
        "landmark": _landmarkController.text,
        "state": statesDropdownValue != null ? statesDropdownValue!.state : "",
        "district": districtDropdownValue != null ? districtDropdownValue : "",
        "postcode": _postalCodeController.text,
        "country":
            countryDropdownValue != null ? countryDropdownValue!.name : "",
      },
      "longitude": "",
      "latitude": ""
    };

    if (locationType == Constants.KEY_MAIN_OFFICE) {
      data['address']['phone_number_on_invoice'] = _phoneNumberController.text;
      data['address']['email_on_invoice'] = _emailController.text;
    }
    String body = json.encode(data);
    var response = await _organizationService
        .updateLocation(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      this.buildDialogView(Constants.LOCATION_UPDATED);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  buildDialogView(String message) {
    return showDialog(
        barrierDismissible: false,
        barrierColor: Colors.black54,
        context: (context),
        builder: (context) => AlertDialog(
              elevation: 100.0,
              backgroundColor: Colors.white, //(0XFFE0E0E0),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(
                  Radius.circular(7.0),
                ),
              ),
              title: Text(Language().getString(Constants.INFO, selectedLang)),
              content: Text(Language().getString(message, selectedLang)),
              actions: <Widget>[
                FxButton.block(
                  elevation: 5,
                  shadowColor: theme.colorScheme.primaryContainer,
                  borderRadiusAll: Constants.buttonRadius.large,
                  onPressed: () {
                    Navigator.pop(context);
                    Navigator.of(context).pop(true);
                  },
                  splashColor: theme.colorScheme.onPrimary.withAlpha(30),
                  backgroundColor: theme.colorScheme.primary,
                  child: Padding(
                    padding: const EdgeInsets.all(3.0),
                    child: Text(
                      Constants.OKAY_STR,
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: StyleView.fontMedium),
                      textAlign: TextAlign.center,
                    ),
                  ),
                )
              ],
            ));
  }

  serviceCallCreateLocation() async {
    Map data = {
      "id": widget.orgId,
      "location_name": _locationNameController.text,
      "contact_person":
          usersDropdownValue != null ? usersDropdownValue!.name : "",
      "contact_number": _contactNumberController.text,
      "address": {
        "plot_no": _plotController.text,
        "buildinghousenumber": _buildinghouseNumberController.text,
        "building_no": _buildingNoController.text,
        "buildingstreetname": _buildingStreetNameController.text,
        "colonysector_arealocality": _colonysectorarealocalityController.text,
        "villagetowncity":
            citiesDropDownValue != null ? citiesDropDownValue : "",
        "taluk": _taluknameController.text,
        "landmark": _landmarkController.text,
        "state": statesDropdownValue != null ? statesDropdownValue!.state : "",
        "district": districtDropdownValue != null ? districtDropdownValue : "",
        "postcode": _postalCodeController.text,
        "country":
            countryDropdownValue != null ? countryDropdownValue!.name : "",
      },
      "longitude": "",
      "latitude": "",
    };

    String body = json.encode(data);
    var response = await _organizationService
        .createLocation(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      this.buildDialogView(Constants.LOCATION_CREATED);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  Future<List<UserModel>> getAllUsers() async {
    String body = json.encode({"id": widget.orgId, "filters": {}});
    var response = await _userService
        .getUserByBuId_grpc(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.USERS_STR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<UserModel> _users = [];

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      var resultArray = resObj['results'];
      for (var data in resultArray) {
        _users.add(UserModel.fromJson(data));
      }
      if (widget.isUpdateLocation! &&
          _users.length > 0 &&
          locationData.length > 0) {
        for (int i = 0; i < _users.length; i++) {
          if (locationData[0].contactPerson == _users[i].name) {
            usersDropdownValue = _users[i];
          }
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return _users;
  }

  Future<List<CountryDAO>> getCountries() async {
    http.Response response = await _service.get_countries();
    List<CountryDAO> list = [];

    if (response.statusCode == 200) {
      var data = json.decode(response.body);
      for (var object in data["data"]) {
        list.add(CountryDAO.fromJaon(object));
      }

      if (widget.isUpdateLocation! &&
          list.length > 0 &&
          locationData.length > 0 &&
          locationData[0].addressDetails != null) {
        for (int i = 0; i < list.length; i++) {
          if (locationData[0].addressDetails!.country == list[i].name) {
            countryDropdownValue = list[i];
            loadStatesDropdown();
          }
        }
      } else {
        if (list.length > 0) {
          for (int i = 0; i < list.length; i++) {
            if (list[i].name == 'India') {
              countryDropdownValue = list[i];
              loadStatesDropdown();
            }
          }
        }
      }
    }
    return list;
  }

  loadStatesDropdown() async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
      });
      this.getStates(countryDropdownValue!.name!).then((value) {
        setState(() {
          _statesList.addAll(value);
          if (widget.isUpdateLocation! &&
              _statesList.length > 0 &&
              locationData.length > 0 &&
              locationData[0].addressDetails != null) {
            for (int i = 0; i < _statesList.length; i++) {
              if (locationData[0].addressDetails!.state ==
                  _statesList[i].state) {
                setState(() {
                  statesDropdownValue = _statesList[i];
                  _districtList = _statesList[i].cities;
                });
              }
            }

            this
                .getCitiesList(
                    countryDropdownValue!.name, statesDropdownValue!.id)
                .then((value) {
              if (value.length > 0) {
                setState(() {
                  _citiesList.clear();
                  _citiesList.addAll(value[0].cities!);
                });

                if (locationData[0].addressDetails!.colonysectorArealocality !=
                    null) {
                  for (int i = 0; i < _citiesList.length; i++) {
                    if (locationData[0].addressDetails!.villagetowncity ==
                        _citiesList[i]) {
                      setState(() {
                        citiesDropDownValue = _citiesList[i];
                      });
                    }
                  }
                }
              }
            });

            if (_districtList!.length > 0) {
              for (int i = 0; i < _districtList!.length; i++) {
                if (locationData[0].addressDetails!.district ==
                    _districtList![i]) {
                  districtDropdownValue = _districtList![i];
                }
              }
            }
          }
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey, Constants.NO_INTERNET,
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<CitiesDAO>> getCitiesList(
      String? countryName, String? stateId) async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = "Getting Cities..";
    });

    var resposne = await _service.getCities(countryName, stateId);
    List<CitiesDAO> _list = [];
    setState(() {
      isLoadingProgress = false;
    });

    if (resposne.statusCode == 200) {
      var data = json.decode(resposne.body);

      bool isString = false;

      if (data['data'] is String) {
        isString = true;
      }

      if (!isString) {
        for (var object in data['data']) {
          _list.add(CitiesDAO.fromJson(object));
        }
      }
    }

    return _list;
  }

  /// Service callfor States

  Future<List<StatesDAO>> getStates(String countryName) async {
    _statesList.clear();
    statesDropdownValue = null;

    http.Response response = await _service
        .getStatesByCountry(countryName)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<StatesDAO> list = [];
    setState(() {
      isLoadingProgress = false;
    });
    if (response.statusCode == 200) {
      var data = json.decode(response.body);
      for (var object in data["data"]) {
        for (var statesObject in object["states"])
          list.add(StatesDAO.fromJson(statesObject));
      }
    }

    return list;
  }

  buildTableContent(
      String textName, TextEditingController _controller, bool isNumberKeyPad,
      {bool isEnable = true}) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(textName,
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: Constants.INDIAN_RUPEE))),
                  )),
            ),
            Expanded(
                flex: 2,
                child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5),
                  child: TextFormField(
                    enabled: isEnable,
                    keyboardType:
                        (defaultTargetPlatform == TargetPlatform.iOS &&
                                isNumberKeyPad)
                            ? TextInputType.numberWithOptions(
                                signed: true, decimal: false)
                            : TextInputType.text,
                    textInputAction: TextInputAction.next,
                    controller: _controller,
                    inputFormatters: (textName == Constants.POST_CODE_STRING ||
                            textName == Constants.PHONE_NUMBER)
                        ? [
                            new LengthLimitingTextInputFormatter(
                                (textName == Constants.PHONE_NUMBER) ? 10 : 6),
                            FilteringTextInputFormatter.digitsOnly
                          ]
                        : [],
                    style: TextStyle(fontFamily: Constants.INDIAN_RUPEE),
                    decoration: InputDecoration(
                      hintText: textName,
                      border: InputBorder.none,
                    ),
                  ),
                ))
          ],
        ));
  }

  buildUsersDropdown(String text) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(text,
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: StyleView.FONT_TITLE))),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5, right: 5),
                  child: DropdownButton<UserModel>(
                      onTap: () {
                        FocusScope.of(context).unfocus();
                      },
                      value: usersDropdownValue,
                      isExpanded: true,
                      hint: Text(
                          Language()
                              .getString(Constants.SELECT_USER, selectedLang),
                          style: TextStyle(fontFamily: StyleView.FONT_TITLE)),
                      underline: SizedBox(),
                      onChanged: (UserModel? data) {
                        setState(() {
                          usersDropdownValue = data;
                          _contactNumberController.text =
                              data!.dialerCode! + " " + data.contact!;
                        });
                      },
                      items: _usersList.map((UserModel model) {
                        return new DropdownMenuItem<UserModel>(
                          child: new Text(model.name!,
                              style:
                                  TextStyle(fontFamily: StyleView.FONT_TITLE)),
                          value: model,
                        );
                      }).toList())),
            )
          ],
        ));
  }

  buildStateDropdown(String text) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(text,
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: StyleView.FONT_TITLE))),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5, right: 5),
                  child: DropdownButton<StatesDAO>(
                      onTap: () {
                        FocusScope.of(context).unfocus();
                      },
                      value: statesDropdownValue,
                      isExpanded: true,
                      hint: Text(
                          Language()
                              .getString(Constants.SELECT_STATE, selectedLang),
                          style: TextStyle(fontFamily: StyleView.FONT_TITLE)),
                      underline: SizedBox(),
                      onChanged: (StatesDAO? data) {
                        _districtList!.clear();

                        districtDropdownValue = null;
                        _citiesList.clear();
                        citiesDropDownValue = null;
                        setState(() {
                          statesDropdownValue = data;
                          _districtList!.addAll(data!.cities!);
                        });
                        this
                            .getCitiesList(countryDropdownValue!.name,
                                statesDropdownValue!.id)
                            .then((value) {
                          if (value.length > 0) {
                            setState(() {
                              _citiesList.clear();
                              _citiesList.addAll(value[0].cities!);
                            });
                          }
                        });
                      },
                      items: _statesList.map((StatesDAO model) {
                        return new DropdownMenuItem<StatesDAO>(
                          child: new Text(model.state!,
                              style:
                                  TextStyle(fontFamily: StyleView.FONT_TITLE)),
                          value: model,
                        );
                      }).toList())),
            )
          ],
        ));
  }

  /// City Dropdown
  buildCityDropdown(String text) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(text,
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: StyleView.FONT_TITLE))),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5, right: 5),
                  child: DropdownButton<String>(
                      value: citiesDropDownValue,
                      isExpanded: true,
                      hint: Text(
                        Language()
                            .getString(Constants.SELECT_CITY, selectedLang),
                      ),
                      underline: SizedBox(),
                      onChanged: (String? data) {
                        setState(() {
                          citiesDropDownValue = data;
                        });
                      },
                      onTap: () {
                        FocusScope.of(context).unfocus();
                      },
                      items: _citiesList.map((String model) {
                        return new DropdownMenuItem<String>(
                          child: new Text(model),
                          value: model,
                        );
                      }).toList())),
            )
          ],
        ));
  }

  buildDistrictDropdown(String text) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(text,
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: StyleView.FONT_TITLE))),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5, right: 5),
                  child: DropdownButton<String>(
                      onTap: () {
                        FocusScope.of(context).unfocus();
                      },
                      value: districtDropdownValue,
                      isExpanded: true,
                      hint: Text(
                          Language().getString(
                              Constants.SELECT_DISTRICT, selectedLang),
                          style: TextStyle(fontFamily: StyleView.FONT_TITLE)),
                      underline: SizedBox(),
                      onChanged: (String? data) {
                        setState(() {
                          districtDropdownValue = data;
                        });
                        // AppController
                        //     .instance.getOrganizationFieldsData.district = data;
                      },
                      items: _districtList!.map((String model) {
                        return new DropdownMenuItem<String>(
                          child: new Text(model,
                              style:
                                  TextStyle(fontFamily: StyleView.FONT_TITLE)),
                          value: model,
                        );
                      }).toList())),
            )
          ],
        ));
  }

  buildCountryDropdown(String text) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(text,
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: StyleView.FONT_TITLE))),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5, right: 5),
                  child: DropdownButton<CountryDAO>(
                      onTap: () {
                        FocusScope.of(context).unfocus();
                      },
                      value: countryDropdownValue,
                      isExpanded: true,
                      hint: Text(
                          Language().getString(
                              Constants.SELECT_COUNTRY, selectedLang),
                          style: TextStyle(fontFamily: StyleView.FONT_TITLE)),
                      underline: SizedBox(),
                      onChanged: (CountryDAO? data) {
                        countryDropdownValue = data;

                        loadStatesDropdown();
                      },
                      items: _countryList.map((CountryDAO model) {
                        return new DropdownMenuItem<CountryDAO>(
                          child: new Text(model.name!,
                              style:
                                  TextStyle(fontFamily: StyleView.FONT_TITLE)),
                          value: model,
                        );
                      }).toList())),
            )
          ],
        ));
  }

  buildMobileNumberTextFormField(
      String textName, TextEditingController _controller, bool isEnable) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(textName,
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: Constants.INDIAN_RUPEE))),
                  )),
            ),
            Expanded(
                flex: 2,
                child: Row(
                  children: [
                    Expanded(
                      child: Container(
                        color: Colors.white70,
                        child: TextFormField(
                          controller: _contactNumberController,
                          keyboardType: TextInputType.number,
                          // focusNode: FocusNode(canRequestFocus: false),
                          style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                          decoration: InputDecoration(
                            hintText: textName,
                            border: InputBorder.none,
                          ),
                          onChanged: (value) {
                            _contactNumberController.text =
                                "+" + _contactNumberController.text;
                            _contactNumberController.selection =
                                TextSelection.fromPosition(TextPosition(
                                    offset:
                                        _contactNumberController.text.length));
                          },
                          inputFormatters: [
                            CommonMethods.inputTextFormatter(isNumber: true)
                          ],
                        ),
                      ),
                    ),
                  ],
                ))
          ],
        ));
  }

  Widget bottomView() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 20),
      child: CommonButtonsView(
        context: context,
        b1Text: Language().getString(Constants.STR_CANCEL, selectedLang),
        b2Text: widget.isUpdateLocation!
            ? Language().getString(Constants.UPDATE_STRING, selectedLang)
            : Language().getString(Constants.ADD_STRING, selectedLang),
        onb1Action: () {
          Navigator.of(context).pop();
        },
        onb2Action: () async {
          String errorMessage = validationgLocationFields();
          if (errorMessage.isNotEmpty) {
            Dialogs.yesCancelDialog(
                context,
                Language().getString(Constants.ERROR, selectedLang),
                Language().getString(errorMessage, selectedLang),
                Language().getString(Constants.OKAY_STR, selectedLang),
                "",
                false);
          } else {
            if (await NetworkStatus.getInternetStatus()) {
              setState(() {
                isLoadingProgress = true;
                progressMessage = (widget.isUpdateLocation!
                    ? Constants.UPDATING
                    : Constants.CREATING);
              });
              if (widget.isUpdateLocation!) {
                this.serviceCallUpdateLocation();
              } else {
                this.serviceCallCreateLocation();
              }
            } else {
              AppUtills.showSnackBar(_scaffoldkey,
                  Language().getString(Constants.NO_INTERNET, selectedLang),
                  snackBarBgColor: Colors.black,
                  messageColor: Colors.white,
                  buttonColor: Colors.white);
            }
          }
        },
      ),
    );
  }
}
