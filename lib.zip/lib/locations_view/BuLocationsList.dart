import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/core/enums/privilleges_enum.dart';
import 'package:vyaparlive/locations_view/card_view/location_card_view.dart';
import 'package:vyaparlive/locations_view/controller/location_controller.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/animation/list_loader/ListLoader.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:flutx/flutx.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/BusinessUnitModel.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/bu_model/LocationsModel.dart';
import 'dart:convert';
import 'package:vyaparlive/service/organization_service.dart';
import 'package:url_launcher/url_launcher.dart';
// import '../Organization/component/SelectLocation.dart';
// import '../Organization/component/SelectLocationWeb.dart';
import '../Organization/component/select_location_interface.dart';

class BuLocationsListPage extends StatefulWidget {
  BuLocationsListPage({this.buId, this.buName});
  final String? buName;
  final String? buId;
  @override
  _BuLocationsListPageState createState() => _BuLocationsListPageState();
}

class _BuLocationsListPageState extends State<BuLocationsListPage> {
  List<BusinessUnitModel> _buList = [];
  List<Locations> locationsList = [];
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  late OrganizationService _organizationService;
  late ThemeData theme;
  late LocationController _locationController;
  List<Map> _namesData = [];
  @override
  void initState() {
    super.initState();

    this.getLoadLanguage();
    theme = AppTheme.vyaparTheme;
    _locationController = FxControllerStore.putOrFind(LocationController());
    _organizationService = OrganizationService();
    loadLocationData();
  }

  getLoadLanguage() async {
    setState(() {
      _namesData = [
        {"name": Language().getString(Constants.CALL, selectedLang)},
        {"name": Language().getString(Constants.EDIT, selectedLang)}
      ];
    });
  }

  loadLocationData() async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
      });

      getBuData().then((value) {
        setState(() {
          _buList.addAll(value);
          locationsList.addAll(_buList[0].locationsList!);
          locationsList = locationsList.reversed.toList();
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Widget _listViewData() {
    if (isLoadingProgress) {
      return ListLoader();
    } else if (!isLoadingProgress && locationsList.length == 0) {
      return Center(
        child: Text(
          Language().getString(Constants.NO_LOCATIONS_ADDED, selectedLang),
        ),
      );
    } else {
      return Column(
        children: [
          Expanded(
            child: Container(
              margin: EdgeInsets.only(top: 20),
              child: AnimationLimiter(
                child: ListView.separated(
                    shrinkWrap: true,
                    itemBuilder: (context, index) {
                      return AnimationConfiguration.staggeredList(
                          position: index,
                          duration: Duration(milliseconds: 1200),
                          child: SlideAnimation(
                            verticalOffset: 50.0,
                            child: FadeInAnimation(
                                child: LocationCard(
                                    converssionNames: _namesData,
                                    address:
                                        locationsList[index].addressDetails!,
                                    contactName:
                                        locationsList[index].contactPerson!,
                                    locationName:
                                        locationsList[index].locationName!,
                                    phoneNumber:
                                        locationsList[index].contactNumber!,
                                    onPressEdit: () {
                                      if (kIsWeb) {
                                        Navigator.push(
                                            context,
                                            new MaterialPageRoute(
                                                builder: (context) =>
                                                    SelectLocation(
                                                      buId: widget.buId,
                                                      isFromLocationTab: true,
                                                      isLocationUpdate: true,
                                                      locationData:
                                                          locationsList[index],
                                                      locationType:
                                                          locationsList[index]
                                                              .locationType,
                                                    ))).then((value) => {
                                                      loadLocationData()
                                                    });
                                      } else {
                                        Navigator.push(
                                            context,
                                            new MaterialPageRoute(
                                                builder: (context) =>
                                                    SelectLocation(
                                                      buId: widget.buId,
                                                      isFromLocationTab: true,
                                                      isLocationUpdate: true,
                                                      locationData:
                                                          locationsList[index],
                                                      locationType:
                                                          locationsList[index]
                                                              .locationType,
                                                    ))).then(
                                            (value) => loadLocationData());
                                      }
                                    },
                                    onPressCall: () {
                                      if (kIsWeb) {
                                        return;
                                      }
                                      Uri uri = Uri.parse("tel:" +
                                          locationsList[index].contactNumber!);
                                      launchUrl(uri);
                                    })),
                          ));
                    },
                    separatorBuilder: (context, index) => new Divider(
                          height: 5.0,
                          color: Colors.transparent,
                        ),
                    itemCount: locationsList.length),
              ),
            ),
          ),
        ],
      );
    }
  }

  Widget _buildBody() {
    return Stack(
      children: [
        SafeArea(
          child: Scaffold(
            extendBodyBehindAppBar: true,
            key: _scaffoldkey,
            backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
            appBar: AppBar(
              centerTitle: true,
              elevation: 0,
              iconTheme: IconThemeData(color: theme.colorScheme.primary),
              title: AppbarName(
                  title: Language().getString(Constants.LOCATIONS, selectedLang),
                  buName: "${widget.buName}"),
              backgroundColor: Colors.transparent,
              actions: <Widget>[
                if (CommonMethods.isPrivillegeExist(
                    context, PrivillegesActions.KEY_MY_COMPANY_BU_LOCATIONS_ADD))
                  IconButton(
                      icon: Icon(FeatherIcons.plus),
                      onPressed: () async {
                        if (kIsWeb) {
                          Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => SelectLocation(
                                          buId: widget.buId,
                                          isFromLocationTab: true,
                                          isLocationUpdate: false,
                                          locationData: null,
                                          locationType: locationsList.length == 0
                                              ? Constants.KEY_MAIN_OFFICE
                                              : Constants.KEY_STOCK_RECEIVE)))
                              .then((value) => loadLocationData());
                        } else {
                          Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => SelectLocation(
                                          buId: widget.buId,
                                          isFromLocationTab: true,
                                          isLocationUpdate: false,
                                          locationData: null,
                                          locationType: locationsList.length == 0
                                              ? Constants.KEY_MAIN_OFFICE
                                              : Constants.KEY_STOCK_RECEIVE)))
                              .then((value) => loadLocationData());
                        }
                      })
              ],
            ),
            body: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomLeft,
                    colors: [
                      Colors.white,
                      theme.colorScheme.primaryContainer,
                      theme.colorScheme.primary,
                    ],
                  ),
                ),
                padding: EdgeInsets.all(10.0),
                child: _listViewData()),
          ),
        ),
      ],
    );
  }

  @override
  void dispose() {
    _locationController.dispose();
    super.dispose();
  }

  @override
  void setState(VoidCallback fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  Widget build(BuildContext context) {
    return FxBuilder(
        controller: _locationController,
        builder: (_locationController) => _buildBody());
  }

  Future<List<BusinessUnitModel>> getBuData() async {
    _buList.clear();
    locationsList.clear();
    String body = json.encode({"id": widget.buId});

    var response = await _organizationService
        .getOrganizationDataById(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<BusinessUnitModel> _list = [];

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var object = json.decode(_grpcResponse.message!);

      _list.add(BusinessUnitModel.fromJson(object[0]));
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return _list;
  }
}
