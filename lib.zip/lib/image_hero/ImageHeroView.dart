import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

class ImageHeroView extends StatelessWidget {
  ImageHeroView({this.fileUrl, this.tagName});
  final String? fileUrl;
  final String? tagName;
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.black12,
        appBar: AppBar(backgroundColor: Colors.black12, title: Text("")),
        body: GestureDetector(
          onTap: () {
            Navigator.pop(context);
          },
          child: Container(
            child: Center(
              child: Hero(
                  tag: tagName!,
                  child: displayStockImageForHero(context, fileUrl)),
            ),
          ),
        ),
      ),
    );
  }

  displayStockImageForHero(BuildContext context, String? fileUrl) {
    return CachedNetworkImage(
      imageUrl: fileUrl!,
      height: MediaQuery.of(context).size.height,
      errorWidget: (context, url, error) => Icon(Icons.error),
    );
  }
}
