import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:vyaparlive/Reports/DownloadAllReports.dart';
import 'package:vyaparlive/assets_management/CreateAssetProductPage.dart';
import 'package:vyaparlive/assets_management/list_card_view/AssetsListCardView.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/DateFilterUtil.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/AssestListDAO.dart';
import 'package:vyaparlive/model/AssetsGroupModel.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:vyaparlive/service/assets_management_grpc.dart';
import 'package:vyaparlive/utills/vyapar_info.dart';

class AssetsListPage extends StatefulWidget {
  @override
  _AssetsListPageState createState() => _AssetsListPageState();
}

class _AssetsListPageState extends State<AssetsListPage> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? selectedLang = AppController.instance.getSelectedlanguage;
  String? buId = "";
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  List<AssetsListDAO> assetsList = [];
  late AssetsManagementGrpcService _assetsService;
  TextEditingController _searchController = TextEditingController();
  bool isEnableDateFilter = false;
  bool isShowFloatButton = false;
  String fromDate = "";
  String toDate = "";
  DateFormat formatter = DateFormat("yyyy-MM-dd");
  List<AssetsGroupModel> assetsGroupist = [];
  AssetsGroupModel? assetGroupDropdownValue;
  bool isForSearchParams = false;
  List<Map>? _mapData;

  @override
  void initState() {
    super.initState();
    _assetsService = AssetsManagementGrpcService();
    this.getLoadLanguage();
    buId = AppController.instance.getMyBuId;
    fromDate = formatter.format(DateTime.now());
    toDate = formatter.format(DateTime.now());
    this.loadAssetsListData();
    this.loadAssetsGroupData();
  }

  loadAssetsListData({String name = "", String? groupName = ""}) async {
    if (await NetworkStatus.getInternetStatus()) {
      if (!isForSearchParams) {
        setState(() {
          isLoadingProgress = true;
        });
      }
      this.getAssetsList(name: name, groupName: groupName).then((value) {
        setState(() {
          assetsList.clear();
          assetsList.addAll(value);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<AssetsListDAO>> getAssetsList(
      {String name = "", String? groupName = ""}) async {
    String body = json.encode({
      "bu_id": buId,
      "filters": {"name": name, "groupName": groupName}
    });

    var response = await _assetsService
        .getAssetsList(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    List<AssetsListDAO> list = [];
    GRPCResponse _grpcResponse = response;

    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(data)) {
        for (var objects in data['results']) {
          list.add(AssetsListDAO.fromJson(objects));
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return list;
  }

  getLoadLanguage() async {
    _mapData = [
      {"name": Language().getString(Constants.ASSET_NAME, selectedLang)},
      {"name": Language().getString(Constants.GROUP, selectedLang)},
      {"name": Language().getString(Constants.QUANTITY, selectedLang)},
      {"name": Language().getString(Constants.EDIT, selectedLang)},
      {"name": Language().getString(Constants.DELETE_STRING, selectedLang)},
    ];
  }

  @override
  Widget build(BuildContext context) {
    return
        // WillPopScope(
        //   onWillPop: () {
        //     return CommonMethods.onBackPress(context);
        //   },
        //   child:
        Stack(
      children: [
        SafeArea(
          child: Scaffold(
            key: _scaffoldkey,
            backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
            appBar: AppBar(
              centerTitle: true,
              title: Column(children: <Widget>[
                Text(
                  Language().getString(Constants.ASSETS_LIST, selectedLang),
                ),
                Text(
                  AppController.instance.getBuName,
                  style: TextStyle(fontSize: 13.0),
                )
              ]),
              backgroundColor: Color(0xFF083e64),
              actions: [
                TextButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          PageTransition(
                              context: context,
                              page: CreateAssetProductPage(
                                title: Constants.CREATE_ASSETS_LIST,
                              ))).then((value) => this.loadAssetsListData());
                    },
                    child: Icon(
                      Icons.add,
                      color: Colors.white,
                    ))
              ],
            ),
            floatingActionButton: (isShowFloatButton)
                ? FloatingActionButton(
                    backgroundColor: Color(Constants.APP_COLOR),
                    onPressed: () {
                      setState(() {
                        isShowFloatButton = false;
                        isLoadingProgress = true;
                        _searchController.clear();
                        assetGroupDropdownValue = null;
                      });
          
                      loadAssetsListData();
                    },
                    child: Text(
                      Language().getString(Constants.CLEAR_FILTERS, selectedLang),
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white, fontSize: 11.0),
                    ))
                : null,
            // drawer: MyDrawer(),
            body: Container(
              margin: EdgeInsets.symmetric(
                horizontal: 10.0,
                vertical: 5.0,
              ),
              child: Column(
                children: <Widget>[
                  // (assetsList.length > 0 && _mapData!.length > 0)
                  //     ? this.showDownloadButton()
                  //     : Container(),
                  this.buildSearchBarView(),
                  (isEnableDateFilter)
                      ? DateFilterUtill(
                          fromDate: fromDate,
                          toDate: toDate,
                          onFromDateSelected: (value) {
                            setState(() {
                              fromDate = value;
                            });
                          },
                          onToDateSelected: (value) {
                            setState(() {
                              toDate = value;
                            });
                          },
                          onSearchParms: () {
                            setState(() {
                              isShowFloatButton = true;
                              isLoadingProgress = true;
                            });
                          },
                        )
                      : Container(),
                  (assetsList.length > 0)
                      ? Expanded(
                          child: ListView.separated(
                              shrinkWrap: true,
                              itemBuilder: (context, index) {
                                return AssetsListCardPage(
                                  modelData: assetsList[index],
                                  onEdit: () {
                                    Navigator.push(
                                      context,
                                      PageTransition(
                                        context: context,
                                        page: CreateAssetProductPage(
                                          title: Constants.UPDATE_ASSETS_LIST,
                                          assetRecordId: assetsList[index].id,
                                        ),
                                      ),
                                    ).then((value) => loadAssetsListData());
                                  },
                                  onDelete: () async {},
                                  mapData: _mapData,
                                );
                              },
                              separatorBuilder: (context, index) => Divider(
                                    color: Colors.transparent,
                                    height: 5.0,
                                  ),
                              itemCount: assetsList.length),
                        )
                      : Container(
                          child: Center(
                            child: Text(Language().getString(
                                Constants.NO_DATA_FOUND, selectedLang)),
                          ),
                        )
                ],
              ),
            ),
          ),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
      // ),
    );
  }

  Widget buildSearchBarView() {
    return Container(
      height: 40.0,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(5.0),
        border: Border.all(
          color: Colors.grey,
        ),
      ),
      child: Row(
        children: <Widget>[
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(5.0),
                  bottomLeft: Radius.circular(5.0),
                ),
                color: Colors.white,
              ),
              padding: EdgeInsets.only(left: 5),
              child: TextFormField(
                controller: _searchController,
                onChanged: onSearchTextChanged,
                style: TextStyle(fontFamily: 'IndianRupee'),
                decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: Language()
                        .getString(Constants.SEARCH_BY_NAME, selectedLang),
                    hintStyle: TextStyle(
                        fontSize: 13.0, fontFamily: StyleView.FONT_TITLE)),
              ),
            ),
          ),
          (_searchController.text.length > 0)
              ? Container(
                  color: Colors.white,
                  child: IconButton(
                      icon: Icon(
                        Icons.close,
                        color: Colors.red,
                        size: 20.0,
                      ),
                      onPressed: () {
                        CommonMethods.hideKeyboard(context);
                        _searchController.clear();
                        onSearchTextChanged(_searchController.text);
                      }),
                )
              : Container(),
          // Container(
          //   color: Colors.white,
          //   child: IconButton(
          //       icon: Icon(Icons.date_range),
          //       onPressed: () {
          //         CommonMethods.hideKeyboard(context);
          //         setState(() {
          //           if (isEnableDateFilter) {
          //             isEnableDateFilter = false;
          //           } else {
          //             isEnableDateFilter = true;
          //           }
          //         });
          //       }),
          // ),
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.only(
                topRight: Radius.circular(5.0),
                bottomRight: Radius.circular(5.0),
              ),
              color: Colors.white,
            ),
            child: IconButton(
                icon: Icon(Icons.filter_list),
                onPressed: () {
                  CommonMethods.hideKeyboard(context);
                  this.showFiltersPopup();
                }),
          )
        ],
      ),
    );
  }

  onSearchTextChanged(String text) async {
    if (text.isEmpty) {
      isLoadingProgress = true;
      isForSearchParams = false;
      this.loadAssetsListData();
    } else {
      isLoadingProgress = false;
      isForSearchParams = true;
      this.loadAssetsListData(name: text);
    }
  }

  showFiltersPopup() {
    return showDialog(
        context: context,
        barrierColor: Colors.black54,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
            title: Text(
              Language().getString(Constants.SORT_BY_STR, selectedLang),
            ),
            actions: [
              Container(
                width: MediaQuery.of(context).size.width,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    TextButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                        child: Text(
                          Language()
                              .getString(Constants.STR_CANCEL, selectedLang),
                          style: TextStyle(
                              color: Color(Constants.APP_COLOR),
                              fontSize: 18.0),
                        )),
                    TextButton(
                        onPressed: () {
                          setState(() {
                            isShowFloatButton = true;
                            isLoadingProgress = true;
                          });

                          Navigator.of(context).pop();
                          if (assetGroupDropdownValue != null) {
                            this.loadAssetsListData(
                                groupName: assetGroupDropdownValue!.name);
                          }
                        },
                        child: Text(
                          Language()
                              .getString(Constants.SUBMIT_STRING, selectedLang),
                          style: TextStyle(
                              color: Color(Constants.APP_COLOR),
                              fontSize: 18.0),
                        ))
                  ],
                ),
              )
            ],
            content: StatefulBuilder(
                builder: (BuildContext context, StateSetter setState) {
              return Container(
                decoration: AppUtills.boxDecoration(),
                child: this.buildAssetsGroupDropdown(setState),
              );
            })));
  }

  loadAssetsGroupData({String name = ""}) async {
    if (await NetworkStatus.getInternetStatus()) {
      this.getAssetsGroupData(name: name).then((value) {
        setState(() {
          assetsGroupist.clear();
          assetsGroupist.addAll(value);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<AssetsGroupModel>> getAssetsGroupData({String name = ""}) async {
    String body = json.encode({
      "bu_id": buId,
      "filters": {"name": name}
    });

    var response = await _assetsService
        .getAssetsGroupList(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<AssetsGroupModel> list = [];
    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;

    if (!_grpcResponse.isError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);

      for (var object in data['results']) {
        list.add(AssetsGroupModel.fromJson(object));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return list;
  }

  Widget buildAssetsGroupDropdown(StateSetter setState) {
    return Container(
        height: 50.0,
        child: Row(
          children: [
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        Language().getString(Constants.GROUP, selectedLang),
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_15,
                            fontFamily: 'IndianRupee'),
                      ),
                    ),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                color: Colors.white,
                padding: EdgeInsets.only(left: 5.0),
                child: DropdownButton<AssetsGroupModel>(
                    onTap: () {
                      FocusScope.of(context).unfocus();
                    },
                    value: assetGroupDropdownValue,
                    hint: new Text(Language()
                        .getString(Constants.SELECT_GROUP, selectedLang)),
                    isExpanded: true,
                    underline: SizedBox(),
                    onChanged: (AssetsGroupModel? data) {
                      setState(() {
                        assetGroupDropdownValue = data;
                      });
                    },
                    items: assetsGroupist.map((AssetsGroupModel model) {
                      return new DropdownMenuItem<AssetsGroupModel>(
                        child: new Text(model.name!),
                        value: model,
                      );
                    }).toList()),
              ),
            ),
          ],
        ));
  }

  Widget showDownloadButton() {
    String reqBody = "";
    String reqUrl = "";
    reqUrl = Constants.NEW_BASE_URL + "http-utils/reports/assetsList";
    reqBody = json.encode({
      "bu_id": buId,
      "filters": {
        "name": _searchController.text,
        "status": "",
        "groupName":
            assetGroupDropdownValue != null ? assetGroupDropdownValue!.name : ""
      }
    });

    var encryptedData = VyaparInfo.encryptData(reqBody);
    Map map = {
      "data": encryptedData,
      "Authorization": AppController.instance.getAuthorizationKey
    };
    return DownloadAllReportsPage(
        isApiCallComplete: (apiCallCompleted) {
          if (apiCallCompleted) {
            setState(() {
              isLoadingProgress = false;
            });
          } else {
            setState(() {
              isLoadingProgress = true;
            });
          }
        },
        url: reqUrl,
        mapData: map,
        fileName: Constants.ASSETS_LIST,
        strDownload: Language().getString(Constants.DOWNLOAD, selectedLang));
  }
}
