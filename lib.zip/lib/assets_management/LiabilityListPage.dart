import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Reports/DownloadAllReports.dart';
import 'package:vyaparlive/assets_management/CreateAssetProductPage.dart';
import 'package:vyaparlive/assets_management/ScrapItemDetails.dart';
import 'package:vyaparlive/assets_management/list_card_view/ScrapListCardView.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/DateFilterUtil.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/AssetsGroupModel.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/ScrapListDAO.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:vyaparlive/service/assets_management_grpc.dart';
import 'package:vyaparlive/utills/vyapar_info.dart';

class LiabilityListPage extends StatefulWidget {
  @override
  _LiabilityListPageState createState() => _LiabilityListPageState();
}

class _LiabilityListPageState extends State<LiabilityListPage> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  String? buName = "";
  String? buId = "";
  bool isLoadingProgress = true;
  String progressMessage = Constants.GETTING_DATA;
  String fromDate = "";
  String toDate = "";
  TextEditingController _searchController = TextEditingController();
  bool isEnableDateFilter = true;
  bool isShowFloatButton = false;
  DateFormat formatter = DateFormat("yyyy-MM-dd");
  late AssetsManagementGrpcService _assetsService;
  List<ScrapListDAO> liabilityList = [];
  List<AssetsGroupModel> assetsGroupist = [];
  AssetsGroupModel? assetGroupDropdownValue;
  DateTime mnthStartDate =
      DateTime.utc(DateTime.now().year, DateTime.now().month, 1);
  List<Map> _mapData = [];

  @override
  void initState() {
    super.initState();
    this.getLoadLanguage();
    _assetsService = AssetsManagementGrpcService();
    buName = AppController.instance.getBuName;
    buId = AppController.instance.getMyBuId;
    fromDate = formatter.format(mnthStartDate);
    toDate = formatter.format(DateTime.now());
    this.loadLiabilityListData(fromDate: fromDate, toDate: toDate);
    this.loadAssetsGroupData();
  }

  loadLiabilityListData(
      {String name = "",
      String fromDate = "",
      String toDate = "",
      String? groupName = ""}) async {
    getLiabilityList(
            name: name,
            fromDate: fromDate,
            toDate: toDate,
            groupName: groupName)
        .then((value) {
      setState(() {
        liabilityList.clear();
        liabilityList.addAll(value);
      });
    });
  }

  getLoadLanguage() {
    _mapData = [
      {"name": Language().getString(Constants.ASSET_NAME, selectedLang)},
      {"name": Language().getString(Constants.GROUP, selectedLang)},
      {"name": Language().getString(Constants.DISPOSED_DATE, selectedLang)},
      {"name": Language().getString(Constants.DATE, selectedLang)},
      {"name": Language().getString(Constants.STATUS_STRING, selectedLang)},
      {"name": Language().getString(Constants.EDIT, selectedLang)},
      {"name": Language().getString(Constants.DELETE_STRING, selectedLang)},
    ];
  }

  @override
  Widget build(BuildContext context) {
    return
        // WillPopScope(
        //   onWillPop: () {
        //     return CommonMethods.onBackPress(context);
        //   },
        //   child:
        Stack(
      children: [
        SafeArea(
          child: Scaffold(
            key: _scaffoldkey,
            backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
            appBar: AppBar(
              backgroundColor: Color(Constants.APP_COLOR),
              centerTitle: true,
              title: Column(
                children: [
                  Text(Language()
                      .getString(Constants.LIABILITY_LIST, selectedLang)),
                  Text(
                    buName!,
                    style: TextStyle(fontSize: 13.0),
                  ),
                ],
              ),
            ),
            floatingActionButton: (isShowFloatButton)
                ? FloatingActionButton(
                    backgroundColor: Color(Constants.APP_COLOR),
                    onPressed: () {
                      setState(() {
                        isLoadingProgress = true;
                        isShowFloatButton = false;
                        assetGroupDropdownValue = null;
                      });
                      fromDate = formatter.format(mnthStartDate);
                      toDate = formatter.format(DateTime.now());
                      this.loadLiabilityListData(
                          fromDate: fromDate, toDate: toDate);
                    },
                    child: Text(
                      Language().getString(Constants.CLEAR_FILTERS, selectedLang),
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white, fontSize: 11.0),
                    ))
                : null,
            // drawer: MyDrawer(),
            body: Container(
                margin: EdgeInsets.symmetric(vertical: 5.0, horizontal: 5.0),
                child: Column(
                  children: [
                    // (liabilityList.length > 0)
                    //     ? this.showDownloadButton()
                    //     : Container(),
                    this.buildSearchBarView(),
                    (isEnableDateFilter)
                        ? DateFilterUtill(
                            fromDate: fromDate,
                            toDate: toDate,
                            onFromDateSelected: (value) {
                              setState(() {
                                fromDate = value;
                              });
                            },
                            onToDateSelected: (value) {
                              setState(() {
                                toDate = value;
                              });
                            },
                            onSearchParms: () {
                              setState(() {
                                isShowFloatButton = true;
                                isLoadingProgress = true;
                              });
          
                              this.loadLiabilityListData(
                                  fromDate: fromDate, toDate: toDate);
                            },
                          )
                        : Container(),
                    (liabilityList.length > 0)
                        ? Expanded(
                            child: ListView.separated(
                                itemBuilder: (context, index) {
                                  return ScrapListCardView(
                                      modelData: liabilityList[index],
                                      onDetailsPage: () {
                                        Navigator.push(
                                            context,
                                            PageTransition(
                                                context: context,
                                                page: ScrapItemDetailsPage(
                                                  scrapId:
                                                      liabilityList[index].id,
                                                )));
                                      },
                                      onEdit: () {
                                        Navigator.push(
                                          context,
                                          PageTransition(
                                            context: context,
                                            page: CreateAssetProductPage(
                                              title: Constants.UPDATE_ASSETS_LIST,
                                              assetRecordId:
                                                  liabilityList[index].id,
                                            ),
                                          ),
                                        ).then((value) => this
                                            .loadLiabilityListData(
                                                fromDate: fromDate,
                                                toDate: toDate));
                                      },
                                      mapData: _mapData);
                                },
                                separatorBuilder: (context, index) => Divider(
                                      color: Colors.transparent,
                                      height: 5.0,
                                    ),
                                itemCount: liabilityList.length),
                          )
                        : Container(
                            child: Center(
                              child: Text(Language().getString(
                                  Constants.NO_DATA_FOUND, selectedLang)),
                            ),
                          ),
                  ],
                )),
          ),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
      // ),
    );
  }

  Widget buildSearchBarView() {
    return Container(
      height: 40.0,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(5.0),
        border: Border.all(
          color: Colors.grey,
        ),
      ),
      child: Row(
        children: <Widget>[
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(5.0),
                  bottomLeft: Radius.circular(5.0),
                ),
                color: Colors.white,
              ),
              padding: EdgeInsets.only(left: 5),
              child: TextFormField(
                controller: _searchController,
                onChanged: onSearchTextChanged,
                style: TextStyle(fontFamily: 'IndianRupee'),
                decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: Language()
                        .getString(Constants.SEARCH_BY_NAME, selectedLang),
                    hintStyle: TextStyle(
                        fontSize: 13.0, fontFamily: StyleView.FONT_TITLE)),
              ),
            ),
          ),
          (_searchController.text.length > 0)
              ? Container(
                  color: Colors.white,
                  child: IconButton(
                      icon: Icon(
                        Icons.close,
                        color: Colors.red,
                        size: 20.0,
                      ),
                      onPressed: () {
                        CommonMethods.hideKeyboard(context);
                        _searchController.clear();
                        onSearchTextChanged(_searchController.text);
                      }),
                )
              : Container(),
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.only(
                topRight: Radius.circular(5.0),
                bottomRight: Radius.circular(5.0),
              ),
              color: Colors.white,
            ),
            child: IconButton(
                icon: Icon(Icons.filter_list),
                onPressed: () {
                  CommonMethods.hideKeyboard(context);
                  this.showFiltersPopup();
                }),
          )
        ],
      ),
    );
  }

  onSearchTextChanged(String text) async {
    if (text.isEmpty) {
      isLoadingProgress = true;
      this.loadLiabilityListData(fromDate: fromDate, toDate: toDate);
    } else {
      isLoadingProgress = false;
      this.loadLiabilityListData(
          name: text, fromDate: fromDate, toDate: toDate);
    }
  }

  Future<List<ScrapListDAO>> getLiabilityList(
      {String name = "",
      String fromDate = "",
      String toDate = "",
      String? groupName = ""}) async {
    String body = json.encode({
      "bu_id": buId,
      "filters": {
        "name": name,
        "DateFrom": fromDate,
        "DateTo": toDate,
        "groupName": groupName
      }
    });

    var response = await _assetsService
        .getLiabilityData(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    List<ScrapListDAO> list = [];
    GRPCResponse _grpcResponse = response;
    var data = json.decode(_grpcResponse.message!);
    bool isString = false;
    if (data is String) {
      isString = true;
    }

    if (!isString) {
      for (var object in data['results']) {
        list.add(ScrapListDAO.fromJson(object));
      }
    }
  
    return list;
  }

  Widget showDownloadButton() {
    String reqBody = "";
    String reqUrl = "";
    reqUrl = Constants.NEW_BASE_URL + "http-utils/reports/liabilityList";
    reqBody = json.encode({
      "bu_id": buId,
      "filters": {"name": _searchController.text, "status": "", "groupName": ""}
    });

    var encryptedData = VyaparInfo.encryptData(reqBody);
    Map map = {
      "data": encryptedData,
      "Authorization": AppController.instance.getAuthorizationKey
    };
    return DownloadAllReportsPage(
        isApiCallComplete: (apiCallCompleted) {
          if (apiCallCompleted) {
            setState(() {
              isLoadingProgress = false;
            });
          } else {
            setState(() {
              isLoadingProgress = true;
            });
          }
        },
        url: reqUrl,
        mapData: map,
        fileName: Constants.LIABILITY_LIST,
        strDownload: Language().getString(Constants.DOWNLOAD, selectedLang));
  }

  showFiltersPopup() {
    return showDialog(
        context: context,
        barrierColor: Colors.black54,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
            title: Text(
              Language().getString(Constants.SORT_BY_STR, selectedLang),
            ),
            actions: [
              Container(
                width: MediaQuery.of(context).size.width,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    TextButton(
                        onPressed: () {
                          setState(() {
                            assetGroupDropdownValue = null;
                          });
                          Navigator.of(context).pop();
                        },
                        child: Text(
                          Language()
                              .getString(Constants.STR_CANCEL, selectedLang),
                          style: TextStyle(
                              color: Color(Constants.APP_COLOR),
                              fontSize: 18.0),
                        )),
                    TextButton(
                        onPressed: () {
                          setState(() {
                            isShowFloatButton = true;
                            isLoadingProgress = true;
                          });

                          Navigator.of(context).pop();
                          if (assetGroupDropdownValue != null) {
                            this.loadLiabilityListData(
                                groupName: assetGroupDropdownValue!.name,
                                fromDate: fromDate,
                                toDate: toDate);
                          }
                        },
                        child: Text(
                          Language()
                              .getString(Constants.SUBMIT_STRING, selectedLang),
                          style: TextStyle(
                              color: Color(Constants.APP_COLOR),
                              fontSize: 18.0),
                        ))
                  ],
                ),
              )
            ],
            content: StatefulBuilder(
                builder: (BuildContext context, StateSetter setState) {
              return Container(
                decoration: AppUtills.boxDecoration(),
                child: this.buildAssetsGroupDropdown(setState),
              );
            })));
  }

  Widget buildAssetsGroupDropdown(StateSetter setState) {
    return Container(
        height: 50.0,
        child: Row(
          children: [
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        Language().getString(Constants.GROUP, selectedLang),
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_15,
                            fontFamily: 'IndianRupee'),
                      ),
                    ),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                color: Colors.white,
                padding: EdgeInsets.only(left: 5.0),
                child: DropdownButton<AssetsGroupModel>(
                    onTap: () {
                      FocusScope.of(context).unfocus();
                    },
                    value: assetGroupDropdownValue,
                    hint: new Text(Language()
                        .getString(Constants.SELECT_GROUP, selectedLang)),
                    isExpanded: true,
                    underline: SizedBox(),
                    onChanged: (AssetsGroupModel? data) {
                      setState(() {
                        assetGroupDropdownValue = data;
                      });
                    },
                    items: assetsGroupist.map((AssetsGroupModel model) {
                      return new DropdownMenuItem<AssetsGroupModel>(
                        child: new Text(model.name!),
                        value: model,
                      );
                    }).toList()),
              ),
            ),
          ],
        ));
  }

  loadAssetsGroupData() async {
    if (await NetworkStatus.getInternetStatus()) {
      this.getAssetsGroupData().then((value) {
        setState(() {
          assetsGroupist.clear();
          assetsGroupist.addAll(value);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<AssetsGroupModel>> getAssetsGroupData() async {
    String body = json.encode({"bu_id": buId, "filters": {}});

    var response = await _assetsService
        .getAssetsGroupList(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<AssetsGroupModel> list = [];
    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;

    if (!_grpcResponse.isError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);

      for (var object in data['results']) {
        list.add(AssetsGroupModel.fromJson(object));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return list;
  }
}
