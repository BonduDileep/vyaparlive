import 'package:flutter/material.dart';
import 'package:vyaparlive/Product/products_widget/PopupMenuItemDesign.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/model/AssestListDAO.dart';

class AssetsListCardPage extends StatelessWidget {
  final VoidCallback? onEdit;
  final VoidCallback? onDelete;
  final AssetsListDAO? modelData;
  final VoidCallback? onDetailsPage;
  final List<Map>? mapData;
  AssetsListCardPage(
      {this.onDelete,
      this.onEdit,
      this.modelData,
      this.onDetailsPage,
      this.mapData});
  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 5.0,
      color: Colors.grey[200],
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
            child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              flex: 6,
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    this.rowView(mapData![0]['name'], modelData!.name!),
                    this.rowView(
                        mapData![1]['name'],
                        modelData!.groupDetails != null
                            ? modelData!.groupDetails!.name!
                            : ""),
                    this.rowView(
                        mapData![2]['name'],
                        modelData!.quantityDetails != null
                            ? "${modelData!.quantityDetails!.quantity}"
                            : "0"),
                  ]),
            ),
            Expanded(child: this.showPopupOptions(context))
          ],
        )),
      ),
    );
  }

  Widget rowView(String title, String value) {
    return Container(
      margin: EdgeInsets.symmetric(
        vertical: 3.0,
      ),
      child: Row(children: <Widget>[
        Expanded(
          child: Container(
            child: Text(title,
                style: TextStyle(
                    color: Color(Constants.APP_COLOR),
                    fontSize: 14.0,
                    fontWeight: FontWeight.bold)),
          ),
        ),
        Expanded(
          flex: 2,
          child: Container(
            child: Text(" :   " + value,
                style: TextStyle(
                  fontSize: StyleView.FONT_SIZE_13,
                )),
          ),
        ),
      ]),
    );
  }

  Widget showPopupOptions(BuildContext context) {
    return Container(
      child: PopupMenuButton(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(10.0))),
        itemBuilder: (context) => [
          PopupMenuItem(
            child: PopupMenuItemDesingView(
                assetPath: "assets/images/edit_image.png",
                itemName: mapData![3]['name']),
            value: "EDIT",
          ),
          // PopupMenuItem(
          //   child: PopupMenuItemDesingView(
          //       assetPath: "assets/images/details.png",
          //       itemName: Constants.DETAILS),
          //   value: "DETAILS",
          // ),
          PopupMenuItem(
            child: PopupMenuItemDesingView(
                assetPath: "assets/images/transaction_icon_product.png",
                itemName: mapData![4]['name']),
            value: "DELETE",
          ),
        ],
        onSelected: (dynamic value) {
          switch (value) {
            case 'EDIT':
              onEdit!();
              break;
            case "DELETE":
              onDelete!();
              break;
            // case "DETAILS":
            //   onDetailsPage();
            //   break;

            default:
          }
        },
      ),
    );
  }
}
