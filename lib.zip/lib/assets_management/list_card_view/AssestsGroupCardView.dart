import 'package:flutter/material.dart';
import 'package:vyaparlive/Product/products_widget/PopupMenuItemDesign.dart';
import 'package:vyaparlive/components/Constants.dart';

class AssetsGroupListCardView extends StatelessWidget {
  final String? assertName;
  final VoidCallback? editAssertGroup;
  final VoidCallback? deleteAssertGroup;
  final List<Map>? mapData;
  AssetsGroupListCardView(
      {this.assertName,
      this.deleteAssertGroup,
      this.editAssertGroup,
      this.mapData});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 5.0,
      color: Colors.grey[200],
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                // crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
              this.rowView(Icons.business, assertName!, true),
              this.showPopupOptions(context)
            ])),
      ),
    );
  }

  Widget rowView(IconData icon, String value, bool isTextBold) {
    return Container(
      margin: EdgeInsets.symmetric(
        vertical: 3.0,
      ),
      child: Container(
        child: Text(
          value,
          style: TextStyle(
              color: Color(Constants.APP_COLOR),
              fontWeight: (isTextBold) ? FontWeight.bold : FontWeight.normal,
              fontSize: 15.0),
        ),
      ),
    );
  }

  Widget showPopupOptions(BuildContext context) {
    return Container(
      child: PopupMenuButton(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(10.0))),
        itemBuilder: (context) => [
          PopupMenuItem(
            child: PopupMenuItemDesingView(
                assetPath: "assets/images/edit_image.png",
                itemName: mapData![0]["name"]),
            value: "EDIT",
          ),
          PopupMenuItem(
            child: PopupMenuItemDesingView(
                assetPath: "assets/images/transaction_icon_product.png",
                itemName: mapData![1]["name"]),
            value: "DELETE",
          ),
        ],
        onSelected: (dynamic value) {
          switch (value) {
            case 'EDIT':
              editAssertGroup!();
              break;
            case "DELETE":
              deleteAssertGroup!();
              break;

            default:
          }
        },
      ),
    );
  }
}
