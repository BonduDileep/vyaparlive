import 'package:flutter/material.dart';
import 'package:vyaparlive/Product/products_widget/PopupMenuItemDesign.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/model/ScrapListDAO.dart';

class ScrapListCardView extends StatelessWidget {
  final String? assertName;
  final bool isForScrap;
  final ScrapListDAO? modelData;
  final VoidCallback? onEdit;
  final VoidCallback? onDetailsPage;
  final List<Map> mapData;

  ScrapListCardView(
      {this.assertName,
      this.isForScrap = false,
      this.modelData,
      this.onDetailsPage,
      this.onEdit,
      required this.mapData});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 5.0,
      color: Colors.grey[200],
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
            child: Row(
          children: [
            Expanded(
              flex: 6,
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    this.rowView(mapData[0]['name'], modelData!.name!),
                    this.rowView(
                        mapData[1]['name'],
                        modelData!.groupData != null
                            ? modelData!.groupData!.name!
                            : ""),
                    (isForScrap)
                        ? this
                            .rowView(mapData[2]['name'], modelData!.disposedDate!)
                        : this.rowView(
                            mapData[3]['name'],
                            AppUtills.getDateFormate(
                                modelData!.createdDate.toString())),
                    (isForScrap)
                        ? this.rowView(
                            mapData[4]['name'],
                            modelData!.isDisposed!
                                ? Constants.DISPOSED
                                : Constants.NON_DISPOSED)
                        : Container(),
                  ]),
            ),
            (!isForScrap)
                ? Expanded(child: this.showPopupOptions(context))
                : Container()
          ],
        )),
      ),
    );
  }

  Widget rowView(String title, String value) {
    return Container(
      margin: EdgeInsets.symmetric(
        vertical: 3.0,
      ),
      child: Row(children: <Widget>[
        Expanded(
          child: Container(
            child: Text(title,
                style: TextStyle(
                    color: Color(Constants.APP_COLOR),
                    fontSize: 14.0,
                    fontWeight: FontWeight.bold)),
          ),
        ),
        Expanded(
          flex: 2,
          child: Container(
            child: Text(" :   " + value,
                style: TextStyle(
                  fontSize: StyleView.FONT_SIZE_13,
                )),
          ),
        ),
      ]),
    );
  }

  Widget showPopupOptions(BuildContext context) {
    return Container(
      child: PopupMenuButton(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(10.0))),
        itemBuilder: (context) => [
          PopupMenuItem(
            child: PopupMenuItemDesingView(
                assetPath: "assets/images/edit_image.png",
                itemName: mapData[5]['name']),
            value: "EDIT",
          ),
          PopupMenuItem(
            child: PopupMenuItemDesingView(
                assetPath: "assets/images/transaction_icon_product.png",
                itemName: mapData[6]['name']),
            value: "DETAILS",
          ),
        ],
        onSelected: (dynamic value) {
          switch (value) {
            case 'EDIT':
              onEdit!();
              break;

            case "DETAILS":
              onDetailsPage!();
              break;

            default:
          }
        },
      ),
    );
  }
}
