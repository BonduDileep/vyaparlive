import 'dart:async';
import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/TextView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/AssestListDAO.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/InventoryManagmentModel.dart';
import 'package:vyaparlive/model/ProductAttributeModel.dart';
import 'package:vyaparlive/service/assets_management_grpc.dart';

class ScrapItemDetailsPage extends StatefulWidget {
  final String? scrapId;
  final bool isFromScrap;
  ScrapItemDetailsPage({this.scrapId, this.isFromScrap = false});
  @override
  _ScrapItemDetailsPageState createState() => _ScrapItemDetailsPageState();
}

class _ScrapItemDetailsPageState extends State<ScrapItemDetailsPage>
    with SingleTickerProviderStateMixin {
  final format = DateFormat("yyyy-MM-dd");
  DateTime fromdate1 = DateTime.now();
  DateTime todate2 = DateTime.now();

  DateFormat formatter = DateFormat("yyyy-MM-dd");
  String formatttedOfferStartDate = "";
  String formattedOfferEndDate = "";
  String formattedManufactureDate = "";
  String formattedExpireDate = "";
  String formattedReleaseDate = "";
  List<ProductAttributeModel> attributesList = [];

  List<InventoryManagementModel> _inventoryList = [];
  late AnimationController _animationController;
  late Animation _animation;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  String? buId = "";
  bool isLoading = false;
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  late AssetsManagementGrpcService _grpcService;
  AssetsListDAO? scrapData;
  String? orgCurrencySymbol = "";
  @override
  void initState() {
    super.initState();
    _grpcService = AssetsManagementGrpcService();

    buId = AppController.instance.getMyBuId;

    _animationController =
        AnimationController(vsync: this, duration: Duration(seconds: 2));
    _animation = Tween(begin: 50.0, end: 200.0).animate(_animationController)
      ..addStatusListener((state) {
        if (state == AnimationStatus.completed) {
        } else if (state == AnimationStatus.dismissed) {}
      })
      ..addListener(() {
        setState(() {});
      });
    _animationController.forward();
    loadProductData();
    // orgCurrencySymbol = AppController.instance.getBuCurrencySymbol;

    String? symbol = AppController.instance.getBuCurrencySymbol;
    orgCurrencySymbol = (symbol != null && symbol.isNotEmpty && symbol != "-")
        ? symbol
        : "\u20B9";
  }

  loadProductData() async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
      });
      this.getScrapDataById().then((value) {
        setState(() {
          scrapData = value;
          if (scrapData != null) {
            for (int k = 0; k < scrapData!.inventoryData!.length; k++) {
              _inventoryList.add(InventoryManagementModel(
                  locationName: scrapData!.inventoryData![k].locationName,
                  quantity: scrapData!.inventoryData![k].quantity));
            }
          }
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<AssetsListDAO> getScrapDataById() async {
    String body = json.encode({"id": widget.scrapId, "bu_id": buId});

    var response = await _grpcService
        .getAssetListDataById(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          "$onError",
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    var data = AssetsListDAO();

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);

      data = AssetsListDAO.fromJson(resObj[0]);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    return data;
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        SafeArea(
          child: Scaffold(
              key: _scaffoldkey,
              backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
              appBar: AppBar(
                centerTitle: true,
                title: Column(children: <Widget>[
                  Text(
                    Language().getString(
                        widget.isFromScrap
                            ? Constants.SCRAP_DETAILS
                            : Constants.LIABILITY_DETAILS,
                        selectedLang),
                    style: TextStyle(fontSize: 15.0),
                  ),
                  Text(
                    AppController.instance.getBuName,
                    style: TextStyle(fontSize: 15.0),
                  )
                ]),
                actions: <Widget>[
                  AppUtills.homeButton(context),
                ],
                backgroundColor: Color(0xFF083e64),
              ),
              body: (scrapData == null)
                  ? Text(Language()
                      .getString(Constants.NO_DATA_FOUND, selectedLang))
                  : SingleChildScrollView(
                      padding: EdgeInsets.symmetric(horizontal: 5.0),
                      child: Container(
                        color: Colors.white,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Container(
                              width: MediaQuery.of(context).size.width,
                              padding: EdgeInsets.all(10.5),
                              margin: EdgeInsets.symmetric(vertical: 10.5),
                              child: Image.asset(
                                'assets/images/empty.jpg',
                                width: _animation.value,
                                height: _animation.value,
                              ),
                            ),
                            SingleChildScrollView(
                              padding: EdgeInsets.symmetric(horizontal: 5.5),
                              child: Container(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    SizedBox(
                                      height: StyleView.HEIGHT_5,
                                    ),
                                    SizedBox(
                                      height: 10.0,
                                    ),
                                    Container(
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: <Widget>[
                                          Container(
                                            child: Row(children: <Widget>[
                                              Container(
                                                child: Text(
                                                  scrapData != null
                                                      ? scrapData!.name!
                                                      : "",
                                                  style: TextStyle(
                                                      fontSize: 17.0,
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),
                                              ),
                                            ]),
                                          ),
                                          Container(
                                            child: Column(children: <Widget>[
                                              Container(
                                                  child: Text(
                                                "$orgCurrencySymbol " +
                                                    CommonMethods
                                                        .getCurrencyValues(
                                                            scrapData != null
                                                                ? scrapData!
                                                                    .netCost
                                                                : 0),
                                                style: TextStyle(
                                                    fontSize: 14.0,
                                                    fontWeight:
                                                        FontWeight.bold),
                                              )),
                                            ]),
                                          )
                                        ],
                                      ),
                                    ),
                                    SizedBox(height: 20.0),
                                    Container(
                                        child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: <Widget>[
                                          this.mainText(Constants.ATTRIBUTES),
                                          Container(
                                            margin: EdgeInsets.symmetric(
                                                vertical: 5.0),
                                            child: SingleChildScrollView(
                                              scrollDirection: Axis.horizontal,
                                              child: Row(
                                                children: <Widget>[
                                                  for (int i = 0;
                                                      i <
                                                          scrapData!
                                                              .attributesList!
                                                              .length;
                                                      i++)
                                                    Container(
                                                        margin: EdgeInsets
                                                            .symmetric(
                                                                horizontal:
                                                                    5.0),
                                                        child: Card(
                                                          elevation: 3.0,
                                                          shape:
                                                              RoundedRectangleBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        50.0),
                                                          ),
                                                          child: Container(
                                                            decoration: BoxDecoration(
                                                                border: Border.all(
                                                                    color: Colors
                                                                            .grey[
                                                                        400]!),
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            50.0)),
                                                            padding:
                                                                EdgeInsets.all(
                                                                    8.0),
                                                            child: Text(
                                                              "${scrapData!.attributesList![i].entries.toList()[0].key} : " +
                                                                  "${scrapData!.attributesList![i].entries.toList()[0].value}",
                                                              style: TextStyle(
                                                                  fontSize:
                                                                      14.0,
                                                                  color: Colors
                                                                          .grey[
                                                                      700]),
                                                            ),
                                                          ),
                                                        )),
                                                ],
                                              ),
                                            ),
                                          )
                                        ])),
                                    SizedBox(height: 10.0),
                                    mainText(Constants.ASSET_DETAILS),
                                    SizedBox(height: 10),
                                    Container(
                                        child: Column(
                                      children: <Widget>[
                                        productDetilsNewDesign(Constants.GROUP,
                                            scrapData!.groupDetails!.name),
                                        productDetilsNewDesign(
                                            Constants.BRAND, scrapData!.brand),
                                        productDetilsNewDesign(
                                            Constants.DESCRIPTION_STRING,
                                            scrapData!.description),
                                        productDetilsNewDesign(
                                            Constants.NET_COST,
                                            "${scrapData!.netCost}"),
                                        productDetilsNewDesign(
                                            Constants.PURCHASED_DATE,
                                            scrapData!.purchasedDate),
                                        productDetilsNewDesign(
                                            Constants.QUANTITY,
                                            "${scrapData!.quantityDetails != null ? scrapData!.quantityDetails!.quantity : ""}"),
                                        productDetilsNewDesign(
                                            Constants.QUANTITY_IN,
                                            scrapData!.quantityDetails != null
                                                ? scrapData!
                                                    .quantityDetails!.quantityIn
                                                : ""),
                                      ],
                                    )),
                                    SizedBox(
                                      height: StyleView.HEIGHT_20,
                                    ),
                                    Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: <Widget>[
                                                mainText(Constants
                                                    .AVAILABLE_LOCATIONS),
                                              ],
                                            ),
                                          ),
                                          SizedBox(
                                            height: StyleView.HEIGHT_10,
                                          ),
                                          Container(
                                            child: _inventoryList.length == 0
                                                ? new Container(
                                                    child: Center(
                                                      child: Text(Language()
                                                          .getString(
                                                              Constants
                                                                  .NO_DETAILS,
                                                              selectedLang)),
                                                    ),
                                                  )
                                                : _createDynamicInventoryTable(),
                                          ),
                                          SizedBox(height: 10),
                                          Visibility(
                                            visible: widget.isFromScrap
                                                ? true
                                                : false,
                                            child: Container(
                                                child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: <Widget>[
                                                mainText(
                                                    Constants.SCRAP_DETAILS),
                                                SizedBox(height: 10),
                                                productDetilsNewDesign(
                                                    Constants
                                                        .SCRAP_DECLARED_DATE,
                                                    scrapData!
                                                        .scrapDeclaredDate),
                                                productDetilsNewDesign(
                                                    Constants.DISPOSED,
                                                    scrapData!.isDisposed!
                                                        ? Constants.YES_STRING
                                                        : Constants.NO_STRING),
                                                productDetilsNewDesign(
                                                    Constants.DISPOSED_DATE,
                                                    scrapData!.disposedDate),
                                                productDetilsNewDesign(
                                                    Constants.DISPOSED_VALUE,
                                                    scrapData!.disposedValue),
                                              ],
                                            )),
                                          )
                                        ]),
                                  ],
                                ),
                              ),
                            ),
                            SizedBox(
                              height: StyleView.HEIGHT_5,
                            ),
                          ],
                        ),
                      ))),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    );
  }

  mainText(String text) {
    return Container(
        child: Text(
      Language().getString(text, selectedLang),
      style: TextStyle(
          fontSize: 15.0,
          letterSpacing: 2.0,
          fontWeight: StyleView.fontMedium,
          color: Colors.grey[800]),
    ));
  }

  productDetilsNewDesign(String text, String? content) {
    return Container(
        margin: EdgeInsets.symmetric(vertical: 7.0),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                child: Text(
                  Language().getString(text, selectedLang),
                  style: TextStyle(fontSize: 14.0, color: Colors.grey[800]),
                ),
              ),
            ),
            Expanded(
              child: Container(
                  margin: EdgeInsets.symmetric(horizontal: 10.0),
                  child: Text(
                    ":  $content",
                    style: TextStyle(fontSize: 14.0, color: Colors.grey[800]),
                  )),
            )
          ],
        ));
  }

  _createDynamicInventoryTable() {
    return Column(children: <Widget>[
      for (int i = 0; i < _inventoryList.length; i++)
        Column(
          children: <Widget>[
            SizedBox(height: 5.0),
            Container(
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    border: Border.all(color: Colors.grey)),
                child: ExpansionTile(
                  title: Text(
                    Language().getString(Constants.LOCATION, selectedLang) +
                        " : ${i + 1}",
                    style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                        fontFamily: StyleView.FONT_TITLE),
                  ),
                  children: <Widget>[
                    _buildListInventoryItem(_inventoryList[i]),
                  ],
                ))
          ],
        )
    ]);
  }

  _buildListInventoryItem(InventoryManagementModel inventoryModel) {
    return Container(
        child: Container(
            padding: EdgeInsets.all(1),
            child: Column(
              children: <Widget>[
                TextView(
                  title: Constants.LOCATION_NAME,
                  value: inventoryModel.locationName,
                ),
                SizedBox(
                    height: 1,
                    child: new Container(color: Color(Constants.GREY_COLOR))),
                TextView(
                  title: Constants.QUANTITY,
                  value: "${inventoryModel.quantity}",
                )
              ],
            )));
  }
}
