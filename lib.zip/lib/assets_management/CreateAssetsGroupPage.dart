import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/assets_management/list_card_view/AssestsGroupCardView.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/AssetsGroupModel.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/service/assets_management_grpc.dart';

class CreateAssetsGroupPage extends StatefulWidget {
  @override
  _CreateAssetsGroupPageState createState() => _CreateAssetsGroupPageState();
}

class _CreateAssetsGroupPageState extends State<CreateAssetsGroupPage> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? buName = "";
  String? buId = "";
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  TextEditingController nameController = TextEditingController();
  TextEditingController descriptionController = TextEditingController();
  List<AssetsGroupModel> assetsList = [];
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  TextEditingController _searchController = TextEditingController();
  late AssetsManagementGrpcService _assestsService;
  List<Map> _mapData = [];
  bool isForSearchFilters = false;
  @override
  void initState() {
    super.initState();
    this.getLoadLanguage();
    buName = AppController.instance.getBuName;
    buId = AppController.instance.getMyBuId;
    _assestsService = AssetsManagementGrpcService();
    this.loadAssetsGroupData();
  }

  loadAssetsGroupData({String name = ""}) async {
    if (await NetworkStatus.getInternetStatus()) {
      if (!isForSearchFilters) {
        setState(() {
          isLoadingProgress = true;
        });
      }

      this.getAssetsGroupData(name: name).then((value) {
        setState(() {
          assetsList.clear();
          assetsList.addAll(value);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  getLoadLanguage() {
    _mapData = [
      {"name": Language().getString(Constants.EDIT, selectedLang)},
      {"name": Language().getString(Constants.DELETE_STRING, selectedLang)}
    ];
  }

  @override
  Widget build(BuildContext context) {
    return
        // WillPopScope(
        //   onWillPop: () {
        //     return CommonMethods.onBackPress(context);
        //   },
        //   child:
        Stack(
      children: [
        SafeArea(
          child: Scaffold(
            key: _scaffoldkey,
            backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
            appBar: AppBar(
              backgroundColor: Color(Constants.APP_COLOR),
              centerTitle: true,
              title: Column(
                children: [
                  Text(Language().getString(Constants.ADD_ASSETS, selectedLang)),
                  Text(buName!, style: TextStyle(fontSize: 13.0))
                ],
              ),
              actions: [
                TextButton(
                    onPressed: () {
                      this.addNewAssert();
                    },
                    child: Icon(
                      Icons.add,
                      color: Colors.white,
                    ))
              ],
            ),
            // drawer: MyDrawer(),
            body: Container(
              margin: EdgeInsets.symmetric(vertical: 5.0, horizontal: 5.0),
              child: Column(
                children: [
                  this.buildSearchbarView(),
                  (assetsList.length > 0 && _mapData.length > 0)
                      ? Expanded(
                          child: ListView.separated(
                          itemBuilder: (context, index) {
                            return AssetsGroupListCardView(
                                assertName: assetsList[index].name,
                                editAssertGroup: () {
                                  this.addNewAssert(
                                      isForUpdate: true,
                                      data: assetsList[index],
                                      currentIndex: index);
                                },
                                deleteAssertGroup: () async {
                                  final action = await Dialogs.yesCancelDialog(
                                      context,
                                      Language().getString(
                                          Constants.WARNING, selectedLang),
                                      Language().getString(
                                          Constants.WARNING_TEXT, selectedLang),
                                      Language().getString(
                                          Constants.OKAY_STR, selectedLang),
                                      "",
                                      false);
          
                                  if (action == DialogAction.yes) {
                                    setState(() {
                                      isLoadingProgress = true;
                                    });
                                    this.serviceCallRemoveAssetsGroup(
                                        assetsList[index].id);
                                  }
                                },
                                mapData: _mapData);
                          },
                          separatorBuilder: (context, index) => Divider(
                            color: Colors.transparent,
                            height: 5.0,
                          ),
                          itemCount: assetsList.length,
                        ))
                      : Container(
                          child: Text(
                          Language()
                              .getString(Constants.NO_DATA_FOUND, selectedLang),
                        ))
                ],
              ),
            ),
          ),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
      // ),
    );
  }

  Widget buildSearchbarView() {
    return Container(
      height: 40.0,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(5.0),
        border: Border.all(
          color: Colors.grey,
        ),
      ),
      child: Row(
        children: <Widget>[
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(5.0),
                  bottomLeft: Radius.circular(5.0),
                ),
                color: Colors.white,
              ),
              padding: EdgeInsets.only(left: 5),
              child: TextFormField(
                controller: _searchController,
                onChanged: onSearchTextChanged,
                style: TextStyle(fontFamily: 'IndianRupee'),
                decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: Language()
                        .getString(Constants.SEARCH_BY_NAME, selectedLang),
                    hintStyle: TextStyle(
                        fontSize: 13.0, fontFamily: StyleView.FONT_TITLE)),
              ),
            ),
          ),
          (_searchController.text.length > 0)
              ? Container(
                  color: Colors.white,
                  child: IconButton(
                      icon: Icon(
                        Icons.close,
                        color: Colors.red,
                        size: 20.0,
                      ),
                      onPressed: () {
                        CommonMethods.hideKeyboard(context);
                        _searchController.clear();
                        onSearchTextChanged(_searchController.text);
                      }),
                )
              : Container(),
        ],
      ),
    );
  }

  addNewAssert(
      {bool isForUpdate = false,
      AssetsGroupModel? data,
      int currentIndex = -1}) {
    if (isForUpdate) {
      setState(() {
        nameController.text = data!.name!;
        descriptionController.text = data.description!;
      });
    } else {
      setState(() {
        nameController.clear();
        descriptionController.clear();
      });
    }
    return showDialog(
        context: context,
        builder: (context) {
          return Container(
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(5.0))),
              margin: EdgeInsets.symmetric(horizontal: 20.0, vertical: 50.0),
              child: StatefulBuilder(builder: (context, StateSetter setState) {
                return Scaffold(
                  bottomNavigationBar: Container(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Expanded(
                          child: Container(
                            margin: EdgeInsets.only(right: 1.0),
                            height: 30.0,
                            child: ElevatedButton(
                                style: CommonMethods.elevatedButtonStyle(),
                                onPressed: () {
                                  setState(() {
                                    nameController.clear();
                                    descriptionController.clear();
                                  });
                                  Navigator.of(context).pop();
                                },
                                child: Text(
                                  Language().getString(
                                      Constants.STR_CANCEL, selectedLang),
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 15.0,
                                      fontWeight: FontWeight.bold),
                                )),
                          ),
                        ),
                        Expanded(
                          child: Container(
                            height: 30.0,
                            margin: EdgeInsets.only(left: 1.0),
                            child: ElevatedButton(
                                style: CommonMethods.elevatedButtonStyle(),
                                onPressed: () {
                                  String errorMessage =
                                      validatingMandatoryFields();
                                  if (errorMessage.isNotEmpty) {
                                    Dialogs.yesCancelDialog(
                                        context,
                                        Language().getString(
                                            Constants.ERROR, selectedLang),
                                        errorMessage,
                                        Language().getString(
                                            Constants.OKAY_STR, selectedLang),
                                        "",
                                        false);
                                  } else {
                                    Navigator.of(context).pop();
                                    if (isForUpdate) {
                                      this.serviceCallUpdateAssetsGroup(
                                          data!.id);
                                    } else {
                                      this.serviceCallCreateAssetsGroup();
                                    }
                                  }
                                },
                                child: Text(
                                  Language().getString(
                                      Constants.STR_SAVE, selectedLang),
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 15.0,
                                      fontWeight: FontWeight.bold),
                                )),
                          ),
                        )
                      ],
                    ),
                  ),
                  body: SingleChildScrollView(
                    child: Container(
                      margin: EdgeInsets.symmetric(horizontal: 5.0),
                      child: Column(
                        children: [
                          Container(
                              margin: EdgeInsets.symmetric(vertical: 5.0),
                              child: Text(
                                  Language().getString(
                                      isForUpdate
                                          ? Constants.UPDATE_ASSETS
                                          : Constants.ADD_ASSETS,
                                      selectedLang),
                                  style: TextStyle(
                                      color: Color(Constants.APP_COLOR),
                                      fontSize: 15.0,
                                      fontWeight: FontWeight.bold))),
                          Container(
                            margin: EdgeInsets.symmetric(vertical: 5.0),
                            padding: EdgeInsets.all(5.0),
                            child: TextField(
                                controller: nameController,
                                decoration: StyleView.getInputDecoration(
                                    helper: Language().getString(
                                        Constants.ENTER_GROUP_NAME,
                                        selectedLang))),
                          ),
                          Container(
                            height: 200,
                            margin: EdgeInsets.symmetric(vertical: 5.0),
                            padding: EdgeInsets.all(10.0),
                            decoration: AppUtills.boxDecoration(),
                            child: new ConstrainedBox(
                              constraints: BoxConstraints(
                                maxHeight: 200.0,
                              ),
                              child: new Scrollbar(
                                child: new SingleChildScrollView(
                                  scrollDirection: Axis.vertical,
                                  reverse: true,
                                  child: SizedBox(
                                    height: 190.0,
                                    child: new TextField(
                                      controller: descriptionController,
                                      maxLines: 100,
                                      decoration: new InputDecoration(
                                        border: InputBorder.none,
                                        hintText: Language().getString(
                                            Constants.DESCRIPTION_STRING,
                                            selectedLang),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }));
        });
  }

  String validatingMandatoryFields() {
    if (nameController.text.isEmpty) {
      return 'Please enter name';
    } else if (descriptionController.text.isEmpty) {
      return 'Please enter description';
    } else {
      return '';
    }
  }

  onSearchTextChanged(String text) async {
    if (text.isEmpty) {
      isLoadingProgress = true;
      isForSearchFilters = false;
      this.loadAssetsGroupData();
    } else {
      isLoadingProgress = false;
      isForSearchFilters = true;
      this.loadAssetsGroupData(name: text);
    }
  }

  serviceCallCreateAssetsGroup() async {
    setState(() {
      isLoadingProgress = true;
    });

    String body = json.encode({
      "bu_id": buId,
      "name": nameController.text,
      "description": descriptionController.text
    });

    var response = await _assestsService
        .createAssetsGroup(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          Language()
              .getString(Constants.GROUP_CREATED_SUCCESSFULLY, selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);

      if (action == DialogAction.yes) {
        setState(() {
          isLoadingProgress = true;
        });
        this.loadAssetsGroupData();
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  serviceCallUpdateAssetsGroup(String? itemId) async {
    setState(() {
      isLoadingProgress = true;
    });

    String body = json.encode({
      "id": itemId,
      "bu_id": buId,
      "name": nameController.text,
      "description": descriptionController.text
    });

    var response = await _assestsService
        .updateAssetsGroup(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          data,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);

      if (action == DialogAction.yes) {
        setState(() {
          isLoadingProgress = true;
        });
        this.loadAssetsGroupData();
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  serviceCallRemoveAssetsGroup(String? itemId) async {
    String body = json.encode({
      "id": itemId,
      "bu_id": buId,
    });

    var response = await _assestsService
        .removeAssetsGroup(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          data,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);

      if (action == DialogAction.yes) {
        setState(() {
          isLoadingProgress = true;
        });
        this.loadAssetsGroupData();
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  Future<List<AssetsGroupModel>> getAssetsGroupData({String name = ""}) async {
    String body = json.encode({
      "bu_id": buId,
      "filters": {"name": name}
    });

    var response = await _assestsService
        .getAssetsGroupList(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<AssetsGroupModel> list = [];
    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;

    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);

      for (var object in data['results']) {
        list.add(AssetsGroupModel.fromJson(object));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return list;
  }
}
