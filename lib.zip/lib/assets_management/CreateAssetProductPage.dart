import 'dart:async';
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:http_parser/http_parser.dart';
import 'package:intl/intl.dart';
import 'package:mime/mime.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Product/attribute_view/AttributeExpandedPage.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/privileges/product_privileges.dart';
import 'package:vyaparlive/components/years_list.dart';
import 'package:vyaparlive/login_view/TermsAndConditionsPage.dart';
import 'package:vyaparlive/model/AssestListDAO.dart';
import 'package:vyaparlive/model/AssetsGroupModel.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/BusinessUnitModel.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/InventoryManagmentModel.dart';
import 'package:vyaparlive/model/ProductAttributeModel.dart';
import 'package:vyaparlive/model/ProductCategoryDAO.dart';
import 'package:vyaparlive/model/ProductSegmentDAO.dart';
import 'package:vyaparlive/model/ProductSubCategoryDAO.dart';
import 'package:vyaparlive/model/product_model/ProductModel.dart';
import 'package:vyaparlive/model/bu_model/LocationsModel.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:vyaparlive/reconciliation_view/ShowPdf.dart';
import 'package:vyaparlive/reconciliation_view/StockReconciliation.dart';
import 'package:vyaparlive/service/Service.dart';
import 'package:vyaparlive/service/assets_management_grpc.dart';

class CreateAssetProductPage extends StatefulWidget {
  final String? title;
  final String? assetRecordId;

  CreateAssetProductPage({this.title, this.assetRecordId});

  @override
  _CreateAssetProductPageState createState() => _CreateAssetProductPageState();
}

class _CreateAssetProductPageState extends State<CreateAssetProductPage> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? quantityDropdownValue;
  String currencySymbol = "";
  var imagePath;
  EdgeInsetsGeometry dialogTitlePadding =
      EdgeInsets.fromLTRB(17.0, 24.0, 24.0, 5.0);
  bool isSelectCaptureChoice = false;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  late File imageFile;
  String imageBlob = '';
  String? buId = "";
  late Service _service;
  String strHeight = "";
  String strVolume = "";
  String strWeight = "";
  String strWidth = "";
  int strQuantity = 0;
  String strDepth = "";
  int productPrice = 0;
  List<BusinessUnitModel> _buList = [];

  /// Product Details Fiellds
  final nameController = TextEditingController();
  final _brandController = new TextEditingController();
  final descriptionController = new TextEditingController();

  /// Shipping Details

  final _weightController = new TextEditingController();
  final _widthController = new TextEditingController();
  final _heightController = new TextEditingController();
  final _depthController = new TextEditingController();
  final _qntyController = new TextEditingController();

  List<ProductSegmentDAO> productsSegments = [];
  List<ProductCategoryDAO> productCategories = [];
  List<ProductSubCategoryDAO> productSubCategories = [];

  final _locationQuantityController = new TextEditingController();
  final hsnCodeController = TextEditingController();
  List<InventoryManagementModel> inventoryList = [];
  List<BuProductModal> _productsList = [];
  DateTime expireDate = DateTime.now();
  DateFormat formatter = DateFormat("yyyy-MM-dd");
  String formattedManufactureDate = "";
  String formattedExpireDate = "";
  String formattedReleaseDate = "";

  List<Locations> locationsList = [];
  Locations? locationDropdownValue;
  String? heightDropdownValue;
  String? weightDropdownValue;
  String? widthDropdownValue;
  String? volumeDropdownValue;
  String? depthDropdownValue;
  final volumeController = TextEditingController();
  bool isImageUpdated = false;
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  double finalAngle = 0.0;
  String remainingQuantity = "0";
  String? purchasedDate = "";
  File? selectedFile;
  String usefulLifeDuration = "";
  String liabilityRadioVaue = Constants.NO_STRING;
  String scrapRadioValue = Constants.NO_STRING;
  String? scrapDeclaredDate = "";
  String scrapDisposedRadioValue = Constants.YES_STRING;
  String? scrapDisposedDate = "";
  TextEditingController disposedValueController = TextEditingController();
  TextEditingController usefulLifeRemainingController = TextEditingController();
  TextEditingController netCostController = TextEditingController();
  TextEditingController currentValueController = TextEditingController();
  String? depreciationDropdownValue;
  final _attributeKeyController = new TextEditingController();
  final _attributeValueController = new TextEditingController();
  List<ProductAttributeModel> attributesList = [];
  List<AssetsGroupModel> assetsGroupist = [];
  late AssetsManagementGrpcService _assestsService;
  AssetsGroupModel? assetGroupDropdownValue;
  String invoiceAttachmentBlob = "";
  AssetsListDAO? assetListData;
  num residualValue = 0;
  String? usefulLifeDurationYearDropdown;
  String? usefulLifeDurationMonthDropdown;
  num daysDifferance = 0;
  final ProductPrivileges? _productPrivileges =
      AppController.instance.getProductPrivileges;

  @override
  void initState() {
    super.initState();
    _service = Service();
    _assestsService = AssetsManagementGrpcService();
    buId = AppController.instance.getMyBuId;

    if (widget.title == Constants.UPDATE_ASSETS_LIST) {
      this.loadAssetData();
    } else {
      this.loadDropdowns();
    }

    this.getBuData().then((value) {
      _buList.addAll(value);
      if (_buList.length > 0) {
        /// Getting bu locations
        setState(() {
          locationsList.addAll(_buList[0].locationsList!);
        });
      }
    });

    for (int i = 0; i < Constants.UNIT_PRICE.length; i++) {
      if (Constants.UNIT_PRICE[i] == "unit") {
        setState(() {
          quantityDropdownValue = Constants.UNIT_PRICE[i];
        });
      }
    }
  }

  loadAssetData() async {
    await this.loadDropdowns();

    if (await NetworkStatus.getInternetStatus()) {
      this.getAssetDataById().then((value) {
        setState(() {
          assetListData = value;
          if (assetListData != null) {
            this.bindingAssetData();
          }
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  loadDropdowns() {
    this.loadAssetsGroupData();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        SafeArea(
          child: Scaffold(
            key: _scaffoldkey,
            backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
            appBar: AppBar(
              leading: (widget.title == Constants.UPDATE_ASSETS_LIST)
                  ? IconButton(
                      icon: Icon(Icons.arrow_back, color: Colors.white),
                      onPressed: () async {
                        final action = await Dialogs.yesCancelDialog(
                            context,
                            Language().getString(Constants.INFO, selectedLang),
                            Language().getString(
                                Constants.BACK_BUTTION_MESSAGE, selectedLang),
                            Language()
                                .getString(Constants.YES_STRING, selectedLang),
                            Language()
                                .getString(Constants.NO_STRING, selectedLang),
                            true);
                        if (action == DialogAction.yes) {
                          Navigator.pop(context);
                        }
                      })
                  : null,
              centerTitle: true,
              title: Column(children: <Widget>[
                Text(
                  Language().getString("${widget.title}", selectedLang),
                ),
                Text(
                  AppController.instance.getBuName,
                  style: TextStyle(fontSize: 13.0),
                )
              ]),
              backgroundColor: Color(0xFF083e64),
              actions: [
                AppUtills.homeButton(context),
              ],
            ),
            bottomNavigationBar: Container(
              margin: EdgeInsets.symmetric(
                horizontal: 10.0,
              ),
              child: ElevatedButton(
                style: CommonMethods.elevatedButtonStyle(),
                onPressed: () => {this.submitInputData()},
                child: Padding(
                  padding: EdgeInsets.symmetric(vertical: 10),
                  child: Text(
                    Language().getString(widget.title, selectedLang),
                    style: TextStyle(
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ),
            body: Container(
              margin: EdgeInsets.symmetric(
                horizontal: 10.0,
                vertical: 5.0,
              ),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Container(
                      margin: EdgeInsets.symmetric(
                        vertical: 5.0,
                      ),
                      child: Text(
                        Language()
                            .getString(Constants.ASSET_DETAILS, selectedLang),
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_15,
                            fontFamily: StyleView.FONT_TITLE,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.symmetric(
                        vertical: 5.0,
                      ),
                      decoration: AppUtills.boxDecoration(),
                      child: Column(children: <Widget>[
                        buildAddProductImage(Language().getString(
                            Constants.PRODUCT_PHOTO_STRING, selectedLang)),
                        SizedBox(
                          height: 1,
                          child:
                              new Container(color: Color(Constants.GREY_COLOR)),
                        ),
                        buildAddProduct(),
                      ]),
                    ),
                    Container(
                        margin: EdgeInsets.symmetric(
                          vertical: 5.0,
                        ),
                        decoration: AppUtills.boxDecoration(),
                        child: ExpansionTile(
                            initiallyExpanded: true,
                            title: Text(Language().getString(
                                Constants.ASSET_BASIC_DETAILS, selectedLang)),
                            children: <Widget>[
                              Column(
                                children: <Widget>[
                                  buildTableContent(Constants.NAME_STRING,
                                      nameController, false, true),
                                  SizedBox(
                                    height: 1,
                                    child: new Container(
                                        color: Color(Constants.GREY_COLOR)),
                                  ),
                                  buildTableContent(Constants.BRAND,
                                      _brandController, false, false),
                                  SizedBox(
                                    height: 1,
                                    child: new Container(
                                        color: Color(Constants.GREY_COLOR)),
                                  ),
                                  this.buildAssetsGroupDropdown(),
                                  SizedBox(
                                    height: 1,
                                    child: new Container(
                                        color: Color(Constants.GREY_COLOR)),
                                  ),
                                  buildTableContent(Constants.DESCRIPTION_STRING,
                                      descriptionController, false, false),
                                  SizedBox(
                                    height: 1,
                                    child: new Container(
                                        color: Color(Constants.GREY_COLOR)),
                                  ),
                                  // this.buildTableContent(Constants.NET_COST,
                                  //     netCostController, true, true),
                                  this.buildNetCostView(),
                                  SizedBox(
                                    height: 1,
                                    child: new Container(
                                        color: Color(Constants.GREY_COLOR)),
                                  ),
                                  this.buildPurchasedDate(),
                                  SizedBox(
                                    height: 1,
                                    child: new Container(
                                        color: Color(Constants.GREY_COLOR)),
                                  ),
                                  // this.buildUsefulLifeDurationDate(),
                                  this.buildYearDropdownView(),
          
                                  SizedBox(
                                    height: 1,
                                    child: new Container(
                                        color: Color(Constants.GREY_COLOR)),
                                  ),
                                  this.buildTableContent(
                                      Constants.USEFUL_LIFE_REMAINING,
                                      usefulLifeRemainingController,
                                      false,
                                      false),
                                  SizedBox(
                                    height: 1,
                                    child: new Container(
                                        color: Color(Constants.GREY_COLOR)),
                                  ),
                                  this.depreciationValueDesign(),
                                  SizedBox(
                                    height: 1,
                                    child: new Container(
                                        color: Color(Constants.GREY_COLOR)),
                                  ),
                                  this.buildResidualValueView(),
                                  SizedBox(
                                    height: 1,
                                    child: new Container(
                                        color: Color(Constants.GREY_COLOR)),
                                  ),
          
                                  this.depreciationExpenseView(),
                                  SizedBox(
                                    height: 1,
                                    child: new Container(
                                        color: Color(Constants.GREY_COLOR)),
                                  ),
                                  // buildTableContent(Constants.QUANTITY,
                                  //     _quantityController, true, true),
                                  this.buildQuantityView(Language().getString(
                                      Constants.QUANTITY, selectedLang))
                                ],
                              )
                            ])),
                    Container(
                      margin: EdgeInsets.symmetric(
                        vertical: 5.0,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          buildTextField(Language()
                              .getString(Constants.FEATURES, selectedLang)),
                          addNewAttribute()
                        ],
                      ),
                    ),
                    Container(
                      child: attributesList.length == 0
                          ? Container(margin: EdgeInsets.symmetric(vertical: 5.0))
                          : onCreateDynamicAttributes(),
                    ),
                    Container(
                      margin: EdgeInsets.symmetric(
                        vertical: 10.0,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          buildTextField(Language()
                              .getString(Constants.INVENTORY, selectedLang)),
                          addNewInventory()
                        ],
                      ),
                    ),
                    Container(
                      child: (inventoryList.length == 0)
                          ? null
                          : onCreateDynamicInventory(),
                    ),
                    this.buildInvoiceAttachement(),
                    this.liabilityDesignView(),
                    this.scrapDesignView(),
                    (scrapRadioValue == Constants.YES_STRING)
                        ? this.showScrapDetailsView()
                        : Container()
                  ],
                ),
              ),
            ),
          ),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    );
  }

  submitInputData() async {
    String validationError = onValuesValidation();
    // String itemDetailsError = validatingItemDetails();
    if (validationError.isNotEmpty) {
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          Language().getString(validationError, selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    } else {
      if (widget.title == Constants.CREATE_ASSETS_LIST) {
        setState(() {
          isLoadingProgress = true;
          progressMessage = Constants.CREATING;
        });
        this.createAssetData();
      } else {
        setState(() {
          isLoadingProgress = true;
          progressMessage = Constants.UPDATING;
        });
        this.updateAssetData();
      }
    }
  }

  buildTableContent(String textName, TextEditingController _controller,
      bool _isKeyboard, bool isMandatory) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: isMandatory
                          ? RichText(
                              text: TextSpan(children: [
                                TextSpan(
                                  text: Language()
                                      .getString(textName, selectedLang),
                                  style: TextStyle(
                                      fontSize: StyleView.FONT_SIZE_15,
                                      fontFamily: StyleView.FONT_TITLE,
                                      color: Colors.black),
                                ),
                                TextSpan(
                                    text: "\*",
                                    style: TextStyle(
                                        fontSize: StyleView.FONT_SIZE_15,
                                        color: Colors.red))
                              ]),
                            )
                          : Text(
                              Language().getString(textName, selectedLang),
                              style: TextStyle(
                                  fontSize: textName == Constants.DISPOSED_VALUE
                                      ? 13.0
                                      : StyleView.FONT_SIZE_15,
                                  fontFamily: 'IndianRupee'),
                            ),
                    ),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                color: Colors.white,
                padding: EdgeInsets.only(left: 5),
                child: TextField(
                    keyboardType:
                        _isKeyboard ? TextInputType.number : TextInputType.text,
                    controller: _controller,
                    style: TextStyle(
                      fontFamily: 'IndianRupee',
                    ),
                    enabled: textName == Constants.USEFUL_LIFE_REMAINING
                        ? false
                        : true,
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: Language().getString(textName, selectedLang),
                    )),
              ),
            )
          ],
        ));
  }

  String onValuesValidation() {
    if (nameController.text.isEmpty) {
      return Constants.PLEASE_ENTER_PRODUCT_NAME;
    } else if (assetGroupDropdownValue == null) {
      return "Please select group";
    } else if (_qntyController.text.isEmpty) {
      return "Please enter quantity";
    } else {
      return "";
    }
  }

  buildAddProductImage(String? textName) {
    return Container(
        child: Center(
      child: Container(
          height: 50,
          padding: EdgeInsets.symmetric(vertical: 10),
          color: Colors.white70,
          child: Container(
            padding: EdgeInsets.only(left: 10),
            child: Align(
                alignment: Alignment.center,
                child: InkWell(
                  onTap: () {
                    this.openBottomSheet(context);
                  },
                  child: Icon(
                    Icons.camera_alt,
                    color: Color(0xFF083e64),
                    size: 30.0,
                  ),
                )),
          )),
    ));
  }

  openBottomSheet(BuildContext context) {
    return Dialogs.openBottomSheet(
        context: context,
        openCamera: (myPicture) async {
          this.updateProductImage(myPicture);
        },
        openGallery: (myPicture) async {
          this.updateProductImage(myPicture);
        });
  }

  updateProductImage(File fileImage) {
    Navigator.of(context).pop();
    setState(() {
      imageFile = fileImage;
      isSelectCaptureChoice = true;
      isImageUpdated = true;
      imageBlob = AppUtills.getBase64Image(fileImage, context);
    });
  }

  buildQuantityView(String? _title) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: RichText(
                    text: TextSpan(children: [
                      TextSpan(
                        text: Language().getString(_title, selectedLang),
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_15,
                            fontFamily: StyleView.FONT_TITLE,
                            color: Colors.black),
                      ),
                      TextSpan(
                          text: "\*",
                          style: TextStyle(
                              fontSize: StyleView.FONT_SIZE_15,
                              color: Colors.red))
                    ]),
                  ),
                ),
              )),
        ),
        Expanded(
            flex: 2,
            child: Container(
              color: Colors.grey,
              alignment: Alignment.centerLeft,
              child: Row(children: <Widget>[
                Expanded(
                    child: Container(
                  padding: EdgeInsets.only(left: 5),
                  margin: EdgeInsets.only(right: 1),
                  color: Colors.white,
                  child: TextFormField(
                    keyboardType: TextInputType.number,
                    controller: _qntyController,
                    style: TextStyle(fontFamily: 'IndianRupee'),
                    decoration: InputDecoration(
                        border: InputBorder.none, hintText: _title),
                    inputFormatters: [
                      new LengthLimitingTextInputFormatter(6),
                      CommonMethods.inputTextFormatter(isNumber: true)
                    ],
                  ),
                )),
                Expanded(
                    child: Container(
                        color: Colors.white,
                        padding: EdgeInsets.only(left: 5),
                        child: DropdownButton<String>(
                            onTap: () {
                              FocusScope.of(context).unfocus();
                            },
                            value: quantityDropdownValue,
                            hint: new Text(
                              Language()
                                  .getString(Constants.SELECT, selectedLang),
                            ),
                            isExpanded: true,
                            underline: SizedBox(),
                            onChanged: (String? data) {
                              setState(() {
                                quantityDropdownValue = data;
                              });
                            },
                            items: Constants.UNIT_PRICE.map((String model) {
                              return new DropdownMenuItem<String>(
                                child: new Text(model),
                                value: model,
                              );
                            }).toList()))),
              ]),
            ))
      ],
    );
  }

  buildAddProduct() {
    return Container(
        child: Row(
      children: <Widget>[
        Expanded(
          flex: 1,
          child: Container(
              padding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
              color: Colors.white,
              child: Container(
                width: MediaQuery.of(context).size.width,
                child: Align(
                    alignment: Alignment.centerLeft, child: displayImageView()),
              )),
        ),
      ],
    ));
  }

  displayImageView() {
    if (isSelectCaptureChoice) {
      return Transform.rotate(
        angle: finalAngle,
        origin: Offset(0, 0),
        child: Image.file(
          imageFile,
          fit: BoxFit.fill,
          gaplessPlayback: true,
        ),
      );
    } else {
      if (assetListData != null && assetListData!.imageUrl!.length > 0) {
        return Image.network(
          Constants.NEW_BASE_URL +
              "assets/buImage/" +
              assetListData!.imageUrl![0].image!,
          fit: BoxFit.fill,
          gaplessPlayback: true,
          errorBuilder:
              (BuildContext context, Object exception, StackTrace? stackTrace) {
            return Image.asset(
              'assets/images/empty.jpg',
              gaplessPlayback: true,
            );
          },
        );
      } else {
        return Image.asset(
          'assets/images/empty.jpg',
          fit: BoxFit.fill,
          gaplessPlayback: true,
        );
      }
    }
  }

  buildText(String title, String _offerValue) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(title,
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_15,
                            fontFamily: StyleView.FONT_TITLE))),
              )),
        ),
        Expanded(
          flex: 2,
          child: Container(
              color: Colors.white70,
              height: 50,
              padding: EdgeInsets.only(left: 5),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  _offerValue,
                  style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                ),
              )),
        )
      ],
    );
  }

  createAssetData() async {
    // this.renderItemDetails();
    List<String> depreciationExpenseArray = [];
    if (currentValueController.text.isNotEmpty) {
      depreciationExpenseArray = currentValueController.text.split(" /");
    } else {
      depreciationExpenseArray.add("0");
    }
    List<String> depreciation = [];
    if (depreciationDropdownValue != null) {
      depreciation = depreciationDropdownValue!.split(" %");
    } else {
      depreciation = ["0"];
    }
    List<Map<String, dynamic>> inventoryArrayList = [];
    var inventoryObject;
    for (int i = 0; i < inventoryList.length; i++) {
      inventoryObject = {
        "location_name": inventoryList[i].locationName,
        "quantity": inventoryList[i].quantity
      };
      inventoryArrayList.add(inventoryObject);
    }
    List<Map<String, dynamic>> attributesArray = [];
    var attributesObject;
    for (int i = 0; i < attributesList.length; i++) {
      attributesObject = {
        "${attributesList[i].attributeKey}":
            "${attributesList[i].attributeValue}"
      };
      attributesArray.add(attributesObject);
    }
    var data = {
      "bu_id": buId,
      "name": nameController.text,
      "description": descriptionController.text,
      "group": assetGroupDropdownValue!.id,
      // "image": imageBlob,
      "purchased_date": purchasedDate,
      // "invoice_attachment": invoiceAttachmentBlob,
      "useful_life_duration": {
        "year": usefulLifeDurationYearDropdown,
        "month": usefulLifeDurationMonthDropdown
      },
      "useful_life_remaining": usefulLifeRemainingController.text,
      "net_cost": double.parse(netCostController.text),
      "depreciation_percent": depreciation[0],
      "depreciation_expense": double.parse(depreciationExpenseArray[0]),
      "is_liability": liabilityRadioVaue == Constants.YES_STRING ? true : false,
      "is_scrap": scrapRadioValue == Constants.YES_STRING ? true : false,
      "scrap_declared_date": scrapDeclaredDate,
      "disposed":
          scrapDisposedRadioValue == Constants.YES_STRING ? true : false,
      "disposed_date": scrapDisposedDate,
      "disposed_value": disposedValueController.text,
      "attributes": attributesArray,
      "inventory_management": inventoryArrayList,
      "residual_value": residualValue,
      "quantity_details": {
        "quantity": int.parse(_qntyController.text),
        "quantity_in":
            quantityDropdownValue != null ? quantityDropdownValue : ""
      }
    };

    String body = json.encode(data);
    var response = await _assestsService
        .createAsset(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    // setState(() {
    //   isLoadingProgress = false;
    // });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);
      if (selectedFile != null) {
        await this.uploadFile(selectedFile!, data);
      }
      await this._uploadAssetImage(data);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  updateAssetData() async {
    // this.renderItemDetails();
    List<String> depreciationExpenseArray = [];
    if (currentValueController.text.isNotEmpty) {
      depreciationExpenseArray = currentValueController.text.split(" /");
    } else {
      depreciationExpenseArray.add("0");
    }
    List<String> depreciation = [];
    if (depreciationDropdownValue != null) {
      depreciation = depreciationDropdownValue!.split(" %");
    } else {
      depreciation = ["0"];
    }
    List<Map<String, dynamic>> inventoryArrayList = [];
    var inventoryObject;
    for (int i = 0; i < inventoryList.length; i++) {
      inventoryObject = {
        "location_name": inventoryList[i].locationName,
        "quantity": inventoryList[i].quantity,
        "batch_no": inventoryList[i].batchNumber
      };
      inventoryArrayList.add(inventoryObject);
    }

    List<Map<String, dynamic>> attributesArray = [];
    var attributesObject;
    for (int i = 0; i < attributesList.length; i++) {
      attributesObject = {
        "${attributesList[i].attributeKey}":
            "${attributesList[i].attributeValue}"
      };
      attributesArray.add(attributesObject);
    }
    var data = {
      "id": widget.assetRecordId,
      "bu_id": buId,
      "name": nameController.text,
      "description": descriptionController.text,
      "group": assetGroupDropdownValue!.id,
      "image": imageBlob,
      "purchased_date": purchasedDate,
      // "invoice_attachment": invoiceAttachmentBlob,
      "useful_life_duration": {
        "year": usefulLifeDurationYearDropdown,
        "month": usefulLifeDurationMonthDropdown
      },
      "useful_life_remaining": usefulLifeRemainingController.text,
      "net_cost": double.parse(netCostController.text),
      "depreciation_percent": depreciation[0],
      "depreciation_expense": double.parse(depreciationExpenseArray[0]),
      "is_liability": liabilityRadioVaue == Constants.YES_STRING ? true : false,
      "is_scrap": scrapRadioValue == Constants.YES_STRING ? true : false,
      "scrap_declared_date": scrapDeclaredDate,
      "disposed":
          scrapDisposedRadioValue == Constants.YES_STRING ? true : false,
      "disposed_date": scrapDisposedDate,
      "disposed_value": disposedValueController.text,
      "attributes": attributesArray,
      "inventory_management": inventoryArrayList,
      "residual_value": residualValue,
      "quantity_details": {
        "quantity": int.parse(_qntyController.text),
        "quantity_in":
            quantityDropdownValue != null ? quantityDropdownValue : "unit"
      }
    };

    String body = json.encode(data);
    var response = await _assestsService
        .updateAsset(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);

      if (selectedFile != null) {
        await this.uploadFile(selectedFile!, widget.assetRecordId);
      }
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          data,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);

      if (action == DialogAction.yes) {
        Navigator.pop(context);
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  renderItemDetails() {
    strHeight = _heightController.text +
        " " +
        (heightDropdownValue != null ? heightDropdownValue! : "");
    strWeight = _weightController.text +
        " " +
        (weightDropdownValue != null ? weightDropdownValue! : "");
    strWidth = _widthController.text +
        " " +
        (widthDropdownValue != null ? widthDropdownValue! : "");
    strVolume = volumeController.text +
        " " +
        (volumeDropdownValue != null ? volumeDropdownValue! : "");
    strDepth = _depthController.text +
        " " +
        (depthDropdownValue != null ? depthDropdownValue! : "");
  }

  alertmessageDisplay(message) {
    return showDialog(
        context: context,
        barrierColor: Colors.black54,
        barrierDismissible: false,
        builder: (context) {
          return AlertDialog(
            elevation: 100.0,
            title: Text(Language().getString(Constants.SUCCESS, selectedLang)),
            content: new Text(Language().getString(message, selectedLang)),
            actions: <Widget>[
              TextButton(
                child: new Text(
                    Language().getString(Constants.OKAY_STR, selectedLang),
                    style: TextStyle(
                      color: Color(Constants.APP_COLOR),
                      fontSize: 18.0,
                    )),
                onPressed: () {
                  Navigator.of(context).pop();
                  Navigator.pop(context);
                },
              ),
            ],
          );
        });
  }

  buildTextField(String _text) {
    return Row(
      children: <Widget>[
        Align(
            child: Text(_text,
                style: TextStyle(
                    fontFamily: StyleView.FONT_TITLE,
                    fontWeight: FontWeight.bold,
                    fontSize: StyleView.FONT_SIZE_15)))
      ],
    );
  }

  buildDateFieldRelease(String _title) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: RichText(
                          text: TextSpan(children: [
                            TextSpan(
                              text: Language().getString(_title, selectedLang),
                              style: TextStyle(
                                  fontSize: StyleView.FONT_SIZE_15,
                                  fontFamily: StyleView.FONT_TITLE,
                                  color: Colors.black),
                            ),
                          ]),
                        )),
                  )),
            ),
            Expanded(
                flex: 2,
                child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5),
                  alignment: Alignment.topLeft,
                  child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                      ),
                      onPressed: () async {
                        FocusScope.of(context).unfocus();
                        // pickCustomDate(context, _title);
                        String value = await AppUtills.getSelectedDate(context);
                        setState(() {
                          formattedReleaseDate = value;
                        });
                      },
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Text(formattedReleaseDate),
                          Image.asset(
                            'assets/images/calander.png',
                            height: 30,
                          )
                        ],
                      )),
                )),
          ],
        ));
  }

  buildDateFieldManufacture(String _title, StateSetter setState) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: RichText(
                          text: TextSpan(children: [
                            TextSpan(
                              text: Language().getString(_title, selectedLang),
                              style: TextStyle(
                                  fontSize: StyleView.FONT_SIZE_15,
                                  fontFamily: StyleView.FONT_TITLE,
                                  color: Colors.black),
                            ),
                          ]),
                        )),
                  )),
            ),
            Expanded(
                flex: 2,
                child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5),
                  alignment: Alignment.topLeft,
                  child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                      ),
                      onPressed: () async {
                        CommonMethods.hideKeyboard(context);

                        String value = await AppUtills.getSelectedDate(context);
                        setState(() {
                          formattedManufactureDate = value;
                        });
                      },
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Text(formattedManufactureDate),
                          Image.asset(
                            'assets/images/calander.png',
                            height: 30,
                          )
                        ],
                      )),
                )),
          ],
        ));
  }

  buildDateFieldExpaire(String _title, StateSetter setState) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: RichText(
                          text: TextSpan(children: [
                            TextSpan(
                              text: Language().getString(_title, selectedLang),
                              style: TextStyle(
                                  fontSize: StyleView.FONT_SIZE_15,
                                  fontFamily: StyleView.FONT_TITLE,
                                  color: Colors.black),
                            ),
                          ]),
                        )),
                  )),
            ),
            Expanded(
                flex: 2,
                child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5),
                  alignment: Alignment.topLeft,
                  child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                      ),
                      onPressed: () async {
                        CommonMethods.hideKeyboard(context);

                        String value = await AppUtills.getSelectedDate(context);
                        setState(() {
                          formattedExpireDate = value;
                        });
                      },
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Text(formattedExpireDate),
                          Image.asset(
                            'assets/images/calander.png',
                            height: 30,
                          )
                        ],
                      )),
                )),
          ],
        ));
  }

  addNewInventory() {
    return SizedBox(
        height: 25.0,
        width: 25.0,
        child: FloatingActionButton(
          heroTag: "bt1",
          onPressed: () {
            FocusScope.of(context).unfocus();
            buildInventoryFieldsTable(
                new InventoryManagementModel(), -1, false);
          },
          child: Icon(
            Icons.add,
            size: 15,
          ),
          backgroundColor: Color(0xFF083e64),
        ));
  }

  buildInventoryFieldsTable(
    InventoryManagementModel _inventoryData,
    int index,
    bool isUpdateInventory,
  ) {
    if (isUpdateInventory) {
      locationDropdownValue = locationsList[index];
      _locationQuantityController.text = _inventoryData.quantity.toString();
      this.updateInventoryQuantity();
    } else {
      locationDropdownValue = null;
      _locationQuantityController.clear();

      this.updateInventoryQuantity();
    }
    if (_qntyController.text.isNotEmpty || _qntyController.text == "0") {
      return showDialog(
          barrierDismissible: false,
          context: context,
          barrierColor: Colors.black54,
          builder: (BuildContext context) {
            return AlertDialog(
                elevation: 100.0,
                backgroundColor: Color(0XFFE0E0E0),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(
                    Radius.circular(
                      7.0,
                    ),
                  ),
                ),
                title: Text(
                  Language().getString(
                      isUpdateInventory
                          ? Constants.UPDATE_INVENTORY
                          : Constants.ADD_INVENTORY,
                      selectedLang),
                  style: TextStyle(
                      fontSize: StyleView.FONT_SIZE_18,
                      fontFamily: StyleView.FONT_TITLE,
                      color: Color(Constants.APP_COLOR)),
                ),
                titlePadding: dialogTitlePadding,
                content: StatefulBuilder(
                    builder: (BuildContext context, StateSetter setState) {
                  return Container(
                    margin: EdgeInsets.symmetric(
                      vertical: 5.0,
                    ),
                    child: SingleChildScrollView(
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          new Text(Language()
                              .getString(Constants.LOCATION, selectedLang)),
                          SizedBox(height: 5.0),
                          this.inventoryLocations(setState),
                          Container(
                              child: Row(
                            children: <Widget>[
                              new Text(Language()
                                  .getString(Constants.QUANTITY, selectedLang)),
                              SizedBox(
                                width: 3.0,
                              ),
                              Text(
                                  Language().getString(
                                          Constants.REMAINING_QUANTITY,
                                          selectedLang) +
                                      " : $remainingQuantity",
                                  style: TextStyle(
                                      fontSize: 10.0,
                                      color: Colors.deepOrange[300]))
                            ],
                          )),
                          SizedBox(height: 5.0),
                          SizedBox(
                              height: 70,
                              child: new TextFormField(
                                  keyboardType: TextInputType.number,
                                  style: TextStyle(
                                      fontFamily: StyleView.FONT_TITLE),
                                  controller: _locationQuantityController,
                                  decoration: StyleView.getInputDecoration(
                                      helper: Language().getString(
                                          Constants.ENTER_QUANTITY,
                                          selectedLang)),
                                  inputFormatters: [
                                    new LengthLimitingTextInputFormatter(6),
                                    CommonMethods.inputTextFormatter(
                                        isNumber: true)
                                  ])),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              TextButton(
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                                child: Text(
                                  Language().getString(
                                      Constants.STR_CANCEL, selectedLang),
                                  style: TextStyle(
                                      color: Color(Constants.APP_COLOR),
                                      fontFamily: StyleView.FONT_TITLE),
                                ),
                              ),
                              TextButton(
                                onPressed: () {
                                  String errorMessage =
                                      this.validateInventoryFields();

                                  if (errorMessage.isNotEmpty) {
                                    Dialogs.yesCancelDialog(
                                        context,
                                        Language().getString(
                                            Constants.ERROR, selectedLang),
                                        errorMessage,
                                        Language().getString(
                                            Constants.OKAY_STR, selectedLang),
                                        "",
                                        false);
                                  } else {
                                    this.validatingInventoryQuantity(
                                      int.parse(
                                          _locationQuantityController.text),
                                      index,
                                      isUpdateInventory,
                                    );
                                  }
                                },
                                child: Text(
                                  Language().getString(
                                      Constants.STR_SAVE, selectedLang),
                                  style: TextStyle(
                                      color: Color(Constants.APP_COLOR),
                                      fontFamily: StyleView.FONT_TITLE),
                                ),
                              )
                            ],
                          )
                        ],
                      ),
                    ),
                  );
                }));
          });
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          Language().getString(Constants.ENTER_VALID_QUANTITY, selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  Widget inventoryLocations(StateSetter setState) {
    return Container(
        margin: EdgeInsets.symmetric(
          vertical: 5.0,
        ),
        decoration: AppUtills.boxDecoration(),
        padding: EdgeInsets.all(1),
        child: Container(
            color: Colors.white70,
            padding: EdgeInsets.only(left: 5, right: 5),
            child: DropdownButton<Locations>(
                onTap: () {
                  FocusScope.of(context).unfocus();
                },
                isExpanded: true,
                hint: Text(
                    Language().getString(Constants.LOCATION, selectedLang)),
                underline: SizedBox(),
                items: locationsList.map((Locations locationData) {
                  return DropdownMenuItem<Locations>(
                    value: locationData,
                    child: new Text(
                      locationData.locationName!,
                      style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                    ),
                  );
                }).toList(),
                value: locationDropdownValue,
                onChanged: (Locations? location) {
                  setState(() {
                    locationDropdownValue = location;
                  });
                })));
  }

  String validateInventoryFields() {
    if (locationDropdownValue == null) {
      return "Please select location";
    } else {
      return "";
    }
  }

  onSaveInventoryDetails(bool isUpdateInventory, int index) {
    if (isUpdateInventory) {
      inventoryList[index] = InventoryManagementModel(
        locationName: locationDropdownValue!.locationName,
        quantity: int.parse(_locationQuantityController.text),
      );
      setState(() {
        inventoryList.reversed;
      });
      Navigator.of(context).pop();
    } else {
      bool isExistLocationName = false;
      int existIndex = -1;
      for (int i = 0; i < inventoryList.length; i++) {
        if (locationDropdownValue!.locationName ==
            inventoryList[i].locationName) {
          isExistLocationName = true;
          existIndex = i;
        }
      }

      if (isExistLocationName) {
        int updateQuantity = inventoryList[existIndex].quantity! +
            int.parse(_locationQuantityController.text) as int;
        inventoryList[existIndex] = InventoryManagementModel(
          locationName: locationDropdownValue!.locationName,
          quantity: updateQuantity,
        );
      } else {
        inventoryList.add(InventoryManagementModel(
          locationName: locationDropdownValue!.locationName,
          quantity: int.parse(_locationQuantityController.text),
        ));
      }

      setState(() {
        inventoryList.reversed;
      });
      Navigator.of(context).pop();
    }
  }

  Widget onCreateDynamicInventory() {
    return Column(children: <Widget>[
      for (int i = 0; i < inventoryList.length; i++)
        Container(
          margin: EdgeInsets.symmetric(
            vertical: 5.0,
          ),
          child: Column(children: <Widget>[
            Container(
                child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  flex: 10,
                  child: Container(
                    padding: EdgeInsets.all(5.0),
                    decoration: AppUtills.boxDecoration(),
                    child: Row(children: [
                      Expanded(
                        flex: 5,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            this.showTitleView(Constants.LOCATION,
                                inventoryList[i].locationName),
                            this.showTitleView(Constants.QUANTITY,
                                "${inventoryList[i].quantity}"),
                          ],
                        ),
                      ),
                      Expanded(
                        child: Container(
                            child: (_productPrivileges!.product_location_edit)
                                ? InkWell(
                                    child: Icon(Icons.edit,
                                        color: Color(Constants.APP_COLOR)),
                                    onTap: () {
                                      buildInventoryFieldsTable(
                                          inventoryList[i], i, true);
                                    })
                                : Container()),
                      ),
                    ]),
                  ),
                ),
                Expanded(
                    child: IconButton(
                        icon: Icon(
                          Icons.remove_circle_outline,
                          color: Colors.red,
                        ),
                        onPressed: () async {
                          final action = await Dialogs.removeItem(
                            context,
                            inventoryList[i].locationName,
                            Language()
                                .getString(Constants.WARNING, selectedLang),
                            Language().getString(
                                Constants.WARNING_TEXT, selectedLang),
                            cancel: Language()
                                .getString(Constants.STR_CANCEL, selectedLang),
                            yes: Language()
                                .getString(Constants.YES_STRING, selectedLang),
                          );

                          if (action == DialogAction.yes) {
                            setState(() {
                              inventoryList.removeAt(i);
                            });
                          }
                        }))
              ],
            )),
          ]),
        ),
    ]);
  }

  Future<List<BusinessUnitModel>> getBuData() async {
    _buList.clear();
    locationsList.clear();
    if (!isLoadingProgress) {
      setState(() {
        isLoadingProgress = true;
      });
    }

    http.Response response = await _service
        .get_organization("", AppController.instance.getMyBuId)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<BusinessUnitModel> _list = [];
    setState(() {
      isLoadingProgress = false;
    });
    if (response.statusCode == 200) {
      var object = json.decode(response.body);
      for (var data in object['data']) {
        _list.add(BusinessUnitModel.fromJson(data));
      }

      if (_list.length > 0 && widget.title == Constants.UPDATE_PRODUCT) {
        /// inventory functionality
        int totalInventoryCount = 0;
        for (int i = 0; i < _productsList[0].inventoryData!.length; i++) {
          totalInventoryCount = totalInventoryCount +
              (_productsList[0].inventoryData![i].quantity as int);

          inventoryList.add(InventoryManagementModel(
              locationName: _productsList[0].inventoryData![i].locationName,
              quantity: _productsList[0].inventoryData![i].quantity,
              batchNumber: _productsList[0].inventoryData![i].batchNumber));
        }
      }
    } else if (response.statusCode == 401) {
      CommonMethods.handleUnauthorizedAccess(context);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          response.body,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    return _list;
  }

  validatingItemDetails() {
    if (_heightController.text.isNotEmpty && heightDropdownValue == null) {
      return Constants.PLEASE_SELECT_HEIGHT;
    } else if (heightDropdownValue != null && _heightController.text.isEmpty) {
      return Constants.PLEASE_ENTER_HEIGHT;
    } else if (volumeController.text.isEmpty && volumeDropdownValue != null) {
      return Constants.PLEASE_ENTER_VOLUM;
    } else if (volumeController.text.isNotEmpty &&
        volumeDropdownValue == null) {
      return Constants.PLEASE_SELECT_VOLUM;
    } else if (_weightController.text.isEmpty && weightDropdownValue != null) {
      return Constants.PLEASE_ENTER_WEIGHT;
    } else if (_weightController.text.isNotEmpty &&
        weightDropdownValue == null) {
      return Constants.PLEASE_SELECT_WEIGHT;
    } else if (_widthController.text.isEmpty && widthDropdownValue != null) {
      return Constants.PLEASE_ENTER_WIDTH;
    } else if (_widthController.text.isNotEmpty && widthDropdownValue == null) {
      return Constants.PLEASE_SELECT_WIDTH;
    } else if (_depthController.text.isEmpty && depthDropdownValue != null) {
      return Constants.PLEASE_ENTER_DEPTH;
    } else if (_depthController.text.isNotEmpty && depthDropdownValue == null) {
      return Constants.PLEASE_SELECT_DEPTH;
    } else {
      return "";
    }
  }

  buildPurchasedDate() {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: RichText(
                          text: TextSpan(children: [
                            TextSpan(
                              text: Language().getString(
                                  Constants.PURCHASED_DATE, selectedLang),
                              style: TextStyle(
                                  fontSize: StyleView.FONT_SIZE_15,
                                  fontFamily: StyleView.FONT_TITLE,
                                  color: Colors.black),
                            ),
                            TextSpan(
                                text: "\*",
                                style: TextStyle(
                                    fontSize: StyleView.FONT_SIZE_15,
                                    color: Colors.red))
                          ]),
                        )),
                  )),
            ),
            Expanded(
                flex: 2,
                child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5),
                  alignment: Alignment.topLeft,
                  child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                      ),
                      onPressed: () async {
                        FocusScope.of(context).unfocus();

                        String value = await AppUtills.getSelectedDate(context);
                        setState(() {
                          purchasedDate = value;
                        });

                        DateTime selectedDate = DateTime.parse(purchasedDate!);
                        DateTime todayDate =
                            DateTime.parse(formatter.format(DateTime.now()));
                        daysDifferance =
                            todayDate.difference(selectedDate).inDays;

                        print("DIFF DAYS : $daysDifferance");
                      },
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Text(purchasedDate!,
                              style: TextStyle(color: Colors.black)),
                          Image.asset(
                            'assets/images/calander.png',
                            height: 30,
                          )
                        ],
                      )),
                )),
          ],
        ));
  }

  Widget buildInvoiceAttachement() {
    return Container(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            child: Row(
              children: [
                Text(
                  Language().getString(Constants.INVOICE_ATTACH, selectedLang),
                  style: TextStyle(fontSize: 15.0, fontWeight: FontWeight.bold),
                ),
                this.showInvoiceAttachmentView()
              ],
            ),
          ),
          Container(
            height: 150.0,
            width: MediaQuery.of(context).size.width,
            margin: EdgeInsets.symmetric(vertical: 5.0),
            decoration: AppUtills.boxDecoration(),
            child: (widget.title == Constants.CREATE_ASSETS_LIST ||
                    (assetListData != null &&
                        assetListData!.invoiceAttachment!.isEmpty &&
                        assetListData!.invoiceAttachementUrl!.length == 0))
                ? this.showInvoiceFileAttachView()
                : this.showUploadedInvoiceAttachementFile(),
          ),
        ],
      ),
    );
  }

  Widget showInvoiceFileAttachView() {
    if (selectedFile == null) {
      return Container(
        child: Center(
          child: Text(
            Language().getString(Constants.ATTCH_FILE, selectedLang),
            style: TextStyle(
              color: Color(Constants.APP_COLOR),
            ),
          ),
        ),
      );
    } else {
      if (lookupMimeType(selectedFile!.path) == "application/pdf") {
        return Container(
          child: Center(
            child: InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ShowPdfPage(path: selectedFile!.path),
                  ),
                );
              },
              child: Text(
                selectedFile!.path.split("/").last,
                style: TextStyle(
                    color: Color(Constants.APP_COLOR),
                    fontSize: 15.0,
                    decoration: TextDecoration.underline),
              ),
            ),
          ),
        );
      } else {
        return Container(
          child: InkWell(
            onTap: () {
              Navigator.push(
                context,
                PageTransition(
                    context: context,
                    page: HeroTagExample(
                      tagName: "My image",
                      fileImage: selectedFile!.path,
                      imageFrom: Constants.GALLERY_IMAGE,
                    )),
              );
            },
            child: Image.file(
              new File(selectedFile!.path),
              gaplessPlayback: true,
              height: 50.0,
              width: 70.0,
            ),
          ),
        );
      }
    }
  }

  buildUsefulLifeDurationDate() {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: RichText(
                          text: TextSpan(children: [
                            TextSpan(
                              text: Language().getString(
                                  Constants.LIFE_DURATION, selectedLang),
                              style: TextStyle(
                                  fontSize: StyleView.FONT_SIZE_15,
                                  fontFamily: StyleView.FONT_TITLE,
                                  color: Colors.black),
                            ),
                          ]),
                        )),
                  )),
            ),
            Expanded(
                flex: 2,
                child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5),
                  alignment: Alignment.topLeft,
                  child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                      ),
                      onPressed: () async {
                        FocusScope.of(context).unfocus();

                        String value = await AppUtills.getSelectedDate(context);
                        setState(() {
                          usefulLifeDuration = value;
                        });
                      },
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Text(usefulLifeDuration),
                          Image.asset(
                            'assets/images/calander.png',
                            height: 30,
                          )
                        ],
                      )),
                )),
          ],
        ));
  }

  Widget liabilityDesignView() {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 5.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            child: Text(
              Language().getString(Constants.IS_LIABILITY, selectedLang),
              style: TextStyle(fontSize: 15.0, fontWeight: FontWeight.bold),
            ),
          ),
          Container(
            child: Row(
              children: [
                Expanded(
                    child: Row(
                  children: [
                    Container(
                      child: Radio(
                          value: liabilityRadioVaue,
                          activeColor: Color(Constants.APP_COLOR),
                          groupValue: Constants.YES_STRING,
                          onChanged: (dynamic value) {
                            setState(() {
                              liabilityRadioVaue = Constants.YES_STRING;

                              scrapDeclaredDate = "";
                              scrapDisposedRadioValue = Constants.YES_STRING;
                              scrapDisposedDate = "";
                              disposedValueController.clear();
                            });
                          }),
                    ),
                    Text(
                      Language().getString(Constants.YES_STRING, selectedLang),
                      style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                      ),
                    )
                  ],
                )),
                Expanded(
                    child: Row(
                  children: [
                    Container(
                      child: Radio(
                          value: liabilityRadioVaue,
                          activeColor: Color(Constants.APP_COLOR),
                          groupValue: Constants.NO_STRING,
                          onChanged: (dynamic value) {
                            setState(() {
                              liabilityRadioVaue = Constants.NO_STRING;
                            });
                          }),
                    ),
                    Text(
                      Language().getString(Constants.NO_STRING, selectedLang),
                      style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                      ),
                    )
                  ],
                ))
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget scrapDesignView() {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 5.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            child: Text(
              Language().getString(Constants.IS_SCRAP, selectedLang),
              style: TextStyle(fontSize: 15.0, fontWeight: FontWeight.bold),
            ),
          ),
          Container(
            child: Row(
              children: [
                Expanded(
                    child: Row(
                  children: [
                    Container(
                      child: Radio(
                          value: Constants.YES_STRING,
                          activeColor: Color(Constants.APP_COLOR),
                          groupValue: scrapRadioValue,
                          onChanged: (dynamic value) {
                            setState(() {
                              scrapRadioValue = Constants.YES_STRING;
                            });
                          }),
                    ),
                    Text(
                      Language().getString(Constants.YES_STRING, selectedLang),
                      style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                      ),
                    )
                  ],
                )),
                Expanded(
                    child: Row(
                  children: [
                    Container(
                      child: Radio(
                          value: scrapRadioValue,
                          activeColor: Color(Constants.APP_COLOR),
                          groupValue: Constants.NO_STRING,
                          onChanged: (dynamic value) {
                            setState(() {
                              scrapRadioValue = Constants.NO_STRING;
                            });
                          }),
                    ),
                    Text(
                      Language().getString(Constants.NO_STRING, selectedLang),
                      style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                      ),
                    )
                  ],
                ))
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget showScrapDetailsView() {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 5.0),
      decoration: AppUtills.boxDecoration(),
      child: Column(
        children: [
          this.buildScrapDeclaredDate(),
          SizedBox(
              height: 1.0,
              child: Container(color: Color(Constants.GREY_COLOR))),
          this.buildDisposedView(),
          SizedBox(
              height: 1.0,
              child: Container(color: Color(Constants.GREY_COLOR))),
          this.scrapDisposedDateView(),
          SizedBox(
              height: 1.0,
              child: Container(color: Color(Constants.GREY_COLOR))),
          this.buildTableContent(
              Constants.DISPOSED_VALUE, disposedValueController, true, false)
        ],
      ),
    );
  }

  Widget buildDisposedView() {
    return Container(
      child: Row(
        children: [
          Expanded(
            child: Container(
                padding: EdgeInsets.only(
                  left: 10.0,
                ),
                height: 50,
                alignment: Alignment.centerLeft,
                color: Color(Constants.GREY_COLOR_LIGHT),
                child: Text(
                  Language().getString(Constants.DISPOSED, selectedLang),
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 15.0,
                  ),
                )),
          ),
          Expanded(
            flex: 2,
            child: Container(
                color: Colors.white,
                height: 50,
                child: Container(
                  child: Row(
                    children: [
                      Expanded(
                          child: Row(
                        children: [
                          Container(
                            child: Radio(
                                value: Constants.YES_STRING,
                                activeColor: Color(Constants.APP_COLOR),
                                groupValue: scrapDisposedRadioValue,
                                onChanged: (dynamic value) {
                                  setState(() {
                                    scrapDisposedRadioValue =
                                        Constants.YES_STRING;
                                  });
                                }),
                          ),
                          Text(
                            Language()
                                .getString(Constants.YES_STRING, selectedLang),
                            style: TextStyle(
                              color: Color(Constants.APP_COLOR),
                            ),
                          )
                        ],
                      )),
                      Expanded(
                          child: Row(
                        children: [
                          Container(
                            child: Radio(
                                value: scrapDisposedRadioValue,
                                activeColor: Color(Constants.APP_COLOR),
                                groupValue: Constants.NO_STRING,
                                onChanged: (dynamic value) {
                                  setState(() {
                                    scrapDisposedRadioValue =
                                        Constants.NO_STRING;
                                  });
                                }),
                          ),
                          Text(
                            Language()
                                .getString(Constants.NO_STRING, selectedLang),
                            style: TextStyle(
                              color: Color(Constants.APP_COLOR),
                            ),
                          )
                        ],
                      ))
                    ],
                  ),
                )),
          )
        ],
      ),
    );
  }

  Widget buildScrapDeclaredDate() {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: RichText(
                          text: TextSpan(children: [
                            TextSpan(
                              text: Language().getString(
                                  Constants.SCRAP_DECLARED_DATE, selectedLang),
                              style: TextStyle(
                                  fontSize: 14.0,
                                  fontFamily: StyleView.FONT_TITLE,
                                  color: Colors.black),
                            ),
                          ]),
                        )),
                  )),
            ),
            Expanded(
                flex: 2,
                child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5),
                  alignment: Alignment.topLeft,
                  child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                      ),
                      onPressed: () async {
                        FocusScope.of(context).unfocus();

                        String value = await AppUtills.getSelectedDate(context);
                        setState(() {
                          scrapDeclaredDate = value;
                        });
                      },
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Text(scrapDeclaredDate!,
                              style: TextStyle(color: Colors.black)),
                          Image.asset(
                            'assets/images/calander.png',
                            height: 30,
                          )
                        ],
                      )),
                )),
          ],
        ));
  }

  Widget scrapDisposedDateView() {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: RichText(
                          text: TextSpan(children: [
                            TextSpan(
                              text: Language().getString(
                                  Constants.DISPOSED_DATE, selectedLang),
                              style: TextStyle(
                                  fontSize: StyleView.FONT_SIZE_15,
                                  fontFamily: StyleView.FONT_TITLE,
                                  color: Colors.black),
                            ),
                          ]),
                        )),
                  )),
            ),
            Expanded(
                flex: 2,
                child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5),
                  alignment: Alignment.topLeft,
                  child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                      ),
                      onPressed: () async {
                        FocusScope.of(context).unfocus();

                        String value = await AppUtills.getSelectedDate(context);
                        setState(() {
                          scrapDisposedDate = value;
                        });
                      },
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Text(scrapDisposedDate!,
                              style: TextStyle(color: Colors.black)),
                          Image.asset(
                            'assets/images/calander.png',
                            height: 30,
                          )
                        ],
                      )),
                )),
          ],
        ));
  }

  Widget depreciationValueDesign() {
    return Container(
        height: 50.0,
        child: Row(
          children: [
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: RichText(
                          text: TextSpan(children: [
                            TextSpan(
                              text: Language().getString(
                                  Constants.DEPRECIATION, selectedLang),
                              style: TextStyle(
                                  fontSize: 14.0,
                                  fontFamily: StyleView.FONT_TITLE,
                                  color: Colors.black),
                            ),
                            TextSpan(
                                text: "\*",
                                style: TextStyle(
                                    fontSize: StyleView.FONT_SIZE_15,
                                    color: Colors.red))
                          ]),
                        )),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                color: Colors.white,
                padding: EdgeInsets.only(left: 5.0),
                child: DropdownButton<String>(
                    onTap: () {
                      FocusScope.of(context).unfocus();
                    },
                    value: depreciationDropdownValue,
                    hint: new Text("%"),
                    isExpanded: true,
                    underline: SizedBox(),
                    onChanged: (String? data) {
                      setState(() {
                        depreciationDropdownValue = data;
                      });

                      this.calculateResidualValue();
                    },
                    items: Constants.PERCENTAGELIST.map((String model) {
                      return new DropdownMenuItem<String>(
                        child: new Text(model),
                        value: model,
                      );
                    }).toList()),
              ),
            ),
          ],
        ));
  }

  addNewAttribute() {
    return SizedBox(
        height: 25.0,
        width: 25.0,
        child: FloatingActionButton(
          onPressed: () {
            FocusScope.of(context).unfocus();

            buildAttributeFieldsTable(new ProductAttributeModel(), -1, false);
          },
          child: Icon(
            Icons.add,
            size: 15,
          ),
          backgroundColor: Color(0xFF083e64),
        ));
  }

  buildAttributeFieldsTable(
    ProductAttributeModel _attributesData,
    int index,
    bool isUpdateAttribute,
  ) {
    if (isUpdateAttribute) {
      _attributeKeyController.text = _attributesData.attributeKey!;
      _attributeValueController.text = _attributesData.attributeValue!;
    } else {
      _attributeKeyController.clear();
      _attributeValueController.clear();
    }

    return showDialog(
        barrierDismissible: false,
        context: context,
        barrierColor: Colors.black54,
        builder: (BuildContext context) {
          return AlertDialog(
            elevation: 100.0,
            contentPadding: EdgeInsets.fromLTRB(15.0, 0, 15.0, 0),
            backgroundColor: Color(0XFFE0E0E0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(
                Radius.circular(
                  7.0,
                ),
              ),
            ),
            title: Text(
              Language().getString(Constants.ADD_NEW_FEATURE, selectedLang),
              style: TextStyle(
                fontSize: StyleView.FONT_SIZE_18,
                fontFamily: StyleView.FONT_TITLE,
                color: Color(Constants.APP_COLOR),
              ),
            ),
            titlePadding: dialogTitlePadding,
            content: Container(
              margin: EdgeInsets.symmetric(
                vertical: 5.0,
              ),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    new Text(Language()
                        .getString(Constants.FEATURE_NAME, selectedLang)),
                    SizedBox(height: 5.0),
                    buildTextFormFieldsDialog(
                      Language()
                          .getString(Constants.FEATURE_NAME, selectedLang),
                      _attributeKeyController,
                    ),
                    new Text(Language()
                        .getString(Constants.FEATURE_DETAILS, selectedLang)),
                    SizedBox(height: 5.0),
                    buildTextFormFieldsDialog(
                      Language()
                          .getString(Constants.FEATURE_DETAILS, selectedLang),
                      _attributeValueController,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        TextButton(
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                          child: Text(
                            Language()
                                .getString(Constants.STR_CANCEL, selectedLang),
                            style: TextStyle(
                                color: Color(Constants.APP_COLOR),
                                fontFamily: StyleView.FONT_TITLE),
                          ),
                        ),
                        TextButton(
                          onPressed: () {
                            onSaveAttributeDetails(isUpdateAttribute, index);
                          },
                          child: Text(
                            Language()
                                .getString(Constants.STR_SAVE, selectedLang),
                            style: TextStyle(
                                color: Color(Constants.APP_COLOR),
                                fontFamily: StyleView.FONT_TITLE),
                          ),
                        )
                      ],
                    )
                  ],
                ),
              ),
            ),
          );
        });
  }

  buildTextFormFieldsDialog(
    String? _labelText,
    TextEditingController controller,
  ) {
    return SizedBox(
        height: 70,
        child: new TextFormField(
            style: TextStyle(fontFamily: StyleView.FONT_TITLE),
            controller: controller,
            decoration: StyleView.getInputDecoration(
              helper: _labelText,
            ),
            onChanged: (text) => {}));
  }

  onSaveAttributeDetails(bool isUpdateAttribute, int index) {
    if (isUpdateAttribute) {
      attributesList[index] = ProductAttributeModel(
          attributeValue: _attributeValueController.text,
          attributeKey: _attributeKeyController.text);
      setState(() {
        attributesList.reversed;
      });
      Navigator.of(context).pop();
        } else {
      attributesList.add(ProductAttributeModel(
          attributeValue: _attributeValueController.text,
          attributeKey: _attributeKeyController.text));
      setState(() {
        attributesList.reversed;
      });
      Navigator.of(context).pop();
        }
  }

  Widget onCreateDynamicAttributes() {
    return Column(children: <Widget>[
      for (int i = 0; i < attributesList.length; i++)
        Container(
          margin: EdgeInsets.symmetric(
            vertical: 5.0,
          ),
          child: Column(
            children: <Widget>[
              AttributeExpandedPage(
                attributeKey: attributesList[i].attributeKey,
                attributeValue: attributesList[i].attributeValue,
                editPage: () {
                  buildAttributeFieldsTable(attributesList[i], i, true);
                },
                removeItem: () async {
                  final action = await Dialogs.removeItem(
                    context,
                    attributesList[i].attributeKey,
                    Language().getString(Constants.WARNING, selectedLang),
                    Language().getString(Constants.WARNING_TEXT, selectedLang),
                    cancel: Language()
                        .getString(Constants.STR_CANCEL, selectedLang),
                    yes: Language()
                        .getString(Constants.YES_STRING, selectedLang),
                  );
                  if (action == DialogAction.yes) {
                    setState(() {
                      attributesList.removeAt(i);
                    });
                  }
                },
              ),
            ],
          ),
        )
    ]);
  }

  loadAssetsGroupData({String name = ""}) async {
    if (await NetworkStatus.getInternetStatus()) {
      this.getAssetsGroupData(name: name).then((value) {
        setState(() {
          assetsGroupist.clear();
          assetsGroupist.addAll(value);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<AssetsGroupModel>> getAssetsGroupData({String name = ""}) async {
    String body = json.encode({
      "bu_id": buId,
      "filters": {"name": name}
    });

    var response = await _assestsService
        .getAssetsGroupList(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<AssetsGroupModel> list = [];
    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    var data = json.decode(_grpcResponse.message!);

    for (var object in data['results']) {
      list.add(AssetsGroupModel.fromJson(object));
    }
  
    return list;
  }

  Widget buildAssetsGroupDropdown() {
    return Container(
        height: 50.0,
        child: Row(
          children: [
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: RichText(
                          text: TextSpan(children: [
                            TextSpan(
                              text: Language()
                                  .getString(Constants.GROUP, selectedLang),
                              style: TextStyle(
                                  fontSize: StyleView.FONT_SIZE_15,
                                  fontFamily: StyleView.FONT_TITLE,
                                  color: Colors.black),
                            ),
                            TextSpan(
                                text: "\*",
                                style: TextStyle(
                                    fontSize: StyleView.FONT_SIZE_15,
                                    color: Colors.red))
                          ]),
                        )),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                color: Colors.white,
                padding: EdgeInsets.only(left: 5.0),
                child: DropdownButton<AssetsGroupModel>(
                    onTap: () {
                      FocusScope.of(context).unfocus();
                    },
                    value: assetGroupDropdownValue,
                    hint: new Text(Language()
                        .getString(Constants.SELECT_GROUP, selectedLang)),
                    isExpanded: true,
                    underline: SizedBox(),
                    onChanged: (AssetsGroupModel? data) {
                      setState(() {
                        assetGroupDropdownValue = data;
                      });
                    },
                    items: assetsGroupist.map((AssetsGroupModel model) {
                      return new DropdownMenuItem<AssetsGroupModel>(
                        child: new Text(model.name!),
                        value: model,
                      );
                    }).toList()),
              ),
            ),
          ],
        ));
  }

  Future<AssetsListDAO> getAssetDataById() async {
    setState(() {
      isLoadingProgress = true;
    });
    String body = json.encode({"bu_id": buId, "id": widget.assetRecordId});
    var response = await _assestsService
        .getAssetListDataById(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    AssetsListDAO modelData = AssetsListDAO();
    GRPCResponse _grpcRespone = response;
    if (!_grpcRespone.getIsError! && !_grpcRespone.getIsException!) {
      var reqData = json.decode(_grpcRespone.message!);

      modelData = AssetsListDAO.fromJson(reqData[0]);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcRespone.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return modelData;
  }

  bindingAssetData() {
    nameController.text = assetListData!.name!;
    _brandController.text = assetListData!.brand!;
    if (assetListData!.groupDetails != null) {
      for (int i = 0; i < assetsGroupist.length; i++) {
        if (assetListData!.groupDetails!.name == assetsGroupist[i].name) {
          assetGroupDropdownValue = assetsGroupist[i];
        }
      }
    }

    if (assetListData!.usefulLifeDuration != null) {
      for (int i = 0; i < YearsList.yearsList.length; i++) {
        if (assetListData!.usefulLifeDuration!.year == YearsList.yearsList[i]) {
          usefulLifeDurationYearDropdown = YearsList.yearsList[i];
          this.calculateDaysDifferance(
              years: usefulLifeDurationYearDropdown != null
                  ? usefulLifeDurationYearDropdown!
                  : "",
              months: usefulLifeDurationMonthDropdown != null
                  ? usefulLifeDurationMonthDropdown!
                  : "");
        }
      }

      for (int j = 0; j < YearsList.monthsList.length; j++) {
        if (assetListData!.usefulLifeDuration!.month ==
            YearsList.monthsList[j]) {
          usefulLifeDurationMonthDropdown = YearsList.monthsList[j];
          this.calculateDaysDifferance(
              years: usefulLifeDurationYearDropdown != null
                  ? usefulLifeDurationYearDropdown!
                  : "",
              months: usefulLifeDurationMonthDropdown != null
                  ? usefulLifeDurationMonthDropdown!
                  : "");
        }
      }
    }

    descriptionController.text = assetListData!.description!;
    purchasedDate = assetListData!.purchasedDate;
    usefulLifeRemainingController.text = assetListData!.usefulLifeRemaining!;
    netCostController.text = "${assetListData!.netCost}";

    for (int i = 0; i < Constants.PERCENTAGELIST.length; i++) {
      String percentage = assetListData!.depreciationPercentage! + " %";
      if (percentage == Constants.PERCENTAGELIST[i]) {
        depreciationDropdownValue = Constants.PERCENTAGELIST[i];
        this.calculateResidualValue();
      }
    }
    num? currentValue = assetListData!.depreciationExpenses;
    currentValueController.text = "$currentValue / year";

    for (int j = 0; j < assetListData!.attributesList!.length; j++) {
      attributesList.add(ProductAttributeModel(
          attributeKey:
              assetListData!.attributesList![j].entries.toList()[0].key,
          attributeValue:
              assetListData!.attributesList![j].entries.toList()[0].value));
    }
    int totalInventoryCount = 0;
    for (int k = 0; k < assetListData!.inventoryData!.length; k++) {
      totalInventoryCount = totalInventoryCount +
          (assetListData!.inventoryData![k].quantity as int);

      inventoryList.add(InventoryManagementModel(
          locationName: assetListData!.inventoryData![k].locationName,
          quantity: assetListData!.inventoryData![k].quantity,
          batchNumber: assetListData!.inventoryData![k].batchNumber));
    }

    if (assetListData!.isLiability!) {
      liabilityRadioVaue = Constants.YES_STRING;
    }

    if (assetListData!.isScrap!) {
      scrapRadioValue = Constants.YES_STRING;
    }

    scrapDeclaredDate = assetListData!.scrapDeclaredDate;
    if (assetListData!.isDisposed!) {
      scrapDisposedRadioValue = Constants.YES_STRING;
    }

    scrapDisposedDate = assetListData!.disposedDate;
    disposedValueController.text = assetListData!.disposedValue!;

    if (assetListData!.quantityDetails != null) {
      _qntyController.text =
          assetListData!.quantityDetails!.quantity.toString();
      quantityDropdownValue = assetListData!.quantityDetails!.quantityIn;
    }
  }

  Widget buildResidualValueView() {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        Language()
                            .getString(Constants.RESIDUAL_VALUE, selectedLang),
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_15,
                            fontFamily: 'IndianRupee'),
                      ),
                    ),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                height: 50,
                alignment: Alignment.centerLeft,
                color: Colors.white,
                padding: EdgeInsets.only(left: 5),
                child: Row(
                  children: [
                    Expanded(
                        child: Text("${residualValue.toStringAsFixed(2)}")),
                    Container(
                      margin: EdgeInsets.symmetric(horizontal: 5.0),
                      child: InkWell(
                          onTap: () {
                            this.showInfoMessageResidual();
                          },
                          child: Icon(Icons.info_outline,
                              color: Color(Constants.APP_COLOR))),
                    ),
                  ],
                ),
              ),
            )
          ],
        ));
  }

  Widget buildYearDropdownView() {
    return Row(
      children: <Widget>[
        Expanded(
          child: Container(
              height: 50,
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: RichText(
                      text: TextSpan(children: [
                        TextSpan(
                          text: Language()
                              .getString(Constants.LIFE_DURATION, selectedLang),
                          style: TextStyle(
                              fontSize: StyleView.FONT_SIZE_15,
                              fontFamily: StyleView.FONT_TITLE,
                              color: Colors.black),
                        ),
                        TextSpan(
                            text: "\*",
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                color: Colors.red))
                      ]),
                    )),
              )),
        ),
        Expanded(
            flex: 2,
            child: Container(
              color: Colors.grey,
              child: Row(children: <Widget>[
                Expanded(
                    child: Container(
                  padding: EdgeInsets.only(left: 5),
                  margin: EdgeInsets.only(right: 1),
                  color: Colors.white,
                  child: DropdownButton<String>(
                    onTap: () {
                      FocusScope.of(context).unfocus();
                    },
                    value: usefulLifeDurationYearDropdown,
                    hint: new Text(
                      Language().getString(Constants.YEAR, selectedLang),
                    ),
                    isExpanded: true,
                    underline: SizedBox(),
                    onChanged: (String? data) {
                      setState(() {
                        usefulLifeDurationYearDropdown = data;
                      });
                      this.calculateDaysDifferance(
                          years: usefulLifeDurationYearDropdown != null
                              ? usefulLifeDurationYearDropdown!
                              : "",
                          months: usefulLifeDurationMonthDropdown != null
                              ? usefulLifeDurationMonthDropdown!
                              : "");

                      if (depreciationDropdownValue != null) {
                        this.calculateResidualValue();
                      }
                    },
                    items: YearsList.yearsList.map((String model) {
                      return new DropdownMenuItem<String>(
                        child: new Text(model),
                        value: model,
                      );
                    }).toList(),
                  ),
                )),
                Expanded(
                  child: Container(
                    color: Colors.white,
                    padding: EdgeInsets.only(left: 5),
                    child: DropdownButton<String>(
                      onTap: () {
                        FocusScope.of(context).unfocus();
                      },
                      value: usefulLifeDurationMonthDropdown,
                      hint: new Text(
                        Language().getString(Constants.MONTH, selectedLang),
                      ),
                      isExpanded: true,
                      underline: SizedBox(),
                      onChanged: (String? data) {
                        setState(() {
                          usefulLifeDurationMonthDropdown = data;
                        });
                        this.calculateDaysDifferance(
                            years: usefulLifeDurationYearDropdown != null
                                ? usefulLifeDurationYearDropdown!
                                : "",
                            months: usefulLifeDurationMonthDropdown != null
                                ? usefulLifeDurationMonthDropdown!
                                : "");
                        if (depreciationDropdownValue != null) {
                          this.calculateResidualValue();
                        }
                      },
                      items: YearsList.monthsList.map((String model) {
                        return new DropdownMenuItem<String>(
                          child: new Text(model),
                          value: model,
                        );
                      }).toList(),
                    ),
                  ),
                ),
              ]),
            ))
      ],
    );
  }

  calculateDaysDifferance({String years = "", String months = ""}) {
    num _year = 0;
    num _months = 0;
    num _totalDays = 0;
    if (years.isNotEmpty) {
      List<String> yearsArray = [];
      yearsArray = years.split(" ");
      _year = int.parse(yearsArray[0]) * 365;
    }

    if (months.isNotEmpty) {
      List<String> monthsArray = [];
      monthsArray = months.split(" ");
      _months = int.parse(monthsArray[0]) * 30;
    }

    _totalDays = (_year + _months) - daysDifferance;

    int y = _totalDays ~/ 365;
    int m = (_totalDays % 365) ~/ 30;
    setState(() {
      if (y == 0 && m == 0) {
        usefulLifeRemainingController.text = "";
      } else if (y == 0 && m != 0) {
        usefulLifeRemainingController.text = "$m Months";
      } else if (y != 0 && m == 0) {
        usefulLifeRemainingController.text = "$y Years";
      } else {
        usefulLifeRemainingController.text = "$y Years $m Months";
      }
    });
  }

  calculateResidualValue() {
    num _deprValue = 0;
    num lifeDurationYear = 0;
    num lifeDurationmonth = 0;
    num totalLifeDuration = 0;

    num residualValueTotal = 0;
    if (depreciationDropdownValue != null) {
      List<String> depreArray = [];
      depreArray = depreciationDropdownValue!.split(" %");

      _deprValue = int.parse(depreArray[0]);
    }

    if (usefulLifeDurationYearDropdown != null) {
      List<String> yearsArray = [];
      yearsArray = usefulLifeDurationYearDropdown!.split(" ");
      lifeDurationYear = double.parse(yearsArray[0]) * 365;
    }

    if (usefulLifeDurationMonthDropdown != null) {
      List<String> monthsArray = [];
      monthsArray = usefulLifeDurationMonthDropdown!.split(" ");
      lifeDurationmonth = double.parse(monthsArray[0]) * 30;
    }

    totalLifeDuration = (lifeDurationYear + lifeDurationmonth) / 365;
    num purchasedCost = double.parse(netCostController.text);
    residualValueTotal = (purchasedCost -
        (purchasedCost * totalLifeDuration * _deprValue) / 100);
    residualValue = residualValueTotal;

    this.calculateDepreciationExpenseValue(residualValueTotal);
  }

  calculateDepreciationExpenseValue(num _value) {
    num _deprExpenseValue = 0;
    num _lifeYearDuration = 0;
    num _lifeMonthDuration = 0;
    num _totalDaysLifeDuration = 0;
    num _purchasedCost = double.parse(netCostController.text);
    if (usefulLifeDurationYearDropdown != null) {
      List<String> yearsArray = [];
      yearsArray = usefulLifeDurationYearDropdown!.split(" ");
      _lifeYearDuration = int.parse(yearsArray[0]) * 365;
    }

    if (usefulLifeDurationMonthDropdown != null) {
      List<String> monthsArray = [];
      monthsArray = usefulLifeDurationMonthDropdown!.split(" ");
      _lifeMonthDuration = int.parse(monthsArray[0]) * 30;
    }

    _totalDaysLifeDuration = _lifeYearDuration + _lifeMonthDuration;
    _deprExpenseValue =
        ((_purchasedCost - _value) / _totalDaysLifeDuration) * 365;
    currentValueController.text =
        "${_deprExpenseValue.toStringAsFixed(2)} / year";
  }

  Widget depreciationExpenseView() {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Text(
                      Language().getString(
                          Constants.DEPRECIATION_EXPENSE, selectedLang),
                      style: TextStyle(
                          fontSize: StyleView.FONT_SIZE_15,
                          fontFamily: 'IndianRupee'),
                    ),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                height: 50,
                color: Colors.white,
                padding: EdgeInsets.only(left: 5),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                          controller: currentValueController,
                          style: TextStyle(
                            fontFamily: 'IndianRupee',
                          ),
                          enabled: false,
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintText: Language().getString(
                                Constants.DEPRECIATION_EXPENSE, selectedLang),
                          )),
                    ),
                    Container(
                      margin: EdgeInsets.symmetric(horizontal: 5.0),
                      child: InkWell(
                          onTap: () {
                            this.showInfoMessageDepreciationExpense();
                          },
                          child: Icon(Icons.info_outline,
                              color: Color(Constants.APP_COLOR))),
                    ),
                  ],
                ),
              ),
            )
          ],
        ));
  }

  Widget buildNetCostView() {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: RichText(
                          text: TextSpan(children: [
                            TextSpan(
                              text: Language()
                                  .getString(Constants.NET_COST, selectedLang),
                              style: TextStyle(
                                  fontSize: StyleView.FONT_SIZE_15,
                                  fontFamily: StyleView.FONT_TITLE,
                                  color: Colors.black),
                            ),
                            TextSpan(
                                text: "\*",
                                style: TextStyle(
                                    fontSize: StyleView.FONT_SIZE_15,
                                    color: Colors.red))
                          ]),
                        )),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                color: Colors.white,
                padding: EdgeInsets.only(left: 5),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                          keyboardType: TextInputType.number,
                          controller: netCostController,
                          style: TextStyle(
                            fontFamily: 'IndianRupee',
                          ),
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintText: Language()
                                .getString(Constants.NET_COST, selectedLang),
                          ),
                          inputFormatters: [
                            CommonMethods.inputTextFormatter(isDouble: true)
                          ]),
                    ),
                    Container(
                      margin: EdgeInsets.symmetric(horizontal: 5.0),
                      child: InkWell(
                          onTap: () {
                            this.showInfoButtonMessage(
                                "Purchase Cost Less Accumulated Depreciation");
                          },
                          child: Icon(Icons.info_outline,
                              color: Color(Constants.APP_COLOR))),
                    ),
                  ],
                ),
              ),
            )
          ],
        ));
  }

  showInfoButtonMessage(String message) {
    Dialogs.yesCancelDialog(
        context,
        Language().getString(Constants.INFO, selectedLang),
        message,
        Language().getString(Constants.OKAY_STR, selectedLang),
        "",
        false);
  }

  showInfoMessageResidual() {
    return showDialog(
        barrierDismissible: false,
        context: context,
        builder: (context) => AlertDialog(
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: Text(
                      Language().getString(Constants.OKAY_STR, selectedLang),
                      style: TextStyle(
                          fontFamily: StyleView.FONT_TITLE,
                          color: Color(Constants.APP_COLOR),
                          fontSize: 20.0)),
                )
              ],
              elevation: 100.0,
              backgroundColor: Color(0XFFE0E0E0),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(
                  Radius.circular(
                    7.0,
                  ),
                ),
              ),
              contentPadding:
                  EdgeInsets.only(right: 15.0, left: 15.0, top: 15.0),
              title: Text(Language().getString(Constants.INFO, selectedLang),
                  style: TextStyle(
                    color: Color(Constants.APP_COLOR),
                    fontSize: 20.0,
                    fontFamily: StyleView.FONT_TITLE,
                    fontWeight: FontWeight.bold,
                  )),
              content: Container(
                height: 100.0,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      child: Text(
                          Language()
                                  .getString(Constants.FORMULA, selectedLang) +
                              " :",
                          style: TextStyle(
                            color: Color(Constants.APP_COLOR),
                            fontSize: 15.0,
                            fontFamily: StyleView.FONT_TITLE,
                            fontWeight: FontWeight.bold,
                          )),
                    ),
                    Container(
                        margin: EdgeInsets.symmetric(vertical: 5.0),
                        child: Text(
                            " (Purchased Cost-(Purchased Cost * UsefulLife Duration * Depreciation Percentage)/100) ",
                            style: TextStyle(
                              fontSize: 14.0,
                              color: Colors.black,
                              fontFamily: StyleView.FONT_TITLE,
                            )))
                  ],
                ),
              ),
            ));
  }

  showInfoMessageDepreciationExpense() {
    return showDialog(
        barrierDismissible: false,
        context: context,
        builder: (context) => AlertDialog(
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: Text(
                      Language().getString(Constants.OKAY_STR, selectedLang),
                      style: TextStyle(
                          fontFamily: StyleView.FONT_TITLE,
                          color: Color(Constants.APP_COLOR),
                          fontSize: 20.0)),
                )
              ],
              elevation: 100.0,
              backgroundColor: Color(0XFFE0E0E0),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(
                  Radius.circular(
                    7.0,
                  ),
                ),
              ),
              contentPadding:
                  EdgeInsets.only(right: 15.0, left: 15.0, top: 15.0),
              title: Text(Language().getString(Constants.INFO, selectedLang),
                  style: TextStyle(
                    color: Color(Constants.APP_COLOR),
                    fontSize: 20.0,
                    fontFamily: StyleView.FONT_TITLE,
                    fontWeight: FontWeight.bold,
                  )),
              content: Container(
                height: 100.0,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      child: Text(
                          Language().getString(
                                  Constants.DEPRECIATION_METHOD, selectedLang) +
                              " :",
                          style: TextStyle(
                            color: Color(Constants.APP_COLOR),
                            fontSize: 15.0,
                            fontFamily: StyleView.FONT_TITLE,
                            fontWeight: FontWeight.bold,
                          )),
                    ),
                    Container(
                      margin: EdgeInsets.symmetric(vertical: 5.0),
                      child: RichText(
                        text: TextSpan(children: [
                          TextSpan(
                            text: "Straight Line: ",
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: StyleView.FONT_TITLE,
                                color: Colors.black,
                                fontWeight: FontWeight.bold),
                          ),
                          TextSpan(
                              text:
                                  " Depreciation Expense = (Cost of the Asset – Residual Value) / Estimated Useful Life of the Asset.",
                              style: TextStyle(
                                fontSize: 14.0,
                                color: Colors.black,
                                fontFamily: StyleView.FONT_TITLE,
                              ))
                        ]),
                      ),
                    )
                  ],
                ),
              ),
            ));
  }

  validatingInventoryQuantity(int quantity, int index, bool isUpdateInventory) {
    if (quantity > int.parse(_qntyController.text)) {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          Language().getString(Constants.INVALID_QUANTITY, selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    } else {
      this.onSaveInventoryDetails(isUpdateInventory, index);
    }
  }

  updateInventoryQuantity() {
    num totalInventoryQuantity = 0;
    if (inventoryList.length > 0) {
      for (int i = 0; i < inventoryList.length; i++) {
        totalInventoryQuantity =
            totalInventoryQuantity + inventoryList[i].quantity!;
      }
      setState(() {
        remainingQuantity =
            (int.parse(_qntyController.text) - totalInventoryQuantity)
                .toString();
      });
    } else {
      setState(() {
        remainingQuantity = _qntyController.text;
      });
    }
  }

  _uploadAssetImage(String? assetId) async {
    String body =
        json.encode({"id": assetId, "bu_id": buId, "image": imageBlob});

    http.Response response =
        await _service.uploadAssetImage(body).catchError((onError) {
      setState(() {
        isLoadingProgress = true;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    setState(() {
      isLoadingProgress = false;
    });

    if (response.statusCode == 200) {
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          Language()
              .getString(Constants.IMAGE_UPLOAD_SUCCESSFULLY, selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);

      if (action == DialogAction.yes) {
        Navigator.pop(context);
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          response.body,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  uploadFile(File file, String? invoiceId) async {
    String imageBlob = "";
    setState(() {
      isLoadingProgress = true;
      progressMessage = Constants.UPDATING;
    });
    if (lookupMimeType(file.path) == "application/pdf") {
      Map<String, String?> headers = {
        "authorization": AppController.instance.getAuthorizationKey,
        "content-type": "application/pdf",
      };

      var uploadUrl =
          Uri.parse(Constants.NEW_BASE_URL + "assets/attachment/$invoiceId");

      http.MultipartRequest _request =
          new http.MultipartRequest("PUT", uploadUrl);
      http.MultipartFile multipartFile = await http.MultipartFile.fromPath(
          "file", file.path,
          contentType: new MediaType('application', 'pdf'));

      _request.files.add(multipartFile);
      _request.headers.addAll(headers as Map<String, String>);

      StreamedResponse response = await _request.send();
      setState(() {
        isLoadingProgress = false;
      });
      response.stream.transform(utf8.decoder).listen((value) {
        var _response = json.decode(value);
        if (_response['status'] == "success") {
          print("ASSET PDF FILE UPLOADED $_response");
        } else {
          print("ASSET PDF FILE UPLOADED $_response");
        }
      });
    } else {
      imageBlob = AppUtills.getBase64Image(file, context);

      String body = json.encode({"invoice_attachment": imageBlob});

      http.Response response = await _service
          .uploadAssetListAttachementImage(body, invoiceId)
          .catchError((onError) {
        setState(() {
          isLoadingProgress = false;
        });
        print("ASSET PDF FILE UPLOADED $onError");
      });
      setState(() {
        isLoadingProgress = false;
      });
      if (response.statusCode == 200) {
        print("ASSET IMAGE UPLOADED ${response.body}");
      } else if (response.statusCode == 401) {
        CommonMethods.handleUnauthorizedAccess(context);
      } else {
        print("ASSET IMAGE UPLOADED ${response.body}");
      }
    }
  }

  Widget showUploadedInvoiceAttachementFile() {
    if (assetListData != null && assetListData!.invoiceAttachment!.isNotEmpty) {
      return Container(
        child: Center(
          child: InkWell(
            onTap: () {
              Navigator.push(
                  context,
                  PageTransition(
                      context: context,
                      page: TermsPage(
                        isFromAssetPage: true,
                        assetRecordId: assetListData!.id,
                        fileName: assetListData!.invoiceAttachment,
                      )));
            },
            child: Text(assetListData!.invoiceAttachment!,
                style: TextStyle(
                  color: Color(Constants.APP_COLOR),
                  decoration: TextDecoration.underline,
                )),
          ),
        ),
      );
    } else if (assetListData != null &&
        assetListData!.invoiceAttachementUrl!.length > 0) {
      return Image.network(
        Constants.NEW_BASE_URL +
            "assets/attachment/" +
            assetListData!.invoiceAttachementUrl![0].image!,
        headers: {
          'Content-type': 'application/json',
          'Accept': 'application/json',
          'authorization': AppController.instance.getAuthorizationKey
        },
        width: 50,
        height: 50,
        gaplessPlayback: true,
        errorBuilder:
            (BuildContext context, Object exception, StackTrace? stackTrace) {
          return Image.asset(
            'assets/images/empty.jpg',
            width: 50,
            height: 50,
            gaplessPlayback: true,
          );
        },
      );
    } else {
      return Container();
    }
  }

  Widget showInvoiceAttachmentView() {
    if (widget.title == Constants.CREATE_ASSETS_LIST) {
      return IconButton(
          icon: Icon(Icons.photo_library),
          onPressed: () async {
            // File? pickedFile;
            // pickedFile = await CommonMethods()
            //     .getFileUpload(context, isForMultiFile: true);
            // setState(() {
            //   selectedFile = pickedFile;
            // });
          });
    } else {
      if (assetListData != null &&
          assetListData!.invoiceAttachment!.isEmpty &&
          assetListData!.invoiceAttachementUrl!.length == 0) {
        return IconButton(
            icon: Icon(Icons.photo_library),
            onPressed: () async {
              File? pickedFile;
              // pickedFile = await CommonMethods()
              //     .getFileUpload(context, isForMultiFile: true);
              // setState(() {
              //   selectedFile = pickedFile;
              // });
            });
      } else {
        return Container();
      }
    }
  }

  showTitleView(String title, String? value) {
    return Container(
        margin: EdgeInsets.symmetric(vertical: 2.0),
        child: RichText(
          text: TextSpan(
            children: <TextSpan>[
              TextSpan(
                  text: title,
                  style: TextStyle(
                      fontSize: 15.0,
                      fontFamily: StyleView.FONT_TITLE,
                      color: Colors.black,
                      fontWeight: FontWeight.bold)),
              TextSpan(
                text: " : $value",
                style: TextStyle(
                  fontSize: 13.0,
                  fontFamily: StyleView.FONT_TITLE,
                  color: Colors.black,
                ),
              )
            ],
          ),
        ));
  }
}
