import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Reports/DownloadAllReports.dart';
import 'package:vyaparlive/assets_management/ScrapItemDetails.dart';
import 'package:vyaparlive/assets_management/list_card_view/ScrapListCardView.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/DateFilterUtil.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/AssetsGroupModel.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/ScrapListDAO.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:vyaparlive/service/assets_management_grpc.dart';
import 'package:vyaparlive/utills/vyapar_info.dart';

class ScrapListPage extends StatefulWidget {
  @override
  _ScrapListPageState createState() => _ScrapListPageState();
}

class _ScrapListPageState extends State<ScrapListPage> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  String? buName = "";
  String? buId = "";
  bool isLoadingProgress = true;
  String progressMessage = Constants.GETTING_DATA;
  String fromDate = "";
  String toDate = "";
  TextEditingController _searchController = TextEditingController();
  bool isEnableDateFilter = true;
  bool isShowFloatButton = false;
  List<String> _checked = [];
  List<String> filterOptions = [
    Constants.DISPOSED,
    Constants.NON_DISPOSED,
  ];
  String filterStatus = "";
  DateFormat formatter = DateFormat("yyyy-MM-dd");
  late AssetsManagementGrpcService _assetsService;
  List<ScrapListDAO> scrapList = [];
  DateTime mnthStartDate =
      DateTime.utc(DateTime.now().year, DateTime.now().month, 1);
  List<AssetsGroupModel> assetsGroupist = [];
  AssetsGroupModel? assetGroupDropdownValue;
  List<Map> _mapData = [];

  @override
  void initState() {
    super.initState();
    this.getLoadLanguage();
    _assetsService = AssetsManagementGrpcService();
    buName = AppController.instance.getBuName;
    buId = AppController.instance.getMyBuId;
    fromDate = formatter.format(mnthStartDate);
    toDate = formatter.format(DateTime.now());
    this.loadScrapListData(fromDate: fromDate, toDate: toDate);
    this.loadAssetsGroupData();
  }

  loadScrapListData(
      {String name = "",
      String fromDate = "",
      String toDate = "",
      bool isDisposed = false,
      bool isNonDisposed = false,
      String? groupName = ""}) async {
    getScapList(
            name: name,
            fromDate: fromDate,
            toDate: toDate,
            isDisposed: isDisposed,
            isNonDisposed: isNonDisposed,
            groupName: groupName)
        .then((value) {
      setState(() {
        scrapList.clear();
        scrapList.addAll(value);
      });
    });
  }

  getLoadLanguage() {
    _mapData = [
      {"name": Language().getString(Constants.ASSET_NAME, selectedLang)},
      {"name": Language().getString(Constants.GROUP, selectedLang)},
      {"name": Language().getString(Constants.DISPOSED_DATE, selectedLang)},
      {"name": Language().getString(Constants.DATE, selectedLang)},
      {"name": Language().getString(Constants.STATUS_STRING, selectedLang)},
      {"name": Language().getString(Constants.EDIT, selectedLang)},
      {"name": Language().getString(Constants.DELETE_STRING, selectedLang)},
    ];
  }

  @override
  Widget build(BuildContext context) {
    return
        // WillPopScope(
        //   onWillPop: () {
        //     return CommonMethods.onBackPress(context);
        //   },
        //   child:
        Stack(
      children: [
        SafeArea(
          child: Scaffold(
            key: _scaffoldkey,
            backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
            appBar: AppBar(
              backgroundColor: Color(Constants.APP_COLOR),
              centerTitle: true,
              title: Column(
                children: [
                  Text(Language().getString(Constants.SCRAP_LIST, selectedLang)),
                  Text(
                    buName!,
                    style: TextStyle(fontSize: 13.0),
                  ),
                ],
              ),
            ),
            floatingActionButton: (isShowFloatButton)
                ? FloatingActionButton(
                    backgroundColor: Color(Constants.APP_COLOR),
                    onPressed: () {
                      setState(() {
                        isLoadingProgress = true;
                        isShowFloatButton = false;
                        _searchController.clear();
                        _checked.clear();
                        filterStatus = "";
                        assetGroupDropdownValue = null;
                      });
                      fromDate = formatter.format(mnthStartDate);
                      toDate = formatter.format(DateTime.now());
                      this.loadScrapListData(fromDate: fromDate, toDate: toDate);
                    },
                    child: Text(
                      Language().getString(Constants.CLEAR_FILTERS, selectedLang),
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white, fontSize: 11.0),
                    ))
                : null,
            // drawer: MyDrawer(),
            body: Container(
                margin: EdgeInsets.symmetric(vertical: 5.0, horizontal: 5.0),
                child: Column(
                  children: [
                    // (scrapList.length > 0)
                    //     ? this.showDownloadButton()
                    //     : Container(),
                    this.buildSearchBarView(),
                    (isEnableDateFilter)
                        ? DateFilterUtill(
                            fromDate: fromDate,
                            toDate: toDate,
                            onFromDateSelected: (value) {
                              setState(() {
                                fromDate = value;
                              });
                            },
                            onToDateSelected: (value) {
                              setState(() {
                                toDate = value;
                              });
                            },
                            onSearchParms: () {
                              setState(() {
                                isShowFloatButton = true;
                                isLoadingProgress = true;
                              });
          
                              this.loadScrapListData(
                                  fromDate: fromDate, toDate: toDate);
                            },
                          )
                        : Container(),
                    (scrapList.length > 0)
                        ? Expanded(
                            child: ListView.separated(
                                shrinkWrap: true,
                                itemBuilder: (context, index) {
                                  return InkWell(
                                    onTap: () {
                                      Navigator.push(
                                          context,
                                          PageTransition(
                                              context: context,
                                              page: ScrapItemDetailsPage(
                                                scrapId: scrapList[index].id,
                                                isFromScrap: true,
                                              )));
                                    },
                                    child: ScrapListCardView(
                                        isForScrap: true,
                                        modelData: scrapList[index],
                                        mapData: _mapData),
                                  );
                                },
                                separatorBuilder: (context, index) => Divider(
                                      color: Colors.transparent,
                                      height: 5.0,
                                    ),
                                itemCount: scrapList.length),
                          )
                        : Container(
                            child: Text(Language().getString(
                                Constants.NO_DATA_FOUND, selectedLang)),
                          ),
                  ],
                )),
          ),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
      // ),
    );
  }

  Widget buildSearchBarView() {
    return Container(
      height: 40.0,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(5.0),
        border: Border.all(
          color: Colors.grey,
        ),
      ),
      child: Row(
        children: <Widget>[
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(5.0),
                  bottomLeft: Radius.circular(5.0),
                ),
                color: Colors.white,
              ),
              padding: EdgeInsets.only(left: 5),
              child: TextFormField(
                controller: _searchController,
                onChanged: onSearchTextChanged,
                style: TextStyle(fontFamily: 'IndianRupee'),
                decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: Language()
                        .getString(Constants.SEARCH_BY_NAME, selectedLang),
                    hintStyle: TextStyle(
                        fontSize: 13.0, fontFamily: StyleView.FONT_TITLE)),
              ),
            ),
          ),
          (_searchController.text.length > 0)
              ? Container(
                  color: Colors.white,
                  child: IconButton(
                      icon: Icon(
                        Icons.close,
                        color: Colors.red,
                        size: 20.0,
                      ),
                      onPressed: () {
                        CommonMethods.hideKeyboard(context);
                        _searchController.clear();
                        onSearchTextChanged(_searchController.text);
                      }),
                )
              : Container(),
          Container(
            color: Colors.white,
            child: IconButton(
                icon: Icon(Icons.date_range),
                onPressed: () {
                  CommonMethods.hideKeyboard(context);
                  setState(() {
                    if (isEnableDateFilter) {
                      isEnableDateFilter = false;
                    } else {
                      isEnableDateFilter = true;
                    }
                  });
                }),
          ),
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.only(
                topRight: Radius.circular(5.0),
                bottomRight: Radius.circular(5.0),
              ),
              color: Colors.white,
            ),
            child: IconButton(
                icon: Icon(Icons.filter_list),
                onPressed: () {
                  CommonMethods.hideKeyboard(context);
                  this.showFiltersPopup();
                }),
          )
        ],
      ),
    );
  }

  onSearchTextChanged(String text) async {
    if (text.isEmpty) {
      isLoadingProgress = true;
      this.loadScrapListData(fromDate: fromDate, toDate: toDate);
    } else {
      isLoadingProgress = false;
      this.loadScrapListData(name: text, fromDate: fromDate, toDate: toDate);
    }
  }

  showFiltersPopup() {
    return showDialog(
        context: context,
        barrierColor: Colors.black54,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
            title: Text(
              Language().getString(Constants.SORT_BY_STR, selectedLang),
            ),
            actions: [
              Container(
                width: MediaQuery.of(context).size.width,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    TextButton(
                        onPressed: () {
                          setState(() {
                            _checked.clear();
                            filterStatus = "";
                            assetGroupDropdownValue = null;
                          });
                          Navigator.of(context).pop();
                        },
                        child: Text(
                          Language()
                              .getString(Constants.STR_CANCEL, selectedLang),
                          style: TextStyle(
                              color: Color(Constants.APP_COLOR),
                              fontSize: 18.0),
                        )),
                    TextButton(
                        onPressed: () {
                          setState(() {
                            isShowFloatButton = true;
                            isLoadingProgress = true;
                          });
                          if (_checked.length > 0) {
                            if (_checked[0] == Constants.DISPOSED) {
                              filterStatus = Constants.DISPOSED;
                            } else if (_checked[0] == Constants.NON_DISPOSED) {
                              filterStatus = Constants.NON_DISPOSED;
                            } else {
                              filterStatus = "";
                            }
                          }

                          Navigator.of(context).pop();

                          this.loadScrapListData(
                              isDisposed: filterStatus == Constants.DISPOSED
                                  ? true
                                  : false,
                              isNonDisposed:
                                  filterStatus == Constants.NON_DISPOSED
                                      ? true
                                      : false,
                              groupName: assetGroupDropdownValue != null
                                  ? assetGroupDropdownValue!.name
                                  : "",
                              fromDate: fromDate,
                              toDate: toDate);
                        },
                        child: Text(
                          Language()
                              .getString(Constants.SUBMIT_STRING, selectedLang),
                          style: TextStyle(
                              color: Color(Constants.APP_COLOR),
                              fontSize: 18.0),
                        ))
                  ],
                ),
              )
            ],
            content: StatefulBuilder(
                builder: (BuildContext context, StateSetter setState) {
              return Container(
                  child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    margin: EdgeInsets.symmetric(vertical: 5.0),
                    child: Text(
                      Language().getString("Sort by Group", selectedLang),
                      style: TextStyle(
                          color: Color(Constants.APP_COLOR),
                          fontSize: 15.0,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                  Container(
                    decoration: AppUtills.boxDecoration(),
                    child: this.buildAssetsGroupDropdown(setState),
                  ),
                  Container(
                    margin: EdgeInsets.symmetric(vertical: 5.0),
                    child: Text(
                      Language().getString("Sort by Status", selectedLang),
                      style: TextStyle(
                          color: Color(Constants.APP_COLOR),
                          fontSize: 15.0,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                  // CheckboxGroup(
                  //   labels: filterOptions,
                  //   checked: _checked,
                  //   onSelected: (List selected) {
                  //     if (selected.length > 1) {
                  //       selected.removeAt(0);
                  //     }
                  //     setState(() {
                  //       _checked = selected;
                  //     });
                  //   },
                  // ),
                ],
              ));
            })));
  }

  Future<List<ScrapListDAO>> getScapList(
      {String name = "",
      String fromDate = "",
      String toDate = "",
      bool isDisposed = false,
      bool isNonDisposed = false,
      String? groupName = ""}) async {
    String body = "";
    Map filters = {
      "name": name,
      "DateFrom": fromDate,
      "DateTo": toDate,
      "groupName": groupName
    };
    if (isDisposed) {
      filters['disposed'] = isDisposed;
    } else if (isNonDisposed) {
      filters['disposed'] = isNonDisposed;
    } else {
      print("No filter selected");
    }
    body = json.encode({"bu_id": buId, "filters": filters});

    var response = await _assetsService
        .getScrapList(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    List<ScrapListDAO> list = [];
    GRPCResponse _grpcResponse = response;
    var data = json.decode(_grpcResponse.message!);
    bool isString = false;

    if (data is String) {
      isString = true;
    }

    if (!isString) {
      for (var object in data['results']) {
        list.add(ScrapListDAO.fromJson(object));
      }
    }

    return list;
  }

  Widget showDownloadButton() {
    String reqBody = "";
    String reqUrl = "";
    reqUrl = Constants.NEW_BASE_URL + "http-utils/reports/scrapList";
    reqBody = json.encode({
      "bu_id": buId,
      "filters": {
        "name": _searchController.text,
        "status": filterStatus,
        "DateFrom": fromDate,
        "DateTo": toDate
      }
    });

    var encryptedData = VyaparInfo.encryptData(reqBody);
    Map map = {
      "data": encryptedData,
      "Authorization": AppController.instance.getAuthorizationKey
    };
    return DownloadAllReportsPage(
        isApiCallComplete: (apiCallCompleted) {
          if (apiCallCompleted) {
            setState(() {
              isLoadingProgress = false;
            });
          } else {
            setState(() {
              isLoadingProgress = true;
            });
          }
        },
        url: reqUrl,
        mapData: map,
        fileName: Constants.SCRAP_LIST,
        strDownload: Language().getString(Constants.DOWNLOAD, selectedLang));
  }

  loadAssetsGroupData() async {
    if (await NetworkStatus.getInternetStatus()) {
      this.getAssetsGroupData().then((value) {
        setState(() {
          assetsGroupist.clear();
          assetsGroupist.addAll(value);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<AssetsGroupModel>> getAssetsGroupData() async {
    String body = json.encode({"bu_id": buId, "filters": {}});

    var response = await _assetsService
        .getAssetsGroupList(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<AssetsGroupModel> list = [];
    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;

    if (!_grpcResponse.isError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);

      for (var object in data['results']) {
        list.add(AssetsGroupModel.fromJson(object));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }

    return list;
  }

  Widget buildAssetsGroupDropdown(StateSetter setState) {
    return Container(
        height: 50.0,
        child: Row(
          children: [
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        Language().getString(Constants.GROUP, selectedLang),
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_15,
                            fontFamily: 'IndianRupee'),
                      ),
                    ),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                color: Colors.white,
                padding: EdgeInsets.only(left: 5.0),
                child: DropdownButton<AssetsGroupModel>(
                    onTap: () {
                      FocusScope.of(context).unfocus();
                    },
                    value: assetGroupDropdownValue,
                    hint: new Text(Language()
                        .getString(Constants.SELECT_GROUP, selectedLang)),
                    isExpanded: true,
                    underline: SizedBox(),
                    onChanged: (AssetsGroupModel? data) {
                      setState(() {
                        assetGroupDropdownValue = data;
                      });
                    },
                    items: assetsGroupist.map((AssetsGroupModel model) {
                      return new DropdownMenuItem<AssetsGroupModel>(
                        child: new Text(model.name!),
                        value: model,
                      );
                    }).toList()),
              ),
            ),
          ],
        ));
  }
}
