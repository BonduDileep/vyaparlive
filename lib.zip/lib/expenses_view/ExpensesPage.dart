import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:date_format/date_format.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutx/flutx.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/DateFilterUtil.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/components/privileges/Expenses_privileges.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/BusinessUnitModel.dart';
import 'package:vyaparlive/model/ExpensesDAO.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'dart:convert';

import 'package:vyaparlive/service/organization_service.dart';

class ExpensesView extends StatefulWidget {
  @override
  _ExpensesViewState createState() => _ExpensesViewState();
}

class _ExpensesViewState extends State<ExpensesView> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? buName = "";
  String? buId = "";
  String _date = "Select Date";
  String startDate = "";
  String endDate = "";
  DateFormat formatter = DateFormat("yyyy-MM-dd");
  static DateTime selectedDate = DateTime.now();
  DateTime expensesDate = DateTime.now();

  String todayDate = "";
  final double calendarHeight = 40.0;
  List<ExpensesDAO> expensesList = [];
  final expensesDescriptionController = TextEditingController();
  final expensesAmountController = TextEditingController();
  TimeOfDay selectedTime = TimeOfDay.now();
  String expensesTime = "Selecte Time";
  double totalExpenses = 0.0;
  DateTime mnthStartDate =
      DateTime.utc(DateTime.now().year, DateTime.now().month, 1);
  List<BusinessUnitModel> _buData = [];
  bool isLoadingProgress = true;
  String progressMessage = Constants.GETTING_DATA;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  late OrganizationService _organizationService;
  String convertedDate = "";
  String? orgCurrencySymbol = "";
  ExpensesPrivileges? _expensesPrivileges =
      AppController.instance.getExpensesPrivileges;
  late ThemeData theme;
  late TextEditingController _fromDateController = new TextEditingController();
  late TextEditingController _toDateController = new TextEditingController();
  bool isShowFloatButton = false;
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _organizationService = OrganizationService();
    startDate = formatter.format(mnthStartDate);
    endDate = formatter.format(DateTime.now());
    todayDate = formatter.format(DateTime.now());
    _fromDateController.text = startDate;
    _toDateController.text = endDate;
    buName = AppController.instance.getBuName;
    buId = AppController.instance.getMyBuId;
    convertedDate = AppUtills.getOneDayAddedDate(endDate);
    serviceCallGetExpensesData(dateFrom: startDate, dateTo: endDate);
    // orgCurrencySymbol = AppController.instance.getBuCurrencySymbol;
    String? symbol = AppController.instance.getBuCurrencySymbol;
    orgCurrencySymbol = (symbol != null && symbol.isNotEmpty && symbol!="-") ? symbol : "\u20B9";
  }

  serviceCallGetExpensesData({String dateFrom = "", String dateTo = ""}) async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
      });
      getExpensesData(dateFrom: dateFrom, dateTo: dateTo).then((value) {
        // _buData.addAll(value);
        setState(() {
          expensesList.clear();
          totalExpenses = 0.0;
          if (value.length > 0) {
            expensesList.addAll(value);
            for (int i = 0; i < expensesList.length; i++) {
              // if (expensesList[i].expenseAmount!.isNotEmpty) {
                totalExpenses = totalExpenses +
                    expensesList[i].expenseAmount!;
              // }
            }
          }
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<ExpensesDAO>> getExpensesData(
      {String? dateFrom, String? dateTo}) async {
    expensesList.clear();
    _buData.clear();
    String body = json.encode({
      "id": buId,
      "filters": {
        "DateFrom": _fromDateController.text,
        "DateTo": _toDateController.text
      }
    });

    var response = await _organizationService
        .getExpensesByBuId(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<ExpensesDAO> list = [];

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;

    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      print(resObj);
      if (!CommonMethods.checkResponseType(resObj)) {
        var data = resObj['results'];
        for (var object in data) {
          list.add(ExpensesDAO.fromJson(object));
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return list;
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
        body: Stack(
      children: [
        SafeArea(
          child: Scaffold(
            key: _scaffoldkey,
            backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
            appBar: AppBar(
              backgroundColor: Colors.transparent, //(Constants.APP_COLOR),
              centerTitle: true,
              elevation: 0,
              iconTheme: IconThemeData(color: theme.colorScheme.primary),
              title: AppbarName(
                  title: Language().getString(Constants.EXPENSES, selectedLang),
                  buName: "$buName"),
              actions: [
                if (_expensesPrivileges!.addExpenses)
                  IconButton(
                      icon: Icon(Icons.add),
                      onPressed: () {
                        this.addNewExpense(
                            Language().getString(Constants.ADD, selectedLang),
                            ExpensesDAO());
                      })
              ],
            ),
            floatingActionButton: (isShowFloatButton)
                ? FloatingActionButton(
                    backgroundColor: theme.colorScheme.primary,
                    onPressed: () {
                      setState(() {
                        isShowFloatButton = false;
                        isLoadingProgress = true;
                        // _searchController.clear();
                      });
                      _fromDateController.text = startDate;
                      _toDateController.text = endDate;
                      serviceCallGetExpensesData();
                    },
                    child: Text(
                      Language().getString(Constants.CLEAR_FILTERS, selectedLang),
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 11.0,
                          fontWeight: StyleView.fontSemiBold),
                    ))
                : null,
            // drawer: MyDrawer(),
            body: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Container(
                margin: EdgeInsets.all(5.0),
                child: Column(
                  children: [
                    Container(
                        child: DateFilterUtill(
                      isShowSearchButton: true,
                      fromDate: "",
                      toDate: "",
                      fromDateController: _fromDateController,
                      toDateController: _toDateController,
                      onFromDateSelected: (value) {
                        setState(() => _fromDateController.text = value);
                      },
                      onToDateSelected: (value) {
                        setState(() => _toDateController.text = value);
                      },
                      onSearchParms: () {
                        isShowFloatButton = true;
                        // convertedDate = "";
                        // if (endDate == todayDate) {
                        //   convertedDate = AppUtills.getOneDayAddedDate(endDate);
                        // } else {
                        //   convertedDate = endDate;
                        // }
                        totalExpenses = 0.0;
          
                        serviceCallGetExpensesData();
                      },
                    )),
                    Container(
                      alignment: Alignment.center,
                      margin: EdgeInsets.only(top: 16),
                      child: Card(
                        elevation: 2.5,
                        child: Padding(
                          padding: const EdgeInsets.all(15.0),
                          child: Row(
                            children: [
                              Text(
                                  Language().getString(Constants.TOTAL_EXPENSES,
                                          selectedLang) +
                                      " : ",
                                  style: TextStyle(
                                      color: Color(Constants.APP_COLOR),
                                      fontWeight: FontWeight.bold)),
                              Text(
                                "$orgCurrencySymbol " +
                                    CommonMethods.getCurrencyValues(
                                        totalExpenses),
                                style: TextStyle(
                                    color: Color(Constants.APP_COLOR),
                                    fontSize: 13.0),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                        child: (expensesList.length > 0)
                            ? Container(
                                margin: EdgeInsets.symmetric(vertical: 10.0),
                                decoration: BoxDecoration(
                                    border: Border.all(
                                        color: Color(Constants.APP_COLOR))),
                                child: Column(
                                  children: [
                                    this.designTitlesView(),
                                    Divider(
                                      height: 1.0,
                                      color: Color(Constants.APP_COLOR),
                                    ),
                                    this.designForExpensesData()
                                  ],
                                ),
                              )
                            : Center(
                                child: Text(Language().getString(
                                    Constants.NO_DATA_FOUND, selectedLang)))),
                  ],
                ),
              ),
            ),
          ),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    ));
  }

  designTitlesView() {
    return Container(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Row(
          children: [
            Expanded(
              flex: 1,
              child: Text(
                Language().getString(Constants.DATE_AND_TIME, selectedLang),
                style: TextStyle(
                    color: Color(Constants.APP_COLOR),
                    fontWeight: FontWeight.bold),
              ),
            ),
            Expanded(
              flex: 2,
              child: Text(
                Language()
                    .getString(Constants.DESCRIPTION_STRING, selectedLang),
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: Color(Constants.APP_COLOR),
                    fontWeight: FontWeight.bold),
              ),
            ),
            Expanded(
              child: Text(
                Language().getString(Constants.AMOUNT, selectedLang) +
                    " ( $orgCurrencySymbol ) ",
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: Color(Constants.APP_COLOR),
                    fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
      ),
    );
  }

  designForExpensesData() {
    if (expensesList.length > 0) {
      return Expanded(
          child: ListView.separated(
        shrinkWrap: true,
        separatorBuilder: (context, index) => Divider(
          height: 1.0,
          color: Color(Constants.APP_COLOR),
        ),
        itemBuilder: (context, index) => Padding(
          padding: const EdgeInsets.all(10.0),
          child: InkWell(
            onTap: () {
              if (_expensesPrivileges!.editExpenses) {
                this.addNewExpense(
                    Constants.UPDATE_STRING, expensesList[index]);
              }
            },
            child: Container(
              child: Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: Text(
                      expensesList[index].expensesDate!,
                      style: TextStyle(
                          color: Color(Constants.APP_COLOR), fontSize: 13.0),
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      "${expensesList[index].expenseDescription}",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: Color(Constants.APP_COLOR), fontSize: 13.0),
                    ),
                  ),
                  Expanded(
                    child: Text(
                      // (expensesList[index].expenseAmount!.isNotEmpty)
                          // ? 
                          CommonMethods.getCurrencyValues(
                              (expensesList[index].expenseAmount!)),
                          // : "",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: Color(Constants.APP_COLOR), fontSize: 13.0),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        itemCount: expensesList.length,
      ));
    } else {
      return Container();
    }
  }

  deleteExpenses(String? expensesId) async {
    String body = json.encode({"id": buId, "expense_id": expensesId});

    var response = await _organizationService
        .deleteOrgExpenses(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      this.serviceCallGetExpensesData(dateFrom: startDate, dateTo: endDate);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  addNewExpense(String? type, ExpensesDAO expensesData) {
    if (type == Constants.UPDATE_STRING) {
      List<String> splitText = expensesData.expensesDate!.split(" ");

      _date = splitText[0];
      expensesTime = splitText[1];
      expensesAmountController.text = expensesData.expenseAmount!.toString();
      expensesDescriptionController.text = expensesData.expenseDescription!;
    } else {
      _date = formatter.format(DateTime.now());
      selectedTime = TimeOfDay.now();
      expensesTime = formatDate(
          DateTime(2019, 08, 1, selectedTime.hour, selectedTime.minute),
          [hh, ':', nn, " ", am]).toString();
      expensesAmountController.clear();
      expensesDescriptionController.clear();
    }
    return showDialog(
        context: context,
        barrierColor: Colors.black54,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
            elevation: 100.0,
            contentPadding: EdgeInsets.fromLTRB(15.0, 10.0, 10.0, 10.0),
            backgroundColor: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(
                Radius.circular(7.0),
              ),
            ),
            actions: [
              Container(
                width: MediaQuery.of(context).size.width,
                padding: EdgeInsets.symmetric(vertical: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            backgroundColor: theme.colorScheme.primary,
                            elevation: 0),
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                        child: Text(
                            Language()
                                .getString(Constants.STR_CANCEL, selectedLang),
                            style: TextStyle(
                              color: Colors.white,
                            ))),
                    (type == Constants.UPDATE_STRING &&
                            _expensesPrivileges!.deleteExpenses)
                        ? ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.red, elevation: 0),
                            onPressed: () {
                              Navigator.of(context).pop();
                              showDeleteDialog(context, expensesData);
                            },
                            child: Text(
                              Language().getString(
                                  Constants.DELETE_STRING, selectedLang),
                              style: TextStyle(color: Colors.white),
                            ))
                        : Container(),
                    ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            backgroundColor: theme.colorScheme.primary,
                            elevation: 0),
                        onPressed: () async {
                          Navigator.of(context).pop();
                          if (type == Constants.UPDATE_STRING) {
                            if (await NetworkStatus.getInternetStatus()) {
                              setState(() {
                                isLoadingProgress = true;
                                progressMessage = Constants.UPDATING;
                              });
                              this.serviceCallUpdateExpenses(
                                  expensesData.expId);
                            } else {
                              AppUtills.showSnackBar(
                                  _scaffoldkey,
                                  Language().getString(
                                      Constants.NO_INTERNET, selectedLang),
                                  snackBarBgColor: Colors.black,
                                  messageColor: Colors.white,
                                  buttonColor: Colors.white);
                            }
                          } else {
                            if (await NetworkStatus.getInternetStatus()) {
                              setState(() {
                                isLoadingProgress = true;
                                progressMessage = Constants.CREATING;
                              });
                              this.serviceCallForAddExpenses();
                            } else {
                              AppUtills.showSnackBar(
                                  _scaffoldkey,
                                  Language().getString(
                                      Constants.NO_INTERNET, selectedLang),
                                  snackBarBgColor: Colors.black,
                                  messageColor: Colors.white,
                                  buttonColor: Colors.white);
                            }
                          }
                        },
                        child: Text(
                          Language()
                              .getString(Constants.STR_SAVE, selectedLang),
                          style: TextStyle(
                            color: Colors.white,
                          ),
                        ))
                  ],
                ),
              ),
            ],
            title: Text(
              Language().getString(Constants.ADD_EXPENSES, selectedLang),
              style: TextStyle(color: Colors.black, fontSize: 18.0),
            ),
            content: StatefulBuilder(
                builder: (BuildContext context, StateSetter setState) {
              return SingleChildScrollView(
                child: Column(
                  children: [
                    FxSpacing.height(10),
                    this.designForDateAndTime(setState),
                    FxSpacing.height(10),
                    this.expensesAmount(),
                    FxSpacing.height(10),
                    this.expensesDescription()
                  ],
                ),
              );
            })));
  }

  showDeleteDialog(context, ExpensesDAO expensesData) {
    return showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) {
          return AlertDialog(
            title: Text(Language().getString(Constants.WARNING, selectedLang)),
            content: Text(Language().getString(
                Constants.ARE_YOU_SURE_DO_YOU_WANT_REMOVE, selectedLang)),
            actions: [
              Container(
                width: MediaQuery.of(context).size.width,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    TextButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                        child: Text(
                          Constants.STR_CANCEL,
                          style: TextStyle(
                              fontSize: 18.0,
                              color: Color(Constants.APP_COLOR)),
                        )),
                    TextButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                          this.deleteExpenses(expensesData.expId);
                        },
                        child: Text(
                          Constants.YES_STRING,
                          style: TextStyle(
                              fontSize: 18.0,
                              color: Color(Constants.APP_COLOR)),
                        ))
                  ],
                ),
              )
            ],
          );
        });
  }

  expensesDescription() {
    return Container(
      padding: EdgeInsets.all(5.0),
      child: TextFormField(
        minLines: 5,
        maxLines: 5,
        controller: expensesDescriptionController,
        decoration: InputDecoration(
            border: OutlineInputBorder(),
            isDense: true,
            contentPadding: EdgeInsets.fromLTRB(5.0, 10.0, 0.0, 10.0),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.all(Radius.circular(10.0)),
              borderSide: BorderSide(color: Colors.grey),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.all(Radius.circular(10.0)),
              borderSide: BorderSide(color: Colors.grey),
            ),
            labelText: Language()
                .getString(Constants.DESCRIPTION_STRING, selectedLang)),
      ),
    );
  }

  expensesAmount() {
    return Container(
        margin: EdgeInsets.symmetric(vertical: 10.0),
        height: 50.0,
        padding: EdgeInsets.all(5.0),
        child: TextField(
          controller: expensesAmountController,
          decoration: StyleView.getInputDecoration(
              helper: Language().getString(Constants.AMOUNT, selectedLang) +
                  " ( $orgCurrencySymbol ) "),
          keyboardType: TextInputType.numberWithOptions(decimal: true),
          inputFormatters: [
            FilteringTextInputFormatter.allow(RegExp("[0-9.]")),
          ],
        ));
  }

  designForDateAndTime(StateSetter setState) {
    return Container(
        child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Container(
          height: 40.0,
          padding: EdgeInsets.all(5),
          decoration: AppUtills.boxDecoration(),
          child: Row(
            children: [
              Container(
                child: Text(
                  "$_date",
                  style: TextStyle(
                    fontSize: 13.0,
                    color: Color(Constants.APP_COLOR),
                  ),
                ),
              ),
              InkWell(
                onTap: () async {
                  final DateTime? picked = await showDatePicker(
                      context: context,
                      initialDate: expensesDate,
                      firstDate: DateTime(1990),
                      lastDate: DateTime(2222));
                  if (picked != null)
                    setState(() {
                      expensesDate = picked;
                      _date = formatter.format(expensesDate);
                    });
                },
                child: Container(
                  child: Icon(Icons.calendar_today, color: Colors.blue),
                ),
              )
            ],
          ),
        ),
        Container(
          height: 40.0,
          decoration: AppUtills.boxDecoration(),
          padding: EdgeInsets.all(5),
          child: Row(
            children: [
              Container(
                child: Text(
                  "$expensesTime",
                  style: TextStyle(
                    fontSize: 13.0,
                    color: Color(Constants.APP_COLOR),
                  ),
                ),
              ),
              InkWell(
                onTap: () async {
                  final TimeOfDay? picked = await showTimePicker(
                    context: context,
                    initialTime: selectedTime,
                  );
                  if (picked != null) {
                    setState(() {
                      selectedTime = picked;

                      expensesTime = formatDate(
                          DateTime(2019, 08, 1, selectedTime.hour,
                              selectedTime.minute),
                          [hh, ':', nn, " ", am]).toString();
                    });
                  }
                },
                child: Container(
                  child: Icon(Icons.access_time, color: Colors.blue),
                ),
              )
            ],
          ),
        )
      ],
    ));
  }

  dateFilterView() {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 5.0),
      decoration: BoxDecoration(
          color: Colors.grey,
          border: Border.all(
            color: Colors.grey,
          ),
          borderRadius: BorderRadius.circular(
            5.0,
          )),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
              flex: 2,
              child: Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      flex: 2,
                      child: Container(
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(
                                  5.0,
                                ),
                                bottomLeft: Radius.circular(5.0))),
                        height: calendarHeight,
                        alignment: Alignment.centerLeft,
                        child: Padding(
                          padding: const EdgeInsets.all(5.0),
                          child: Text(startDate),
                        ),
                      ),
                    ),
                    Expanded(
                      child: Container(
                        height: calendarHeight,
                        color: Colors.white,
                        child: IconButton(
                            icon: Icon(
                              Icons.calendar_today,
                              color: Colors.blue,
                            ),
                            onPressed: () async {
                              final DateTime? picked = await showDatePicker(
                                  context: context,
                                  initialDate: selectedDate,
                                  firstDate: DateTime(1990),
                                  lastDate: DateTime(2222));
                              if (picked != null && picked != selectedDate) {
                                setState(() {
                                  selectedDate = picked;
                                  startDate = formatter.format(selectedDate);
                                });
                              }
                            }),
                      ),
                    ),
                  ],
                ),
              )),
          SizedBox(
            height: calendarHeight,
            width: 1.0,
            child: Container(
              color: Colors.grey,
            ),
          ),
          Expanded(
              flex: 2,
              child: Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      flex: 2,
                      child: Container(
                        alignment: Alignment.centerLeft,
                        height: calendarHeight,
                        color: Colors.white,
                        child: Padding(
                          padding: const EdgeInsets.all(5.0),
                          child: Text(endDate),
                        ),
                      ),
                    ),
                    Expanded(
                      child: Container(
                        color: Colors.white,
                        height: calendarHeight,
                        child: IconButton(
                            icon: Icon(
                              Icons.calendar_today,
                              color: Colors.blue,
                            ),
                            onPressed: () async {
                              final DateTime? picked = await showDatePicker(
                                  context: context,
                                  initialDate: selectedDate,
                                  firstDate: DateTime(1990),
                                  lastDate: DateTime(2222));
                              if (picked != null && picked != selectedDate) {
                                setState(() {
                                  selectedDate = picked;
                                  endDate = formatter.format(selectedDate);
                                });
                              }
                            }),
                      ),
                    ),
                  ],
                ),
              )),
          Expanded(
            child: InkWell(
              child: Container(
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                        topRight: Radius.circular(
                          5.0,
                        ),
                        bottomRight: Radius.circular(5.0))),
                height: calendarHeight,
                child: Icon(Icons.search),
              ),
            ),
          )
        ],
      ),
    );
  }

  serviceCallUpdateExpenses(String? expensesId) async {
    Map data = {
      "expense_date": _date + " " + expensesTime,
      "expense_description": expensesDescriptionController.text,
      "expense_amount": expensesAmountController.text,
      "expense_id": expensesId,
      "id": buId
    };
    String body = json.encode(data);

    var response = await _organizationService
        .updateOrgExpenses(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      this.serviceCallGetExpensesData(dateFrom: startDate, dateTo: endDate);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  serviceCallForAddExpenses() async {
    Map data = {
      "expense_date": _date + " " + expensesTime,
      "expense_description": expensesDescriptionController.text,
      "expense_amount": expensesAmountController.text,
      "id": buId
    };
    String body = json.encode(data);

    var response = await _organizationService
        .addOrgExpenses(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      this.serviceCallGetExpensesData(dateFrom: startDate, dateTo: endDate);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }
}
