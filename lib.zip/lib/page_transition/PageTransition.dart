import 'package:flutter/material.dart';

class PageTransition extends PageRouteBuilder {
  final Widget? page;
  final BuildContext? context;
  PageTransition({this.page, this.context})
      : super(
            pageBuilder: (context, animation, anotherAnimation) {
              return page!;
            },
            transitionDuration: Duration(milliseconds: 1500),
            transitionsBuilder: (context, animation, anotherAnimation, child) {
              animation = CurvedAnimation(
                  curve: Curves.fastOutSlowIn, parent: animation);
              return Align(
                child: SizeTransition(
                  sizeFactor: animation,
                  child: child,
                  axisAlignment: 0.0,
                ),
              );
            });
}
