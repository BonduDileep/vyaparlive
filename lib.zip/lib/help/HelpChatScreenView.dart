import 'dart:async';

import 'package:vyaparlive/Transaction/discussion_product_view/message_card.dart';
import 'package:vyaparlive/service/user_services.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:flutter/material.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';

import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/Chat.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/TransactionsModel.dart';
import 'package:vyaparlive/model/UserModel.dart';
import 'package:vyaparlive/service/bu_list_grpc_service.dart';
import 'dart:convert';
// import 'package:socket_io_client/socket_io_client.dart' as io;
import 'package:vyaparlive/utills/SharePref.dart';

import '../Transaction/buyer/DiscussionView.dart';

class HelpChatScreenView extends StatefulWidget {
  final String? chatId;
  final String? transactionName;
  final String? firebaseToken;
  final bool isFromTransaction;
  HelpChatScreenView(
      {this.chatId,
      this.transactionName,
      this.firebaseToken,
      this.isFromTransaction = false});
  @override
  _HelpChatScreenViewState createState() => _HelpChatScreenViewState();
}

class _HelpChatScreenViewState extends State<HelpChatScreenView>
    with TickerProviderStateMixin {
  final TextEditingController _textController = new TextEditingController();
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  late AnimationController animationController;
  ScrollController? _scrollController;
  List<ChatMessage> _messages = [];
  List<ChatMessage> confirmationMsgList = [];
  var dbHelper;
  Future<List<Chat>>? messages;
  Future<List<Chat>>? startmessages;
  List<Chat>? discussionsList;
  String? selectedLang = AppController.instance.getSelectedlanguage; // 'en';
  late SharedPreferences sharedPreferences;
  String? buId = "";
  bool isMsgItemSelected = false;
  var productsData = [];
  Timer? timer;
  String? buyerName = "";
  String? sellerName = "";
  String? buName = "";
  TransactionsModel? transactionDetails;
  // io.Socket? socket;
  String? organizationId = "";
  UserModel? userData;
  String? transactionUserId = "";
  String? userName = "";
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  bool _isClientTyping = false;
  String? _typingClientId;
  late BuListGrpcService _transactionService;
  late UserService _userService;
  bool isBuyerSellerAccepted = false;
  late ThemeData theme;

  List<String> _structuredMessageList = [
    "Need help in adding products",
    "Need help in Generating Invoices",
    "Need help in B2B wholesale features",
    "Need help in seeing reports",
    "Need help in Subscription payment",
    "Others"
  ];
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _transactionService = BuListGrpcService();
    _userService = UserService();
    buId = AppController.instance.getMyBuId;
    buName = AppController.instance.getBuName;
    SharePref().getUserName().then((value) {
      setState(() {
        userName = value;
      });
    });
    _scrollController = ScrollController();
    // animationController = new AnimationController(
    //     vsync: this, duration: new Duration(milliseconds: 1000));
    _scrollToBottom();
    // loadTransactionData();
    // initSocket();
    getSupportMessages();
  }

  getSupportMessages() async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = Constants.GETTING_DATA;
    });
    Map data = {"bu": buId};
    String body = json.encode(data);
    var response = await _userService
        .getMessages_grpc(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      setState(() {
        isLoadingProgress = false;
        var data = json.decode(_grpcResponse.message!);
        if (data != null && data.length > 0) {
          for (var item in data) {
            List<dynamic> message = item['message'];
            for (var msgItem in message) {
              dynamic user_item = {
                "_id": msgItem['_id'],
                "message": msgItem['user'],
                "bu_id": item['bu'],
                "user_name": AppController.instance.getBuName
              };
              ChatMessage user_message = new ChatMessage(
                messageData: user_item,
                isSelected: false,
                animationController: new AnimationController(
                  vsync: this,
                  duration: new Duration(milliseconds: 1000),
                ),
              );
              _messages.add(user_message);
              user_message.animationController!.forward();
              dynamic admin_item = {
                "_id": msgItem['_id'],
                "message": msgItem['admin'],
                "bu_id": 'admin',
                "user_name": 'Admin'
              };
              ChatMessage admin_message = new ChatMessage(
                messageData: admin_item,
                isSelected: false,
                animationController: new AnimationController(
                  vsync: this,
                  duration: new Duration(milliseconds: 1000),
                ),
              );
              _messages.add(admin_message);
              admin_message.animationController!.forward();
            }
            // dynamic message_item = {
            //   "_id": item['_id'],
            //   "message": item['message'],
            //   "bu_id": item['bu'],
            //   "user_name": buId == item['bu']
            //       ? AppController.instance.getBuName
            //       : "Admin"
            // };
            // ChatMessage message = new ChatMessage(
            //   messageData: message_item,
            //   isSelected: false,
            //   animationController: new AnimationController(
            //     vsync: this,
            //     duration: new Duration(milliseconds: 1000),
            //   ),
            // );
            // _messages.add(message);
            // message.animationController!.forward();
          }
          Timer(Duration(seconds: 1), _scrollToBottom);
        }
      });
    } else {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  // void initSocket() async {
  //   socket = io.io('${Constants.CHAT_COMMUNICATION_URL}', <String, dynamic>{
  //     'autoConnect': true,
  //     'transports': ['websocket']
  //   });

  //   socket!.on('connect', (_) {
  //     print("socket connected:");
  //     sendJoinChat();
  //   });

  //   socket!.on('error', (error) {
  //     print('error');
  //     print(error);
  //   });

  //   print("socket.connected:${socket!.connected}");

  //   socket!.on('msgReceive', (data) {
  //     var value = json.decode(data);
  //     if (value['type'] == 'typing') {
  //       setState(() {
  //         _isClientTyping = true;
  //         _typingClientId = value['sender_id'];
  //       });
  //       Future.delayed(Duration(seconds: 2)).then((value) {
  //         setState(() {
  //           _isClientTyping = false;
  //           _typingClientId = null;
  //         });
  //       });
  //     } else {
  //       _onReceiveMessage(data);
  //     }
  //   });
  // }

  // _unSubscribes() {
  //   if (socket != null) {
  //     socket!.disconnect();
  //   }
  // }

  // void sendJoinChat() {
  //   socket!.emit("joinChat", widget.chatId);
  // }

  // void _onReceiveMessage(msg) {
  //   var data = json.decode(msg);

  //   data['id'] = _messages.length;

  //   ChatMessage _message = new ChatMessage(
  //     messageData: data,
  //     isSelected: false,
  //     animationController: new AnimationController(
  //       vsync: this,
  //       duration: new Duration(milliseconds: 1000),
  //     ),
  //   );
  //   setState(() {
  //     _messages.add(_message);
  //   });
  //   Timer(Duration(seconds: 1), _scrollToBottom);

  //   if (data.containsKey('order_status') && data['order_status'] == 'success') {
  //     Navigator.of(context).pop();
  //   }
  // }

  _sendMessage({String type = "TEXT", String message = ''}) async {
    var messageObject = json.decode(message);
    var messageMap = Map<String, Object?>();
    //   messageMap['sender_id'] = AppController.instance.myBuId;

    messageMap['message'] = messageObject["message"];
    messageMap['bu_id'] = messageObject["bu_id"];

    //   messageMap['chat_id'] = widget.chatId;
    //   messageMap['type'] = type;

    messageMap['user_name'] = buName;
    messageMap['message_date'] = DateTime.now().toUtc().toString();
    messageObject['user_name'] = buName;
    messageObject['message_date'] = messageMap['message_date'];
    //   messageObject['type'] = type;
    messageObject['id'] = _messages.length;

    //   String jsonString = json.encode(messageMap);

    //   socket!.emit('new_message', jsonString);

    ChatMessage _message = new ChatMessage(
      messageData: messageObject,
      isSelected: false,
      animationController: new AnimationController(
        vsync: this,
        duration: new Duration(milliseconds: 1000),
      ),
    );
    setState(() {
      _messages.add(_message);
    });

    _scrollToBottom();
  }

  @override
  void dispose() {
    // for (ChatMessage message in _messages)
    //   message.animationController!.dispose();
    // // _unSubscribes();
    _scrollController!.dispose();
    // animationController.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    if (!mounted) return; // avoid updates after dispose

    if (_scrollController?.hasClients ?? false) {
      _scrollController!.animateTo(
        _scrollController!.position.maxScrollExtent,
        duration: const Duration(seconds: 1),
        curve: Curves.fastOutSlowIn,
      );
    } else {
      // schedule once, not infinite recursion
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _scrollToBottom();
      });
    }
  }

  chatTyping() {
    var messageMap = Map<String, Object?>();
    messageMap['sender_id'] = AppController.instance.myBuId;
    messageMap['chat_id'] = widget.chatId;
    messageMap['type'] = 'typing';
    String jsonString = json.encode(messageMap);
    // socket!.emit('new_message', jsonString);
  }

  showStructureMessagePopup(String messagesFrom) {
    return showDialog(
      context: context,
      barrierColor: Colors.black54,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        elevation: 100.0,
        contentPadding: EdgeInsets.fromLTRB(15.0, 0, 15.0, 0),
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(
            Radius.circular(7.0),
          ),
        ),
        titlePadding: EdgeInsets.fromLTRB(17.0, 10.0, 10.0, 10.0),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              Language().getString(Constants.INFO_MESSAGES, selectedLang),
              style: TextStyle(
                fontSize: 17.0,
                color: theme.colorScheme.primary,
              ),
            ),
            IconButton(
                icon: Icon(
                  Icons.close,
                  color: Colors.red,
                ),
                onPressed: () {
                  Navigator.of(context).pop();
                })
          ],
        ),
        content: Container(
            height: MediaQuery.of(context).size.height,
            child: showStockStructureMessages(messagesFrom)),
      ),
    );
  }

  showStockStructureMessages(String messagesFrom) {
    return SingleChildScrollView(
      child: Column(
        children: [
          for (int index = 0; index < _structuredMessageList.length; index++)
            InkWell(
              onTap: () async {
                Navigator.of(context).pop();
                if (await NetworkStatus.getInternetStatus()) {
                  _handleSubmitted('${_structuredMessageList[index]}',
                      "STRUCTURE_MESSAGE", buId!);
                  botMessage(
                      'Thanks for contacting support team. We will get back to you shortly.');
                } else {
                  AppUtills.showSnackBar(_scaffoldkey,
                      Language().getString(Constants.NO_INTERNET, selectedLang),
                      snackBarBgColor: Colors.black,
                      messageColor: Colors.white,
                      buttonColor: Colors.white);
                }
              },
              child: Card(
                elevation: 2.5,
                child: ListTile(
                  title: Text(
                    _structuredMessageList[index],
                    style: TextStyle(
                        color: theme.colorScheme.primary, fontSize: 15),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  _buildTextComposer() {
    return Container(
      padding: EdgeInsets.only(left: 15.0),
      child: Row(
        children: <Widget>[
          InkWell(
            onTap: () {
              this.showStructureMessagePopup("");
            },
            child: Container(
              child: Icon(Icons.more_vert, color: theme.colorScheme.primary),
            ),
          ),
          SizedBox(width: 10.0),
          Flexible(
            child: new TextField(
                textInputAction: TextInputAction.done,
                controller: _textController,
                onChanged: ((value) {
                  setState(() {
                    chatTyping();
                    _isClientTyping = true;
                  });
                }),
                minLines: 1,
                maxLines: 5,
                decoration: new InputDecoration.collapsed(
                    hintStyle: TextStyle(color: Colors.black, fontSize: 14.0),
                    hintText: Language().getString(
                        Constants.SEND_A_MESSAGE_STRING, selectedLang))),
          ),
          new Container(
            child: new IconButton(
                icon: new Icon(
                  FeatherIcons.send,
                  size: 19.0,
                  color: theme.colorScheme.primary,
                ),
                onPressed: () async {
                  if (await NetworkStatus.getInternetStatus()) {
                    this._handleSubmitted(_textController.text, "TEXT", buId!);
                    botMessage(
                        'Thanks for contacting support team. We will get back to you shortly.');
                  } else {
                    AppUtills.showSnackBar(
                        _scaffoldkey,
                        Language()
                            .getString(Constants.NO_INTERNET, selectedLang),
                        snackBarBgColor: Colors.black,
                        messageColor: Colors.white,
                        buttonColor: Colors.white);
                  }
                }),
          )
        ],
      ),
    );
  }

  validate(text) {
    bool isValid = false;
    if (text == '') {
      isValid = false;
    } else {
      isValid = true;
    }
    return isValid;
  }

  updateChat(var data) {
    ChatMessage message = new ChatMessage(
      messageData: data,
      isSelected: false,
      animationController: new AnimationController(
        vsync: this,
        duration: new Duration(milliseconds: 1000),
      ),
    );
    setState(() {
      _messages.add(message);
    });
    message.animationController!.forward();
  }

  void botMessage(String text) {
    var message_item = {
      "_id": DateTime.now().millisecondsSinceEpoch.toString(),
      "message": text,
      "bu_id": "bot",
      "user_name": "Support"
    };
    ChatMessage message = new ChatMessage(
      messageData: message_item,
      isSelected: false,
      animationController: new AnimationController(
        vsync: this,
        duration: new Duration(milliseconds: 1000),
      ),
    );
    setState(() {
      _messages.add(message);
    });
    message.animationController!.forward();
    _scrollToBottom();
  }

  // We can use controller to clear text after submitting
  void _handleSubmitted(String text, String messageType, String _buId) async {
    if (!validate(text)) {
      return;
    }
    _sendMessage(
        type: messageType,
        message: json.encode({"bu_id": _buId, "message": text}));
    _textController.clear();
    _scrollToBottom();
    Map data = {"bu": _buId, "message": text};

    String body = json.encode(data);
    var response = await _userService
        .sendSupportMessage(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }

    // }
  }

  Widget _messagesListView() {
    return Expanded(
      child: (_messages.length > 0)
          ? Container(
              child: ListView(
                controller: _scrollController,
                physics: new BouncingScrollPhysics(
                    parent: AlwaysScrollableScrollPhysics()),
                shrinkWrap: true,
                children: <Widget>[
                  for (int i = 0; i < _messages.length; i++)
                    // designMessageType(_messages[i])
                    MessageCardView(
                        chatMessage: _messages[i],
                        onPressSend: () {},
                        userName: "$buName",
                        onPressReceive: () {},
                        buId: "$buId")
                ],
              ),
            )
          : Center(
              child: Text(
                Language().getString(Constants.NO_DATA_FOUND, selectedLang),
              ),
            ),
    );
  }

  Future<bool> onBackPress() async {
    CommonMethods.hideKeyboard(context);
    Navigator.of(context).pop();
    return false;
  }

  Widget _showTypingIndicator() {
    if (_isClientTyping &&
        _typingClientId != null &&
        (_typingClientId != AppController.instance.getMyBuId)) {
      return Container(
          color: Colors.transparent,
          alignment: Alignment.centerLeft,
          padding: const EdgeInsets.all(10.0),
          child: Text(Language().getString(Constants.STR_TYPING, selectedLang),
              style: TextStyle(
                fontSize: 15.0,
                color: theme.colorScheme.primary,
              )));
    } else {
      return SizedBox();
    }
  }

  Widget _buildBody() {
    return Column(
      children: <Widget>[
        _messagesListView(),
        _showTypingIndicator(),
        SizedBox(height: 5.0),
        Container(
          margin: EdgeInsets.only(left: 10.0, right: 10.0, bottom: 10.0),
          child: _buildTextComposer(),
          decoration: new BoxDecoration(
              color: theme.colorScheme.primaryContainer,
              borderRadius: BorderRadius.circular(30.0)),
        ),
      ],
    );
  }

  // @override
  // void setState(VoidCallback fn) {
  //   if (mounted) {
  //     super.setState(fn);
  //   }
  // }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      child: Stack(
        children: [
          SafeArea(
            child: Scaffold(
                key: _scaffoldkey,
                appBar: AppBar(
                    iconTheme: IconThemeData(color: theme.colorScheme.primary),
                    centerTitle: true,
                    elevation: 0.0,
                    leading: IconButton(
                        icon: Icon(
                          Icons.arrow_back,
                          color: theme.colorScheme.primary,
                        ),
                        onPressed: () async {
                          this.onBackPress();
                        }),
                    title: AppbarName(
                        title: Language()
                            .getString(Constants.STR_SUPPORT, selectedLang),
                        buName: "${buName ?? ""}"),
                    actions: [
                      AppUtills.homeButton(context),
                    ],
                    backgroundColor: Colors.transparent //(Constants.APP_COLOR),
                    ),
                backgroundColor:
                    Colors.white, //(Constants.APP_BACKGROUND_COLOR),
                body: _buildBody()),
          ),
          AppUtills.showLoadingView(
              context: context,
              message: Language().getString(progressMessage, selectedLang),
              isLoading: isLoadingProgress),
        ],
      ),
      onWillPop: onBackPress,
    );
  }
}
