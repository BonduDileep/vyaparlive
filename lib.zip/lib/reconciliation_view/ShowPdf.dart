import 'dart:async';
import 'package:flutter/material.dart';
import 'package:pdfx/pdfx.dart';
import 'package:vyaparlive/components/Constants.dart';

class ShowPdfPage extends StatefulWidget {
  final String? path;

  const ShowPdfPage({Key? key, this.path}) : super(key: key);

  @override
  State<ShowPdfPage> createState() => _ShowPdfPageState();
}

class _ShowPdfPageState extends State<ShowPdfPage> {
  late PdfControllerPinch _pdfController;

  @override
  void initState() {
    super.initState();
    _pdfController = PdfControllerPinch(
      document: PdfDocument.openFile(widget.path!),
    );
  }

  @override
  void dispose() {
    _pdfController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
        appBar: AppBar(
          backgroundColor: Color(Constants.APP_COLOR),
          title: const Text("PDF View"),
          centerTitle: true,
        ),
        body: PdfViewPinch(
          controller: _pdfController,
          onDocumentError: (error) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text("Error loading PDF: $error")),
            );
          },
        ),
      ),
    );
  }
}


// import 'dart:async';

// import 'package:flutter/material.dart';
// import 'package:flutter_pdfview/flutter_pdfview.dart';
// import 'package:vyaparlive/components/Constants.dart';

// class ShowPdfPage extends StatefulWidget {
//   final String? path;

//   ShowPdfPage({Key? key, this.path}) : super(key: key);

//   _ShowPdfPageState createState() => _ShowPdfPageState();
// }

// class _ShowPdfPageState extends State<ShowPdfPage> with WidgetsBindingObserver {
//   final Completer<PDFViewController> _controller =
//       Completer<PDFViewController>();
//   int? pages = 0;
//   int? currentPage = 0;
//   bool isReady = false;
//   String errorMessage = '';

//   @override
//   Widget build(BuildContext context) {
//     return SafeArea(
//       child: Scaffold(
//         backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
//         appBar: AppBar(
//           backgroundColor: Color(Constants.APP_COLOR),
//           title: Text("PDF View"),
//           centerTitle: true,
//         ),
//         body: Stack(
//           children: <Widget>[
//             PDFView(
//               filePath: widget.path,
//               enableSwipe: true,
//               swipeHorizontal: false,
//               autoSpacing: false,
//               pageFling: true,
//               pageSnap: true,
//               defaultPage: currentPage!,
//               fitPolicy: FitPolicy.BOTH,
//               preventLinkNavigation: false,
//               onRender: (_pages) {
//                 setState(() {
//                   pages = _pages;
//                 });
//               },
//               onError: (error) {
//                 setState(() {
//                   errorMessage = error.toString();
//                 });
//               },
//               onPageError: (page, error) {
//                 setState(() {
//                   errorMessage = '$page: ${error.toString()}';
//                 });
//               },
//               onViewCreated: (PDFViewController pdfViewController) {
//                 _controller.complete(pdfViewController);
//               },
//               onPageChanged: (int? page, int? total) {
//                 print('page change: $page/$total');
//                 setState(() {
//                   currentPage = page;
//                 });
//               },
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
