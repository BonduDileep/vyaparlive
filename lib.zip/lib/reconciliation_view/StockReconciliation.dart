import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:vyaparlive/core/enums/privilleges_enum.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Transaction/buyer/DiscussionView.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/TransactionDetailsView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/invoice_view/InvoiceDesingView.dart';
import 'package:vyaparlive/model/Chat.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/InvoiceDAO.dart';
import 'package:vyaparlive/model/StructuredDAO.dart';
import 'package:vyaparlive/model/TransactionsModel.dart';
import 'package:vyaparlive/model/transaction/InvoiceDataDAO.dart';
import 'package:vyaparlive/model/transaction/InvoiceDetailsModel.dart';
import 'package:vyaparlive/model/transaction/ReconciliationModel.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:vyaparlive/service/Service.dart';
import 'package:vyaparlive/service/bu_list_grpc_service.dart';
import 'package:socket_io_client/socket_io_client.dart' as io;
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:vyaparlive/utills/SharePref.dart';

class StockReconciliationPage extends StatefulWidget {
  StockReconciliationPage(
      {this.transactionId,
      this.transactionName,
      this.invoiceNo,
      this.resolution,
      this.invoiceId});

  final String? transactionName;
  final String? invoiceNo;
  final String? resolution;
  final String? transactionId;
  final String? invoiceId;

  @override
  _StockReconciliationPageState createState() =>
      _StockReconciliationPageState();
}

class _StockReconciliationPageState extends State<StockReconciliationPage>
    with TickerProviderStateMixin {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  static const String PRODUCT_REPLACEMENT = "Product Replacement";
  static const String PAYMENT_ADJUSTMENT = "Payment Adjustment";
  String? radioButtonValue;
  DateFormat formatter = DateFormat("d-MM-yyyy");
  String? dropDownValue;
  List<ChatMessage> _messages = [];
  Future<List<Chat>>? messages;
  final _textController = TextEditingController();
  late AnimationController animationController;
  ScrollController? _scrollController;
  bool showCapturedPhoto = false;
  var imagePath;
  bool cameraPriviewShow = false;
  List<TransactionsModel> _transactionsList = [];
  final _returenedTextController = TextEditingController();
  bool isProductReplacement = false;
  File? imageFile;
  String imageBlob = '';
  var dbHelper;
  String? buName = "";
  String? buId = "";
  late Service _service;
  bool isLoading = false;
  List<InvoiceDetails?> _invoiceList = [];
  List<bool> isItemChecked = [];
  List<InvoiceDAO> _invoiceMsgData = [];
  bool isCtrTransaction = false;
  io.Socket? socket;
  List<StructuredDAO> _structuredMessageList = [];
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  String? userName = "";
  String? message = "";
  int imageValue = 0;
  late BuListGrpcService _transactionService;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  List<Map> _namesData = [];
  Uint8List? _webImage;
  final String imageName = "stock_reconciliation_web.png";
  String? relativePath = "";
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    this.getLoadLanguage();
    _transactionService = BuListGrpcService();
    _scrollController = ScrollController();
    SharePref().getUserName().then((value) {
      setState(() {
        userName = value;
      });
    });
    animationController = new AnimationController(
        vsync: this, duration: new Duration(milliseconds: 700));

    // messageList();
    buName = AppController.instance.getBuName;
    buId = AppController.instance.getMyBuId;
    _service = Service();

    loadTransactionData();

    /// Service call for get structured messages
    getStructureMessages();
  }

  getLoadLanguage() {
    _namesData = [
      {"name": Language().getString(Constants.NAME_STRING, selectedLang)},
      {"name": Language().getString(Constants.TXN_ID, selectedLang)},
      {"name": Language().getString(Constants.TXN_INITIATED_DATE, selectedLang)}
    ];
  }

  getStructureMessages() async {
    if (await NetworkStatus.getInternetStatus()) {
      serviceCallGetStructuredMessages().then((value) {
        setState(() {
          _structuredMessageList.addAll(value);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  loadTransactionData() async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
      });
      await getInvoiceData().then((value) {
        _invoiceList.clear();
        if (value.length > 0) {
          setState(() {
            _invoiceList.add(value[0].invoiceDetails);
            if (_invoiceList[0]!.invoiceType == Constants.CTR3) {
              setState(() {
                isCtrTransaction = true;
              });

              if (_invoiceList[0]!.ctrTransactionDetails != null) {
                initSocket();
              }
            } else {
              if (_invoiceList[0]!.orderTrackDetails != null) {
                initSocket();
              }
            }
          });
        }
      });
      await this.getAllDiscussionData().then((value) {
        _transactionsList.addAll(value);
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  @override
  void dispose() {
    for (ChatMessage message in _messages)
      message.animationController!.dispose();
    _scrollController!.dispose();
    _unSubscribes();
    animationController.dispose();
    super.dispose();
  }

  @override
  void setState(VoidCallback fn) {
    // TODO: implement setState
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
        body: Stack(
      children: [
        SafeArea(
          child: Scaffold(
              key: _scaffoldkey,
              backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
              appBar: AppBar(
                backgroundColor: Colors.transparent, //Color(Constants.APP_COLOR),
                centerTitle: true,
                elevation: 0,
                iconTheme: IconThemeData(color: theme.colorScheme.primary),
                title: AppbarName(
                    title: Language()
                        .getString(Constants.STOCK_RECONCILIATION, selectedLang),
                    buName: "$buName"),
                actions: [
                  AppUtills.homeButton(context),
                ],
              ),
              body: (_invoiceList.length == 0 && _transactionsList.length == 0)
                  ? Container(
                      decoration: AppUtills.appBackgroundWithImage(),
                      child: Center(
                          child: Text(Language().getString(
                              Constants.YOUR_ORDER_IS_BEING_PROCESS,
                              selectedLang))))
                  : SingleChildScrollView(
                      padding: EdgeInsets.all(5.0),
                      child: ConstrainedBox(
                        constraints: BoxConstraints(
                            maxHeight: MediaQuery.of(context).size.height / 1.2),
                        child: Column(
                          children: <Widget>[
                            TransactionDetailsViewPage(
                                transactionName: widget.transactionName,
                                transactionId: widget.transactionId,
                                transactionDate: _transactionsList.length > 0
                                    ? _transactionsList[0]
                                        .transactionDate
                                        .toString()
                                    : null,
                                namesData: _namesData),
                            SizedBox(height: 5.0),
                            Container(
                                child: Column(
                              children: <Widget>[
                                Container(
                                  decoration: AppUtills.boxDecoration(),
                                  padding: EdgeInsets.all(10.0),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Expanded(
                                        child: Container(
                                          child: Row(
                                            children: [
                                              Container(
                                                child: Text(
                                                  Language().getString(
                                                      Constants.INVOICE_NO,
                                                      selectedLang),
                                                  style: TextStyle(
                                                    color: Color(
                                                        Constants.APP_COLOR),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                child: Text(
                                                  ": ${widget.invoiceNo}",
                                                  style: TextStyle(
                                                    fontSize: 13.0,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        child: Container(
                                          child: Row(
                                            children: [
                                              Container(
                                                child: Text(
                                                  Language().getString(
                                                      Constants.RESOLUTION,
                                                      selectedLang),
                                                  style: TextStyle(
                                                    color: Color(
                                                        Constants.APP_COLOR),
                                                  ),
                                                ),
                                              ),
                                              Expanded(
                                                child: Text(
                                                  ": ${_invoiceList[0]!.stockReconciliation != null ? _invoiceList[0]!.stockReconciliation!.status : ""}",
                                                  style: TextStyle(
                                                    fontSize: 12.0,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                                handleBottomView()
                              ],
                            )),
                            Expanded(child: this.chatviewFunctionality()),
                            (_invoiceList[0]!.status == Constants.CANCELLED)
                                ? Container(
                                    alignment: Alignment.centerLeft,
                                    child: Text(
                                      "**For more messages see reconciliation discussion of later invoice(s)",
                                      textAlign: TextAlign.start,
                                      style: TextStyle(
                                          color: Color(Constants.APP_COLOR),
                                          fontSize: 15.0,
                                          fontWeight: FontWeight.w400),
                                    ),
                                  )
                                : Container()
                          ],
                        ),
                      ),
                    )),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    ));
  }

  Widget chatviewFunctionality() {
    if (isCtrTransaction) {
      return Container(
          margin: EdgeInsets.symmetric(
            vertical: 5.0,
          ),
          decoration: AppUtills.boxDecoration(),
          child: this.showMessagesListview());
    } else {
      return Container(
          decoration: AppUtills.boxDecoration(),
          child: this.showMessagesListview());
    }
  }

  Widget showMessagesListview() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Container(
          margin: EdgeInsets.symmetric(
            horizontal: 5.0,
            vertical: 5.0,
          ),
          child: Text(
            Language()
                .getString(Constants.RECONCILIATION_DISCUSSION, selectedLang),
            style: TextStyle(
                fontWeight: FontWeight.bold, color: Color(Constants.APP_COLOR)),
          ),
        ),
        list(),
        (_invoiceList[0]!.status == Constants.CANCELLED)
            ? Container()
            : Container(
                margin: EdgeInsets.all(5.0),
                child: _buildTextComposer(),
              ),
      ],
    );
  }

  statusColorHandling(String? status) {
    if (status == "delivered") {
      return Colors.green;
    } else if (status == "returned") {
      return Colors.red;
    } else {
      return Colors.deepOrangeAccent;
    }
  }

  ctrTransactionBottomView() {
    if (_invoiceList.length > 0 &&
        _invoiceList[0]!.stockReconciliation != null &&
        _invoiceList[0]!.stockReconciliation!.status != "") {
      return new Container(
        height: 40.0,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              Language().getString(Constants.STATUS_STRING, selectedLang) +
                  " : ",
              style: TextStyle(fontSize: 15.0, fontWeight: FontWeight.bold),
            ),
            Text(
              _invoiceList[0]!.stockReconciliation!.status!,
              style: TextStyle(
                  fontSize: 15.0,
                  color: statusColorHandling(
                      _invoiceList[0]!.stockReconciliation!.status),
                  fontWeight: FontWeight.bold),
            )
          ],
        ),
      );
    } else {
      if (_transactionsList.length > 0 &&
          _transactionsList[0].seller!.id == buId) {
        return Container(
          color: Color(Constants.APP_BACKGROUND_COLOR),
          child: Row(
            children: <Widget>[
              Expanded(
                  child: Container(
                padding: EdgeInsets.only(left: 10),
                margin: EdgeInsets.only(left: 0, right: 5),
                child: ElevatedButton(
                  style: CommonMethods.elevatedButtonStyle(),
                  child: Text(
                      Language().getString(Constants.DELIVERED, selectedLang)),
                  onPressed: () async {
                    if (await NetworkStatus.getInternetStatus()) {
                      this.serviceCallForDelivery("delivered", "");
                    } else {
                      AppUtills.showSnackBar(
                          _scaffoldkey,
                          Language()
                              .getString(Constants.NO_INTERNET, selectedLang),
                          snackBarBgColor: Colors.black,
                          messageColor: Colors.white,
                          buttonColor: Colors.white);
                    }
                  },
                ),
              )),
              Expanded(
                  child: Container(
                padding: EdgeInsets.only(right: 10),
                margin: EdgeInsets.only(left: 5, right: 0),
                child: ElevatedButton(
                    style: CommonMethods.elevatedButtonStyle(),
                    child: Text(
                        Language().getString(Constants.RETURNED, selectedLang)),
                    onPressed: () {
                      showChoiceDialog();
                    }),
              )),
            ],
          ),
        );
      }
    }
  }

  handleBottomView() {
    if (_transactionsList.length > 0 &&
        _invoiceList.length > 0 &&
        _invoiceList[0]!.status != Constants.CANCELLED) {
      ///check condition wether it is buyer or seller
      if (_transactionsList[0].buyer!.id == buId) {
        ///check payment details and status
        if (_invoiceList[0]!.stockReconciliation == null ||
            _invoiceList[0]!.stockReconciliation!.status == "pending" ||
            _invoiceList[0]!.stockReconciliation!.status == "not resolved") {
          return Container(
            padding: EdgeInsets.symmetric(vertical: 10),
            child: CommonButtonsView(
              context: context,
              b1Text: (CommonMethods.isPrivillegeExist(
                      context,
                      PrivillegesActions
                          .KEY_TRANSACTIONS_TRANSACTION_STEPS_STOCK_RECONCILIATION_GO_TO_RECONCILIATION_RESOLVED))
                  ? Language().getString(Constants.RESOLVED, selectedLang)
                  : "",
              b2Text: (_invoiceList.length > 0 &&
                      _invoiceList[0]!.stockReconciliation != null &&
                      _invoiceList[0]!.stockReconciliation!.status ==
                          "not resolved")
                  ? ""
                  : (CommonMethods.isPrivillegeExist(
                          context,
                          PrivillegesActions
                              .KEY_TRANSACTIONS_TRANSACTION_STEPS_STOCK_RECONCILIATION_GO_TO_RECONCILIATION_NOT_RESOLVED))
                      ? Language()
                          .getString(Constants.NOT_RESOLVED, selectedLang)
                      : "",
              onb1Action: () async {
                final action = await Dialogs.yesCancelDialog(
                    context,
                    Language().getString(Constants.CONFIRMATION, selectedLang),
                    Language().getString(
                        Constants.STOCK_RESOLVE_COMPLETE, selectedLang),
                    Language().getString(Constants.YES_STRING, selectedLang),
                    Language().getString(Constants.NO_STRING, selectedLang),
                    true);
                if (action == DialogAction.yes) {
                  if (await NetworkStatus.getInternetStatus()) {
                    serviceCallForResove("resolved");
                  } else {
                    AppUtills.showSnackBar(
                        _scaffoldkey,
                        Language()
                            .getString(Constants.NO_INTERNET, selectedLang),
                        snackBarBgColor: Colors.black,
                        messageColor: Colors.white,
                        buttonColor: Colors.white);
                  }
                }
              },
              onb2Action: () {
                this.showStructureMessagePopup("NOT_RESOLVED");
              },
            ),
          );
        } else {
          /// stock status
          return new Container(
              height: 40.0,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text(
                    Language()
                            .getString(Constants.STATUS_STRING, selectedLang) +
                        " : ",
                    style:
                        TextStyle(fontSize: 15.0, fontWeight: FontWeight.bold),
                  ),
                  Text(
                    _invoiceList[0]!.stockReconciliation!.status!,
                    style: TextStyle(
                        fontSize: 15.0,
                        color: Colors.green,
                        fontWeight: FontWeight.bold),
                  )
                ],
              ));
        }
      } else {
        /// check stock status
        if (_invoiceList[0]!.stockReconciliation == null ||
            _invoiceList[0]!.stockReconciliation!.status == "pending" ||
            _invoiceList[0]!.stockReconciliation!.status == "not resolved") {
          return Container(
            padding: EdgeInsets.symmetric(vertical: 10),
            child: CommonButtonsView(
              context: context,
              b1Text:
                  Language().getString(Constants.PIN_TO_RESOLVE, selectedLang),
              b2Text:
                  Language().getString(Constants.UPDATE_INVOICE, selectedLang),
              onb1Action: () {
                _handleSubmitted(
                    "please confirm  stock(s) received  and delivery accepted.",
                    "text_message",
                    "");
              },
              onb2Action: () {
                if (_invoiceList[0]!.stockReconciliation == null ||
                    _invoiceList[0]!.stockReconciliation!.status == "pending") {
                  Dialogs.yesCancelDialog(context, Constants.INFO, "$message",
                      Constants.OKAY_STR, "", false);
                } else {
                  this.showUpdateInvoiceOptions();
                }
              },
            ),
          );
        } else {
          return new Container(
              height: 40.0,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text(
                    Language()
                            .getString(Constants.STATUS_STRING, selectedLang) +
                        " : ",
                    style:
                        TextStyle(fontSize: 15.0, fontWeight: FontWeight.bold),
                  ),
                  Text(
                    _invoiceList[0]!.stockReconciliation!.status!,
                    style: TextStyle(
                        fontSize: 15.0,
                        color: Colors.green,
                        fontWeight: FontWeight.bold),
                  )
                ],
              ));
        }
      }
    }
    return Container();
  }

  showUpdateInvoiceOptions() {
    return showDialog(
        context: context,
        barrierColor: Colors.black54,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
              actions: [
                Container(
                  width: MediaQuery.of(context).size.width,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TextButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                        child: Text(
                          Language()
                              .getString(Constants.STR_CANCEL, selectedLang),
                          style: TextStyle(
                            color: Color(Constants.APP_COLOR),
                            fontSize: 18.0,
                          ),
                        ),
                      ),
                      TextButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                          if (radioButtonValue != null) {
                            Navigator.push(
                              context,
                              PageTransition(
                                context: context,
                                page: InvoiceDesingPage(
                                    transactionName: widget.transactionName,
                                    transactionDate: _transactionsList[0]
                                        .transactionDate
                                        .toString(),
                                    transactionId: _transactionsList[0].id,
                                    buyerName: _transactionsList[0].buyer!.name,
                                    invoiceNo: widget.invoiceNo,
                                    isFromStockReconciliation: true,
                                    isForProductReplacement:
                                        isProductReplacement,
                                    sellerName:
                                        _transactionsList[0].seller!.name,
                                    invoiceId: widget.invoiceId),
                              ),
                            );
                          } else {
                            Dialogs.yesCancelDialog(
                                context,
                                Language()
                                    .getString(Constants.INFO, selectedLang),
                                Language().getString(
                                    Constants.PLEASE_SELECT_ANY_OPTION,
                                    selectedLang),
                                Language().getString(
                                    Constants.OKAY_STR, selectedLang),
                                "",
                                false);
                          }
                        },
                        child: Text(
                          Language()
                              .getString(Constants.OKAY_STR, selectedLang),
                          style: TextStyle(
                            color: Color(Constants.APP_COLOR),
                            fontSize: 18.0,
                          ),
                        ),
                      ),
                    ],
                  ),
                )
              ],
              contentPadding: EdgeInsets.fromLTRB(25.0, 25.0, 10.0, 25.0),
              content: StatefulBuilder(
                  builder: (BuildContext context, StateSetter setState) {
                return Container(
                  height: 200.0,
                  child: Column(
                    children: [
                      InkWell(
                        onTap: () {
                          setState(() {
                            radioButtonValue = PRODUCT_REPLACEMENT;
                            isProductReplacement = true;
                          });
                        },
                        child: Container(
                          child: Row(
                            children: [
                              Radio(
                                  activeColor: Color(Constants.APP_COLOR),
                                  value: PRODUCT_REPLACEMENT,
                                  groupValue: radioButtonValue,
                                  onChanged: (dynamic value) {
                                    setState(() {
                                      radioButtonValue = PRODUCT_REPLACEMENT;
                                      isProductReplacement = true;
                                    });
                                  }),
                              Expanded(
                                child: Text(
                                  Language().getString(
                                      PRODUCT_REPLACEMENT, selectedLang),
                                  style: TextStyle(
                                      color: Color(Constants.APP_COLOR)),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      InkWell(
                        onTap: () {
                          setState(() {
                            radioButtonValue = PAYMENT_ADJUSTMENT;
                            isProductReplacement = false;
                          });
                        },
                        child: Container(
                          child: Row(
                            children: [
                              Radio(
                                  activeColor: Color(Constants.APP_COLOR),
                                  value: PAYMENT_ADJUSTMENT,
                                  groupValue: radioButtonValue,
                                  onChanged: (dynamic value) {
                                    setState(() {
                                      radioButtonValue = PAYMENT_ADJUSTMENT;
                                      isProductReplacement = false;
                                    });
                                  }),
                              Expanded(
                                child: Text(
                                  Language().getString(
                                      PAYMENT_ADJUSTMENT, selectedLang),
                                  style: TextStyle(
                                      color: Color(Constants.APP_COLOR)),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              }),
            ));
  }

  _buildTextComposer() {
    if (_invoiceList.length > 0 && _transactionsList.length > 0) {
      if (_invoiceList[0]!.stockReconciliation == null ||
          _invoiceList[0]!.stockReconciliation!.status == "pending" ||
          _invoiceList[0]!.stockReconciliation!.status == "not resolved") {
        if (_transactionsList.length > 0 &&
            _transactionsList[0].buyer!.id == buId) {
          message = Language()
              .getString(Constants.START_DISCUSSION_BY_CLICK, selectedLang);
        } else {
          message = "${_transactionsList[0].buyer!.name} " +
              Language().getString(
                  Constants.NEED_TO_INITIATE_DISCUSSION, selectedLang);
        }
        return Container(
          height: 50.0,
          padding: EdgeInsets.all(2.0),
          margin: const EdgeInsets.symmetric(horizontal: 8.0),
          decoration: new BoxDecoration(
            boxShadow: [
              BoxShadow(
                  color: Colors.grey, offset: Offset(0, 5), blurRadius: 5.0)
            ],
            borderRadius: BorderRadius.circular(50.0),
            color: Colors.white,
          ),
          child: Container(
            child: Row(
              children: <Widget>[
                (_transactionsList.length > 0 &&
                        _transactionsList[0].seller!.id != buId)
                    ? Expanded(
                        child: InkWell(
                          onTap: () {
                            if (_invoiceList[0]!.stockReconciliation == null ||
                                _invoiceList[0]!.stockReconciliation!.status ==
                                    "pending") {
                              Dialogs.yesCancelDialog(
                                  context,
                                  Language()
                                      .getString(Constants.INFO, selectedLang),
                                  "$message",
                                  Language().getString(
                                      Constants.OKAY_STR, selectedLang),
                                  "",
                                  false);
                            } else {
                              this.showStructureMessagePopup("");
                            }
                          },
                          child: Container(
                            child: Icon(Icons.more_vert,
                                color: theme.colorScheme.primary),
                          ),
                        ),
                      )
                    : SizedBox(width: 30),
                Expanded(
                  flex: 4,
                  child: Container(
                    child: new TextFormField(
                        controller: _textController,
                        decoration: new InputDecoration.collapsed(
                            hintStyle: TextStyle(color: Colors.black),
                            hintText: Language().getString(
                                Constants.SEND_A_MESSAGE_STRING,
                                selectedLang))),
                  ),
                ),
                if (CommonMethods.isPrivillegeExist(
                    context,
                    PrivillegesActions
                        .KEY_TRANSACTIONS_TRANSACTION_STEPS_STOCK_RECONCILIATION_GO_TO_RECONCILIATION_ADD_PHOTO))
                  Expanded(
                    flex: 2,
                    child: Row(
                      children: [
                        Expanded(
                          child: new Container(
                            child: IconButton(
                                icon: Icon(Icons.camera_alt,
                                    color: theme.colorScheme.primary),
                                onPressed: () async {
                                  if (_invoiceList[0]!.stockReconciliation ==
                                          null ||
                                      _invoiceList[0]!
                                              .stockReconciliation!
                                              .status ==
                                          "pending") {
                                    Dialogs.yesCancelDialog(
                                        context,
                                        Language().getString(
                                            Constants.INFO, selectedLang),
                                        "$message",
                                        Language().getString(
                                            Constants.OKAY_STR, selectedLang),
                                        "",
                                        false);
                                  } else {
                                    if (kIsWeb) {
                                      PlatformFile? selectedFile;
                                      selectedFile = await CommonMethods()
                                          .getFileUpload(context);
                                      if (selectedFile != null) {
                                        Uint8List bytes = selectedFile.bytes!;
                                        uploadImage(bytes,
                                            "${AppController.instance.getCurrentOrgName}_stock_${selectedFile.name}");
                                      }
                                    } else {
                                      this.openBottomView(context);
                                    }
                                  }
                                }),
                          ),
                        ),
                        Expanded(
                          child: new Container(
                            child: new IconButton(
                                icon: new Icon(
                                  Icons.send,
                                  color: theme.colorScheme.primary,
                                ),
                                onPressed: () async {
                                  if (_invoiceList[0]!.stockReconciliation ==
                                          null ||
                                      _invoiceList[0]!
                                              .stockReconciliation!
                                              .status ==
                                          "pending") {
                                    Dialogs.yesCancelDialog(
                                        context,
                                        Language().getString(
                                            Constants.INFO, selectedLang),
                                        "$message",
                                        Language().getString(
                                            Constants.OKAY_STR, selectedLang),
                                        "",
                                        false);
                                  } else {
                                    if (await NetworkStatus
                                        .getInternetStatus()) {
                                      this._handleSubmitted(
                                          _textController.text,
                                          "text_message",
                                          "");
                                    } else {
                                      AppUtills.showSnackBar(
                                          _scaffoldkey,
                                          Language().getString(
                                              Constants.NO_INTERNET,
                                              selectedLang),
                                          snackBarBgColor: Colors.black,
                                          messageColor: Colors.white,
                                          buttonColor: Colors.white);
                                    }
                                  }
                                }),
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        );
      } else {
        return Container();
      }
    }
  }

  uploadImage(dynamic imageData, String fileName) async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = "Getting url..";
    });
    Map data = {
      "filename": (kIsWeb) ? fileName : imageData.path.split("/").last,
      "location": "stock_reconciliation"
    };
    String body = json.encode(data);
    http.Response response = await _service.getPresignedUrl(body);
    if (response.statusCode == 200) {
      var responseBody = json.decode(response.body);
      setState(() {
        progressMessage = "Upload image..";
      });
      var uploadFileRes =
          await _service.uploadToS3Signed(responseBody['url'], imageData);
      print(uploadFileRes);
      relativePath = responseBody['relativepath'];
      _handleSubmitted(relativePath, "image_message", "");
      setState(() {
        isLoadingProgress = false;
      });
    } else {
      setState(() {
        isLoadingProgress = false;
      });
    }
  }

  openBottomView(BuildContext context) {
    return Dialogs.openBottomSheet(
        context: context,
        openCamera: (myPicture) async {
          Navigator.of(context).pop();
          this.updateImage(myPicture);
        },
        openGallery: (myPicture) async {
          Navigator.of(context).pop();
          this.updateImage(myPicture);
        });
  }

  updateImage(File fileImage) {
    setState(() {
      imageFile = fileImage;
      imageBlob = AppUtills.getBase64Image(fileImage, context);
      // uploadImage(fileImage, "");
      List<String> fileName = imageFile!.path.split('/');
      uploadImage(imageFile,
          "${AppController.instance.getCurrentOrgName}_stock_${fileName.last}");
    });
  }

  showStructureMessagePopup(String messagesFrom) {
    return showDialog(
      context: context,
      barrierColor: Colors.black54,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        elevation: 100.0,
        contentPadding: EdgeInsets.fromLTRB(15.0, 0, 15.0, 0),
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(
            Radius.circular(7.0),
          ),
        ),
        titlePadding: EdgeInsets.fromLTRB(17.0, 10.0, 10.0, 10.0),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              Language().getString(Constants.INFO_MESSAGES, selectedLang),
              style: TextStyle(
                fontSize: 17.0,
                color: theme.colorScheme.primary,
              ),
            ),
            IconButton(
                icon: Icon(
                  Icons.close,
                  color: Colors.red,
                ),
                onPressed: () {
                  Navigator.of(context).pop();
                })
          ],
        ),
        content: Container(
            height: MediaQuery.of(context).size.height,
            child: showStockStructureMessages(messagesFrom)),
      ),
    );
  }

  onStockNotResolved(int index, String messagesFrom) async {
    final action = await Dialogs.yesCancelDialog(
        context,
        Language().getString(Constants.CONFIRMATION, selectedLang),
        Language().getString(
                Constants.DO_YOU_WANT_TO_SEND_THIS_MESSAGE, selectedLang) +
            " \"${_structuredMessageList[index].name}\" ",
        Language().getString(Constants.YES_STRING, selectedLang),
        Language().getString(Constants.NO_STRING, selectedLang),
        true);

    if (action == DialogAction.yes) {
      if (await NetworkStatus.getInternetStatus()) {
        _handleSubmitted(
            "${_structuredMessageList[index].name},${_structuredMessageList[index].description}",
            "STRUCTURE_MESSAGE",
            messagesFrom);

        stockNotResolved(messagesFrom,
            type: _structuredMessageList[index].name,
            description: _structuredMessageList[index].description,
            code: _structuredMessageList[index].code);
      } else {
        AppUtills.showSnackBar(_scaffoldkey,
            Language().getString(Constants.NO_INTERNET, selectedLang),
            snackBarBgColor: Colors.black,
            messageColor: Colors.white,
            buttonColor: Colors.white);
      }
    }
  }

  showStockStructureMessages(String messagesFrom) {
    return SingleChildScrollView(
      child: Column(
        children: [
          for (int index = 0; index < _structuredMessageList.length; index++)
            InkWell(
              onTap: () async {
                Navigator.of(context).pop();
                if (messagesFrom == "NOT_RESOLVED") {
                  onStockNotResolved(index, messagesFrom);
                } else {
                  if (await NetworkStatus.getInternetStatus()) {
                    _handleSubmitted(
                        '${_structuredMessageList[index].name},${_structuredMessageList[index].description}',
                        "STRUCTURE_MESSAGE",
                        'stop_socket');
                    stockNotResolved(messagesFrom,
                        type: _structuredMessageList[index].name,
                        description: _structuredMessageList[index].description,
                        code: _structuredMessageList[index].code);
                  } else {
                    AppUtills.showSnackBar(
                        _scaffoldkey,
                        Language()
                            .getString(Constants.NO_INTERNET, selectedLang),
                        snackBarBgColor: Colors.black,
                        messageColor: Colors.white,
                        buttonColor: Colors.white);
                  }
                }
              },
              child: Card(
                elevation: 2.5,
                child: ListTile(
                  title: Text(
                    _structuredMessageList[index].name!,
                    style: TextStyle(
                        color: theme.colorScheme.primary, fontSize: 15),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Future<List<StructuredDAO>> serviceCallGetStructuredMessages() async {
    http.Response response = await _service.getStockStructureMessages();

    List<StructuredDAO> list = [];

    if (response.statusCode == 200) {
      var data = json.decode(response.body);
      for (var object in data['data']) {
        list.add(StructuredDAO.fromJson(object));
      }
    } else if (response.statusCode == 401) {
      CommonMethods.handleUnauthorizedAccess(context);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          response.body,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }

    return list;
  }

  validate(text) {
    bool isValid = false;
    if (text == "") {
      isValid = true;
    } else {
      isValid = false;
    }
    return isValid;
  }

  void _handleSubmitted(
      var text, String messageType, String messageFrom) async {
    if (validate(text)) {
      return;
    }
    if (messageFrom != 'stop_socket' && messageFrom != "NOT_RESOLVED") {
      _sendMessage(
          message: json.encode({
        "bu_id": buId,
        "messages": text,
        "message_type": messageType,
        "status": "",
      }));
    }
    _textController.clear();
    Map data = {
      "txnId": widget.transactionId,
      "bill_no": _invoiceList[0]!.billNo,
      "bu": buId,
      "messages": text,
      "message_type": messageType,
      "user_name": userName
    };

    String body = json.encode(data);

    var response = await _transactionService
        .startStockReconciliation(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      if (messageFrom == "NOT_RESOLVED") {
        serviceCallForResove("not resolved");
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    _scrollToBottom();
  }

  _scrollToBottom() {
    if (_scrollController!.hasClients) {
      _scrollController!.animateTo(_scrollController!.position.maxScrollExtent,
          duration: Duration(milliseconds: 300), curve: Curves.easeOut);
    }
  }

  updateChat(var data) {
    ChatMessage message = new ChatMessage(
      messageData: data,
      isSelected: false,
      animationController: new AnimationController(
        vsync: this,
        duration: new Duration(milliseconds: 700),
      ),
    );
    setState(() {
      _messages.add(message);
    });
    message.animationController!.forward();

    _scrollToBottom();
  }

  list() {
    return Expanded(
      child: (_messages.length > 0)
          ? dataTable()
          : Center(
              child: Text(
                Language().getString(Constants.NO_DATA_FOUND, selectedLang),
              ),
            ),
    );
  }

  dataTable() {
    return Container(
      child: ListView(
        controller: _scrollController,
        children: <Widget>[
          for (int i = 0; i < _messages.length; i++)
            designMessageData(_messages[i].messageData, i)
        ],
      ),
    );
  }

  designMessageData(var messageData, int index) {
    if (messageData['message_type'] == 'dc_order_placed') {
      return Container(
        margin: EdgeInsets.symmetric(vertical: 5.0),
        child: Column(
          children: [
            Container(
              child: Text(
                messageData['messages'],
                style: TextStyle(fontSize: 12.0),
              ),
            ),
            Container(
              child: Text(
                AppUtills.getDateFormate(
                    messageData['message_date'].toString()),
                style: TextStyle(fontSize: 12.0),
              ),
            )
          ],
        ),
      );
    } else if (messageData["bu_id"] == buId) {
      /// Your Bu is equal to
      if (messageData["message_type"] == "STRUCTURE_MESSAGE") {
        List splitText = [];
        if (messageData["discrepancy_code"].isNotEmpty) {
          for (int i = 0; i < _structuredMessageList.length; i++) {
            if (messageData["discrepancy_code"] ==
                _structuredMessageList[i].code) {
              splitText = [
                _structuredMessageList[i].name,
                _structuredMessageList[i].description
              ];
            }
          }
        }

        if (splitText.length > 0) {
          return Column(
            children: [
              Card(
                child: Container(
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: Colors.grey,
                      ),
                    ),
                    child: Column(
                      children: [
                        Container(
                          padding: EdgeInsets.all(
                            5.0,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Expanded(
                                flex: 1,
                                child: Text(
                                  Language()
                                      .getString(Constants.TYPE, selectedLang),
                                  style: TextStyle(
                                      color: Color(Constants.APP_COLOR),
                                      fontSize: 15.0,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                              Expanded(
                                child: Text(
                                  Language().getString(
                                      Constants.DESCRIPTION_STRING,
                                      selectedLang),
                                  style: TextStyle(
                                      color: Color(Constants.APP_COLOR),
                                      fontSize: 15.0,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Divider(
                          height: 1.0,
                          color: Color(Constants.APP_COLOR),
                        ),
                        Container(
                          child: Container(
                            padding: EdgeInsets.all(
                              5.0,
                            ),
                            child: Row(
                              children: [
                                Expanded(
                                  flex: 1,
                                  child: Text(
                                    "${splitText[0]}",
                                    style: TextStyle(
                                      color: Color(Constants.APP_COLOR),
                                      fontSize: 13.0,
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: Text(
                                    "${splitText[1]}",
                                    style: TextStyle(
                                      color: Color(Constants.APP_COLOR),
                                      fontSize: 13.0,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.all(
                            5.0,
                          ),
                          child: AppUtills.showMsgDetails(
                            messageData["user_name"],
                            AppUtills.getDateFormate(
                                messageData["message_date"].toString()),
                          ),
                        )
                      ],
                    )),
              ),
            ],
          );
        } else {
          return Container();
        }
      } else {
        return new Container(
            margin: const EdgeInsets.symmetric(vertical: 3.0, horizontal: 10.0),
            child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: <Widget>[
                  new Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: <Widget>[
                      (messageData["message_type"] == "image_message")
                          ? AppUtills.displaySendStockImage(
                              context,
                              index,
                              messageData["messages"],
                              messageData[Constants.INVOCIE_IMAGE],
                              messageData['user_name'],
                              messageData['message_date'].toString())
                          : Container(
                              padding: EdgeInsets.all(5.0),
                              decoration: AppUtills.sendMessageDesign(),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Container(
                                    constraints: BoxConstraints(
                                        maxWidth:
                                            MediaQuery.of(context).size.width -
                                                52),
                                    child: Text(messageData["messages"],
                                        style: TextStyle(
                                            color: Color(Constants.APP_COLOR))),
                                  ),
                                  Container(
                                    padding: EdgeInsets.all(
                                      5.0,
                                    ),
                                    child: AppUtills.showMsgDetails(
                                      messageData["user_name"],
                                      AppUtills.getDateFormate(
                                          messageData["message_date"]
                                              .toString()),
                                    ),
                                  )
                                ],
                              ))
                    ],
                  )
                ]));
      }
    } else {
      /// Your Bu id not equal
      if (messageData["message_type"] == "STRUCTURE_MESSAGE") {
        List splitText = [];
        if (messageData["discrepancy_code"].isNotEmpty) {
          for (int i = 0; i < _structuredMessageList.length; i++) {
            if (messageData["discrepancy_code"] ==
                _structuredMessageList[i].code) {
              splitText = [
                _structuredMessageList[i].name,
                _structuredMessageList[i].description
              ];
            }
          }
        }

        if (splitText.length > 0) {
          return Column(
            children: [
              Card(
                child: Container(
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: Colors.grey,
                      ),
                    ),
                    child: Column(
                      children: [
                        Container(
                          padding: EdgeInsets.all(
                            5.0,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Expanded(
                                flex: 1,
                                child: Text(
                                  Language()
                                      .getString(Constants.TYPE, selectedLang),
                                  style: TextStyle(
                                      color: Color(Constants.APP_COLOR),
                                      fontSize: 15.0,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                              Expanded(
                                child: Text(
                                  Language().getString(
                                      Constants.DESCRIPTION_STRING,
                                      selectedLang),
                                  style: TextStyle(
                                      color: Color(Constants.APP_COLOR),
                                      fontSize: 15.0,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Divider(
                          height: 1.0,
                          color: Color(Constants.APP_COLOR),
                        ),
                        Container(
                          child: Container(
                            padding: EdgeInsets.all(
                              5.0,
                            ),
                            child: Row(
                              children: [
                                Expanded(
                                  flex: 1,
                                  child: Text(
                                    "${splitText[0]}",
                                    style: TextStyle(
                                      color: Color(Constants.APP_COLOR),
                                      fontSize: 13.0,
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: Text(
                                    "${splitText[1]}",
                                    style: TextStyle(
                                      color: Color(Constants.APP_COLOR),
                                      fontSize: 13.0,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.all(5.0),
                          child: AppUtills.showMsgDetails(
                            messageData["user_name"],
                            AppUtills.getDateFormate(
                                messageData["message_date"].toString()),
                          ),
                        )
                      ],
                    )),
              ),
            ],
          );
        } else {
          return Container();
        }
      } else {
        return Container(
            margin: const EdgeInsets.symmetric(vertical: 3.0, horizontal: 10.0),
            child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  new Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      (messageData["message_type"] == "image_message")
                          ? AppUtills.displayReceiveStockImage(
                              context,
                              index,
                              messageData["messages"],
                              messageData[Constants.INVOCIE_IMAGE],
                              messageData['user_name'],
                              messageData['message_date'].toString())
                          : Container(
                              padding: EdgeInsets.all(5.0),
                              decoration: AppUtills.receiveMessageDesign(),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    constraints: BoxConstraints(
                                        maxWidth:
                                            MediaQuery.of(context).size.width -
                                                52),
                                    child: Text(
                                      messageData["messages"],
                                      style: TextStyle(
                                          color: Color(Constants.APP_COLOR)),
                                    ),
                                  ),
                                  Container(
                                    child: AppUtills.showMsgDetails(
                                      messageData["user_name"],
                                      AppUtills.getDateFormate(
                                          messageData["message_date"]
                                              .toString()),
                                    ),
                                  )
                                ],
                              ))
                    ],
                  )
                ]));
      }
    }
  }

  Future<List<TransactionsModel>> getAllDiscussionData() async {
    _transactionsList.clear();
    _invoiceMsgData.clear();
    String body = json.encode({"id": widget.transactionId});

    var response = await _transactionService
        .getTransactionDataById(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<TransactionsModel> _discussionsData = [];
    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      _discussionsData.add(TransactionsModel.fromJson(resObj[0]));
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return _discussionsData;
  }

  Future<List<InvoiceDataDAO>> getInvoiceData() async {
    setState(() {
      isLoadingProgress = true;
    });
    String body = json.encode({"id": widget.invoiceId});
    var response = await _transactionService
        .getInvoiceDetailsByInvoiceId(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    List<InvoiceDataDAO> list = [];
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      bool isString = false;
      if (resObj is String) {
        isString = true;
      }
      if (!isString) {
        list.add(InvoiceDataDAO.fromJson(resObj[0]));

        List<ReconciliationDetails> messageList = [];
        if (list[0].invoiceDetails != null &&
            list[0].invoiceDetails!.stockReconciliation != null) {
          messageList
              .addAll(list[0].invoiceDetails!.stockReconciliation!.messages!);
          setState(() {
            _messages.clear();
          });
          for (var items in messageList) {
            updateChat({
              "bu_id": items.bu,
              "messages": items.message,
              "message_type": items.messageType,
              "user_name": items.userName,
              "message_date": items.messageDate,
              Constants.INVOCIE_IMAGE: items.invoiceImage,
              "discrepancy_code": items.discrepancyCode
            });
          }
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
      return list;
  }

  serviceCallForDelivery(String status, String message) async {
    setState(() {
      isLoadingProgress = true;
    });
    Map data = {
      "txnId": widget.transactionId,
      "bill_no": _invoiceList[0]!.billNo,
      "reconciliation_type": "stock",
      "status": status,
      "ctr3_message": message
    };

    String body = json.encode(data);
    http.Response response =
        await _service.updateDeliveryStatus(body).catchError((value) {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    if (response.statusCode == 200) {
      loadStockReconciliationData();
    } else if (response.statusCode == 401) {
      CommonMethods.handleUnauthorizedAccess(context);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          response.body,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  void serviceCallForResove(String stockStatus) async {
    setState(() {
      isLoadingProgress = true;
    });
    Map data = {
      "txnId": widget.transactionId,
      "bill_no": _invoiceList[0]!.billNo,
      "reconciliation_type": "stock",
      "status": stockStatus,
      "user_name": userName
    };

    String body = json.encode(data);
    var response = await _transactionService
        .updateStockResolve(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = true;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      _sendMessage(
          message: json.encode({
        "bu_id": buId,
        "messages": "Stock $stockStatus by $userName",
        "message_type": "dc_order_placed",
        "status": stockStatus,
        Constants.INVOCIE_IMAGE: ""
      }));
      if (stockStatus == "resolved") {
        Navigator.of(context).pop();
      } else {
        loadStockReconciliationData();
      }
    } else {
      setState(() {
        isLoadingProgress = true;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  loadStockReconciliationData() async {
    if (await NetworkStatus.getInternetStatus()) {
      await this.getInvoiceData().then((value) {
        _invoiceList.clear();
        if (value.length > 0) {
          _invoiceList.add(value[0].invoiceDetails);

          if (_invoiceList[0]!.invoiceType == Constants.CTR3) {
            setState(() {
              isCtrTransaction = true;
            });

            setState(() {
              if (_invoiceList[0]!.ctrTransactionDetails != null) {
                initSocket();
              }
            });
          } else {
            setState(() {
              if (_invoiceList[0]!.orderTrackDetails != null) {
                initSocket();
              }
            });
          }
        }
      });

      this.getAllDiscussionData().then((value) {
        _transactionsList.addAll(value);
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  showChoiceDialog() {
    return showDialog(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(15.0)),
            ),
            title: Column(
              children: <Widget>[
                Align(
                  alignment: Alignment.topRight,
                  child: GestureDetector(
                    onTap: () {
                      Navigator.of(context).pop();
                    },
                    child: Icon(
                      Icons.close,
                      color: Colors.red,
                    ),
                  ),
                ),
                SizedBox(
                  height: 2.5,
                ),
                buildTextFormFields(
                    Constants.ENTER_REASON, _returenedTextController),
              ],
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                SizedBox(
                  height: 10,
                ),
                GestureDetector(
                  onTap: () {},
                  child: ButtonTheme(
                    minWidth: MediaQuery.of(context).size.width,
                    child: ElevatedButton(
                      style: CommonMethods.elevatedButtonStyle(),
                      onPressed: () async {
                        Navigator.of(context).pop();
                        if (await NetworkStatus.getInternetStatus()) {
                          this.serviceCallForDelivery(
                              "returned", _returenedTextController.text);
                        } else {
                          AppUtills.showSnackBar(
                              _scaffoldkey,
                              Language().getString(
                                  Constants.NO_INTERNET, selectedLang),
                              snackBarBgColor: Colors.black,
                              messageColor: Colors.white,
                              buttonColor: Colors.white);
                        }
                      },
                      child: Padding(
                          padding: EdgeInsets.symmetric(vertical: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Expanded(
                                flex: 1,
                                child: Icon(Icons.arrow_right),
                              ),
                              Expanded(
                                  flex: 2,
                                  child: Text(Language()
                                      .getString(Constants.SEND, selectedLang)))
                            ],
                          )),
                    ),
                  ),
                ),
              ],
            ),
          );
        });
  }

  buildTextFormFields(String _labelText, TextEditingController _controller) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8.0, vertical: 8.0),
      child: new TextFormField(
        controller: _controller,
        style: TextStyle(fontFamily: StyleView.FONT_TITLE),
        decoration: InputDecoration(
          labelText: Language().getString(_labelText, selectedLang),
          isDense: true,
          border: OutlineInputBorder(),
          focusColor: Color(0xFF083e64),
          enabledBorder:
              OutlineInputBorder(borderSide: BorderSide(color: Colors.grey)),
          focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(color: StyleView.secondaryColor)),
        ),
        onChanged: (text) => {},
      ),
    );
  }

  void initSocket() async {
    // String url = "${Constants.NEW_BASE_URL}communication";
    // String url ="http://${Constants.BASE_URL_2}:${Constants.SOCKET_PORT}/communication";
    // print(Constants.CHAT_COMMUNICATION_URL);
    socket = io.io('${Constants.CHAT_COMMUNICATION_URL}', <String, dynamic>{
      'autoConnect': true,
      'transports': ['websocket']
    });

    socket!.on('connect', (_) {
      print("socket connected:");
      sendJoinChat();
    });

    socket!.on('error', (error) {
      print('error');
      print(error);
    });

    print("socket.connected:${socket!.connected}");

    socket!.on('msgReceive', (data) {
      _onReceiveMessage(data);
    });
  }

  _unSubscribes() {
    if (socket != null) {
      socket!.disconnect();
    }
  }

  void sendJoinChat() {
    socket!.emit(
        "joinChat", "STR-${widget.transactionId}-${_invoiceList[0]!.billNo}");
  }

  void _onReceiveMessage(msg) {
    var data = json.decode(msg);
    ChatMessage message = new ChatMessage(
      messageData: data,
      isSelected: false,
      animationController: new AnimationController(
        vsync: this,
        duration: new Duration(milliseconds: 700),
      ),
    );
    setState(() {
      _messages.add(message);
    });
    message.animationController!.forward();
    Timer(Duration(seconds: 1), _scrollToBottom);
    if (data.containsKey('status') && data['status'] == 'resolved') {
      Navigator.of(context).pop();
    }
  }

  _sendMessage({String message = ''}) async {
    // String messageId = uuid.v1();

    var dataObj = json.decode(message);
    var mainMap = Map<String, Object?>();
    mainMap['sender_id'] = AppController.instance.myBuId;

    mainMap['messages'] = dataObj["messages"];
    mainMap['bu_id'] = dataObj["bu_id"];

    mainMap['chat_id'] =
        "STR-${widget.transactionId}-${_invoiceList[0]!.billNo}";
    mainMap['message_type'] = dataObj["message_type"];
    mainMap['status'] = dataObj['status'];
    mainMap[Constants.INVOCIE_IMAGE] = dataObj[Constants.INVOCIE_IMAGE];
    mainMap['user_name'] = userName;
    mainMap['message_date'] = DateTime.now().toUtc().toString();
    dataObj['user_name'] = userName;
    dataObj['message_date'] = mainMap['message_date'];
    if (dataObj['message_type'] == "STRUCTURE_MESSAGE") {
      mainMap['discrepancy_code'] = dataObj['discrepancy_code'];
    }

    String jsonString = json.encode(mainMap);

    socket!.emit('new_message', jsonString);

    ChatMessage _message = new ChatMessage(
      messageData: dataObj,
      isSelected: false,
      animationController: new AnimationController(
        vsync: this,
        duration: new Duration(milliseconds: 700),
      ),
    );
    setState(() {
      _messages.add(_message);
    });

    _scrollToBottom();
  }

  void stockNotResolved(String stockStatus,
      {required String? type,
      required String? description,
      required String? code}) async {
    setState(() {
      isLoadingProgress = true;
    });

    Map data = {
      "txnId": widget.transactionId,
      "bill_no": _invoiceList[0]!.billNo,
      "user_name": userName,
      "bu": buId,
      "messages": description,
      "discrepancy_code": code,
    };

    String body = json.encode(data);
    var response = await _transactionService
        .stockReconciliationNotResolved(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      _sendMessage(
          message: json.encode({
        "bu_id": buId,
        "messages": description,
        "discrepancy_code": code,
        "message_type": "STRUCTURE_MESSAGE",
        "status": "",
      }));
      _sendMessage(
          message: json.encode({
        "bu_id": buId,
        "messages": "Stock not resolved by $userName",
        "message_type": "dc_order_placed",
        "status": stockStatus,
        Constants.INVOCIE_IMAGE: ""
      }));

      getInvoiceData().then((value) {
        _invoiceList.clear();
        if (value.length > 0) {
          setState(() {
            _invoiceList.add(value[0].invoiceDetails);
          });
        }
      });
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }
}

class HeroTagExample extends StatelessWidget {
  HeroTagExample({this.fileImage, this.tagName, this.imageFrom});
  final String? fileImage;
  final String? tagName;
  final String? imageFrom;
  static const String GALLERY_IMAGE = "gallery_image";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black12,
      appBar: AppBar(backgroundColor: Colors.black12, title: Text("$tagName")),
      body: GestureDetector(
        onTap: () {
          Navigator.pop(context);
        },
        child: Container(
          child: Center(
            child: Hero(
                tag: tagName!,
                child: this.displayStockImageForHero(imageFrom, fileImage)),
          ),
        ),
      ),
    );
  }

  displayStockImageForHero(String? imageFrom, String? fileImage) {
    if (imageFrom == GALLERY_IMAGE) {
      return Image.file(
        File(fileImage!),
        fit: BoxFit.contain,
      );
    } else {
      return Image.network(
        Constants.NEW_BASE_URL + "transaction/buimgs/" + fileImage!,
        headers: {
          'Content-type': 'application/json',
          'Accept': 'application/json',
          'authorization': AppController.instance.getAuthorizationKey
        },
        fit: BoxFit.contain,
        errorBuilder:
            (BuildContext context, Object exception, StackTrace? stackTrace) {
          return Image.asset('assets/images/empty.jpg',
              gaplessPlayback: true, fit: BoxFit.contain);
        },
      );
    }
  }
}
