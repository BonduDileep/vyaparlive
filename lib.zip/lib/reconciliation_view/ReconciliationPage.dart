import 'dart:async';
import 'dart:io';
import 'package:vyaparlive/core/enums/privilleges_enum.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:http_parser/http_parser.dart';
import 'package:intl/intl.dart';
import 'package:mime/mime.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Transaction/seller/InvoiceWebView.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/CommonNavigation.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/TransactionDetailsView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/components/privileges/transaction_privileges.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/InvoiceDAO.dart' as invocieDAO;
import 'package:vyaparlive/model/TransactionsModel.dart';
import 'package:vyaparlive/model/UserModel.dart';
import 'package:vyaparlive/model/transaction/InvoiceDataDAO.dart';
import 'package:vyaparlive/model/transaction/InvoiceDetailsModel.dart';
import 'package:vyaparlive/model/transaction/ReceivedPaymnetDAO.dart';
import 'package:vyaparlive/model/transaction/TrackingDetailsDAO.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:vyaparlive/reconciliation_view/PaymentReconciliation.dart';
import 'package:vyaparlive/reconciliation_view/ShowPdf.dart';
import 'package:vyaparlive/reconciliation_view/StockReconciliation.dart';
import 'package:http/http.dart' as http;
import 'package:vyaparlive/server_image_view/ShowServerImageView.dart';
import 'dart:convert';
import 'package:vyaparlive/service/Service.dart';
import 'package:vyaparlive/service/bu_list_grpc_service.dart';
import 'package:vyaparlive/service/user_services.dart';
import 'package:vyaparlive/utills/SharePref.dart';
import 'package:toast/toast.dart';

class ReconciliationView extends StatefulWidget {
  ReconciliationView(
      {this.transactionName, this.reconciliationName, this.transactionId});
  final String? transactionName;
  final String? reconciliationName;
  final String? transactionId;
  @override
  _ReconciliationViewState createState() => _ReconciliationViewState();
}

class _ReconciliationViewState extends State<ReconciliationView> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? buName = "";
  DateFormat formatter = DateFormat("yyyy-MM-d");
  String? buId = "";
  late Service _service;
  static DateTime selectedDate = DateTime.now();
  String todayDate = DateFormat('yyyy-MM-d').format(selectedDate);
  String deliveryDate = Constants.SELECT_DATE;
  List<String> deliveryDateList = [];
  List<TransactionsModel> _transactionsList = [];
  List<InvoiceDetails> _invoiceList = [];
  bool isTransactionBuyer = false;
  UserModel? userDropdownvalue;
  List<UserModel> _usersList = [];
  TimeOfDay selectedTime = TimeOfDay.now();
  String actualDeliveryTime = Constants.SELECT_TIME;
  TransactionPrivileges? _transactionPrivileges =
      AppController.instance.getTransactionPrivileges;
  // List<UserModel> updateUserDropdownValue = [];
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  String? receivedBy = "";
  late BuListGrpcService _transactionService;
  TextEditingController _payAmount = TextEditingController();
  String datePicker = "";
  String showSelectedDate = Constants.SELECT_DATE;
  List<ReceivedPaymentDAO> receivedList = [];
  bool isShowSmallCircularIndicator = false;
  num totalPendingAmount = 0;
  bool isTransactionRequestSuccess = false;
  // TrackingDetailsDAO trackingDropdownValue;
  File? pickedFile;
  bool isReady = false;
  int pages = 0;
  List<InvoiceDataDAO> invoiceDetailsList = [];
  bool isFileSelected = false;
  String? actualProductsRadioButionVaue;
  String? rawMaterialRadioButtonValue;
  String? orgCurrencySymbol = "";
  List<InvoiceDetails?> appendInvoiceData = [];
  String selectedLang = AppController.instance.getSelectedlanguage;
  SharedPreferences? sharedPreferences;
  List<Map> _namesData = [];
  late UserService _userService;
  List<String?> productsConversionTypeList = [];
  List<invocieDAO.Product> _invoiceProductsList = [];
  String? userId = "";
  String? userName = "";
  List<TrackingDetailsDAO?> _trackingDropdownValueUpdate = [];
  Uint8List? _webImage;
  final String imageName = "stock_received_web.png";
  String? relativePath = "";
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    this.getLoadLanguage();
    _userService = UserService();
    _service = Service();
    SharePref().getUserName().then((value) {
      userName = value;
    });
    SharePref().getUserId().then((value) {
      userId = value;
    });
    _transactionService = BuListGrpcService();
    buId = AppController.instance.getMyBuId;
    buName = AppController.instance.getBuName;
    this.loadTransactionData();
    orgCurrencySymbol = AppController.instance.getBuCurrencySymbol;
  }

  getLoadLanguage() async {
    _namesData = [
      {"name": Language().getString(Constants.NAME_STRING, selectedLang)},
      {"name": Language().getString(Constants.TXN_ID, selectedLang)},
      {"name": Language().getString(Constants.TXN_INITIATED_DATE, selectedLang)}
    ];
  }

  loadTransactionData({bool updatePendingAmount = false}) async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
      });
      // updateUserDropdownValue.clear();
      invoiceDetailsList.clear();
      // trackingDropdownValue = null;
      _trackingDropdownValueUpdate.clear();
      _transactionsList.clear();
      getAllDiscussionData().then((value) {
        _transactionsList.addAll(value);
        this.bindingGeneratedInvoiceList();

        if (widget.reconciliationName == Constants.STOCK_RECONCILIATION) {
          // loadUserServiceCall();
        }
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  loadUserServiceCall() async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
      });
      this.getAllUsers(buId).then((value) {
        setState(() {
          _usersList.addAll(value);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<TransactionsModel>> getAllDiscussionData(
      {bool updatePendingAmount = false}) async {
    _transactionsList.clear();
    _invoiceList.clear();
    _usersList.clear();
    receivedList.clear();
    String body = json.encode({"id": widget.transactionId});
    var response = await _transactionService
        .getTransactionDataById(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<TransactionsModel> _discussionsData = [];
    setState(() {
      isLoadingProgress = false;
      isShowSmallCircularIndicator = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      _discussionsData.add(TransactionsModel.fromJson(resObj[0]));
      if (updatePendingAmount) {
        receivedList.add(ReceivedPaymentDAO(
            receivedDate: showSelectedDate,
            receivedAmount: double.parse(_payAmount.text.trim())));
        isTransactionRequestSuccess = false;
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return _discussionsData;
  }

  @override
  void setState(VoidCallback fn) {
    // TODO: implement setState
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  Widget build(BuildContext context) {
    ToastContext().init(context);
    return AppBackgroundView(
        body: Stack(
      children: [
        SafeArea(
          child: Scaffold(
              key: _scaffoldkey,
              backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
              appBar: AppBar(
                centerTitle: true,
                elevation: 0,
                iconTheme: IconThemeData(color: theme.colorScheme.primary),
                title: AppbarName(
                    title: Language()
                        .getString(widget.reconciliationName, selectedLang),
                    buName: "$buName"),
                actions: [
                  AppUtills.homeButton(context),
                ],
                backgroundColor: Colors.transparent, //Color(Constants.APP_COLOR),
              ),
              bottomNavigationBar: this.bottomView(),
              body: showStockReceiveInvoiceView()),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    ));
  }

  Widget showRaisedButton() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 10),
      child: ElevatedButton(
          style: ElevatedButton.styleFrom(
              backgroundColor: theme.colorScheme.primary, elevation: 0),
          onPressed: () async {
            DateFormat timeFormat = DateFormat("HH:mm aa");
            setState(() {
              isLoadingProgress = true;
            });
            if (widget.reconciliationName == Constants.STOCK_RECONCILIATION) {
              if (await NetworkStatus.getInternetStatus()) {
                deliveryDate = formatter.format(DateTime.now());
                DateTime now = DateTime.now();
                actualDeliveryTime = timeFormat.format(now);
                receivedBy = _transactionsList[0].buyer!.name;
                this.serviceCallUpdateStockInvoiceDetails(
                    _transactionsList[0].invoiceDetails![0].billNo,
                    receivedBy,
                    _transactionsList[0].invoiceDetails![0].invoiceId,
                    isOfflineStock: true,
                    receivedType: Constants.SALABLE_PRODUCTS);
              } else {
                AppUtills.showSnackBar(_scaffoldkey,
                    Language().getString(Constants.NO_INTERNET, selectedLang),
                    snackBarBgColor: Colors.black,
                    messageColor: Colors.white,
                    buttonColor: Colors.white);
              }
            } else {
              if (await NetworkStatus.getInternetStatus()) {
                deliveryDate = formatter.format(DateTime.now());
                DateTime now = DateTime.now();
                actualDeliveryTime = timeFormat.format(now);
                receivedBy = _transactionsList[0].seller!.name;
                this.serviceCallUpdatePaymentInvoiceDetails(
                    _transactionsList[0].invoiceDetails![0].billNo, receivedBy);
              } else {
                AppUtills.showSnackBar(_scaffoldkey,
                    Language().getString(Constants.NO_INTERNET, selectedLang),
                    snackBarBgColor: Colors.black,
                    messageColor: Colors.white,
                    buttonColor: Colors.white);
              }
            }
          },
          child: Text(
            widget.reconciliationName == Constants.STOCK_RECONCILIATION
                ? Language()
                    .getString(Constants.STOCK_RECEIVED_BY_BUYER, selectedLang)
                : Language()
                    .getString(Constants.PAYMENT_RECEIVED, selectedLang),
            style: TextStyle(color: Colors.white),
          )),
    );
  }

  Widget? bottomView() {
    if (_transactionsList.length > 0 &&
        _transactionsList[0].isOffline! &&
        _invoiceList.length > 0) {
      if (widget.reconciliationName == Constants.STOCK_RECONCILIATION &&
          _invoiceList[0].stockReceivedStatus != 'received') {
        return showRaisedButton();
      } else if (widget.reconciliationName ==
              Constants.PAYMENT_RECONCILIATION &&
          _invoiceList[0].paymentReceivedStatus != 'received') {
        return showRaisedButton();
      } else {
        return null;
      }
    } else {
      return null;
    }
  }

  Widget designForPaymentReconciliation() {
    bool isAllInvoicesCancelled = false;
    for (int i = 0; i < _invoiceList.length; i++) {
      isAllInvoicesCancelled = false;
      if (_invoiceList[i].status == Constants.CANCELLED) {
        isAllInvoicesCancelled = true;
      }
    }

    if (isAllInvoicesCancelled) {
      return AppUtills.showTransactionStageMessage();
    } else {
      if (_transactionsList[0].ctrDetails != null &&
          _transactionsList[0].ctrDetails!.type == Constants.CTR1) {
        return Container(
          child: SingleChildScrollView(
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  for (int i = 0; i < _invoiceList.length; i++)
                    if (_invoiceList[i].status != "cancelled" &&
                        _invoiceList[i].invoiceType != Constants.CTR3)
                      this.buildInvoicePaymentExpansionTile(_invoiceList[i], i)
                ]),
          ),
        );
      } else {
        return Container(
          child: SingleChildScrollView(
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  for (int i = 0; i < _invoiceList.length; i++)
                    if (_invoiceList[i].status != "cancelled")
                      // &&
                      //     _invoiceList[i].stockReconciliation != null &&
                      //     _invoiceList[i].stockReconciliation.status == 'resolved')
                      this.buildInvoicePaymentExpansionTile(_invoiceList[i], i)
                ]),
          ),
        );
      }
    }
  }

  buildInvoicePaymentExpansionTile(InvoiceDetails invoiceDetails, int index) {
    return Container(
      margin: EdgeInsets.symmetric(
        vertical: 2.0,
      ),
      decoration: AppUtills.boxDecoration(),
      child: ExpansionTile(
          title: Container(
            alignment: Alignment.centerLeft,
            child: InkWell(
              onTap: () {
                CommonNavigation.navigationToInvoiceDesign(
                  context,
                  widget.transactionName,
                  widget.transactionId,
                  _transactionsList.length > 0
                      ? _transactionsList[0].transactionDate.toString()
                      : null,
                  invoiceDetails.billNo.toString(),
                  invoiceDetails.invoiceId,
                );
              },
              child: Text(
                Language().getString(Constants.INVOICE, selectedLang) +
                    " #${invoiceDetails.billNo}",
                style: TextStyle(
                    color: Color(Constants.APP_COLOR),
                    fontWeight: FontWeight.bold,
                    decoration: TextDecoration.underline),
              ),
            ),
          ),
          subtitle: Text(
            Language().getString(Constants.RESOLUTION, selectedLang) +
                " : ${invoiceDetails.paymentReconciliation != null ? invoiceDetails.paymentReconciliation!.status : ""}",
            style: TextStyle(
              fontSize: 13.0,
            ),
          ),
          onExpansionChanged: (value) {
            if (value) {
              getInvoiceDetailsByInvoiceId(invoiceDetails.invoiceId)
                  .then((value) {
                setState(() {
                  invoiceDetailsList.clear();
                  invoiceDetailsList.addAll(value);
                  if (invoiceDetailsList.length > 0) {
                    appendInvoiceData[index] =
                        invoiceDetailsList[0].invoiceDetails;
                  }
                });
              });
            }
          },
          children: _transactionsList[0].isOffline!
              ? this.offlinePaymentDetailsView(
                  // (appendInvoiceData.length > index)
                  //     ?
                  appendInvoiceData[index]!,
                  // : null,
                  invoiceDetails.invoiceId,
                  index)
              : this.paymentInvoiceDetailsView(
                  appendInvoiceData.length > index
                      ? appendInvoiceData[index]
                      : null,
                  index,
                  invoiceDetails.invoiceId)),
    );
  }

  List<Widget> offlinePaymentDetailsView(
      InvoiceDetails? invoiceDetails, String? invoiceId, int index) {
    return <Widget>[
      Divider(
        color: Color(Constants.APP_COLOR),
      ),
      Container(
          padding: EdgeInsets.all(5.0),
          margin: EdgeInsets.symmetric(
            vertical: 5.0,
          ),
          child: buildRowPaymentText(
              Constants.INVOICE_AMOUNT, "${invoiceDetails?.finalTotal}", 1, 1)),
      Container(
          padding: EdgeInsets.all(5.0),
          margin: EdgeInsets.symmetric(
            vertical: 5.0,
          ),
          child: buildRowPaymentText(Constants.PAYMENT_RECEIVED_DATE,
              "${invoiceDetails?.paymentReceivedDate}", 1, 1)),
      Container(
          padding: EdgeInsets.all(5.0),
          margin: EdgeInsets.symmetric(
            vertical: 5.0,
          ),
          child: buildRowPaymentText(Constants.RECEIVED_BY,
              "${invoiceDetails?.paymentReceivedBy}", 1, 1)),
      Container(
          padding: EdgeInsets.all(5.0),
          margin: EdgeInsets.symmetric(
            vertical: 5.0,
          ),
          child: buildRowPaymentText(Constants.PAYMENT_STATUS,
              "${invoiceDetails?.paymentReceivedStatus}", 1, 1)),
      Container(
          padding: EdgeInsets.all(5.0),
          margin: EdgeInsets.symmetric(
            vertical: 5.0,
          ),
          child: buildRowPaymentText(Constants.PENDING_AMOUNT,
              "${invoiceDetails?.pendingAmount}", 1, 1)),
      this.designPaymentReceiveFunctionality(invoiceDetails?.billNo, invoiceId),
      this.showReceivedPaymentData(
          appendInvoiceData.length > index
              ? appendInvoiceData[index]!.receivedPayments
              : [],
          index)
    ];
  }

  List<Widget> paymentInvoiceDetailsView(
      InvoiceDetails? invoiceDetails, int index, String? invoiceId) {
    if (invoiceDetails != null) {
      String paymentDueDate = "";
      if (invoiceDetails.paymentDueDate != null) {
        paymentDueDate = formatter.format(invoiceDetails.paymentDueDate!);
      }
      bool isTransactionOffline = false;
      if (_transactionsList[0].isOffline!) {
        isTransactionOffline = true;
      }

      return <Widget>[
        Divider(color: Color(Constants.APP_COLOR)),
        this.showInvoiceAmountView(paymentDueDate,
            invoiceDetails.finalTotal != null ? invoiceDetails.finalTotal : 0),
        this.showPartPaymentView(invoiceDetails),
        this.showResolutionStatusView(
            isTransactionOffline, invoiceDetails, invoiceId),
        this.showPendingAmountView(invoiceDetails.pendingAmount != null
            ? invoiceDetails.pendingAmount
            : 0),
        Container(
          margin: EdgeInsets.symmetric(vertical: 5.0, horizontal: 5.0),
          alignment: Alignment.centerLeft,
          child: Text(
            isTransactionBuyer
                ? "${Language().getString(Constants.PAYMENT_SENT, selectedLang)} :"
                : "${Language().getString(Constants.PAYMENT_RECEIVED, selectedLang)} :",
            style: TextStyle(
                color: Color(Constants.APP_COLOR),
                fontSize: 15.0,
                fontWeight: FontWeight.bold),
          ),
        ),
        (_transactionsList[0].seller!.id == buId &&
                invoiceDetailsList.length > 0)
            ? this.designPaymentReceiveFunctionality(
                invoiceDetails.billNo, invoiceId)
            : Container(),
        this.showReceivedPaymentData(
            appendInvoiceData.length > index
                ? appendInvoiceData[index]!.receivedPayments
                : [],
            index)
      ];
    } else {
      return <Widget>[
        Container(
            child: Text(
                Language().getString(Constants.NO_DATA_FOUND, selectedLang)))
      ];
    }
  }

  Widget designPaymentReceiveFunctionality(dynamic billNo, String? invoiceId) {
    return Container(
      height: 40.0,
      decoration: AppUtills.boxDecoration(),
      margin: EdgeInsets.symmetric(horizontal: 5.0),
      child: Row(
        children: [
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(5.0),
                      bottomLeft: Radius.circular(5.0))),
              height: 40.0,
              margin: EdgeInsets.only(right: 2.0),
              padding: EdgeInsets.all(5.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("$showSelectedDate"),
                  Container(
                    child: InkWell(
                        onTap: () async {
                          datePicker = await AppUtills.getSelectedDate(context);
                          setState(() {
                            showSelectedDate = datePicker;
                          });
                        },
                        child: Icon(
                          Icons.date_range,
                          color: Colors.green,
                        )),
                  ),
                ],
              ),
            ),
          ),
          Expanded(
              child: Container(
            color: Colors.white,
            height: 40.0,
            padding: EdgeInsets.all(2.0),
            child: TextField(
              controller: _payAmount,
              keyboardType: TextInputType.numberWithOptions(signed: true),
              enableInteractiveSelection: false,
              cursorWidth: 1.0,
              inputFormatters: [
                CommonMethods.inputTextFormatter(isNumber: true)
              ],
              decoration: InputDecoration(
                  contentPadding: EdgeInsets.all(10.0),
                  border: InputBorder.none,
                  hintText:
                      Language().getString(Constants.AMOUNT, selectedLang)),
            ),
          )),
          Container(
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                    topRight: Radius.circular(5.0),
                    bottomRight: Radius.circular(5.0))),
            height: 40.0,
            margin: EdgeInsets.only(left: 2.0),
            child: InkWell(
              onTap: () async {
                String message = paymentValidation();
                if (message.isNotEmpty) {
                  Dialogs.yesCancelDialog(
                      context,
                      Language().getString(Constants.ERROR, selectedLang),
                      Language().getString(message, selectedLang),
                      Language().getString(Constants.OKAY_STR, selectedLang),
                      "",
                      false);
                } else {
                  final action = await Dialogs.yesCancelDialog(
                      context,
                      Language().getString(Constants.INFO, selectedLang),
                      Language().getString(
                          Constants.DO_YOU_WANT_ADD_THIS_PAYMENT, selectedLang),
                      Language().getString(Constants.OKAY_STR, selectedLang),
                      Language().getString(Constants.STR_CANCEL, selectedLang),
                      true);

                  if (action == DialogAction.yes) {
                    if (await NetworkStatus.getInternetStatus()) {
                      setState(() {
                        isShowSmallCircularIndicator = true;
                      });
                      this.serviceCallPaymentReceived(billNo, invoiceId);
                    } else {
                      AppUtills.showSnackBar(
                          _scaffoldkey,
                          Language()
                              .getString(Constants.NO_INTERNET, selectedLang),
                          snackBarBgColor: Colors.black,
                          messageColor: Colors.white,
                          buttonColor: Colors.white);
                    }
                  }
                }
              },
              child: Icon(Icons.add),
            ),
          )
        ],
      ),
    );
  }

  Widget gotoPaymentDiscussion(
      {String? invoiceNo, String? resolution, String? invoiceId}) {
    if (CommonMethods.isPrivillegeExist(
        context,
        PrivillegesActions
            .KEY_TRANSACTIONS_TRANSACTION_STEPS_PAYMENT_RECONCILIATION_GO_TO_RECONCILIATION)) {
      return Expanded(
          child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: theme.colorScheme.primary,
                  padding:
                      EdgeInsets.all(5)), //CommonMethods.elevatedButtonStyle(),
              onPressed: () {
                Navigator.push(
                        context,
                        PageTransition(
                            context: context,
                            page: PaymentReconciliationPage(
                                transactionName: widget.transactionName,
                                transactionId: widget.transactionId,
                                invoiceNo: invoiceNo,
                                resolution: resolution,
                                invoiceId: invoiceId)))
                    .then((value) => this.loadTransactionData());
              },
              child: Container(
                child: Text(
                  Language().getString(
                      Constants.GO_TO_RECONCILIATION_DISCUSSION, selectedLang),
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white, fontSize: 12.0),
                ),
              )));
    } else {
      return SizedBox();
    }
  }

  Widget designForStockReconciliation() {
    return Container(
      child: SingleChildScrollView(
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              for (int i = 0; i < _invoiceList.length; i++)
                buildInvoiceExpansionTile(_invoiceList[i], i)
            ]),
      ),
    );
  }

  Widget buildInvoiceExpansionTile(
      InvoiceDetails currentInvoiceDetails, int index) {
    if (currentInvoiceDetails.status == 'cancelled') {
      return Container(
          child: Card(
              child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                  child: InkWell(
                onTap: () {
                  CommonNavigation.navigationToInvoiceDesign(
                    context,
                    widget.transactionName,
                    widget.transactionId,
                    _transactionsList.length > 0
                        ? _transactionsList[0].transactionDate.toString()
                        : null,
                    currentInvoiceDetails.billNo.toString(),
                    currentInvoiceDetails.invoiceId,
                  );
                },
                child: Text(
                  Language().getString(Constants.INVOICE, selectedLang) +
                      "  #${currentInvoiceDetails.billNo}",
                  style: TextStyle(
                      fontSize: 15.0,
                      fontWeight: FontWeight.bold,
                      color: Color(Constants.APP_COLOR),
                      decoration: TextDecoration.underline),
                ),
              )),
              Container(
                  margin: EdgeInsets.only(top: 5.0),
                  child: Row(children: [
                    Text(
                      Constants.STATUS_STRING + " : ",
                      style: TextStyle(
                          fontSize: 15.0,
                          fontWeight: FontWeight.bold,
                          color: Color(Constants.APP_COLOR)),
                    ),
                    Text(
                        Language().getString(
                            Constants.THIS_INVOICE_CANCELLED, selectedLang),
                        style: TextStyle(fontSize: 14.0, color: Colors.red))
                  ]))
            ]),
      )));
    } else {
      return Container(
        margin: EdgeInsets.symmetric(
          vertical: 2.0,
        ),
        decoration: AppUtills.boxDecoration(),
        child: ExpansionTile(
          title: Container(
            alignment: Alignment.centerLeft,
            child: InkWell(
              onTap: () {
                CommonNavigation.navigationToInvoiceDesign(
                  context,
                  widget.transactionName,
                  widget.transactionId,
                  _transactionsList.length > 0
                      ? _transactionsList[0].transactionDate.toString()
                      : null,
                  currentInvoiceDetails.billNo.toString(),
                  currentInvoiceDetails.invoiceId,
                );
              },
              child: Text(
                  Language().getString(Constants.INVOICE, selectedLang) +
                      " #${currentInvoiceDetails.billNo}",
                  style: TextStyle(
                      color: Color(Constants.APP_COLOR),
                      fontWeight: FontWeight.bold,
                      decoration: TextDecoration.underline)),
            ),
          ),
          subtitle: showResolution(currentInvoiceDetails),
          children: (appendInvoiceData.length > index)
              ? showInvoiceStockReceiveDetails(appendInvoiceData[index]!, index,
                  currentInvoiceDetails.invoiceId)
              : [Container()],
          onExpansionChanged: (value) {
            if (value) {
              actualDeliveryTime = Constants.SELECT_TIME;
              deliveryDate = Constants.SELECT_DATE;
              getInvoiceDetailsByInvoiceId(currentInvoiceDetails.invoiceId)
                  .then((value) {
                setState(() {
                  invoiceDetailsList.clear();
                  _invoiceProductsList.clear();
                  productsConversionTypeList.clear();
                  _trackingDropdownValueUpdate[index] = null;
                  invoiceDetailsList.addAll(value);
                  if (invoiceDetailsList.length > 0) {
                    appendInvoiceData[index] =
                        invoiceDetailsList[0].invoiceDetails;
                    _invoiceProductsList.addAll(invoiceDetailsList[0]
                                .invoiceDetails!
                                .replacedProducts!
                                .length >
                            0
                        ? invoiceDetailsList[0]
                            .invoiceDetails!
                            .replacedProducts!
                        : invoiceDetailsList[0].invoiceDetails!.products!);
                  }
                });
              });
            }
          },
        ),
      );
    }
  }

  List<Widget> showInvoiceStockDetails(
      InvoiceDetails invoiceDetailsById, int index, String? invoiceId) {
    if (invoiceDetailsById.orderTrackDetails != null) {
      // if (_usersList.length > 0 && invoiceDetailsById.receivedBy.isEmpty) {
      //   for (int i = 0; i < _usersList.length; i++) {
      //     updateUserDropdownValue.add(null);
      //     if (invoiceDetailsById.receivedBy == _usersList[i].name) {
      //       setState(() {
      //         userDropdownvalue = _usersList[i];
      //         updateUserDropdownValue[i] = _usersList[i];
      //       });
      //     }
      //   }
      // }

      bool isTransactionOffline = false;
      if (_transactionsList[0].isOffline!) {
        isTransactionOffline = true;
      }

      return [
        Divider(color: Color(Constants.APP_COLOR)),
        Container(
            padding: EdgeInsets.all(5.0),
            margin: EdgeInsets.symmetric(
              vertical: 5.0,
            ),
            child: buildRowText(Constants.DELIVERY_DUE_DATE,
                showExpectedDeliveryDateTime(invoiceDetailsById), 1, 3)),
        Container(
            padding: EdgeInsets.all(5.0),
            margin: EdgeInsets.symmetric(
              vertical: 5.0,
            ),
            child: buildRowText(Constants.DISPATCH_DELIVERY_DATE_TIME,
                showDispatchDeliveryDateTime(invoiceDetailsById), 1, 3)),
        Container(
          padding: EdgeInsets.all(5.0),
          margin: EdgeInsets.symmetric(
            vertical: 5.0,
          ),
          child: Row(
            children: [
              Expanded(
                  flex: 1,
                  child: Text(
                    Language().getString(
                        Constants.ACTUAL_DELIVERY_DATE, selectedLang),
                    style: TextStyle(
                        fontSize: 13.0,
                        color: Color(Constants.APP_COLOR),
                        fontWeight: FontWeight.bold),
                  )),
              Expanded(
                  flex: 2,
                  child: (isTransactionBuyer)
                      ? handlingBuyerStockView(invoiceDetailsById)
                      : showSellerDeliveryDateAndTimeView(invoiceDetailsById)),
            ],
          ),
        ),
        Container(
          padding: EdgeInsets.all(5.0),
          margin: EdgeInsets.symmetric(
            vertical: 5.0,
          ),
          child: Row(
            children: [
              Expanded(
                  flex: 1,
                  child: Text(
                    Language().getString(Constants.GRN_NUMBER, selectedLang),
                    style: TextStyle(
                        fontSize: 13.0,
                        color: Color(Constants.APP_COLOR),
                        fontWeight: FontWeight.bold),
                  )),
              Expanded(
                  flex: 2,
                  child: showReceivedByText(
                      invoiceDetailsById.orderTrackDetails!.grnNumber)),
            ],
          ),
        ),
        Container(
          padding: EdgeInsets.all(5.0),
          margin: EdgeInsets.symmetric(
            vertical: 5.0,
          ),
          child: Row(
            children: [
              Expanded(
                  flex: 1,
                  child: Text(
                    Language().getString(Constants.DOC_TYPE, selectedLang),
                    style: TextStyle(
                        fontSize: 13.0,
                        color: Color(Constants.APP_COLOR),
                        fontWeight: FontWeight.bold),
                  )),
              Expanded(
                flex: 2,
                child: designTrackingDetailsDropdown(
                    appendInvoiceData.length > index &&
                            appendInvoiceData[index]!
                                    .orderTrackDetails!
                                    .deliveryTrackingList!
                                    .length >
                                0
                        ? appendInvoiceData[index]!
                            .orderTrackDetails!
                            .deliveryTrackingList!
                        : [],
                    index),
              ),
            ],
          ),
        ),

        /// Checking delivery details
        (_trackingDropdownValueUpdate[index] != null)
            ? Container(
                padding: EdgeInsets.all(5.0),
                margin: EdgeInsets.symmetric(
                  vertical: 5.0,
                ),
                child: buildRowText(
                    "${_trackingDropdownValueUpdate[index]!.docType} no",
                    "${_trackingDropdownValueUpdate[index]!.docNumber}",
                    1,
                    3))
            : Container(),
        Container(
          padding: EdgeInsets.all(5.0),
          margin: EdgeInsets.symmetric(
            vertical: 5.0,
          ),
          child: Row(
            children: [
              Expanded(
                  flex: 1,
                  child: Text(
                    Language().getString(Constants.RECEIVED_BY, selectedLang),
                    style: TextStyle(
                        fontSize: 13.0,
                        color: Color(Constants.APP_COLOR),
                        fontWeight: FontWeight.bold),
                  )),
              Expanded(
                  flex: 2,
                  child: (isTransactionBuyer)
                      ? (invoiceDetailsById.receivedBy!.isEmpty)
                          ? showReceivedByText(userName)
                          :
                          // ? this.buildUserDropdown(index)
                          // :
                          showReceivedByText(invoiceDetailsById.receivedBy)
                      // (invoiceDetailsById.receivedBy)
                      : showReceivedByText(invoiceDetailsById.receivedBy)),
            ],
          ),
        ),
        Container(
          padding: EdgeInsets.all(5.0),
          margin: EdgeInsets.symmetric(
            vertical: 5.0,
          ),
          child: Row(
            children: [
              Expanded(
                  flex: 1,
                  child: Text(
                    Language().getString(
                        Constants.STOCk_RECEIVED_STATUS, selectedLang),
                    style: TextStyle(
                        fontSize: 13.0,
                        color: Color(Constants.APP_COLOR),
                        fontWeight: FontWeight.bold),
                  )),
              if (CommonMethods.isPrivillegeExist(
                  context,
                  PrivillegesActions
                      .KEY_TRANSACTIONS_TRANSACTION_STEPS_STOCK_RECONCILIATION_STOCK_RECEIVE))
                Expanded(
                    flex: 2,
                    child: updateStockStatusView(
                        invoiceDetailsById, index, invoiceId)),
            ],
          ),
        ),

        Container(
          padding: EdgeInsets.all(5.0),
          margin: EdgeInsets.symmetric(
            vertical: 5.0,
          ),
          child: Row(
            children: [
              Expanded(
                flex: 1,
                child: Row(
                  children: [
                    Text(
                      Language().getString(Constants.RESOLUTION, selectedLang) +
                          "       ",
                      style: TextStyle(
                          fontSize: 13.0,
                          color: Color(Constants.APP_COLOR),
                          fontWeight: FontWeight.bold),
                    ),
                    Expanded(
                      child: Text(
                        ": ${invoiceDetailsById.stockReconciliation != null ? invoiceDetailsById.stockReconciliation!.status : " "}",
                        style: TextStyle(
                          fontSize: 13.0,
                          color: Color(Constants.APP_COLOR),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              (isTransactionOffline ||
                      invoiceDetailsById.stockReceivedStatus!.isEmpty ||
                      invoiceDetailsById.stockReceivedStatus == 'pending')
                  ? Container()
                  : gotoStockDiscussionPage(
                      invoiceStatus: invoiceDetailsById.stockReceivedStatus,
                      invoiceNo: invoiceDetailsById.billNo.toString(),
                      resolution: invoiceDetailsById.stockReconciliation != null
                          ? invoiceDetailsById.stockReconciliation!.status
                          : "",
                      invoiceId: invoiceId)
            ],
          ),
        ),
        if (CommonMethods.isPrivillegeExist(
            context,
            PrivillegesActions
                .KEY_TRANSACTIONS_TRANSACTION_STEPS_STOCK_RECONCILIATION_ADD_PHOTO))
          pickFileFromDevice((isTransactionBuyer &&
                  invoiceDetailsById.status != Constants.CANCELLED &&
                  invoiceDetailsById.stockReceivedStatus != 'received')
              ? true
              : false),
      ];
    } else {
      return [Container()];
    }
  }

  List<Widget> crtTransactionStockDesign(
      InvoiceDetails invoiceDetails, int index, String? _invoiceId) {
    // if (_usersList.length > 0 && invoiceDetails.receivedBy == "") {
    //   for (int i = 0; i < _usersList.length; i++) {
    //     updateUserDropdownValue.add(null);
    //     if (invoiceDetails.receivedBy == _usersList[i].name) {
    //       setState(() {
    //         userDropdownvalue = _usersList[i];
    //         updateUserDropdownValue[i] = _usersList[i];
    //       });
    //     }
    //   }
    // }
    bool isTransactionOffline = false;
    if (_transactionsList[0].isOffline!) {
      isTransactionOffline = true;
    }
    return [
      Divider(
        color: Color(Constants.APP_COLOR),
      ),
      Container(
          padding: EdgeInsets.all(5.0),
          margin: EdgeInsets.symmetric(
            vertical: 5.0,
          ),
          child: buildRowText(Constants.DELIVERY_DUE_DATE,
              this.showExpectedDeliveryDateTime(invoiceDetails), 1, 3)),
      Container(
          padding: EdgeInsets.all(5.0),
          margin: EdgeInsets.symmetric(
            vertical: 5.0,
          ),
          child: buildRowText(Constants.DISPATCH_DELIVERY_DATE_TIME,
              this.showDispatchDeliveryDateTime(invoiceDetails), 1, 3)),
      Container(
        padding: EdgeInsets.all(5.0),
        margin: EdgeInsets.symmetric(
          vertical: 5.0,
        ),
        child: Row(
          children: [
            Expanded(
                flex: 1,
                child: Text(
                  Language()
                      .getString(Constants.ACTUAL_DELIVERY_DATE, selectedLang),
                  style: TextStyle(
                      fontSize: 13.0,
                      color: Color(Constants.APP_COLOR),
                      fontWeight: FontWeight.bold),
                )),
            Expanded(
                flex: 2,
                child: (isTransactionBuyer)
                    ? this.handlingBuyerStockView(invoiceDetails)
                    : this.showSellerDeliveryDateAndTimeView(invoiceDetails)),
          ],
        ),
      ),

      Container(
        padding: EdgeInsets.all(5.0),
        margin: EdgeInsets.symmetric(
          vertical: 5.0,
        ),
        child: Row(
          children: [
            Expanded(
                flex: 1,
                child: Text(
                  Language().getString(Constants.GRN_NUMBER, selectedLang),
                  style: TextStyle(
                      fontSize: 13.0,
                      color: Color(Constants.APP_COLOR),
                      fontWeight: FontWeight.bold),
                )),
            Expanded(
                flex: 2,
                child: showReceivedByText(
                    invoiceDetails.ctrTransactionDetails != null
                        ? invoiceDetails.ctrTransactionDetails!.grnNumber
                        : "")),
          ],
        ),
      ),
      Container(
        padding: EdgeInsets.all(5.0),
        margin: EdgeInsets.symmetric(
          vertical: 5.0,
        ),
        child: Row(
          children: [
            Expanded(
                flex: 1,
                child: Text(
                  Language().getString(Constants.DOC_TYPE, selectedLang),
                  style: TextStyle(
                      fontSize: 13.0,
                      color: Color(Constants.APP_COLOR),
                      fontWeight: FontWeight.bold),
                )),
            Expanded(
                flex: 2,
                child: designTrackingDetailsDropdown(
                    this.getCtrTrackingDetailsList(index), index)),
          ],
        ),
      ),

      /// Checking delivery details
      (_trackingDropdownValueUpdate[index] != null)
          ? Container(
              padding: EdgeInsets.all(5.0),
              margin: EdgeInsets.symmetric(
                vertical: 5.0,
              ),
              child: buildRowText(
                  "${_trackingDropdownValueUpdate[index]!.docType} no",
                  "${_trackingDropdownValueUpdate[index]!.docNumber}",
                  1,
                  3))
          : Container(),
      Container(
        padding: EdgeInsets.all(5.0),
        margin: EdgeInsets.symmetric(
          vertical: 5.0,
        ),
        child: Row(
          children: [
            Expanded(
                flex: 1,
                child: Text(
                  Language().getString(Constants.RECEIVED_BY, selectedLang),
                  style: TextStyle(
                      fontSize: 13.0,
                      color: Color(Constants.APP_COLOR),
                      fontWeight: FontWeight.bold),
                )),
            Expanded(
                flex: 2,
                child: (isTransactionBuyer)
                    ? (invoiceDetails.receivedBy!.isEmpty)
                        ? showReceivedByText(userName)
                        // this.buildUserDropdown(index)
                        : showReceivedByText(invoiceDetails.receivedBy)
                    : showReceivedByText(invoiceDetails.receivedBy)),
          ],
        ),
      ),
      Container(
        padding: EdgeInsets.all(5.0),
        margin: EdgeInsets.symmetric(
          vertical: 5.0,
        ),
        child: Row(
          children: [
            Expanded(
                flex: 1,
                child: Text(
                  Language()
                      .getString(Constants.STOCk_RECEIVED_STATUS, selectedLang),
                  style: TextStyle(
                      fontSize: 13.0,
                      color: Color(Constants.APP_COLOR),
                      fontWeight: FontWeight.bold),
                )),
            Expanded(
                flex: 2,
                child: this
                    .updateStockStatusView(invoiceDetails, index, _invoiceId)),
          ],
        ),
      ),
      Container(
        padding: EdgeInsets.all(5.0),
        margin: EdgeInsets.symmetric(
          vertical: 5.0,
        ),
        child: Row(
          children: [
            Expanded(
              flex: 1,
              child: Row(
                children: [
                  Text(
                    Language().getString(Constants.RESOLUTION, selectedLang) +
                        "       ",
                    style: TextStyle(
                        fontSize: 13.0,
                        color: Color(Constants.APP_COLOR),
                        fontWeight: FontWeight.bold),
                  ),
                  Expanded(
                    child: Text(
                      ": ${invoiceDetails.stockReconciliation != null ? invoiceDetails.stockReconciliation!.status : " "}",
                      style: TextStyle(
                        fontSize: 13.0,
                        color: Color(Constants.APP_COLOR),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            (isTransactionOffline ||
                    invoiceDetails.stockReceivedStatus!.isEmpty ||
                    invoiceDetails.stockReceivedStatus == 'pending')
                ? Container()
                : this.gotoStockDiscussionPage(
                    invoiceStatus: invoiceDetails.stockReceivedStatus,
                    invoiceNo: invoiceDetails.billNo.toString(),
                    resolution: invoiceDetails.stockReconciliation != null
                        ? invoiceDetails.stockReconciliation!.status
                        : "",
                    invoiceId: invoiceDetailsList.length > 0
                        ? invoiceDetailsList[0].invoiceId
                        : "")
          ],
        ),
      ),
      this.pickFileFromDevice((isTransactionBuyer &&
              invoiceDetails.stockReceivedStatus != 'received')
          ? true
          : false),
    ];
  }

  Widget gotoStockDiscussionPage(
      {String? invoiceStatus,
      String? invoiceNo,
      String? resolution,
      String? invoiceId}) {
    if (CommonMethods.isPrivillegeExist(
        context,
        PrivillegesActions
            .KEY_TRANSACTIONS_TRANSACTION_STEPS_STOCK_RECONCILIATION_GO_TO_RECONCILIATION)) {
      return Expanded(
          flex: 1,
          child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: theme.colorScheme.primary,
                  padding:
                      EdgeInsets.all(5)), //CommonMethods.elevatedButtonStyle(),
              onPressed: () {
                if (_transactionsList.length > 0 &&
                    _transactionsList[0].buyer!.id == buId &&
                    invoiceStatus == "pending") {
                  Dialogs.yesCancelDialog(
                      context,
                      Language().getString(Constants.INFO, selectedLang),
                      Language().getString(
                          Constants.PLEASE_UPDATE_STATUS, selectedLang),
                      Language().getString(Constants.OKAY_STR, selectedLang),
                      "",
                      false);
                } else {
                  Navigator.push(
                          context,
                          PageTransition(
                              context: context,
                              page: StockReconciliationPage(
                                  transactionName: widget.transactionName,
                                  transactionId: widget.transactionId,
                                  invoiceNo: invoiceNo,
                                  resolution: resolution,
                                  invoiceId: invoiceId)))
                      .then((value) => this.loadTransactionData());
                }
              },
              child: Container(
                child: Text(
                  Language().getString(
                      Constants.GO_TO_RECONCILIATION_DISCUSSION, selectedLang),
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 12.0, color: Colors.white),
                ),
              )));
    } else {
      return SizedBox();
    }
  }

  List<Widget> showInvoiceCancelView(InvoiceDetails invoiceDetails) {
    return [
      Divider(
        color: Color(Constants.APP_COLOR),
      ),
      Container(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(Language()
              .getString(Constants.THIS_INVOICE_CANCELLED, selectedLang)),
        ),
      )
    ];
  }

  showReceivedByText(String? receivedBy) {
    return Container(
      child: Text(
        ": $receivedBy",
        style: TextStyle(
          fontSize: 13.0,
          color: Color(Constants.APP_COLOR),
        ),
      ),
    );
  }

  showSellerDeliveryDateAndTimeView(InvoiceDetails invoiceDetails) {
    return Container(
      child: Text(
        ": ${invoiceDetails.actualDeliveryDate} " +
            "${invoiceDetails.actualDeliveryTime}",
        style: TextStyle(
          fontSize: 13.0,
          color: Color(Constants.APP_COLOR),
        ),
      ),
    );
  }

  handlingBuyerStockView(InvoiceDetails invoiceDetails) {
    if (invoiceDetails.actualDeliveryDate!.isNotEmpty &&
        invoiceDetails.actualDeliveryTime!.isNotEmpty) {
      return Container(
        child: Text(
          ": ${invoiceDetails.actualDeliveryDate} " +
              "${invoiceDetails.actualDeliveryTime}",
          style: TextStyle(
            fontSize: 13.0,
            color: Color(Constants.APP_COLOR),
          ),
        ),
      );
    } else {
      return Container(
        child: Row(
          children: [
            Row(
              children: [
                Text(
                  ": $deliveryDate",
                  style: TextStyle(
                    fontSize: 13.0,
                    color: Color(Constants.APP_COLOR),
                  ),
                ),
                InkWell(
                  onTap: () async {
                    deliveryDate = await AppUtills.getSelectedDate(context,
                        isShowTodayDate: true);
                    setState(() {
                      deliveryDate = deliveryDate;
                    });
                  },
                  child: Container(
                    child: Icon(
                      Icons.calendar_today,
                      color: Colors.blue,
                    ),
                  ),
                )
              ],
            ),
            Row(
              children: [
                Container(
                  margin: EdgeInsets.only(left: 3.0),
                  child: Text(
                    ": $actualDeliveryTime",
                    style: TextStyle(
                      fontSize: 13.0,
                      color: Color(Constants.APP_COLOR),
                    ),
                  ),
                ),
                InkWell(
                  onTap: () async {
                    actualDeliveryTime =
                        await AppUtills.getSelectedTime(context);
                    setState(() {
                      actualDeliveryTime = actualDeliveryTime;
                    });
                  },
                  child: Container(
                    child: Icon(Icons.access_time, color: Colors.blue),
                  ),
                )
              ],
            )
          ],
        ),
      );
    }
  }

  Widget updateStockStatusView(
      InvoiceDetails invoiceDetails, int index, String? _invoiceId) {
    return Container(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            child: Text(
              ": ${invoiceDetails.stockReceivedStatus != null ? invoiceDetails.stockReceivedStatus : ""}",
              style: TextStyle(
                fontSize: 13.0,
                color: Color(Constants.APP_COLOR),
              ),
            ),
          ),
          (isTransactionBuyer &&
                  invoiceDetails.stockReceivedStatus != 'received')
              ? (_transactionPrivileges!.receive_stocks)
                  ? Container(
                      height: 30.0,
                      padding: EdgeInsets.all(3.0),
                      decoration: BoxDecoration(
                          color: (deliveryDate != "")
                              ? theme.colorScheme.primary
                              : Colors.grey,
                          borderRadius: BorderRadius.circular(7.0)),
                      alignment: Alignment.center,
                      child: InkWell(
                        onTap: () async {
                          String errorMessage = validateMandatoryFields();
                          if (errorMessage.isNotEmpty) {
                            Dialogs.yesCancelDialog(
                                context,
                                Language()
                                    .getString(Constants.ERROR, selectedLang),
                                Language()
                                    .getString(errorMessage, selectedLang),
                                Language().getString(
                                    Constants.OKAY_STR, selectedLang),
                                "",
                                false);
                          } else {
                            // if (updateUserDropdownValue[index] == null) {
                            //   Dialogs.yesCancelDialog(
                            //       context,
                            //       Language()
                            //           .getString(Constants.INFO, selectedLang),
                            //       Language().getString(
                            //           Constants.PLEASE_SELECT_USER,
                            //           selectedLang),
                            //       Language().getString(
                            //           Constants.OKAY_STR, selectedLang),
                            //       "",
                            //       false);
                            // } else {
                            // if (_transactionsList[0].transactionType ==
                            //         Constants.KEY_RAW_MATERIAL &&
                            //     _productConsumptionPrivileges
                            //         .view_raw_material) {
                            //   this.showStockReceivedChoiceDialog(
                            //       invoiceId: _invoiceId,
                            //       billNo: invoiceDetails.billNo);
                            // } else {
                            setState(() {
                              productsConversionTypeList.clear();
                            });
                            showReceivedProductsConversionType(
                                invoiceId: _invoiceId,
                                billNo: invoiceDetails.billNo,
                                invoiceProducts: _invoiceProductsList);

                            //   }
                            // }
                          }
                        },
                        child: Text(
                          Language().getString(
                              Constants.STOCK_RECEIVED, selectedLang),
                          style: TextStyle(color: Colors.white, fontSize: 12.0),
                        ),
                      ),
                    )
                  : Container()
              : Container(),
        ],
      ),
    );
  }

  String validateMandatoryFields() {
    if (deliveryDate.isEmpty || deliveryDate == Constants.SELECT_DATE) {
      return Constants.PLEASE_SELECT_ACTUAL_DELIVERY_DATE;
    } else if (actualDeliveryTime.isEmpty ||
        actualDeliveryTime == Constants.SELECT_TIME) {
      return Constants.PLEASE_SELECT_ACTUAL_DELIVERY_TIME;
    } else {
      return "";
    }
  }

  serviceCallUpdateStockInvoiceDetails(
      dynamic invoiceNo, String? _receivedUser, String? invoiceId,
      {bool isOfflineStock = false, String? receivedType = ""}) async {
    List<Map<String, dynamic>> _products = [];
    var productObj;
    if (_transactionsList[0].isOffline!) {
      for (int i = 0; i < _invoiceProductsList.length; i++) {
        productObj = {
          "id": _invoiceProductsList[i].id,
        };
        _products.add(productObj);
      }
    } else {
      for (int i = 0; i < _invoiceProductsList.length; i++) {
        productObj = {
          "id": _invoiceProductsList[i].id,
          "conversion_type":
              productsConversionTypeList[i] == Constants.SALABLE_PRODUCTS
                  ? "product"
                  : "raw_material"
        };
        _products.add(productObj);
      }
    }

    Map data = {
      "txnId": _transactionsList[0].id,
      "bill_no": invoiceNo,
      "actual_delivery_date": deliveryDate,
      "actual_delivery_time": actualDeliveryTime,
      "stock_received_by": _receivedUser,
      "actual_delivery_date_time": _transactionsList[0].isOffline!
          ? deliveryDate + " " + actualDeliveryTime
          : AppUtills.convertDateTimeToUtc(
              selectedDate: deliveryDate, selectedTime: actualDeliveryTime),
      "stock_received_status": "received",
      "received_type": receivedType,
      "product_conversion": _products,
      // "images": relativePath
    };

    String body = json.encode(data);
    var response = await _transactionService
        .updateStockStatus(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      // updateUserDropdownValue.clear();
      if (isOfflineStock || !isFileSelected) {
        this.loadTransactionData();
      } else {
        this.uploadFile(pickedFile!, invoiceId);
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          "${_grpcResponse.message}",
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  serviceCallUpdatePaymentInvoiceDetails(
      dynamic invoiceNo, String? _receivedUser) async {
    Map data = {
      "txnId": _transactionsList[0].id,
      "bill_no": invoiceNo,
      "payment_date": deliveryDate,
      "payment_time": actualDeliveryTime,
      "payment_received_by": _receivedUser,
      "payment_received_status": "received"
    };

    String body = json.encode(data);

    var response = await _transactionService
        .updatePaymentReceivedReconciliation(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;

    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      loadTransactionData();
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    // http.Response response =
    //     await _service.updatePaymentReconciliation(body).catchError((onError) {
    //   setState(() {
    //     isLoadingProgress = false;
    //   });
    //   Dialogs.yesCancelDialog(
    //       context,
    //       Language().getString(Constants.ERROR, selectedLang),
    //       onError.toString(),
    //       Language().getString(Constants.OKAY_STR, selectedLang),
    //       "",
    //       false);
    // });

    // setState(() {
    //   isLoadingProgress = false;
    // });
    // if (response.statusCode == 200) {
    //   // updateUserDropdownValue.clear();
    //   loadTransactionData();
    // } else if (response.statusCode == 401) {
    //   CommonMethods.handleUnauthorizedAccess(context);
    // } else {
    //   var data = json.decode(response.body);
    //   Dialogs.yesCancelDialog(
    //       context,
    //       Language().getString(Constants.ERROR, selectedLang),
    //       data['message'],
    //       Language().getString(Constants.OKAY_STR, selectedLang),
    //       "",
    //       false);
    // }
  }

  Widget buildUserDropdown(int index) {
    return Row(
      children: [
        Container(
          child: Text(
            ": ",
            style: TextStyle(
              fontSize: 13.0,
              color: Color(Constants.APP_COLOR),
            ),
          ),
        ),
        Expanded(
          child: Container(
              height: 30.0,
              decoration: AppUtills.boxDecoration(),
              padding: EdgeInsets.all(2),
              child: DropdownButton<UserModel>(
                  // value: index < updateUserDropdownValue.length
                  //     ? updateUserDropdownValue[index]
                  //     : null,
                  hint: new Text(
                      Language().getString(Constants.SELECT, selectedLang)),
                  isExpanded: true,
                  underline: SizedBox(),
                  onChanged: (UserModel? data) {
                    setState(() {
                      // updateUserDropdownValue[index] = data;
                      userDropdownvalue = data;
                    });
                  },
                  items: _usersList.map((UserModel model) {
                    return new DropdownMenuItem<UserModel>(
                      child: new Text(model.name!),
                      value: model,
                    );
                  }).toList())),
        ),
      ],
    );
  }

  Future<List<UserModel>> getAllUsers(String? buId) async {
    _usersList.clear();

    String body = json.encode({"id": buId, "filters": {}});

    var response = await _userService
        .getUserByBuId_grpc(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    List<UserModel> _users = [];
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      var resultArray = resObj['results'];
      for (var data in resultArray) {
        _users.add(UserModel.fromJson(data));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
      return _users;
  }

  Widget buildRowText(
      String title, String value, int firseFlex, int secondFlex) {
    return Container(
      child: Row(
        children: [
          Expanded(
              flex: 1,
              child: Text(
                Language().getString(title, selectedLang),
                style: TextStyle(
                    fontSize: 13.0,
                    color: Color(Constants.APP_COLOR),
                    fontWeight: FontWeight.bold),
              )),
          Expanded(
              flex: 2,
              child: Text(
                ":  $value",
                style: TextStyle(
                  fontSize: 13.0,
                  color: Color(Constants.APP_COLOR),
                ),
              )),
        ],
      ),
    );
  }

  Widget buildRowPaymentText(
      String title, String value, int firseFlex, int secondFlex) {
    return Container(
      child: Row(
        children: [
          Expanded(
              flex: firseFlex,
              child: Text(
                Language().getString(title, selectedLang),
                style: TextStyle(
                    fontSize: 13.0,
                    color: Color(Constants.APP_COLOR),
                    fontWeight: FontWeight.bold),
              )),
          Expanded(
              flex: secondFlex,
              child: Text(
                ":  $value",
                style: TextStyle(
                  fontSize: 13.0,
                  color: Color(Constants.APP_COLOR),
                ),
              )),
        ],
      ),
    );
  }

  showResolution(InvoiceDetails invoiceDetails) {
    String? resolutionStatus = "";
    if (invoiceDetails.invoiceType == Constants.CTR3) {
      if (invoiceDetails.stockReconciliation != null) {
        resolutionStatus = invoiceDetails.stockReconciliation!.status;
      } else {
        resolutionStatus = Language()
            .getString(Constants.STOCK_DETAILS_NOT_UPDATED_YET, selectedLang);
      }
    } else {
      if (invoiceDetails.stockReconciliation != null) {
        resolutionStatus = invoiceDetails.stockReconciliation!.status;
      } else {
        resolutionStatus = "";
      }
    }
    if (invoiceDetails.status == "cancelled") {
      return Text(
          Language().getString(Constants.INVOICE_CANCELLED, selectedLang),
          style: TextStyle(
              color: Colors.red, fontSize: 15.0, fontWeight: FontWeight.bold));
    } else {
      return Text(
        Language().getString(Constants.RESOLUTION, selectedLang) +
            " : $resolutionStatus",
        style: TextStyle(
          fontSize: 13.0,
        ),
      );
    }
  }

  serviceCallPaymentReceived(dynamic billNo, String? invoiceId) async {
    Map data = {
      "txnId": widget.transactionId,
      "bill_no": billNo,
      "received_amount": double.parse(_payAmount.text.trim()),
      "received_date": showSelectedDate,
      "invoice_id": invoiceId
    };
    String body = json.encode(data);
    var response = await _transactionService
        .updatePaymentReceivedAmount(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
      isShowSmallCircularIndicator = false;
    });

    GRPCResponse _grpcResponse = response;

    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      loadTransactionData(updatePendingAmount: true);
      setState(() {
        _payAmount.clear();
        showSelectedDate = Constants.SELECT_DATE;
      });
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  Widget designTrackingDetailsDropdown(
      List<TrackingDetailsDAO> trackingList, int index) {
    if (trackingList.length > 0) {
      if (_trackingDropdownValueUpdate[index] == null) {
        _trackingDropdownValueUpdate[index] = trackingList[0];
      }

      return Container(
        child: Row(
          children: [
            Container(child: Text(": ")),
            Expanded(
              child: Container(
                height: 30.0,
                decoration: AppUtills.boxDecoration(),
                padding: EdgeInsets.all(2),
                child: DropdownButton<TrackingDetailsDAO>(
                  value: _trackingDropdownValueUpdate[index],
                  hint: new Text(
                      Language().getString(Constants.SELECT, selectedLang)),
                  isExpanded: true,
                  underline: SizedBox(),
                  onChanged: (TrackingDetailsDAO? data) {
                    setState(() {
                      _trackingDropdownValueUpdate[index] = data;
                    });
                  },
                  items: trackingList.map((TrackingDetailsDAO model) {
                    return new DropdownMenuItem<TrackingDetailsDAO>(
                      child: new Text(model.docType!),
                      value: model,
                    );
                  }).toList(),
                ),
              ),
            )
          ],
        ),
      );
    } else {
      return Container();
    }
  }

  Widget pickFileFromDevice(bool isStockReceivedPending) {
    return Container(
      margin: EdgeInsets.symmetric(
        vertical: 5.0,
      ),
      child: Column(
        children: [
          (isStockReceivedPending)
              ? this.showSelectedImage(pickedFile)
              : (invoiceDetailsList.length > 0)
                  ? this.loadStockReceivedServerImage()
                  : Container(),
          (isStockReceivedPending)
              ? Container(
                  height: 25.0,
                  margin: EdgeInsets.symmetric(vertical: 5.0),
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: theme.colorScheme.primary,
                        elevation: 0),
                    onPressed: () async {
                      if (kIsWeb) {
                        final _file = await Dialogs.getWebImage();
                        if (_file != null) {
                          _webImage = await _file.readAsBytes();
                          uploadImage(_webImage, imageName);
                        }
                      } else {
                        Dialogs.openBottomSheet(
                            context: context,
                            openCamera: (myPicture) async {
                              this.updateProductImage(myPicture);
                            },
                            openGallery: (myPicture) async {
                              this.updateProductImage(myPicture);
                            });
                      }
                    },
                    child: Text(
                      Language().getString(
                          Constants.ATTACH_FILE_OR_PHOTO, selectedLang),
                      style: TextStyle(color: Colors.white, fontSize: 13.0),
                    ),
                  ),
                )
              : Container()
        ],
      ),
    );
  }

  updateProductImage(var fileImage) {
    Navigator.of(context).pop();
    if (fileImage != null) {
      setState(() {
        pickedFile = fileImage;
        isFileSelected = true;
        // imageBlob = AppUtills.getBase64Image(fileImage, context);
      });
      uploadImage(pickedFile, "");
    }
  }

  uploadImage(dynamic imageData, String fileName) async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = "Getting url..";
    });
    Map data = {
      "filename": (kIsWeb) ? fileName : imageData.path.split("/").last,
      "location": "stock_received"
    };
    String body = json.encode(data);

    http.Response response = await _service.getPresignedUrl(body);
    //get_file_upload_url(null);

    if (response.statusCode == 200) {
      var responseBody = json.decode(response.body);
      setState(() {
        progressMessage = 'Uploading image..';
      });
      var uploadFileRes =
          await _service.uploadToS3Signed(responseBody['url'], imageData);
      print(uploadFileRes);
      setState(() {
        relativePath = responseBody['relativepath'];
        isLoadingProgress = false;
      });
      Toast.show(
        "File uploaded!",
        duration: Toast.lengthShort,
        gravity: Toast.bottom,
      );
    } else {
      setState(() {
        isLoadingProgress = false;
      });
    }
  }

  Widget showSelectedImage(File? _file) {
    if (_file == null) {
      return Container(
        child: Image.asset(
          "assets/images/empty.jpg",
          gaplessPlayback: true,
          height: 50.0,
          width: 50.0,
        ),
      );
    } else {
      if (lookupMimeType(_file.path) == "application/pdf") {
        return Container(
          child: InkWell(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ShowPdfPage(path: _file.path),
                ),
              );
            },
            child: Text(
              _file.path.split("/").last,
              style: TextStyle(
                  color: Color(Constants.APP_COLOR),
                  fontSize: 15.0,
                  decoration: TextDecoration.underline),
            ),
          ),
        );
      } else {
        return Container(
          child: InkWell(
            onTap: () {
              Navigator.push(
                context,
                PageTransition(
                    context: context,
                    page: HeroTagExample(
                      tagName: "My image",
                      fileImage: pickedFile!.path,
                      imageFrom: Constants.GALLERY_IMAGE,
                    )),
              );
            },
            child: (kIsWeb)
                ? Image.memory(
                    _webImage!,
                    gaplessPlayback: true,
                    height: 50.0,
                    width: 70.0,
                  )
                : Image.file(
                    new File(pickedFile!.path),
                    gaplessPlayback: true,
                    height: 50.0,
                    width: 70.0,
                  ),
          ),
        );
      }
    }
  }

  uploadFile(File file, String? invoiceId) async {
    String imageBlob = "";
    setState(() {
      isLoadingProgress = true;
      progressMessage = Constants.UPDATING;
    });
    if (lookupMimeType(file.path) == "application/pdf") {
      Map<String, String?> headers = {
        "authorization": AppController.instance.getAuthorizationKey,
        "content-type": "application/pdf",
      };

      var uploadUrl =
          Uri.parse(Constants.NEW_BASE_URL + "invoice/image-pdf/$invoiceId");

      http.MultipartRequest _request =
          new http.MultipartRequest("PUT", uploadUrl);
      http.MultipartFile multipartFile = await http.MultipartFile.fromPath(
          "sign", file.path,
          contentType: new MediaType('application', 'pdf'));

      _request.files.add(multipartFile);
      _request.headers.addAll(headers as Map<String, String>);

      StreamedResponse response = await _request.send();
      setState(() {
        isLoadingProgress = false;
      });
      response.stream.transform(utf8.decoder).listen((value) {
        var _response = json.decode(value);
        if (_response['status'] == "success") {
          this.loadTransactionData();
        } else {
          Dialogs.yesCancelDialog(
              context,
              Language().getString(Constants.ERROR, selectedLang),
              "$response",
              Language().getString(Constants.OKAY_STR, selectedLang),
              "",
              false);
        }
      });
    } else {
      imageBlob = AppUtills.getBase64Image(file, context);
      String body = json.encode({"images": imageBlob});
      http.Response response = await _service
          .uploadStockReceivedImage(body, invoiceId)
          .catchError((onError) {
        setState(() {
          isLoadingProgress = false;
        });
        Dialogs.yesCancelDialog(
            context,
            Language().getString(Constants.ERROR, selectedLang),
            onError.toString(),
            Language().getString(Constants.OKAY_STR, selectedLang),
            "",
            false);
      });

      if (response.statusCode == 200) {
        this.loadTransactionData();
      } else if (response.statusCode == 401) {
        CommonMethods.handleUnauthorizedAccess(context);
      } else {
        Dialogs.yesCancelDialog(
            context,
            Language().getString(Constants.ERROR, selectedLang),
            response.body,
            Language().getString(Constants.OKAY_STR, selectedLang),
            "",
            false);
      }
    }
  }

  Future<List<InvoiceDataDAO>> getInvoiceDetailsByInvoiceId(
      String? invoiceId) async {
    setState(() {
      isLoadingProgress = true;
    });
    String body = json.encode({"id": invoiceId});

    var response = await _transactionService
        .getInvoiceDetailsByInvoiceId(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    List<InvoiceDataDAO> list = [];
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      bool isString = false;
      if (resObj is String) {
        isString = true;
      }
      if (!isString) {
        list.add(InvoiceDataDAO.fromJson(resObj[0]));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return list;
  }

  Widget loadStockReceivedServerImage() {
    if (invoiceDetailsList[0].imageDps!.length > 0) {
      String url = Constants.NEW_BASE_URL +
          "invoice/photoimgs/${invoiceDetailsList[0].imageDps![0].image}";
      return Container(
        child: InkWell(
            onTap: () {
              Navigator.push(
                context,
                PageTransition(
                    context: context,
                    page: ShowServerImagePage(
                      tagName: "My image",
                      fileImage: invoiceDetailsList[0].imageDps![0].image,
                      imageFrom: Constants.SERVER_IMAGE,
                      imageUrl: url,
                    )),
              );
            },
            child: Image.network(
              url,
              headers: {
                'Content-type': 'application/json',
                'Accept': 'application/json',
                'authorization': AppController.instance.getAuthorizationKey
              },
              gaplessPlayback: true,
              width: 80.0,
              height: 80.0,
              fit: BoxFit.fill,
              errorBuilder: (BuildContext context, Object exception,
                  StackTrace? stackTrace) {
                return Image.asset('assets/images/empty.jpg',
                    width: 80,
                    height: 80,
                    gaplessPlayback: true,
                    fit: BoxFit.fill);
              },
            )),
      );
    } else if (invoiceDetailsList[0].invoiceAttachment!.isNotEmpty) {
      return Container(
        margin: EdgeInsets.symmetric(vertical: 10.0),
        child: InkWell(
          onTap: () {
            /**
             * Here we are connection to WEBVIEW in APP, Please check condition for web
             */
            Navigator.push(
                context,
                PageTransition(
                    context: context,
                    page: InvoiceWebViewPage(
                      isFromReconciliationPage: true,
                      invoiceId: invoiceDetailsList[0].invoiceId,
                      transactionId: invoiceDetailsList[0].invoiceAttachment,
                    )));
          },
          child: Text(
            invoiceDetailsList[0].invoiceAttachment!,
            style: TextStyle(
                color: Color(Constants.APP_COLOR),
                fontSize: 17.0,
                fontWeight: FontWeight.w500,
                decoration: TextDecoration.underline),
          ),
        ),
      );
    } else {
      return Container();
    }
  }

  showStockReceivedChoiceDialog({String? invoiceId, num? billNo}) {
    rawMaterialRadioButtonValue = Constants.KEY_RAW_MATERIAL;
    return showDialog(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(15.0)),
              ),
              title: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Expanded(
                    child: Text(
                      Language().getString(Constants.ORDER_FOR, selectedLang),
                      style: TextStyle(
                          color: Color(Constants.APP_COLOR),
                          fontSize: 18.0,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      rawMaterialRadioButtonValue = null;
                      actualProductsRadioButionVaue = null;
                      Navigator.of(context).pop();
                    },
                    child: Icon(
                      Icons.close,
                      color: Colors.red,
                    ),
                  ),
                  SizedBox(
                    height: 2.5,
                  ),
                ],
              ),
              content:
                  StatefulBuilder(builder: (context, StateSetter setState) {
                return this.showTransactionTypeRadioButtonView(
                    invoiceId: invoiceId, billNo: billNo, setState: setState);
              }));
        });
  }

  Widget showTransactionTypeRadioButtonView(
      {String? invoiceId, dynamic billNo, StateSetter? setState}) {
    return Container(
      height: 150.0,
      child: Column(
        children: [
          Row(
            children: [
              Radio(
                value: Constants.SALABLE_PRODUCTS,
                activeColor: Color(Constants.APP_COLOR),
                groupValue: actualProductsRadioButionVaue,
                onChanged: (dynamic value) {
                  setState!(() {
                    actualProductsRadioButionVaue = value;
                    rawMaterialRadioButtonValue = null;
                  });
                },
              ),
              Text(Language()
                  .getString(Constants.SALABLE_PRODUCTS, selectedLang)),
            ],
          ),
          Row(
            children: [
              Radio(
                value: Constants.KEY_RAW_MATERIAL,
                activeColor: Color(Constants.APP_COLOR),
                groupValue: rawMaterialRadioButtonValue,
                onChanged: (dynamic value) {
                  setState!(() {
                    rawMaterialRadioButtonValue = value;
                    actualProductsRadioButionVaue = null;
                  });
                },
              ),
              Text(Language().getString(Constants.RAW_MATERIALS, selectedLang)),
            ],
          ),
          Container(
            width: MediaQuery.of(context).size.width,
            child: ElevatedButton(
              onPressed: () {
                if (rawMaterialRadioButtonValue == null &&
                    actualProductsRadioButionVaue == null) {
                  Dialogs.yesCancelDialog(
                      context,
                      Language().getString(Constants.ERROR, selectedLang),
                      Language().getString(
                          Constants.PLEASE_SELECT_ANY_OPTION, selectedLang),
                      Language().getString(Constants.OKAY_STR, selectedLang),
                      "",
                      false);
                } else {
                  Navigator.of(context).pop();
                  this.updateRawMaterialStockReceived(
                      receivedType: rawMaterialRadioButtonValue,
                      invoiceId: invoiceId,
                      billNo: billNo);
                }
              },
              style: CommonMethods.elevatedButtonStyle(),
              child: Text(
                Language().getString(Constants.CONFIRM, selectedLang),
                style: TextStyle(
                  color: Colors.white,
                ),
              ),
            ),
          )
        ],
      ),
    );
  }

  updateRawMaterialStockReceived(
      {String? receivedType = "", String? invoiceId, dynamic billNo}) async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
      });

      this.serviceCallUpdateStockInvoiceDetails(
          billNo, userName, invoiceId,
          receivedType: receivedType);
      // userDropdownvalue != null ? userDropdownvalue.name : "", invoiceId,
      // receivedType: receivedType);
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  showInvoiceStockReceiveDetails(
      InvoiceDetails invoiceDetails, int index, String? currentInvoiceId) {
    if (invoiceDetails.invoiceType == Constants.CTR3) {
      return crtTransactionStockDesign(invoiceDetails, index, currentInvoiceId);
    } else {
      return showInvoiceStockDetails(invoiceDetails, index, currentInvoiceId);
    }
  }

  bindingGeneratedInvoiceList() {
    setState(() {
      /// Checking Your bu id seller or buyer for handing views
      for (int j = 0; j < _transactionsList.length; j++) {
        if (_transactionsList[j].buyer!.id == buId) {
          isTransactionBuyer = true;
        }
      }
      if (_transactionsList[0].ctrDetails != null &&
          _transactionsList[0].ctrDetails!.type == Constants.CTR1) {
        for (int i = 0; i < _transactionsList[0].invoiceDetails!.length; i++) {
          if (_transactionsList[0].invoiceDetails![i].ctrTransactionDetails !=
              null) {
            _invoiceList.add(_transactionsList[0].invoiceDetails!.last);
            appendInvoiceData.add(InvoiceDetails());
            _trackingDropdownValueUpdate.add(null);
          }
        }
      } else {
        for (int i = 0; i < _transactionsList[0].invoiceDetails!.length; i++) {
          // if (_transactionsList[0].invoiceDetails[i].assignPackingDetails !=
          //     null) {
          //   _invoiceList.add(_transactionsList[0].invoiceDetails[i]);
          //   appendInvoiceData.add(InvoiceDetails());
          // } else

          if (_transactionsList[0].invoiceDetails![i].invoiceType ==
                  Constants.CTR3 &&
              _transactionsList[0].invoiceDetails![i].ctrTransactionDetails !=
                  null) {
            if (_transactionsList[0].invoiceDetails![i].packageDetails !=
                null) {
              _invoiceList.add(_transactionsList[0].invoiceDetails![i]);
              appendInvoiceData.add(InvoiceDetails());
              _trackingDropdownValueUpdate.add(null);
            }
          } else {
            if (_transactionsList[0].invoiceDetails![i].orderTrackDetails !=
                    null &&
                (_transactionsList[0].invoiceDetails![i].packageDetails !=
                        null ||
                    _transactionsList[0]
                            .invoiceDetails![i]
                            .assignPackingDetails !=
                        null)) {
              //
              _invoiceList.add(_transactionsList[0].invoiceDetails![i]);
              appendInvoiceData.add(InvoiceDetails());
              _trackingDropdownValueUpdate.add(null);
            }
          }
        }
      }
    });
  }

  showStockReceiveInvoiceView() {
    if (_invoiceList.length > 0) {
      return Container(
        decoration: AppUtills.appBackgroundWithImage(),
        padding: EdgeInsets.all(10.0),
        child: Column(children: <Widget>[
          TransactionDetailsViewPage(
              transactionName: widget.transactionName,
              transactionId: widget.transactionId,
              transactionDate: _transactionsList.length > 0
                  ? _transactionsList[0].transactionDate.toString()
                  : null,
              namesData: _namesData),
          Expanded(
            child: Container(
              margin: EdgeInsets.symmetric(
                vertical: 10.0,
              ),
              child:
                  (widget.reconciliationName == Constants.STOCK_RECONCILIATION)
                      ? designForStockReconciliation()
                      : this.designForPaymentReconciliation(),
            ),
          )
        ]),
      );
    } else if(_transactionsList.isNotEmpty && _transactionsList[0].isOffline!) {
      return AppUtills.showTransactionNotApplicableMessage();
    }else{
      return AppUtills.showTransactionStageMessage();
    }
  }

  showReceivedPaymentData(List<ReceivedPaymentDAO>? paymentData, int index) {
    if (paymentData != null && paymentData.length > 0) {
      return ListView.separated(
        shrinkWrap: true,
        reverse: true,
        physics: NeverScrollableScrollPhysics(),
        itemBuilder: (context, index) {
          return Container(
            margin: EdgeInsets.symmetric(horizontal: 10.0),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(children: [
                  Expanded(
                      child: Text(paymentData[index].receivedDate!,
                          style: TextStyle(
                              color: Color(Constants.APP_COLOR),
                              fontWeight: FontWeight.bold))),
                  Expanded(
                      child: Text(
                    "$orgCurrencySymbol" +
                        CommonMethods.getCurrencyValues(
                            paymentData[index].receivedAmount),
                    style: TextStyle(color: Color(Constants.APP_COLOR)),
                  )),
                ]),
              ),
            ),
          );
        },
        itemCount: paymentData.length,
        separatorBuilder: (context, index) =>
            new Divider(height: 0.0, color: Colors.transparent),
      );
    } else {
      return Container(height: 40.0);
    }
  }

  showPendingAmountView(num? pendingAmount) {
    return Container(
      padding: EdgeInsets.all(5.0),
      child: Row(
        children: [
          Text(
            Language().getString(Constants.PENDING_AMOUNT, selectedLang) +
                " :  ",
            style: TextStyle(
                fontSize: 13.0,
                color: Color(Constants.APP_COLOR),
                fontWeight: FontWeight.bold),
          ),
          Expanded(
              flex: 2,
              child: Row(
                children: [
                  Container(
                    child: Text(
                      "$orgCurrencySymbol" +
                          CommonMethods.getCurrencyValues(pendingAmount),
                      style: TextStyle(
                        fontSize: 13.0,
                        color: Color(Constants.APP_COLOR),
                      ),
                    ),
                  ),
                  (isShowSmallCircularIndicator)
                      ? Container(
                          margin: EdgeInsets.symmetric(horizontal: 5.0),
                          height: 15.0,
                          width: 15.0,
                          child: CircularProgressIndicator(
                            strokeWidth: 2.0,
                            valueColor: new AlwaysStoppedAnimation<Color?>(
                                Colors.greenAccent[700]),
                          ),
                        )
                      : Container()
                ],
              )),
        ],
      ),
    );
  }

  showInvoiceAmountView(String paymentDueDate, num? finalAmount) {
    return Container(
      child: Row(children: [
        Expanded(
          child: Container(
              padding: EdgeInsets.all(5.0),
              margin: EdgeInsets.symmetric(
                vertical: 5.0,
              ),
              child: buildRowPaymentText(
                  Constants.INVOICE_AMOUNT,
                  "$orgCurrencySymbol" +
                      CommonMethods.getCurrencyValues(finalAmount),
                  1,
                  1)),
        ),
        Expanded(
          child: Container(
              padding: EdgeInsets.all(5.0),
              margin: EdgeInsets.symmetric(
                vertical: 5.0,
              ),
              child: buildRowPaymentText(
                  Constants.PAYMENT_DUE_DATE, "$paymentDueDate", 1, 1)),
        ),
      ]),
    );
  }

  showPartPaymentView(InvoiceDetails invoiceDetails) {
    return Container(
      child: Row(
        children: [
          Expanded(
            child: Container(
                padding: EdgeInsets.all(5.0),
                margin: EdgeInsets.symmetric(
                  vertical: 5.0,
                ),
                child: buildRowPaymentText(Constants.PART_PAYMENT, "", 1, 1)),
          ),
          Expanded(
            child: Container(
                padding: EdgeInsets.all(5.0),
                margin: EdgeInsets.symmetric(
                  vertical: 5.0,
                ),
                child:
                    buildRowPaymentText(Constants.PART_PAYMENT_DATE, "", 1, 1)),
          )
        ],
      ),
    );
  }

  showResolutionStatusView(bool isTransactionOffline,
      InvoiceDetails invoiceDetails, String? invoiceId) {
    return Container(
      padding: EdgeInsets.all(5.0),
      margin: EdgeInsets.symmetric(
        vertical: 5.0,
      ),
      child: Row(
        children: [
          Expanded(
            flex: 1,
            child: Row(
              children: [
                Text(
                  Language().getString(Constants.RESOLUTION, selectedLang),
                  style: TextStyle(
                      fontSize: 13.0,
                      color: Color(Constants.APP_COLOR),
                      fontWeight: FontWeight.bold),
                ),
                Container(
                  child: Text(
                    ": ${invoiceDetails.paymentReconciliation != null ? invoiceDetails.paymentReconciliation!.status : ""}",
                    style: TextStyle(
                      fontSize: 13.0,
                      color: Color(Constants.APP_COLOR),
                    ),
                  ),
                ),
              ],
            ),
          ),
          this.showPaymentDiscussionButtonView(
              isTransactionOffline, invoiceDetails, invoiceId)
        ],
      ),
    );
  }

  String paymentValidation() {
    if (showSelectedDate == Constants.SELECT_DATE) {
      return Constants.PLEASE_SELECT_DATE;
    } else if (_payAmount.text.isEmpty) {
      return Constants.PLEASE_ENTER_AMOUNT;
    } else {
      return "";
    }
  }

  showReceivedProductsConversionType(
      {String? invoiceId = "",
      dynamic billNo = 0,
      required List<invocieDAO.Product> invoiceProducts}) {
    for (int i = 0; i < invoiceProducts.length; i++) {
      productsConversionTypeList.add(Constants.RAW_MATERIALS);
    }
    return showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => Container(
            margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
            child: AppBackgroundView(
              body: Scaffold(
                backgroundColor: Colors.transparent,
                bottomNavigationBar: Container(
                    child: Padding(
                        padding: const EdgeInsets.only(
                            left: 10, right: 10, bottom: 20),
                        child: CommonButtonsView(
                          context: context,
                          b1Text: Language()
                              .getString(Constants.STR_CANCEL, selectedLang),
                          b2Text: Language()
                              .getString(Constants.CONFIRM, selectedLang),
                          onb1Action: () {
                            productsConversionTypeList.clear();
                            Navigator.of(context).pop();
                          },
                          onb2Action: () {
                            bool isNullExist = false;
                            for (int i = 0;
                                i < productsConversionTypeList.length;
                                i++) {
                              if (productsConversionTypeList[i] == null) {
                                isNullExist = true;
                                break;
                              }
                            }
                            if (isNullExist) {
                              Dialogs.yesCancelDialog(
                                  context,
                                  Language()
                                      .getString(Constants.INFO, selectedLang),
                                  Language().getString(
                                      Constants
                                          .MUST_SELECT_ALL_INVENTORY_ALLOCATIONS,
                                      selectedLang),
                                  Language().getString(
                                      Constants.OKAY_STR, selectedLang),
                                  "",
                                  false);
                            } else {
                              Navigator.of(context).pop();
                              this.updateRawMaterialStockReceived(
                                  invoiceId: invoiceId, billNo: billNo);
                            }
                          },
                        ))),
                body: StatefulBuilder(
                  builder: (context, StateSetter setState) => Container(
                    padding: EdgeInsets.all(8.0),
                    child: Column(
                      children: [
                        Container(
                            margin: EdgeInsets.symmetric(vertical: 5.0),
                            child: Center(
                              child: Text(
                                  Language().getString(
                                      Constants.INVENTORY_ALLOCATION,
                                      selectedLang),
                                  style: TextStyle(
                                      color: Color(Constants.APP_COLOR),
                                      fontWeight: FontWeight.w600)),
                            )),
                        Expanded(
                          child: ListView.builder(
                              itemBuilder: (context, index) =>
                                  showInvoiceProductsCardView(
                                      invoiceProducts, index, setState),
                              itemCount: invoiceProducts.length),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            )));
  }

  Widget showInvoiceProductsCardView(
      List<invocieDAO.Product> products, int index, StateSetter setState) {
    return Container(
        child: Card(
      elevation: 2.5,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(children: [
          Container(
              child: Column(
            children: [
              this.productDetailsView(
                  Constants.PRODUCT, products[index].productName),
              this.productDetailsView(Constants.QUANTITY,
                  "${products[index].quantity} ${products[index].quantityIn}")
            ],
          )),
          this.radioButtonFunctionality(setState, index)
        ]),
      ),
    ));
  }

  Widget radioButtonFunctionality(StateSetter setState, int index) {
    return Container(
        child: Row(
      children: [
        Expanded(
          child: Container(
              margin: EdgeInsets.only(right: 5.0),
              child: Row(
                children: [
                  Radio(
                      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      activeColor: Color(Constants.APP_COLOR),
                      value: Constants.SALABLE_PRODUCTS,
                      groupValue: productsConversionTypeList[index],
                      onChanged: (dynamic value) {
                        setState(() {
                          productsConversionTypeList[index] = value;
                        });
                      }),
                  Expanded(
                      child: Text(
                          Language().getString(
                              Constants.SALABLE_PRODUCTS, selectedLang),
                          style: TextStyle(
                              color: Color(Constants.APP_COLOR),
                              fontWeight: FontWeight.w100)))
                ],
              )),
        ),
        if (CommonMethods.isPrivillegeExist(
            context,
            PrivillegesActions
                .KEY_TRANSACTIONS_TRANSACTION_STEPS_STOCK_RECONCILIATION_STOCK_RECEIVE_RAW_MATERIAL))
          Expanded(
            child: Container(
                margin: EdgeInsets.only(left: 5.0),
                child: Row(
                  children: [
                    Radio(
                        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        value: Constants.RAW_MATERIALS,
                        activeColor: Color(Constants.APP_COLOR),
                        groupValue: productsConversionTypeList[index],
                        onChanged: (dynamic value) {
                          setState(() {
                            productsConversionTypeList[index] = value;
                          });
                        }),
                    Expanded(
                        child: Text(
                            Language().getString(
                                Constants.RAW_MATERIALS, selectedLang),
                            style: TextStyle(
                                color: Color(Constants.APP_COLOR),
                                fontWeight: FontWeight.w100)))
                  ],
                )),
          )
      ],
    ));
  }

  Widget productDetailsView(String title, String? value) {
    return Padding(
      padding: const EdgeInsets.all(3.0),
      child: Row(
        children: [
          Expanded(
            child: Text(Language().getString(title, selectedLang),
                style: TextStyle(
                    color: Color(Constants.APP_COLOR),
                    fontWeight: FontWeight.w700)),
          ),
          Text("  : "),
          Expanded(
            flex: 3,
            child: Text("$value"),
          )
        ],
      ),
    );
  }

  List<TrackingDetailsDAO> getCtrTrackingDetailsList(int index) {
    List<TrackingDetailsDAO> _finalCtrTrackingList = [];
    if (appendInvoiceData.length > index &&
        appendInvoiceData[index]!.ctrTransactionDetails != null) {
      _finalCtrTrackingList.addAll(appendInvoiceData[index]!
              .ctrTransactionDetails
              ?.deliveryTrackingList ??
          []);
      // _finalCtrTrackingList.addAll(
      //     appendInvoiceData[index].inDirectDetails?.deliveryTrackingList ?? []);
    }
    return _finalCtrTrackingList;
  }

  String showExpectedDeliveryDateTime(InvoiceDetails invoiceDetails) {
    if (invoiceDetails.invoiceType == Constants.CTR3) {
      return "${invoiceDetails.ctrTransactionDetails != null ? invoiceDetails.ctrTransactionDetails!.deliveryDate : ""} ${invoiceDetails.ctrTransactionDetails != null ? invoiceDetails.ctrTransactionDetails!.deliveryTime : ""}";
    } else {
      return "${invoiceDetails.orderTrackDetails != null ? invoiceDetails.orderTrackDetails!.deliveryDate : ""} ${invoiceDetails.orderTrackDetails != null ? invoiceDetails.orderTrackDetails!.deliveryTime : ""}";
    }
  }

  String showDispatchDeliveryDateTime(InvoiceDetails invoiceDetails) {
    if (invoiceDetails.invoiceType == Constants.CTR3) {
      return "${invoiceDetails.ctrTransactionDetails != null ? invoiceDetails.ctrTransactionDetails!.deliveryDate : ""} ${invoiceDetails.ctrTransactionDetails != null ? invoiceDetails.ctrTransactionDetails!.deliveryTime : ""}";
    }
    if (invoiceDetails.orderTrackDetails != null) {
      return invoiceDetails.orderTrackDetails!.dispatchDeliveryDateTime!;
    }

    return "";
  }

  showPaymentDiscussionButtonView(bool isTransactionOffline,
      InvoiceDetails invoiceDetails, String? invoiceId) {
    if (_transactionsList.length > 0 &&
        _transactionsList[0].ctrDetails?.type == Constants.CTR1) {
      return this.gotoPaymentDiscussion(
          invoiceNo: invoiceDetails.billNo.toString(),
          resolution: invoiceDetails.paymentReconciliation != null
              ? invoiceDetails.paymentReconciliation!.status
              : "",
          invoiceId: invoiceId);
    } else if (isTransactionOffline ||
        invoiceDetails.status == Constants.CANCELLED ||
        invoiceDetails.stockReconciliation?.status != "resolved") {
      return Container();
    } else {
      return this.gotoPaymentDiscussion(
          invoiceNo: invoiceDetails.billNo.toString(),
          resolution: invoiceDetails.paymentReconciliation != null
              ? invoiceDetails.paymentReconciliation!.status
              : "",
          invoiceId: invoiceId);
    }
  }
}
