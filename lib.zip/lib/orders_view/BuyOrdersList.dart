import 'package:vyaparlive/orders_view/controller/orders_controller.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/animation/list_loader/ListLoader.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:flutx/flutx.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Transaction/card_view/ListItemCardDesing.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/OrderDAO.dart';
import 'package:vyaparlive/orders_view/OrderDetails.dart';
import 'dart:convert';
import 'package:vyaparlive/service/bu_list_grpc_service.dart';

class BuyOrdersListPage extends StatefulWidget {
  final List<OrderDAO>? buyOrders;
  BuyOrdersListPage({this.buyOrders});
  @override
  _BuyOrdersListPageState createState() => _BuyOrdersListPageState();
}

class _BuyOrdersListPageState extends State<BuyOrdersListPage> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  List<String> status = ["Delivered", "Pending", "Accepted"];
  List<OrderDAO> _ordersList = [];
  String? buId = "";
  DateFormat formatter = DateFormat("dd-MM-yyy");
  String? orderDate;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;

  String transactionName = "";
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  static String showLoaderText = Constants.NO_DATA_FOUND;
  TextEditingController _searchController = new TextEditingController();
  bool isShowFloatButton = false;
  late BuListGrpcService _transactionService;
  bool isSearchForParams = false;
  late OrdersController _ordersController;
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _ordersController = FxControllerStore.putOrFind(OrdersController());
    _transactionService = BuListGrpcService();
    buId = AppController.instance.getMyBuId;
    loadOrdersData("");
  }

  loadOrdersData(String params) async {
    if (await NetworkStatus.getInternetStatus()) {
      if (!isSearchForParams) {
        setState(() {
          isLoadingProgress = true;
        });
      }
      getOrders(params).then((value) {
        setState(() {
          if (value.length > 0) {
            _ordersList.clear();
            for (int i = 0; i < value.length; i++) {
              if (value[i].buyer!.id == buId) {
                _ordersList.add(value[i]);
              }
            }
          } else {
            showLoaderText = Constants.NO_DATA_FOUND;
          }
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Widget _listViewData() {
    Size screensize = MediaQuery.of(context).size;
    if (isLoadingProgress) {
      return Expanded(child: ListLoader());
    } else if (!isLoadingProgress && _ordersList.length == 0) {
      return Expanded(
        child: Center(
          child: Text(Language().getString(showLoaderText, selectedLang)),
        ),
      );
    } else {
      return Expanded(
        child: Padding(
            padding: EdgeInsets.only(top: screensize.height * 0.02),
            child: AnimationLimiter(
              child: ListView.separated(
                physics: const BouncingScrollPhysics(
                    parent: AlwaysScrollableScrollPhysics()),
                shrinkWrap: true,
                separatorBuilder: (context, i) =>
                    Divider(height: 0.0, color: Colors.transparent),
                itemBuilder: (BuildContext ctxt, int i) {
                  return AnimationConfiguration.staggeredList(
                      position: i,
                      duration: const Duration(milliseconds: 1200),
                      child: SlideAnimation(
                          verticalOffset: 50.0,
                          child: FadeInAnimation(
                              child: InkWell(
                            onTap: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => OrderDetailsPage(
                                          isFromSellOrders: false,
                                          orderId: _ordersList[i].id,
                                          transactionName: _ordersList[i]
                                              .seller!
                                              .name))).then(
                                  (value) => {loadOrdersData("")});
                            },
                            child: Container(
                                child: ListItemCardDesingView(
                              strDate: Language()
                                  .getString(Constants.DATE, selectedLang),
                              strName: Language().getString(
                                  Constants.NAME_STRING, selectedLang),
                              strStatus: Language().getString(
                                  Constants.STATE_NAME_STRING, selectedLang),
                              name: _ordersList[i].seller!.name,
                              status: _ordersList[i].orderDetails!.status,
                              date: _ordersList[i]
                                  .orderDetails!
                                  .orderDate
                                  .toString(),
                              backgroundColor: Colors.grey,
                            )),
                          ))));
                },
                itemCount: _ordersList.length,
              ),
            )),
      );
    }
  }

  Widget _buildBody() {
    return Stack(
      children: [
        SafeArea(
          child: Scaffold(
            key: _scaffoldkey,
            floatingActionButton: (isShowFloatButton)
                ? FloatingActionButton(
                    backgroundColor: Color(Constants.APP_COLOR),
                    onPressed: () {
                      this.renderClearFiltersData();
                      isShowFloatButton = false;
                      loadOrdersData("");
                    },
                    child: Text(
                      Language().getString(Constants.ERROR, selectedLang),
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 10.0),
                    ),
                  )
                : null,
            body: Container(
                margin: EdgeInsets.only(right: 5.0),
                color: Colors.white,
                child: Card(
                  elevation: 20,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.only(
                          topRight: Radius.circular(10.0),
                          bottomRight: Radius.circular(10.0))),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      children: <Widget>[
                        Container(height: 50.0, child: this.buildSearchBarView()),
                        _listViewData()
                      ],
                    ),
                  ),
                )),
          ),
        ),
        // AppUtills.showLoadingView(
        //     context: context,
        //     message: Language().getString(progressMessage, selectedLang),
        //     isLoading: isLoadingProgress),
      ],
    );
  }

  @override
  void dispose() {
    _ordersController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FxBuilder(
        controller: _ordersController,
        builder: (_ordersController) => _buildBody());
  }

  renderClearFiltersData() {
    AppController.instance.setFromDate = null;
    AppController.instance.setToDate = null;
    AppController.instance.setConnectionName = null;
    AppController.instance.setTransactionStatus = null;
    AppController.instance.setTxnFilterOption = null;
  }

  buildSearchBarView() {
    return Card(
      elevation: 5,
      shadowColor: theme.colorScheme.primary,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0),
          side:
              BorderSide(color: theme.colorScheme.primary, strokeAlign: 0.01)),
      child: Row(
        children: <Widget>[
          Expanded(
              flex: 5,
              child: Row(
                children: <Widget>[
                  Expanded(
                    flex: 5,
                    child: Container(
                      padding: EdgeInsets.only(left: 5),
                      child: TextFormField(
                        controller: _searchController,
                        onChanged: onSearchTextChanged,
                        style: TextStyle(
                            fontFamily: 'IndianRupee',
                            fontSize: 15,
                            color: Colors.black,
                            fontWeight: FontWeight.w400),
                        decoration: InputDecoration(
                            border: InputBorder.none,
                            hintText: Language().getString(
                                Constants.SEARCH_BY_BUSINESS, selectedLang)),
                      ),
                    ),
                  ),
                  (_searchController.text.isNotEmpty)
                      ? Container(
                          color: Colors.white,
                          child: IconButton(
                              icon: Icon(
                                Icons.close,
                                color: Colors.red,
                                size: 20.0,
                              ),
                              onPressed: () {
                                setState(() {
                                  _searchController.clear();

                                  onSearchTextChanged(_searchController.text);
                                });
                              }))
                      : new Container()
                ],
              )),
          Expanded(
              child: Container(
                  margin: EdgeInsets.only(left: 2),
                  // decoration: BoxDecoration(
                  //     color: Colors.white,
                  //     borderRadius: BorderRadius.only(
                  //       topRight: Radius.circular(5.0),
                  //       bottomRight: Radius.circular(5.0),
                  //     )),
                  padding: EdgeInsets.only(left: 5),
                  child: Container()
                  // IconButton(
                  //     icon: Icon(
                  //       Icons.filter_list,
                  //       color: theme.colorScheme.primary,
                  //     ),
                  //     onPressed: () async {
                  //       var result = await Navigator.push(
                  //           context,
                  //           new MaterialPageRoute(
                  //               builder: (context) => FilterTransactionPage(
                  //                     buId: buId,
                  //                     connectionBuId: buId,
                  //                     isFromInPersonOrder: true,
                  //                   )));
                  //       if (result != null) {
                  //         setState(() {
                  //           isShowFloatButton = true;
                  //         });

                  //         loadOrdersData("");
                  //       }
                  //     }),
                  ))
        ],
      ),
    );
  }

  onSearchTextChanged(String text) async {
    if (text.isEmpty) {
      setState(() {
        showLoaderText = Constants.LOADING;
        isSearchForParams = true;
        isSearchForParams = false;
        isLoadingProgress = true;
      });

      loadOrdersData("");
    } else {
      setState(() {
        showLoaderText = Constants.LOADING;
        isSearchForParams = true;
      });

      String params = "$text";
      loadOrdersData(params);
    }
  }

  Future<List<OrderDAO>> getOrders(String params) async {
    // http.Response
    _ordersList.clear();
    String body = json.encode({
      "buId": buId,
      "filters": {"name": params, "type": 1}
    });
    var response = await _transactionService
        .findOrdersByBuId(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<OrderDAO> list = [];
    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);
      for (var objects in data['results']) {
        list.add(OrderDAO.fromJson(objects));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
      return list;
  }
}
