import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/components/privileges/inperson_order_privileges.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/ModelProduct.dart';
import 'package:vyaparlive/model/OrderDAO.dart';
import 'package:vyaparlive/model/TransactionsModel.dart';
import 'package:vyaparlive/orders_view/AddOrderProduct.dart';
import 'dart:convert';
import 'package:vyaparlive/service/bu_list_grpc_service.dart';

class EditMenuOrderPage extends StatefulWidget {
  EditMenuOrderPage(
      {this.isFromSellOrders = false, this.orderId, this.transactionName});
  final bool isFromSellOrders;
  final String? orderId;
  final String? transactionName;
  @override
  _EditMenuOrderPageState createState() => _EditMenuOrderPageState();
}

class _EditMenuOrderPageState extends State<EditMenuOrderPage> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  List<OrderDAO> _ordersList = [];
  List<Product> _products = [];
  List<Product> selectedProducts = [];

  String? buId = "";
  String? buName = "";
  final reasonController = TextEditingController();
  List<ModelProduct>? _resultList = [];
  bool isProductAdded = false;
  List<TextEditingController> _enterProductCount = [];
  InPersonOrderPrivileges? _inPersonOrderPrivileges =
      AppController.instance.getInpersonOrderPrivileges;

  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  late BuListGrpcService _transactionService;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  String? orgCurrencySymbol = "";
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _transactionService = BuListGrpcService();
    buId = AppController.instance.getMyBuId;
    buName = AppController.instance.getBuName;
    loadOrdersData();
    // orgCurrencySymbol = AppController.instance.getBuCurrencySymbol;
    String? symbol = AppController.instance.getBuCurrencySymbol;
    orgCurrencySymbol = (symbol != null && symbol.isNotEmpty && symbol!="-") ? symbol : "\u20B9";
  }

  loadOrdersData() async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
      });
      this.getOrderDetails().then((value) {
        setState(() {
          _ordersList.clear();
          _ordersList.addAll(value);
          for (int i = 0;
              i < _ordersList[0].orderDetails!.products!.length;
              i++) {
            _enterProductCount.add(TextEditingController());
            _products.add(_ordersList[0].orderDetails!.products![i]);
          }

          if (_products.length > 0) {
            for (int i = 0; i < _products.length; i++) {
              _enterProductCount[i] =
                  TextEditingController(text: _products[i].quantity.toString());
            }
          }
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
        body: Stack(
      children: [
        SafeArea(
          child: Scaffold(
            key: _scaffoldkey,
            backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
            appBar: AppBar(
              centerTitle: true,
              elevation: 0,
              iconTheme: IconThemeData(color: theme.colorScheme.primary),
              title: AppbarName(
                  title: Language().getString(Constants.EDIT_ORDER, selectedLang),
                  buName: "${widget.transactionName}"),
              actions: [
                AppUtills.homeButton(context),
              ],
              backgroundColor: Colors.transparent,
            ),
            bottomNavigationBar: (_inPersonOrderPrivileges!
                    .update_in_person_order)
                ? Container(
                    margin: EdgeInsets.all(10.0),
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          backgroundColor: theme.colorScheme.primary),
                      onPressed: () async {
                        if (await NetworkStatus.getInternetStatus()) {
                          this.serviceCallUpdateOrder();
                        } else {
                          AppUtills.showSnackBar(
                              _scaffoldkey,
                              Language()
                                  .getString(Constants.NO_INTERNET, selectedLang),
                              snackBarBgColor: Colors.black,
                              messageColor: Colors.white,
                              buttonColor: Colors.white);
                        }
                      },
                      child: Text(
                          Language()
                              .getString(Constants.UPDATE_ORDER, selectedLang),
                          style: TextStyle(color: Colors.white)),
                    ),
                  )
                : null,
            body: Container(
              padding: EdgeInsets.all(5.0),
              child: _ordersList.length == 0
                  ? Center(
                      child: Text(
                      Language().getString(Constants.NO_DATA_FOUND, selectedLang),
                    ))
                  : Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        this.showOrderInformation(),
                        SizedBox(height: 5.0),
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.only(top: 20),
                            child: ListView.builder(
                              shrinkWrap: true,
                              itemBuilder: (context, index) {
                                return showProductsDesign(index);
                              },
                              itemCount: _products.length,
                            ),
                          ),
                        )
                      ],
                    ),
            ),
          ),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    ));
  }

  showProductsDesign(int index) {
    return Card(
        elevation: 5.0,
        color: Colors.white,
        child: Container(
          padding: EdgeInsets.all(5.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              this.showProductImage(index),
              Expanded(
                flex: 3,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Expanded(
                          flex: 2,
                          child: new Container(
                            child: Text(_products[index].productName!,
                                style: TextStyle(
                                    fontWeight: StyleView.fontSemiBold,
                                    color: theme.colorScheme.primary)),
                          ),
                        ),
                        handlingBuyerView(index)
                      ],
                    ),
                    SizedBox(
                      height: 5.0,
                    ),
                    Row(
                      children: <Widget>[
                        Expanded(
                          flex: 2,
                          child: new Container(
                            child: Text(
                              Language().getString(
                                      Constants.TOTAL_AMOUNT, selectedLang) +
                                  " : $orgCurrencySymbol" +
                                  CommonMethods.getCurrencyValues(
                                      _products[index].total),
                              style:
                                  TextStyle(color: Color(Constants.APP_COLOR)),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ));
  }

  Widget showProductImage(int index) {
    // if (_products[index].productImage != null &&
    //     _products[index].productImage!.isNotEmpty) {
    return Expanded(
      child: Container(
          padding: EdgeInsets.all(5.5),
          margin: EdgeInsets.all(2.5),
          child: AppUtills.displayImage(_products[index].productImage,
              context: context)),
    );
    // } else {
    //   return SizedBox();
    // }
  }

  handlingBuyerView(int index) {
    return Expanded(
        flex: 2,
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  this.removeProductQuantity(index),
                  this.showProductQuantity(index),
                  this.addProductQuantity(index),
                ],
              ),
            ]));
  }

  Widget removeProductQuantity(int index) {
    return Container(
      child: InkWell(
        onTap: () {
          int? count = _products[index].quantity as int?;
          setState(() {
            count = count! - 1;
            if (count == 0) {
              _products.removeAt(index);
              _enterProductCount.removeAt(index);
            } else {
              _products[index] = Product(
                  id: _products[index].id,
                  productName: _products[index].productName,
                  productImage: _products[index].productImage,
                  quantity: count,
                  total: _products[index].total);
              _enterProductCount[index] = TextEditingController(
                  text: _products[index].quantity.toString());
              _enterProductCount[index].selection = TextSelection.fromPosition(
                  TextPosition(offset: _enterProductCount[index].text.length));
            }
          });
        },
        child: Icon(Icons.remove),
      ),
    );
  }

  Widget addProductQuantity(int index) {
    return Container(
      child: InkWell(
        onTap: () {
          int? count = _products[index].quantity as int?;
          setState(() {
            count = count! + 1;

            _products[index] = Product(
                id: _products[index].id,
                productName: _products[index].productName,
                productImage: _products[index].productImage,
                quantity: count,
                total: _products[index].total);
          });
          _enterProductCount[index] =
              TextEditingController(text: _products[index].quantity.toString());
          _enterProductCount[index].selection = TextSelection.fromPosition(
              TextPosition(offset: _enterProductCount[index].text.length));
        },
        child: Icon(Icons.add),
      ),
    );
  }

  Widget showProductQuantity(int index) {
    return Container(
      height: 30.0,
      width: 60.0,
      decoration: AppUtills.boxDecoration(),
      padding: EdgeInsets.all(2.0),
      child: Center(
        child: TextFormField(
          textAlign: TextAlign.center,
          controller: _enterProductCount[index],
          decoration: InputDecoration(
            hintText: "0",
            border: InputBorder.none,
          ),
          keyboardType: TextInputType.number,
          inputFormatters: [
            new LengthLimitingTextInputFormatter(7),
            FilteringTextInputFormatter.digitsOnly
          ],
          style: TextStyle(fontSize: 12.0),
          onChanged: (value) {
            /// Adding input value for product counter value
            if (value.isEmpty) {
              _products[index].quantity = 0;
            } else {
              _products[index].quantity = int.parse(value);
            }
          },
        ),
      ),
    );
  }

  serviceCallUpdateOrder() async {
    setState(() {
      isLoadingProgress = true;
    });
    List<Map<String, dynamic>> productsArray = [];
    var productsObject;
    if (_products.length > 0) {
      for (int i = 0; i < _products.length; i++) {
        if (_products[i].quantity != 0) {
          productsObject = {
            "id": _products[i].id,
            "unit_price": _products[i].unitPrice,
            "quantity": _products[i].quantity,
            "discount": "",
            "tax": "",
            "total": _products[i].total,
            "product_name": _products[i].productName,
            "product_image": ""
          };
          productsArray.add(productsObject);
        }
      }
    }
    String body = json.encode({
      "buyer": {
        "id": _ordersList[0].buyer!.id,
        "name": _ordersList[0].buyer!.name
      },
      "seller": {
        "id": _ordersList[0].seller!.id,
        "name": _ordersList[0].seller!.name
      },
      "order_details": {
        "products": productsArray,
        "status": _ordersList[0].orderDetails!.status
      },
      "id": _ordersList[0].id
    });

    var response = await _transactionService
        .updateMenuOrder(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    // _service.updateMenuOrder(body)

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      return showDialog(
          context: (context),
          builder: (context) => AlertDialog(
                title: Text(
                  Language().getString(Constants.SUCCESS, selectedLang),
                ),
                content: Text(
                  Language().getString(Constants.ORDER_UPDATED, selectedLang),
                ),
                actions: <Widget>[
                  TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                        Navigator.of(context).pop(true);
                      },
                      child: Text(
                        Language()
                            .getString(Constants.OKAY_STR, selectedLang),
                        style: TextStyle(
                          color: Color(Constants.APP_COLOR),
                          fontSize: 18.0,
                        ),
                      ))
                ],
              ));
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  Future<List<OrderDAO>> getOrderDetails() async {
    setState(() {
      _ordersList.clear();
    });
    String body = json.encode({"id": widget.orderId});
    // http.Response
    var response = await _transactionService
        .findOrdersDetailsById(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<OrderDAO> list = [];
    setState(() {
      isLoadingProgress = false;
    });
    //  _service.getOrderDetails(widget.orderId)

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);
      list.add(OrderDAO.fromJson(data[0]));
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
      return list;
  }

  showOrderInformation() {
    return Container(
      child: Row(
        children: [
          Expanded(
              child: Container(
                  child: (widget.isFromSellOrders)
                      ? this.showSimpleRowText(
                          Constants.BUYER, _ordersList[0].buyer!.name!)
                      : this.showSimpleRowText(
                          Constants.SELLER, _ordersList[0].seller!.name!))),
          Expanded(
            child: Container(
              height: 30.0,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                    backgroundColor: theme.colorScheme.primary),
                onPressed: () async {
                  _resultList = await Navigator.push(
                      context,
                      new MaterialPageRoute(
                          builder: (context) => AddMenuOrder(
                              buId: _ordersList[0].seller!.id,
                              buName: _ordersList[0].seller!.name,
                              isNewOrder: false)));

                  if (_resultList != null && _resultList!.length > 0) {
                    for (int i = 0; i < _resultList!.length; i++) {
                      bool isExists = false;
                      int existIndex = -1;
                      for (int j = 0; j < _products.length; j++) {
                        if (_resultList![i].id == _products[j].id) {
                          isExists = true;
                          existIndex = j;
                        }
                      }

                      if (isExists) {
                        int totalQuantity = _resultList![i].counter! +
                            (_products[existIndex].quantity as int);
                        setState(() {
                          _products[existIndex] = Product(
                              id: _products[existIndex].id,
                              productName: _products[existIndex].productName,
                              productImage: _products[existIndex].productImage,
                              total: _products[existIndex].total,
                              quantity: totalQuantity);

                          _enterProductCount[existIndex] =
                              TextEditingController(
                                  text: _products[existIndex]
                                      .quantity
                                      .toString());
                        });
                      } else {
                        setState(() {
                          _enterProductCount.add(TextEditingController());
                          _products.add(Product(
                              id: _resultList![i].id,
                              productName: _resultList![i].name,
                              productImage: _resultList![i].images,
                              total: _resultList![i].price,
                              quantity: _resultList![i].counter));

                          for (int i = 0; i < _products.length; i++) {
                            _enterProductCount[i] = TextEditingController(
                                text: _products[i].quantity.toString());
                          }
                        });
                      }
                    }
                  }
                },
                child: Text(
                  Language()
                      .getString(Constants.ADD_MORE_PRODUCTS, selectedLang),
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  showSimpleRowText(String title, String name) {
    return Row(
      children: [
        Container(
            child: Text(
          Language().getString(title, selectedLang),
          style: TextStyle(
              color: Color(Constants.APP_COLOR),
              fontSize: 15.0,
              fontWeight: FontWeight.bold),
        )),
        Expanded(
            child: Row(
          children: [
            Text(" : "),
            Expanded(
              child: Text(name),
            )
          ],
        ))
      ],
    );
  }
}
