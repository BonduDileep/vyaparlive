import 'package:flutx/flutx.dart';

class OrdersController extends FxController {
  @override
  String getTag() {
    return 'orders_controller';
  }
}
