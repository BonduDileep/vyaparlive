import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/OrderDAO.dart';
import 'package:vyaparlive/orders_view/BuyOrdersList.dart';
import 'package:vyaparlive/orders_view/SellOrdersList.dart';

class OrdersBuyAndSellList extends StatefulWidget {
  @override
  _OrdersBuyAndSellListState createState() => _OrdersBuyAndSellListState();
}

class _OrdersBuyAndSellListState extends State<OrdersBuyAndSellList>
    with SingleTickerProviderStateMixin {
  TabController? _tabController;
  String? buName = "";
  String? buId = "";
  List<OrderDAO> _buyOrdersList = [];
  List<OrderDAO> _sellOrdersList = [];
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;

  @override
  void initState() {
    super.initState();
    buName = AppController.instance.getBuName;
    buId = AppController.instance.getMyBuId;

    _tabController = TabController(length: 2, vsync: this, initialIndex: 0);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          appBar: PreferredSize(
            preferredSize: Size.fromHeight(50.0),
            child: AppBar(
              automaticallyImplyLeading: false,
              backgroundColor: Color(Constants.APP_COLOR),
              bottom: TabBar(
                  indicatorSize: TabBarIndicatorSize.tab,
                  controller: _tabController,
                  onTap: (value) {
                    setState(() {
                      _tabController!.index = value;
                    });
                  },
                  tabs: <Widget>[
                    Tab(
                      child: Text(Language()
                          .getString(Constants.BUY_ORDERS, selectedLang)),
                    ),
                    Tab(
                      child: Text(Language()
                          .getString(Constants.SELL_ORDERS, selectedLang)),
                    ),
                  ]),
            ),
          ),
          backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
          body: TabBarView(
              physics: NeverScrollableScrollPhysics(),
              controller: _tabController,
              children: [
                BuyOrdersListPage(buyOrders: _buyOrdersList),
                SellOrdersListPage(sellOrders: _sellOrdersList)
              ])),
    );
  }
}
