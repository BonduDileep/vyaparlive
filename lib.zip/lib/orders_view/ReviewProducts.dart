import 'dart:convert';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Transaction/card_view/ProductCardDesign.dart';
import 'package:vyaparlive/Transaction/TransactionsPage.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/components/privileges/transaction_privileges.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/BusinessUnitModel.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/ModelProduct.dart';
import 'package:vyaparlive/model/bu_model/LocationsModel.dart';
import 'package:vyaparlive/orders_view/OrdersPage.dart';
import 'package:vyaparlive/service/bu_list_grpc_service.dart';
import 'package:vyaparlive/service/organization_service.dart';
import 'package:vyaparlive/utills/SharePref.dart';

class ReviewProductsPage extends StatefulWidget {
  final List<ModelProduct>? orderedProducts;
  final String? connectionBuId;
  final String? connectionName;
  final bool? isOnlineConnection;
  ReviewProductsPage(
      {this.orderedProducts,
      this.connectionBuId,
      this.connectionName,
      this.isOnlineConnection});
  @override
  _ReviewProductsPageState createState() => _ReviewProductsPageState();
}

class _ReviewProductsPageState extends State<ReviewProductsPage> {
  String? buId = "";
  String? buName = "";
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  List<ModelProduct>? selectedProducts = [];
  late BuListGrpcService _transactionService;
  String progressMessage = Constants.GETTING_DATA;
  bool isLoadingProgress = false;
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? userName = "";
  String? userId = "";
  String? orgCurrencySymbol = "";
  TransactionPrivileges? _transactionPrivileges =
      AppController.instance.getTransactionPrivileges;
  late OrganizationService _organizationService;
  Locations? locationDropdownValue;
  List<Locations> locationsList = [];
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _organizationService = OrganizationService();
    _transactionService = BuListGrpcService();
    selectedProducts = widget.orderedProducts;
    buId = AppController.instance.getMyBuId;
    buName = AppController.instance.getBuName;
    SharePref().getUserName().then((value) {
      userName = value;
    });
    SharePref().getUserId().then((value) {
      userId = value;
    });

    // orgCurrencySymbol = AppController.instance.getBuCurrencySymbol;
    String? symbol = AppController.instance.getBuCurrencySymbol;
    orgCurrencySymbol = (symbol != null && symbol.isNotEmpty && symbol!="-") ? symbol : "\u20B9";
    getBuData().then((value) {
      locationsList.clear();
      if (value.length > 0) locationsList.addAll(value[0].locationsList!);
    });
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
        body: Stack(
      children: [
        SafeArea(
          child: Scaffold(
            key: _scaffoldkey,
            backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
            appBar: AppBar(
              backgroundColor: Colors.transparent, //(Constants.APP_COLOR),
              centerTitle: true,
              elevation: 0,
              iconTheme: IconThemeData(color: theme.colorScheme.primary),
              title: AppbarName(
                  title: Language()
                      .getString(Constants.REVIEW_PRODUCTS, selectedLang),
                  buName: "$buName"),
            ),
            bottomNavigationBar: Container(
              margin: EdgeInsets.symmetric(horizontal: 10.0),
              padding: EdgeInsets.symmetric(vertical: 10),
              child: CommonButtonsView(
                context: context,
                b1Text: Language().getString(Constants.STR_CANCEL, selectedLang),
                b2Text: Language().getString(Constants.CONFIRM, selectedLang),
                onb1Action: () {
                  Navigator.pop(context);
                },
                onb2Action: () {
                  if (widget.isOnlineConnection!) {
                    this.buildShipToAddressDropdown();
                  } else {
                    this.postBodyForProductsSell();
                  }
                },
              ),
            ),
            body: Container(
              margin: EdgeInsets.symmetric(horizontal: 5.0, vertical: 5.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        children: [
                          Expanded(
                              child: Container(
                            child: Row(
                              children: [
                                Text(
                                  Language().getString(
                                      Constants.ORDER_FOR_, selectedLang),
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: Color(Constants.APP_COLOR)),
                                ),
                                Expanded(
                                  child: Text(
                                    widget.connectionName!,
                                    style: TextStyle(fontSize: 15.0),
                                  ),
                                ),
                              ],
                            ),
                          )),
                        ],
                      ),
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: ListView.separated(
                          itemBuilder: (context, index) {
                            return ProductCardDesignView(
                              strTotalAmount: Language().getString(
                                  Constants.TOTAL_AMOUNT, selectedLang),
                              strUnitPrice: Language()
                                  .getString(Constants.PRICE_UNIT, selectedLang),
                              strQuantity: Language()
                                  .getString(Constants.QUANTITY, selectedLang),
                              strOfferApplied: Language().getString(
                                  Constants.OFFER_APPLIED, selectedLang),
                              productImage: selectedProducts![index].images,
                              productName: selectedProducts![index].name,
                              productPrice: selectedProducts![index].price,
                              productQnty: selectedProducts![index].counter,
                              quantityIn: selectedProducts![index].quantityIn,
                              isShowUnitPriceText: true,
                              isShowOffer: selectedProducts![index].isButton,
                            );
                          },
                          separatorBuilder: (context, index) {
                            return Divider(
                              height: 5.0,
                              color: Colors.transparent,
                            );
                          },
                          itemCount: selectedProducts!.length),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    ));
  }

  void serviceCallOrder() async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = Language().getString(Constants.CREATING, selectedLang);
    });
    List<Map<String, dynamic>> productsArray = [];
    var productsObject;

    for (int i = 0; i < selectedProducts!.length; i++) {
      if (selectedProducts![i].counter != 0) {
        productsObject = {
          "id": selectedProducts![i].id,
          "unit_price": "",
          "quantity": selectedProducts![i].counter,
          "discount": "",
          "tax": "",
          "total": selectedProducts![i].price,
          "quantity_in": selectedProducts![i].quantityIn,
          "offer_selected": selectedProducts![i].isButton,
        };
        productsArray.add(productsObject);
      }
    }

    Map data = {
      "buyer": {"id": widget.connectionBuId},
      "seller": {"id": buId},
      "order_details": {"products": productsArray},
      "user_id": userId,
      "user_name": userName,
      "ship_to_address": locationDropdownValue!.locationId
    };

    String body = json.encode(data);

    var response = await _transactionService
        .createMenuOrder(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);
      if (AppController.instance.getInpersonOrdeerAccept) {
        this.showAlertDialog(
            Language().getString(
                Constants.ORDER_PLACED_SUCCSESSFULLY_ALERT_STRING,
                selectedLang),
            false);
      } else {
        this.acceptOrder(data);
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  showAlertDialog(String? message, bool isOrderAccepted) {
    return showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) {
          return AlertDialog(
            content: Text(message!),
            actions: <Widget>[
              TextButton(
                  onPressed: () {
                    if (isOrderAccepted &&
                        _transactionPrivileges!.view_transaction) {
                      Navigator.pushAndRemoveUntil(
                          context,
                          MaterialPageRoute(
                              builder: (context) => TransactionsView(
                                    buId: buId,
                                    buName: buName,
                                  )),
                          (Route<dynamic> route) => false);
                    } else {
                      Navigator.pushAndRemoveUntil(
                          context,
                          MaterialPageRoute(builder: (context) => OrdersPage()),
                          (Route<dynamic> route) => false);
                    }
                  },
                  child: Text(
                      Language().getString(Constants.OKAY_STR, selectedLang),
                      style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                        fontSize: 18.0,
                      ))),
            ],
          );
        });
  }

  void acceptOrder(String? orderId) async {
    setState(() {
      isLoadingProgress = true;
    });

    Map data = {
      "id": orderId,
      "message": "Order Accepted",
      "status": "Order Accepted",
      "user_name": userName
    };
    String body = json.encode(data);
    var response = await _transactionService
        .acceptMenuOrder(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResposne = response;
    if (!_grpcResposne.getIsError! && !_grpcResposne.getIsException!) {
      this.showAlertDialog(
          Language().getString(Constants.TRANSACTION_CREATED, selectedLang),
          true);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          "${_grpcResposne.message}",
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  postBodyForProductsSell() async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = Constants.GETTING_DATA;
    });
    Map data = {
      "id": "",
      "is_offline": true,
      "buyer": {
        "id": widget.connectionBuId,
        "name": widget.connectionName,
        "is_offline": true
      },
      "sender":{
        "id": buId,
      },
      "seller": {
        "id": buId,
        "name": buName,
      },
      "ctr": {"type": "", "Agent": "", "transaction_ref": ""},
      "discussion": {
        "initiator": widget.connectionBuId,
        "initiator_user": widget.connectionName,
        "message_start_date": "",
        "confirmation_message": [],
        "confirmation_status": ""
      }
    };
    String body = json.encode(data);
    var response = await _transactionService
        .beginTransaction(body, AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);

      if (await NetworkStatus.getInternetStatus()) {
        this.prepareTransactionsProductsBody(data, false);
      } else {
        AppUtills.showSnackBar(_scaffoldkey,
            Language().getString(Constants.NO_INTERNET, selectedLang),
            snackBarBgColor: Colors.black,
            messageColor: Colors.white,
            buttonColor: Colors.white);
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  prepareTransactionsProductsBody(
      String? transactionId, bool isForBuyProudcts) async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = "Sending products...";
    });

    List<Map<String, dynamic>> productsArray = [];
    var productsObject;
    for (int i = 0; i < selectedProducts!.length; i++) {
      productsObject = {
        "id": selectedProducts![i].id,
        "unit_price": "",
        "quantity": selectedProducts![i].counter,
        "total": selectedProducts![i].price,
        "offer_selected": selectedProducts![i].offerSelected,
        "quantity_in": selectedProducts![i].quantityIn
      };
      productsArray.add(productsObject);
    }

    Map data = {
      "id": transactionId,
      "order_details": {
        "user_id": userId,
        "user_name": userName,
        "products": productsArray
      }
    };
    String body = json.encode(data);
    var response = await _transactionService
        .createPlaceOrder(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
        progressMessage = "";
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    setState(() {
      isLoadingProgress = false;
      progressMessage = "";
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      if (await NetworkStatus.getInternetStatus()) {
        this.serviceCallInvoice(transactionId);
      } else {
        AppUtills.showSnackBar(_scaffoldkey,
            Language().getString(Constants.NO_INTERNET, selectedLang),
            snackBarBgColor: Colors.black,
            messageColor: Colors.white,
            buttonColor: Colors.white);
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  void serviceCallInvoice(String? transactionId) async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = Constants.GETTING_DATA;
    });
    List<Map<String, dynamic>?> productArrayList = [];
    var productObject;

    for (int i = 0; i < selectedProducts!.length; i++) {
      if (selectedProducts![i].counter != 0) {
        productObject = {
          "id": selectedProducts![i].id,
          "quantity": selectedProducts![i].counter,
          "unit_price": selectedProducts![i].unitPrice,
          "offer_selected": selectedProducts![i].offerSelected,
          "batch_no": selectedProducts![i].batchPriceList!.length > 0
              ? selectedProducts![i].batchPriceList![0].batchNumber
              : []
        };
      }

      productArrayList.add(productObject);
    }

    Map data = {
      "txnId": transactionId,
      "products": productArrayList,
      "term_type": "bu",
      "additional_discount_type": "number",
      "additional_discount": 0
    };
    String body = json.encode(data);

    var response = await _transactionService
        .generateTransactionInvoice(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      return showDialog(
        context: context,
        builder: (context) => AlertDialog(
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(
                        builder: (context) => TransactionsView(
                              buId: buId,
                              buName: buName,
                            )),
                    (Route<dynamic> route) => false);
              },
              child: Text(
                Language().getString(Constants.OKAY_STR, selectedLang),
                style: TextStyle(
                  fontSize: 18.0,
                  color: Color(
                    Constants.APP_COLOR,
                  ),
                ),
              ),
            ),
          ],
          content: Container(
            child: Text(
              Language().getString(
                  Constants.INVOICE_GENERATED_SUCCESSFULLY, selectedLang),
            ),
          ),
        ),
      );
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  Future<List<BusinessUnitModel>> getBuData() async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = Constants.GETTING_DATA;
    });
    locationsList.clear();
    String body = json.encode({"id": widget.connectionBuId});

    var response = await _organizationService
        .getOrganizationDataById(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<BusinessUnitModel> _list = [];

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var object = json.decode(_grpcResponse.message!);
      _list.add(BusinessUnitModel.fromJson(object[0]));
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return _list;
  }

  buildShipToAddressDropdown() {
    return showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) {
          return AlertDialog(
              title: Container(
                child: Text(
                    Language()
                        .getString(Constants.SHIP_TO_LOCATION, selectedLang),
                    style: TextStyle(
                        fontSize: 15.0,
                        fontWeight: StyleView.fontMedium,
                        color: theme.colorScheme.primary)),
              ),
              content:
                  StatefulBuilder(builder: (context, StateSetter setState) {
                return Container(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        decoration: AppUtills.boxDecoration(),
                        padding: EdgeInsets.all(2),
                        child: DropdownButton<Locations>(
                          value: locationDropdownValue,
                          hint: new Text(Language().getString(
                              Constants.SELECT_SHIP_TO_LOCATION, selectedLang)),
                          isExpanded: true,
                          underline: SizedBox(),
                          onChanged: (Locations? data) {
                            setState(() {
                              locationDropdownValue = data;
                            });
                          },
                          items: locationsList.map((Locations model) {
                            return new DropdownMenuItem<Locations>(
                              child: new Text(model.locationName!),
                              value: model,
                            );
                          }).toList(),
                        ),
                      ),
                      Container(
                          margin: EdgeInsets.only(top: 15.0),
                          padding: EdgeInsets.symmetric(vertical: 10),
                          child: CommonButtonsView(
                            context: context,
                            b1Text: Language()
                                .getString(Constants.STR_CANCEL, selectedLang),
                            b2Text: Language()
                                .getString(Constants.CONTINUE, selectedLang),
                            onb1Action: () {
                              locationDropdownValue = null;
                              Navigator.of(context).pop();
                            },
                            onb2Action: () async {
                              if (locationDropdownValue == null) {
                                Dialogs.yesCancelDialog(
                                    context,
                                    Language().getString(
                                        Constants.ERROR, selectedLang),
                                    Language().getString(
                                        Constants
                                            .PLEASE_SELECT_SHIP_TO_LOCATION,
                                        selectedLang),
                                    Language().getString(
                                        Constants.OKAY_STR, selectedLang),
                                    "",
                                    false);
                              } else {
                                Navigator.of(context).pop();
                                if (await NetworkStatus.getInternetStatus()) {
                                  setState(() {
                                    isLoadingProgress = true;
                                    progressMessage = Language().getString(
                                        Constants.CREATING, selectedLang);
                                  });
                                  this.serviceCallOrder();
                                } else {
                                  AppUtills.showSnackBar(
                                      _scaffoldkey,
                                      Language().getString(
                                          Constants.NO_INTERNET, selectedLang),
                                      snackBarBgColor: Colors.black,
                                      messageColor: Colors.white,
                                      buttonColor: Colors.white);
                                }
                              }
                            },
                          ))
                    ],
                  ),
                );
              }));
        });
  }
}
