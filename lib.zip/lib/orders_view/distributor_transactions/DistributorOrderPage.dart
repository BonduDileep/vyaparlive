import 'package:flutter/material.dart';
import 'package:vyaparlive/Transaction/card_view/ProductCardDesign.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/model/TransactionsModel.dart';

class DistributorOrderPage extends StatelessWidget {
  final List<Product>? productsData;
  final String? status;
  DistributorOrderPage({this.productsData, this.status});
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
        appBar: AppBar(
          backgroundColor: Color(Constants.APP_COLOR),
          centerTitle: true,
          title: Text(Constants.ORDER_DETAILS),
        ),
        body: Container(
          margin: EdgeInsets.symmetric(horizontal: 5.0),
          child: Column(
            children: [
              Expanded(
                child: ListView.builder(
                  itemBuilder: (context, index) => ProductCardDesignView(
                    productImage: productsData![index].productImage!.length > 0
                        ? productsData![index].productImage![0]
                        : null,
                    productName: productsData![index].productName,
                    productPrice: productsData![index].total,
                    productQnty: productsData![index].quantity,
                    isFromPO: false,
                  ),
                  itemCount: productsData!.length,
                ),
              ),
              Container(
                margin: EdgeInsets.symmetric(
                  vertical: 10.0,
                ),
                child: Row(
                  children: [Expanded(child: Text("Order Status : $status"))],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
