import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/animation/list_loader/ListLoader.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/DateFilterUtil.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/DistributorReportsDAO.dart';

import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/orders_view/distributor_transactions/DistributorOrderPage.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:vyaparlive/service/bu_list_grpc_service.dart';
import 'dart:convert';

import 'package:vyaparlive/utills/SharePref.dart';

class DistributorsPage extends StatefulWidget {
  @override
  _DistributorsPageState createState() => _DistributorsPageState();
}

class _DistributorsPageState extends State<DistributorsPage> {
  TextEditingController _searchController = new TextEditingController();
  String? buId = "";
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  bool isShowFloatButton = false;
  late BuListGrpcService _transactionService;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? userId = "";
  List<DistributorReportsDAO> distributorList = [];
  String _strFromDate = "";
  String _strToDate = "";
  bool isEnableDateFilter = false;
  DateFormat formatter = DateFormat("yyyy-MM-dd");
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _strFromDate = formatter.format(DateTime.now());
    _strToDate = formatter.format(DateTime.now());
    buId = AppController.instance.getMyBuId;
    _transactionService = BuListGrpcService();
    SharePref().getUserId().then((value) {
      userId = value;
    });
    loadSalesUserTransaction();
  }

  loadSalesUserTransaction(
      {String fromDate = "", String toDate = "", String name = ""}) async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
      });
      getReports(fromDate: fromDate, toDate: toDate, name: name).then((value) {
        distributorList.clear();
        setState(() {
          distributorList.addAll(value);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Widget _listViewData() {
    Size screensize = MediaQuery.of(context).size;
    if (isLoadingProgress) {
      return Expanded(child: ListLoader());
    } else if (!isLoadingProgress && distributorList.length == 0) {
      return Expanded(
        child: Center(
            child: Text(
          Language().getString(Constants.NO_DATAFOUND_STRING, selectedLang),
        )),
      );
    } else {
      return Expanded(
          child: Padding(
        padding: EdgeInsets.only(top: screensize.height * 0.02),
        child: AnimationLimiter(
          child: ListView.builder(
              physics: const BouncingScrollPhysics(
                  parent: AlwaysScrollableScrollPhysics()),
              shrinkWrap: true,
              itemCount: 30, //distributorList.length,
              itemBuilder: (context, index) {
                return AnimationConfiguration.staggeredList(
                    position: index,
                    duration: Duration(milliseconds: 1200),
                    child: SlideAnimation(
                      verticalOffset: 50.0,
                      child: FadeInAnimation(child: this.showCardView(index)),
                    ));
              }),
        ),
      ));
    }
  }

  Widget _buildBody() {
    return Stack(
      children: [
        SafeArea(
          child: Scaffold(
            backgroundColor: Colors.white,
            key: _scaffoldkey,
            floatingActionButton: (isShowFloatButton)
                ? FloatingActionButton(
                    backgroundColor: Color(Constants.APP_COLOR),
                    onPressed: () {
                      setState(() {
                        isShowFloatButton = false;
                        isLoadingProgress = true;
                        _searchController.clear();
                        _strFromDate = formatter.format(DateTime.now());
                        _strToDate = formatter.format(DateTime.now());
                      });
          
                      loadSalesUserTransaction();
                    },
                    child: Text(
                      Language().getString(Constants.CLEAR_FILTERS, selectedLang),
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white, fontSize: 11.0),
                    ))
                : null,
            body: Container(
              margin: EdgeInsets.only(left: 5.0),
              child: Card(
                elevation: 20,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(10.0),
                        bottomLeft: Radius.circular(10.0))),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    children: [
                      Container(
                        height: 50.0,
                        child: this.buildSearchBarView(),
                      ),
                      (isEnableDateFilter)
                          ? DateFilterUtill(
                              fromDate: _strFromDate,
                              toDate: _strToDate,
                              onFromDateSelected: (value) {
                                setState(() {
                                  _strFromDate = value;
                                });
                              },
                              onToDateSelected: (value) {
                                setState(() {
                                  _strToDate = value;
                                });
                              },
                              onSearchParms: () {
                                setState(() {
                                  isShowFloatButton = true;
                                  isLoadingProgress = true;
                                });
          
                                loadSalesUserTransaction(
                                    fromDate: _strFromDate, toDate: _strToDate);
                              },
                            )
                          : Container(),
                      _listViewData()
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
        // AppUtills.showLoadingView(
        //     context: context,
        //     message: Language().getString(progressMessage, selectedLang),
        //     isLoading: isLoadingProgress),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return _buildBody();
  }

  Widget showCardView(int index) {
    return InkWell(
      onTap: () {
        Navigator.push(
            context,
            PageTransition(
                context: context,
                page: DistributorOrderPage(
                  productsData: distributorList[index].productList,
                  status: distributorList[index].status,
                )));
      },
      child: Card(
        elevation: 5.0,
        color: Colors.white,
        shadowColor: AppTheme.theme.colorScheme.primary, //Colors.white,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
            side: BorderSide(color: AppTheme.theme.colorScheme.primary)),
        child: Container(
          padding: EdgeInsets.all(5.0),
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(children: <Widget>[
                  Container(
                    child: Text(
                        Language().getString(Constants.BUYER, selectedLang),
                        style: TextStyle(
                          color: Color(Constants.APP_COLOR),
                          fontSize: StyleView.FONT_SIZE_15,
                        )),
                  ),
                  Container(
                    child: Text("", //" : ${distributorList[index].buyer}",
                        style: TextStyle(
                          color: Color(Constants.APP_COLOR),
                          fontSize: StyleView.FONT_SIZE_15,
                        )),
                  ),
                ]),
                SizedBox(height: 5.0),
                Row(children: <Widget>[
                  Container(
                    child: Text(
                        Language().getString(Constants.SELLER, selectedLang),
                        style: TextStyle(
                          color: Color(Constants.APP_COLOR),
                          fontSize: StyleView.FONT_SIZE_15,
                        )),
                  ),
                  Text("", //" : ${distributorList[index].seller}",
                      style: TextStyle(
                        fontSize: StyleView.FONT_SIZE_15,
                        color: Color(Constants.APP_COLOR),
                      )),
                ]),
                SizedBox(height: 5.0),
                Row(children: <Widget>[
                  Container(
                    child:
                        Text(Language().getString(Constants.DATE, selectedLang),
                            style: TextStyle(
                              color: Color(Constants.APP_COLOR),
                              fontSize: StyleView.FONT_SIZE_15,
                            )),
                  ),
                  Container(
                    child: Text("",
                        //" : ${AppUtills.getDateFormate(distributorList[index].createdDate.toString())}",
                        style: TextStyle(
                          color: Color(Constants.APP_COLOR),
                          fontSize: StyleView.FONT_SIZE_15,
                        )),
                  )
                ]),
                SizedBox(height: 5.0),
                Row(children: <Widget>[
                  Container(
                    child: Text(
                        Language()
                            .getString(Constants.STATUS_STRING, selectedLang),
                        style: TextStyle(
                          color: Color(Constants.APP_COLOR),
                          fontSize: StyleView.FONT_SIZE_15,
                        )),
                  ),
                  Container(
                    child: Text("", //" : ${distributorList[index].status}",
                        style: TextStyle(
                          // color: CommonMethods.transactionStatusColorHandling(
                          //     distributorList[index].status),
                          fontSize: StyleView.FONT_SIZE_15,
                        )),
                  )
                ]),
              ]),
        ),
      ),
    );
  }

  buildSearchBarView() {
    return Card(
      elevation: 5,
      shadowColor: theme.colorScheme.primary,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0),
          side:
              BorderSide(color: theme.colorScheme.primary, strokeAlign: 0.01)),
      child: Row(
        children: <Widget>[
          Expanded(
              flex: 5,
              child: Row(
                children: <Widget>[
                  Expanded(
                    flex: 5,
                    child: Container(
                      padding: EdgeInsets.only(left: 5),
                      child: TextFormField(
                        controller: _searchController,
                        onChanged: onSearchTextChanged,
                        style: TextStyle(fontFamily: 'IndianRupee'),
                        decoration: InputDecoration(
                            border: InputBorder.none,
                            hintText: Language().getString(
                                Constants.SEARCH_BY_BUSINESS, selectedLang)),
                      ),
                    ),
                  ),
                  (_searchController.text.isNotEmpty)
                      ? Container(
                          color: Colors.white,
                          child: IconButton(
                              icon: Icon(
                                Icons.close,
                                color: Colors.red,
                                size: 20.0,
                              ),
                              onPressed: () {
                                setState(() {
                                  _searchController.clear();
                                  onSearchTextChanged(_searchController.text);
                                });
                              }))
                      : new Container()
                ],
              )),
          Container(
            color: Colors.grey,
          ),
          Expanded(
            child: Container(
              margin: EdgeInsets.only(left: 2),
              padding: EdgeInsets.only(left: 5),
              child: IconButton(
                icon: Icon(Icons.date_range),
                onPressed: () async {
                  if (isEnableDateFilter) {
                    setState(() {
                      isEnableDateFilter = false;
                    });
                  } else {
                    setState(() {
                      isEnableDateFilter = true;
                    });
                  }
                },
              ),
            ),
          )
        ],
      ),
    );
  }

  onSearchTextChanged(String text) async {
    if (text.isEmpty) {
      loadSalesUserTransaction();
    } else {
      loadSalesUserTransaction(name: text);
    }
  }

  Future<List<DistributorReportsDAO>> getReports(
      {String fromDate = "", String toDate = "", String name = ""}) async {
    setState(() {
      isLoadingProgress = true;
    });
    Map data = {
      "bu": buId,
      "user": userId,
      "filters": {
        "DateFrom": fromDate,
        "DateTo": toDate,
// "from": number;
// "count": number;
        "isDesc": true,
        "name": name
      }
    };
    String body = json.encode(data);
    var response = await _transactionService
        .getSalesUserTransaction(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    List<DistributorReportsDAO> list = [];
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      var resultArray = resObj['results'];
      if (resultArray.length > 0) {
        for (var object in resultArray) {
          list.add(DistributorReportsDAO.fromJson(object));
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return list;
  }
}
