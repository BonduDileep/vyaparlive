import 'dart:convert';

import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/MyDrawer.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/components/privileges/inperson_order_privileges.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/BuListModel.dart';
import 'package:vyaparlive/model/Contacts.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/OrderDAO.dart';
import 'package:vyaparlive/orders_view/AddOrderProduct.dart';
import 'package:vyaparlive/orders_view/BuyOrdersList.dart';
import 'package:vyaparlive/orders_view/SellOrdersList.dart';
import 'package:vyaparlive/service/invitation_services.dart';

class OrdersPage extends StatefulWidget {
  @override
  _OrdersPageState createState() => _OrdersPageState();
}

class _OrdersPageState extends State<OrdersPage>
    with SingleTickerProviderStateMixin {
  TabController? _tabController;
  String? buName = "";
  String? buId = "";
  List<OrderDAO> _buyOrdersList = [];
  List<OrderDAO> _sellOrdersList = [];
  bool isLoading = false;
  InPersonOrderPrivileges? _inPersonOrderPrivileges =
      AppController.instance.getInpersonOrderPrivileges;
  bool isDistributorsPage = false;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  List<Contacts> _connectionsList = [];
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  Contacts? connectionsDropdownValue;
  late InvitationService _invitationService;
  var mergedList = [];
  late ThemeData theme;
  int tabIndexColorChange = 0;
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _invitationService = InvitationService();
    buName = AppController.instance.getBuName;
    buId = AppController.instance.getMyBuId;
    _tabController = TabController(length: 2, vsync: this, initialIndex: 0);
    loadConnectionsData();
  }

  loadConnectionsData() async {
    if (await NetworkStatus.getInternetStatus()) {
      this.getContacts(buId).then((value) {
        _connectionsList.clear();
        _connectionsList.addAll(value);
        loadGetContacts("");
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  @override
  Widget build(BuildContext context) {
    Size screensize = MediaQuery.of(context).size;
    return WillPopScope(
        child: SafeArea(
          child: Scaffold(
              key: _scaffoldkey,
              backgroundColor: Colors.white,
              appBar: AppBar(
                iconTheme: IconThemeData(color: theme.colorScheme.primary),
                centerTitle: true,
                elevation: 0.0,
                title: AppbarName(
                    title: Language()
                        .getString(Constants.IN_PERSON_ORDERS, selectedLang),
                    buName: "$buName"),
                backgroundColor: Colors.transparent,
                bottom: PreferredSize(
                  preferredSize: Size.fromHeight(screensize.height * 0.09),
                  child: TabBar(
                      indicatorSize: TabBarIndicatorSize.tab,
                      controller: _tabController,
                      indicator: BoxDecoration(
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey,
                              blurRadius: 6.0,
                            ),
                            BoxShadow(color: Colors.white, offset: Offset(0, 9)),
                          ],
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(10),
                              topRight: Radius.circular(10)),
                          color: Colors.white),
                      onTap: (value) {
                        if (!kIsWeb) {
                          CommonMethods.hideKeyboard(context);
                        }
                        setState(() {
                          _tabController!.index = value;
          
                          if (_tabController!.index == 2) {
                            isDistributorsPage = true;
                          } else {
                            isDistributorsPage = false;
                          }
                        });
                      },
                      tabs: <Widget>[
                        Tab(
                          child: Text(
                            Language()
                                .getString(Constants.BUY_ORDERS, selectedLang),
                            style: TextStyle(color: theme.colorScheme.primary),
                          ),
                        ),
                        Tab(
                          child: Text(
                            Language()
                                .getString(Constants.SELL_ORDERS, selectedLang),
                            style: TextStyle(color: theme.colorScheme.primary),
                          ),
                        ),
                        // Tab(
                        //   child: Text(
                        //     Language()
                        //         .getString(Constants.DISTRIBUTORS, selectedLang),
                        //     style: TextStyle(color: theme.colorScheme.primary),
                        //   ),
                        // ),
                      ]),
                ),
                actions: <Widget>[
                  this.placeOrderFunctionality(),
                  AppUtills.homeButton(context),
                ],
              ),
              drawer: MyDrawer(),
              body: isLoading
                  ? Text("")
                  : TabBarView(
                      physics: NeverScrollableScrollPhysics(),
                      controller: _tabController,
                      children: [
                          BuyOrdersListPage(buyOrders: _buyOrdersList),
                          SellOrdersListPage(sellOrders: _sellOrdersList),
                          // DistributorsPage(),
                        ])),
        ),
        onWillPop: () {
          return CommonMethods.onBackPress(context).then((value) => value);
        });
  }

  Widget placeOrderFunctionality() {
    if (_tabController!.index == 1 &&
        _inPersonOrderPrivileges!.add_in_person_order) {
      return IconButton(
          icon: Icon(Icons.add),
          onPressed: () {
            if (_connectionsList.length > 0) {
              this.showConnectionsPopUp();
            } else {
              String? message = "";
              if (AppController.instance.getLoginUserRole ==
                  Constants.ROLE_FIELD_OFFICER) {
                message = Language().getString(
                    Constants.NO_CONNECTIONS_FOUND +
                        "\n" +
                        Constants.PLEASE_CONTACT_ADMIN,
                    selectedLang);
              } else {
                message = Language()
                    .getString(Constants.NO_CONNECTIONS_FOUND, selectedLang);
              }
              Dialogs.yesCancelDialog(
                  context,
                  Language().getString(Constants.ERROR, selectedLang),
                  message,
                  Language().getString(Constants.OKAY_STR, selectedLang),
                  "",
                  false);
            }
          });
    } else if (_tabController!.index == 2) {
      return IconButton(
          icon: Icon(Icons.add),
          onPressed: () {
            Navigator.push(
                context,
                new MaterialPageRoute(
                    builder: (context) => AddMenuOrder(
                        connectionId: "",
                        buId: buId,
                        buName: buName,
                        isNewOrder: true,
                        isFromDistributorsPage: isDistributorsPage)));
          });
    } else {
      return Container();
    }
  }

  showConnectionsPopUp() {
    return showDialog(
        barrierDismissible: false,
        barrierColor: Colors.black54,
        context: context,
        builder: (context) {
          return AlertDialog(
              elevation: 100.0,
              contentPadding: EdgeInsets.fromLTRB(15.0, 0, 15.0, 0),
              backgroundColor: Colors.white, //(0XFFE0E0E0),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(
                  Radius.circular(
                    7.0,
                  ),
                ),
              ),
              title: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Text(
                    Language()
                        .getString(Constants.CHOOSE_CONNECTION, selectedLang),
                    style: TextStyle(color: theme.colorScheme.primary),
                  ),
                  GestureDetector(
                    onTap: () {
                      Navigator.of(context).pop();
                    },
                    child: Icon(
                      Icons.close,
                      color: Colors.red,
                    ),
                  ),
                ],
              ),
              content: StatefulBuilder(
                  builder: (BuildContext context, StateSetter setState) {
                return Container(
                    height: 150.0,
                    margin: EdgeInsets.only(top: 20),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Container(
                            margin: EdgeInsets.symmetric(
                                horizontal: 5.0, vertical: 10.0),
                            decoration: AppUtills.boxDecoration(),
                            child: DropdownButton<Contacts>(
                                onTap: () {
                                  FocusScope.of(context).unfocus();
                                },
                                value: connectionsDropdownValue,
                                hint: Container(
                                  padding: EdgeInsets.symmetric(horizontal: 8),
                                  child: new Text(Language().getString(
                                      Constants.SELECT_GROUP, selectedLang)),
                                ),
                                isExpanded: true,
                                underline: SizedBox(),
                                onChanged: (Contacts? data) {
                                  setState(() {
                                    connectionsDropdownValue = data;
                                  });
                                },
                                items: _connectionsList.map((Contacts model) {
                                  return new DropdownMenuItem<Contacts>(
                                    child: Container(
                                      padding:
                                          EdgeInsets.symmetric(horizontal: 8),
                                      child: new Text(model.buName!),
                                    ),
                                    value: model,
                                  );
                                }).toList()),
                          ),
                          // Container(
                          //   margin: EdgeInsets.symmetric(
                          //       horizontal: 5.0, vertical: 10.0),
                          //   decoration: AppUtills.boxDecoration(),
                          //   child: SearchableDropdown.single(
                          //     items: _connectionsList.map((Contacts model) {
                          //       return new DropdownMenuItem<dynamic>(
                          //         child: RichText(
                          //           text: TextSpan(children: [
                          //             TextSpan(
                          //               text: model.buName,
                          //               style: TextStyle(
                          //                   color: Colors.black,
                          //                   fontFamily: StyleView.FONT_TITLE),
                          //             ),
                          //             TextSpan(
                          //                 text: model.isOnline
                          //                     ? "   ( Online Connection )"
                          //                     : "   ( Offline Customer )",
                          //                 style: TextStyle(
                          //                     color: Colors.grey,
                          //                     fontSize: 10.0,
                          //                     fontFamily: StyleView.FONT_TITLE))
                          //           ]),
                          //         ),
                          //         // new Text(model.buName +
                          //         // (model.isOnline
                          //         //     ? "Online Connection"
                          //         //     : "Offline Customer")),
                          //         value: model,
                          //       );
                          //     }).toList(),
                          //     value: connectionsDropdownValue,
                          //     underline: Container(),
                          //     hint: Language()
                          //         .getString(Constants.SEARCH, selectedLang),
                          //     searchHint: Language()
                          //         .getString(Constants.SEARCH, selectedLang),
                          //     onChanged: (value) {
                          //       setState(() {
                          //         connectionsDropdownValue = value;
                          //       });
                          //     },
                          //     isExpanded: true,
                          //   ),
                          // ),
                          SizedBox(height: 10.0),
                          Container(
                              width: MediaQuery.of(context).size.width,
                              child: CommonButtonsView(
                                context: context,
                                b1Text: "",
                                b2Text: Language()
                                    .getString(Constants.DONE, selectedLang),
                                onb2Action: () async {
                                  if (connectionsDropdownValue != null) {
                                    Navigator.pop(context);

                                    Navigator.push(
                                        context,
                                        new MaterialPageRoute(
                                            builder: (context) => AddMenuOrder(
                                                  connectionId:
                                                      connectionsDropdownValue!
                                                          .buId,
                                                  connectionName:
                                                      connectionsDropdownValue!
                                                          .buName,
                                                  buId: buId,
                                                  buName: buName,
                                                  isNewOrder: true,
                                                  isFromDistributorsPage:
                                                      isDistributorsPage,
                                                  inOnlineConnection:
                                                      connectionsDropdownValue!
                                                          .isOnline,
                                                )));
                                  } else {
                                    Dialogs.yesCancelDialog(
                                        context,
                                        Language().getString(
                                            Constants.ERROR, selectedLang),
                                        Language().getString(
                                            Constants.SELECT_BU, selectedLang),
                                        Language().getString(
                                            Constants.OKAY_STR, selectedLang),
                                        "",
                                        false);
                                  }
                                },
                              )),
                        ]));
              }));
        });
  }

  Future<List<Contacts>> getContacts(String? buId) async {
    setState(() {
      _connectionsList.clear();
    });
    String body = json.encode({"buId": buId, "filters": {}});

    var response = await _invitationService
        .findAllConnections_grpc(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<Contacts> _model = [];

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(resObj)) {
        for (var noteJson in resObj['results']) {
          _model.add(Contacts.fromJson(noteJson));
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
      return _model;
  }

  getAllContacts(String params) async {
    String body = json.encode({"buId": buId, "filters": {}});

    var response = await _invitationService
        .getContactsByBuId_grpc(
            body, AppController.instance.getAuthorizationKey, params)
        .catchError((onError) async {
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    GRPCResponse data = response;
    if (!data.getIsError! && !data.getIsException!) {
      var resBody = json.decode(data.message!);
      var resultArray = resBody['results'];
      for (var object in resultArray) {
        BuListModel _buModel = BuListModel.fromJson(object);
        Contacts _model = Contacts(
            buId: _buModel.recordId, buName: _buModel.name, isOnline: false);
        _connectionsList.add(_model);
        // _list.add(BuListModel.fromJson(object));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          data.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  loadGetContacts(String params) async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        // isLoadingProgress = true;
      });

      this.getAllContacts(params).then((value) {
        setState(() {
          // _buList.clear();
          // _buList.addAll(value);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }
}
