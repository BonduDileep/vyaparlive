import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Transaction/card_view/ProductCardDesign.dart';
import 'package:vyaparlive/components/AppController.dart';

import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/components/privileges/inperson_order_privileges.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/BusinessUnitModel.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/OrderDAO.dart';
import 'package:vyaparlive/model/TransactionsModel.dart';
import 'package:vyaparlive/model/bu_model/LocationsModel.dart';
import 'package:vyaparlive/orders_view/EditMenuOrder.dart';
import 'package:vyaparlive/orders_view/OrdersPage.dart';
import 'package:vyaparlive/service/Service.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/service/bu_list_grpc_service.dart';
import 'package:vyaparlive/service/organization_service.dart';
import 'package:vyaparlive/utills/SharePref.dart';

class OrderDetailsPage extends StatefulWidget {
  OrderDetailsPage(
      {this.isFromSellOrders = false, this.orderId, this.transactionName});
  final bool isFromSellOrders;
  final String? orderId;
  final String? transactionName;
  @override
  _OrderDetailsPageState createState() => _OrderDetailsPageState();
}

class _OrderDetailsPageState extends State<OrderDetailsPage> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  late Service _service;
  // ProgressDialog progressDialog;
  List<OrderDAO> _ordersList = [];
  List<Product> _filterOrdersList = [];
  List<Product> _products = [];
  List<Product> selectedProducts = [];

  String? buId = "";
  String? buName = "";
  final reasonController = TextEditingController();
  bool isProductAdded = false;
  String? userName = "";
  InPersonOrderPrivileges? _inPersonOrderPrivileges =
      AppController.instance.getInpersonOrderPrivileges;
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  late BuListGrpcService _transactionService;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  Locations? locationDropdownValue;
  List<Locations> locationsList = [];
  late OrganizationService _organizationService;
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _organizationService = OrganizationService();
    _service = Service();
    _transactionService = BuListGrpcService();
    buId = AppController.instance.getMyBuId;
    buName = AppController.instance.getBuName;
    SharePref().getUserName().then((value) {
      setState(() {
        userName = value;
      });
    });

    this.loadOrderData();
    this.getBuData().then((value) {
      setState(() {
        locationsList.clear();
        if (value.length > 0) {
          locationsList.addAll(value[0].locationsList!);
        }
      });
    });
  }

  loadOrderData() async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
      });
      this.getOrderDetails().then((value) {
        setState(() {
          _ordersList.addAll(value);
          if (_ordersList.length > 0) {
            for (int i = 0;
                i < _ordersList[0].orderDetails!.products!.length;
                i++) {
              _products.add(_ordersList[0].orderDetails!.products![i]);
              _filterOrdersList.add(_ordersList[0].orderDetails!.products![i]);
            }
          }
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
        body: Stack(
      children: [
        SafeArea(
          child: Scaffold(
            key: _scaffoldkey,
            backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
            appBar: AppBar(
                centerTitle: true,
                elevation: 0,
                iconTheme: IconThemeData(color: theme.colorScheme.primary),
                title: AppbarName(
                    title: Language()
                        .getString(Constants.ORDER_DETAILS, selectedLang),
                    buName: "${widget.transactionName}"),
                actions: [
                  AppUtills.homeButton(context),
                ],
                backgroundColor: Colors.transparent //(Constants.APP_COLOR),
                ),
            bottomNavigationBar: _ordersList.length > 0 && widget.isFromSellOrders
                ? sellerBottomView()
                : buyerBottomView(),
            body: Container(
                padding: EdgeInsets.all(5.0),
                child: _ordersList.length == 0
                    ? Center(
                        child: Text(
                        Language()
                            .getString(Constants.NO_DATA_FOUND, selectedLang),
                      ))
                    : SingleChildScrollView(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            this.showOrderInformation(),
                            SizedBox(height: 5.0),
                            for (int index = 0; index < _products.length; index++)
                              ProductCardDesignView(
                                strTotalAmount: Language().getString(
                                    Constants.TOTAL_AMOUNT, selectedLang),
                                strUnitPrice: Language().getString(
                                    Constants.PRICE_UNIT, selectedLang),
                                strQuantity: Language()
                                    .getString(Constants.QUANTITY, selectedLang),
                                strOfferApplied: Language().getString(
                                    Constants.OFFER_APPLIED, selectedLang),
                                productName: _products[index].productName,
                                productImage: _products[index].productImage,
                                productPrice: _products[index].total,
                                productQnty: _products[index].quantity,
                                quantityIn: _products[index].quantityIn,
                              )
                          ],
                        ),
                      )),
          ),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    ));
  }

  showProductsDesign(int index) {
    return Card(
        elevation: 5.0,
        color: Colors.grey[100],
        child: Container(
          padding: EdgeInsets.all(5.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Expanded(
                  flex: 1,
                  child: Row(
                    children: <Widget>[
                      Card(
                        elevation: 2,
                        child: Container(
                            padding: EdgeInsets.all(5.5),
                            margin: EdgeInsets.all(2.5),
                            child: AppUtills.displayImage(
                                _products[index].productImage!.length > 0
                                    ? _products[index].productImage![0]
                                    : null,
                                context: context)),
                      ),
                    ],
                  )),
              Expanded(
                flex: 3,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Expanded(
                          flex: 2,
                          child: new Container(
                            child: Text(_products[index].productName!,
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Color(Constants.APP_COLOR))),
                          ),
                        ),
                        Expanded(
                          flex: 1,
                          child: new Container(
                            child: Text(
                              Language().getString(
                                      Constants.QUANTITY, selectedLang) +
                                  " : " +
                                  "${_products[index].quantity}",
                              style:
                                  TextStyle(color: Color(Constants.APP_COLOR)),
                            ),
                          ),
                        )
                      ],
                    ),
                    SizedBox(
                      height: 5.0,
                    ),
                    Row(
                      children: <Widget>[
                        Expanded(
                          flex: 2,
                          child: new Container(
                            child: Text(
                              Language().getString(
                                      Constants.PRICE, selectedLang) +
                                  " :  ${_products[index].total}",
                              style:
                                  TextStyle(color: Color(Constants.APP_COLOR)),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ));
  }

  handlingBuyerView(int index) {
    if (_ordersList[0].orderDetails!.status == "pending") {
      return Expanded(
          flex: 2,
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Container(
                      child: new IconButton(
                          icon: Icon(Icons.remove),
                          onPressed: () {
                            int? count = _products[index].quantity as int?;
                            setState(() {
                              if (count == _filterOrdersList[index].quantity) {
                                _products[index] = _filterOrdersList[index];
                              } else {
                                count = count! - 1;
                                if (count ==
                                    _filterOrdersList[index].quantity) {
                                  isProductAdded = false;
                                }

                                _products[index] = Product(
                                    id: _products[index].id,
                                    productName: _products[index].productName,
                                    productImage: _products[index].productImage,
                                    quantity: count,
                                    total: _products[index].total);
                              }
                            });
                          }),
                    ),
                    new Container(
                        height: 25.0,
                        width: 25.0,
                        decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey)),
                        child: Center(
                            child: Text(_products[index].quantity.toString()))),
                    Container(
                      child: new IconButton(
                        icon: Icon(Icons.add),
                        onPressed: () {
                          int? count = _products[index].quantity as int?;
                          setState(() {
                            count = count! + 1;
                            if (count != _filterOrdersList[index].quantity) {
                              isProductAdded = true;
                              _products[index] = Product(
                                  id: _products[index].id,
                                  productName: _products[index].productName,
                                  productImage: _products[index].productImage,
                                  quantity: count,
                                  total: _products[index].total);
                            }
                          });
                        },
                      ),
                    )
                  ],
                ),
              ]));
    } else {
      return Expanded(
        flex: 1,
        child: new Container(
          child: Text(
            Language().getString(Constants.QUANTITY, selectedLang) +
                " : " +
                "${_products[index].quantity}",
            style: TextStyle(color: Color(Constants.APP_COLOR)),
          ),
        ),
      );
    }
  }

  buyerBottomView() {
    if (_ordersList.length > 0 &&
        _ordersList[0].orderDetails!.status == "pending") {
      return Container(
        color: Color(Constants.APP_BACKGROUND_COLOR),
        padding: EdgeInsets.all(20),
        child: Row(
          children: <Widget>[
            Expanded(
                child: Container(
              padding: EdgeInsets.only(left: 10),
              margin: EdgeInsets.only(left: 0, right: 5),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  textStyle: TextStyle(
                    color: Colors.white,
                  ),
                  backgroundColor: Colors.red,
                ),
                child: Text(
                  Language().getString(Constants.REJECT_STRING, selectedLang),
                ),
                onPressed: () {
                  showChoiceDialog();
                },
              ),
            )),
            Expanded(
                child: Container(
              padding: EdgeInsets.only(right: 10),
              margin: EdgeInsets.only(left: 5, right: 0),
              child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    textStyle: TextStyle(color: Colors.white),
                    backgroundColor: Colors.green,
                  ),
                  child: Text(
                    Language().getString(Constants.ACCEPT_STRING, selectedLang),
                  ),
                  onPressed: () async {
                    this.buildShipToAddressDropdown();
                  }),
            )),
          ],
        ),
      );
    } else {
      return showCurrentStatus();
    }
  }

  sellerBottomView() {
    return showCurrentStatus();
  }

  updateProductView() {
    return Container(
        padding: EdgeInsets.all(10.0),
        child: ElevatedButton(
            style: CommonMethods.elevatedButtonStyle(),
            onPressed: () async {
              if (await NetworkStatus.getInternetStatus()) {
                this.serviceCallUpdateOrder();
              } else {
                AppUtills.showSnackBar(_scaffoldkey,
                    Language().getString(Constants.NO_INTERNET, selectedLang),
                    snackBarBgColor: Colors.black,
                    messageColor: Colors.white,
                    buttonColor: Colors.white);
              }
            },
            child: Text(
                Language().getString(Constants.UPDATE_ORDER, selectedLang),
                style: TextStyle(color: Colors.white))));
  }

  showCurrentStatus() {
    if (_ordersList.length > 0) {
      return Container(
          padding: EdgeInsets.all(20.0),
          child: Row(
            children: <Widget>[
              Text(
                Language().getString(
                        Constants.ORDER_STATUS_STRING, selectedLang) +
                    " : ",
                style: TextStyle(
                    color: Color(Constants.APP_COLOR),
                    fontSize: 15.0,
                    fontWeight: FontWeight.bold),
              ),
              Text(
                _ordersList[0].orderDetails!.status!,
                style: TextStyle(
                    fontSize: 13.0,
                    color: CommonMethods.transactionStatusColorHandling(
                        _ordersList[0].orderDetails!.status),
                    fontWeight: FontWeight.bold),
              ),
            ],
          ));
    }
  }

  serviceCallUpdateOrder() async {
    setState(() {
      isLoadingProgress = true;
    });
    List<Map<String, dynamic>> productsArray = [];
    var productsObject;
    for (int i = 0; i < _products.length; i++) {
      productsObject = {
        "id": _products[i].id,
        "unit_price": _products[i].unitPrice,
        "quantity": _products[i].quantity,
        "discount": "",
        "tax": "",
        "total": _products[i].total,
        "product_name": _products[i].productName,
        "product_image": ""
      };
      productsArray.add(productsObject);
    }
    Map data = {
      "buyer": {
        "id": _ordersList[0].buyer!.id,
        "name": _ordersList[0].buyer!.name
      },
      "seller": {
        "id": _ordersList[0].seller!.id,
        "name": _ordersList[0].seller!.name
      },
      "order_details": {
        "products": productsArray,
        "status": _ordersList[0].orderDetails!.status
      },
      "id": _ordersList[0].id
    };
    String body = json.encode(data);
    http.Response response =
        await _service.updateMenuOrder(body).catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    // await progressDialog.hide();
    setState(() {
      isLoadingProgress = false;
    });
    if (response.statusCode == 200) {
      return showDialog(
          context: (context),
          builder: (context) => AlertDialog(
                title: Text(
                  Language().getString(Constants.SUCCESS, selectedLang),
                ),
                content: Text(
                  Language().getString(Constants.ORDER_UPDATED, selectedLang),
                ),
                actions: <Widget>[
                  TextButton(
                      onPressed: () async {
                        Navigator.of(context).pop();
                        setState(() {
                          _ordersList.clear();
                          _products.clear();
                          _filterOrdersList.clear();
                          isProductAdded = false;
                        });
                        loadOrderData();
                      },
                      child: Text(
                        Language().getString(Constants.OKAY_STR, selectedLang),
                      ))
                ],
              ));
    } else if (response.statusCode == 401) {
      CommonMethods.handleUnauthorizedAccess(context);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          response.body,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  Future<List<OrderDAO>> getOrderDetails() async {
    setState(() {
      _ordersList.clear();
      _products.clear();
      _filterOrdersList.clear();
    });
    String body = json.encode({"id": widget.orderId});
    var response = await _transactionService
        .findOrdersDetailsById(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<OrderDAO> list = [];
    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(data)) {
        list.add(OrderDAO.fromJson(data[0]));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
      return list;
  }

  Future<void> showChoiceDialog() {
    return showDialog(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(15.0)),
            ),
            title: Column(
              children: <Widget>[
                Align(
                  alignment: Alignment.topRight,
                  child: GestureDetector(
                    onTap: () {
                      Navigator.of(context).pop();
                    },
                    child: Icon(
                      Icons.close,
                      color: Colors.red,
                    ),
                  ),
                ),
                SizedBox(
                  height: 2.5,
                ),
                buildTextFormFields(
                    Constants.ENTER_CODE_HERE_STR, reasonController),
              ],
            ),
            content: ElevatedButton(
                onPressed: () async {
                  Navigator.of(context).pop();
                  if (reasonController.text.isEmpty) {
                    alertDialog(
                      Language().getString(
                          Constants.PLEASE_ENTER_REASON, selectedLang),
                    );
                  } else {
                    if (await NetworkStatus.getInternetStatus()) {
                      this.onRejectOrder();
                    } else {
                      AppUtills.showSnackBar(
                          _scaffoldkey,
                          Language()
                              .getString(Constants.NO_INTERNET, selectedLang),
                          snackBarBgColor: Colors.black,
                          messageColor: Colors.white,
                          buttonColor: Colors.white);
                    }
                  }
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFF083e64),
                  textStyle: TextStyle(color: Colors.white),
                  elevation: 3.0,
                ),
                child: Text(
                  Language().getString(Constants.SUBMIT_STRING, selectedLang),
                  style: TextStyle(color: Colors.white),
                )),
          );
        });
  }

  void acceptOrder() async {
    setState(() {
      isLoadingProgress = true;
    });

    Map data = {
      "id": widget.orderId,
      "message": "Order Accepted",
      "status": "Order Accepted",
      "user_name": userName,
      "ship_to_address":
          locationDropdownValue != null ? locationDropdownValue!.locationId : ""
    };
    String body = json.encode(data);
    var response = await _transactionService
        .acceptMenuOrder(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResposne = response;
    if (!_grpcResposne.getIsError! && !_grpcResposne.getIsException!) {
      // loadOrderData();
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          Language().getString(Constants.ORDER_ACCEPTE_SUCCESS, selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
      if (action == DialogAction.yes) {
        Navigator.pushReplacement(
            context,
            MaterialPageRoute(
                builder: (context) => OrdersPage(), maintainState: false));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(
              Language().getString(Constants.ERROR, selectedLang),
              selectedLang),
          "${_grpcResposne.message}",
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  onRejectOrder() async {
    setState(() {
      isLoadingProgress = true;
      _ordersList.clear();
    });
    Map data = {
      "id": widget.orderId,
      "message": reasonController.text,
      "status": "Order Rejected"
    };
    String body = json.encode(data);
    var response = await _transactionService
        .acceptMenuOrder(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResposne = response;
    if (!_grpcResposne.getIsError! && !_grpcResposne.getIsException!) {
      loadOrderData();
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          "${_grpcResposne.message}",
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  alertDialog(String? message) {
    return showDialog(
        barrierDismissible: false,
        context: (context),
        builder: (context) {
          return AlertDialog(
            content: Text(message!),
            actions: <Widget>[
              TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: Text(
                    Language().getString(Constants.OKAY_STR, selectedLang),
                  ))
            ],
          );
        });
  }

  buildTextFormFields(
    String _labelText,
    TextEditingController _controller,
  ) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8.0, vertical: 8.0),
      child: new TextFormField(
        controller: _controller,
        style: TextStyle(fontFamily: StyleView.FONT_TITLE),
        decoration: InputDecoration(
          labelText: Language().getString(Constants.ENTER_REASON, selectedLang),
          isDense: true,
          border: OutlineInputBorder(),
          focusColor: Color(0xFF083e64),
          enabledBorder:
              OutlineInputBorder(borderSide: BorderSide(color: Colors.grey)),
          focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(color: StyleView.secondaryColor)),
        ),
        onChanged: (text) => {text = reasonController.text},
      ),
    );
  }

  Future<List<BusinessUnitModel>> getBuData() async {
    setState(() {
      isLoadingProgress = true;
      progressMessage =
          Language().getString(Constants.GETTING_LOACTION_DATA, selectedLang);
    });
    locationsList.clear();
    String body = json.encode({"id": buId});

    var response = await _organizationService
        .getOrganizationDataById(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<BusinessUnitModel> _list = [];

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var object = json.decode(_grpcResponse.message!);
      _list.add(BusinessUnitModel.fromJson(object[0]));
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return _list;
  }

  buildShipToAddressDropdown() {
    return showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) {
          return AlertDialog(
              title: Container(
                child: Text(
                    Language()
                        .getString(Constants.SHIP_TO_LOCATION, selectedLang),
                    style: TextStyle(
                        fontSize: 15.0,
                        fontWeight: FontWeight.bold,
                        color: theme.colorScheme.primary)),
              ),
              content:
                  StatefulBuilder(builder: (context, StateSetter setState) {
                return Container(
                  height: 150.0,
                  child: Column(
                    children: [
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.all(2.0),
                          child: Container(
                            decoration: AppUtills.boxDecoration(),
                            padding: EdgeInsets.all(2),
                            child: DropdownButton<Locations>(
                              value: locationDropdownValue,
                              hint: new Text(Language().getString(
                                  Constants.SELECT_SHIP_TO_LOCATION,
                                  selectedLang)),
                              isExpanded: true,
                              underline: SizedBox(),
                              onChanged: (Locations? data) {
                                setState(() {
                                  locationDropdownValue = data;
                                });
                              },
                              items: locationsList.map((Locations model) {
                                return new DropdownMenuItem<Locations>(
                                  child: new Text(model.locationName!),
                                  value: model,
                                );
                              }).toList(),
                            ),
                          ),
                        ),
                      ),
                      Container(
                          margin: EdgeInsets.symmetric(vertical: 15.0),
                          padding: EdgeInsets.only(bottom: 10),
                          child: CommonButtonsView(
                            context: context,
                            b1Text: Language()
                                .getString(Constants.STR_CANCEL, selectedLang),
                            b2Text: Language()
                                .getString(Constants.CONTINUE, selectedLang),
                            onb1Action: () {
                              locationDropdownValue = null;
                              Navigator.of(context).pop();
                            },
                            onb2Action: () async {
                              Navigator.of(context).pop();
                              if (await NetworkStatus.getInternetStatus()) {
                                this.acceptOrder();
                              } else {
                                AppUtills.showSnackBar(
                                    _scaffoldkey,
                                    Language().getString(
                                        Constants.NO_INTERNET, selectedLang),
                                    snackBarBgColor: Colors.black,
                                    messageColor: Colors.white,
                                    buttonColor: Colors.white);
                              }
                            },
                          ))
                    ],
                  ),
                );
              }));
        });
  }

  showOrderInformation() {
    return Container(
        child: Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
              child: Container(
                  child: (widget.isFromSellOrders)
                      ? this.showSimpleRowText(
                          Constants.BUYER, _ordersList[0].buyer!.name!)
                      : this.showSimpleRowText(
                          Constants.SELLER, _ordersList[0].seller!.name!))),
          Expanded(
              child: Container(
                  height: 30.0,
                  child: (_ordersList[0].orderDetails!.status == "pending" &&
                          _inPersonOrderPrivileges!.edit_in_person_order)
                      ? ElevatedButton(
                          style: ElevatedButton.styleFrom(
                              backgroundColor: theme.colorScheme.primary),
                          onPressed: () async {
                            var data = await Navigator.push(
                                context,
                                new MaterialPageRoute(
                                    builder: (context) => EditMenuOrderPage(
                                          orderId: _ordersList[0].id,
                                          transactionName:
                                              widget.transactionName,
                                          isFromSellOrders:
                                              widget.isFromSellOrders,
                                        )));
                            if (data != null) {
                              loadOrderData();
                            }
                          },
                          child: Text(
                            Language().getString(
                                Constants.EDIT_PRODUCTS, selectedLang),
                            style: TextStyle(color: Colors.white),
                          ))
                      : Container()))
        ],
      ),
    ));
  }

  showSimpleRowText(String title, String name) {
    return Row(
      children: [
        Container(
            child: Text(
          Language().getString(title, selectedLang),
          style: TextStyle(
              color: Color(Constants.APP_COLOR),
              fontSize: 15.0,
              fontWeight: FontWeight.bold),
        )),
        Expanded(
            child: Row(
          children: [
            Text(" : "),
            Expanded(
              child: Text(name),
            )
          ],
        ))
      ],
    );
  }
}
