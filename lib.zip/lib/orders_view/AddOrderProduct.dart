import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Product/CategorySearchPage.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/Contacts.dart';
import 'package:vyaparlive/model/DistributorsDAO.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/ModelProduct.dart';
import 'package:vyaparlive/model/product_model/OffersDAO.dart';
import 'package:vyaparlive/model/product_model/ProductModel.dart';
import 'package:vyaparlive/orders_view/OrdersPage.dart';
import 'dart:convert';
import 'package:vyaparlive/orders_view/ReviewProducts.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:vyaparlive/service/bu_list_grpc_service.dart';
import 'package:vyaparlive/service/invitation_services.dart';
import 'package:vyaparlive/service/product_services.dart';
import 'package:vyaparlive/utills/SharePref.dart';

class AddMenuOrder extends StatefulWidget {
  AddMenuOrder(
      {this.buId,
      this.buName,
      this.isNewOrder,
      this.isFromDistributorsPage = false,
      this.connectionId = "",
      this.connectionName = "",
      this.inOnlineConnection = false});
  final String? buId;
  final String? buName;
  final bool? isNewOrder;
  final bool isFromDistributorsPage;
  final String? connectionId;
  final String? connectionName;
  final bool inOnlineConnection;
  @override
  _AddMenuOrderState createState() => _AddMenuOrderState();
}

class _AddMenuOrderState extends State<AddMenuOrder> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  List<BuProductModal> _reponseObject = [];
  List<ModelProduct> _products = [];
  List<ModelProduct> selectedProducts = [];
  String? buId = "";
  List<Contacts> _connectionsList = [];
  List<DistributorsDAO> _distributorsList = [];
  Contacts? connectionsDropdownValue;
  // DistributorsDAO? buyerDistributorDropdown;
  // DistributorsDAO? sellerDistributorDropdown;
  Contacts? buyerDistributorDropdown;
  Contacts? sellerDistributorDropdown;
  List<TextEditingController> _enterQuantity = [];
  TextEditingController _searchController = TextEditingController();
  bool isLoading = false;
  bool isLoadingProgress = true;
  String progressMessage = Constants.GETTING_DATA;
  bool isShowFloatButton = false;
  String showLoaderText = "No data found";
  late BuListGrpcService _transactionService;
  late ProductService _productService;
  String productQuantity = "";
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  late InvitationService _invitationService;
  String? orgCurrencySymbol = "";
  String? userName = "";
  String? userId = "";
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _invitationService = InvitationService();
    _transactionService = BuListGrpcService();
    _productService = ProductService();
    buId = widget.buId;
    loadProductsData();
    loadContactsData();
    // orgCurrencySymbol = AppController.instance.getBuCurrencySymbol;
    String? symbol = AppController.instance.getBuCurrencySymbol;
    orgCurrencySymbol = (symbol != null && symbol.isNotEmpty && symbol!="-") ? symbol : "\u20B9";
    SharePref().getUserName().then((value) {
      userName = value;
    });
    SharePref().getUserId().then((value) {
      userId = value;
    });
  }

  loadProductsData(
      {String name = "",
      String? productSector = "",
      String? productSegment = "",
      String? productCategory = "",
      String? productSubCategory = ""}) async {
    if (await NetworkStatus.getInternetStatus()) {
      getBuProducts(
              name: name,
              productSector: productSector,
              productSegment: productSegment,
              productCategory: productCategory,
              productSubCategory: productSubCategory)
          .then((value) {
        _reponseObject.clear();
        _reponseObject.addAll(value);
        if (_reponseObject.length > 0) {
          setState(() {
            _products.clear();
            for (int i = 0; i < _reponseObject.length; i++) {
              _enterQuantity.add(new TextEditingController());
              // if (_reponseObject[i].batchPrice.length > 0) {
              int index = -1;
              bool isPriceAvailable = false;
              for (int j = 0; j < _reponseObject[i].batchPrice!.length; j++) {
                if (_reponseObject[i].batchPrice![j].quantity != 0 &&
                    _reponseObject[i].batchPrice![j].price != 0) {
                  // isQuantityExist = true;
                  index = j;
                  isPriceAvailable = true;
                  break;
                }
              }

              if (isPriceAvailable) {
                _products.add(ModelProduct(
                    id: _reponseObject[i].id,
                    name: _reponseObject[i].name,
                    counter: 0,
                    isButton: false,
                    images: _reponseObject[i].images,
                    price: _reponseObject[i].batchPrice![index].price,
                    quantity: _reponseObject[i].batchPrice![0].quantity,
                    isItemSelected: false,
                    batchPriceList: _reponseObject[i].batchPrice,
                    offerList: _reponseObject[i].offers,
                    quantityIn: _reponseObject[i].batchPrice!.length > 0
                        ? _reponseObject[i].batchPrice![index].quantityIn
                        : ""));
              }

              // }
            }
          });
        }
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<void> loadContactsData() async {
    if (await NetworkStatus.getInternetStatus()) {
      getContacts(buId).then((value) {
        _connectionsList.clear();
        for (var i = 0; i < value.length; i++) {
          if (value[i].isDistributor == true) {
            _connectionsList.add(value[i]);
          }
        }
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
        body: Stack(
      children: [
        SafeArea(
          child: Scaffold(
              key: _scaffoldkey,
              backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
              appBar: AppBar(
                backgroundColor: Colors.transparent, //(Constants.APP_COLOR),
                centerTitle: true,
                elevation: 0,
                iconTheme: IconThemeData(color: theme.colorScheme.primary),
                title: AppbarName(
                    title: Language()
                        .getString(Constants.IN_PERSON_ORDERS, selectedLang),
                    buName: "${widget.buName}"),
                actions: [
                  IconButton(
                      icon: Icon(
                        Icons.filter_list,
                        color: Colors.white,
                      ),
                      onPressed: () async {
                        CommonMethods.hideKeyboard(context);
                        var parms = await Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => CategorySearchPage(
                                    buName: widget.buName,
                                  )),
                        );
          
                        if (parms != null) {
                          showLoaderText = "Loading..";
                          isShowFloatButton = true;
                          isLoadingProgress = true;
                          loadProductsData(
                              productSector: parms['product_sector'],
                              productSegment: parms['product_segment'],
                              productCategory: parms['product_category'],
                              productSubCategory: parms['product_sub_category']);
                        }
                      }),
                  AppUtills.homeButton(context),
                ],
              ),
              bottomNavigationBar: (selectedProducts.length > 0)
                  ? Container(
                      margin: EdgeInsets.all(10.0),
                      padding: EdgeInsets.only(bottom: 10),
                      child: widget.isNewOrder!
                          ? CommonButtonsView(
                              context: context,
                              b1Text: "",
                              b2Text: Language().getString(
                                      Constants.PLACE_ORDER_STR, selectedLang) +
                                  " ( ${selectedProducts.length} )",
                              onb2Action: () async {
                                if (widget.isFromDistributorsPage) {
                                  if (_connectionsList.length > 0) {
                                    this.showDistributors();
                                  }
                                } else {
                                  Navigator.push(
                                    context,
                                    PageTransition(
                                      context: context,
                                      page: ReviewProductsPage(
                                        orderedProducts: selectedProducts,
                                        connectionBuId: widget.connectionId,
                                        connectionName: widget.connectionName,
                                        isOnlineConnection:
                                            widget.inOnlineConnection,
                                      ),
                                    ),
                                  );
                                }
                              },
                            )
                          : CommonButtonsView(
                              context: context,
                              b1Text: "",
                              b2Text: Language().getString(
                                      Constants.CONFIRM, selectedLang) +
                                  " ( ${selectedProducts.length} )",
                              onb2Action: () {
                                Navigator.pop(context, selectedProducts);
                              },
                            ))
                  : null,
              floatingActionButton: (isShowFloatButton)
                  ? FloatingActionButton(
                      backgroundColor: Color(Constants.APP_COLOR),
                      onPressed: () {
                        showLoaderText = "Loading..";
                        isShowFloatButton = false;
                        isLoadingProgress = true;
                        loadProductsData();
                      },
                      child: Text(
                        Language()
                            .getString(Constants.CLEAR_FILTERS, selectedLang),
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 10.0, color: Colors.white),
                      ),
                    )
                  : null,
              body: Container(
                  margin: EdgeInsets.all(10.0),
                  child: Column(
                    children: [
                      Container(
                        height: 40.0,
                        decoration: AppUtills.boxDecoration(),
                        child: Container(
                          padding: EdgeInsets.only(left: 5),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(5.0),
                            color: Colors.white,
                          ),
                          child: TextFormField(
                            controller: _searchController,
                            onChanged: onSearchTextChanged,
                            style: TextStyle(fontFamily: 'IndianRupee'),
                            decoration: InputDecoration(
                                border: InputBorder.none,
                                hintText: Language().getString(
                                    Constants.SEARCH_BY_PRODUCT, selectedLang),
                                hintStyle: TextStyle(
                                    fontSize: 13.0,
                                    fontFamily: StyleView.FONT_TITLE)),
                          ),
                        ),
                      ),
                      (_products.length == 0)
                          ? Center(
                              child: Text(
                              Language().getString(showLoaderText, selectedLang),
                            ))
                          : Expanded(
                              child: Padding(
                                padding: const EdgeInsets.only(top: 20),
                                child: ListView.builder(
                                  shrinkWrap: true,
                                  itemBuilder: (context, index) {
                                    return showProductsCardView(index);
                                  },
                                  itemCount: _products.length,
                                ),
                              ),
                            ),
                    ],
                  ))),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    ));
  }

  Widget removeProductQuantity(int index) {
    return Container(
      child: InkWell(
        onTap: () {
          CommonMethods.hideKeyboard(context);
          int count = _products[index].counter!;
          count--;
          setState(() {
            if (count == 0) {
              int productIndex = selectedProducts
                  .indexWhere((element) => element.id == _products[index].id);

              _products[index].counter = count;
              selectedProducts.removeAt(productIndex);
              _enterQuantity[index].clear();
            } else {
              if (count > 0) {
                _products[index].counter = count;
                _enterQuantity[index] = TextEditingController(
                    text: _products[index].counter.toString());
                _enterQuantity[index].selection = TextSelection.fromPosition(
                    TextPosition(offset: _enterQuantity[index].text.length));
              }
            }
          });
        },
        child: Icon(Icons.remove),
      ),
    );
  }

  Widget showProductName(int index) {
    return Expanded(
      flex: 3,
      child: new Container(
        child: Text(_products[index].name!,
            style: TextStyle(
                fontWeight: FontWeight.bold, color: theme.colorScheme.primary)),
      ),
    );
  }

  Widget showProductImage(int index) {
    return Expanded(
        child: Row(
      children: <Widget>[
        Card(
          elevation: 2,
          child: Container(
              padding: EdgeInsets.all(5.5),
              margin: EdgeInsets.all(2.5),
              child: AppUtills.displayImage(_products[index].images,
                  context: context)),
        ),
      ],
    ));
  }

  Widget addProductQuantity(int index) {
    return Container(
      child: InkWell(
        onTap: () {
          CommonMethods.hideKeyboard(context);
          int? count = _products[index].counter;
          setState(() {
            if (count == 0) {
              selectedProducts.add(_products[index]);
            }
            count = count! + 1;
            _products[index].counter = count;
            _enterQuantity[index] = TextEditingController(
                text: _products[index].counter.toString());
            _enterQuantity[index].selection = TextSelection.fromPosition(
                TextPosition(offset: _enterQuantity[index].text.length));
          });
        },
        child: Icon(Icons.add),
      ),
    );
  }

  Widget quantityInputField(int index) {
    return Expanded(
      child: Container(
        height: 30.0,
        width: 0.0,
        decoration: BoxDecoration(border: Border.all(color: Colors.grey)),
        child: Center(
          child: TextFormField(
            controller: _enterQuantity[index],
            textAlign: TextAlign.center,
            keyboardType: TextInputType.number,
            style: TextStyle(fontSize: 12.0),
            decoration: InputDecoration(
              hintText: "0",
              border: InputBorder.none,
            ),
            inputFormatters: [
              new LengthLimitingTextInputFormatter(7),
              FilteringTextInputFormatter.digitsOnly
            ],
            onChanged: (value) {
              if (value.isEmpty) {
                bool isExist = false;
                int j = -1;
                for (int i = 0; i < selectedProducts.length; i++) {
                  if (_products[index].id == selectedProducts[i].id) {
                    j = i;
                    isExist = true;
                  }
                }

                if (isExist) {
                  setState(() {
                    _products[index].counter = 0;
                    selectedProducts.removeAt(j);
                  });
                } else {
                  setState(() {
                    _products[index].counter = int.parse(value);
                    selectedProducts.add(_products[index]);
                  });
                }
              } else {
                if (value != "0") {
                  if (selectedProducts.length > 0) {
                    bool isExists = false;
                    int j = -1;
                    for (int i = 0; i < selectedProducts.length; i++) {
                      if (_products[index].id == selectedProducts[i].id) {
                        j = i;
                        isExists = true;
                      }
                    }

                    if (isExists) {
                      selectedProducts[j].counter = int.parse(value);
                      _products[index].counter = int.parse(value);
                    } else {
                      setState(() {
                        _products[index].counter = int.parse(value);
                        selectedProducts.add(_products[index]);
                      });
                    }
                  } else {
                    setState(() {
                      _products[index].counter = int.parse(value);
                      selectedProducts.add(_products[index]);
                    });
                  }
                } else {
                  _enterQuantity[index].clear();
                }
              }
            },
          ),
        ),
      ),
    );
  }

  onSearchTextChanged(String text) async {
    if (text.isEmpty) {
      showLoaderText = "Loading..";
      isLoadingProgress = true;
      loadProductsData();
    } else {
      showLoaderText = "Loading..";
      loadProductsData(name: text);
    }
  }

  Future<List<BuProductModal>> getBuProducts(
      {String name = "",
      String? productSector = "",
      String? productSegment = "",
      String? productCategory = "",
      String? productSubCategory = ""}) async {
    _products.clear();
    _reponseObject.clear();
    String body = json.encode({
      "id": buId,
      "filter": {
        "name": name,
        "product_sector": productSector,
        "product_segment": productSegment,
        "product_category": productCategory,
        "product_sub_category": productSubCategory,
        "for_sale": true,
      }
    });

    var response = await _productService
        .getProductByBuId_v2(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<BuProductModal> products = [];
    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      var data = resObj['results'];
      for (var i in data) {
        products.add(BuProductModal.fromJson(i));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return products;
  }

  Future<List<Contacts>> getContacts(String? buId) async {
    setState(() {
      _connectionsList.clear();
      isLoadingProgress = true;
    });
    String body = json.encode({"buId": buId, "filters": {}});

    var response = await _invitationService
        .findAllConnections_grpc(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<Contacts> _model = [];
    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);

      for (var noteJson in resObj['results']) {
        _model.add(Contacts.fromJson(noteJson));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
      return _model;
  }

  Future<List<DistributorsDAO>> getDistributorsList(String? buId) async {
    setState(() {
      _connectionsList.clear();
      isLoadingProgress = true;
      progressMessage = Constants.PLEASE_WAIT;
    });
    String body = json.encode({"bu": buId});
    var response = await _productService
        .getDistributorsData(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<DistributorsDAO> _model = [];
    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      for (var noteJson in resObj)
        _model.add(DistributorsDAO.fromJson(noteJson));
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return _model;
  }

  showDistributors() {
    return showDialog(
        barrierDismissible: false,
        barrierColor: Colors.black54,
        context: context,
        builder: (context) {
          return SingleChildScrollView(
            child: AlertDialog(
                elevation: 100.0,
                contentPadding: EdgeInsets.fromLTRB(15.0, 0, 15.0, 0),
                backgroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(
                    Radius.circular(7.0),
                  ),
                ),
                title: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Text(
                      Language().getString(
                          Constants.CHOOSE_DISTRIBUTOR, selectedLang),
                      style: TextStyle(color: theme.colorScheme.primary),
                    ),
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          sellerDistributorDropdown = null;
                          buyerDistributorDropdown = null;
                        });
                        Navigator.of(context).pop();
                      },
                      child: Icon(Icons.close, color: Colors.red),
                    ),
                  ],
                ),
                content: StatefulBuilder(
                    builder: (BuildContext context, StateSetter setState) {
                  return Container(
                      padding: EdgeInsets.only(top: 20),
                      child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Container(
                                margin: EdgeInsets.symmetric(vertical: 5.0),
                                child: Text(
                                    Language().getString(
                                        Constants.SELLER, selectedLang),
                                    style: TextStyle(
                                        color: theme.colorScheme.primary,
                                        fontSize: 15.0))),
                            Container(
                              decoration: BoxDecoration(
                                  color: Colors.white54,
                                  borderRadius: BorderRadius.circular(10)),
                              margin: EdgeInsets.symmetric(
                                  horizontal: 5.0, vertical: 10.0),
                              child: DropdownButton<Contacts>(
                                  value: sellerDistributorDropdown,
                                  hint: new Text(
                                    Language().getString(
                                        Constants.SELECT, selectedLang),
                                  ),
                                  isExpanded: true,
                                  underline: SizedBox(),
                                  onChanged: (value) {
                                    setState(() {
                                      sellerDistributorDropdown = value;
                                    });
                                  },
                                  items: _connectionsList.map((Contacts model) {
                                    return new DropdownMenuItem<Contacts>(
                                      child: Container(
                                        padding:
                                            EdgeInsets.symmetric(horizontal: 5),
                                        child: new Text(model.buName!),
                                      ),
                                      value: model,
                                    );
                                  }).toList()),
                            ),
                            Container(
                                margin: EdgeInsets.symmetric(vertical: 5.0),
                                child: Text(
                                    Language().getString(
                                        Constants.BUYER, selectedLang),
                                    style: TextStyle(
                                        color: theme.colorScheme.primary,
                                        fontSize: 15.0))),
                            Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: 5.0, vertical: 10.0),
                              child: DropdownButton<Contacts>(
                                  value: buyerDistributorDropdown,
                                  hint: new Text(
                                    Language().getString(
                                        Constants.SELECT, selectedLang),
                                  ),
                                  isExpanded: true,
                                  underline: SizedBox(),
                                  onChanged: (value) {
                                    setState(() {
                                      buyerDistributorDropdown = value;
                                    });
                                  },
                                  items: _connectionsList.map((Contacts model) {
                                    return new DropdownMenuItem<Contacts>(
                                      child: Container(
                                        padding:
                                            EdgeInsets.symmetric(horizontal: 5),
                                        child: new Text(model.buName!),
                                      ),
                                      value: model,
                                    );
                                  }).toList()),
                            ),
                            SizedBox(height: 10.0),
                            Container(
                                width: MediaQuery.of(context).size.width,
                                padding: EdgeInsets.symmetric(vertical: 10),
                                child: CommonButtonsView(
                                  context: context,
                                  b1Text: "",
                                  b2Text: Language().getString(
                                      Constants.CREATE_TRANSACTION,
                                      selectedLang),
                                  onb2Action: () async {
                                    if (buyerDistributorDropdown != null &&
                                        sellerDistributorDropdown != null) {
                                      if (await NetworkStatus
                                          .getInternetStatus()) {
                                        if (buyerDistributorDropdown!.buId !=
                                            sellerDistributorDropdown!.buId) {
                                          Navigator.pop(context);
                                          this.serviceCallDistributors();
                                        } else {
                                          Dialogs.yesCancelDialog(
                                              context,
                                              Language().getString(
                                                  Constants.ERROR,
                                                  selectedLang),
                                              Language().getString(
                                                  Constants.NOT_BE_SAME,
                                                  selectedLang),
                                              Language().getString(
                                                  Constants.OKAY_STR,
                                                  selectedLang),
                                              "",
                                              false);
                                        }
                                      } else {
                                        AppUtills.showSnackBar(
                                            _scaffoldkey,
                                            Language().getString(
                                                Constants.NO_INTERNET,
                                                selectedLang),
                                            snackBarBgColor: Colors.black,
                                            messageColor: Colors.white,
                                            buttonColor: Colors.white);
                                      }
                                    } else {
                                      Dialogs.yesCancelDialog(
                                          context,
                                          Language().getString(
                                              Constants.ERROR, selectedLang),
                                          Language().getString(
                                              Constants.SELECT_DISTRIBUTOR,
                                              selectedLang),
                                          Language().getString(
                                              Constants.OKAY_STR, selectedLang),
                                          "",
                                          false);
                                    }
                                  },
                                )),
                          ]));
                })),
          );
        });
  }

  showConnectionsPopUp() {
    return showDialog(
        barrierDismissible: false,
        barrierColor: Colors.black54,
        context: context,
        builder: (context) {
          return AlertDialog(
              elevation: 100.0,
              contentPadding: EdgeInsets.fromLTRB(15.0, 0, 15.0, 0),
              backgroundColor: Color(0XFFE0E0E0),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(
                  Radius.circular(
                    7.0,
                  ),
                ),
              ),
              title: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Text(
                    Language()
                        .getString(Constants.CHOOSE_CONNECTION, selectedLang),
                    style: TextStyle(color: Color(Constants.APP_COLOR)),
                  ),
                  GestureDetector(
                    onTap: () {
                      Navigator.of(context).pop();
                    },
                    child: Icon(
                      Icons.close,
                      color: Colors.red,
                    ),
                  ),
                ],
              ),
              content: StatefulBuilder(
                  builder: (BuildContext context, StateSetter setState) {
                return Container(
                    height: 150.0,
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          // Container(
                          //   margin: EdgeInsets.symmetric(
                          //       horizontal: 5.0, vertical: 10.0),
                          //   decoration: AppUtills.boxDecoration(),
                          //   child: SearchableDropdown.single(
                          //     items: _connectionsList.map((Contacts model) {
                          //       return new DropdownMenuItem<Contacts>(
                          //         child: new Text(model.buName),
                          //         value: model,
                          //       );
                          //     }).toList(),
                          //     value: connectionsDropdownValue,
                          //     underline: Container(),
                          //     hint: Language()
                          //         .getString(Constants.SEARCH, selectedLang),
                          //     searchHint: Language()
                          //         .getString(Constants.SEARCH, selectedLang),
                          //     onChanged: (value) {
                          //       setState(() {
                          //         connectionsDropdownValue = value;
                          //       });
                          //     },
                          //     isExpanded: true,
                          //   ),
                          // ),
                          SizedBox(height: 10.0),
                          Container(
                              width: MediaQuery.of(context).size.width,
                              child: ElevatedButton(
                                style: CommonMethods.elevatedButtonStyle(),
                                onPressed: () async {
                                  if (connectionsDropdownValue != null) {
                                    Navigator.pop(context);

                                    if (await NetworkStatus
                                        .getInternetStatus()) {
                                      this.serviceCallOrder();
                                    } else {
                                      AppUtills.showSnackBar(
                                          _scaffoldkey,
                                          Language().getString(
                                              Constants.NO_INTERNET,
                                              selectedLang),
                                          snackBarBgColor: Colors.black,
                                          messageColor: Colors.white,
                                          buttonColor: Colors.white);
                                    }
                                  } else {
                                    Dialogs.yesCancelDialog(
                                        context,
                                        Language().getString(
                                            Constants.ERROR, selectedLang),
                                        Language().getString(
                                            Constants.SELECT_BU, selectedLang),
                                        Language().getString(
                                            Constants.OKAY_STR, selectedLang),
                                        "",
                                        false);
                                  }
                                },
                                child: Text(
                                    Language().getString(
                                        Constants.DONE, selectedLang),
                                    style: TextStyle(color: Colors.white)),
                              )),
                        ]));
              }));
        });
  }

  void serviceCallOrder() async {
    setState(() {
      isLoadingProgress = true;
    });
    List<Map<String, dynamic>> productsArray = [];
    var productsObject;

    for (int i = 0; i < selectedProducts.length; i++) {
      if (selectedProducts[i].counter != 0) {
        productsObject = {
          "id": selectedProducts[i].id,
          "unit_price": "",
          "quantity": selectedProducts[i].counter,
          "discount": "",
          "tax": "",
          "offer_selected": selectedProducts[i].isButton,
          "total": selectedProducts[i].price
        };
        productsArray.add(productsObject);
      }
    }

    Map data = {
      "buyer": {"id": connectionsDropdownValue!.buId},
      "seller": {"id": widget.buId},
      "order_details": {"products": productsArray},
      "user_id": userId,
      "user_name": userName
    };

    String body = json.encode(data);

    // http.Response
    var response = await _transactionService
        .createMenuOrder(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      if (widget.isFromDistributorsPage) {
        this.showAlertDialog(
          Language().getString(Constants.TRANSACTION_CREATED, selectedLang),
        );
      } else {
        this.showAlertDialog(
          Language().getString(
              Constants.ORDER_PLACED_SUCCSESSFULLY_ALERT_STRING,
              selectedLang),
        );
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  void serviceCallDistributors() async {
    setState(() {
      isLoadingProgress = true;
    });
    List<Map<String, dynamic>> productsArray = [];
    var productsObject;

    for (int i = 0; i < selectedProducts.length; i++) {
      if (selectedProducts[i].counter != 0) {
        productsObject = {
          "id": selectedProducts[i].id,
          "unit_price": "",
          "quantity": selectedProducts[i].counter,
          "discount": "",
          "tax": "",
          "total": selectedProducts[i].price
        };
        productsArray.add(productsObject);
      }
    }

    Map data = {
      "buyer": buyerDistributorDropdown!.buId,
      "seller": sellerDistributorDropdown!.buId,
      "distributed_by": buId,
      "products": productsArray
    };

    String body = json.encode(data);

    var response = await _transactionService
        .createDistributorTransaction(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      this.showAlertDialog(
        Language().getString(Constants.TRANSACTION_CREATED, selectedLang),
      );
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  showAlertDialog(String? message) {
    return showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) {
          return AlertDialog(
            content: Text(message!),
            actions: <Widget>[
              TextButton(
                  onPressed: () {
                    Navigator.pushAndRemoveUntil(
                        context,
                        MaterialPageRoute(builder: (context) => OrdersPage()),
                        (Route<dynamic> route) => false);
                  },
                  child: Text(
                      Language().getString(Constants.OKAY_STR, selectedLang),
                      style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                        fontSize: 18.0,
                      ))),
            ],
          );
        });
  }

  showProductsCardView(int index) {
    return Container(
        height: MediaQuery.of(context).size.height * 0.15,
        child: Card(
            // elevation: 5.0,
            // color: Colors.grey[100],
            child: Container(
          // padding: EdgeInsets.all(5.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Expanded(
                child: Container(
                    child: (_products[index].images != null &&
                            _products[index].images!.isNotEmpty)
                        ? ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: AppUtills.imageAspectRatio(
                                '${_products[index].images}',
                                aspectRatio: 16 / 12,
                                context: context))
                        : Image.asset(
                            'assets/images/no_image.jpg',
                          )),
              ),
              Expanded(
                flex: 4,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Container(
                        margin: EdgeInsets.symmetric(vertical: 5.0),
                        child: Row(
                          children: <Widget>[
                            this.showProductName(index),
                            Expanded(
                              flex: 2,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: <Widget>[
                                  this.removeProductQuantity(index),
                                  this.quantityInputField(index),
                                  this.addProductQuantity(index)
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                      Container(
                        // margin: EdgeInsets.symmetric(vertical: 10.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Expanded(
                              flex: 2,
                              child: new Container(
                                child: Row(
                                  children: [
                                    Text(
                                      Language().getString(
                                          Constants.PRICE_UNIT, selectedLang),
                                      style: TextStyle(color: Colors.black),
                                    ),
                                    Expanded(
                                      child: Text(
                                        " : $orgCurrencySymbol " +
                                            CommonMethods.getAvailablePrice(
                                                _products[index]
                                                    .batchPriceList!) +
                                            " ${_products[index].quantityIn}",
                                        style: TextStyle(fontSize: 13.0),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            this.showAvailableOffer(index)
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        )));
  }

  showAvailableOffer(int index) {
    OffersDAO? _avilableOffer;
    for (int i = 0; i < _products[index].offerList!.length; i++) {
      if (_products[index].offerList![i].isOfferActive! &&
          !_products[index].offerList![i].isOfferExpired!) {
        _avilableOffer = _products[index].offerList![i];
      }
    }

    if (_avilableOffer != null) {
      return Expanded(
        child: Padding(
          padding: const EdgeInsets.only(top: 8.0),
          child: Center(
            child: Container(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  InkWell(
                      onTap: () {
                        CommonMethods.hideKeyboard(context);

                        Dialogs.showOffer(
                            context,
                            _avilableOffer!.offerQuantity,
                            _avilableOffer.offerName,
                            _avilableOffer.minOrder,
                            _avilableOffer.maxOrder,
                            _avilableOffer.offerType);
                      },
                      child: Container(
                        margin: EdgeInsets.symmetric(
                          horizontal: 5.0,
                        ),
                        child: Text(
                          Language().getString(Constants.OFFER, selectedLang),
                          style: TextStyle(
                              color: StyleView.offerColor,
                              decoration: TextDecoration.underline),
                        ),
                      )),
                  Container(
                    child: SizedBox(
                      height: 20.0,
                      width: 20.0,
                      child: Checkbox(
                          activeColor: StyleView.offerColor,
                          value: _products[index].isButton,
                          onChanged: (bool? value) {
                            CommonMethods.hideKeyboard(context);
                            setState(() {
                              _products[index].isButton = value;
                            });
                          }),
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      );
    } else {
      return Container();
    }
  }
}
