import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/animation/list_loader/ListLoader.dart';
import 'package:checkbox_grouped/checkbox_grouped.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Invitation/InvitationProfile.dart';
import 'package:vyaparlive/Invitation/ReceivedInvitationsCardView.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/Dialog.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/BuBasicDataModel.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/InviteesModel.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:vyaparlive/service/invitation_services.dart';
import 'dart:convert';
import 'package:vyaparlive/utills/SharePref.dart';

class InviteesStatusView extends StatefulWidget {
  @override
  _InviteesStatusViewState createState() => _InviteesStatusViewState();
}

class _InviteesStatusViewState extends State<InviteesStatusView> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  List<InviteesModel> _inviteesModel = [];

  bool isLoading = false;
  String? userContact = '';
  BuBasicDataModel? dropdownValue;
  TextEditingController _searchController = TextEditingController();
  // ProgressDialog progressDialog;
  bool isShowFloatButton = false;
  String selectedFilterText = "";
  List<String> filterOptions = [];
  List<String> _checked = [];
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  String showLoaderText = Constants.NO_DATA_FOUND;
  late InvitationService _invitationService;
  bool isSearchForParams = false;
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _invitationService = InvitationService();
    this.getLoadLanguage();
    SharePref().getPhoneNumber().then((onValue) {
      setState(() {
        userContact = onValue;
        loadInvitationsData();
      });
    });
  }

  loadInvitationsData(
      {String mobileNumber = "",
      String invitationStatus = "",
      String inviteeName = ""}) async {
    if (await NetworkStatus.getInternetStatus()) {
      if (!isSearchForParams) {
        setState(() {
          isLoadingProgress = true;
        });
      }
      getAllInvitees(
              mobileNumber: mobileNumber,
              invitationStatus: invitationStatus,
              inviteeName: inviteeName)
          .then((data) {
        setState(() {
          if (data.length > 0) {
            _inviteesModel.clear();
            _inviteesModel.addAll(data);
          } else {
            showLoaderText = Constants.NO_DATA_FOUND;
          }
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<InviteesModel>> getAllInvitees(
      {String invitationStatus = "",
      String mobileNumber = "",
      String inviteeName = ""}) async {
    setState(() {
      _inviteesModel.clear();
    });
    String body = json.encode({
      "contact": userContact,
      "filters": {
        "DateFrom": "",
        "DateTo": "",
        "status": invitationStatus,
        "companyName": inviteeName,
        "contact": mobileNumber
      }
    });

    var response = await _invitationService
        .getInviteeInvitations_grpc(body)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<InviteesModel> _model = [];

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);
      var resultArray = data['results'];
      for (var noteJson in resultArray) {
        _model.add(InviteesModel.fromJson(noteJson));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message!,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
      return _model;
  }

  getLoadLanguage() {
    filterOptions = [
      Language().getString(Constants.ACCEPTED_INVITATIONS, selectedLang),
      Language().getString(Constants.PENDING_INVITATIONS, selectedLang),
      Language().getString(Constants.REJECT_INVITATIONS, selectedLang)
    ];
  }

  buildFilterDialog() {
    return showDialog(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) {
          return StatefulBuilder(builder: (context, StateSetter setState) {
            return Scaffold(
                backgroundColor: Colors.transparent,
                body: Center(
                  child: Container(
                    // height: MediaQuery.of(context).size.height * 0.50,
                    margin: EdgeInsets.all(50.0),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.all(
                        Radius.circular(15.0),
                      ),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.all(20.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                Language().getString(
                                    Constants.SORT_INVITATIONS_BY,
                                    selectedLang),
                                style: TextStyle(
                                  fontSize: StyleView.FONT_SIZE_15,
                                  fontWeight: StyleView.fontSemiBold,
                                  fontFamily: StyleView.FONT_TITLE,
                                ),
                                textAlign: TextAlign.center,
                              ),
                              GestureDetector(
                                onTap: () {
                                  this.renderClearFilterData();
                                  Navigator.of(context).pop();
                                },
                                child: Padding(
                                  padding: EdgeInsets.all(5.0),
                                  child: Icon(
                                    Icons.close,
                                    color: Colors.red,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width,
                          height: 1,
                          color: Colors.grey,
                        ),
                        SizedBox(height: 5),
                        SimpleGroupedCheckbox<String>(
                          controller: GroupController(),
                          onItemSelected: (selected) {
                            // if (selected.length > 1) {
                            //   selected.removeAt(0);
                            // }
                            setState(() {
                              _checked.add(selected);
                            });
                          },
                          itemsTitle: filterOptions,
                          values: filterOptions,
                          groupStyle: GroupStyle(
                              activeColor: theme.colorScheme.primary,
                              itemTitleStyle: TextStyle(
                                  fontSize: 15,
                                  fontWeight: StyleView.fontMedium)),
                          // checkFirstElement: false,
                        ),
                        // CheckboxGroup(
                        //   labels: filterOptions,
                        //   checked: _checked,
                        //   onSelected: (List selected) {
                        //     if (selected.length > 1) {
                        //       selected.removeAt(0);
                        //     }
                        //     setState(() {
                        //       _checked = selected;
                        //     });
                        //   },
                        // ),
                        // Spacer(),
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                              backgroundColor: theme.colorScheme.primary),
                          onPressed: () {
                            Navigator.of(context).pop();
                            if (_checked.length > 0) {
                              setState(() {
                                isShowFloatButton = true;
                              });
                              if (_checked[0] ==
                                  Language().getString(
                                      Constants.PENDING_INVITATIONS,
                                      selectedLang)) {
                                this.loadInvitationsData(
                                    invitationStatus: "pending");
                              } else if (_checked[0] ==
                                  Language().getString(
                                      Constants.REJECT_INVITATIONS,
                                      selectedLang)) {
                                this.loadInvitationsData(
                                    invitationStatus: "rejected");
                              } else {
                                this.loadInvitationsData(
                                    invitationStatus: "accepted");
                              }
                            }
                          },
                          child: Text(Language()
                              .getString(Constants.APPLY_FILTER, selectedLang)),
                        ),
                        SizedBox(
                          height: 10.0,
                        )
                      ],
                    ),
                  ),
                ));
          });
        });
  }

  buildSearchBarView() {
    return Card(
      elevation: 5,
      shadowColor: theme.colorScheme.primary,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0),
          side:
              BorderSide(color: theme.colorScheme.primary, strokeAlign: 0.01)),
      child: Row(
        children: <Widget>[
          Expanded(
              flex: 5,
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: TextFormField(
                  controller: _searchController,
                  onChanged: onSearchTextChanged,
                  style: TextStyle(fontWeight: StyleView.fontSemiBold),
                  decoration: InputDecoration(
                      contentPadding: EdgeInsets.only(bottom: 5),
                      border: InputBorder.none,
                      hintText: Language().getString(
                          Constants.SEARCH_BY_ORGANIZATION_NAME, selectedLang),
                      hintStyle: TextStyle(
                          fontSize: 13.0, fontWeight: StyleView.fontSemiBold)),
                ),
              )),
          Container(
            color: Colors.grey,
          ),
          Expanded(
              child: Container(
                  padding: EdgeInsets.only(left: 5),
                  child: IconButton(
                      icon: Icon(
                        Icons.filter_list,
                        color: theme.colorScheme.primary,
                      ),
                      onPressed: () {
                        CommonMethods.hideKeyboard(context);
                        buildFilterDialog();
                      })))
        ],
      ),
    );
  }

  onSearchTextChanged(String text) async {
    showLoaderText = Constants.LOADING;
    if (text.isEmpty) {
      isSearchForParams = false;
      loadInvitationsData();
    } else {
      isSearchForParams = true;
      if (CommonMethods.isNumeric(_searchController.text)) {
        this.loadInvitationsData(mobileNumber: _searchController.text);
      } else {
        this.loadInvitationsData(inviteeName: _searchController.text);
      }
    }
  }

  Widget _listViewData() {
    if (isLoadingProgress) {
      return Expanded(child: ListLoader());
    } else if (!isLoadingProgress && _inviteesModel.length == 0) {
      return Expanded(
          child: Center(
              child: Text(
        Language().getString(showLoaderText, selectedLang),
      )));
    } else {
      return Expanded(
        child: AnimationLimiter(
            child: ListView.separated(
          physics: new BouncingScrollPhysics(
              parent: AlwaysScrollableScrollPhysics()),
          shrinkWrap: true,
          separatorBuilder: (context, index) => Divider(
            height: 5.0,
            color: Colors.transparent,
          ),
          itemBuilder: (BuildContext ctxt, int index) {
            return AnimationConfiguration.staggeredList(
              position: index,
              duration: Duration(milliseconds: 900),
              child: SlideAnimation(
                verticalOffset: 50.0,
                child: FadeInAnimation(
                  child: InkWell(
                    onTap: () {
                      CommonMethods.hideKeyboard(context);
                      Navigator.push(
                              context,
                              PageTransition(
                                  context: context,
                                  page: InvitationProfile(
                                      isInviteeDetails: true,
                                      title: Language().getString(
                                          Constants.INVITATION_PROFILE_STRING,
                                          selectedLang),
                                      data: _inviteesModel[index])))
                          .then((value) {
                        setState(() {
                          isLoadingProgress = true;
                        });
                        loadInvitationsData();
                      });
                    },
                    child: ReceivedInvitationsCardView(
                      name: Language()
                          .getString(Constants.NAME_STRING, selectedLang),
                      status: Language()
                          .getString(Constants.STATUS_STRING, selectedLang),
                      org: Language()
                          .getString(Constants.ORGANIZATION, selectedLang),
                      strInvitedDate: Language()
                          .getString(Constants.INVITED_DATE, selectedLang),
                      strAcceptedDate: Language()
                          .getString(Constants.ACCEPTED_DATE, selectedLang),
                      invitedDate: (_inviteesModel[index].inviter != null &&
                              _inviteesModel[index].inviter!.invitedDateTime !=
                                  null)
                          ? AppUtills.getISTTime(_inviteesModel[index]
                              .inviter!
                              .invitedDateTime
                              .toString())
                          : "",
                      acceptedDate: (_inviteesModel[index].inviter != null &&
                              _inviteesModel[index].invitee!.acceptedDateTime !=
                                  null)
                          ? AppUtills.getISTTime(_inviteesModel[index]
                              .invitee!
                              .acceptedDateTime
                              .toString())
                          : "",
                      inviterName: _inviteesModel[index].inviter!.contactPerson,
                      organization:
                          _inviteesModel[index].inviter!.inviteCompanyName,
                      date: AppUtills.getISTTime(new DateTime.now().toString()),
                      // _inviteesModel[index]
                      //   .metadata
                      //   .lastModified
                      //   .toString()),
                      invitationStatus: _inviteesModel[index].status,
                    ),
                  ),
                ),
              ),
            );
          },
          itemCount: _inviteesModel.length,
        )),
      );
    }
  }

  @override
  void dispose() {
    this.renderClearFilterData();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
        body: Stack(
      children: [
        SafeArea(
          child: Scaffold(
            key: _scaffoldkey,
            backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
            floatingActionButton: (isShowFloatButton)
                ? FloatingActionButton(
                    backgroundColor: theme.colorScheme.primary,
                    onPressed: () {
                      this.renderClearFilterData();
                      setState(() {
                        isShowFloatButton = false;
                        isLoadingProgress = true;
                        _searchController.clear();
                        CommonMethods.hideKeyboard(context);
                      });
          
                      loadInvitationsData();
                    },
                    child: Text(
                      Language().getString(Constants.CLEAR_FILTERS, selectedLang),
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 10.0, color: Colors.white),
                    ),
                  )
                : null,
            body: Container(
              color: Color(Constants.APP_BACKGROUND_COLOR),
              padding: EdgeInsets.all(8.0),
              child: Column(children: <Widget>[
                Container(
                  height: 60,
                  child: buildSearchBarView(),
                ),
                SizedBox(height: 5.0),
                _listViewData()
              ]),
            ),
          ),
        ),
        // AppUtills.showLoadingView(
        //     context: context,
        //     message: Language().getString(progressMessage, selectedLang),
        //     isLoading: isLoadingProgress),
      ],
    ));
  }

  renderClearFilterData() {
    AppController.instance.setInvitationStatus = null;
    _checked.clear();
  }
}
