import 'package:vyaparlive/service/organization_service.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Organization/CreateBUPage.dart';
import 'package:vyaparlive/Product/NonSelectableProducts.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';

import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/components/privileges/invitation_privileges.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/BuBasicDataModel.dart';
import 'package:vyaparlive/model/Contacts.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';

import 'package:vyaparlive/model/InviteesModel.dart';
import 'dart:convert';

import 'package:vyaparlive/service/invitation_services.dart';
import 'package:vyaparlive/utills/SharePref.dart';
import 'package:vyaparlive/connections_view/ContactsPage.dart';

class InvitationProfile extends StatefulWidget {
  InvitationProfile({
    this.isInviteeDetails,
    this.title,
    this.invitationCode,
    this.contact,
    this.data,
  });
  final String? invitationCode;
  final String? contact;
  final bool? isInviteeDetails;
  final String? title;
  final InviteesModel? data;

  @override
  _InvitationProfileState createState() => _InvitationProfileState();
}

class _InvitationProfileState extends State<InvitationProfile> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  bool isLoading = false;
  final _invitationcodecontroller = TextEditingController();

  List<InviteesModel> _invitationData = [];
  List<BuBasicDataModel> buList = [];
  String? userId;

  BuildContext? mContext;

  InvitationPrivileges? _invitationPrivileges =
      AppController.instance.getInvitationPrivileges;
  Contacts? connectionDropdownValue;
  BuBasicDataModel? buDropdownValue;
  late InvitationService _invitationService;
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  late OrganizationService _organizationService;
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _invitationService = InvitationService();
    _organizationService = OrganizationService();
    if (widget.isInviteeDetails!) {
      SharePref().getUserId().then((onValue) {
        userId = onValue;
        loadBusinessUnitList();
      });
    }
    serviceCallGetInvitation();
  }

  loadBusinessUnitList() async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
      });
      this.getBUList().then((onValue) {
        setState(() {
          buList.addAll(onValue);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  serviceCallGetInvitation() async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
      });
      this.getInvitationData().then((value) {
        setState(() {
          _invitationData.addAll(value);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  /// Service call for get bu list

  getBUList() async {
    setState(() {
      isLoadingProgress = true;
    });
    String body = json.encode({"id": userId});
    // http.Response response =
    //     await _service.get_organization("v2/user/", userId);
    setState(() {
      isLoadingProgress = false;
    });
    // var _list = List<BuBasicDataModel>();
    var response = await _organizationService
        .getBulistByUserId(body: body, token: "")
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    setState(() {
      isLoadingProgress = false;
    });
    List<BuBasicDataModel> _list = [];
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var responseBody = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(responseBody)) {
        for (var obj in responseBody) {
          _list.add(BuBasicDataModel.fromJson(obj));
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
      return _list;
  }

  /// Dynamically create popup

  buildTextFormFields(String _labelText, TextEditingController _controller,
      bool isAcceptInvitation) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 8.0),
      child: new TextFormField(
        controller: _controller,
        style: TextStyle(fontFamily: StyleView.FONT_TITLE),
        decoration: InputDecoration(
          labelText: isAcceptInvitation ? _labelText : "Enter a reason",
          isDense: true,
          border: OutlineInputBorder(),
          focusColor: Color(0xFF083e64),
          enabledBorder:
              OutlineInputBorder(borderSide: BorderSide(color: Colors.grey)),
          focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(color: StyleView.secondaryColor)),
        ),
        onChanged: (text) => {text = _invitationcodecontroller.text},
      ),
    );
  }

  onRejectInvitation() async {
    setState(() {
      isLoadingProgress = true;
    });
    Map data = {
      "id": widget.data!.id,
      "reason": _invitationcodecontroller.text
    };
    String body = json.encode(data);
    var response = await _invitationService
        .rejectInvitation_grpc(body)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var msg = json.decode(_grpcResponse.message!);
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          msg["message"],
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);

      if (action == DialogAction.yes) {
        Navigator.of(context).pop();
        serviceCallGetInvitation();
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  onInvitationCodeSubmit() async {
    setState(() {
      isLoadingProgress = true;
    });
    Map data = {
      "id": widget.data!.id,
      "bu_id": buDropdownValue != null ? buDropdownValue!.id : "",
      "code": _invitationcodecontroller.text
    };

    String body = json.encode(data);
    var response = await _invitationService
        .acceptInvitation_grpc(body)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);

      if (action == DialogAction.yes) {
        _invitationcodecontroller.clear();
        Navigator.of(context).pop();
        if (buList.length > 0) {
          Navigator.push(
            context,
            new MaterialPageRoute(builder: (context) => ContactsView()),
          );
        } else {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => CreateBUView(
                        title: Constants.CREATE_BUSINESS_UNIT,
                        isOrgUpdate: false,
                      ))).then((value) {});
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  navigateToContacts() {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (contex) => ContactsView(), maintainState: false));
  }

  showChoiceDialog(BuildContext context, bool isAcceptInvitation) {
    return showDialog(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) {
          return StatefulBuilder(builder: (context, StateSetter setState) {
            return AlertDialog(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(15.0)),
                ),
                title: Column(
                  children: <Widget>[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(Language().getString(
                            Constants.ACCEPT_INVITATION, selectedLang)),
                        Align(
                          alignment: Alignment.topRight,
                          child: GestureDetector(
                            onTap: () {
                              buDropdownValue = null;
                              _invitationcodecontroller.clear();
                              Navigator.of(context).pop();
                            },
                            child: Icon(
                              Icons.close,
                              color: Colors.red,
                            ),
                          ),
                        ),
                      ],
                    ),
                    (isAcceptInvitation)
                        ? this.showBuList(setState)
                        : Container(),
                    buildTextFormFields(Constants.ENTER_CODE_HERE_STR,
                        _invitationcodecontroller, isAcceptInvitation),
                  ],
                ),
                content: CommonButtonsView(
                  context: context,
                  b1Text: "",
                  b2Text: Language()
                      .getString(Constants.SUBMIT_STRING, selectedLang),
                  onb2Action: () async {
                    if (await NetworkStatus.getInternetStatus()) {
                      if (isAcceptInvitation) {
                        String errorMessage = validateMandatoryFields();
                        if (errorMessage.isNotEmpty) {
                          Dialogs.yesCancelDialog(
                              context,
                              Language()
                                  .getString(Constants.ERROR, selectedLang),
                              errorMessage,
                              Language()
                                  .getString(Constants.OKAY_STR, selectedLang),
                              "",
                              false);
                        } else {
                          Navigator.of(context).pop();

                          this.onInvitationCodeSubmit();
                        }
                      } else {
                        Navigator.of(context).pop();

                        this.onRejectInvitation();
                      }
                    } else {
                      AppUtills.showSnackBar(
                          _scaffoldkey,
                          Language()
                              .getString(Constants.NO_INTERNET, selectedLang),
                          snackBarBgColor: Colors.black,
                          messageColor: Colors.white,
                          buttonColor: Colors.white);
                    }
                  },
                ));
          });
        });
  }

  String validateMandatoryFields() {
    if (buDropdownValue == null) {
      return "Please select BU";
    } else if (_invitationcodecontroller.text.isEmpty) {
      return "Enter invitation code";
    } else {
      return "";
    }
  }

  Widget showBuList(StateSetter setState) {
    return Container(
        margin: EdgeInsets.symmetric(
          vertical: 5.0,
        ),
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.symmetric(vertical: 10),
              child: Text(
                "Select Business Unit for adding this connection",
                style: TextStyle(
                    fontSize: 15,
                    fontWeight: StyleView.fontMedium,
                    color: Colors.black),
              ),
            ),
            Container(
              height: 50.0,
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(5.0),
                  border: Border.all(color: Colors.grey)),
              width: MediaQuery.of(context).size.width,
              padding: EdgeInsets.all(5.0),
              child: DropdownButton<BuBasicDataModel>(
                isExpanded: true,
                value: buDropdownValue,
                underline: SizedBox(),
                hint: Text(Language()
                    .getString(Constants.SELECT_CONNECTION, selectedLang)),
                onChanged: (BuBasicDataModel? newValue) {
                  setState(() {
                    buDropdownValue = newValue;
                  });
                },
                items: buList.map((BuBasicDataModel value) {
                  return DropdownMenuItem<BuBasicDataModel>(
                    value: value,
                    child: Container(
                        padding: EdgeInsets.all(7.0),
                        child: Text(value.businessName!)),
                  );
                }).toList(),
              ),
            ),
          ],
        ));
  }

  _handlingStatusColors(String? status) {
    if (status == "pending") {
      return Colors.orange;
    } else if (status == "accepted") {
      return Colors.green;
    } else if (status == "rejected") {
      return Colors.red;
    } else {
      return Colors.indigo;
    }
  }

  buildProfileFields(String title, String? subTitile) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(title,
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: StyleView.FONT_TITLE))),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                  height: 50,
                  color: Colors.white,
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text("$subTitile",
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: StyleView.FONT_TITLE))),
                  )),
            ),
          ],
        ));
  }

  buildTextField(String _text) {
    return Container(
        alignment: Alignment.topLeft,
        child: Text(
          _text,
          style: TextStyle(
              fontSize: StyleView.FONT_SIZE_15,
              fontWeight: FontWeight.bold,
              fontFamily: StyleView.FONT_TITLE),
        ));
  }

  Future<List<InviteesModel>> getInvitationData() async {
    setState(() {
      isLoadingProgress = true;
      _invitationData.clear();
    });
    String body = json.encode({"id": widget.data!.id});
    var response =
        await _invitationService.getInvitationData(body).catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    // _service.getInvitationDetails(widget.data.id);

    setState(() {
      isLoadingProgress = false;
    });

    List<InviteesModel> list = [];

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);
      // for (var object in data[0]) {
      list.add(InviteesModel.fromJson(data[0]));
      // }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
      return list;
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
        body: Stack(
      children: [
        SafeArea(
          child: Scaffold(
            key: _scaffoldkey,
            backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
            appBar: AppBar(
                backgroundColor: Colors.transparent, //Color(Constants.APP_COLOR),
                centerTitle: true,
                elevation: 0,
                iconTheme: IconThemeData(color: theme.colorScheme.primary),
                title: AppbarName(
                    title: Language().getString(widget.title, selectedLang),
                    buName: widget.isInviteeDetails!
                        ? widget.data!.invitee!.companyName!
                        : widget.data!.inviter!.inviteCompanyName!)),
            bottomNavigationBar: (_invitationData.length > 0 &&
                    widget.isInviteeDetails! &&
                    _invitationData[0].status == "pending")
                ? Container(
                    margin: EdgeInsets.symmetric(horizontal: 5.0),
                    padding: EdgeInsets.only(bottom: 20),
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: <Widget>[
                          Expanded(
                              child: (_invitationPrivileges!.invitation_reject)
                                  ? ElevatedButton(
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: Colors.red,
                                      ),
                                      onPressed: () {
                                        _invitationcodecontroller.clear();
                                        showChoiceDialog(context, false);
                                      },
                                      child: Text(
                                        Language().getString(
                                            Constants.REJECT_STRING,
                                            selectedLang),
                                        style: TextStyle(color: Colors.white),
                                      ),
                                    )
                                  : Container()),
                          SizedBox(width: 3),
                          Expanded(
                              child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Color(Constants.APP_COLOR),
                                  ),
                                  onPressed: () {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                NonSelectableProducts(
                                                    buName: widget.data!.inviter!
                                                        .inviteCompanyName,
                                                    buId: _invitationData[0]
                                                        .inviter!
                                                        .inviteCompany)));
                                  },
                                  child: Text(
                                    Language().getString(
                                        Constants.SEEPRODUCTS_STRING,
                                        selectedLang),
                                    style: TextStyle(color: Colors.white),
                                  ))),
                          SizedBox(width: 3),
                          Expanded(
                              child: (_invitationPrivileges!.invitation_accept)
                                  ? ElevatedButton(
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: Colors.green,
                                      ),
                                      onPressed: () {
                                        _invitationcodecontroller.clear();
                                        this.showChoiceDialog(context, true);
                                      },
                                      child: Text(
                                        Language().getString(
                                            Constants.ACCEPT_STRING,
                                            selectedLang),
                                        style: TextStyle(color: Colors.white),
                                      ))
                                  : Container())
                        ]),
                  )
                : Container(
                    padding: EdgeInsets.all(10.0),
                    child: _invitationData.length > 0
                        ? Padding(
                            padding: const EdgeInsets.only(bottom: 20.0),
                            child: Row(
                              children: <Widget>[
                                Text(
                                  Language().getString(
                                      Constants.INVITATION_STATUS, selectedLang),
                                  style: TextStyle(
                                      fontSize: 15.0,
                                      fontWeight: StyleView.fontSemiBold),
                                ),
                                Text(
                                  _invitationData[0].status!,
                                  style: TextStyle(
                                      fontSize: 15.0,
                                      color: _handlingStatusColors(
                                          _invitationData[0].status),
                                      fontWeight: StyleView.fontMedium),
                                ),
                              ],
                            ),
                          )
                        : Container()),
            body: (_invitationData.length == 0)
                ? Container(
                    child: Center(
                      child: Text(
                        Language()
                            .getString(Constants.NO_DATA_FOUND, selectedLang),
                      ),
                    ),
                  )
                : SingleChildScrollView(
                    padding: EdgeInsets.all(10),
                    child: Column(
                      children: <Widget>[
                        SizedBox(height: 10),
                        buildTextField(Language().getString(
                            Constants.RELATION_DETAILS_STRING, selectedLang)),
                        SizedBox(height: 5),
                        Container(
                            child: Container(
                                decoration: BoxDecoration(
                                    border: Border.all(color: Colors.grey),
                                    borderRadius: BorderRadius.circular(5)),
                                child: Column(children: <Widget>[
                                  buildProfileFields(
                                      Language().getString(
                                          Constants.BUSINESS_RELATION,
                                          selectedLang),
                                      widget.isInviteeDetails!
                                          ? _invitationData[0].invitee!.relation
                                          : _invitationData[0]
                                              .inviter!
                                              .businessRelation)
                                ]))),
                        SizedBox(height: 5),
                        Container(
                            child: widget.isInviteeDetails!
                                ? Column(
                                    children: <Widget>[
                                      SizedBox(height: 10),
                                      buildTextField(
                                        Language().getString(
                                            Constants.INVITER_DETAILS,
                                            selectedLang),
                                      ),
                                      SizedBox(height: 5),
                                      Container(
                                        child: Container(
                                            decoration: BoxDecoration(
                                                border: Border.all(
                                                    color: Colors.grey),
                                                borderRadius:
                                                    BorderRadius.circular(5)),
                                            child: Column(
                                              children: <Widget>[
                                                buildProfileFields(
                                                    Language().getString(
                                                        Constants.NAME_STRING,
                                                        selectedLang),
                                                    _invitationData[0]
                                                        .inviter!
                                                        .contactPerson),
                                                SizedBox(
                                                    height: 1,
                                                    child: new Container(
                                                        color: Color(Constants
                                                            .GREY_COLOR))),
                                                buildProfileFields(
                                                    Language().getString(
                                                        Constants.PHONE_NUMBER,
                                                        selectedLang),
                                                    _invitationData[0]
                                                        .inviter!
                                                        .contact),
                                                SizedBox(
                                                    height: 1,
                                                    child: new Container(
                                                        color: Color(Constants
                                                            .GREY_COLOR))),
                                              ],
                                            )),
                                      ),
                                      SizedBox(height: 10),
                                      buildTextField(
                                        Language().getString(
                                            Constants.INVITEE_DETAILS,
                                            selectedLang),
                                      ),
                                      SizedBox(height: 5),
                                      Container(
                                        child: Container(
                                            decoration: BoxDecoration(
                                                border: Border.all(
                                                    color: Colors.grey),
                                                borderRadius:
                                                    BorderRadius.circular(5)),
                                            child: Column(
                                              children: <Widget>[
                                                buildProfileFields(
                                                    Language().getString(
                                                        Constants.NAME_STRING,
                                                        selectedLang),
                                                    _invitationData[0]
                                                        .invitee!
                                                        .companyName),
                                                SizedBox(
                                                    height: 1,
                                                    child: new Container(
                                                        color: Color(Constants
                                                            .GREY_COLOR))),
                                                buildProfileFields(
                                                    Language().getString(
                                                        Constants.EMAIL,
                                                        selectedLang),
                                                    _invitationData[0]
                                                        .invitee!
                                                        .emailId),
                                                SizedBox(
                                                    height: 1,
                                                    child: new Container(
                                                        color: Color(Constants
                                                            .GREY_COLOR))),
                                                buildProfileFields(
                                                    Language().getString(
                                                        Constants.PHONE_NUMBER,
                                                        selectedLang),
                                                    "${_invitationData[0].invitee!.countryCode} ${_invitationData[0].invitee!.contact}"),
                                                SizedBox(
                                                    height: 1,
                                                    child: new Container(
                                                        color: Color(Constants
                                                            .GREY_COLOR))),
                                              ],
                                            )),
                                      ),
                                    ],
                                  )
                                : Column(
                                    children: <Widget>[
                                      SizedBox(height: 10),
                                      buildTextField(
                                        Language().getString(
                                            Constants.INVITEE_DETAILS,
                                            selectedLang),
                                      ),
                                      SizedBox(height: 5),
                                      Container(
                                        child: Container(
                                            decoration: BoxDecoration(
                                                border: Border.all(
                                                    color: Colors.grey),
                                                borderRadius:
                                                    BorderRadius.circular(5)),
                                            child: Column(
                                              children: <Widget>[
                                                buildProfileFields(
                                                    Language().getString(
                                                        Constants.NAME_STRING,
                                                        selectedLang),
                                                    _invitationData[0]
                                                        .invitee!
                                                        .companyName),
                                                SizedBox(
                                                    height: 1,
                                                    child: new Container(
                                                        color: Color(Constants
                                                            .GREY_COLOR))),
                                                buildProfileFields(
                                                    Language().getString(
                                                        Constants.PHONE_NUMBER,
                                                        selectedLang),
                                                    _invitationData[0]
                                                        .invitee!
                                                        .contact),
                                                SizedBox(
                                                    height: 1,
                                                    child: new Container(
                                                        color: Color(Constants
                                                            .GREY_COLOR))),
                                                buildProfileFields(
                                                    Language().getString(
                                                        Constants.EMAIL_ID_STRING,
                                                        selectedLang),
                                                    _invitationData[0]
                                                        .invitee!
                                                        .emailId),
                                                // SizedBox(
                                                //     height: 1,
                                                //     child: new Container(
                                                //         color:
                                                //             Color(Constants.GREY_COLOR))),
                                                // buildProfileFields(
                                                //     Language().getString(
                                                //         Constants.STATUS_STRING,
                                                //         selectedLang),
                                                //     widget.data.status),
                                              ],
                                            )),
                                      ),
                                      SizedBox(height: 10),
                                      buildTextField(
                                        Language().getString(
                                            Constants.INVITER_DETAILS,
                                            selectedLang),
                                      ),
                                      SizedBox(height: 5),
                                      Container(
                                        child: Container(
                                            decoration: BoxDecoration(
                                                border: Border.all(
                                                    color: Colors.grey),
                                                borderRadius:
                                                    BorderRadius.circular(5)),
                                            child: Column(
                                              children: <Widget>[
                                                buildProfileFields(
                                                    Language().getString(
                                                        Constants.NAME_STRING,
                                                        selectedLang),
                                                    _invitationData[0]
                                                        .inviter!
                                                        .inviteCompanyName),
                                                SizedBox(
                                                    height: 1,
                                                    child: new Container(
                                                        color: Color(Constants
                                                            .GREY_COLOR))),
                                                buildProfileFields(
                                                    Language().getString(
                                                        Language().getString(
                                                            Constants
                                                                .CONTACT_PERSON,
                                                            selectedLang),
                                                        selectedLang),
                                                    _invitationData[0]
                                                        .inviter!
                                                        .contactPerson),
                                                SizedBox(
                                                    height: 1,
                                                    child: new Container(
                                                        color: Color(Constants
                                                            .GREY_COLOR))),
                                                buildProfileFields(
                                                    Language().getString(
                                                        Constants.PHONE_NUMBER,
                                                        selectedLang),
                                                    _invitationData[0]
                                                        .inviter!
                                                        .contact),
                                              ],
                                            )),
                                      ),
                                    ],
                                  )),
                        SizedBox(height: 10),
                      ],
                    ),
                  ),
          ),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    ));
  }
}
