import 'package:vyaparlive/theme/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';

class InvitationCardView extends StatelessWidget {
  final String? name;
  final String? number;
  final String? status;
  final String? inviterName;
  final String? mobileNumber;
  final String? invitationStatus;
  final VoidCallback? removeInvitation;
  final VoidCallback? resendConfirmation;
  final String? invitedDate;
  final String? acceptedDate;
  final String? strInvitedDate;
  final String? strAcceptedDate;
  final ThemeData theme = AppTheme.vyaparTheme;
  InvitationCardView(
      {this.invitationStatus,
      this.inviterName,
      this.mobileNumber,
      this.removeInvitation,
      this.resendConfirmation,
      this.name,
      this.number,
      this.status,
      this.invitedDate,
      this.acceptedDate,
      this.strInvitedDate,
      this.strAcceptedDate});
  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 7.0,
      shadowColor: theme.colorScheme.primary,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(5.0),
          side: BorderSide(
              color: theme.colorScheme.primaryContainer, strokeAlign: 1)),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: <Widget>[
            buildInvitationsView(name, "$inviterName"),
            buildInvitationsView(number, ("$mobileNumber")),
            buildInvitationsView(strInvitedDate, ("$invitedDate")),
            buildInvitationsView(strAcceptedDate, ("$acceptedDate")),
            Container(
              margin: EdgeInsets.symmetric(vertical: 5.0),
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: Text(status!,
                        style: TextStyle(
                          fontWeight: StyleView.fontSemiBold,
                          color: Colors.black,
                        )),
                  ),
                  Text("  : "),
                  Expanded(
                      flex: 2,
                      child: Text(invitationStatus!,
                          style: TextStyle(
                              color: invitationStatus == "pending"
                                  ? Colors.orange
                                  : Colors.green,
                              fontWeight: StyleView.fontSemiBold,
                              fontSize: 13.0))),
                ],
              ),
            ),
            (invitationStatus == "accepted")
                ? Container()
                : Padding(
                    padding: const EdgeInsets.only(
                        left: 10.0, right: 10, bottom: 10),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        InkWell(
                            child: Icon(
                              Icons.delete,
                              size: 25,
                              color: Colors.red,
                            ),
                            onTap: () => removeInvitation!()),
                        SizedBox(width: 20),
                        InkWell(
                          onTap: () => resendConfirmation!(),
                          child: Icon(
                            FeatherIcons.share2,
                            size: 25,
                          ),
                        )
                      ],
                    ),
                  ),
          ],
        ),
      ),
    );
  }

  buildInvitationsView(String? title, String subTitle) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 5.0),
      child: Row(
        children: <Widget>[
          Expanded(
            child: Text("$title",
                style: TextStyle(
                    color: Colors.black, fontWeight: StyleView.fontSemiBold)),
          ),
          Text("  : "),
          Expanded(
            flex: 2,
            child: Text("$subTitle",
                style: TextStyle(
                    fontSize: 13.0, fontWeight: StyleView.fontMedium)),
          ),
        ],
      ),
    );
  }
}
