import 'dart:convert';
import 'package:share_plus/share_plus.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/animation/list_loader/ListLoader.dart';
import 'package:checkbox_grouped/checkbox_grouped.dart';
import 'package:clipboard/clipboard.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
// import 'package:share/share.dart';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Invitation/InvitationCardView.dart';

import 'package:vyaparlive/Invitation/InvitationProfile.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/InviteesModel.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:vyaparlive/service/invitation_services.dart';
import 'package:vyaparlive/utills/SharePref.dart';
import 'package:toast/toast.dart';

class MyInvitationsView extends StatefulWidget {
  final bool isPageReload;
  MyInvitationsView({this.isPageReload = false});
  @override
  _MyInvitationsViewState createState() => _MyInvitationsViewState();
}

class _MyInvitationsViewState extends State<MyInvitationsView> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  List<InviteesModel> _inviteesModel = [];
  bool isLoading = false;

  String? userId = "";
  TextEditingController _searchController = TextEditingController();
  List<String> filterOptions = [];
  List<String> _checked = [];

  bool isShowFloatButton = false;
  String? selectedFilterText = "";
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  String showLoaderText = Constants.NO_DATA_FOUND;
  late InvitationService _invitationService;
  bool isSearchForParams = false;
  late ThemeData theme;
  late CustomGroupController customController = CustomGroupController();
  @override
  void initState() {
    super.initState();
    this.getLoadLanguage();
    theme = AppTheme.vyaparTheme;
    _invitationService = InvitationService();
    SharePref().getPhoneNumber().then((value) {
      userId = value;
      loadInvitationsData();
    });
  }

  loadInvitationsData(
      {String userId = "",
      String invitationStatus = "",
      String mobileNumber = "",
      String inviteeName = ""}) async {
    if (await NetworkStatus.getInternetStatus()) {
      if (!isSearchForParams) {
        setState(() {
          isLoadingProgress = true;
        });
      }
      getAllInvitees(
              invitationStatus: invitationStatus,
              mobileNumber: mobileNumber,
              inviteeName: inviteeName)
          .then((onValue) {
        setState(() {
          if (onValue.length > 0) {
            _inviteesModel.clear();
            _inviteesModel.addAll(onValue);
          } else {
            showLoaderText = Constants.NO_DATA_FOUND;
          }
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<InviteesModel>> getAllInvitees(
      {String invitationStatus = "",
      String inviteeName = "",
      String mobileNumber = ""}) async {
    setState(() {
      _inviteesModel.clear();
    });

    String body = json.encode({
      "contact": userId,
      "filters": {
        "DateFrom": "",
        "DateTo": "",
        "status": invitationStatus,
        "companyName": inviteeName,
        "contact": mobileNumber
      }
    });

    var response = await _invitationService
        .getInviterInvitations_grpc(body)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<InviteesModel> _model = [];

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      var resultArray = resObj['results'];
      for (var noteJson in resultArray) {
        _model.add(InviteesModel.fromJson(noteJson));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return _model;
  }

  getLoadLanguage() {
    filterOptions = [
      Language().getString(Constants.ACCEPTED_INVITATIONS, selectedLang),
      Language().getString(Constants.PENDING_INVITATIONS, selectedLang),
      Language().getString(Constants.REJECT_INVITATIONS, selectedLang)
    ];
  }

  buildFilterDialog() {
    return showDialog(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) {
          return StatefulBuilder(builder: (context, StateSetter setState) {
            return Scaffold(
                backgroundColor: Colors.transparent,
                body: Center(
                  child: Container(
                    // height: MediaQuery.of(context).size.height * 0.50,
                    margin: EdgeInsets.symmetric(horizontal: 30.0),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.all(Radius.circular(15.0)),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.all(20.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                Language().getString(
                                    Constants.SORT_INVITATIONS_BY,
                                    selectedLang),
                                style: TextStyle(
                                  fontSize: StyleView.FONT_SIZE_15,
                                  fontWeight: StyleView.fontSemiBold,
                                  fontFamily: StyleView.FONT_TITLE,
                                ),
                                textAlign: TextAlign.center,
                              ),
                              GestureDetector(
                                onTap: () {
                                  this.renderClearFilterData();
                                  Navigator.of(context).pop();
                                },
                                child: Padding(
                                  padding: EdgeInsets.all(5.0),
                                  child: Icon(
                                    Icons.close,
                                    color: Colors.red,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),

                        Container(
                          width: MediaQuery.of(context).size.width,
                          height: 1,
                          color: Colors.grey,
                        ),
                        SizedBox(height: 5),
                        SimpleGroupedCheckbox<String>(
                          controller: GroupController(),
                          onItemSelected: (selected) {
                            // if (selected.length > 1) {
                            //   selected.removeAt(0);
                            // }
                            setState(() {
                              _checked.add(selected);
                            });
                          },
                          itemsTitle: filterOptions,
                          values: filterOptions,
                          groupStyle: GroupStyle(
                              activeColor: theme.colorScheme.primary,
                              itemTitleStyle: TextStyle(
                                  fontSize: 15,
                                  fontWeight: StyleView.fontMedium)),
                          // checkFirstElement: false,
                        ),
                        // CheckboxGroup(
                        //   labels: filterOptions,
                        //   checked: _checked,
                        //   onSelected: (List selected) {
                        //     if (selected.length > 1) {
                        //       selected.removeAt(0);
                        //     }
                        //     setState(() {
                        //       _checked = selected;
                        //     });
                        //   },
                        // ),
                        // Spacer(),
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: theme.colorScheme.primary,
                          ),
                          onPressed: () {
                            Navigator.of(context).pop();
                            if (_checked.length > 0) {
                              setState(() {
                                isShowFloatButton = true;
                              });
                              if (_checked[0] ==
                                  Language().getString(
                                      Constants.PENDING_INVITATIONS,
                                      selectedLang)) {
                                this.loadInvitationsData(
                                    invitationStatus: "pending");
                              } else if (_checked[0] ==
                                  Language().getString(
                                      Constants.REJECT_INVITATIONS,
                                      selectedLang)) {
                                this.loadInvitationsData(
                                    invitationStatus: "rejected");
                              } else {
                                this.loadInvitationsData(
                                    invitationStatus: "accepted");
                              }
                            }
                          },
                          child: Text(Language()
                              .getString(Constants.APPLY_FILTER, selectedLang)),
                        ),
                        SizedBox(
                          height: 10.0,
                        )
                      ],
                    ),
                  ),
                ));
          });
        });
  }

  buildSearchBarView() {
    return Card(
      elevation: 5,
      shadowColor: theme.colorScheme.primary,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0),
          side:
              BorderSide(color: theme.colorScheme.primary, strokeAlign: 0.01)),
      child: Row(
        children: <Widget>[
          Expanded(
              flex: 5,
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: TextFormField(
                  controller: _searchController,
                  onChanged: onSearchTextChanged,
                  style: TextStyle(fontWeight: StyleView.fontSemiBold),
                  decoration: InputDecoration(
                      contentPadding: EdgeInsets.only(bottom: 5),
                      border: InputBorder.none,
                      hintText: Language().getString(
                          Constants.SEARCH_BY_INVITATION_NAME, selectedLang),
                      hintStyle: TextStyle(
                          fontSize: 13.0, fontWeight: StyleView.fontSemiBold)),
                ),
              )),
          Container(
            color: Colors.grey,
          ),
          Expanded(
              child: Container(
                  padding: EdgeInsets.only(left: 5),
                  child: IconButton(
                      icon: Icon(
                        Icons.filter_list,
                        color: theme.colorScheme.primary,
                      ),
                      onPressed: () {
                        CommonMethods.hideKeyboard(context);
                        buildFilterDialog();
                      })))
        ],
      ),
    );
  }

  onSearchTextChanged(String text) async {
    showLoaderText = Constants.LOADING;
    if (text.isEmpty) {
      isSearchForParams = false;
      loadInvitationsData();
    }
    isSearchForParams = true;
    if (CommonMethods.isNumeric(_searchController.text)) {
      this.loadInvitationsData(mobileNumber: _searchController.text);
    } else {
      this.loadInvitationsData(inviteeName: _searchController.text);
    }
  }

  shareInvitation(inviteData) {
    String message =
        'Your Vyapar Live invitation code is: ${inviteData.code}\n\nPlease download the app from ${Constants.NEW_BASE_URL}lookup/apk/download';
    return showDialog(
        barrierDismissible: false,
        barrierColor: Colors.black45,
        context: context,
        builder: (context) => AlertDialog(
              contentPadding: EdgeInsets.fromLTRB(10.0, 24.0, 0.0, 24.0),
              content: Container(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      Language()
                          .getString(Constants.SHARE_INVITATION, selectedLang),
                      textAlign: TextAlign.start,
                      style: TextStyle(
                          fontSize: 15.0,
                          fontWeight: FontWeight.bold,
                          color: Color(Constants.APP_COLOR)),
                    ),
                    Container(
                        padding:
                            EdgeInsets.only(top: 10.0, left: 16, right: 16),
                        child: SelectableText(
                            // style: TextStyle(fontSize: 15, height: 1.3),
                            Language()
                                    .getString(Constants.MR_MRS, selectedLang) +
                                "${inviteData.inviter.contactPerson} " +
                                Language().getString(
                                    Constants
                                        .SEND_INVITATIONS_VYAPARLIVE_MOBILE_NUMBER,
                                    selectedLang) +
                                " ${inviteData.inviter.contact} " +
                                Language().getString(
                                    Constants.TO_YOUR_MOBILE_NUMBER,
                                    selectedLang) +
                                " ${inviteData.invitee.contact}.\n\n$message")
                        // "Mr/Ms.${inviteData.inviter.contactPerson} has sent you an invitation for Vyapar live from mobile number ${inviteData.inviter.contact} to your mobile number ${inviteData.invitee.contact}.\n\n$message"),
                        )
                  ],
                ),
              ),
              actions: <Widget>[
                TextButton(
                  child: new Text(
                    Language().getString(Constants.CLOSE, selectedLang),
                    style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                        fontSize: StyleView.FONT_SIZE_15),
                  ),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                ),
                SizedBox(width: 110.0),
                TextButton(
                  child: new Text(
                    Language().getString(
                        (kIsWeb) ? 'Copy' : Constants.SHARE, selectedLang),
                    style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                        fontSize: StyleView.FONT_SIZE_15),
                  ),
                  onPressed: () {
                    var shareData =
                        "Mr/Ms.${inviteData.inviter.contactPerson} has sent you an invitation for Vyapar live from mobile number ${inviteData.inviter.contact} to your mobile number ${inviteData.invitee.contact}.\n\n$message";
                    if (kIsWeb) {
                      FlutterClipboard.copy(shareData).then((value) => {
                            // print('copied'),
                            Toast.show("Copied to clipboard",
                                duration: Toast.lengthShort,
                                gravity: Toast.bottom)
                          });
                      // Navigator.of(context).pop();
                    } else {
                      SharePlus.instance.share(ShareParams(
                            text: shareData,
                            title: Language().getString(
                              Constants.APANAVYAPAR_INVITATION, selectedLang),
                            subject: Language().getString(
                              Constants.APANAVYAPAR_INVITATION, selectedLang),
                          ));
                      // Share.share(
                      //   shareData,
                      //   subject: Language().getString(
                      //       Constants.APANAVYAPAR_INVITATION, selectedLang),
                      // );
                      // Navigator.of(context).pop();
                    }
                    // String invieeNumber = AppController.instance
                    //     .getInvitationFieldsData.getInviteeContactNumber;
                  },
                ),
              ],
            ));
  }

  Widget _listViewData() {
    if (isLoadingProgress) {
      return Expanded(child: ListLoader());
    } else if (!isLoadingProgress && _inviteesModel.length == 0) {
      return Expanded(
          child: Center(
              child: Text(
        Language().getString(showLoaderText, selectedLang),
      )));
    } else {
      return Expanded(
        child: AnimationLimiter(
          child: ListView.separated(
            physics: new BouncingScrollPhysics(
                parent: new AlwaysScrollableScrollPhysics()),
            shrinkWrap: true,
            separatorBuilder: (context, index) =>
                Divider(height: 5.0, color: Colors.transparent),
            itemBuilder: (BuildContext ctxt, int index) {
              return AnimationConfiguration.staggeredList(
                position: index,
                duration: Duration(milliseconds: 900),
                child: SlideAnimation(
                  verticalOffset: 50.0,
                  child: FadeInAnimation(
                    child: InkWell(
                      onTap: () {
                        CommonMethods.hideKeyboard(context);
                        Navigator.push(
                                context,
                                PageTransition(
                                    context: context,
                                    page: InvitationProfile(
                                        isInviteeDetails: false,
                                        title: Language().getString(
                                            Constants
                                                .MY_INVITEES_PROFILE_STRING,
                                            selectedLang),
                                        invitationCode:
                                            _inviteesModel[index].code,
                                        contact:
                                            "${_inviteesModel[index].invitee!.countryCode} ${_inviteesModel[index].invitee!.contact}",
                                        data: _inviteesModel[index])))
                            .then((value) => loadInvitationsData());
                      },
                      child: InvitationCardView(
                        name: Language()
                            .getString(Constants.NAME_STRING, selectedLang),
                        number: Language()
                            .getString(Constants.MOBILE_NUMBER, selectedLang),
                        status: Language()
                            .getString(Constants.STATUS_STRING, selectedLang),
                        strInvitedDate: Language()
                            .getString(Constants.INVITED_DATE, selectedLang),
                        strAcceptedDate: Language()
                            .getString(Constants.ACCEPTED_DATE, selectedLang),
                        invitationStatus: _inviteesModel[index].inviter != null
                            ? _inviteesModel[index].status
                            : "",
                        inviterName: _inviteesModel[index].inviter != null
                            ? _inviteesModel[index].invitee!.companyName
                            : "",
                        mobileNumber:
                            "${_inviteesModel[index].invitee!.countryCode} ${_inviteesModel[index].invitee!.contact}",
                        removeInvitation: () {
                          this.showAlertPopUp(_inviteesModel[index].id);
                        },
                        resendConfirmation: () =>
                            shareInvitation(_inviteesModel[index]),
                        invitedDate: (_inviteesModel[index].inviter != null &&
                                _inviteesModel[index]
                                        .inviter!
                                        .invitedDateTime !=
                                    null)
                            ? AppUtills.getISTTime(_inviteesModel[index]
                                .inviter!
                                .invitedDateTime
                                .toString())
                            : "",
                        acceptedDate: (_inviteesModel[index].inviter != null &&
                                _inviteesModel[index]
                                        .invitee!
                                        .acceptedDateTime !=
                                    null)
                            ? AppUtills.getISTTime(_inviteesModel[index]
                                .invitee!
                                .acceptedDateTime
                                .toString())
                            : "",
                      ),
                    ),
                  ),
                ),
              );
            },
            itemCount: _inviteesModel.length,
          ),
        ),
      );
    }
  }

  @override
  void dispose() {
    this.renderClearFilterData();
    super.dispose();
  }

  @override
  void setState(VoidCallback fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  Widget build(BuildContext context) {
    ToastContext().init(context);
    return AppBackgroundView(
        body: Stack(
      children: [
        SafeArea(
          child: Scaffold(
            key: _scaffoldkey,
            backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
            floatingActionButton: (isShowFloatButton)
                ? FloatingActionButton(
                    backgroundColor: theme.colorScheme.primary,
                    onPressed: () {
                      this.renderClearFilterData();
                      setState(() {
                        selectedFilterText = null;
                        isShowFloatButton = false;
                        isLoadingProgress = true;
                        _searchController.clear();
                        CommonMethods.hideKeyboard(context);
                      });
          
                      loadInvitationsData();
                    },
                    child: Text(
                      Language().getString(Constants.CLEAR_FILTERS, selectedLang),
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 10.0, color: Colors.white),
                    ),
                  )
                : null,
            body: Container(
                color: Color(Constants.APP_BACKGROUND_COLOR),
                margin: EdgeInsets.only(right: 5.0),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    children: <Widget>[
                      Container(
                        height: 60,
                        child: buildSearchBarView(),
                      ),
                      SizedBox(
                        height: 5.0,
                      ),
                      _listViewData()
                    ],
                  ),
                )),
          ),
        ),
        // AppUtills.showLoadingView(
        //     context: context,
        //     message: Language().getString(progressMessage, selectedLang),
        //     isLoading: isLoadingProgress),
      ],
    ));
  }

  showAlertPopUp(String? _invitationId) async {
    final action = await Dialogs.yesCancelDialog(
        context,
        Language().getString(Constants.WARNING, selectedLang),
        Language().getString(Constants.INVITATION_DELETE_TEXT, selectedLang),
        Language().getString(Constants.YES_STRING, selectedLang),
        Language().getString(Constants.NO_STRING, selectedLang),
        true);
    if (action == DialogAction.yes) {
      setState(() {
        isLoadingProgress = true;
      });

      this.removeInvitation(_invitationId);
    }
  }

  removeInvitation(String? invitationId) async {
    Map data = {"id": invitationId};
    String body = json.encode(data);

    var response = await _invitationService
        .deleteInvitation(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      loadInvitationsData();
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  renderClearFilterData() {
    AppController.instance.setInvitationStatus = null;
    _checked.clear();
  }
}
