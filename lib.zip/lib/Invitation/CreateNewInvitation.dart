import 'package:flutter_native_contact_picker/model/contact.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/service/organization_service.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
// import 'package:fluttercontactpicker/fluttercontactpicker.dart';
// import 'package:flutter_native_contact_picker/flutter_native_contact_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/BuBasicDataModel.dart';
import 'package:vyaparlive/model/BusinessRelationDAO.dart';
import 'package:vyaparlive/model/RoleRelationDAO.dart';
import 'package:vyaparlive/model/StatesDAO.dart';
import 'package:vyaparlive/service/Service.dart';
import 'package:vyaparlive/utills/SharePref.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:vyaparlive/model/DepartmentDAO.dart';

class CreateNewInvitation extends StatefulWidget {
  @override
  CreateNewInvitationState createState() => CreateNewInvitationState();
}

class CreateNewInvitationState extends State<CreateNewInvitation> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  ScrollController _scrollController =
      new ScrollController(initialScrollOffset: 0.0, keepScrollOffset: true);
  TextEditingController _bussinessNameController = TextEditingController();
  final _usernamecontroller = TextEditingController();
  final _emailcontroller = TextEditingController();
  final _phonenumbercontroller = TextEditingController();
  bool isLoading = false;
  String? userId = "";
  List<BuBasicDataModel> _bubasicdatamodel = [];
  BuBasicDataModel? dropdownValue;

  StatesDAO? statesDropdownValue;

  String? cityDropdownValue;
  List<BusinessRelationDAO> _businessRelationList = [];
  late BusinessRelationDAO businessRelationDropdown;

  late Service _service;
  List<DepartmentDAO> _departmentList = [];
  DepartmentDAO? departmentDropdownValue;
  String? loggedUserMobilenumber = "";
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  TextEditingController _countryCodeController = new TextEditingController();
  late OrganizationService _organizationService;
  @override
  void initState() {
    super.initState();
    _service = Service();
    _organizationService = new OrganizationService();
    appendingInvitationData();
    SharePref().getPhoneNumber().then((value) {
      loggedUserMobilenumber = value;
    });
    SharePref().getUserId().then((onValue) {
      setState(() {
        userId = onValue;
      });
    });

    loadDropdownServiceCalls();
  }

  loadDropdownServiceCalls() async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        // isLoadingProgress = true;
      });
      getAllBuBusinessData(userId).then((onValue) {
        setState(() {
          _bubasicdatamodel.addAll(onValue);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
    if (await NetworkStatus.getInternetStatus()) {
      getBusinessRelation().then((value) {
        setState(() {
          _businessRelationList.addAll(value);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
    getDepartments().then((value) {
      setState(() {
        _departmentList.addAll(value);
      });
    });
  }

  /// Service call for departments

  Future<List<DepartmentDAO>> getDepartments() async {
    http.Response response = await _service.get_department();
    List<DepartmentDAO> list = [];

    if (response.statusCode == 200) {
      var data = json.decode(response.body);
      for (var object in data["data"]) {
        list.add(DepartmentDAO.fromJson(object));
      }
      if (list.length > 0 &&
          AppController.instance.invitationFieldsData!.getBusinessUnitId !=
              null) {
        for (int i = 0; i < list.length; i++) {
          if (AppController.instance.invitationFieldsData!.getBusinessUnitId ==
              list[i].name) {
            departmentDropdownValue = list[i];
            AppController.instance.invitationFieldsData?.setBusinessUnitId =
                departmentDropdownValue!.name!;
          }
        }
      }
    }
    return list;
  }

  /// Service call for business relation

  Future<List<BusinessRelationDAO>> getBusinessRelation() async {
    http.Response response =
        await _service.getDropDownType("lookup/relationType");
    List<BusinessRelationDAO> list = [];
    if (response.statusCode == 200) {
      var data = json.decode(response.body);
      for (var object in data["data"]) {
        list.add(BusinessRelationDAO.fromJson(object));
      }
      if (list.length > 0 &&
          AppController.instance.getInvitationFieldsData.getBusinessRelation !=
              null) {
        for (int i = 0; i < list.length; i++) {
          if (AppController
                  .instance.getInvitationFieldsData.getBusinessRelation ==
              list[i].type) {
            businessRelationDropdown = list[i];
            AppController.instance.getInvitationFieldsData.setBusinessRelation =
                businessRelationDropdown.type;
          }
        }
      }
    }
    return list;
  }

  /// Service call for business role

  Future<List<RoleRelationDAO>> getBusinessRole() async {
    http.Response response = await _service.getDropDownType("lookup/role");
    List<RoleRelationDAO> list = [];
    if (response.statusCode == 200) {
      var data = json.decode(response.body);
      for (var object in data["data"]) {
        list.add(RoleRelationDAO.fromJson(object));
      }
    }
    return list;
  }

  /// Service call for get all bus

  Future<List<BuBasicDataModel>> getAllBuBusinessData(String? userId) async {
    String body = json.encode({"id": userId});
    var response = await _organizationService
        .getBulistByUserId(body: body, token: "")
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<BuBasicDataModel> _model = [];
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var responseBody = json.decode(_grpcResponse.message!);

      for (var noteJson in responseBody) {
        _model.add(BuBasicDataModel.fromJson(noteJson));
      }
      if (_model.length > 0 &&
          AppController.instance.getInvitationFieldsData.getParentId !=
              null) {
        for (int i = 0; i < _model.length; i++) {
          if (AppController.instance.getInvitationFieldsData.getParentId ==
              _model[i].id) {
            dropdownValue = _model[i];
            AppController.instance.getInvitationFieldsData.setBusinessName =
                dropdownValue!.businessName;
            AppController.instance.getInvitationFieldsData.setParentId =
                dropdownValue!.id;
          }
        }
      } else {
        if (_model.length > 0) {
          for (int i = 0; i < _model.length; i++) {
            if (AppController.instance.getMyBuId == _model[i].id) {
              dropdownValue = _model[i];
              AppController.instance.getInvitationFieldsData.setBusinessName =
                  dropdownValue!.businessName;
              AppController.instance.getInvitationFieldsData.setParentId =
                  dropdownValue!.id;
            }
          }
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
      return _model;
  }

  /// Creating unit/team lookup

  buildDepartmentDropdown(String text) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(Language().getString(text, selectedLang),
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: StyleView.FONT_TITLE))),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5, right: 5),
                  child: DropdownButton<DepartmentDAO>(
                      onTap: () {
                        CommonMethods.hideKeyboard(context);
                      },
                      value: departmentDropdownValue,
                      isExpanded: true,
                      hint: Text(
                          Language().getString(
                              Constants.SELECT_UNIT_TEAM, selectedLang),
                          style: TextStyle(fontFamily: StyleView.FONT_TITLE)),
                      underline: SizedBox(),
                      onChanged: (DepartmentDAO? data) {
                        setState(() {
                          departmentDropdownValue = data;
                          AppController.instance.invitationFieldsData!
                                  .setBusinessUnitId =
                              departmentDropdownValue!.name!;
                        });
                      },
                      items: _departmentList.map((DepartmentDAO model) {
                        return new DropdownMenuItem<DepartmentDAO>(
                          child: new Text(model.name!,
                              style:
                                  TextStyle(fontFamily: StyleView.FONT_TITLE)),
                          value: model,
                        );
                      }).toList())),
            )
          ],
        ));
  }

  buildParentDetailsDropDown(
      String textName, TextEditingController _controller) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                            Language().getString(textName, selectedLang),
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: StyleView.FONT_TITLE))),
                  )),
            ),
            Expanded(
                flex: 2,
                child: Container(
                    height: 50,
                    padding: EdgeInsets.all(5),
                    decoration: BoxDecoration(color: Colors.white),
                    child: DropdownButton<BuBasicDataModel>(
                        onTap: () {
                          CommonMethods.hideKeyboard(context);
                        },
                        value: dropdownValue,
                        isExpanded: true,
                        hint: Text(Language()
                            .getString(Constants.SELECT_BU, selectedLang)),
                        underline: SizedBox(),
                        onChanged: (BuBasicDataModel? data) {
                          setState(() {
                            dropdownValue = data;
                            AppController.instance.getInvitationFieldsData
                                .setBusinessName = data!.businessName;
                            AppController.instance.getInvitationFieldsData
                                .setParentId = data.id;
                          });
                        },
                        items: _bubasicdatamodel.map((BuBasicDataModel model) {
                          return new DropdownMenuItem<BuBasicDataModel>(
                            child: new Text(
                              model.businessName!,
                              style:
                                  TextStyle(fontFamily: StyleView.FONT_TITLE),
                            ),
                            value: model,
                          );
                        }).toList())))
          ],
        ));
  }

  ///Dynamically creating invitation fields
  buildTableContent(String textName, TextEditingController _controller,
      bool isKeyboard, bool isMandatory) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: isMandatory
                            ? RichText(
                                text: TextSpan(children: [
                                  TextSpan(
                                    text: Language()
                                        .getString(textName, selectedLang),
                                    style: TextStyle(
                                        fontSize: StyleView.FONT_SIZE_15,
                                        fontFamily: StyleView.FONT_TITLE,
                                        color: Colors.black),
                                  ),
                                  TextSpan(
                                      text: "\*",
                                      style: TextStyle(
                                          fontSize: StyleView.FONT_SIZE_15,
                                          color: Colors.red))
                                ]),
                              )
                            : Text(Language().getString(textName, selectedLang),
                                style: TextStyle(
                                    fontSize: StyleView.FONT_SIZE_15,
                                    fontFamily: 'IndianRupee'))),
                  )),
            ),
            Expanded(
                flex: 2,
                child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5),
                  child: TextFormField(
                    // focusNode: FocusNode(canRequestFocus: false),
                    controller: _controller,

                    keyboardType: isKeyboard
                        ? TextInputType.numberWithOptions(signed: true)
                        : TextInputType.text,
                    style: TextStyle(fontFamily: 'IndianRupee'),
                    textInputAction: TextInputAction.next,
                    decoration: InputDecoration(
                      hintText: textName == Constants.EMAIL
                          ? "name@business.com"
                          : Language().getString(textName, selectedLang),
                      border: InputBorder.none,
                    ),
                    onChanged: (text) => {
                      text = _controller.text,
                      updateData(textName, _controller.text)
                    },
                  ),
                ))
          ],
        ));
  }

  buildTextContent(String textName, String value, String _appControllerValue) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(textName,
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: 'IndianRupee'))),
                  )),
            ),
            Expanded(
                flex: 2,
                child: Container(
                    color: Colors.white70,
                    height: 50,
                    padding: EdgeInsets.only(left: 5),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        value,
                        style: TextStyle(fontFamily: 'IndianRupee'),
                      ),
                    )))
          ],
        ));
  }

  ///Save invitation fields data onChage()
  void updateData(String fieldName, String text) {
    switch (fieldName) {
      case Constants.INVITEE_NAME_STRING:
        AppController.instance.getInvitationFieldsData.setInviteeName = text;

        break;
      case Constants.EMAIL:
        AppController.instance.getInvitationFieldsData.setInviteeEmail = text;

        break;
      case Constants.MOBILE_NUMBER:
        AppController.instance.getInvitationFieldsData.setInviteeContactNumber =
            text;

        break;

      default:
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        SingleChildScrollView(
            controller: _scrollController,
            child: Container(
              color: Color(Constants.APP_BACKGROUND_COLOR),
              child: Column(children: <Widget>[
                Container(
                    margin: EdgeInsets.symmetric(vertical: 5.0),
                    decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey),
                        borderRadius: BorderRadius.circular(5)),
                    child: ExpansionTile(
                      title: Text(Language()
                          .getString(Constants.OUR_BU_DETAILS, selectedLang)),
                      children: <Widget>[
                        Column(
                          children: <Widget>[
                            buildParentDetailsDropDown(
                                Constants.BUSSINESS_INPUT_STRING,
                                _bussinessNameController),
                            SizedBox(
                                height: 1,
                                child: new Container(
                                    color: Color(Constants.GREY_COLOR))),
                            buildDepartmentDropdown(
                                Constants.BUSINESS_UNIT_OR_TEAM_STRING)
                          ],
                        ),
                      ],
                    )),
                SizedBox(height: 10),
                Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      border: Border.all(color: Colors.grey),
                    ),
                    child: ExpansionTile(
                        title: Text(Language().getString(
                            Constants.INVITEE_CONTACT_DETAILS_STRING,
                            selectedLang)),
                        children: <Widget>[
                          Column(children: <Widget>[
                            buildTableContent(Constants.NAME_STRING,
                                _usernamecontroller, false, true),
                            SizedBox(
                                height: 1,
                                child: new Container(
                                    color: Color(Constants.GREY_COLOR))),
                            Container(
                              padding: EdgeInsets.all(1),
                              child: Row(
                                children: <Widget>[
                                  Expanded(
                                    child: Container(
                                        height: 50,
                                        color:
                                            Color(Constants.GREY_COLOR_LIGHT),
                                        child: Container(
                                          padding: EdgeInsets.only(left: 10),
                                          child: Align(
                                              alignment: Alignment.centerLeft,
                                              child: RichText(
                                                text: TextSpan(children: [
                                                  TextSpan(
                                                    text: Language().getString(
                                                        Constants.MOBILE_NUMBER,
                                                        selectedLang),
                                                    style: TextStyle(
                                                        fontSize: StyleView
                                                            .FONT_SIZE_15,
                                                        fontFamily: StyleView
                                                            .FONT_TITLE,
                                                        color: Colors.black),
                                                  ),
                                                  TextSpan(
                                                      text: "\*",
                                                      style: TextStyle(
                                                          fontSize: StyleView
                                                              .FONT_SIZE_15,
                                                          color: Colors.red))
                                                ]),
                                              )),
                                        )),
                                  ),
                                  Expanded(
                                      flex: 2,
                                      child: Row(
                                        children: [
                                          Expanded(
                                            flex: 1,
                                            child: Container(
                                              color: Colors.white70,
                                              padding: EdgeInsets.only(left: 5),
                                              child: TextFormField(
                                                keyboardType:
                                                    (defaultTargetPlatform ==
                                                            TargetPlatform.iOS)
                                                        ? TextInputType
                                                            .numberWithOptions(
                                                                signed: true)
                                                        : TextInputType.number,
                                                controller:
                                                    _countryCodeController,
                                                textInputAction:
                                                    TextInputAction.next,
                                                style: TextStyle(
                                                    fontFamily: 'IndianRupee'),
                                                decoration: InputDecoration(
                                                  hintText: "+00",
                                                  border: InputBorder.none,
                                                ),
                                                inputFormatters: [
                                                  LengthLimitingTextInputFormatter(
                                                      5),
                                                  CommonMethods
                                                      .inputTextFormatter(
                                                          isNumber: true)
                                                ],
                                                onChanged: (text) {
                                                  _countryCodeController.text =
                                                      "+$text";
                                                  _countryCodeController
                                                          .selection =
                                                      TextSelection.fromPosition(
                                                          TextPosition(
                                                              offset:
                                                                  _countryCodeController
                                                                      .text
                                                                      .length));
                                                  AppController
                                                          .instance
                                                          .getInvitationFieldsData
                                                          .setCountryCode =
                                                      _countryCodeController
                                                          .text;
                                                },
                                              ),
                                            ),
                                          ),
                                          Expanded(
                                            flex: 2,
                                            child: Container(
                                              color: Colors.white70,
                                              padding: EdgeInsets.only(left: 5),
                                              child: TextFormField(
                                                controller:
                                                    _phonenumbercontroller,
                                                keyboardType:
                                                    (defaultTargetPlatform ==
                                                            TargetPlatform.iOS)
                                                        ? TextInputType
                                                            .numberWithOptions(
                                                                signed: true)
                                                        : TextInputType.number,
                                                textInputAction:
                                                    TextInputAction.done,
                                                style: TextStyle(
                                                    fontFamily: 'IndianRupee'),
                                                decoration: InputDecoration(
                                                    hintText: Language()
                                                        .getString(
                                                            Constants
                                                                .MOBILE_NUMBER,
                                                            selectedLang),
                                                    border: InputBorder.none,
                                                    hintStyle: TextStyle(
                                                        fontSize: 15.0)),
                                                onChanged: (text) => {
                                                  text = _phonenumbercontroller
                                                      .text,
                                                  updateData(
                                                      Constants.MOBILE_NUMBER,
                                                      _phonenumbercontroller
                                                          .text)
                                                },
                                                inputFormatters: [
                                                  LengthLimitingTextInputFormatter(
                                                      10),
                                                  FilteringTextInputFormatter
                                                      .allow(RegExp("[0-9]"))
                                                ],
                                              ),
                                            ),
                                          ),
                                          Container(
                                            color: Colors.white70,
                                            child: IconButton(
                                                icon: Icon(Icons.contact_phone),
                                                onPressed: () async {
                                                  CommonMethods.hideKeyboard(
                                                      context);
                                                  if (!kIsWeb) {
                                                    Contact? _contact =
                                                        await AppUtills
                                                            .getContactFromPhoneBook();
                                                    this.updateSelectedPhoneNumber(
                                                        _contact);
                                                  }
                                                }),
                                          )
                                        ],
                                      ))
                                ],
                              ),
                            ),
                            SizedBox(
                                height: 1,
                                child: new Container(
                                    color: Color(Constants.GREY_COLOR))),
                            buildTableContent(Constants.EMAIL, _emailcontroller,
                                false, false),
                          ])
                        ])),
              ]),
            )),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    );
  }

  appendingInvitationData() {
    _phonenumbercontroller.text = AppController
                .instance.getInvitationFieldsData.getInviteeContactNumber !=
            null
        ? AppController.instance.getInvitationFieldsData.getInviteeContactNumber
        : "";
    _usernamecontroller.text =
        AppController.instance.getInvitationFieldsData.getInviteeName != null
            ? AppController.instance.getInvitationFieldsData.getInviteeName
            : "";
    _emailcontroller.text =
        AppController.instance.getInvitationFieldsData.getInviteeEmail != null
            ? AppController.instance.getInvitationFieldsData.getInviteeEmail
            : "";
    if (AppController.instance.getInvitationFieldsData.getCountryCode != null) {
      _countryCodeController.text =
          AppController.instance.getInvitationFieldsData.getCountryCode;
    } else {
      _countryCodeController.text = "+91";

      AppController.instance.getInvitationFieldsData.setCountryCode =
          _countryCodeController.text;
    }
  }

  updateSelectedPhoneNumber(Contact? _data) {
    String? trimedPhoneNumber = "";
    List<String>? selectedPhone = [];
    // PhoneNumber? contact = _data.phoneNumber;
    setState(() {
      if (_data!.phoneNumbers!.isNotEmpty && _data.phoneNumbers![0].contains("+91")) {
        selectedPhone = _data.phoneNumbers![0].split(" ");
        trimedPhoneNumber = selectedPhone![1] + selectedPhone![2];
      } else {
        trimedPhoneNumber = _data.phoneNumbers![0].replaceAll(" ", "");
        _usernamecontroller.clear();
        _countryCodeController.clear();
      }
      _phonenumbercontroller.text = trimedPhoneNumber!;
      _phonenumbercontroller.selection = TextSelection.fromPosition(
          TextPosition(offset: _phonenumbercontroller.text.length));
      _usernamecontroller.text = _data.fullName!;
      if (selectedPhone!.length > 0) {
        _countryCodeController.text = selectedPhone![0];
        AppController.instance.getInvitationFieldsData.setCountryCode =
            _countryCodeController.text;
      }

      AppController.instance.getInvitationFieldsData.setInviteeName =
          _usernamecontroller.text;
      AppController.instance.getInvitationFieldsData.setInviteeContactNumber =
          _phonenumbercontroller.text;
    });
  }
}
