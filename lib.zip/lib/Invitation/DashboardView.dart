import 'package:share_plus/share_plus.dart';
import 'package:vyaparlive/service/user_services.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:clipboard/clipboard.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
// import 'package:share/share.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Invitation/CreateNewInvitation.dart';
import 'package:vyaparlive/Invitation/InvitationReview.dart';
import 'package:vyaparlive/Invitation/InviteDashboard.dart';

import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/connections_view/ContactsPage.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/InvitationFieldsData.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:vyaparlive/service/invitation_services.dart';
import 'dart:convert';
import 'package:vyaparlive/utills/SharePref.dart';
import 'package:toast/toast.dart';

import '../model/UserModel.dart';

class DashboardView extends StatefulWidget {
  @override
  DashboardViewState createState() => DashboardViewState();
}

class DashboardViewState extends State<DashboardView>
    with TickerProviderStateMixin {
  TabController? _tabController;
  bool isCompleteStepOne = false;
  bool isCompleteStepTwo = false;
  int currentStep = 0;
  int tabIndex = 0;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  bool isLoading = false;
  final _usernamecontroller = TextEditingController();
  final _emailcontroller = TextEditingController();
  final _phonenumbercontroller = TextEditingController();
  String name = '';
  String email = '';
  String phonenumber = '';
  var objectData;
  String? userContact = "";
  String? userId;
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  late InvitationService _invitationService;
  late UserService _userService;
  late ThemeData theme;
  num nTabs = 2;
  late UserModel userData;

  /// Language conversion

  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _invitationService = InvitationService();
    _userService = new UserService();
    InvitationFieldsData data = InvitationFieldsData();
    AppController.instance.setInvitationFieldsData = data;
    _tabController = TabController(length: 2, vsync: this);
    SharePref().getPhoneNumber().then((onValue) {
      setState(() => userContact = onValue);
    });

    SharePref().getUserId().then((onValue) {
      setState(() => userId = onValue);
      onUserDetails();
    });
  }

  /// Navigate to next tab page

  void onNextStep() {
    String validateError = validateFields()!;
    if (validateError.isNotEmpty) {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          validateError,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    } else {
      if (AppController
                  .instance.getInvitationFieldsData.getInviteeEmail ==
              null ||
          AppController
              .instance.getInvitationFieldsData.getInviteeEmail.isEmpty ||
          validateEmail(
              AppController.instance.getInvitationFieldsData.getInviteeEmail)) {
        tabIndex = _tabController!.index + 1;
      } else {
        Dialogs.yesCancelDialog(
            context,
            Language().getString(Constants.ERROR, selectedLang),
            Language().getString(Constants.PLEASE_ENTER_EMAIL, selectedLang),
            Language().getString(Constants.OKAY_STR, selectedLang),
            "",
            false);
      }
    }

    switch (tabIndex) {
      case 1:
        setState(() {
          isCompleteStepOne = true;
          _tabController!.animateTo(tabIndex);
        });

        break;
      case 2:
        setState(() {
          isCompleteStepTwo = true;
        });
        break;
      default:
    }
  }

  /// Service call for get user details

  onUserDetails() async {
    String body = json.encode({"id": userId});
    // http.Response
    var response = await _userService
        .getUserById_grpc(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      objectData = resObj[0];
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  /// Validating invitation fields

  String? validateFields() {
    if (AppController.instance.getInvitationFieldsData.getInviteeName == null ||
        AppController.instance.getInvitationFieldsData.getInviteeName.isEmpty) {
      return Language()
          .getString(Constants.PLEASE_ENTER_INVITEE_NAME, selectedLang);
    } else if (AppController
                .instance.getInvitationFieldsData.getInviteeContactNumber ==
            null ||
        AppController
            .instance.getInvitationFieldsData.getInviteeContactNumber.isEmpty) {
      return Language()
          .getString(Constants.PLEASE_ENTER_INVITEE_MOBILE, selectedLang);
    } else if (AppController
            .instance.getInvitationFieldsData.getInviteeContactNumber.length <
        10) {
      return Language()
          .getString(Constants.PLEASE_ENTER_VALID_MOBILE, selectedLang);
    } else if (AppController
            .instance.getInvitationFieldsData.getInviteeContactNumber ==
        userContact) {
      return Language().getString(Constants.USER_ALREADY_EXIST, selectedLang) +
          userContact;
    } else {
      return "";
    }
  }

  bool validateEmail(String value) {
    Pattern pattern =
        r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
    RegExp regex = new RegExp(pattern as String);
    return (!regex.hasMatch(value)) ? false : true;
  }

  /// service call for create new invitation

  onCreatenewInvitation() async {
    setState(() {
      isLoadingProgress = true;
    });
    String contactPersonName = objectData['name'].toString();
    String contactNum = objectData['contact'].toString();
    String emailUrl = objectData['PersonalEmailId'].toString();
    // AppController.instance.getInvitationFieldsData.getBusinessRelation,
    Map data = {
      "inviter": {
        "invite_company":
            AppController.instance.getInvitationFieldsData.getParentId,
        "invite_company_name": AppController.instance.getBuName,
        "contact_person": contactPersonName,
        "contact": contactNum,
        "business_relation": "Direct",
        "url": emailUrl,
        "invited_date_time": "",
        "supplier": false,
        "buyer": false
      },
      "invitee": {
        "email_id":
            AppController.instance.getInvitationFieldsData.getInviteeEmail,
        "contact": AppController
            .instance.getInvitationFieldsData.getInviteeContactNumber,
        "company_name":
            AppController.instance.getInvitationFieldsData.getInviteeName,
        "relation": "Direct",
        "accepted_date_time": "",
        "supplier": false,
        "buyer": false,
        "country_code":
            AppController.instance.getInvitationFieldsData.getCountryCode,
      }
    };
    String body = json.encode(data);

    var response = await _invitationService
        .createInvitation(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resonseBody = json.decode(_grpcResponse.message!);
      var message = resonseBody["sms-message"];
      String? invieeNumber = AppController
          .instance.getInvitationFieldsData.getInviteeContactNumber;

      return showDialog(
          barrierDismissible: false,
          context: context,
          builder: (context) => AlertDialog(
                contentPadding: EdgeInsets.fromLTRB(10.0, 24.0, 0.0, 24.0),
                content: Container(
                  height: 250.0,
                  child: Column(
                    children: [
                      Text(
                        Language().getString(
                            Constants.INVITATION_SENT_SUCCESSFULLY_ALERT_STRING,
                            selectedLang),
                        textAlign: TextAlign.start,
                        style: TextStyle(
                            fontSize: 15.0,
                            fontWeight: FontWeight.bold,
                            color: Color(Constants.APP_COLOR)),
                      ),
                      Container(
                        margin: EdgeInsets.only(top: 50.0),
                        child: SelectableText(Language()
                                .getString(Constants.MR_MRS, selectedLang) +
                            "$contactPersonName " +
                            Language().getString(
                                Constants
                                    .SEND_INVITATIONS_VYAPARLIVE_MOBILE_NUMBER,
                                selectedLang) +
                            " $contactNum " +
                            Language().getString(
                                Constants.TO_YOUR_MOBILE_NUMBER, selectedLang) +
                            " $invieeNumber.\n" +
                            Language().getString(message, selectedLang)),
                      )
                    ],
                  ),
                ),
                actions: <Widget>[
                  TextButton(
                    child: new Text(
                      Language().getString(Constants.CLOSE, selectedLang),
                      style: TextStyle(
                          color: Color(Constants.APP_COLOR),
                          fontSize: StyleView.FONT_SIZE_15),
                    ),
                    onPressed: () {
                      // clearInvitationData();
                      Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              builder: (context) => InviteView(),
                              maintainState: false));
                    },
                  ),
                  SizedBox(width: 110.0),
                  TextButton(
                    child: new Text(
                      Language().getString(
                          (kIsWeb)
                              ? Language()
                                  .getString(Constants.COPY, selectedLang)
                              : Language()
                                  .getString(Constants.SHARE, selectedLang),
                          selectedLang),
                      style: TextStyle(
                          color: Color(Constants.APP_COLOR),
                          fontSize: StyleView.FONT_SIZE_15),
                    ),
                    onPressed: () {
                      var shareData =
                          "Mr/Ms.$contactPersonName has sent you an invitation for Vyapar live from mobile number $contactNum to your mobile number $invieeNumber.\n $message";
                      if (kIsWeb) {
                        FlutterClipboard.copy(shareData).then((value) => {
                              print('copied'),
                              Toast.show("Copied to clipboard",
                                  duration: Toast.lengthShort,
                                  gravity: Toast.bottom)
                            });
                      } else {
                        SharePlus.instance.share(ShareParams(
                          text: shareData,
                          title: Language().getString(
                              Constants.APANAVYAPAR_INVITATION, selectedLang),
                          subject: Language().getString(
                              Constants.APANAVYAPAR_INVITATION, selectedLang),
                        ));
                        // Share.share(
                        //   shareData,
                        //   subject: Language().getString(
                        //       Constants.APANAVYAPAR_INVITATION, selectedLang),
                        // );
                      }
                    },
                  ),
                ],
              ));
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  /// Alert popup

  alertmessageDisplay(String message) {
    return showDialog(
        barrierDismissible: false,
        context: context,
        builder: (context) {
          return AlertDialog(
            title: new Text(Language().getString(Constants.INFO, selectedLang)),
            content: Text(message),
            actions: <Widget>[
              TextButton(
                child: new Text(
                    Language().getString(Constants.OKAY_STR, selectedLang),
                    style: TextStyle(
                        color: Color(Constants.APP_COLOR), fontSize: 18.0)),
                onPressed: () {
                  Navigator.of(context).pop();

                  Navigator.push(context,
                      PageTransition(context: context, page: ContactsView()));
                },
              ),
            ],
          );
        });
  }

  /// Creating  invitation fields

  inviteContactField() {
    return Container(
        decoration: BoxDecoration(
            border: Border.all(color: Colors.grey),
            borderRadius: BorderRadius.circular(5)),
        child: ExpansionTile(
          title: Text(Language().getString(
              Constants.INVITEE_CONTACT_DETAILS_STRING, selectedLang)),
          children: <Widget>[
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                buildTableInputContent(
                    Language()
                        .getString(Constants.INVITEE_NAME_STRING, selectedLang),
                    Language()
                        .getString(Constants.TEMP_USER_NAME, selectedLang),
                    _usernamecontroller,
                    _usernamecontroller.text),
                SizedBox(
                    height: 1,
                    child: new Container(color: Color(Constants.GREY_COLOR))),
                buildTableInputContent('ER_TITLE_STRING', Constants.TEMP_PHN,
                    _phonenumbercontroller, _phonenumbercontroller.text),
                SizedBox(
                    height: 1,
                    child: new Container(color: Color(Constants.GREY_COLOR))),
                buildTableInputContent(
                    Constants.EMAIL_ID_STRING,
                    Constants.TEMP_USER_EMAIL,
                    _emailcontroller,
                    _emailcontroller.text),
              ],
            ),
          ],
        ));
  }

  /// Dynamically creating input fields

  buildTableInputContent(String textName, textFormName,
      TextEditingController _controller, String _textContoller) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(textName,
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: StyleView.FONT_TITLE))),
                  )),
            ),
            Expanded(
                flex: 2,
                child: Container(
                    height: 50,
                    color: Colors.white70,
                    padding: EdgeInsets.only(left: 5),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: new TextFormField(
                        style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                        controller: _controller,
                        decoration: InputDecoration(
                          labelText: textName,
                        ),
                        onChanged: (text) => {name = _textContoller},
                      ),
                    )))
          ],
        ));
  }

  @override
  void dispose() {
    _tabController!.dispose();
    super.dispose();
  }

  /// Creating bottom navigation ui

  buildButton() {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 30, horizontal: 20),
      child: CommonButtonsView(
        context: context,
        b2Text: (isCompleteStepOne)
            ? Language().getString(Constants.CREATE_INVITATION, selectedLang)
            : Language().getString(Constants.NEXT, selectedLang),
        onb2Action: () => {
          if (isCompleteStepOne) {onCreatenewInvitation()} else {onNextStep()}
        },
        b1Text: (!isCompleteStepOne)
            ? Language().getString(Constants.STR_CANCEL, selectedLang)
            : "",
        onb1Action: () => Navigator.of(context).pop(),
      ),
    );
  }

  /// Highliting text

  createInvitationHeading() {
    return Container(
      alignment: Alignment.center,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          new Text(
              Language().getString(
                  Constants.PLEASE_FILL_INVITE_FORM_TITLE_STRING, selectedLang),
              style: TextStyle(
                  decoration: TextDecoration.underline,
                  fontSize: StyleView.FONT_SIZE_15,
                  color: Colors.black,
                  fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  reviewInvitationHeading() {
    return Container(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          new Text(
            Language().getString(
                Constants.REVIEW_THE_INVITE_FORM_STRING, selectedLang),
            style: TextStyle(
                decoration: TextDecoration.underline,
                fontSize: StyleView.FONT_SIZE_18,
                fontWeight: FontWeight.bold,
                color: Colors.black),
          ),
        ],
      ),
    );
  }

  Color circleContainerColor(index) {
    Color _customColor;
    if (index < tabIndex) {
      _customColor = Colors.black;
    } else if (index == tabIndex) {
      _customColor = Colors.black;
    } else {
      _customColor = Colors.grey;
    }
    return _customColor;
  }

  Color circleContainerBorder(index) {
    Color _customBorder;
    if (index < tabIndex) {
      _customBorder = Colors.black;
    } else if (index == tabIndex) {
      _customBorder = Colors.black;
    } else {
      _customBorder = Colors.grey;
    }
    return _customBorder;
  }

  Widget completeSterView(index) {
    if (index < tabIndex) {
      return Icon(
        Icons.check,
        size: 20,
        color: Colors.white,
      );
    } else if (index == tabIndex) {
      return Text(
        "${index + 1}",
        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
      );
    } else {
      return Text("${index + 1}");
    }
  }

  Color? lineColor(index) {
    Color? _customLineColor;
    if (index < tabIndex) {
      _customLineColor = Colors.green;
    } else if (index == tabIndex) {
      _customLineColor = Colors.grey;
    }

    return _customLineColor;
  }

  List<Widget> stepperView() {
    List<Widget> _list = [];

    for (int i = 0; i < nTabs; i++) {
      _list.add(Container(
        height: 30,
        width: 30,
        alignment: Alignment.center,
        decoration: BoxDecoration(
            color: circleContainerColor(i),
            borderRadius: BorderRadius.all(Radius.circular(30 / 2)),
            border: Border.all(color: circleContainerBorder(i))),
        child: completeSterView(i),
      ));
      if (i != nTabs - 1) {
        _list.add(
          Expanded(
            child: Container(
              height: 3.5,
              color: Colors.grey,
            ),
          ),
        );
      }
    }
    return _list;
  }

  Widget renderViews() {
    if (tabIndex == 0) {
      return Expanded(
        child: Container(
            color: Colors.transparent, //(Constants.APP_BACKGROUND_COLOR),
            child: CreateNewInvitation()),
      );
    } else {
      return Expanded(
        child: Container(
            color: Colors.transparent, //(Constants.APP_BACKGROUND_COLOR),
            child: new InvitationReview()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    ToastContext().init(context);
    return AppBackgroundView(
      body: Stack(
        children: [
          SafeArea(
            child: Scaffold(
                key: _scaffoldkey,
                backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                resizeToAvoidBottomInset: true,
                appBar: AppBar(
                  elevation: 0.0,
                  iconTheme: IconThemeData(color: theme.colorScheme.primary),
                  backgroundColor: Colors.transparent, //(Constants.APP_COLOR),
                  centerTitle: true,
                  title: AppbarName(
                      title: Language().getString(
                          Constants.ADD_NEW_INVITE_STRING, selectedLang),
                      buName: AppController.instance.getBuName),
                  actions: isCompleteStepOne
                      ? [
                          IconButton(
                            onPressed: () {
                              setState(() {
                                isCompleteStepOne = false;
                                isCompleteStepTwo = false;
                                tabIndex = _tabController!.index - 1;
                                _tabController!.animateTo(tabIndex);
                              });
                            },
                            icon: Icon(Icons.edit, color: Colors.white),
                          ),
                        ]
                      : [],
                ),
                bottomNavigationBar: buildButton(),
                body: (isLoading)
                    ? new Container(
                        child: Center(
                        child: CircularProgressIndicator(),
                      ))
                    : Container(
                        padding: EdgeInsets.all(16),
                        child: Column(
                          children: [
                            Row(
                              children: stepperView(),
                            ),
                            SizedBox(height: 10),
                            Expanded(
                                child: Column(
                              children: [renderViews()],
                            ))
                          ],
                        ),
                      )),
          ),
          AppUtills.showLoadingView(
              context: context,
              message: Language().getString(progressMessage, selectedLang),
              isLoading: isLoadingProgress),
        ],
      ),
    );
  }

  clearInvitationData() {
    AppController.instance.getInvitationFieldsData.setInviteeEmail = '';
    AppController.instance.getInvitationFieldsData.setInviteeName = '';
    AppController.instance.getInvitationFieldsData.setInviteeContactNumber = '';
    AppController.instance.getInvitationFieldsData.setBusinessRelation = '';
    AppController.instance.getInvitationFieldsData.setBusinessName = '';
    AppController.instance.getInvitationFieldsData.setParentId = '';
  }
}
