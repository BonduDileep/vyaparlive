import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/InvitationFieldsData.dart';

class InvitationReview extends StatefulWidget {
  @override
  InvitationReviewState createState() => InvitationReviewState();
}

class InvitationReviewState extends State<InvitationReview> {
  ScrollController _scrollController =
      new ScrollController(initialScrollOffset: 0.0, keepScrollOffset: true);

  InvitationFieldsData? invitationFieldsData;

  String? relationType;
  String? roleInRelationShip;
  String? ableToInvite;

  String? businessName;
  String? businessTeam;

  String? country;
  String? state;
  String? city;
  String? currency;
  String? currencyCode;

  String? inviteeName;
  String? inviteeEmail;
  String? inviteeMobile;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  String? countryCode;

  @override
  void initState() {
    super.initState();
    invitationFieldsData = AppController.instance.getInvitationFieldsData;
    relationType = invitationFieldsData!.getBusinessRelation;
    roleInRelationShip = invitationFieldsData!.getBusinessRole;
    ableToInvite = invitationFieldsData!.getAbleToInvite;

    businessName = invitationFieldsData!.getBusinessName;
    businessTeam = invitationFieldsData!.getBusinessUnitId;

    country = invitationFieldsData!.getCountry;
    state = invitationFieldsData!.getState;
    city = invitationFieldsData!.getCity;
    currency = invitationFieldsData!.getCurrency;
    currencyCode = invitationFieldsData!.getCountryCode;

    inviteeName = invitationFieldsData!.getInviteeName;
    inviteeEmail = invitationFieldsData!.getInviteeEmail;
    inviteeMobile = invitationFieldsData!.getInviteeContactNumber;
    countryCode = invitationFieldsData!.getCountryCode;
  }

  @override
  void dispose() {
    super.dispose();
  }

  inviteContactField() {
    return Container(
      decoration: BoxDecoration(
          border: Border.all(color: Colors.grey),
          borderRadius: BorderRadius.circular(5)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          buildTableContent(Constants.INVITEE_NAME_STRING,
              inviteeName != null ? inviteeName : ""),
          SizedBox(
              height: 1,
              child: new Container(color: Color(Constants.GREY_COLOR))),
          buildTableContent(Constants.EMAIL_ID_STRING,
              inviteeEmail != null ? inviteeEmail : ""),
          SizedBox(
              height: 1,
              child: new Container(color: Color(Constants.GREY_COLOR))),
          buildTableContent(
              Constants.MOBILE_NUMBER, "$countryCode $inviteeMobile"),
          SizedBox(
              height: 1,
              child: new Container(color: Color(Constants.GREY_COLOR))),
        ],
      ),
    );
  }

  relationshipField() {
    return Container(
      decoration: BoxDecoration(
          border: Border.all(color: Colors.grey),
          borderRadius: BorderRadius.circular(5)),
      child: Column(
        children: <Widget>[
          buildTableContent(
              Constants.TEMP_TYPE, relationType != null ? relationType : ""),
        ],
      ),
    );
  }

  commercialRelationshipField() {
    return Container(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          new Text(
              Language().getString(
                  Constants.COMMERCIAL_RELATIONSHIP_TITLE_STRING, selectedLang),
              style: TextStyle(
                  decoration: TextDecoration.underline,
                  fontSize: StyleView.FONT_SIZE_15,
                  color: Colors.black,
                  fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  bussinessField() {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(5),
          border: Border.all(color: Colors.grey)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          buildTableContent(Constants.BUSINESS_NAME_TITLE_STRING,
              businessName != null ? businessName : ""),
          SizedBox(
              height: 1,
              child: new Container(color: Color(Constants.GREY_COLOR))),
          buildTableContent(Constants.BUSINESS_UNIT_OR_TEAM_STRING,
              businessTeam != null ? businessTeam : ""),
        ],
      ),
    );
  }

  buildTableContent(String textName, textFormName) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                            Language().getString(textName, selectedLang),
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: StyleView.FONT_TITLE))),
                  )),
            ),
            Expanded(
                flex: 2,
                child: Container(
                    height: 50,
                    color: Colors.white70,
                    padding: EdgeInsets.only(left: 5),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        textFormName,
                        style: TextStyle(fontFamily: StyleView.FONT_TITLE),
                      ),
                    )))
          ],
        ));
  }

  basicDetails() {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(5),
          border: Border.all(color: Colors.grey)),
      child: Column(children: <Widget>[
        buildTableContent(
            Constants.COUNTRY_NAME_STRING, country != null ? country : ""),
        SizedBox(
            height: 1,
            child: new Container(color: Color(Constants.GREY_COLOR))),
        buildTableContent(
            Constants.STATE_NAME_STRING, state != null ? state : ""),
        SizedBox(
            height: 1,
            child: new Container(color: Color(Constants.GREY_COLOR))),
        buildTableContent(Constants.CITY_NAME_STRING, city != null ? city : ""),
        SizedBox(
            height: 1,
            child: new Container(color: Color(Constants.GREY_COLOR))),
        buildTableContent(
            Constants.CURRENCY_STRING, currency != null ? currency : ""),
        SizedBox(
            height: 1,
            child: new Container(color: Color(Constants.GREY_COLOR))),
        buildTableContent(Constants.CURRENCY_CODE_STRING,
            currencyCode != null ? currencyCode : ""),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
        controller: _scrollController,
        child: Container(
          color: Color(Constants.APP_BACKGROUND_COLOR),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              // commercialRelationshipField(),
              SizedBox(height: 5),
              Text(
                  Language().getString(
                      Constants.INVITEE_CONTACT_DETAILS_STRING, selectedLang),
                  style: TextStyle(
                      fontSize: StyleView.FONT_SIZE_15,
                      color: Colors.black,
                      fontWeight: FontWeight.bold)),
              SizedBox(
                height: 10,
              ),
              inviteContactField(),
              SizedBox(
                height: 20,
              ),
              Text(Language().getString(Constants.OUR_BU_DETAILS, selectedLang),
                  style: TextStyle(
                      fontSize: StyleView.FONT_SIZE_15,
                      color: Colors.black,
                      fontWeight: FontWeight.bold)),
              SizedBox(
                height: 10,
              ),
              bussinessField(),
              SizedBox(
                height: 20,
              ),
            ],
          ),
        ));
  }
}
