import 'package:vyaparlive/theme/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:vyaparlive/components/StyleView.dart';

class ReceivedInvitationsCardView extends StatelessWidget {
  final String? name;
  final String? org;
  final String? strDate;
  final String? status;
  final String? inviterName;
  final String? organization;
  final String? date;
  final String? invitationStatus;
  final VoidCallback? removeInvitation;
  final String? strInvitedDate;
  final String? strAcceptedDate;
  final String? invitedDate;
  final String? acceptedDate;
  final ThemeData theme = AppTheme.vyaparTheme;
  ReceivedInvitationsCardView(
      {this.invitationStatus,
      this.inviterName,
      this.organization,
      this.removeInvitation,
      this.date,
      this.name,
      this.org,
      this.status,
      this.strDate,
      this.strInvitedDate,
      this.strAcceptedDate,
      this.invitedDate,
      this.acceptedDate});
  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 7.0,
      shadowColor: theme.colorScheme.primary,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(5.0),
          side: BorderSide(
              color: theme.colorScheme.primaryContainer, strokeAlign: 1)),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: <Widget>[
            buildInvitationsView(name!, "$inviterName"),
            buildInvitationsView(org!, "$organization"),
            buildInvitationsView(strInvitedDate!, "$invitedDate"),
            buildInvitationsView(strAcceptedDate!, "$acceptedDate"),
            Row(
              children: <Widget>[
                Expanded(
                  child: Container(
                      height: 20,
                      child: Container(
                        child: Align(
                            alignment: Alignment.centerLeft,
                            child: Text(status!,
                                style: TextStyle(
                                    color: Colors.black,
                                    fontWeight: StyleView.fontSemiBold))),
                      )),
                ),
                Expanded(
                  flex: 2,
                  child: Container(
                      height: 20,
                      child: Container(
                        child: Align(
                          alignment: Alignment.centerLeft,
                          child: Row(children: <Widget>[
                            Text(":   "),
                            Text(invitationStatus!,
                                style: TextStyle(
                                    color: invitationStatus == "pending"
                                        ? Colors.orange
                                        : Colors.green,
                                    fontWeight: StyleView.fontSemiBold,
                                    fontSize: 13.0))
                          ]),
                        ),
                      )),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  buildInvitationsView(String title, String subTitle) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 5.0),
      child: Row(
        children: <Widget>[
          Expanded(
            child: Container(
                height: 20,
                child: Container(
                  child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(title,
                          style: TextStyle(
                              color: Colors.black,
                              fontWeight: StyleView.fontSemiBold))),
                )),
          ),
          Text("  : "),
          Expanded(
            flex: 2,
            child: Container(
                height: 20,
                child: Container(
                  child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text("$subTitle",
                          style: TextStyle(
                              fontSize: 13.0,
                              fontWeight: StyleView.fontMedium,
                              color: Colors.black))),
                )),
          ),
        ],
      ),
    );
  }
}
