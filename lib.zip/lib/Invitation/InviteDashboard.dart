import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Invitation/DashboardView.dart';
import 'package:vyaparlive/Invitation/InviteesStatusPage.dart';
import 'package:vyaparlive/Invitation/MyInvitationsPage.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/MyDrawer.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/privileges/invitation_privileges.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';

class InviteView extends StatefulWidget {
  final bool isFromHomePage;
  InviteView({this.isFromHomePage = false});
  @override
  _InviteViewState createState() => _InviteViewState();
}

class _InviteViewState extends State<InviteView> with TickerProviderStateMixin {
  TabController? _tabController;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  List<String> strList = ["Create Invitation", "Filter"];
  var filteroptions = [
    {'name': "Pending Invitataions", 'isFilterValue': false},
    {'name': "Rejected Invitations", 'isFilterValue': false},
  ];
  InvitationPrivileges? _invitationPrivileges =
      AppController.instance.getInvitationPrivileges;
  bool isMyInvitationsPageReload = false;
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController!.dispose();
    super.dispose();
  }

  @override
  void setState(VoidCallback fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return AppBackgroundView(
      body: WillPopScope(
          child: SafeArea(
            child: Scaffold(
                backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                resizeToAvoidBottomInset: true,
                appBar: AppBar(
                  backgroundColor: Colors.transparent,
                  elevation: 0,
                  iconTheme: IconThemeData(color: theme.colorScheme.primary),
                  title: AppbarName(
                      title: Language()
                          .getString(Constants.INVITATIONS_STRING, selectedLang),
                      buName: "${AppController.instance.getBuName}"),
                  centerTitle: true,
                  actions: <Widget>[
                    (_invitationPrivileges!.invitation_create)
                        ? IconButton(
                            icon: Icon(Icons.add),
                            onPressed: () {
                              CommonMethods.hideKeyboard(context);
                              Navigator.push(
                                  context,
                                  PageTransition(
                                      context: context, page: DashboardView()));
                            })
                        : Container(),
                    AppUtills.homeButton(context),
                  ],
                  bottom: PreferredSize(
                    preferredSize: Size.fromHeight(screenSize.height * 0.09),
                    child: TabBar(
                        indicatorSize: TabBarIndicatorSize.tab,
                        indicator: BoxDecoration(
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey,
                                blurRadius: 6.0,
                              ),
                              BoxShadow(
                                  color: Colors.white, offset: Offset(0, 9)),
                            ],
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(10),
                                topRight: Radius.circular(10)),
                            color: Colors.white),
                        controller: _tabController,
                        onTap: (index) {
                          CommonMethods.hideKeyboard(context);
                        },
                        tabs: <Widget>[
                          Tab(
                            child: Text(
                              Language().getString(Constants.SENT, selectedLang),
                              style: TextStyle(color: theme.colorScheme.primary),
                            ),
                          ),
                          Tab(
                              child: Text(
                            Language().getString(Constants.RECEIVE, selectedLang),
                            style: TextStyle(color: theme.colorScheme.primary),
                          ))
                        ]),
                  ),
                ),
                drawer: (widget.isFromHomePage) ? null : MyDrawer(),
                body: TabBarView(
                    controller: _tabController,
                    physics: NeverScrollableScrollPhysics(),
                    children: [
                      MyInvitationsView(isPageReload: isMyInvitationsPageReload),
                      InviteesStatusView()
                    ])),
          ),
          onWillPop: () async {
            if (widget.isFromHomePage) {
              return Navigator.canPop(context);
            } else {
              return CommonMethods.onBackPress(context);
            }
          }),
    );
  }

  buildFilterDialog() {
    return showDialog(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) {
          return StatefulBuilder(builder: (context, StateSetter setState) {
            return Scaffold(
                backgroundColor: Colors.transparent,
                body: Container(
                  height: MediaQuery.of(context).size.height * 0.50,
                  margin: EdgeInsets.all(50.0),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(
                      Radius.circular(15.0),
                    ),
                  ),
                  child: Column(
                    children: <Widget>[
                      Align(
                        alignment: Alignment.topRight,
                        child: GestureDetector(
                          onTap: () {
                            Navigator.of(context).pop();
                          },
                          child: Padding(
                            padding: EdgeInsets.all(5.0),
                            child: Icon(
                              Icons.close,
                              color: Colors.red,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 2.5,
                      ),
                      Text(
                        Language()
                            .getString(Constants.SORT_BY_STR, selectedLang),
                        style: TextStyle(
                            fontSize: StyleView.FONT_SIZE_18,
                            fontFamily: StyleView.FONT_TITLE),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(
                        height: 2.5,
                      ),
                      Container(
                        width: MediaQuery.of(context).size.width,
                        height: 2,
                        color: Colors.grey,
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      ListView.builder(
                          shrinkWrap: true,
                          itemCount: filteroptions.length,
                          itemBuilder: (BuildContext context, int index) {
                            return ListTile(
                              title:
                                  Text(filteroptions[index]['name'] as String),
                              leading: Checkbox(
                                  value: filteroptions[index]['isFilterValue']
                                      as bool?,
                                  onChanged: (bool? value) {
                                    setState(() {
                                      filteroptions[index]['isFilterValue'] =
                                          value!;
                                    });
                                  }),
                              onTap: () {},
                            );
                          }),
                      Spacer(),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                              borderRadius: new BorderRadius.circular(10.0)),
                          backgroundColor: Color(0xFF083e64),
                          textStyle: TextStyle(color: Colors.white),
                          elevation: 3.0,
                        ),
                        onPressed: () => {Navigator.of(context).pop()},
                        child: Padding(
                            padding: EdgeInsets.symmetric(
                                vertical: 5.0, horizontal: 5.0),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                Icon(Icons.arrow_right),
                                Text(Language().getString(
                                    Constants.APPLY_FILTER, selectedLang)),
                              ],
                            )),
                      ),
                      SizedBox(
                        height: 10.0,
                      )
                    ],
                  ),
                ));
          });
        });
  }
}
