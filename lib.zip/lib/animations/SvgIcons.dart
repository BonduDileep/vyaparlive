class SvgIcons {
  static const String app_logo = '''
<?xml version="1.0" encoding="UTF-8" standalone="no" ?>
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" width="0" height="0" viewBox="0 0 500 400" xml:space="preserve">
<desc>Created with Fabric.js 3.6.3</desc>
<defs>
</defs>
<g transform="matrix(2.42 0 0 2.42 249.28720389957257 239.16)"  >
<g style=""   >
		<g transform="matrix(1 0 0 1 18.7675 34.248000000000005)"  >
<path style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-dashoffset: 0; stroke-linejoin: miter; stroke-miterlimit: 4; fill: rgb(255,152,0); fill-rule: nonzero; opacity: 1;"  transform=" translate(-66.2675, -81.748)" d="M 66.268 76.769 c -2.745 0 -4.979 2.233 -4.979 4.979 s 2.233 4.979 4.979 4.979 s 4.978 -2.233 4.978 -4.979 s -2.233 -4.979 -4.978 -4.979 Z m 0 8.957 c -2.193 0 -3.979 -1.785 -3.979 -3.979 s 1.785 -3.979 3.979 -3.979 s 3.978 1.785 3.978 3.979 s -1.784 3.979 -3.978 3.979 Z" stroke-linecap="round" />
</g>
		<g transform="matrix(1 0 0 1 38.24250000000001 2.7825000000000024)"  >
<path style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-dashoffset: 0; stroke-linejoin: miter; stroke-miterlimit: 4; fill: rgb(255,152,0); fill-rule: nonzero; opacity: 1;"  transform=" translate(-85.7425, -50.2825)" d="M 85.742 45.304 c -2.744 0 -4.978 2.233 -4.978 4.978 s 2.233 4.979 4.978 4.979 s 4.979 -2.233 4.979 -4.979 s -2.233 -4.978 -4.979 -4.978 Z m 0 8.956 c -2.193 0 -3.978 -1.785 -3.978 -3.979 s 1.784 -3.978 3.978 -3.978 s 3.979 1.784 3.979 3.978 s -1.785 3.979 -3.979 3.979 Z" stroke-linecap="round" />
</g>
		<g transform="matrix(1 0 0 1 -25.1015 35.875)"  >
<path style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-dashoffset: 0; stroke-linejoin: miter; stroke-miterlimit: 4; fill: rgb(255,152,0); fill-rule: nonzero; opacity: 1;"  transform=" translate(-22.3985, -83.375)" d="M 22.398 79.363 c -2.212 0 -4.011 1.8 -4.011 4.012 s 1.799 4.012 4.011 4.012 s 4.012 -1.8 4.012 -4.012 s -1.8 -4.012 -4.012 -4.012 Z m 0 7.023 c -1.66 0 -3.011 -1.351 -3.011 -3.012 s 1.351 -3.012 3.011 -3.012 s 3.012 1.351 3.012 3.012 s -1.351 3.012 -3.012 3.012 Z" stroke-linecap="round" />
</g>
		<g transform="matrix(1 0 0 1 -19.471999999999998 -31.922)"  >
<path style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-dashoffset: 0; stroke-linejoin: miter; stroke-miterlimit: 4; fill: rgb(255,152,0); fill-rule: nonzero; opacity: 1;"  transform=" translate(-28.028000000000002, -15.578)" d="M 28.028 19.9 c 2.384 0 4.322 -1.938 4.322 -4.322 s -1.938 -4.322 -4.322 -4.322 s -4.322 1.938 -4.322 4.322 s 1.938 4.322 4.322 4.322 Z m 0 -7.645 c 1.832 0 3.322 1.49 3.322 3.322 s -1.49 3.322 -3.322 3.322 s -3.322 -1.49 -3.322 -3.322 s 1.49 -3.322 3.322 -3.322 Z" stroke-linecap="round" />
</g>
		<g transform="matrix(1 0 0 1 -33.428 -3.201999999999998)"  >
<circle style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-dashoffset: 0; stroke-linejoin: miter; stroke-miterlimit: 4; fill: rgb(255,152,0); fill-rule: nonzero; opacity: 1;"  cx="0" cy="0" r="3.512" />
</g>
		<g transform="matrix(1 0 0 1 34.625500000000024 -30.302500000000002)"  >
<path style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-dashoffset: 0; stroke-linejoin: miter; stroke-miterlimit: 4; fill: rgb(255,152,0); fill-rule: nonzero; opacity: 1;"  transform=" translate(-82.12550000000002, -17.1975)" d="M 82.126 19.669 c 1.365 0 2.471 -1.107 2.471 -2.471 s -1.106 -2.472 -2.471 -2.472 s -2.472 1.107 -2.472 2.472 s 1.107 2.471 2.472 2.471 Z" stroke-linecap="round" />
</g>
		<g transform="matrix(1 0 0 1 6.127500000000005 -37.3865)"  >
<path style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-dashoffset: 0; stroke-linejoin: miter; stroke-miterlimit: 4; fill: rgb(255,152,0); fill-rule: nonzero; opacity: 1;"  transform=" translate(-53.627500000000005, -10.113500000000002)" d="M 53.627 12.585 c 1.365 0 2.472 -1.107 2.472 -2.471 s -1.107 -2.472 -2.472 -2.472 s -2.471 1.107 -2.471 2.472 s 1.106 2.471 2.471 2.471 Z" stroke-linecap="round" />
</g>
		<g transform="matrix(1 0 0 1 -1.6165000000000056 36.49350000000002)"  >
<path style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-dashoffset: 0; stroke-linejoin: miter; stroke-miterlimit: 4; fill: rgb(255,152,0); fill-rule: nonzero; opacity: 1;"  transform=" translate(-45.8835, -83.99350000000001)" d="M 45.884 81.522 c -1.365 0 -2.472 1.107 -2.472 2.471 s 1.107 2.472 2.472 2.472 s 2.471 -1.107 2.471 -2.472 s -1.107 -2.471 -2.471 -2.471 Z" stroke-linecap="round" />
</g>
		<g transform="matrix(1 0 0 1 32.155499999999996 21.22350000000001)"  >
<path style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-dashoffset: 0; stroke-linejoin: miter; stroke-miterlimit: 4; fill: rgb(255,152,0); fill-rule: nonzero; opacity: 1;"  transform=" translate(-79.65549999999999, -68.7235)" d="M 79.655 66.252 c -1.365 0 -2.471 1.107 -2.471 2.472 s 1.106 2.471 2.471 2.471 s 2.472 -1.107 2.472 -2.471 s -1.107 -2.472 -2.472 -2.472 Z" stroke-linecap="round" />
</g>
		<g transform="matrix(1 0 0 1 -39.2485 21.22350000000001)"  >
<path style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-dashoffset: 0; stroke-linejoin: miter; stroke-miterlimit: 4; fill: rgb(255,152,0); fill-rule: nonzero; opacity: 1;"  transform=" translate(-8.2515, -68.7235)" d="M 8.251 66.252 c -1.365 0 -2.471 1.107 -2.471 2.472 s 1.106 2.471 2.471 2.471 s 2.472 -1.107 2.472 -2.471 s -1.107 -2.472 -2.472 -2.472 Z" stroke-linecap="round" />
</g>
		<g transform="matrix(1 0 0 1 -13.167500000000004 14.120000000000008)"  >
<path style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-dashoffset: 0; stroke-linejoin: miter; stroke-miterlimit: 4; fill: rgb(255,152,0); fill-rule: nonzero; opacity: 1;"  transform=" translate(-34.332499999999996, -61.620000000000005)" d="M 34.332 45.668 c -8.792 0 -15.944 7.153 -15.944 15.945 c 0 4.94 2.239 9.531 6.145 12.596 c 2.801 2.2 6.19 3.363 9.8 3.363 c 3.581 0 6.969 -1.168 9.798 -3.377 c 3.906 -3.049 6.146 -7.635 6.146 -12.582 c 0 -8.792 -7.152 -15.945 -15.944 -15.945 Z m 9.7 27.285 c -1.626 -3.875 -5.434 -6.432 -9.7 -6.432 s -8.085 2.562 -9.702 6.444 c -3.33 -2.863 -5.243 -6.953 -5.243 -11.352 c 0 -8.241 6.704 -14.945 14.944 -14.945 s 14.944 6.704 14.944 14.945 c 0 4.406 -1.914 8.491 -5.244 11.34 Z" stroke-linecap="round" />
</g>
		<g transform="matrix(1 0 0 1 -13.173500000000004 11.565499999999982)"  >
<path style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-dashoffset: 0; stroke-linejoin: miter; stroke-miterlimit: 4; fill: rgb(255,152,0); fill-rule: nonzero; opacity: 1;"  transform=" translate(-34.326499999999996, -59.065499999999986)" d="M 34.326 53.562 c -3.034 0 -5.503 2.469 -5.503 5.504 s 2.469 5.503 5.503 5.503 s 5.504 -2.469 5.504 -5.503 s -2.469 -5.504 -5.504 -5.504 Z" stroke-linecap="round" />
</g>
		<g transform="matrix(1 0 0 1 15.219000000000001 -14.265)"  >
<path style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-dashoffset: 0; stroke-linejoin: miter; stroke-miterlimit: 4; fill: rgb(255,152,0); fill-rule: nonzero; opacity: 1;"  transform=" translate(-62.719, -33.235)" d="M 62.718 17.283 c -8.792 0 -15.944 7.152 -15.944 15.944 c 0 4.94 2.239 9.532 6.145 12.597 c 2.804 2.2 6.192 3.363 9.8 3.363 c 3.581 0 6.969 -1.168 9.799 -3.377 c 3.905 -3.05 6.146 -7.636 6.146 -12.583 c 0 -8.792 -7.152 -15.944 -15.944 -15.944 Z m 9.701 27.285 c -1.627 -3.875 -5.435 -6.432 -9.701 -6.432 s -8.085 2.562 -9.702 6.444 c -3.33 -2.863 -5.243 -6.953 -5.243 -11.353 c 0 -8.24 6.704 -14.944 14.944 -14.944 s 14.944 6.704 14.944 14.944 c 0 4.407 -1.914 8.492 -5.243 11.341 Z" stroke-linecap="round" />
</g>
		<g transform="matrix(1 0 0 1 15.212500000000006 -16.820500000000003)"  >
<path style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-dashoffset: 0; stroke-linejoin: miter; stroke-miterlimit: 4; fill: rgb(255,152,0); fill-rule: nonzero; opacity: 1;"  transform=" translate(-62.712500000000006, -30.679499999999997)" d="M 62.712 25.176 c -3.034 0 -5.503 2.469 -5.503 5.503 s 2.469 5.504 5.503 5.504 s 5.504 -2.469 5.504 -5.504 s -2.469 -5.503 -5.504 -5.503 Z" stroke-linecap="round" />
</g>
		<g transform="matrix(1 0 0 1 -12.25 -13.337000000000003)"  >
<path style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-dashoffset: 0; stroke-linejoin: miter; stroke-miterlimit: 4; fill: rgb(255,152,0); fill-rule: nonzero; opacity: 1;"  transform=" translate(-35.25, -34.163)" d="M 24.116 44.797 c 0 0.276 0.224 0.5 0.5 0.5 s 0.5 -0.224 0.5 -0.5 c 0 -5.548 2.16 -10.764 6.082 -14.686 c 3.923 -3.922 9.139 -6.082 14.686 -6.082 c 0.276 0 0.5 -0.224 0.5 -0.5 s -0.224 -0.5 -0.5 -0.5 c -5.814 0 -11.28 2.264 -15.393 6.375 c -4.111 4.111 -6.375 9.577 -6.375 15.393 Z" stroke-linecap="round" />
</g>
		<g transform="matrix(1 0 0 1 14.288999999999998 13.202999999999989)"  >
<path style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-dashoffset: 0; stroke-linejoin: miter; stroke-miterlimit: 4; fill: rgb(255,152,0); fill-rule: nonzero; opacity: 1;"  transform=" translate(-61.789, -60.70299999999999)" d="M 72.423 49.569 c -0.276 0 -0.5 0.224 -0.5 0.5 c 0 5.547 -2.16 10.763 -6.082 14.686 c -3.922 3.922 -9.138 6.082 -14.686 6.082 c -0.276 0 -0.5 0.224 -0.5 0.5 s 0.224 0.5 0.5 0.5 c 5.815 0 11.281 -2.264 15.393 -6.375 c 4.111 -4.112 6.375 -9.578 6.375 -15.393 c 0 -0.276 -0.224 -0.5 -0.5 -0.5 Z" stroke-linecap="round" />
</g>
</g>
</g>
<g transform="matrix(0.8 0 0 0.8000000000000002 249.96000000000004 329.3916599986961)"  >
<path style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-dashoffset: 0; stroke-linejoin: miter; stroke-miterlimit: 4; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;"  transform=" translate(-249.95000000000002, -250)" d="M 76.9 288.8 h 346.2 c 21.4 0 38.8 -17.4 38.8 -38.8 v 0 c 0 -21.4 -17.4 -38.8 -38.8 -38.8 H 76.9 C 55.4 211.2 38 228.6 38 250 v 0 C 38 271.4 55.4 288.8 76.9 288.8 z" stroke-linecap="round" />
</g>
<g transform="matrix(1 0 0 1 244.36352737855333 331.3703825700893)" style=""  ><path fill="#000000" opacity="1" d=""/><path fill="#000000" opacity="1" d="M-106.66-10.38L-101.93-10.38L-101.93-9.21L-110.63 9.16L-115.88 9.16L-124.57-9.21L-124.57-10.38L-119.84-10.38L-113.25 4.50L-106.66-10.38Z"/><path fill="#000000" opacity="1" d="M-88.11 9.16L-88.11 1.90L-95.75-9.21L-95.75-10.38L-90.59-10.38L-85.49-2.27L-80.35-10.38L-75.22-10.38L-75.22-9.21L-82.86 1.90L-82.86 9.16L-88.11 9.16Z"/><path fill="#000000" opacity="1" d="M-68.28 9.16L-73.00 9.16L-73.00 8.00L-64.31-10.38L-59.06-10.38L-50.37 8.00L-50.37 9.16L-55.09 9.16L-56.79 5.37L-66.61 5.37L-68.28 9.16ZM-64.66 1.00L-58.71 1.00L-61.69-5.68L-64.66 1.00Z"/><path fill="#000000" opacity="1" d="M-23.71-3.96L-23.71-2.80Q-23.71-1.34-24.08-0.07Q-24.44 1.20-25.32 2.15Q-26.19 3.10-27.69 3.65Q-29.20 4.20-31.47 4.20L-31.47 4.20L-32.29 4.20Q-33.86 4.20-35.36 4.17Q-36.87 4.15-38.29 3.91L-38.29 3.91L-38.29 9.16L-43.54 9.16L-43.54-10.38Q-41.04-10.67-38.28-10.82Q-35.52-10.96-32.87-10.96L-32.87-10.96L-32.05-10.96Q-29.60-10.96-28.00-10.41Q-26.40-9.85-25.43-8.91Q-24.47-7.96-24.09-6.67Q-23.71-5.39-23.71-3.96L-23.71-3.96ZM-33.10-0.46L-33.10-0.46Q-31.56-0.46-30.71-0.68Q-29.87-0.90-29.47-1.29Q-29.08-1.69-29.02-2.21Q-28.96-2.74-28.96-3.38L-28.96-3.38Q-28.96-4.02-29.02-4.56Q-29.08-5.10-29.46-5.48Q-29.84-5.86-30.62-6.08Q-31.41-6.30-32.90-6.30L-32.90-6.30Q-33.83-6.30-35.33-6.24Q-36.84-6.18-38.29-6.03L-38.29-6.03L-38.29-0.73Q-36.92-0.55-35.70-0.51Q-34.47-0.46-33.10-0.46Z"/><path fill="#000000" opacity="1" d="M-14.55 9.16L-19.28 9.16L-19.28 8.00L-10.59-10.38L-5.34-10.38L3.35 8.00L3.35 9.16L-1.37 9.16L-3.06 5.37L-12.89 5.37L-14.55 9.16ZM-10.94 1.00L-4.99 1.00L-7.96-5.68L-10.94 1.00Z"/><path fill="#000000" opacity="1" d="M30.30 9.16L25.23 9.16L21.32 3.04Q19.75 3.04 18.29 3.01Q16.83 2.98 15.43 2.75L15.43 2.75L15.43 9.16L10.18 9.16L10.18-10.38Q12.69-10.67 15.44-10.82Q18.20-10.96 20.85-10.96L20.85-10.96L21.67-10.96Q24.12-10.96 25.72-10.45Q27.33-9.94 28.29-9.07Q29.25-8.19 29.63-7.02Q30.01-5.86 30.01-4.55L30.01-4.55L30.01-3.38Q30.01-1.54 29.28-0.04Q28.55 1.46 26.69 2.28L26.69 2.28L30.30 8.00L30.30 9.16ZM20.91-6.30L20.91-6.30Q19.89-6.30 18.39-6.24Q16.89-6.18 15.43-6.03L15.43-6.03L15.43-1.89Q16.80-1.72 18.02-1.67Q19.25-1.63 20.01-1.63L20.01-1.63Q21.76-1.63 22.72-1.79Q23.68-1.95 24.13-2.27Q24.59-2.59 24.67-3.09Q24.76-3.58 24.76-4.28L24.76-4.28Q24.76-4.66 24.70-5.03Q24.65-5.39 24.28-5.68Q23.92-5.97 23.13-6.14Q22.34-6.30 20.91-6.30Z"/><path fill="#000000" opacity="1" d=""/><path fill="#000000" opacity="1" d="M67.61 9.16L48.91 9.16L48.91-10.38L54.16-10.38L54.16 4.50L67.61 4.50L67.61 9.16Z"/><path fill="#000000" opacity="1" d="M74.84-10.38L80.09-10.38L80.09 9.16L74.84 9.16L74.84-10.38Z"/><path fill="#000000" opacity="1" d="M104.82-10.38L109.55-10.38L109.55-9.21L100.86 9.16L95.61 9.16L86.91-9.21L86.91-10.38L91.64-10.38L98.23 4.50L104.82-10.38Z"/><path fill="#000000" opacity="1" d="M135.07-10.38L135.07-5.71L121.62-5.71L121.62-2.80L132.15-2.80L132.15 1.87L121.62 1.87L121.62 4.50L135.07 4.50L135.07 9.16L116.37 9.16L116.37-10.38L135.07-10.38Z"/><text
  x="140"
  y="-2"
  font-size="24"
  font-weight="bold"
  fill="#000"
>
  ™
</text>
</g><g transform="matrix(0.93 0 0 -1.42 249.57596833807344 358.95905967706966)">
<path style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-dashoffset: 0; stroke-linejoin: miter; stroke-miterlimit: 4; fill: rgb(255,152,0); fill-rule: nonzero; opacity: 1;"  transform=" translate(-49.95, -50)" d="M 91.7 49 H 8.3 c -0.6 0 -1 0.4 -1 1 s 0.4 1 1 1 h 83.3 c 0.6 0 1 -0.4 1 -1 S 92.2 49 91.7 49 z" stroke-linecap="round" />
</g>

</svg>
''';
}
