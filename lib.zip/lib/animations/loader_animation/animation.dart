import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';

class Palse extends StatelessWidget {
  const Palse({
    Key? key,
    required ValueNotifier<bool> loading,
  })  : _loading = loading,
        super(key: key);

  final ValueNotifier<bool> _loading;
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder(
      valueListenable: _loading,
      builder: (BuildContext context, bool value, Widget? child) {
        return SpinKitDualRing(
          color: Colors.black,
          size: 40.0,
          lineWidth: 3,
        );
      },
    );
  }
}
// class SpinKitDemo extends StatelessWidget {
//   const SpinKitDemo({
//     Key? key,
//     required ValueNotifier<bool> loading,
//   })  : _loading = loading,
//         super(key: key);

//   final ValueNotifier<bool> _loading;
//   @override
//   Widget build(BuildContext context) {
//     return ValueListenableBuilder(
//       valueListenable: _loading,
//       builder: (BuildContext context, bool value, Widget? child) {
//         return SpinKitFadingCircle(
//           color: Colors.white,
//           size: 50.0,
//         );
//       },
//     );
//   }
// }
