import 'package:vyaparlive/components/DateFilterUtil.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/model/BuListModel.dart';
import 'package:vyaparlive/model/Contacts.dart';
import 'package:vyaparlive/model/quotations/QuotationsModel.dart';
import 'package:vyaparlive/quotation/QuotationDesingView.dart';
import 'package:vyaparlive/quotation/QuotationView.dart';
import 'package:vyaparlive/service/invitation_services.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:vyaparlive/utills/animation/list_loader/ListLoader.dart';
import 'package:custom_searchable_dropdown/custom_searchable_dropdown.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:flutx/flutx.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/TransactionsModel.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:vyaparlive/service/Service.dart';
import 'package:vyaparlive/service/bu_list_grpc_service.dart';

class SentQuotationsView extends StatefulWidget {
  final String? buId;
  final String? params;
  final String? connectionBuId;
  final bool isFromConnection;
  final bool isFromInternalBu;
  final bool isFromOfflineConnections;
  final QuotationsTabController controller;
  SentQuotationsView(
      {this.buId,
      this.params,
      this.connectionBuId,
      this.isFromConnection = false,
      this.isFromInternalBu = false,
      this.isFromOfflineConnections = false,
      required  this.controller,});
  @override
  _SentQuotationsViewState createState() => _SentQuotationsViewState();
}

class _SentQuotationsViewState extends State<SentQuotationsView>
    with TickerProviderStateMixin {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  List<QuotationsModel> _transactionsList = [];
  List<QuotationsModel> _resTransactionsList = [];

  bool isForRefresh = false;
  String? radioButtonValue = "";
  static const String OFFLINE = "Offline";
  static const String ONLINE = "Online";
  String? rawMaterialTransactionRadioValue;
  String? actualTransactionRadioValue = Constants.SALABLE_PRODUCTS;
  late Service _service;
  DateFormat formatter = DateFormat("yyyy-MM-dd");
  String? _buId = "";
  String? transactionName = "";
  String? transactionStatus = "";
  String transactionDate = "";
  String status = "";
  TextEditingController _searchController = TextEditingController();
  DateTime selectedDate = DateTime.now();
  final fromDateController = TextEditingController();
  final toDateController = TextEditingController();
  final double calendarHeight = 40.0;
  List<BuListModel> _buList = [];
  BuListModel? offlineBuDropdownvalue;
  List<Contacts> _contactsModel = [];
  Contacts? connectionName;
  // ProgressDialog progressDialog;
  String formatedUserDob = "";
  bool isShowFloatButton = false;
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_BUY_TRANSACTIONS;
  String showLoaderText = Constants.NO_DATA_FOUND;
  String params = "";
  late BuListGrpcService _transactionService;
  bool isSearchParam = false;
  ScrollController? _scrollController;
  late ThemeData theme;
  String selectedConnectionName = "";
  late InvitationService _invitationService;
  bool isLoading = false;
  late AnimationController _animationController;
  late TextEditingController statusTypeController = new TextEditingController();
  DateTime mnthStartDate =
      DateTime.utc(DateTime.now().year, DateTime.now().month, 1);
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    widget.controller.refresh = refresh;
    _scrollController = new ScrollController();
    initBottomSheetAnimation();
    _service = Service();
    _transactionService = BuListGrpcService();
    _buId = widget.buId;
    _invitationService = new InvitationService();
    radioButtonValue = ONLINE;
    fromDateController.text = formatter.format(mnthStartDate);
    toDateController.text = formatter.format(DateTime.now());
    serviceCalls();
  }

  void refresh() {
    serviceCalls();
  }

  initBottomSheetAnimation() {
    _animationController = BottomSheet.createAnimationController(this);
    _animationController.duration =
        const Duration(milliseconds: Constants.bottomSheet_duration);
    _animationController.reverseDuration =
        const Duration(milliseconds: Constants.bottomSheet_reverse_duration);
    _animationController.drive(CurveTween(curve: Curves.easeIn));
  }

  serviceCalls() async {
    if (widget.isFromConnection ||
        widget.isFromInternalBu ||
        widget.isFromOfflineConnections) {
      _searchController.text = widget.params!;
      loadTransactionsData(name: widget.params);
    } else {
      params = "";
      loadTransactionsData();
    }
  }

  loadOfflineBulistData(String params) async {
    if (await NetworkStatus.getInternetStatus()) {
      this.getAllOfflineContacts(params).then((value) {
        setState(() {
          _buList.clear();
          _buList.addAll(value);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<BuListModel>> getAllOfflineContacts(String params) async {
    setState(() {
      isLoading = true;
    });

    String body = json.encode({"buId": widget.buId, "filters": {}});

    var response = await _invitationService
        .getContactsByBuId_grpc(
            body, AppController.instance.getAuthorizationKey, params)
        .catchError((onError) async {
      print("GET CONTACTS ERROR: $onError");
      setState(() {
        isLoading = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    setState(() {
      isLoading = false;
    });
    List<BuListModel> _list = [];
    GRPCResponse data = response;
    if (!data.getIsError! && !data.getIsException!) {
      var resBody = json.decode(data.message!);
      var resultArray = resBody['results'];
      for (var object in resultArray) {
        _list.add(BuListModel.fromJson(object));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          data.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }

    return _list;
  }

  loadConnectionsData() async {
    if (await NetworkStatus.getInternetStatus()) {
      this.getContacts(widget.buId).then((onValue) {
        setState(() {
          _contactsModel.clear();
          _contactsModel.addAll(onValue);
          if (_contactsModel.length > 0) {
            for (int i = 0; i < _contactsModel.length; i++) {
              if (AppController.instance.getConnectionName ==
                  _contactsModel[i].buId) {
                connectionName = _contactsModel[i];
              }
            }
          }
          filterBottomPopup(context);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<Contacts>> getContacts(String? buId) async {
    setState(() {
      _contactsModel.clear();
      isLoading = true;
    });
    String body = json.encode({"buId": buId, "filters": {}});

    var response = await _invitationService
        .findAllConnections_grpc(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoading = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<Contacts> _model = [];
    setState(() {
      isLoading = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);

      for (var noteJson in resObj['results']) {
        _model.add(Contacts.fromJson(noteJson));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    return _model;
  }

  loadTransactionsData(
      {String? name = "",
      String? status = "",
      String? fromDate = "",
      String? toDate = "",
      bool? isOffline = false,
      String? transactionType = ""}) async {
    if (await NetworkStatus.getInternetStatus()) {
      if (!isSearchParam) {
        setState(() {
          isLoadingProgress = true;
        });
      }

      _getAllQuotations(
              name: name,
              status: status,
              fromDate: fromDate,
              toDate: toDate,
              isOffline: isOffline,
              transactionType: transactionType)
          .then((onValue) {
        setState(() {
          _resTransactionsList.addAll(onValue);
          if (_resTransactionsList.length > 0) {
            for (int i = 0; i < _resTransactionsList.length; i++) {
              if (_resTransactionsList[i].seller!.id == _buId) {
                _transactionsList.add(_resTransactionsList[i]);
              } else {
                showLoaderText = Constants.NO_DATA_FOUND;
              }
            }

            // _transactionsList = _transactionsList.reversed.toList();
          } else {
            showLoaderText = Constants.NO_DATA_FOUND;
          }
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<QuotationsModel>> _getAllQuotations(
      {String? name = "",
      String? status = "",
      String? fromDate = "",
      String? toDate = "",
      bool? isOffline = false,
      String? transactionType = ""}) async {
    // setState(() {
    _transactionsList.clear();
    _resTransactionsList.clear();
    // });

    // String body = json.encode({
    //   "filters": {
    //     "buId": _buId
    //     // "DateFrom": fromDateController.text,
    //     // "DateTo": toDateController.text,
    //   }
    // });

    String body = json.encode({
      "bu": _buId,
      "filters": {
        "DateFrom": fromDateController.text,
        "DateTo": toDateController.text,
      }
    });

    var response = await _transactionService
        .getSentQuotations_v1(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<QuotationsModel> _list = [];

    setState(() {
      isForRefresh = true;
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(resObj)) {
        var resultArray = resObj;
        for (var i in resultArray) {
          _list.add(QuotationsModel.fromJson(i));
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }

    return _list;
  }

  Future<List<TransactionsModel>> getConnectionHistrory(String param) async {
    setState(() {
      isLoadingProgress = true;
    });
    http.Response response = await _service.getConnectionTransactionHistory(
        _buId, widget.connectionBuId, params);
    List<TransactionsModel> _list = [];

    isForRefresh = true;
    setState(() {
      isLoadingProgress = false;
    });
    if (response.statusCode == 200) {
      final object = json.decode(response.body);
      bool isString = false;
      if (object['data'] is String) {
        isString = true;
      }

      if (!isString) {
        var resultArray = object['data']['results'];
        for (var i in resultArray) {
          _list.add(TransactionsModel.fromJson(i));
        }
      }
    } else if (response.statusCode == 401) {
      CommonMethods.handleUnauthorizedAccess(context);
    } else {
      final object = json.decode(response.body);
      String? messgae = object['message'];

      Future.delayed(Duration.zero).then((value) {
        Dialogs.yesCancelDialog(
            context,
            Language().getString(Constants.ERROR, selectedLang),
            messgae,
            Language().getString(Constants.OKAY_STR, selectedLang),
            "",
            false);
      });
    }
    return _list;
  }

  buildSearchBarView() {
    return Card(
      elevation: 2.0,
      shadowColor: theme.colorScheme.primary,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(5.0),
          side:
              BorderSide(color: theme.colorScheme.primary, strokeAlign: 0.01)),
      child: Row(
        children: <Widget>[
          Expanded(
              flex: 5,
              child: Row(
                children: <Widget>[
                  Expanded(
                    flex: 5,
                    child: Container(
                      padding: EdgeInsets.only(left: 15),
                      child: TextFormField(
                        controller: _searchController,
                        onChanged: onSearchTextChanged,
                        style: TextStyle(fontWeight: StyleView.fontSemiBold),
                        decoration: InputDecoration(
                            border: InputBorder.none,
                            hintText: Language().getString(
                                Constants.SEARCH_BY_BUSINESS, selectedLang),
                            hintStyle: TextStyle(
                                fontSize: 13.0,
                                fontWeight: StyleView.fontSemiBold)),
                      ),
                    ),
                  ),
                  if (_searchController.text.isNotEmpty)
                    Container(
                        color: Colors.white,
                        child: IconButton(
                            icon: Icon(
                              Icons.close,
                              color: Colors.red,
                              size: 20.0,
                            ),
                            onPressed: () {
                              setState(() {
                                CommonMethods.hideKeyboard(context);
                                renderClearFiltersData();
                                isShowFloatButton = false;
                                onSearchTextChanged(_searchController.text);
                              });
                            }))
                ],
              )),
          Container(
            color: Colors.grey,
          ),
          Expanded(
              child: Container(
                  margin: EdgeInsets.only(left: 2),
                  padding: EdgeInsets.only(left: 5),
                  child: IconButton(
                      icon: Icon(Icons.filter_list),
                      onPressed: () async {
                        CommonMethods.hideKeyboard(context);
                        if (_contactsModel.length == 0) {
                          await loadConnectionsData();
                        } else {
                          filterBottomPopup(context);
                        }
                      })))
        ],
      ),
    );
  }

  onSearchTextChanged(String text) async {
    showLoaderText = Constants.LOADING;
    if (text.isEmpty) {
      isSearchParam = false;
      loadTransactionsData();
    } else {
      isSearchParam = true;
      // String param = "?name=$text";
      loadTransactionsData(name: text);
    }
  }

  void renderClearFiltersData() {
    _searchController.clear();
    fromDateController.text = formatter.format(mnthStartDate);
    toDateController.text = formatter.format(DateTime.now());
    connectionName = null;
    offlineBuDropdownvalue = null;
    statusTypeController.clear();
  }

  Widget _listViewData() {
    if (isLoadingProgress) {
      return Expanded(child: ListLoader());
    } else if (!isLoadingProgress && _transactionsList.length == 0) {
      return Expanded(
          child: Center(
        child: new Text(Language().getString(showLoaderText, selectedLang)),
      ));
    } else {
      return Expanded(
        child: Container(
            child: AnimationLimiter(
          child: ListView.separated(
            controller: _scrollController,
            physics: const BouncingScrollPhysics(
                parent: AlwaysScrollableScrollPhysics()),
            shrinkWrap: true,
            separatorBuilder: (context, index) => Divider(
              height: 5.0,
              color: Colors.transparent,
            ),
            itemBuilder: (BuildContext ctxt, int index) {
              return AnimationConfiguration.staggeredList(
                position: index,
                // duration: Duration(milliseconds: 500),
                child: SlideAnimation(
                  verticalOffset: 50.0,
                  child: FadeInAnimation(
                    child: Stack(
                      children: [
                        InkWell(
                            onTap: () {
                              CommonMethods.hideKeyboard(context);
                              Navigator.push(
                                context,
                                PageTransition(
                                  context: context,
                                  page: QuotationDesingPage(
                                    invoiceNo: _transactionsList[index].quotationNo,
                                    transactionName:
                                        _transactionsList[index].buyer!.isOffline!?_transactionsList[index].buyer!.name:_transactionsList[index].buyer!.businessName,
                                    transactionId: _transactionsList[index].id,
                                    transactionDate: _transactionsList[index]
                                        .transactionDate
                                        .toString(),
                                    buyerName:
                                        _transactionsList[index].buyer!.name,
                                    sellerName:
                                        _transactionsList[index].seller!.name,
                                    invoiceId: _transactionsList[index].id,
                                  ),
                                ),
                              );
                            },
                            child: Container(child: listRow(index))),
                      ],
                    ),
                  ),
                ),
              );
            },
            itemCount: _transactionsList.length,
          ),
        )),
      );
    }
  }

  Widget showRadiobuttonsView(StateSetter setState) {
    return Row(children: [
      Container(
        child: Row(
          children: [
            Radio(
              value: OFFLINE,
              activeColor: Color(Constants.APP_COLOR),
              groupValue: radioButtonValue,
              onChanged: (dynamic value) {
                renderClearFiltersData();
                setState(() {
                  radioButtonValue = OFFLINE;
                  rawMaterialTransactionRadioValue = null;
                  actualTransactionRadioValue = Constants.SALABLE_PRODUCTS;
                });
                if (_buList.length == 0) {
                  loadOfflineBulistData("");
                } else {
                  // setState(() {
                  radioButtonValue = value;
                  rawMaterialTransactionRadioValue = null;
                  actualTransactionRadioValue = Constants.SALABLE_PRODUCTS;
                  // });
                  Future.delayed(Duration(seconds: 1))
                      .then((value) => setState(() {
                            isLoadingProgress = false;
                          }));
                }
              },
            ),
            Text(
              Language().getString(OFFLINE, selectedLang),
              style: TextStyle(fontWeight: StyleView.fontSemiBold),
            ),
          ],
        ),
      ),
      Container(
        child: Row(
          children: [
            Radio(
              value: ONLINE,
              activeColor: Color(Constants.APP_COLOR),
              groupValue: radioButtonValue,
              onChanged: (dynamic value) {
                this.renderClearFiltersData();
                setState(() {
                  radioButtonValue = OFFLINE;
                  rawMaterialTransactionRadioValue = null;
                  actualTransactionRadioValue = Constants.SALABLE_PRODUCTS;
                });
                radioButtonValue = value;
                isLoadingProgress = true;
                rawMaterialTransactionRadioValue = null;
                actualTransactionRadioValue = Constants.SALABLE_PRODUCTS;
              },
            ),
            Text(
              Language().getString(ONLINE, selectedLang),
              style: TextStyle(fontWeight: StyleView.fontSemiBold),
            ),
          ],
        ),
      ),
    ]);
  }

  dateFilterView() {
    return DateFilterUtill(
      isShowSearchButton: true,
      onFromDateSelected: (value) => fromDateController.text = value,
      onToDateSelected: (value) => toDateController.text = value,
      fromDateController: fromDateController,
      toDateController: toDateController,
      onSearchParms: () {
        Map data = {
          "status": statusTypeController.text,
          "DateFrom": fromDateController.text,
          "DateTo": toDateController.text,
          "name":
              widget.isFromConnection ? widget.params : selectedConnectionName,
          "offline": radioButtonValue == OFFLINE ? true : false,
          "transaction_type": rawMaterialTransactionRadioValue != null
              ? Constants.KEY_RAW_MATERIAL
              : ""
        };
        setState(() {
          isLoadingProgress = true;
        });
        loadTransactionsData(
            status: data['status'],
            fromDate: data['DateFrom'],
            toDate: data['DateTo'],
            name: data['name'],
            isOffline: data['offline'],
            transactionType: data['transaction_type']);
      },
    );
  }

  showConnectionsList() {
    return Container(
        margin: EdgeInsets.symmetric(vertical: 10.0),
        decoration: AppUtills.boxDecoration(),
        child: CustomSearchableDropDown(
          items: _contactsModel.toList(),
          label: connectionName == null
              ? Language().getString(
                  Constants.PLEASE_SELECT_BUSSINESS_UNIT, selectedLang)
              : connectionName!.buName,
          dropdownItemStyle: TextStyle(color: Colors.black),
          labelStyle: TextStyle(
              fontWeight: StyleView.fontMedium,
              color: Colors.black,
              fontSize: 14.0),
          suffixIcon: Padding(
            padding: const EdgeInsets.all(0.0),
            child: Icon(Icons.search),
          ),
          dropDownMenuItems: _contactsModel.map((item) {
            return item.buName;
          }).toList(),
          onChanged: (value) {
            if (value != null) {
              // setState(() {
              connectionName = value;
              _searchController.text = value.buName;
              selectedConnectionName = connectionName!.buName!;
              // });
            }
          },
        ));
  }

  showOfflineBulist() {
    return Container(
        margin: EdgeInsets.symmetric(vertical: 10.0),
        decoration: AppUtills.boxDecoration(),
        child: CustomSearchableDropDown(
          items: _buList.toList(),
          label: offlineBuDropdownvalue == null
              ? Language()
                  .getString(Constants.PLEASE_SELECT_CONNECTION, selectedLang)
              : offlineBuDropdownvalue!.name,
          labelStyle:
              TextStyle(fontWeight: StyleView.fontSemiBold, fontSize: 14.0),
          suffixIcon: Padding(
            padding: const EdgeInsets.all(0.0),
            child: Icon(Icons.search),
          ),
          dropDownMenuItems: _buList.map((item) {
            return item.name;
          }).toList(),
          onChanged: (value) {
            if (value != null) {
              // setState(() {
              offlineBuDropdownvalue = value;
              _searchController.text = value.buName;
              selectedConnectionName = offlineBuDropdownvalue!.name!;
              // });
            }
          },
        ));
  }

  showTransactionStatus() {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 5.0),
      decoration: AppUtills.boxDecoration(),
      child: CustomSearchableDropDown(
        items: Constants.transactionsStatusList.toList(),
        label: Language()
            .getString(Constants.SEARCH_BY_TRANSACTION_STATUS, selectedLang),
        labelStyle:
            TextStyle(fontWeight: StyleView.fontSemiBold, fontSize: 14.0),
        suffixIcon: Padding(
          padding: const EdgeInsets.all(0.0),
          child: Icon(Icons.search),
        ),
        dropDownMenuItems: Constants.transactionsStatusList.map((item) {
          return item;
        }).toList(),
        dropdownItemStyle: TextStyle(fontWeight: StyleView.fontMedium),
        onChanged: (value) {
          // setState(() {
          statusTypeController.text = value;
          // });
        },
      ),
    );
  }

  Widget showTransactionTypeView(StateSetter setState) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 5.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
              child: Text(
            Language().getString(Constants.TRANSACTION_TYPE, selectedLang),
            style: TextStyle(
                color: Colors.black, fontWeight: StyleView.fontSemiBold),
          )),
          Container(
            child: Row(
              children: [
                Row(
                  children: [
                    Radio(
                      value: Constants.KEY_RAW_MATERIAL,
                      activeColor: Color(Constants.APP_COLOR),
                      groupValue: rawMaterialTransactionRadioValue,
                      onChanged: (dynamic value) {
                        setState(() {
                          rawMaterialTransactionRadioValue = value;
                          actualTransactionRadioValue = null;
                        });
                      },
                    ),
                    Text(
                      Language()
                          .getString(Constants.RAW_MATERIALS, selectedLang),
                      style: TextStyle(fontWeight: StyleView.fontSemiBold),
                    ),
                  ],
                ),
                Row(
                  children: [
                    Radio(
                      value: Constants.SALABLE_PRODUCTS,
                      activeColor: Color(Constants.APP_COLOR),
                      groupValue: actualTransactionRadioValue,
                      onChanged: (dynamic value) {
                        // setState(() {
                        actualTransactionRadioValue = value;
                        rawMaterialTransactionRadioValue = null;
                        // });
                      },
                    ),
                    Text(
                      Language()
                          .getString(Constants.SALABLE_PRODUCTS, selectedLang),
                      style: TextStyle(fontWeight: StyleView.fontSemiBold),
                    ),
                  ],
                )
              ],
            ),
          )
        ],
      ),
    );
  }

  void filterBottomPopup(context) {
    showModalBottomSheet(
        transitionAnimationController: _animationController,
        isScrollControlled: true,
        backgroundColor: Colors.white,
        barrierColor: Colors.black54,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20.0),
                topRight: Radius.circular(20.0))),
        context: context,
        builder: (BuildContext buildContext) {
          return StatefulBuilder(
            builder: (BuildContext context,
                void Function(void Function()) setState) {
              return Padding(
                padding: const EdgeInsets.all(8.0),
                child: ListView(
                  shrinkWrap: true,
                  children: [
                    Column(children: [
                      Container(
                        width: MediaQuery.of(context).size.width * 0.25,
                        height: 3,
                        color: Colors.grey,
                      ),
                      showRadiobuttonsView(setState),
                      // dateFilterView(),
                      FxSpacing.height(5.0),
                      (radioButtonValue == OFFLINE)
                          ? this.showOfflineBulist()
                          : this.showConnectionsList(),
                      FxSpacing.height(10.0),
                    ]),
                    FxSpacing.height(10.0),
                    Container(
                      padding: EdgeInsets.only(bottom: 10),
                      child: CommonButtonsView(
                        context: context,
                        b1Text: Language()
                            .getString(Constants.STR_CANCEL, selectedLang),
                        b2Text: Language()
                            .getString(Constants.APPLY_FILTER, selectedLang),
                        onb1Action: () => {Navigator.of(context).pop()},
                        onb2Action: () {
                          Map data = {
                            "status": statusTypeController.text,
                            "DateFrom": fromDateController.text,
                            "DateTo": toDateController.text,
                            "name": widget.isFromConnection
                                ? widget.params
                                : selectedConnectionName,
                            "offline":
                                radioButtonValue == OFFLINE ? true : false,
                            "transaction_type":
                                rawMaterialTransactionRadioValue != null
                                    ? Constants.KEY_RAW_MATERIAL
                                    : ""
                          };
                          Navigator.of(context).pop();
                          setState(() {
                            isLoadingProgress = true;
                            isShowFloatButton = true;
                          });
                          loadTransactionsData(
                              status: data['status'],
                              fromDate: data['DateFrom'],
                              toDate: data['DateTo'],
                              name: data['name'],
                              isOffline: data['offline'],
                              transactionType: data['transaction_type']);
                        },
                      ),
                    )
                  ],
                ),
              );
            },
          );
        });
  }

  @override
  void dispose() {
    this.renderClearFiltersData();
    _scrollController!.dispose();
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        SafeArea(
          child: Scaffold(
            key: _scaffoldkey,
            floatingActionButton: (isShowFloatButton)
                ? FloatingActionButton(
                    backgroundColor: theme.colorScheme.primary,
                    onPressed: () {
                      // progressDialog.show();
                      isLoadingProgress = true;
                      setState(() {
                        isShowFloatButton = false;
                        if (!widget.isFromConnection ||
                            !widget.isFromInternalBu ||
                            !widget.isFromOfflineConnections) {
                          _searchController.clear();
                        }
                      });
                      renderClearFiltersData();
                      loadTransactionsData();
                    },
                    child: Text(
                      Language().getString(Constants.CLEAR_FILTERS, selectedLang),
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 10.0,
                        fontWeight: StyleView.fontMedium,
                      ),
                    ),
                  )
                : null,
            backgroundColor: Colors.transparent,
            body: Container(
                margin: EdgeInsets.only(right: 5),
                child: Card(
                  elevation: 20,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.only(
                          topRight: Radius.circular(10.0),
                          bottomRight: Radius.circular(10.0))),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      children: <Widget>[
                        Container(height: 60, child: buildSearchBarView()),
                        Container(
                          child: dateFilterView(),
                          margin:
                              EdgeInsets.symmetric(horizontal: 4, vertical: 3),
                        ),
                        _listViewData()
                      ],
                    ),
                  ),
                )),
          ),
        ),
      ],
    );
  }

  listRow(int index) {
    if (_transactionsList[index].seller!.id == _buId) {
      transactionName = _transactionsList[index].buyer!.isOffline!?_transactionsList[index].buyer!.name:_transactionsList[index].buyer!.businessName;
    }

    return Card(
      elevation: 2.5,
      color: Colors.white,
      shadowColor: AppTheme.theme.colorScheme.primary, //Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(5),
        // side: BorderSide(color: AppTheme.theme.colorScheme.primary)
      ),
      child: Container(
        padding: EdgeInsets.only(left: 10.0, top: 8.0, bottom: 8.0),
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                "$transactionName",
                style: TextStyle(
                    color: AppTheme.theme.colorScheme
                        .primary, //Color(Constants.APP_COLOR),
                    fontSize: 15.0,
                    fontWeight: StyleView.fontSemiBold),
              ),
              FxSpacing.height(3.0),
              Text(
                "${_transactionsList[index].quotation_details!.products!.length} items | Total: ${CommonMethods.getCurrencyValues(_transactionsList[index].quotation_details!.total_price)}",
                style: TextStyle(
                    color: Color(0xFF282828), //Color(Constants.APP_COLOR),
                    fontSize: 12.5,
                    fontWeight: StyleView.fontMedium),
              ),
              FxSpacing.height(5.0),
              Row(
                children: [
                  Icon(Icons.date_range_sharp,
                      size: 15.0,
                      color: CommonMethods.transactionStatusColorHandling(
                          status) //Color(0xFF282828),
                      ),
                  FxSpacing.width(3.0),
                  Text(
                    AppUtills.getISTTime(
                        _transactionsList[index].transactionDate.toString()),
                    style: TextStyle(
                        color: Color(0xFF282828), //Color(Constants.APP_COLOR),
                        fontSize: 12.5,
                        fontWeight: StyleView.fontMedium),
                  ),
                ],
              ),
            ]),
      ),
    );
  }
}
