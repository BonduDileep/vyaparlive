import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/core/enums/privilleges_enum.dart';
import 'package:vyaparlive/quotation/ReceivedQuotationsPage.dart';
import 'package:vyaparlive/quotation/SentQuotationsPage.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Transaction/buyer/BuyTransactionsPage.dart';
import 'package:vyaparlive/Transaction/seller/SellTransactionsPage.dart';
import 'package:vyaparlive/Transaction/direcr_order_view/DirectOrderPage.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/MyDrawer.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/core/locator.dart';
import 'package:vyaparlive/core/view_models/homeview_model.dart';
import 'package:vyaparlive/model/Contacts.dart';
import 'dart:convert';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/Transaction/buyer/DiscussionView.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:socket_io_client/socket_io_client.dart' as io;
import 'package:vyaparlive/service/bu_list_grpc_service.dart';
import 'package:vyaparlive/service/invitation_services.dart';
import 'package:vyaparlive/stock_returns_view/ReturnProducts.dart';
import 'package:vyaparlive/utills/SharePref.dart';

import '../model/BuListModel.dart';
import '../offline_connections/FillOrderForm.dart';
import '../offline_connections/buy_products_view/BuyOfflineProductsView.dart';
import '../service/api_service/InvitationApiService.dart';

class QuotationsTabController {
  VoidCallback? refresh;
}

class QuotationView extends StatefulWidget {
  final bool isFromConnections;
  final bool isFromInternalConnection;
  final String? buId;
  final String? buName;
  final bool isFromBuList;
  final bool isFromHomePage;
  final bool isFromOfflineConnections;

  QuotationView(
      {this.isFromConnections = false,
      this.buId,
      this.buName,
      this.isFromBuList = false,
      this.isFromInternalConnection = false,
      this.isFromHomePage = false,
      this.isFromOfflineConnections = false});
  @override
  _QuotationViewState createState() => _QuotationViewState();
}

class _QuotationViewState extends State<QuotationView>
    with TickerProviderStateMixin {
  late TabController _tabController;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  String? buName = "";
  String? buId = "";
  String? userId = "";
  String? connectionBuId = "";
  Contacts? _contacts;
  Contacts? connectionDropdownValue;
  List<Contacts> _connectionsList = [];
  bool isLoading = false;
  String? connectionType;
  int tabIndexColorChange = 0;
  bool isLoadingProgress = false;
  String progressMessage = "Getting Connections..";
  String? params = "";
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  HomeViewModel? _homeViewModel = locator<HomeViewModel>();
  io.Socket? socket;
  late InvitationService _invitationService;
  String? rawMaterialTransactionRadioValue;
  String? actualTransactionRadioValue;
  bool isBuyProductsSelected = false;
  late BuListGrpcService _transactionService;
  int tabIndex = 1;
  bool isBuyList = true;
  bool isSellList = false;
  late ThemeData theme;
  String _connectionSearchQuery = '';

  final sentController = QuotationsTabController();

  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _invitationService = InvitationService();
    SharePref().getUserId().then((value) {
      userId = value;
    });
    if (AppController.instance.getIsFromConfirmationPage) {
      _homeViewModel!.initSocket(AppController.instance.getCnfTransactionId);
      _homeViewModel!.sendMessage(
          type: AppController.instance.getCnfType,
          message: json.encode(
            {
              "bu_id": AppController.instance.getCnfBuId,
              "message": AppController.instance.getCnfMessage,
            },
          ),
          userName: AppController.instance.getCnfUserName,
          transactionId: AppController.instance.getCnfTransactionId);

      this.clearAppControllerData();
    } else {
      _homeViewModel!.unSubscribes();
    }

    _tabController = TabController(length: 2, vsync: this);

    if (widget.isFromConnections) {
      _contacts = AppController.instance.getConnectionsData;
      // buName = _contacts!.buName;
      buName = AppController.instance.getBuName;
      params = _contacts!.buName;
      connectionBuId = _contacts!.buId;
      buId = AppController.instance.getMyBuId;
    } else if (widget.isFromInternalConnection) {
      // buName = widget.buName;
      buName = AppController.instance.getBuName;
      connectionBuId = widget.buId;
      buId = AppController.instance.getMyBuId;
      params = widget.buName;
    } else if (widget.isFromBuList) {
      // buName = widget.buName;
      buName = AppController.instance.getBuName;
      buId = widget.buId;
      params = "";
    } else if (widget.isFromOfflineConnections) {
      // buName = widget.buName;
      buName = AppController.instance.getBuName;
      params = widget.buName;
      connectionBuId = widget.buId;
      buId = AppController.instance.getMyBuId;
    } else {
      buName = AppController.instance.getBuName;
      buId = AppController.instance.getMyBuId;

      params = "";
    }
    loadConnectionsData("");
    _transactionService = BuListGrpcService();
  }

  Future<bool> onBackPress() async {
    if (widget.isFromBuList || widget.isFromHomePage) {
      return Navigator.canPop(context);
    } else {
      return CommonMethods.onBackPress(context);
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  void setState(VoidCallback fn) {
    // TODO: implement setState
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  Widget build(BuildContext context) {
    Size screensize = MediaQuery.of(context).size;
    return AppBackgroundView(
      body: Stack(
        children: [
          WillPopScope(
            child: SafeArea(
              child: Scaffold(
                  key: _scaffoldkey,
                  backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                  appBar: AppBar(
                    elevation: 0,
                    iconTheme: IconThemeData(color: theme.colorScheme.primary),
                    backgroundColor: Colors.transparent,
                    centerTitle: true,
                    title: AppbarName(
                        title: Language()
                            .getString(Constants.QUOTATIONS_STR, selectedLang),
                        buName: buName),
                    actions: <Widget>[
                      if (CommonMethods.isPrivillegeExist(context,
                          PrivillegesActions.KEY_TRANSACTIONS_ADD_ICON))
                        IconButton(
                            icon: Icon(Icons.add),
                            onPressed: () {
                              CommonMethods.hideKeyboard(context);
                              if (_connectionsList.length > 0) {
                                connectionDropdownValue = null;
                                connectionType = null;
                                showAllConnections();
                                // showDiscussionChoiceDialog();
                              } else {
                                Dialogs.yesCancelDialog(
                                    context,
                                    Language().getString(
                                        Constants.ERROR, selectedLang),
                                    Language().getString(
                                        Constants.NO_CONNECTIONS_FOUND,
                                        selectedLang),
                                    Language().getString(
                                        Constants.OKAY_STR, selectedLang),
                                    "",
                                    false);
                              }
                            }),
                    ],
                    bottom: PreferredSize(
                      preferredSize: Size.fromHeight(screensize.height * 0.09),
                      child: TabBar(
                          indicatorSize: TabBarIndicatorSize.tab,
                          controller: _tabController,
                          onTap: (index) {
                            setState(() {
                              tabIndexColorChange = index;
                            });
                            CommonMethods.hideKeyboard(context);
                          },
                          indicator: BoxDecoration(
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey,
                                  blurRadius: 6.0,
                                ),
                                BoxShadow(
                                    color: Colors.white, offset: Offset(0, 9)),
                              ],
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(10),
                                  topRight: Radius.circular(10)),
                              color: Colors.white),
                          tabs: <Widget>[
                            Tab(
                              child: Text(
                                Language().getString(
                                    Constants.QUOTATIONS_SENT_STR,
                                    selectedLang),
                                style: TextStyle(
                                    color: theme.colorScheme.primary,
                                    fontWeight: StyleView.fontBold),
                              ),
                            ),
                            Tab(
                              child: Text(
                                Language().getString(
                                    Constants.QUOTATIONS_RECEIVED_STR,
                                    selectedLang),
                                style: TextStyle(
                                    color: theme.colorScheme.primary,
                                    fontWeight: StyleView.fontBold),
                              ),
                            ),
                          ]),
                    ),
                  ),
                  drawer: (widget.isFromBuList || widget.isFromHomePage)
                      ? null
                      : MyDrawer(),
                  body: TabBarView(
                      physics: NeverScrollableScrollPhysics(),
                      controller: _tabController,
                      children: [
                        SentQuotationsView(
                          buId: buId,
                          params: params,
                          connectionBuId: connectionBuId,
                          isFromConnection: widget.isFromConnections,
                          isFromInternalBu: widget.isFromInternalConnection,
                          isFromOfflineConnections:
                              widget.isFromOfflineConnections,
                          controller: sentController,
                        ),
                        ReceivedQuotationsView(
                            buId: buId,
                            params: params,
                            connectionBuId: connectionBuId,
                            isFromConnection: widget.isFromConnections,
                            isFromOfflineConnections:
                                widget.isFromOfflineConnections,
                            isFromInternalBu: widget.isFromInternalConnection)
                      ])),
            ),
            onWillPop: onBackPress,
          ),
          AppUtills.showLoadingView(
              context: context,
              message: Language().getString(progressMessage, selectedLang),
              isLoading: isLoadingProgress),
        ],
      ),
    );
  }

  Future<Contacts?> _showConnectionSearchDialog(BuildContext parentContext) {
    _connectionSearchQuery = '';
    return showDialog<Contacts?>(
      context: parentContext,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            final query = _connectionSearchQuery.trim();
            final lowerQuery = query.toLowerCase();
            List<Contacts> filtered = _connectionsList.where((c) {
              final name = (c.buName ?? '').toLowerCase();
              final phone = (c.contactNumber ?? '').toLowerCase();
              return name.contains(lowerQuery) || phone.contains(lowerQuery);
            }).toList();
            final isPhoneQuery =
                query.isNotEmpty && RegExp(r'^[0-9+\s-]+$').hasMatch(query);
            final showAddNew = filtered.isEmpty && isPhoneQuery && query.length >= 7;
            return Dialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Padding(
                    padding: EdgeInsets.fromLTRB(12, 12, 12, 0),
                    child: TextField(
                      autofocus: true,
                      decoration: InputDecoration(
                        hintText: "Search by name or mobile...",
                        prefixIcon: Icon(Icons.search, color: Colors.grey),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        contentPadding: EdgeInsets.symmetric(vertical: 10),
                      ),
                      onChanged: (value) {
                        setState(() {
                          _connectionSearchQuery = value;
                        });
                      },
                    ),
                  ),
                  SizedBox(
                    height: 300,
                    child: filtered.isEmpty
                        ? Center(
                            child: Text(
                              query.isEmpty
                                  ? "No connections"
                                  : "No connections found",
                              style: TextStyle(color: Colors.grey),
                            ),
                          )
                        : ListView.builder(
                            itemCount: filtered.length,
                            itemBuilder: (context, index) {
                              final contact = filtered[index];
                              return ListTile(
                                title: Text(
                                  contact.isOnline
                                      ? contact.buName!
                                      : "${contact.buName!} (Offline)",
                                ),
                                subtitle: (contact.contactNumber ?? '')
                                        .isNotEmpty
                                    ? Text(contact.contactNumber!)
                                    : null,
                                onTap: () {
                                  Navigator.of(context).pop(contact);
                                },
                              );
                            },
                          ),
                  ),
                  if (showAddNew)
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                      child: SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: theme.colorScheme.primary,
                            foregroundColor: Colors.white,
                          ),
                          icon: Icon(Icons.person_add),
                          label: Text("Add new contact with $query"),
                          onPressed: () async {
                            final newContact =
                                await _showAddNewContactDialog(context, query);
                            if (newContact != null) {
                              Navigator.of(context).pop(newContact);
                            }
                          },
                        ),
                      ),
                    ),
                  Padding(
                    padding: EdgeInsets.only(bottom: 8),
                    child: TextButton(
                      onPressed: () => Navigator.of(context).pop(null),
                      child: Text(
                        Language().getString(Constants.STR_CANCEL, selectedLang),
                        style: TextStyle(color: Colors.red),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Future<Contacts?> _showAddNewContactDialog(
      BuildContext parentContext, String phone) {
    final nameController = TextEditingController();
    final phoneController = TextEditingController(text: phone);
    bool isSaving = false;
    return showDialog<Contacts?>(
      context: parentContext,
      barrierDismissible: false,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
              ),
              title: Text(
                "Add New Contact",
                style: TextStyle(
                    color: theme.colorScheme.primary, fontSize: 16.0),
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: nameController,
                    autofocus: true,
                    decoration: InputDecoration(
                      labelText: Language().getString(
                          Constants.PLEASE_ENTERPERSON_NAME_STRING,
                          selectedLang),
                      border: OutlineInputBorder(),
                    ),
                  ),
                  SizedBox(height: 10),
                  TextField(
                    controller: phoneController,
                    keyboardType: TextInputType.phone,
                    decoration: InputDecoration(
                      labelText: Language()
                          .getString(Constants.ENTER_MOBILE_NUMBER, selectedLang),
                      border: OutlineInputBorder(),
                    ),
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: isSaving
                      ? null
                      : () => Navigator.of(context).pop(null),
                  child: Text(
                    Language().getString(Constants.STR_CANCEL, selectedLang),
                    style: TextStyle(color: Colors.red),
                  ),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: theme.colorScheme.primary,
                    foregroundColor: Colors.white,
                  ),
                  onPressed: isSaving
                      ? null
                      : () async {
                          final name = nameController.text.trim();
                          final phoneNum = phoneController.text.trim();
                          if (name.isEmpty) {
                            AppUtills.showSnackBar(
                                _scaffoldkey,
                                Language().getString(
                                    Constants.PLEASE_ENTERPERSON_NAME_STRING,
                                    selectedLang),
                                snackBarBgColor: Colors.black,
                                messageColor: Colors.white,
                                buttonColor: Colors.white);
                            return;
                          }
                          if (phoneNum.isEmpty) {
                            AppUtills.showSnackBar(
                                _scaffoldkey,
                                Language().getString(
                                    Constants.ENTER_MOBILE_NUMBER,
                                    selectedLang),
                                snackBarBgColor: Colors.black,
                                messageColor: Colors.white,
                                buttonColor: Colors.white);
                            return;
                          }
                          setState(() {
                            isSaving = true;
                          });
                          final created =
                              await _createQuickContact(name, phoneNum);
                          if (created != null) {
                            Navigator.of(context).pop(created);
                          } else {
                            setState(() {
                              isSaving = false;
                            });
                          }
                        },
                  child: isSaving
                      ? SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                              strokeWidth: 2, color: Colors.white),
                        )
                      : Text(Language()
                          .getString(Constants.OKAY_STR, selectedLang)),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Future<Contacts?> _createQuickContact(String name, String phone) async {
    if (!await NetworkStatus.getInternetStatus()) {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
      return null;
    }
    Map data = {
      "name": name,
      "buId": buId,
      "contact": phone,
      "email_id": "",
      "GST_No": "",
      "address": {
        "addressformat": "",
        "plot_no": "",
        "businesslocationnumber": "",
        "buildinghousenumber": "",
        "building_no": "",
        "buildingstreetname": "",
        "colonysector_arealocality": "",
        "villagetowncity": "",
        "taluk": "",
        "landmark": "",
        "state": "",
        "district": "",
        "postcode": "",
        "country": "",
      },
      "currency_code": "",
      "currency_symbol": "",
    };
    String body = json.encode(data);
    var response = await _invitationService
        .createContact_grpc(body, AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      // Reload contacts and find the newly created one by phone number.
      final refreshed = await getContacts(buId, "");
      setState(() {
        _connectionsList.clear();
        _connectionsList.addAll(refreshed);
      });
      Contacts? found;
      for (var c in refreshed) {
        if ((c.contactNumber ?? '') == phone && !c.isOnline) {
          found = c;
          break;
        }
      }
      if (found != null) return found;
      // Fallback: construct a minimal offline contact.
      final fallback = Contacts();
      fallback.buName = name;
      fallback.contactNumber = phone;
      fallback.isOnline = false;
      return fallback;
    } else {
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
      return null;
    }
  }

  showAllConnections() {
    return showDialog(
      barrierColor: Colors.black54,
      barrierDismissible: false,
      context: context,
      builder: (context) => AlertDialog(
        elevation: 100.0,
        contentPadding: EdgeInsets.fromLTRB(15.0, 0, 15.0, 0),
        backgroundColor: Colors.white, //Color(0XFFE0E0E0),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(
            Radius.circular(7.0),
          ),
        ),
        actions: [
          Container(
              width: MediaQuery.of(context).size.width,
              padding: EdgeInsets.only(bottom: 10),
              child: CommonButtonsView(
                context: context,
                b1Text:
                    Language().getString(Constants.STR_CANCEL, selectedLang),
                b2Text: Language().getString(Constants.OKAY_STR, selectedLang),
                onb1Action: () {
                  connectionDropdownValue = null;
                  connectionType = null;

                  Navigator.of(context).pop();
                },
                onb2Action: () {
                  Navigator.of(context).pop();
                  if (connectionDropdownValue!.isOnline) {
                    Navigator.push(
                      context,
                      PageTransition(
                        context: context,
                        page: DirectOrderPage(
                          isForSell: true,
                          isOnline: connectionDropdownValue!.isOnline,
                          connectionId: connectionDropdownValue!.buId,
                          connectionName: connectionDropdownValue!.buName,
                          isQuotation: true,
                        ),
                      ),
                    );
                  } else {
                    Navigator.push(
                      context,
                      PageTransition(
                        context: context,
                        page: FillOrderForm(
                          contactName: connectionDropdownValue!.buName,
                          recordId: connectionDropdownValue!.buId,
                          isQuotation: true,
                        ),
                      ),
                    ).then((_) {
                      // Reset / refresh tab when coming back
                      print(_tabController.index);
                      if (_tabController.index == 0) {
                        sentController.refresh?.call();
                      }
                    });
                  }
                },
              ))
        ],
        title: Text(
          Language().getString(Constants.SELECT_CONNECTION, selectedLang),
          style: TextStyle(color: theme.colorScheme.primary, fontSize: 15.0),
        ),
        titlePadding: EdgeInsets.fromLTRB(17.0, 24.0, 0.0, 10.0),
        content: StatefulBuilder(
            builder: (BuildContext context, StateSetter setState) {
          return Container(
              padding: EdgeInsets.only(bottom: 20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  GestureDetector(
                    onTap: () {
                      _showConnectionSearchDialog(context).then((selected) {
                        if (selected != null) {
                          setState(() {
                            connectionDropdownValue = selected;
                          });
                        }
                      });
                    },
                    child: Container(
                      height: 50.0,
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(5.0),
                          border: Border.all(
                              color: const Color.fromARGB(255, 10, 2, 2))),
                      width: MediaQuery.of(context).size.width,
                      padding: EdgeInsets.symmetric(horizontal: 12.0),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              connectionDropdownValue != null
                                  ? (connectionDropdownValue!.isOnline
                                      ? connectionDropdownValue!.buName!
                                      : "${connectionDropdownValue!.buName!} (Offline)")
                                  : Language().getString(
                                      Constants.PLEASE_SELECT_CONNECTION,
                                      selectedLang),
                              style: TextStyle(
                                fontSize: 14,
                                color: connectionDropdownValue != null
                                    ? Colors.black
                                    : Colors.grey,
                              ),
                            ),
                          ),
                          Icon(Icons.arrow_drop_down, color: Colors.grey),
                        ],
                      ),
                    ),
                  ),
                ],
              ));
        }),
      ),
    );
  }

  showDiscussionChoiceDialog() {
    return showDialog(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(15.0))),
              title: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Container(
                    child: Text(
                      Language().getString("Discussion For", selectedLang),
                      style: TextStyle(
                          color: theme.colorScheme.primary,
                          fontWeight: FontWeight.w700,
                          fontSize: 15.0),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      isBuyProductsSelected = false;
                      rawMaterialTransactionRadioValue = null;
                      actualTransactionRadioValue = null;
                      Navigator.of(context).pop();
                    },
                    child: Icon(
                      Icons.close,
                      color: Colors.red,
                    ),
                  ),
                ],
              ),
              content:
                  StatefulBuilder(builder: (context, StateSetter setState) {
                return Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Container(
                      width: MediaQuery.of(context).size.width,
                      height: 50,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                            borderRadius: new BorderRadius.circular(30.0),
                          ),
                          backgroundColor: theme.colorScheme.primary,
                          textStyle: TextStyle(
                              color: Colors.white,
                              fontFamily: StyleView.FONT_TEXT),
                          elevation: 3.0,
                        ),
                        onPressed: () => {
                          setState(() {
                            isBuyProductsSelected = true;
                          }),
                          Navigator.of(context).pop(),
                          showAllConnections(),
                          // this.createProductTransaction()
                        },
                        child: Padding(
                          padding: EdgeInsets.symmetric(vertical: 15),
                          child: Text(Language()
                              .getString(Constants.BUY_PRODUCTS, selectedLang)),
                        ),
                      ),
                    ),
                    SizedBox(height: 10.0),
                    Container(
                      width: MediaQuery.of(context).size.width,
                      height: 50,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                            borderRadius: new BorderRadius.circular(30.0),
                          ),
                          backgroundColor: theme.colorScheme.primary,
                          textStyle: TextStyle(
                              color: Colors.white,
                              fontFamily: StyleView.FONT_TEXT),
                          elevation: 3.0,
                        ),
                        onPressed: () => {
                          setState(() {
                            isBuyProductsSelected = false;
                          }),
                          // Future.delayed(Duration.zero).then((value) async {
                          //   if (await NetworkStatus.getInternetStatus()) {
                          //     setState(() {
                          //       isLoadingProgress = true;
                          //     });
                          //     this.postBodyForProductsSell();
                          //   } else {
                          //     AppUtills.showSnackBar(
                          //         _scaffoldkey,
                          //         Language().getString(
                          //             Constants.NO_INTERNET, selectedLang),
                          //         snackBarBgColor: Colors.black,
                          //         messageColor: Colors.white,
                          //         buttonColor: Colors.white);
                          //   }
                          // }),
                          Navigator.of(context).pop(),
                          showAllConnections(),
                        },
                        child: Padding(
                          padding: EdgeInsets.symmetric(vertical: 15),
                          child: Text(Language().getString(
                              Constants.SELL_PRODUCTS, selectedLang)),
                        ),
                      ),
                    )
                  ],
                );
              }));
        });
  }

  postBodyForProductsSell() async {
    Map data = {
      "id": "",
      "is_offline": !connectionDropdownValue!
          .isOnline, // !connectionDropdownValue!.isOnline,
      "buyer": {
        "id": connectionDropdownValue!.buId,
        "name": connectionDropdownValue!.buName,
        "is_offline": !connectionDropdownValue!.isOnline
      },
      "sender": {
        "id": buId,
      },
      "seller": {
        "id": buId,
        "name": buName,
      },
      "sales": {
        "seller": {"id": userId}
      },
      "ctr": {"type": "", "Agent": "", "transaction_ref": ""},
      "discussion": {
        "initiator": buId,
        "initiator_user": buName,
        "message_start_date": "",
        "confirmation_message": [],
        "confirmation_status": ""
      }
    };
    String body = json.encode(data);
    print("post body buy products: $body");
    var response = await _transactionService
        .beginTransaction(body, AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);

      Navigator.push(
        context,
        new MaterialPageRoute(
          builder: (context) => DiscussionView(
              transactionId: data,
              transactionName: connectionDropdownValue!.buName,
              isFromTransaction: true),
        ),
      );
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  postBodyForProductsBuy({String? raw}) async {
    Map data = {
      "id": "",
      "is_offline": !connectionDropdownValue!.isOnline,
      "buyer": {
        "id": buId,
        "name": buName,
      },
      "seller": {
        "id": connectionDropdownValue!.buId,
        "name": connectionDropdownValue!.buName,
        "is_offline": !connectionDropdownValue!.isOnline
      },
      "sender": {
        "id": buId,
      },
      "sales": {
        "buyer": {"id": userId}
      },
      "ctr": {"type": "", "Agent": "", "transaction_ref": ""},
      "discussion": {
        "initiator": buId,
        "initiator_user": buName,
        "message_start_date": "",
        "confirmation_message": [],
        "confirmation_status": ""
      }
    };
    if (isBuyProductsSelected && rawMaterialTransactionRadioValue != null) {
      data['transaction_type'] = Constants.KEY_RAW_MATERIAL;
    }

    String body = json.encode(data);
    print("postBodyForProductsBuy ${body}");
    var response = await _transactionService
        .beginTransaction(body, AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);

      Navigator.push(
          context,
          new MaterialPageRoute(
              builder: (context) => DiscussionView(
                    transactionId: data,
                    transactionName: connectionDropdownValue!.buName,
                    isFromTransaction: true,
                  )));
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  clearAppControllerData() {
    AppController.instance.setCnfBuId = null;
    AppController.instance.setCnfMessage = null;
    AppController.instance.setCnfTransactionId = null;
    AppController.instance.setCnfType = null;
    AppController.instance.setCnfUserName = null;
    AppController.instance.setIsFromConfirmationPage = false;
  }

  loadConnectionsData(String parms) async {
    if (await NetworkStatus.getInternetStatus()) {
      this.getContacts(buId, parms).then((onValue) {
        setState(() {
          if (onValue.length > 0) {
            _connectionsList.clear();
            _connectionsList.addAll(onValue);
          }
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<Contacts>> getContacts(String? buId, String parms) async {
    setState(() {
      _connectionsList.clear();
    });
    String body = json.encode({"buId": buId, "filters": {}});

    List<Contacts> _model = [];

    Map<String, dynamic> mapData = {"name": params};
    List<BuListModel> fetchOfflineUsers = await InvitationApiService.instance
        .getOfflineUsersByBuId(
            context: context,
            buId: buId!,
            mapData: mapData,
            langError: Language().getString(Constants.ERROR, selectedLang),
            langOk: Language().getString(Constants.OKAY_STR, selectedLang));

    for (var i = 0; i < fetchOfflineUsers.length; i++) {
      var element = fetchOfflineUsers[i];
      Contacts contacts = new Contacts();
      contacts.buId = element.recordId;
      contacts.buName = element.name;
      contacts.contactNumber = element.contact;
      contacts.city =
          element.address != null && element.address!.villagetowncity != null
              ? element.address!.villagetowncity
              : "";
      contacts.isOnline = false;
      _model.add(contacts);
    }

    var response = await _invitationService
        .findAllConnections_grpc(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    // setState(() {
    isLoadingProgress = false;
    // });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(resObj)) {
        for (var noteJson in resObj['results']) {
          _model.add(Contacts.fromJson(noteJson));
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }

    _model.sort((a, b) => a.buName.toString().compareTo(b.buName.toString()));
    return _model;
  }

  createProductTransaction() async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
        progressMessage = Constants.CREATING;
      });
      this.postBodyForProductsBuy();
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }
}
