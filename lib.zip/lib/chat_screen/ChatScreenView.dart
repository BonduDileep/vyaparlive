import 'dart:async';

import 'package:vyaparlive/Transaction/TransactionsPage.dart';
import 'package:vyaparlive/Transaction/discussion_product_view/message_card.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:flutter/material.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Transaction/buyer/ConfirmMessages.dart';
import 'package:vyaparlive/Transaction/buyer/ConfirmationProducts.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';

import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/Chat.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/ModelProduct.dart';
import 'package:vyaparlive/model/TransactionsModel.dart';
import 'package:vyaparlive/model/UserModel.dart';
import 'package:vyaparlive/service/bu_list_grpc_service.dart';
import 'package:vyaparlive/model/ProductDataModal.dart';
import 'dart:convert';
import 'package:socket_io_client/socket_io_client.dart' as io;
import 'package:vyaparlive/utills/SharePref.dart';
import 'package:clipboard/clipboard.dart';
import 'package:toast/toast.dart';

import '../Transaction/buyer/DiscussionView.dart';

class ChatScreenView extends StatefulWidget {
  final String? chatId;
  final String? transactionName;
  final String? firebaseToken;
  final bool isFromTransaction;
  ChatScreenView(
      {this.chatId,
      this.transactionName,
      this.firebaseToken,
      this.isFromTransaction = false});
  @override
  _ChatScreenViewState createState() => _ChatScreenViewState();
}

class _ChatScreenViewState extends State<ChatScreenView>
    with TickerProviderStateMixin {
  final TextEditingController _textController = new TextEditingController();
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  late AnimationController animationController;
  ScrollController? _scrollController;
  List<ChatMessage> _messages = [];
  List<ChatMessage> confirmationMsgList = [];
  var dbHelper;
  Future<List<Chat>>? messages;
  Future<List<Chat>>? startmessages;
  List<Chat>? discussionsList;
  List<ProductDataModal> selectedList = [];
  List<ProductDataModal> viewCartList = [];
  int updateOfferCount = 0;
  int totalQuantity = 0;
  int totalAmount = 0;
  String? selectedLang = AppController.instance.getSelectedlanguage; // 'en';
  late SharedPreferences sharedPreferences;
  String? buId = "";
  List<TransactionsModel> _transactionsList = [];
  bool isMsgItemSelected = false;
  var productsData = [];
  Timer? timer;
  String? buyerName = "";
  String? sellerName = "";
  String? buName = "";
  TransactionsModel? transactionDetails;
  io.Socket? socket;
  String? organizationId = "";
  UserModel? userData;
  String? transactionUserId = "";
  String? userName = "";
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  bool _isClientTyping = false;
  String? _typingClientId;
  late BuListGrpcService _transactionService;
  bool isBuyerSellerAccepted = false;
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _transactionService = BuListGrpcService();
    buId = AppController.instance.getMyBuId;
    buName = AppController.instance.getBuName;
    SharePref().getUserName().then((value) {
      setState(() {
        userName = value;
      });
    });
    _scrollController = ScrollController();
    animationController = new AnimationController(
        vsync: this, duration: new Duration(milliseconds: 1000));
    _scrollToBottom();
    // loadTransactionData();
    initSocket();
  }

  // loadTransactionData() async {
  //   if (await NetworkStatus.getInternetStatus()) {
  //     this.getAllDiscussionData().then((value) {
  //       setState(() {
  //         _typingClientId = AppController.instance.getMyBuId;
  //         _transactionsList.addAll(value);
  //         buyerName = _transactionsList[0].buyer!.name;
  //         sellerName = _transactionsList[0].seller!.name;
  //         AppController.instance.setSellerId = _transactionsList[0].seller!.id;
  //         if (_transactionsList[0].buyer!.id == buId) {
  //           organizationId = _transactionsList[0].seller!.id;
  //           transactionUserId = _transactionsList[0].seller!.userId;

  //           widget.transactionName =
  //               _transactionsList[0].seller!.name! + " ( Seller )";
  //         } else {
  //           organizationId = _transactionsList[0].buyer!.id;
  //           transactionUserId = _transactionsList[0].buyer!.userId;

  //           widget.transactionName =
  //               _transactionsList[0].buyer!.name! + " ( Buyer )";
  //         }
  //       });

  //       initSocket();
  //     });
  //   } else {
  //     AppUtills.showSnackBar(_scaffoldkey,
  //         Language().getString(Constants.NO_INTERNET, selectedLang),
  //         snackBarBgColor: Colors.black,
  //         messageColor: Colors.white,
  //         buttonColor: Colors.white);
  //   }
  // }

  // Future<List<TransactionsModel>> getAllDiscussionData() async {
  //   setState(() {
  //     isLoadingProgress = true;
  //     _transactionsList.clear();
  //   });
  //   String body = json.encode({"id": widget.chatId});
  //   var response = await _transactionService
  //       .getTransactionDataById(
  //           body: body, token: AppController.instance.getAuthorizationKey)
  //       .catchError((onError) {
  //     setState(() {
  //       isLoadingProgress = false;
  //       Dialogs.yesCancelDialog(
  //           context,
  //           Language().getString(Constants.ERROR, selectedLang),
  //           onError,
  //           Language().getString(Constants.OKAY_STR, selectedLang),
  //           "",
  //           false);
  //     });
  //   });

  //   List<TransactionsModel> _discussionsData = [];
  //   setState(() {
  //     isLoadingProgress = false;
  //   });
  //   if (response != null) {
  //     GRPCResponse _grpcResponse = response;
  //     if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
  //       var resObj = json.decode(_grpcResponse.message!);
  //       _discussionsData.add(TransactionsModel.fromJson(resObj[0]));
  //       List<Message> messageList = [];
  //       if (_discussionsData[0].discussion != null &&
  //           _discussionsData[0].discussion!.messages!.length > 0) {
  //         if (_discussionsData[0].discussion!.buyerAccepted! &&
  //             _discussionsData[0].discussion!.sellerAccepted!) {
  //           isBuyerSellerAccepted = true;
  //         }
  //         messageList.addAll(_discussionsData[0].discussion!.messages!);
  //         setState(() {
  //           _messages.clear();
  //         });
  //         for (int i = 0; i < messageList.length; i++) {
  //           var items = messageList[i];
  //           updateChat({
  //             "bu_id": items.bu,
  //             "message": items.message,
  //             "user_name": items.userName,
  //             "message_date": items.messageDate,
  //             "type": items.type,
  //             "user_id": items.userId,
  //             "order_placed_by": items.orderPlacedBy,
  //             "order_status_date": items.orderStatusDate,
  //             "order_status": items.orderStatus,
  //             "id": i
  //           });
  //         }
  //       }
  //     } else {
  //       Dialogs.yesCancelDialog(
  //           context,
  //           Language().getString(Constants.ERROR, selectedLang),
  //           _grpcResponse.message,
  //           Language().getString(Constants.OKAY_STR, selectedLang),
  //           "",
  //           false);
  //     }
  //   } else {
  //     Dialogs.yesCancelDialog(
  //         context,
  //         Language().getString(Constants.ERROR, selectedLang),
  //         "$response",
  //         Language().getString(Constants.OKAY_STR, selectedLang),
  //         "",
  //         false);
  //   }
  //   return _discussionsData;
  // }

  void initSocket() async {
    // String url ="http://${Constants.BASE_URL_2}:${Constants.SOCKET_PORT}/communication";
    // "ws://3.7.248.184:4010/socket.io/?EIO=4&transport=websocket&sid=${widget.transactionId}";
    // jLcqmctof2ny9dk9AAAW';

    ////"http://${Constants.BASE_URL_2}/api/v1/communication";

    socket = io.io('${Constants.CHAT_COMMUNICATION_URL}', <String, dynamic>{
      'autoConnect': true,
      'transports': ['websocket']
    });

    socket!.on('connect', (_) {
      print("socket connected:");
      sendJoinChat();
    });

    socket!.on('error', (error) {
      print('error');
      print(error);
    });

    print("socket.connected:${socket!.connected}");

    socket!.on('msgReceive', (data) {
      var value = json.decode(data);
      if (value['type'] == 'typing') {
        setState(() {
          _isClientTyping = true;
          _typingClientId = value['sender_id'];
        });
        Future.delayed(Duration(seconds: 2)).then((value) {
          setState(() {
            _isClientTyping = false;
            _typingClientId = null;
          });
        });
      } else {
        _onReceiveMessage(data);
      }
    });
  }

  _unSubscribes() {
    if (socket != null) {
      socket!.disconnect();
    }
  }

  void sendJoinChat() {
    socket!.emit("joinChat", widget.chatId);
  }

  void _onReceiveMessage(msg) {
    var data = json.decode(msg);

    data['id'] = _messages.length;

    ChatMessage _message = new ChatMessage(
      messageData: data,
      isSelected: false,
      animationController: new AnimationController(
        vsync: this,
        duration: new Duration(milliseconds: 1000),
      ),
    );
    setState(() {
      _messages.add(_message);
    });
    Timer(Duration(seconds: 1), _scrollToBottom);

    if (data.containsKey('order_status') && data['order_status'] == 'success') {
      Navigator.of(context).pop();
    }
  }

  _sendMessage({String type = "TEXT", String message = ''}) async {
    var messageObject = json.decode(message);
    var messageMap = Map<String, Object?>();
    messageMap['sender_id'] = AppController.instance.myBuId;

    messageMap['message'] = messageObject["message"];
    messageMap['bu_id'] = messageObject["bu_id"];

    messageMap['chat_id'] = widget.chatId;
    messageMap['type'] = type;

    messageMap['user_name'] = userName;
    messageMap['message_date'] = DateTime.now().toUtc().toString();
    messageObject['user_name'] = userName;
    messageObject['message_date'] = messageMap['message_date'];
    messageObject['type'] = type;
    messageObject['id'] = _messages.length;

    String jsonString = json.encode(messageMap);

    socket!.emit('new_message', jsonString);

    ChatMessage _message = new ChatMessage(
      messageData: messageObject,
      isSelected: false,
      animationController: new AnimationController(
        vsync: this,
        duration: new Duration(milliseconds: 1000),
      ),
    );
    setState(() {
      _messages.add(_message);
    });

    _scrollToBottom();
  }

  @override
  void dispose() {
    for (ChatMessage message in _messages)
      message.animationController!.dispose();
    _unSubscribes();
    _scrollController!.dispose();
    animationController.dispose();
    super.dispose();
  }

  _scrollToBottom() {
    if (_scrollController!.hasClients) {
      _scrollController!.animateTo(
        _scrollController!.position.maxScrollExtent,
        duration: Duration(seconds: 1),
        curve: Curves.fastOutSlowIn,
      );
    } else {
      Timer(Duration(milliseconds: 0), () => _scrollToBottom());
    }
  }

  chatTyping() {
    var messageMap = Map<String, Object?>();
    messageMap['sender_id'] = AppController.instance.myBuId;
    messageMap['chat_id'] = widget.chatId;
    messageMap['type'] = 'typing';
    String jsonString = json.encode(messageMap);
    socket!.emit('new_message', jsonString);
  }

  _buildTextComposer() {
    if (isBuyerSellerAccepted) {
      return Container();
    } else {
      return Container(
        padding: EdgeInsets.only(left: 15.0),
        child: Row(
          children: <Widget>[
            Flexible(
              child: new TextField(
                  textInputAction: TextInputAction.done,
                  controller: _textController,
                  onChanged: ((value) {
                    setState(() {
                      chatTyping();
                      _isClientTyping = true;
                    });
                  }),
                  minLines: 1,
                  maxLines: 5,
                  decoration: new InputDecoration.collapsed(
                      hintStyle: TextStyle(color: Colors.black, fontSize: 14.0),
                      hintText: Language().getString(
                          Constants.SEND_A_MESSAGE_STRING, selectedLang))),
            ),
            new Container(
              child: new IconButton(
                  icon: new Icon(
                    FeatherIcons.send,
                    size: 19.0,
                    color: theme.colorScheme.primary,
                  ),
                  onPressed: () async {
                    if (await NetworkStatus.getInternetStatus()) {
                      this._handleSubmitted(_textController.text, "TEXT");
                    } else {
                      AppUtills.showSnackBar(
                          _scaffoldkey,
                          Language()
                              .getString(Constants.NO_INTERNET, selectedLang),
                          snackBarBgColor: Colors.black,
                          messageColor: Colors.white,
                          buttonColor: Colors.white);
                    }
                  }),
            )
          ],
        ),
      );
    }
  }

  validate(text) {
    bool isValid = false;
    if (text == '') {
      isValid = false;
    } else {
      isValid = true;
    }
    return isValid;
  }

  updateChat(var data) {
    ChatMessage message = new ChatMessage(
      messageData: data,
      isSelected: false,
      animationController: new AnimationController(
        vsync: this,
        duration: new Duration(milliseconds: 1000),
      ),
    );
    setState(() {
      _messages.add(message);
    });
    message.animationController!.forward();
  }

  // We can use controller to clear text after submitting
  void _handleSubmitted(String text, String messageType) async {
    if (!validate(text)) {
      return;
    }
    _sendMessage(
        type: messageType,
        message: json.encode({"bu_id": buId, "message": text}));
    _textController.clear();
    _scrollToBottom();
    Map data = {
      "bu": buId,
      "messages": text,
      "id": widget.chatId,
      "user_name": userName,
      "type": messageType
    };

    String body = json.encode(data);
    var response = await _transactionService
        .sedMessage(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }

    // }
  }

  Widget _messagesListView() {
    return Expanded(
      child: (_messages.length > 0)
          ? Container(
              child: ListView(
                controller: _scrollController,
                physics: new BouncingScrollPhysics(
                    parent: AlwaysScrollableScrollPhysics()),
                shrinkWrap: true,
                children: <Widget>[
                  for (int i = 0; i < _messages.length; i++)
                    // designMessageType(_messages[i])
                    MessageCardView(
                        chatMessage: _messages[i],
                        onPressSend: () {
                          if (_messages[i].isSelected!) {
                            setState(() {
                              _messages[i].isSelected = false;
                              confirmationMsgList.remove(_messages[i]);
                            });
                          } else {
                            setState(() {
                              _messages[i].isSelected = true;
                              confirmationMsgList.add(_messages[i]);
                            });
                          }
                        },
                        userName: "$userName",
                        onPressReceive: () {
                          if (_messages[i].isSelected!) {
                            setState(() {
                              _messages[i].isSelected = false;
                              confirmationMsgList.remove(_messages[i]);
                            });
                          } else {
                            setState(() {
                              _messages[i].isSelected = true;
                              confirmationMsgList.add(_messages[i]);
                            });
                          }
                        },
                        buId: "$buId")
                ],
              ),
            )
          : Center(
              child: Text(
                Language().getString(Constants.NO_DATA_FOUND, selectedLang),
              ),
            ),
    );
  }

  handelingNavigationFlow() {
    if (_transactionsList[0].offerDetails != null) {
      if (_transactionsList[0].buyer!.id == AppController.instance.getMyBuId &&
          _transactionsList[0].offerDetails!.productDetails!.length > 0) {
        navigatToScreen(true);
      } else if (_transactionsList[0].seller!.id == buId) {
        navigatToScreen(true);
      } else {
        navigatToScreen(true);
      }
    } else {
      if (_transactionsList[0].seller!.id == buId) {
        navigatToScreen(true);
      } else {
        navigatToScreen(false);
      }
    }
  }

  navigatToScreen(bool isTransactionSubmit) {
    confirmationMsgList
        .sort((a, b) => a.messageData['id'].compareTo(b.messageData['id']));

    /// if transaction have rough orders
    if (_transactionsList[0].roughOrderDetails != null) {
      List<ModelProduct> _roughProducts = [];
      for (int i = 0;
          i < _transactionsList[0].roughOrderDetails!.products!.length;
          i++) {
        _roughProducts.add(ModelProduct(
            id: _transactionsList[0].roughOrderDetails!.products![i].id,
            name: _transactionsList[0]
                .roughOrderDetails!
                .products![i]
                .productName,
            counter: _transactionsList[0]
                .roughOrderDetails!
                .products![i]
                .quantity as int?,
            isButton: false,
            images: _transactionsList[0]
                        .roughOrderDetails!
                        .products![i]
                        .productImage!
                        .length >
                    0
                ? _transactionsList[0]
                    .roughOrderDetails!
                    .products![i]
                    .productImage![0]
                : null,
            price: _transactionsList[0].roughOrderDetails!.products![i].total,
            quantity: 0,
            isItemSelected: false,
            offerList: []));
      }

      /// Comparing is seller id equal to selected bu or not
      if (_transactionsList[0].seller!.id == AppController.instance.myBuId) {
        /// if seller is equal to our selected bu
        Navigator.push(
            context,
            new MaterialPageRoute(
                builder: (context) => ConfirmMessagesPage(
                    isTransactionSubmit: isTransactionSubmit,
                    chatMessages: confirmationMsgList,
                    transactionId: widget.chatId,
                    transactionName: widget.transactionName,
                    transactionBuyerId: _transactionsList[0].buyer!.id)));
      } else {
        /// is seller id not equal to our selected bu
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ConfirmationProductsPage(
                transactionData: _transactionsList[0],
                chatMessages: confirmationMsgList,
                transactionId: widget.chatId,
                transactionName: widget.transactionName,
                productsData: _roughProducts,
                isFromDiscussion: true),
          ),
        );
      }
    } else {
      /// if transaction have no rough orders
      Navigator.push(
          context,
          new MaterialPageRoute(
              builder: (context) => ConfirmMessagesPage(
                  isTransactionSubmit: isTransactionSubmit,
                  chatMessages: confirmationMsgList,
                  transactionId: widget.chatId,
                  transactionName: widget.transactionName,
                  transactionBuyerId: _transactionsList[0].buyer!.id,
                  isFromDiscussion: true)));
    }
  }

  Future<bool> onBackPress() async {
    CommonMethods.hideKeyboard(context);

    if (confirmationMsgList.length > 0) {
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.WARNING, selectedLang),
          Language().getString(Constants.LOST_SELECTED_MESSAGES, selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          Language().getString(Constants.STR_CANCEL, selectedLang),
          true);
      if (action == DialogAction.yes) {
        Navigator.of(context).pop();
      }
    } else if (widget.isFromTransaction) {
      Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (context) => TransactionsView()),
          (route) => false);
    } else {
      Navigator.of(context).pop();
    }
    return false;
  }

  Widget _showTypingIndicator() {
    if (_isClientTyping &&
        _typingClientId != null &&
        (_typingClientId != AppController.instance.getMyBuId)) {
      return Container(
          color: Colors.transparent,
          alignment: Alignment.centerLeft,
          padding: const EdgeInsets.all(10.0),
          child: Text(Language().getString(Constants.STR_TYPING, selectedLang),
              style: TextStyle(
                fontSize: 15.0,
                color: theme.colorScheme.primary,
              )));
    } else {
      return SizedBox();
    }
  }

  openCopyAlertDialog() {
    return showDialog(
        barrierDismissible: false,
        context: context,
        barrierColor: Colors.black54,
        builder: (BuildContext context) {
          return AlertDialog(
            elevation: 100.0,
            contentPadding: EdgeInsets.fromLTRB(15.0, 0, 15.0, 0),
            backgroundColor: Color(0XFFE0E0E0),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(7.0))),
            actions: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  InkWell(
                    onTap: () => {
                      Navigator.of(context).pop(),
                    },
                    child: Text(
                      Language().getString(Constants.STR_CANCEL, selectedLang),
                      style: TextStyle(
                          color: Color(Constants.APP_COLOR),
                          fontSize: 15,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                  InkWell(
                    onTap: () => {
                      FlutterClipboard.copy(
                              "${Constants.HTTP_URL_PREFIX}${Constants.CHAT_URL}customer-chat/${widget.chatId}")
                          // "${Constants.HTTP_URL_PREFIX}${Constants.BASE_URL_2}/api/v1/http-utils/customer/chat/${widget.chatId}")
                          .then((value) => {
                                Toast.show(
                                  "copied to clipboard",
                                  duration: Toast.lengthShort,
                                  gravity: Toast.bottom,
                                )
                              }),
                      Navigator.of(context).pop(),
                    },
                    child: Text(
                      Language().getString(Constants.COPY, selectedLang),
                      style: TextStyle(
                          color: Color(Constants.APP_COLOR),
                          fontSize: 15,
                          fontWeight: FontWeight.bold),
                    ),
                  )
                ],
              )
            ],
            titlePadding: EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 10.0),
            title: Text(
              Language().getString(Constants.STR_COPY_TO_SHARE, selectedLang),
              style: TextStyle(
                  color: Color(Constants.APP_COLOR),
                  fontSize: 15,
                  fontWeight: FontWeight.bold),
            ),
            content: Container(
              // height: 70.0,
              child: Text(
                  // "${Constants.HTTP_URL_PREFIX}${Constants.BASE_URL_2}/api/v1/http-utils/customer/chat/${widget.chatId}"),
                  "${Constants.HTTP_URL_PREFIX}${Constants.CHAT_URL}customer-chat/${widget.chatId}")
            ),
          );
        });
  }

  Widget _buildBody() {
    return Column(
      children: <Widget>[
        _messagesListView(),
        _showTypingIndicator(),
        SizedBox(height: 5.0),
        Container(
          margin: EdgeInsets.only(left: 10.0, right: 10.0, bottom: 10.0),
          child: _buildTextComposer(),
          decoration: new BoxDecoration(
              color: theme.colorScheme.primaryContainer,
              borderRadius: BorderRadius.circular(30.0)),
        ),
      ],
    );
  }

  @override
  void setState(VoidCallback fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      child: Stack(
        children: [
          SafeArea(
            child: Scaffold(
                key: _scaffoldkey,
                appBar: AppBar(
                    iconTheme: IconThemeData(color: theme.colorScheme.primary),
                    centerTitle: true,
                    elevation: 0.0,
                    leading: IconButton(
                        icon: Icon(
                          Icons.arrow_back,
                          color: theme.colorScheme.primary,
                        ),
                        onPressed: () async {
                          this.onBackPress();
                        }),
                    title: AppbarName(
                        title: Language().getString(
                            Constants.DISCUSSIONS_STRING, selectedLang),
                        buName: "${widget.transactionName}"),
                    actions: [
                      AppUtills.homeButton(context),
                    ],
                    backgroundColor: Colors.transparent //(Constants.APP_COLOR),
                    ),
                backgroundColor: Colors.white, //(Constants.APP_BACKGROUND_COLOR),
                body: _buildBody()),
          ),
          AppUtills.showLoadingView(
              context: context,
              message: Language().getString(progressMessage, selectedLang),
              isLoading: isLoadingProgress),
        ],
      ),
      onWillPop: onBackPress,
    );
  }
}
