import 'package:vyaparlive/redux/actions/registration_data.dart';
import 'package:vyaparlive/redux/actions/reset_data.dart';
import 'package:vyaparlive/redux/state/app_state.dart';
import 'package:vyaparlive/redux/actions/menu_action.dart';

AppState appReducer(AppState state, action) {
  if (action is ResetData) {
    return AppState(mapData: null);
  }
  if (action is MenuAppState) {
    return state.copyWith(mapData: action);
  }
  if (action is RegistrationState) {
    return state.copyWith(mapData: action);
  }

  return state;
}
