class ResetData {}
