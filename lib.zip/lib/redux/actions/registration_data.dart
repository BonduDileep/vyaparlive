class RegistrationState {
  final Map<String, dynamic> mapData;
  RegistrationState({required this.mapData});

  RegistrationState copyWith({required Map<String, dynamic> itemData}) {
    return RegistrationState(mapData: itemData);
  }
}
