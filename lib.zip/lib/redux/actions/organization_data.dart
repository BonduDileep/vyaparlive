class OrganizationState {
  final Map<String, dynamic> data;
  OrganizationState({required this.data});

  OrganizationState copyWith({required Map<String, dynamic> itemData}) {
    return OrganizationState(data: itemData);
  }
}
