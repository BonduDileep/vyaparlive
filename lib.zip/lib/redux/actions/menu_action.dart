class MenuAppState {
  final List<dynamic> featureMenu;
  MenuAppState({required this.featureMenu});

  MenuAppState copyWith({required List<dynamic> menuItems}) {
    return MenuAppState(
      featureMenu: menuItems,
    );
  }
}
