// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:youtube_player_flutter/youtube_player_flutter.dart' as Prefix;
// import 'package:youtube_player_iframe/youtube_player_iframe.dart';

// class VideoPlayerScreen extends StatefulWidget {
//   final String videoUrls;

//   VideoPlayerScreen({required this.videoUrls});
//   @override
//   _VideoPlayerScreenState createState() => _VideoPlayerScreenState();
// }

// class _VideoPlayerScreenState extends State<VideoPlayerScreen> {
//   late YoutubePlayerController _controller;
//   late String videoURL;
//   @override
//   void initState() {
//     super.initState();
//     videoURL = widget.videoUrls;
//     // String? videoId = Prefix.YoutubePlayer.convertUrlToId(videoURL);
//     // print(videoId);
//     String? videoId = YoutubePlayerController.convertUrlToId(widget.videoUrls);
//     print(videoId);
//     _controller = YoutubePlayerController.fromVideoId(
//       videoId: videoId!,
//       params: const YoutubePlayerParams(
//           showFullscreenButton: true, strictRelatedVideos: true),
//     );
//     // _controller.load(videoId);
//   }

//   @override
//   void dispose() {
//     _controller.close();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.white,
//       appBar: AppBar(
//         backgroundColor: Colors.blue,
//         leading: IconButton(
//           icon: Icon(Icons.arrow_back),
//           onPressed: () {
//             SystemChrome.setPreferredOrientations(
//                 [DeviceOrientation.portraitUp]);
//             Navigator.pop(context);
//           },
//         ),
//       ),
//       body: SafeArea(
//           child: YoutubePlayer(
//         controller: _controller,
//         aspectRatio: 16 / 9,
//       )),
//     );
//   }
// }




import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:youtube_player_iframe/youtube_player_iframe.dart';

class VideoPlayerScreen extends StatefulWidget {
  final String videoUrls;
  const VideoPlayerScreen({Key? key, required this.videoUrls}) : super(key: key);

  @override
  State<VideoPlayerScreen> createState() => _VideoPlayerScreenState();
}

class _VideoPlayerScreenState extends State<VideoPlayerScreen> {
  late final YoutubePlayerController _controller;

  @override
  void initState() {
    super.initState();
    final videoId = YoutubePlayerController.convertUrlToId(widget.videoUrls);
    _controller = YoutubePlayerController.fromVideoId(
      videoId: videoId ?? '',
      autoPlay: true,
      params: const YoutubePlayerParams(
        showFullscreenButton: true,
        showControls: true,
        strictRelatedVideos: false,
        origin: 'https://www.youtube-nocookie.com',
      ),
    );
  }

  @override
  void dispose() {
    _controller.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubePlayerScaffold(
      controller: _controller,
      builder: (context, player) {
        return Scaffold(
          backgroundColor: Colors.black,
          appBar: AppBar(
            backgroundColor: Colors.blue,
            leading: IconButton(
              icon: const Icon(Icons.arrow_back),
              onPressed: () {
                SystemChrome.setPreferredOrientations([
                  DeviceOrientation.portraitUp,
                ]);
                Navigator.pop(context);
              },
            ),
          ),
          body: Center(
            child: AspectRatio(
              aspectRatio: 16 / 9,
              child: player,
            ),
          ),
        );
      },
    );
  }
}

