import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/help_view/VidePlayerScreen.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/config/Language.dart';

class HelpViewPage extends StatefulWidget {
  @override
  _HelpViewPageState createState() => _HelpViewPageState();
}

class _HelpViewPageState extends State<HelpViewPage> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? buName = "";
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  List<String> cardTitles = [
    "Invitation Accept",
    "Business Unit Creation",
    "Product Creation",
    "Generating Retail Invoice",
    "View Products Inventory",
    "Create B2B Sale",
    "Generate Purchase Order",
    "Create Online Purchase Order",
    "Accept Online Purchase Order",
    "Generate Invoice Order",
    "Update Iacking Details",
    "Update Delivery Details",
    "Receive Stocks From seller",
    "Stock Reconciliation By Seller",
    "Buyer Raise Stock Discrepancy To Seller",
    "Payment Reconciliation By Buyer",
    "Payment Reconciliation By Seller",
    "Create B2B Connection",
    "B2B Transaction Steps"
  ];
  List<String> videoUrls = [
    "https://youtube.com/shorts/d0GsJ-AKthE?feature=share",
    // "https://youtu.be/hcrm7gzT8Ao", //Old bu creation
    "https://youtube.com/shorts/YoKUAJoVtlk",  //new Bu creation
    "https://youtu.be/jdrYPDUMYsk",
    // "https://youtu.be/z--qMMF0HKM",
    "https://youtube.com/shorts/MVWedT971uQ?feature=share",
    "https://youtube.com/shorts/ES75tZQBWCo?feature=share",
    "https://youtu.be/pjHyk_1SXFM",
    "https://youtu.be/r6a10I024OU",
    "https://youtu.be/ALW9EGDZdhc",
    "https://youtube.com/shorts/6Vi0XSBa3_s?feature=share",
    "https://youtube.com/shorts/1VQXp7yfW-Y?feature=share",
    "https://youtube.com/shorts/PPEzmdudzvw?feature=share",
    "https://youtube.com/shorts/WWk7ROzPcmA?feature=share",
    "https://youtube.com/shorts/Emef79aPZ_M?feature=share",
    "https://youtube.com/shorts/ZAOZJoC5Ncg?feature=share",
    "https://youtu.be/6UIHVNRH5TI",
    "https://youtube.com/shorts/0KLIFs6dGu0?feature=share",
    "https://youtu.be/lFO_CPHjHZU",
    "https://youtube.com/shorts/cqBs3SuElX4",
    "https://youtube.com/shorts/bKDanZpwSME"
  ];
  late ThemeData theme;

  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    buName = AppController.instance.getBuName;
  }

  crossAxisCount(BoxConstraints boxConstraint) {
    if (kIsWeb && boxConstraint.maxWidth > 900) {
      return 6;
    }
    if (kIsWeb && boxConstraint.maxWidth < 900) {
      return 3;
    }

    return 2;
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
        body: SafeArea(
          child: Scaffold(
                key: _scaffoldkey,
                backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                appBar: AppBar(
            backgroundColor: Colors.transparent, //(Constants.APP_COLOR),
            centerTitle: true,
            elevation: 0,
            iconTheme: IconThemeData(color: theme.colorScheme.primary),
            title: AppbarName(
                title: Language().getString(Constants.STR_HELP, selectedLang),
                buName: "$buName")),
                body: Container(
            margin: EdgeInsets.all(5.0),
            padding: EdgeInsets.only(top: 20),
            child: LayoutBuilder(
                builder: (BuildContext context, BoxConstraints boxConstrainst) {
              // print(boxConstrainst.maxWidth);
              return Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Expanded(
                    child: GridView.builder(
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: crossAxisCount(boxConstrainst),
                        mainAxisSpacing: 5.0,
                        crossAxisSpacing: 5.0,
                      ),
                      itemBuilder: (context, index) => Card(
                        elevation: 10,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8.0)),
                        child: Padding(
                          padding: const EdgeInsets.all(5.0),
                          child: InkWell(
                            onTap: () {
                              // launchUrl(Uri.parse(videoUrls[index]),
                              //     mode: LaunchMode.externalApplication);
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => VideoPlayerScreen(
                                      videoUrls: videoUrls[index]),
                                ),
                              );
                            },
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  cardTitles[index],
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: StyleView.fontRegular),
                                ),
                                Icon(
                                  Icons.play_circle_filled,
                                  color: Colors.red,
                                  size: 50.0,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      itemCount: cardTitles.length,
                    ),
                  ),
                ],
              );
            })),
              ),
        ));
  }
}
