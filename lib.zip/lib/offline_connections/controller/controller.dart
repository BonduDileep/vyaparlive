import 'package:flutter/material.dart';
import 'package:flutx/flutx.dart';

import '../../page_transition/PageTransition.dart';
import '../BuSellProducts.dart';
import '../FillOrderForm.dart';
import '../buy_products_view/BuyOrderDetailsPage.dart';

class Controller extends FxController {
  void navitationSellProductsPage(
      {required BuildContext context,
      required String connectionBuName,
      required String recordId}) {
    Navigator.push(
        context,
        PageTransition(
            context: context,
            page: BuSellProductsPage(
                contactName: connectionBuName, recordId: recordId)));
  }

  void navigationFillOrderFormOfflineConnection({
    required BuildContext context,
    required String connectionBuName,
    required String recordId
  }){
     Navigator.push(
        context,
        PageTransition(
            context: context,
            page: FillOrderForm(
                contactName: connectionBuName, recordId: recordId)));
  }

  void navigationBuyProductsPage(
      {required BuildContext context,
      required String connectionBuName,
      required String recordId}) {
    Navigator.push(
        context,
        PageTransition(
            context: context,
            page:
                BuyOrderDetailsPage(buName: connectionBuName, buId: recordId)));
  }

  @override
  String getTag() {
    return "controller";
  }
}
