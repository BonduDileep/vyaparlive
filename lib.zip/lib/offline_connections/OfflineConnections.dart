import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/core/enums/privilleges_enum.dart';
import 'package:vyaparlive/offline_connections/controller/controller.dart';
import 'package:vyaparlive/service/api_service/InvitationApiService.dart';
import 'package:vyaparlive/service/api_service/UserApiService.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:flutx/flutx.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/offline_connections/CreateOfflineCustomerPage.dart';
import 'package:vyaparlive/offline_connections/business_view/BuListCardView.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/MyDrawer.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/BuBasicDataModel.dart';
import 'package:vyaparlive/model/BuListModel.dart';
import 'package:vyaparlive/model/CountryDAO.dart';
import 'package:vyaparlive/model/DepartmentDAO.dart';
import 'package:vyaparlive/model/StatesDAO.dart';
import 'package:vyaparlive/model/UserModel.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';

import '../Transaction/TransactionsPage.dart';
import '../Transaction/buyer/DiscussionView.dart';
import '../service/api_service/TransactionApiService.dart';
import '../utills/SharePref.dart';

class OfflineConnections extends StatefulWidget {
  @override
  _OfflineConnectionsState createState() => _OfflineConnectionsState();
}

class _OfflineConnectionsState extends State<OfflineConnections> {
  String? buId = "";
  String? buName = "";
  bool isSearchForParams = false;
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? userId = "";
  BuBasicDataModel? dropdownValue;
  DepartmentDAO? departmentDropdownValue;
  TextEditingController _searchController = TextEditingController();
  List<BuListModel> _buList = [];
  String showLoaderText = Constants.NO_DATA_FOUND;
  StatesDAO? statesDropdownValue;
  String? districtDropdownValue;
  CountryDAO? countryDropdownValue;
  String? citiesDropDownValue;
  String buContactId = '';
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  List<UserModel> _usersList = [];
  UserModel? usersDropdownValue;
  late ThemeData theme;
  late Controller _controller;
  @override
  void initState() {
    super.initState();
    _controller = FxControllerStore.putOrFind(Controller());
    theme = AppTheme.vyaparTheme;
    buId = AppController.instance.getMyBuId;
    buName = AppController.instance.getBuName;
    SharePref().getUserId().then((value) {
      userId = value;
    });
    loadGetContacts("");
    loadUsersData();
  }

  Widget searchFilterView() {
    return Container(
      height: 50.0,
      child: Card(
        elevation: 5,
        shadowColor: theme.colorScheme.primary,
        shape: new RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
            side: new BorderSide(
                color: theme.colorScheme.primary, strokeAlign: 0.02)),
        child: Row(
          children: <Widget>[
            Expanded(
                child: Container(
              padding: EdgeInsets.only(left: 10),
              child: TextFormField(
                controller: _searchController,
                onChanged: onSearchTextChanged,
                style: TextStyle(fontWeight: StyleView.fontSemiBold),
                decoration: InputDecoration(
                    contentPadding: EdgeInsets.only(bottom: 10),
                    border: InputBorder.none,
                    hintText: Language()
                        .getString(Constants.SEARCH_BY_NAME, selectedLang),
                    hintStyle: TextStyle(
                        fontSize: 13.0, fontWeight: StyleView.fontSemiBold)),
              ),
            )),
          ],
        ),
      ),
    );
  }

  onSearchTextChanged(String text) async {
    showLoaderText = Constants.LOADING;
    if (text.isEmpty) {
      isSearchForParams = false;
      loadGetContacts("");
    } else {
      isSearchForParams = true;

      loadGetContacts(text);
    }
  }

  Widget buListView(int index) {
    return BuListCardView(
      name: _buList[index].name,
      email: _buList[index].emailId,
      contact: _buList[index].contact,
      connectionId: _buList[index].recordId,
      gstNo: _buList[index].gstNo,
      strBuyProducts:
          Language().getString(Constants.BUY_PRODUCTS, selectedLang),
      strSellProducts:
          Language().getString(Constants.SELL_PRODUCTS, selectedLang),
      strEdit: Language().getString(Constants.EDIT, selectedLang),
      strDelete: Language().getString(Constants.DELETE_STRING, selectedLang),
      strAssignToUser:
          Language().getString(Constants.ASSIGN_TO_USER, selectedLang),
      strTransactionHistory:
          Language().getString(Constants.TRANSACTION_HISTORY, selectedLang),
      strDiscussion:
          Language().getString(Constants.START_ORDER_DISCUSSION, selectedLang),
      editBu: () {
        CommonMethods.hideKeyboard(context);
        Navigator.push(
            context,
            PageTransition(
                context: context,
                page: CreateOfflineCustomerPage(
                  buId: _buList[index].recordId,
                  buName: _buList[index].name,
                  isForUpdate: true,
                  modelData: _buList[index],
                ))).then((value) => this.loadGetContacts(""));
      },
      deleteBu: () async {
        final action = await Dialogs.yesCancelDialog(
            context,
            Language().getString(Constants.WARNING, selectedLang),
            Language().getString(Constants.WARNING_TEXT, selectedLang),
            Language().getString(Constants.YES_STRING, selectedLang),
            Language().getString(Constants.STR_CANCEL, selectedLang),
            true);

        if (action == DialogAction.yes) {
          if (await NetworkStatus.getInternetStatus()) {
            setState(() => isLoadingProgress = true);
            bool isRemoved = await InvitationApiService.instance
                .removeOfflineUser(
                    context: context,
                    contactId: _buList[index].recordId!,
                    langError:
                        Language().getString(Constants.ERROR, selectedLang),
                    langOk:
                        Language().getString(Constants.OKAY_STR, selectedLang));
            if (isRemoved) {
              final action = await Dialogs.yesCancelDialog(
                  context,
                  Language().getString(Constants.SUCCESS, selectedLang),
                  Language().getString(Constants.RECORD_DELETED, selectedLang),
                  Language().getString(Constants.OKAY_STR, selectedLang),
                  "",
                  false);
              if (action == DialogAction.yes) {
                loadGetContacts("");
              }
            }
          } else {
            AppUtills.showSnackBar(_scaffoldkey,
                Language().getString(Constants.NO_INTERNET, selectedLang),
                snackBarBgColor: Colors.black,
                messageColor: Colors.white,
                buttonColor: Colors.white);
          }
        }
      },
      assignToUser: () {
        if (_usersList.length > 0) {
          this.showUsersList(_buList[index].recordId);
        }
      },
      onSellProducts: () {
        CommonMethods.hideKeyboard(context);
        _controller.navitationSellProductsPage(
            context: context,
            connectionBuName: _buList[index].name!,
            recordId: _buList[index].recordId!);
      },
      onBuyProducts: () {
        CommonMethods.hideKeyboard(context);
        _controller.navigationBuyProductsPage(
            context: context,
            connectionBuName: _buList[index].name!,
            recordId: _buList[index].recordId!);
      },
      onTransactionHistory: () {
        CommonMethods.hideKeyboard(context);
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => TransactionsView(
                      isFromOfflineConnections: true,
                      buId: _buList[index].buId,
                      buName: _buList[index].name,
                    ))).then((value) => {
              // loadBuData()
            });
      },
      onStartDiscussionClick: () {
        CommonMethods.hideKeyboard(context);
        selectedContact = _buList[index];
        showDiscussionChoiceDialog();
      },
      onChatClick: () {},
    );
  }

  BuListModel? selectedContact;

  Widget usersDropdownView(StateSetter setState, String? connectionId) {
    return Container(
        height: MediaQuery.of(context).size.height * 0.23,
        padding: EdgeInsets.only(top: 10),
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Container(
                  margin: EdgeInsets.symmetric(horizontal: 5.0, vertical: 10.0),
                  decoration: AppUtills.boxDecoration(),
                  // height: 50,
                  child: DropdownButton<UserModel>(
                      onTap: () {
                        FocusScope.of(context).unfocus();
                      },
                      value: usersDropdownValue,
                      hint: Container(
                          padding: EdgeInsets.symmetric(horizontal: 8),
                          child: new Text(
                            Language().getString(
                                Constants.SELECT_A_USER, selectedLang),
                          )),
                      isExpanded: true,
                      underline: SizedBox(),
                      onChanged: (UserModel? data) {
                        setState(() {
                          usersDropdownValue = data;
                        });
                      },
                      items: _usersList.map((UserModel model) {
                        return new DropdownMenuItem<UserModel>(
                          child: Container(
                              padding: EdgeInsets.symmetric(horizontal: 8),
                              child: new Text(model.name!)),
                          value: model,
                        );
                      }).toList())),
              SizedBox(height: 10.0),
              Container(
                  width: MediaQuery.of(context).size.width,
                  child: CommonButtonsView(
                    context: context,
                    b1Text: "",
                    b2Text: Language().getString(Constants.DONE, selectedLang),
                    onb2Action: () async {
                      if (usersDropdownValue != null) {
                        Navigator.of(context).pop();
                        setState(() => isLoadingProgress = true);
                        String value = await InvitationApiService.instance
                            .assignOfflineConnectionToUser(
                                context: context,
                                connectionId: connectionId!,
                                userId: usersDropdownValue!.id!,
                                buId: buId!,
                                langError: Language()
                                    .getString(Constants.ERROR, selectedLang),
                                langOk: Language().getString(
                                    Constants.OKAY_STR, selectedLang));
                        setState(() => isLoadingProgress = false);
                        if (value.isNotEmpty) {
                          Dialogs.yesCancelDialog(
                              context,
                              Language()
                                  .getString(Constants.SUCCESS, selectedLang),
                              value,
                              Language()
                                  .getString(Constants.OKAY_STR, selectedLang),
                              "",
                              false);
                        }
                      } else {
                        Dialogs.yesCancelDialog(
                            context,
                            Language()
                                .getString(Constants.WARNING, selectedLang),
                            Language().getString(
                                Constants.PLEASE_SELECT_USER, selectedLang),
                            Language()
                                .getString(Constants.OKAY_STR, selectedLang),
                            "",
                            false);
                      }
                    },
                  )),
            ]));
  }

  showUsersList(String? connectionId) {
    return showDialog(
        barrierDismissible: false,
        barrierColor: Colors.black54,
        context: context,
        builder: (context) {
          return AlertDialog(
              elevation: 100.0,
              contentPadding: EdgeInsets.fromLTRB(15.0, 0, 15.0, 0),
              backgroundColor: Colors.white, //(0XFFE0E0E0),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(
                  Radius.circular(7.0),
                ),
              ),
              title: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Text(
                    Language().getString(Constants.SELECT_USER, selectedLang),
                    style: TextStyle(color: Colors.black),
                  ),
                  GestureDetector(
                    onTap: () {
                      usersDropdownValue = null;
                      Navigator.of(context).pop();
                    },
                    child: Icon(
                      Icons.close,
                      color: Colors.red,
                    ),
                  ),
                ],
              ),
              content: StatefulBuilder(
                  builder: (BuildContext context, StateSetter setState) {
                return this.usersDropdownView(setState, connectionId);
              }));
        });
  }

  @override
  void setState(VoidCallback fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
      body: Stack(
        children: [
          WillPopScope(
            child: SafeArea(
              child: Scaffold(
                  key: _scaffoldkey,
                  backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                  appBar: AppBar(
                    backgroundColor: Colors.transparent, //(Constants.APP_COLOR),
                    centerTitle: true,
                    elevation: 0,
                    iconTheme: IconThemeData(color: theme.colorScheme.primary),
                    title: AppbarName(
                        title: Language().getString(
                            Constants.OFFLINE_CONNECTIONS, selectedLang),
                        buName: "$buName"),
                    actions: [
                      if (CommonMethods.isPrivillegeExist(
                          context,
                          PrivillegesActions
                              .KEY_OFFLINE_CONNECTIONS_ADD_NEW_CONNECTION))
                        IconButton(
                            icon: Icon(Icons.add),
                            onPressed: () async {
                              Navigator.push(
                                      context,
                                      PageTransition(
                                          context: context,
                                          page: CreateOfflineCustomerPage()))
                                  .then((value) => this.loadGetContacts(""));
                            })
                    ],
                  ),
                  drawer: MyDrawer(),
                  body: Container(
                      margin: EdgeInsets.only(left: 5, right: 5, top: 20),
                      child: Column(
                        children: [
                          searchFilterView(),
                          (_buList.length > 0)
                              ? Expanded(
                                  child: Container(
                                    margin: EdgeInsets.only(top: 10),
                                    child: AnimationLimiter(
                                      child: ListView.separated(
                                        shrinkWrap: true,
                                        physics:
                                            new AlwaysScrollableScrollPhysics(
                                                parent:
                                                    new BouncingScrollPhysics()),
                                        separatorBuilder: (context, index) =>
                                            new Divider(
                                          height: 5,
                                          color: Colors.transparent,
                                        ),
                                        itemBuilder: (context, index) {
                                          return AnimationConfiguration
                                              .staggeredList(
                                                  position: index,
                                                  duration:
                                                      Duration(milliseconds: 900),
                                                  child: SlideAnimation(
                                                      verticalOffset: 50.0,
                                                      child: FadeInAnimation(
                                                          child: buListView(
                                                              index))));
                                        },
                                        itemCount: _buList.length,
                                      ),
                                    ),
                                  ),
                                )
                              : Expanded(
                                  child: Center(
                                      child: Text(
                                  Language()
                                      .getString(showLoaderText, selectedLang),
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: StyleView.fontMedium),
                                ))),
                        ],
                      ))),
            ),
            onWillPop: () {
              return CommonMethods.onBackPress(context).then((value) => value);
            },
          ),
          AppUtills.showLoadingView(
              context: context,
              message: Language().getString(progressMessage, selectedLang),
              isLoading: isLoadingProgress),
        ],
      ),
    );
  }

  Future<void> loadUsersData() async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() => isLoadingProgress = true);
      List<UserModel> fetchUsersList = await UserApiService.instance
          .getUsersByBuId(context, buId!,
              langError: Language().getString(Constants.ERROR, selectedLang),
              langOk: Language().getString(Constants.OKAY_STR, selectedLang));
      setState(() {
        isLoadingProgress = false;
        _usersList.clear();
      });

      if (fetchUsersList.length > 0) {
        setState(() => _usersList.addAll(fetchUsersList));
      }
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  loadGetContacts(String params) async {
    if (await NetworkStatus.getInternetStatus()) {
      if (!isSearchForParams) {
        setState(() => isLoadingProgress = true);
      }
      Map<String, dynamic> mapData = {"name": params};
      List<BuListModel> fetchOfflineUsers = await InvitationApiService.instance
          .getOfflineUsersByBuId(
              context: context,
              buId: buId!,
              mapData: mapData,
              langError: Language().getString(Constants.ERROR, selectedLang),
              langOk: Language().getString(Constants.OKAY_STR, selectedLang));
      setState(() {
        isLoadingProgress = false;
        _buList.clear();
      });
      if (fetchOfflineUsers.length > 0) {
        fetchOfflineUsers
            .sort((a, b) => a.name.toString().compareTo(b.name.toString()));
        setState(() => _buList.addAll(fetchOfflineUsers));
      } else {
        setState(() => showLoaderText =
            Language().getString(Constants.NO_DATA_FOUND, selectedLang));
      }
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  String? rawMaterialTransactionRadioValue;
  String? actualTransactionRadioValue;
  bool isBuyProductsSelected = false;

  showDiscussionChoiceDialog() {
    return showDialog(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(15.0)),
              ),
              title: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Container(
                    child: Text(
                      Language().getString(
                          Constants.STR_DISCUSSION_FOR, selectedLang),
                      style: TextStyle(
                          color: theme.colorScheme.primary,
                          fontWeight: StyleView.fontMedium,
                          fontSize: 15.0),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      rawMaterialTransactionRadioValue = null;
                      actualTransactionRadioValue = null;
                      isBuyProductsSelected = false;
                      Navigator.of(context).pop();
                    },
                    child: Icon(
                      Icons.close,
                      color: Colors.red,
                    ),
                  ),
                ],
              ),
              content:
                  StatefulBuilder(builder: (context, StateSetter setState) {
                return Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Container(
                      width: MediaQuery.of(context).size.width,
                      height: 50,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                            borderRadius: new BorderRadius.circular(30.0),
                          ),
                          backgroundColor: theme.colorScheme.primary,
                          elevation: 3.0,
                        ),
                        onPressed: () => {
                          serviceCallBuyProducts(),
                          Navigator.of(context).pop(),
                        },
                        child: Padding(
                          padding: EdgeInsets.symmetric(vertical: 15),
                          child: Text(
                            Language().getString(
                                Constants.BUY_PRODUCTS, selectedLang),
                            style: TextStyle(fontWeight: StyleView.fontRegular),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 10),
                    Container(
                      width: MediaQuery.of(context).size.width,
                      height: 50,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                            borderRadius: new BorderRadius.circular(30.0),
                          ),
                          backgroundColor: theme.colorScheme.primary,
                          elevation: 3.0,
                        ),
                        onPressed: () async {
                          setState(() => isBuyProductsSelected = false);
                          serviceCallSellProducts();
                          Navigator.of(context).pop();
                        },
                        child: Padding(
                          padding: EdgeInsets.symmetric(vertical: 15),
                          child: Text(
                            Language().getString(
                                Constants.SELL_PRODUCTS, selectedLang),
                            style: TextStyle(fontWeight: StyleView.fontRegular),
                          ),
                        ),
                      ),
                    )
                  ],
                );
              }));
        });
  }

  Future<void> serviceCallBuyProducts() async {
    if (await NetworkStatus.getInternetStatus()) {
      Map mapData = {
        "id": "",
        "is_offline": true,
        "order_type":"offline_discussion_buy",
        "buyer": {
          "id": buId,
          "name": buName,
        },
        "seller": {
          "id": selectedContact!.recordId,
          "name": selectedContact!.name,
          "is_offline": true
        },
        "sales": {
          "buyer": {"id": userId}
        },
        "sender": {
          "id": buId,
        },
        "ctr": {"type": "", "Agent": "", "transaction_ref": ""},
        "discussion": {
          "initiator": selectedContact!.recordId,
          "initiator_user": selectedContact!.name,
          "message_start_date": "",
          "confirmation_message": [],
          "confirmation_status": ""
        }
      };
      if (isBuyProductsSelected && rawMaterialTransactionRadioValue != null) {
        mapData['transaction_type'] = Constants.KEY_RAW_MATERIAL;
      }
      setState(() => isLoadingProgress = true);
      String transactionId = await TransactionApiService.instance.buyProducts(
          context: context,
          mapData: mapData,
          langError: Language().getString(Constants.ERROR, selectedLang),
          langOk: Language().getString(Constants.OKAY_STR, selectedLang));
      setState(() => isLoadingProgress = false);
      if (transactionId.isNotEmpty) {
        Navigator.push(
            context,
            new MaterialPageRoute(
                builder: (context) => DiscussionView(
                      transactionId: transactionId,
                      transactionName: selectedContact!.name,
                    )));
      }
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<void> serviceCallSellProducts() async {
    if (await NetworkStatus.getInternetStatus()) {
      Map mapData = {
        "id": "",
        "is_offline": true,
        "order_type":"offline_discussion_sell",
        "buyer": {
          "id": selectedContact!.recordId,
          "name": selectedContact!.name,
          "is_offline": true
        },
        "seller": {
          "id": buId,
          "name": buName,
        },
        "sales": {
          "buyer": {"id": userId}
        },
        "sender": {
          "id": buId,
        },
        "ctr": {"type": "", "Agent": "", "transaction_ref": ""},
        "discussion": {
          "initiator": selectedContact!.recordId,
          "initiator_user": selectedContact!.name,
          "message_start_date": "",
          "confirmation_message": [],
          "confirmation_status": ""
        }
      };
      setState(() => isLoadingProgress = true);
      String transactionId = await TransactionApiService.instance.sellProducts(
          context: context,
          mapData: mapData,
          langError: Language().getString(Constants.ERROR, selectedLang),
          langOk: Language().getString(Constants.OKAY_STR, selectedLang));
      setState(() => isLoadingProgress = false);
      if (transactionId.isNotEmpty) {
        Navigator.push(
          context,
          new MaterialPageRoute(
            builder: (context) => DiscussionView(
              transactionId: transactionId,
              transactionName: selectedContact!.name,
            ),
          ),
        );
      }
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }
}
