import 'package:flutter/foundation.dart';
import 'package:vyaparlive/components/BackDropInvoiceDateButton.dart';
import 'package:vyaparlive/components/additional_charges/AdditionalChargeButton.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Transaction/ListOfTransactions.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/ModelProduct.dart';
import 'package:vyaparlive/model/bu_model/LocationsModel.dart';
import 'package:vyaparlive/model/product_model/OffersDAO.dart';
import 'package:vyaparlive/model/product_model/ProductModel.dart';
import 'package:vyaparlive/service/bu_list_grpc_service.dart';
import 'package:vyaparlive/service/organization_service.dart';
import 'package:vyaparlive/service/product_services.dart';
import 'dart:convert';

import 'package:vyaparlive/utills/SharePref.dart';

import '../../components/DecimalTextInputFormatter.dart';
import '../../invoice_view/BatchPriceDropdownView.dart';
import '../../model/product_model/BatchPriceDAO.dart';
import '../../retailer_view/card_view/ProductsCardView.dart';
import '../service/api_service/ProductsApiService.dart';
import 'package:vyaparlive/utills/barcode/BarcodeScanPage.dart';
import 'package:vyaparlive/Product/AddProductPopup.dart';


class FillOrderForm extends StatefulWidget {
  final String? recordId;
  final String? contactName;
  final bool? isQuotation;
  final bool? isChallan;
  final String? transactionId;
  final bool? fromCreateTransaction;
  final List<ModelProduct>? selectedProducts;
  final String? orderFormId;

  FillOrderForm(
      {this.contactName,
      this.recordId,
      this.isQuotation = false,
      this.isChallan = false,
      this.transactionId,
      this.fromCreateTransaction = false,
      this.selectedProducts,
      this.orderFormId});

  @override
  _FillOrderFormState createState() => _FillOrderFormState();
}

class _FillOrderFormState extends State<FillOrderForm> {
  String? buId = "";
  String? buName = "";
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  TextEditingController _searchController = new TextEditingController();
  String showLoaderText = Constants.GETTING_DATA;
  List<BuProductModal> _responseProducts = [];
  List<ModelProduct> _productsList = [];
  List<ModelProduct> _selectedProducts = [];
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  List<TextEditingController> _enterProductCount = [];
  String? userId = "";
  String? userName = "";
  bool isSearchForParams = false;
  late BuListGrpcService _transactionService;
  late ProductService _productService;
  String? rawMaterialTransactionRadioValue;
  String? actualTransactionRadioValue;
  String? orgCurrencySymbol = "";
  Locations? locationDropdownValue;
  List<Locations> locationsList = [];
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  late OrganizationService _organizationService;
  late ThemeData theme;
  final _rupeeController = TextEditingController();
  String? offerInPercentage;
  String? radioButtonValue = Constants.OFFER_IN_PERCENTAGE;
  String discountType = "percent";
  List<TextEditingController> _quantityInputController = [];

  List<BatchPriceDAO?> batchPricingDropdownList = [];
  List<bool> canShowPriceEditField = [];
  List<TextEditingController> _finalPriceEditController = [];
  List<BatchPriceDAO?> tempBatchPricingList = [];

  bool isIncludeGST = true;
  bool addAdditionalDiscount = false;
  bool buyer_consent_selected = false;
  String? lastBarcodeProductId;
  String? backDateInvoice;
  List<Map<String, String>> additionalCharges = [];

  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _organizationService = OrganizationService();
    _transactionService = BuListGrpcService();
    buId = AppController.instance.getMyBuId;
    buName = AppController.instance.getBuName;
    _productService = ProductService();
    loadProductData("");
    SharePref().getUserId().then((value) {
      setState(() {
        userId = value;
      });

      SharePref().getUserName().then((value) {
        setState(() {
          userName = value;
        });
      });
    });

    // orgCurrencySymbol = AppController.instance.getBuCurrencySymbol;
    String? symbol = AppController.instance.getBuCurrencySymbol;
    orgCurrencySymbol = (symbol != null && symbol.isNotEmpty && symbol != "-")
        ? symbol
        : "\u20B9";
  }

  // loadProductData(String parm) async {
  //   if (await NetworkStatus.getInternetStatus()) {
  //     if (!isSearchForParams) {
  //       setState(() {
  //         isLoadingProgress = true;
  //       });
  //     }
  //     this.getProductsByBuId(parm).then((value) {
  //       _responseProducts.clear();
  //       _productsList.clear();
  //       _responseProducts.addAll(value);
  //       batchPricingDropdownList.clear();
  //       _enterProductCount.clear();
  //       tempBatchPricingList.clear();
  //       canShowPriceEditField.clear();
  //       _finalPriceEditController.clear();
  //       if (_responseProducts.length > 0) {
  //         for (int i = 0; i < _responseProducts.length; i++) {
  //           bool isPriceAvailable = false;
  //           int index = -1;
  //           _responseProducts[i]
  //               .batchPrice!
  //               .removeWhere((element) => element.quantity == 0);
  //           for (int j = 0; j < _responseProducts[i].batchPrice!.length; j++) {
  //             BatchPriceDAO batchPriceDAO = _responseProducts[i].batchPrice![j];
  //             if (batchPriceDAO.quantity != 0 && batchPriceDAO.price != 0) {
  //               isPriceAvailable = true;
  //               index = j;
  //               break;
  //             }
  //           }

  //           if (isPriceAvailable) {
  //             setState(() {
  //               ModelProduct modelProduct = ModelProduct(
  //                   offerList: _responseProducts[i].offers,
  //                   id: _responseProducts[i].id,
  //                   name: _responseProducts[i].name,
  //                   counter: 0,
  //                   isButton: false,
  //                   images: _responseProducts[i].images,
  //                   // _responseProducts[i].imageThumbnail!.length > 0
  //                   //     ? _responseProducts[i].imageThumbnail![0].image
  //                   //     : null,
  //                   price: 0, //_responseProducts[i].batchPrice![index].price,
  //                   counterNew: 0,
  //                   quantity: _responseProducts[i].batchPrice![0].quantity,
  //                   isItemSelected: false,
  //                   batchPriceList: _responseProducts[i].batchPrice,
  //                   quantityIn:
  //                       _responseProducts[i].batchPrice![index].quantityIn);

  //               // ====================================================================
  //               if (widget.selectedProducts != null &&
  //                   widget.selectedProducts!.length > 0) {
  //                 int selectedIndex = widget.selectedProducts!
  //                     .indexWhere((element) => modelProduct.id == element.id);

  //                 if (selectedIndex != -1) {
  //                   modelProduct.counterNew =
  //                       widget.selectedProducts![selectedIndex].quantity;
  //                   modelProduct.counter = widget
  //                       .selectedProducts![selectedIndex].quantity!
  //                       .toInt();
  //                   modelProduct.price =
  //                       widget.selectedProducts![selectedIndex].quantity! *
  //                           _responseProducts[i].batchPrice![index].price!;
  //                   modelProduct.batchNumber =
  //                       _responseProducts[i].batchPrice![index].batchNumber;

  //                   _selectedProducts.add(modelProduct);
  //                 }
  //               }
  //               _productsList.add(modelProduct);

  //               // _productsList.add(modelProduct);
  //               // _enterProductCount.add(new TextEditingController());
  //               batchPricingDropdownList.add(null);

  //               int findIndex = _selectedProducts
  //                   .indexWhere((element) => modelProduct.id == element.id);
  //               if (findIndex > -1) {
  //                 canShowPriceEditField
  //                     .add(_selectedProducts[findIndex].isPriceChanged!);
  //                 _enterProductCount.add(new TextEditingController(
  //                     text:
  //                         _selectedProducts[findIndex].counterNew.toString()));
  //                 _enterProductCount[_enterProductCount.length - 1].selection =
  //                     TextSelection.fromPosition(TextPosition(
  //                         offset:
  //                             _enterProductCount[_enterProductCount.length - 1]
  //                                 .text
  //                                 .length));
  //               } else {
  //                 canShowPriceEditField.add(false);
  //                 _enterProductCount.add(new TextEditingController(text: ""));
  //               }

  //               // _enterProductCount.add(new TextEditingController(text: ""));

  //               tempBatchPricingList.add(null);
  //               _finalPriceEditController
  //                   .add(new TextEditingController(text: ""));
  //               // canShowPriceEditField.add(false);
  //             });
  //           }
  //         }

  //       } else {
  //         setState(() {
  //           showLoaderText = Constants.NO_DATA_FOUND;
  //         });
  //       }
  //     });
  //   } else {
  //     AppUtills.showSnackBar(_scaffoldkey,
  //         Language().getString(Constants.NO_INTERNET, selectedLang),
  //         snackBarBgColor: Colors.black,
  //         messageColor: Colors.white,
  //         buttonColor: Colors.white);
  //   }
  // }

  loadProductData(String parm) async {
    if (!await NetworkStatus.getInternetStatus()) {
      AppUtills.showSnackBar(
        _scaffoldkey,
        Language().getString(Constants.NO_INTERNET, selectedLang),
        snackBarBgColor: Colors.black,
        messageColor: Colors.white,
        buttonColor: Colors.white,
      );
      return;
    }

    if (!isSearchForParams) {
      setState(() => isLoadingProgress = true);
    }

    final apiProducts = await getProductsByBuId(parm);

    // Reset lists
    _responseProducts.clear();
    _productsList.clear();
    // _selectedProducts.clear();
    _responseProducts.addAll(apiProducts);

    batchPricingDropdownList.clear();
    _enterProductCount.clear();
    tempBatchPricingList.clear();
    canShowPriceEditField.clear();
    _finalPriceEditController.clear();

    if (_responseProducts.isEmpty) {
      setState(() => showLoaderText = Constants.NO_DATA_FOUND);
      return;
    }

    // -------------------------------------------
    // STAGE 1: Build ModelProduct list (without UI lists)
    // -------------------------------------------
    List<ModelProduct> selectedTop = [];
    List<ModelProduct> unselected = [];

    for (var item in _responseProducts) {
      // Remove zero-quantity batches
      item.batchPrice?.removeWhere((b) => b.quantity == 0);

      if (item.batchPrice == null || item.batchPrice!.isEmpty) continue;

      // Find first usable batch
      final validBatch = item.batchPrice!.firstWhere(
        (b) => b.quantity != 0 && b.price != 0,
        orElse: () => BatchPriceDAO(price: 0, quantity: 0),
      );

      if (validBatch.price == 0) continue;

      // Build ModelProduct
      final model = ModelProduct(
          offerList: item.offers,
          id: item.id,
          name: item.name,
          counter: 0,
          isButton: false,
          images: item.images,
          price: 0,
          counterNew: 0,
          quantity: validBatch.quantity,
          isItemSelected: false,
          batchPriceList: item.batchPrice,
          quantityIn: validBatch.quantityIn,
          unitPrice: validBatch.price,
          selectedUnit: validBatch.quantityIn);

      // Check if previously selected (from widget or runtime barcode selection)
      int selectedIndex =
          widget.selectedProducts?.indexWhere((e) => e.id == model.id) ?? -1;

      // Also check runtime _selectedProducts (e.g. barcode-added)
      int runtimeIndex = _selectedProducts.indexWhere((e) => e.id == model.id);

      if (runtimeIndex != -1) {
        // Restore from runtime selection (barcode scan)
        final old = _selectedProducts[runtimeIndex];
        model.counterNew = old.counterNew;
        model.counter = old.counterNew?.toInt();
        model.price = old.price;
        model.unitPrice = old.unitPrice;
        model.batchNumber = old.batchNumber;
        model.selectedUnit = old.selectedUnit;

        selectedTop.add(model);
      } else if (selectedIndex != -1) {
        // Restore previous selection from widget
        final old = widget.selectedProducts![selectedIndex];
        model.counterNew = old.quantity;
        model.counter = old.quantity?.toInt();
        model.price = (old.quantity ?? 0) * validBatch.price!;
        model.batchNumber = validBatch.batchNumber;

        selectedTop.add(model);
        // Only add if not already in _selectedProducts (avoids duplicates on repeated search)
        if (_selectedProducts.indexWhere((e) => e.id == model.id) == -1) {
          _selectedProducts.add(model);
        }
      } else {
        unselected.add(model);
      }
    }

    // -------------------------------------------
    // STAGE 2: Merge Selected FIRST + then others
    // -------------------------------------------
    _productsList.clear();
    _productsList.addAll(selectedTop);
    _productsList.addAll(unselected);

    // -------------------------------------------
    // STAGE 3: Now build UI state lists in correct order
    // -------------------------------------------
    for (int i = 0; i < _productsList.length; i++) {
      final model = _productsList[i];

      // Dropdown
      batchPricingDropdownList.add(null);
      // tempBatchPricingList.add(null);
      final firstBatch = model.batchPriceList!.first;
      tempBatchPricingList.add(BatchPriceDAO.clone(firstBatch));

      // Price edit field
      int sIndex = _selectedProducts.indexWhere((e) => e.id == model.id);
      canShowPriceEditField.add(
        sIndex != -1
            ? (_selectedProducts[sIndex].isPriceChanged ?? false)
            : false,
      );

      // Quantity controller
      final qtyCtrl = TextEditingController(
        text: model.counterNew != null && model.counterNew! > 0
            ? model.counterNew.toString()
            : "",
      );
      qtyCtrl.selection = TextSelection.fromPosition(
        TextPosition(offset: qtyCtrl.text.length),
      );
      _enterProductCount.add(qtyCtrl);

      // Batch price edit controller
      _finalPriceEditController.add(TextEditingController());
    }

    setState(() {
      // refresh UI
    });

    updateProductsList(_productsList);

    /// Keep barcode-added product on top after search
    if (lastBarcodeProductId != null) {
      final index =
          _productsList.indexWhere((p) => p.id == lastBarcodeProductId);

      if (index > 0) {
        moveProductToTop(index);
      }
    }
  }

  num getTotalPriceForProduct(int index) {
    num price = 0;
    for (int i = 0; i < _selectedProducts.length; i++) {
      if (_selectedProducts[i].id == _productsList[index].id) {
        price = _selectedProducts[i].price!;
      }
    }
    return price;
  }

  Future<List<BuProductModal>> getProductsByBuId(parmsurl) async {
    Map<String, dynamic> mapData = {
      "name": parmsurl,
      "for_sale": true,
      "isDesc": true
    };
    List<BuProductModal> _products = await ProductsApiService.instance
        .getBuProducts(
            context: context,
            buId: buId!,
            mapFilter: mapData,
            langError: Language().getString(Constants.ERROR, selectedLang),
            langOk: Language().getString(Constants.OKAY_STR, selectedLang));

    setState(() {
      isLoadingProgress = false;
    });

    return _products;
  }

  @override
  void setState(VoidCallback fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  int canShowBottomView() {
    int count = 0;
    for (var element in _selectedProducts) {
      if (element.counterNew! > 0) {
        count++;
      }
    }
    return count;
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
        body: Stack(
      children: [
        SafeArea(
          child: Scaffold(
            key: _scaffoldkey,
            backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
            appBar: AppBar(
                backgroundColor:
                    Colors.transparent, //Color(Constants.APP_COLOR),
                centerTitle: true,
                elevation: 0,
                iconTheme: IconThemeData(color: theme.colorScheme.primary),
                title: AppbarName(
                    title: Language().getString(
                        widget.isQuotation!
                            ? 'New Quotation'
                            : Constants.FILL_ORDER_FORM,
                        selectedLang),
                    buName: '$buName')),
            bottomNavigationBar:
                (canShowBottomView() > 0) ? viewBottomView() : null,
            body: Container(
              margin: EdgeInsets.symmetric(horizontal: 10.0, vertical: 5.0),
              child: Column(
                children: [
                  this.buildSearchFilterView(),
                  (_productsList.length > 0)
                      ? productsGridView()
                      : Center(
                          child: Text(Language()
                              .getString(showLoaderText, selectedLang)),
                        )
                ],
              ),
            ),
          ),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress)
      ],
    ));
  }

  Widget buildSearchFilterView() {
    Widget searchBox = Expanded(
      child: Container(
        margin: EdgeInsets.symmetric(vertical: 5.0),
        decoration: AppUtills.boxDecoration(),
        height: 40.0,
        child: Row(
          children: [
            Expanded(
              child: Container(
                padding: EdgeInsets.all(2.0),
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(5.0)),
                child: TextFormField(
                  controller: _searchController,
                  decoration: InputDecoration(
                      contentPadding: EdgeInsets.only(
                          bottom: Constants.CONTENT_PADDING_18_15),
                      border: InputBorder.none,
                      hintText: Language()
                          .getString(Constants.SEARCH_BY_PRODUCT, selectedLang),
                      hintStyle: TextStyle(
                        fontSize: 13.0,
                      )),
                  onChanged: onChangeText,
                ),
              ),
            ),
            (_searchController.text.isNotEmpty)
                ? Container(
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                          topRight: Radius.circular(5.0),
                          bottomRight: Radius.circular(5.0),
                        )),
                    child: IconButton(
                        icon: Icon(
                          Icons.close,
                          color: Colors.red,
                        ),
                        onPressed: () {
                          _searchController.clear();
                          onChangeText(_searchController.text);
                        }),
                  )
                : Container(),
            if (!kIsWeb)
              Container(
                child: IconButton(
                  icon: Icon(Icons.qr_code_scanner,
                      color: theme.colorScheme.primary, size: 20.0),
                  onPressed: _scanBarcode,
                  tooltip: 'Scan Barcode',
                ),
              ),
            Container(
              child: IconButton(
                icon: Icon(Icons.qr_code_outlined,
                    color: theme.colorScheme.primary, size: 20.0),
                onPressed: () => showBarcodePopup(context),
                tooltip: 'Edit Barcode',
              ),
            ),
          ],
        ),
      ),
    );

    Widget addProductButton = ElevatedButton(
      onPressed: () {
        showAddProductPopup(context).then((value) async {
          if (value != null) {
            await loadProductData("");
            
            String? newProductId;
            if (value is Map) {
              newProductId = value["id"] ?? value["_id"] ?? value["productId"];
            }
            
            if (newProductId != null) {
              int index = _productsList.indexWhere((p) => p.id == newProductId);
              if (index != -1) {
                addProductsQuantity(index);
              }
            } else if (value is Map && value.containsKey("name")) {
              int index = _productsList.indexWhere((p) => p.name == value["name"]);
              if (index != -1) {
                addProductsQuantity(index);
              }
            }
          }
        });
      },
      child: Text("Add Product"),
      style: ElevatedButton.styleFrom(
        backgroundColor: theme.colorScheme.primary,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8.0),
        ),
        padding: kIsWeb ? EdgeInsets.symmetric(horizontal: 10) : null,
      ),
    );

    if (kIsWeb) {
      return Row(
        children: [
          searchBox,
          SizedBox(width: 5),
          Container(
            height: 40,
            child: addProductButton,
          ),
        ],
      );
    } else {
      return Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(children: [searchBox]),
          SizedBox(height: 10),
          Container(
            height: 45,
            width: double.infinity,
            child: addProductButton,
          ),
        ],
      );
    }
  }

  onChangeText(String text) {
    showLoaderText = Constants.LOADING;
    if (text.isEmpty) {
      isSearchForParams = false;
      loadProductData("");
    } else {
      isSearchForParams = true;
      loadProductData(text);
    }
  }

  getButtonText() {
    if (widget.isQuotation!) {
      return Language().getString(Constants.GENERATE_QUOTATION, selectedLang) +
          " (${canShowBottomView()})";
    } else if (widget.isChallan!) {
      return Language().getString(Constants.GENERATE_CHALLAN, selectedLang) +
          " (${canShowBottomView()})";
    } else {
      return Language().getString(Constants.GENERATE_INVOICE, selectedLang) +
          " (${canShowBottomView()})";
    }
  }

  Widget viewBottomView() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (widget.isQuotation!)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 5),
            child: Row(
              // crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Container(
                  height: 25.0,
                  width: 25.0,
                  child: Checkbox(
                    activeColor: Color(Constants.APP_COLOR),
                    value: buyer_consent_selected,
                    onChanged: (value) {
                      setState(() {
                        buyer_consent_selected = value ?? false;
                      });
                    },
                  ),
                ),
                Container(
                  child: Text(
                    Language().getString(
                        Constants.BUYER_MUST_ACCEPT_QUOTATION, selectedLang),
                    style: TextStyle(
                      color: Colors.black,
                    ),
                  ),
                )
              ],
            ),
          ),
        if (!widget.isChallan! && !widget.isQuotation!)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 5),
            child: Column(
              children: [
                // Additional Charges Button with Eye Icon
                Row(
                  children: [
                    Expanded(
                      child: AdditionalChargeButton(
                        selectedLang: selectedLang!,
                        buttonText: "Add additional charges ${additionalCharges.length > 0 ? "(${additionalCharges.length})" : ""}",
                        onAdd: (label, amount) {
                          setState(() {
                            additionalCharges.add({
                              "label": label,
                              "value": amount,
                            });
                          });
                        },
                      ),
                    ),
                    if (additionalCharges.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(left: 10.0),
                        child: InkWell(
                          onTap: _showAdditionalChargesPopup,
                          child:  Icon(
                              Icons.visibility,
                              color: Color(Constants.APP_COLOR),
                              size: 20.0,
                          ),
                        ),
                      ),
                  ],
                ),
                SizedBox(height: 8.0),
                // Back Date Invoice Button
                Row(
                  children: [
                    BackDropInvoiceDateButton(
                        selectedLang: selectedLang!,
                        buttonText: "Back date invoice",
                        onSelected: (val1) {
                          print("selected date: " + val1);
                          setState(() {
                            backDateInvoice = val1;
                          });
                        }),
                    SizedBox(
                      width: 10.0,
                    ),
                    Text(
                      backDateInvoice != null ? ": ${backDateInvoice!}" : "",
                      style: TextStyle(
                          color: Colors.black, fontWeight: StyleView.fontMedium),
                    )
                  ],
                ),
              ],
            ),
          ),
        Container(
            margin: EdgeInsets.symmetric(horizontal: 5.0),
            padding: EdgeInsets.all(10),
            child: CommonButtonsView(
              context: context,
              b1Text: Language().getString(Constants.STR_CANCEL, selectedLang),
              b2Text: getButtonText(),
              onb1Action: () => Navigator.of(context).pop(),
              onb2Action: () {
                if (widget.isQuotation!) {
                  serviceCallQuotation();
                } else {
                  showConfirmationPopup();
                }
              },
            )),
      ],
    );
  }

  postBodyForProductsBuy() async {
    setState(() {
      isLoadingProgress = true;
    });

    Map data = {
      "id": "",
      "is_offline": true,
      "order_type": "offline_direct_sell",
      "buyer": {
        "id": widget.recordId,
        "name": widget.contactName,
        "is_offline": true
      },
      "sender": {
        "id": buId,
      },
      "seller": {
        "id": buId,
        "name": buName,
      },
      "ctr": {"type": "", "Agent": "", "transaction_ref": ""},
      "discussion": {
        "initiator": widget.recordId,
        "initiator_user": widget.contactName,
        "message_start_date": "",
        "confirmation_message": [],
        "confirmation_status": ""
      }
    };

    if (widget.orderFormId != null && widget.orderFormId!.isNotEmpty) {
      data["order_form_id"] = widget.orderFormId;
    }

    String body = json.encode(data);
    // print("FILL: begin: $body");
    var response = await _transactionService
        .beginTransaction(body, AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);
      if (await NetworkStatus.getInternetStatus()) {
        prepareTransactionsProductsBody(data);
      } else {
        AppUtills.showSnackBar(_scaffoldkey,
            Language().getString(Constants.NO_INTERNET, selectedLang),
            snackBarBgColor: Colors.black,
            messageColor: Colors.white,
            buttonColor: Colors.white);
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  prepareTransactionsProductsBody(String? transactionId) async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = Constants.SENDING_PRODUCTS;
    });

    List<Map<String, dynamic>> productsArray = [];
    var productsObject;
    for (int i = 0; i < _selectedProducts.length; i++) {
      if (_selectedProducts[i].counterNew! > 0) {
        num quantity = (_selectedProducts[i].selectedUnit == 'gram' ||
                _selectedProducts[i].selectedUnit == 'ml')
            ? _selectedProducts[i].counterNew! / 1000
            : _selectedProducts[i].counterNew!;
        productsObject = {
          "id": _selectedProducts[i].id,
          "unit_price": _selectedProducts[i].price,
          "quantity": quantity, //_selectedProducts[i].counterNew,
          "total": _selectedProducts[i].price,
          "offer_selected": _selectedProducts[i].isButton
        };
        productsArray.add(productsObject);
      }
    }

    Map data = {
      "id": transactionId,
      "order_details": {
        "user_id": userId,
        "user_name": userName,
        "products": productsArray
      }
    };
    String body = json.encode(data);
    // print("FILL: transaction: $body");
    var response = await _transactionService
        .createPlaceOrder(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
        progressMessage = "";
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    setState(() {
      isLoadingProgress = false;
      progressMessage = "";
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      if (await NetworkStatus.getInternetStatus()) {
        serviceCallInvoice(transactionId);
      } else {
        AppUtills.showSnackBar(_scaffoldkey,
            Language().getString(Constants.NO_INTERNET, selectedLang),
            snackBarBgColor: Colors.black,
            messageColor: Colors.white,
            buttonColor: Colors.white);
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  naviToTransactionPage(String transactionId) {
    Navigator.push(
      context,
      new MaterialPageRoute(
        builder: (context) => ListOfTransactionsPage(
          transactionId: transactionId,
        ),
      ),
    );
  }

  showAvailableOffer(int index) {
    OffersDAO? _avilableOffer;
    for (int i = 0; i < _productsList[index].offerList!.length; i++) {
      if (_productsList[index].offerList![i].isOfferActive! &&
          !_productsList[index].offerList![i].isOfferExpired!) {
        _avilableOffer = _productsList[index].offerList![i];
      }
    }

    if (_avilableOffer != null) {
      for (var element in _selectedProducts) {
        if (_productsList[index].id == element.id) {
          _productsList[index].isButton = element.offerSelected;
        }
      }
      return Container(
        margin: EdgeInsets.symmetric(
          vertical: 7.0,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Container(
              margin: EdgeInsets.symmetric(
                horizontal: 5.0,
              ),
              child: SizedBox(
                height: 20.0,
                width: 20.0,
                child: Checkbox(
                    activeColor: StyleView.offerColor,
                    value: _productsList[index].isButton,
                    onChanged: (bool? value) {
                      CommonMethods.hideKeyboard(context);
                      setState(() {
                        _productsList[index].isButton = value;
                        for (int i = 0; i < _selectedProducts.length; i++) {
                          if (_productsList[index].id ==
                              _selectedProducts[i].id) {
                            _selectedProducts[i].offerSelected = value;
                          }
                        }
                      });
                    }),
              ),
            ),
            InkWell(
                onTap: () {
                  CommonMethods.hideKeyboard(context);

                  Dialogs.showOffer(
                      context,
                      _avilableOffer!.offerQuantity,
                      _avilableOffer.offerName,
                      _avilableOffer.minOrder,
                      _avilableOffer.maxOrder,
                      _avilableOffer.offerType);
                },
                child: Container(
                  margin: EdgeInsets.symmetric(
                    horizontal: 5.0,
                  ),
                  child: Text(
                    Language().getString(Constants.OFFER, selectedLang),
                    style: TextStyle(
                        fontSize: 14.0,
                        fontWeight: FontWeight.bold,
                        color: StyleView.offerColor,
                        decoration: TextDecoration.underline),
                  ),
                )),
          ],
        ),
      );
    } else {
      return Container();
    }
  }

  void _showAdditionalChargesPopup() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          Language().getString("Additional Charges", selectedLang),
          style: TextStyle(
            color: Color(Constants.APP_COLOR),
            fontWeight: FontWeight.bold,
          ),
        ),
        content: SingleChildScrollView(
          child: Container(
            width: double.maxFinite,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (additionalCharges.isEmpty)
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Text(
                      "No additional charges added",
                      style: TextStyle(
                        color: Colors.grey,
                        fontSize: 14,
                      ),
                    ),
                  )
                else
                  ListView.builder(
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    itemCount: additionalCharges.length,
                    itemBuilder: (context, index) {
                      final charge = additionalCharges[index];
                      return Container(
                        margin: EdgeInsets.symmetric(vertical: 8.0),
                        padding: EdgeInsets.all(12.0),
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.grey[300]!),
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    charge["label"] ?? "",
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 14,
                                      color: Colors.black,
                                    ),
                                  ),
                                  SizedBox(height: 4.0),
                                  Text(
                                    "$orgCurrencySymbol ${charge["value"]}",
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: Colors.grey[600],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            InkWell(
                              onTap: () {
                                setState(() {
                                  additionalCharges.removeAt(index);
                                });
                                Navigator.pop(context);
                                // Show popup again if charges still exist
                                if (additionalCharges.isNotEmpty) {
                                  Future.delayed(Duration(milliseconds: 300), () {
                                    _showAdditionalChargesPopup();
                                  });
                                }
                              },
                              child: Icon(
                                Icons.delete,
                                color: Colors.red,
                                size: 20.0,
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              Language().getString("Close", selectedLang),
              style: TextStyle(
                color: Color(Constants.APP_COLOR),
                fontSize: 16,
              ),
            ),
          ),
        ],
      ),
    );
  }

  showConfirmationPopup() {
    return showDialog(
      context: context,
      barrierColor: Colors.black54,
      barrierDismissible: false,
      builder: (context) => StatefulBuilder(builder: (context, setState) {
        return AlertDialog(
          actions: [
            Container(
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    TextButton(
                      onPressed: () {
                        Navigator.of(context).pop();
                        setState(() {
                          isIncludeGST = true;
                          addAdditionalDiscount = false;
                          radioButtonValue = Constants.OFFER_IN_PERCENTAGE;
                          discountType = "percent";
                        });
                        _rupeeController.clear();
                        offerInPercentage = null;
                        // radioButtonValue = null;
                      },
                      child: Text(
                        Language()
                            .getString(Constants.STR_CANCEL, selectedLang),
                        style: TextStyle(
                          color: Colors.red,
                          fontSize: 18.0,
                        ),
                      ),
                    ),
                    TextButton(
                      onPressed: () async {
                        Navigator.of(context).pop();
                        if (await NetworkStatus.getInternetStatus()) {
                          if (widget.isQuotation!) {
                            serviceCallQuotation();
                          } else if (widget.isChallan!) {
                            serviceCallChallan();
                          } else {
                            postBodyForProductsBuy();
                          }
                        } else {
                          AppUtills.showSnackBar(
                              _scaffoldkey,
                              Language().getString(
                                  Constants.NO_INTERNET, selectedLang),
                              snackBarBgColor: Colors.black,
                              messageColor: Colors.white,
                              buttonColor: Colors.white);
                        }
                      },
                      child: Text(
                        Language().getString(
                            widget.isQuotation!
                                ? Constants.GENERATE_QUOTATION
                                : widget.isChallan!
                                    ? Constants.GENERATE_CHALLAN
                                    : Constants.GENERATE_INVOICE,
                            selectedLang),
                        style: TextStyle(
                          color: Color(Constants.APP_COLOR),
                          fontSize: 18.0,
                        ),
                      ),
                    ),
                    // TextButton(
                    //   onPressed: () {
                    //     Navigator.of(context).pop();
                    //     showInvoiceDiscountPopup();
                    //   },
                    //   child: Text(
                    //     Language()
                    //         .getString(Constants.YES_STRING, selectedLang),
                    //     style: TextStyle(
                    //       color: Color(Constants.APP_COLOR),
                    //       fontSize: 18.0,
                    //     ),
                    //   ),
                    // ),
                  ]),
            )
          ],
          contentPadding: EdgeInsets.fromLTRB(25.0, 25.0, 10.0, 25.0),
          content: SingleChildScrollView(
            child: Container(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  buildIncludeGSTView(setState),
                  SizedBox(
                    height: 5.0,
                  ),
                  Divider(
                    color: Colors.grey,
                    thickness: 1,
                  ),
                  SizedBox(
                    height: 5.0,
                  ),
                  buildAdditionalDiscountView(setState),
                  SizedBox(
                    height: 10.0,
                  ),
                  addAdditionalDiscount
                      ? buildAdditionalDiscountSelectionView(setState)
                      : Container(),
                ],
              ),
            ),
          ),
        );
      }),
    );
  }

  buildAdditionalDiscountSelectionView(StateSetter setState) {
    // radioButtonValue = Constants.OFFER_IN_PERCENTAGE;
    // discountType = "percent";
    return Container(
      // height: 350.0,
      child: Column(
        children: [
          Container(
            child: Row(
              children: [
                Radio(
                    activeColor: Color(Constants.APP_COLOR),
                    value: Constants.OFFER_IN_PERCENTAGE,
                    groupValue: radioButtonValue,
                    onChanged: (dynamic value) {
                      setState(() {
                        radioButtonValue = Constants.OFFER_IN_PERCENTAGE;
                        discountType = "percent";
                        _rupeeController.clear();
                      });
                    }),
                Expanded(
                  child: Text(
                    Language()
                        .getString(Constants.OFFER_IN_PERCENTAGE, selectedLang),
                    style: TextStyle(color: Color(Constants.APP_COLOR)),
                  ),
                ),
              ],
            ),
          ),
          Container(
            child: Row(
              children: [
                Radio(
                    activeColor: Color(Constants.APP_COLOR),
                    value: Constants.OFFER_IN_AMOUNT,
                    groupValue: radioButtonValue,
                    onChanged: (dynamic value) {
                      setState(() {
                        radioButtonValue = Constants.OFFER_IN_AMOUNT;
                        discountType = "number";

                        offerInPercentage = null;
                      });
                    }),
                Expanded(
                  child: Text(
                    Language().getString(
                            Constants.OFFER_IN_AMOUNT, selectedLang) +
                        " ( $orgCurrencySymbol ) ",
                    style: TextStyle(color: Color(Constants.APP_COLOR)),
                  ),
                ),
              ],
            ),
          ),
          (radioButtonValue == Constants.OFFER_IN_AMOUNT)
              ? buildInputFieldForAmount()
              : buildOfferPercentageDropdown(setState)
        ],
      ),
    );
  }

  buildAdditionalDiscountView(StateSetter setState) {
    return Container(
        child: Row(
      children: <Widget>[
        Container(
          child: Checkbox(
            activeColor: Color(Constants.APP_COLOR),
            value: addAdditionalDiscount,
            onChanged: (value) {
              setState(
                () {
                  addAdditionalDiscount = value!;
                  if (!value) {
                    radioButtonValue = Constants.OFFER_IN_PERCENTAGE;
                    discountType = "percent";
                    _rupeeController.clear();
                    offerInPercentage = null;
                  }
                },
              );
            },
          ),
        ),
        Expanded(
          child: Text(
            Language()
                .getString(Constants.ADD_ADDITIONAL_DISCOUNT, selectedLang),
            style: TextStyle(
              fontWeight: StyleView.fontMedium,
              color: Color(Constants.APP_COLOR),
              fontSize: 14,
            ),
          ),
        )
      ],
    ));
  }

  buildIncludeGSTView(StateSetter setState) {
    return Container(
        child: Row(
      children: <Widget>[
        Container(
          child: Checkbox(
            activeColor: Color(Constants.APP_COLOR),
            value: isIncludeGST,
            onChanged: (value) {
              setState(
                () {
                  isIncludeGST = value!;
                },
              );
            },
          ),
        ),
        Expanded(
          child: Text(
            "GST Invoice (GST added)",
            style: TextStyle(
              fontWeight: StyleView.fontMedium,
              color: Color(Constants.APP_COLOR),
              fontSize: 14,
            ),
          ),
        )
      ],
    ));
  }

  showInvoiceDiscountPopup() {
    radioButtonValue = Constants.OFFER_IN_PERCENTAGE;
    discountType = "percent";
    return showDialog(
        context: context,
        barrierColor: Colors.black54,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    _rupeeController.clear();
                    offerInPercentage = null;
                    radioButtonValue = null;
                  },
                  child: Text(
                    Language().getString(Constants.STR_CANCEL, selectedLang),
                    style: TextStyle(
                      color: Color(Constants.APP_COLOR),
                      fontSize: 18.0,
                    ),
                  ),
                ),
                TextButton(
                  onPressed: () async {
                    Navigator.of(context).pop();
                    if (await NetworkStatus.getInternetStatus()) {
                      postBodyForProductsBuy();
                    } else {
                      AppUtills.showSnackBar(
                          _scaffoldkey,
                          Language()
                              .getString(Constants.NO_INTERNET, selectedLang),
                          snackBarBgColor: Colors.black,
                          messageColor: Colors.white,
                          buttonColor: Colors.white);
                    }
                  },
                  child: Text(
                    Language().getString(Constants.OKAY_STR, selectedLang),
                    style: TextStyle(
                      color: Color(Constants.APP_COLOR),
                      fontSize: 18.0,
                    ),
                  ),
                ),
              ],
              contentPadding: EdgeInsets.fromLTRB(25.0, 25.0, 10.0, 25.0),
              content: StatefulBuilder(
                  builder: (BuildContext context, StateSetter setState) {
                return SingleChildScrollView(
                  child: Container(
                    // height: 350.0,
                    child: Column(
                      children: [
                        Container(
                          child: Row(
                            children: [
                              Radio(
                                  activeColor: Color(Constants.APP_COLOR),
                                  value: Constants.OFFER_IN_PERCENTAGE,
                                  groupValue: radioButtonValue,
                                  onChanged: (dynamic value) {
                                    setState(() {
                                      radioButtonValue =
                                          Constants.OFFER_IN_PERCENTAGE;
                                      discountType = "percent";
                                      _rupeeController.clear();
                                    });
                                  }),
                              Expanded(
                                child: Text(
                                  Language().getString(
                                      Constants.OFFER_IN_PERCENTAGE,
                                      selectedLang),
                                  style: TextStyle(
                                      color: Color(Constants.APP_COLOR)),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          child: Row(
                            children: [
                              Radio(
                                  activeColor: Color(Constants.APP_COLOR),
                                  value: Constants.OFFER_IN_AMOUNT,
                                  groupValue: radioButtonValue,
                                  onChanged: (dynamic value) {
                                    setState(() {
                                      radioButtonValue =
                                          Constants.OFFER_IN_AMOUNT;
                                      discountType = "number";

                                      offerInPercentage = null;
                                    });
                                  }),
                              Expanded(
                                child: Text(
                                  Language().getString(
                                          Constants.OFFER_IN_AMOUNT,
                                          selectedLang) +
                                      " ( $orgCurrencySymbol ) ",
                                  style: TextStyle(
                                      color: Color(Constants.APP_COLOR)),
                                ),
                              ),
                            ],
                          ),
                        ),
                        (radioButtonValue == Constants.OFFER_IN_AMOUNT)
                            ? buildInputFieldForAmount()
                            : buildOfferPercentageDropdown(setState)
                      ],
                    ),
                  ),
                );
              }),
            ));
  }

  buildInputFieldForAmount() {
    return Container(
      height: 40.0,
      margin: EdgeInsets.symmetric(
        vertical: 10.0,
      ),
      decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(
            color: Colors.grey,
          ),
          borderRadius: BorderRadius.circular(5.0)),
      child: Padding(
        padding: const EdgeInsets.all(5.0),
        child: TextFormField(
          controller: _rupeeController,
          keyboardType: TextInputType.numberWithOptions(signed: true),
          inputFormatters: [CommonMethods.inputTextFormatter(isNumber: true)],
          decoration: InputDecoration(
              border: InputBorder.none,
              hintText:
                  Language().getString(Constants.ENTER_AMOUNT, selectedLang),
              contentPadding: EdgeInsets.only(bottom: 10.0)),
        ),
      ),
    );
  }

  buildOfferPercentageDropdown(StateSetter setState) {
    return Container(
      margin: EdgeInsets.symmetric(
        vertical: 5.0,
      ),
      height: 50.0,
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(
          color: Colors.grey,
        ),
        borderRadius: BorderRadius.circular(5.0),
      ),
      padding: EdgeInsets.all(5),
      child: DropdownButton<String>(
        onTap: () {
          FocusScope.of(context).unfocus();
        },
        value: offerInPercentage,
        hint: new Text("%"),
        isExpanded: true,
        underline: SizedBox(),
        onChanged: (String? data) {
          setState(() {
            offerInPercentage = data;
          });
        },
        items: Constants.PERCENTAGELIST.map((String model) {
          return new DropdownMenuItem<String>(
            child: new Text(model),
            value: model,
          );
        }).toList(),
      ),
    );
  }

  void serviceCallInvoice(String? transactionId) async {
    setState(() {
      isLoadingProgress = true;
      progressMessage =
          Language().getString(Constants.GETTING_DATA, selectedLang);
    });
    List<Map<String, dynamic>?> productArrayList = [];
    var productObject;

    for (int i = 0; i < _selectedProducts.length; i++) {
      if (_selectedProducts[i].counterNew != 0) {
        num quantity = (_selectedProducts[i].selectedUnit == 'gram' ||
                _selectedProducts[i].selectedUnit == 'ml')
            ? _selectedProducts[i].counterNew! / 1000
            : _selectedProducts[i].counterNew!;
        productObject = {
          "id": _selectedProducts[i].id,
          "quantity": quantity, //_selectedProducts[i].counterNew,
          "unit_price": _selectedProducts[i].unitPrice,
          "offer_selected": _selectedProducts[i].offerSelected,
          "batch_no": _selectedProducts[i].batchNumber
        };
        productArrayList.add(productObject);
      }
    }

    List<String> splitValue = [];

    if (radioButtonValue == Constants.OFFER_IN_PERCENTAGE &&
        offerInPercentage != null) {
      splitValue = offerInPercentage!.split(" %");
    } else {
      splitValue
          .add(_rupeeController.text.isEmpty ? "0.0" : _rupeeController.text);
    }

    // Prepare additional charges
    List<Map<String, dynamic>> _additionalChargesData = [];
    for (var element in additionalCharges) {
      _additionalChargesData.add({
        "label": element["label"],
        "value": num.parse(element["value"] ?? "0")
      });
    }

    Map data = {
      "txnId": transactionId,
      "products": productArrayList,
      "term_type": "bu",
      "additional_discount_type": discountType,
      "additional_discount": double.parse(splitValue[0]),
      "include_gst": isIncludeGST,
    };

    if (_additionalChargesData.isNotEmpty) {
      data["additional_charges"] = _additionalChargesData;
    }

    if (backDateInvoice != null) {
      data["invoice_back_dt"] = backDateInvoice;
    }

    String body = json.encode(data);

    // print("FILL: sellinvoice: $body");

    var response = await _transactionService
        .generateTransactionInvoice(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          Language().getString(
              Constants.INVOICE_GENERATED_SUCCESSFULLY, selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
      if (action == DialogAction.yes) {
        Navigator.of(context).pop();
        naviToTransactionPage(transactionId!);
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  void serviceCallQuotation() async {
    setState(() {
      isLoadingProgress = true;
      progressMessage =
          Language().getString(Constants.GETTING_DATA, selectedLang);
    });
    List<Map<String, dynamic>?> productArrayList = [];
    var productObject;

    for (int i = 0; i < _selectedProducts.length; i++) {
      if (_selectedProducts[i].counterNew != 0) {
        num quantity = (_selectedProducts[i].selectedUnit == 'gram' ||
                _selectedProducts[i].selectedUnit == 'ml')
            ? _selectedProducts[i].counterNew! / 1000
            : _selectedProducts[i].counterNew!;
        productObject = {
          "id": _selectedProducts[i].id,
          "quantity": quantity, //_selectedProducts[i].counterNew,
          "unit_price": _selectedProducts[i].unitPrice,
          "offer_selected": _selectedProducts[i].offerSelected,
          "batch_no": _selectedProducts[i].batchNumber
        };
        productArrayList.add(productObject);
      }
    }

    List<String> splitValue = [];

    if (radioButtonValue == Constants.OFFER_IN_PERCENTAGE &&
        offerInPercentage != null) {
      splitValue = offerInPercentage!.split(" %");
    } else {
      splitValue
          .add(_rupeeController.text.isEmpty ? "0.0" : _rupeeController.text);
    }

    // Prepare additional charges
    // List<Map<String, dynamic>> _additionalChargesData = [];
    // for (var element in additionalCharges) {
    //   _additionalChargesData.add({
    //     "label": element["label"],
    //     "value": num.parse(element["value"] ?? "0")
    //   });
    // }

    Map data = {
      "bu": buId,
      "buyer": {
        "id": widget.recordId,
        "name": widget.contactName,
        "is_offline": true
      },
      "seller": {
        "id": buId,
        "name": buName,
      },
      "products": productArrayList,
      "additional_discount_type": discountType,
      "additional_discount": double.parse(splitValue[0]),
      "show_quotation_acceptance": buyer_consent_selected
      // "include_gst": isIncludeGST,
    };

    // if (_additionalChargesData.isNotEmpty) {
    //   data["additional_charges"] = _additionalChargesData;
    // }

    if (widget.transactionId != null) {
      data["transaction_id"] = widget.transactionId;
    } else {
      data["transaction_id"] = "new";
    }

    if (widget.orderFormId != null && widget.orderFormId!.isNotEmpty) {
      data["order_form_id"] = widget.orderFormId;
    }
    String body = json.encode(data);

    // print("FILL: sellinvoice: $body");

    var response = await _transactionService
        .generateQuotation(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      var transactionId = "";
      if (resObj != null && resObj['transaction_id'] != null) {
        transactionId = resObj['transaction_id'];
      }
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          Language().getString(
              Constants.QUOTATION_GENERATED_SUCCESSFULLY, selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
      if (action == DialogAction.yes) {
        Navigator.of(context).pop();
        if (widget.fromCreateTransaction!) {
          naviToTransactionPage(
              transactionId); // get transaction id from response if needed
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  void serviceCallChallan() async {
    setState(() {
      isLoadingProgress = true;
      progressMessage =
          Language().getString(Constants.GETTING_DATA, selectedLang);
    });
    List<Map<String, dynamic>?> productArrayList = [];
    var productObject;

    for (int i = 0; i < _selectedProducts.length; i++) {
      if (_selectedProducts[i].counterNew != 0) {
        productObject = {
          "id": _selectedProducts[i].id,
          "quantity": _selectedProducts[i].counterNew,
          "unit_price": _selectedProducts[i].unitPrice,
          "offer_selected": _selectedProducts[i].offerSelected,
          "batch_no": _selectedProducts[i].batchNumber
        };
        productArrayList.add(productObject);
      }
    }

    List<String> splitValue = [];

    if (radioButtonValue == Constants.OFFER_IN_PERCENTAGE &&
        offerInPercentage != null) {
      splitValue = offerInPercentage!.split(" %");
    } else {
      splitValue
          .add(_rupeeController.text.isEmpty ? "0.0" : _rupeeController.text);
    }

    // Prepare additional charges
    // List<Map<String, dynamic>> _additionalChargesData = [];
    // for (var element in additionalCharges) {
    //   _additionalChargesData.add({
    //     "label": element["label"],
    //     "value": num.parse(element["value"] ?? "0")
    //   });
    // }

    Map data = {
      "bu": buId,
      "buyer": {
        "id": widget.recordId,
        "name": widget.contactName,
        "is_offline": true
      },
      "seller": {
        "id": buId,
        "name": buName,
      },
      "products": productArrayList,
      "additional_discount_type": discountType,
      "additional_discount": double.parse(splitValue[0]),
      // "include_gst": isIncludeGST,
    };

    // if (_additionalChargesData.isNotEmpty) {
    //   data["additional_charges"] = _additionalChargesData;
    // }
    String body = json.encode(data);

    // print("FILL: sellinvoice: $body");

    var response = await _transactionService
        .generateChallan(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          Language().getString(
              Constants.CHALLAN_GENERATED_SUCCESSFULLY, selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
      if (action == DialogAction.yes) {
        Navigator.of(context).pop();
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  Widget productsGridView() {
    return Expanded(
        child: Container(
      margin: EdgeInsets.only(top: 16, bottom: 16),
      decoration: AppUtills.boxDecoration(),
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.all(5.0),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    Language().getString(Constants.PRODUCT_NAME, selectedLang),
                    style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                        fontWeight: FontWeight.bold),
                  ),
                ),
                Expanded(
                  child: Text(
                    Language().getString(Constants.QUANTITY, selectedLang),
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                        fontWeight: FontWeight.bold),
                  ),
                ),
                Expanded(
                  child: Text(
                    Language().getString(Constants.TOTAL_PRICE, selectedLang) +
                        " ( $orgCurrencySymbol )",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                        fontWeight: FontWeight.bold),
                  ),
                )
              ],
            ),
          ),
          Divider(color: Color(Constants.APP_COLOR)),
          Expanded(
            child: ListView.separated(
                shrinkWrap: true,
                separatorBuilder: (context, index) => new Divider(
                      color: Colors.transparent,
                      height: 0.0,
                    ),
                itemCount: _productsList.length,
                itemBuilder: (context, index) {
                  return Card(
                    child: Column(
                      children: [
                        ProductsCardView(
                          onRemoveProductQuantit: () {
                            if (_selectedProducts.length > 0)
                              removeProductsQuantity(index);
                          },
                          onAddProductQuantity: () {
                            addProductsQuantity(index);
                          },
                          desingQuntityField: Container(
                            width: 50.0,
                            height: 30.0,
                            alignment: Alignment.bottomCenter,
                            decoration: AppUtills.boxDecoration(),
                            child: _designQuantityInputField(index),
                          ),
                          productName: _productsList[index].name,
                          removeProduct: () async {
                            final action = await Dialogs.yesCancelDialog(
                                context,
                                Language()
                                    .getString(Constants.WARNING, selectedLang),
                                Language().getString(
                                    Constants.WARNING_TEXT, selectedLang),
                                Language().getString(
                                    Constants.OKAY_STR, selectedLang),
                                "",
                                false);

                            if (action == DialogAction.yes) {
                              setState(() {
                                _productsList.removeAt(index);
                                batchPricingDropdownList.removeAt(index);
                              });
                            }
                          },
                          productTotalPrice:
                              getProductPrice(index), //_productsList[index]
                          // .price, //getTotalPriceForProduct(index),
                          quantityIn:
                              _productsList[index].quantityIn, // <-- NEW
                          selectedUnit: AppUtills.sanitizeUnit(
                            _productsList[index].selectedUnit,
                            _productsList[index].quantityIn ?? '',
                          ),

                          onUnitChange: (unit) {
                            setState(() {
                              _productsList[index].selectedUnit = unit;

                              /// UPDATE MULTIPLIER
                              if (unit == "kg")
                                _productsList[index].unitMultiplier = 1;
                              if (unit == "gram")
                                _productsList[index].unitMultiplier = 0.001;

                              if (unit == "litre")
                                _productsList[index].unitMultiplier = 1;
                              if (unit == "ml")
                                _productsList[index].unitMultiplier = 0.001;

                              /// RECALCULATE PRICE
                              int sIndex = _selectedProducts.indexWhere(
                                  (e) => e.id == _productsList[index].id);

                              _productsList[index].price =
                                  _productsList[index].counterNew! *
                                      _productsList[index].unitPrice! *
                                      _productsList[index].unitMultiplier!;

                              if (sIndex != -1) {
                                final p = _selectedProducts[sIndex];
                                p.price = p.counterNew! *
                                    p.unitPrice! *
                                    _productsList[index].unitMultiplier!;
                                p.selectedUnit = unit;
                              }

                              calculateTotal(index);
                            });
                          },
                        ),
                        batchPricingDropdown(
                            _productsList[index].batchPriceList!, index),
                        this.showAvailableOffer(index)
                      ],
                    ),
                  );
                }),
          )
        ],
      ),
    ));
  }

  void removeProductsQuantity(int index) {
    num? countDecrement = _productsList[index].counterNew;
    int selectedProductIndex = getSelectedProductIndex(index);
    if (selectedProductIndex > -1) {
      countDecrement = _selectedProducts[selectedProductIndex].counterNew!;
    }

    countDecrement = (countDecrement! * 2 - 1).round() / 2;
    // countDecrement = countDecrement! - 1;
    if (countDecrement == 0) {
      final findIndex = _selectedProducts
          .indexWhere((element) => _productsList[index].id == element.id);
      if (findIndex != -1) {
        setState(() {
          _productsList[index].counterNew = countDecrement!;
          // totalInvoicePrice =
          //     totalInvoicePrice - tempBatchPricingList[index]!.price!;
          _productsList[index].price = 0;
          // _selectedProducts.removeAt(findIndex);
          _enterProductCount[index].text = "0";
        });
        // calculatePercentage();
      }
      return;
    }

    num multiplier =
        AppUtills.getUnitMultiplier(_productsList[index].selectedUnit);

    if (countDecrement > 0) {
      final findIndex = _selectedProducts
          .indexWhere((element) => _productsList[index].id == element.id);
      if (findIndex != -1) {
        setState(() {
          _productsList[index].counterNew = countDecrement!;
          _selectedProducts[findIndex].counterNew = countDecrement;
          _selectedProducts[findIndex].price =
              tempBatchPricingList[index]!.price! *
                  _productsList[index].counterNew! *
                  multiplier;
          // totalInvoicePrice =
          //     totalInvoicePrice - tempBatchPricingList[index]!.price!;
          _enterProductCount[index] = TextEditingController(
              text: _productsList[index].counterNew.toString());
          _enterProductCount[index].selection = TextSelection.fromPosition(
              TextPosition(offset: _enterProductCount[index].text.length));
        });
        // calculatePercentage();
        // calculateProductTotalPrice(
        //     findIndex, selectedProductsList[findIndex].counter);
      }
    }
    calculateTotal(index);
  }

  int getSelectedProductIndex(int index) {
    return _selectedProducts
        .indexWhere((element) => _productsList[index].id == element.id);
  }

  num getProductPrice(int index) {
    int finalIndex = _selectedProducts
        .indexWhere((element) => _productsList[index].id == element.id);
    if (finalIndex > -1) {
      // final multiplier = AppUtills.getUnitMultiplier(_selectedProducts[finalIndex].selectedUnit);
      return _selectedProducts[finalIndex].price!;
    } else {
      return _productsList[index].price!;
    }
  }

  void addProductsQuantity(int index) async {
    num countIncrement = _productsList[index].counterNew!;
    int selectedProductIndex = getSelectedProductIndex(index);
    if (selectedProductIndex > -1) {
      countIncrement = _selectedProducts[selectedProductIndex].counterNew!;
    }
    if (countIncrement == 0 && selectedProductIndex == -1) {
      countIncrement = countIncrement + 1;
      setState(() {
        _productsList[index].counterNew = countIncrement;
        _productsList[index].price = tempBatchPricingList[index]!.price! *
            _productsList[index].counterNew!;
        // totalInvoicePrice = totalInvoicePrice + _productsList[index].price!;
        _enterProductCount[index] = TextEditingController(
            text: _productsList[index].counterNew.toString());
        _enterProductCount[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _enterProductCount[index].text.length));
        _productsList[index].unitPrice = tempBatchPricingList[index]!.price!;
        _productsList[index].batchNumber =
            tempBatchPricingList[index]!.batchNumber;
        _selectedProducts.add(_productsList[index]);
      });
      // calculatePercentage();
      return;
    }

    countIncrement = countIncrement + 1;
    num multiplier =
        AppUtills.getUnitMultiplier(_productsList[index].selectedUnit);
    final maxQtyBase =
        batchPricingDropdownList[index]?.quantity ?? double.infinity;

    // Convert typed qty to base unit (kg/ltr)
    final qtyInBase = countIncrement * multiplier;

    // if (countIncrement > batchPricingDropdownList[index]!.quantity!)
    if (qtyInBase > maxQtyBase) {
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ALERT, selectedLang),
          Language().getString(
              "Entered Quantity ${countIncrement}${_productsList[index].selectedUnit} not available",
              selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
      if (action == DialogAction.yes) {
        return;
      }
    }

    if (selectedProductIndex != -1) {
      setState(() {
        _productsList[index].counterNew = countIncrement;
        _productsList[index].price =
            tempBatchPricingList[index]!.price! * qtyInBase;
        _selectedProducts[selectedProductIndex].counterNew = countIncrement;
        _selectedProducts[selectedProductIndex].price =
            tempBatchPricingList[index]!.price! * qtyInBase;
        _selectedProducts[selectedProductIndex].unitPrice =
            tempBatchPricingList[index]!.price!;
        _selectedProducts[selectedProductIndex].batchNumber =
            tempBatchPricingList[index]!.batchNumber;
        // totalInvoicePrice =
        //     totalInvoicePrice + tempBatchPricingList[index]!.price!;
        _enterProductCount[index] = TextEditingController(
            text: _productsList[index].counterNew.toString());
        _enterProductCount[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _enterProductCount[index].text.length));
      });
      // calculatePercentage();
    }

    calculateTotal(index);
  }

  Widget _designQuantityInputField(int index) {
    return Container(
      height: 60.0,
      width: 60.0,
      child: TextFormField(
        textAlign: TextAlign.center,
        enableInteractiveSelection: false,
        controller: _enterProductCount[index],
        decoration: InputDecoration(
          hintText: "0",
          contentPadding:
              EdgeInsets.only(bottom: Constants.CONTENT_PADDING_18_15),
          border: InputBorder.none,
        ),
        keyboardType:
            TextInputType.numberWithOptions(signed: true, decimal: true),
        style: TextStyle(fontSize: 12.0),
        inputFormatters: [
          new LengthLimitingTextInputFormatter(5),
          DecimalTextInputFormatter(decimalPlaces: 2),
        ],
        onFieldSubmitted: (value) {},
        onChanged: (value) async {
          if (value.isNotEmpty) {
            num countValue = num.parse(value);
            num multiplier =
                AppUtills.getUnitMultiplier(_productsList[index].selectedUnit);
            final maxQtyBase =
                batchPricingDropdownList[index]?.quantity ?? double.infinity;

            // Convert typed qty to base unit (kg/ltr)
            final qtyInBase = countValue * multiplier;

            // if (countIncrement > batchPricingDropdownList[index]!.quantity!)
            if (qtyInBase > maxQtyBase)
            // if (countValue > batchPricingDropdownList[index]!.quantity!)
            {
              await Dialogs.yesCancelDialog(
                  context,
                  Language().getString(Constants.ALERT, selectedLang),
                  Language().getString(
                      "Entered Quantity ${countValue}${_productsList[index].selectedUnit} not available",
                      selectedLang),
                  Language().getString(Constants.OKAY_STR, selectedLang),
                  "",
                  false);
              final previousQty = _productsList[index].counterNew!;
              _enterProductCount[index].text = previousQty.toString();
              _enterProductCount[index].selection = TextSelection.fromPosition(
                  TextPosition(offset: previousQty.toString().length));
              return;
            }

            if (_selectedProducts.length > 0) {
              final findIndex = _selectedProducts.indexWhere(
                  (element) => _productsList[index].id == element.id);

              if (findIndex != -1) {
                setState(() {
                  _selectedProducts[findIndex].counterNew = countValue;
                  _selectedProducts[findIndex].price =
                      tempBatchPricingList[index]!.price! * qtyInBase;
                  _productsList[index].price =
                      tempBatchPricingList[index]!.price! * qtyInBase;
                  _productsList[index].batchNumber =
                      tempBatchPricingList[index]!.batchNumber;
                  _selectedProducts[findIndex].batchNumber =
                      tempBatchPricingList[index]!.batchNumber;
                  // totalInvoicePrice =
                  //     totalInvoicePrice + _productsList[index].price!;
                });
                // calculatePercentage();
              } else {
                setState(() {
                  _productsList[index].counterNew = countValue;
                  _productsList[index].price =
                      tempBatchPricingList[index]!.price! * qtyInBase;
                  // totalInvoicePrice =
                  //     totalInvoicePrice + _productsList[index].price!;
                  _enterProductCount[index] = TextEditingController(
                      text: _productsList[index].counterNew.toString());
                  _enterProductCount[index].selection =
                      TextSelection.fromPosition(TextPosition(
                          offset: _enterProductCount[index].text.length));
                  _productsList[index].batchNumber =
                      tempBatchPricingList[index]!.batchNumber;
                  _selectedProducts.add(_productsList[index]);
                });
                // calculatePercentage();
              }
            } else {
              setState(() {
                _productsList[index].counterNew = countValue;
                _productsList[index].price =
                    batchPricingDropdownList[index]!.price! * qtyInBase;
                // totalInvoicePrice =
                //     totalInvoicePrice + _productsList[index].price!;
                _enterProductCount[index] = TextEditingController(
                    text: _productsList[index].counterNew.toString());
                _enterProductCount[index].selection =
                    TextSelection.fromPosition(TextPosition(
                        offset: _enterProductCount[index].text.length));
                _productsList[index].batchNumber =
                    tempBatchPricingList[index]!.batchNumber;
                _selectedProducts.add(_productsList[index]);
              });
              // calculatePercentage();
            }
          } else {
            final findIndex = _selectedProducts
                .indexWhere((element) => _productsList[index].id == element.id);
            if (findIndex != -1) {
              _selectedProducts.removeAt(findIndex);
            }
            setState(() {
              _selectedProducts = _selectedProducts;
              // totalInvoicePrice =
              //     totalInvoicePrice - _productsList[index].price!;
              _productsList[index].price = 0;
              _productsList[index].counterNew = 0;
              _enterProductCount[index].clear();
            });
            // calculatePercentage();
          }
          calculateTotal(index);
        },
      ),
    );
  }

  Widget batchPricingDropdown(List<BatchPriceDAO> batchNumberList, int index) {
    int selectedProductIndex = getSelectedProductIndex(index);
    if (batchNumberList.length > 0 && batchPricingDropdownList.length > 0) {
      if (batchPricingDropdownList[index] == null) {
        // batchPricingDropdownList[index] = batchNumberList[0];
        // batchPricingDropdownList[index]?.isBatchChecked = true;
        // _finalPriceEditController[index].text = "${batchNumberList[0].price}";
        // tempBatchPricingList[index] = BatchPriceDAO.clone(batchNumberList[0]);

        if (selectedProductIndex > -1) {
          _finalPriceEditController[index].text =
              "${_selectedProducts[selectedProductIndex].unitPrice}";
          BatchPriceDAO? selectedBatchPrice;
          for (var element in batchNumberList) {
            if (element.batchNumber ==
                _selectedProducts[selectedProductIndex].batchNumber) {
              selectedBatchPrice = element;
            }
          }
          if (selectedBatchPrice != null) {
            batchPricingDropdownList[index] = selectedBatchPrice;
            tempBatchPricingList[index] =
                BatchPriceDAO.clone(selectedBatchPrice);
          } else {
            batchPricingDropdownList[index] = batchNumberList[0];
            tempBatchPricingList[index] =
                BatchPriceDAO.clone(batchNumberList[0]);
          }
          tempBatchPricingList[index]?.price =
              _selectedProducts[selectedProductIndex].unitPrice;
        } else {
          batchPricingDropdownList[index] = batchNumberList[0];
          _finalPriceEditController[index].text = "${batchNumberList[0].price}";
          tempBatchPricingList[index] = BatchPriceDAO.clone(batchNumberList[0]);
        }
        batchPricingDropdownList[index]?.isBatchChecked = true;
      }

      return BatchPriceDropDownView(
          isFromRetailPage: true,
          canShowDynamicPricing: true,
          currentDropdownIndex: index,
          batchPricingList: batchNumberList,
          batchDropdown: batchPricingDropdownList,
          finalPriceEditController: _finalPriceEditController,
          canShowPriceEditField: canShowPriceEditField,
          canShowPrice: true,
          canShowEdit: true,
          editedPrice: tempBatchPricingList[index]?.price,
          selectedDropdownValue: (data) {
            // totalInvoicePrice = 0;
            batchPricingDropdownList[index] = data;
            tempBatchPricingList[index] = BatchPriceDAO.clone(data!);
            _finalPriceEditController[index].text = "${data.price}";
            for (var findIndex = 0;
                findIndex < _selectedProducts.length;
                findIndex++) {
              if (_productsList[index].id == _selectedProducts[findIndex].id) {
                setState(() {
                  canShowPriceEditField[index] = false;
                  num totalPriceValue =
                      (data!.price! * _selectedProducts[findIndex].counterNew!);
                  // batchPricingDropdownList[index] = data;
                  _selectedProducts[findIndex].price = totalPriceValue;
                  batchPricingDropdownList[index]?.isBatchChecked = true;

                  // _finalPriceEditController[index].text = "${data.price}";
                  // tempBatchPricingList[index] = BatchPriceDAO.clone(data);
                  tempBatchPricingList[index]?.isBatchChecked = true;
                  _selectedProducts[findIndex].batchNumber = data.batchNumber;
                });
              } else {
                setState(() {
                  batchPricingDropdownList[index]?.isBatchChecked = false;
                  tempBatchPricingList[index]?.isBatchChecked = false;
                });
              }

              // totalInvoicePrice += selectedProductsList[findIndex].price!;
            }
          },
          onEdit: (index) {
            setState(() {
              canShowPriceEditField[index!] = !canShowPriceEditField[index];
              int finalIndex = -1;
              for (int i = 0; i < _selectedProducts.length; i++) {
                if (_selectedProducts[i].id == _productsList[index].id) {
                  finalIndex = i;
                }
              }
              if (finalIndex > -1) {
                _selectedProducts[finalIndex].isPriceChanged =
                    canShowPriceEditField[index];
              } else {
                _selectedProducts.add(_productsList[index]);
                _selectedProducts[_selectedProducts.length - 1].isPriceChanged =
                    canShowPriceEditField[index];
              }
            });
            // print(index);
          },
          onChangeFinalPrice: (value) {
            // print(value);
            // print(index);
            // print(batchPricingDropdownList[index]?.batchNumber);
            if (value.isEmpty) {
              return;
            }
            num price = num.parse(value);
            if (price > 0) {
              // totalInvoicePrice = 0;
              setState(() {
                tempBatchPricingList[index]!.price = price;
              });

              for (var findIndex = 0;
                  findIndex < _selectedProducts.length;
                  findIndex++) {
                if (_productsList[index].id ==
                    _selectedProducts[findIndex].id) {
                  setState(() {
                    _selectedProducts[findIndex].unitPrice = price;
                    num totalPriceValue =
                        (price * _selectedProducts[findIndex].counterNew!);
                    _selectedProducts[findIndex].price = totalPriceValue;
                  });
                }
                // totalInvoicePrice += _selectedProducts[findIndex].price!;
              }
            }
          },
          strBatchPricing: Language().getString("Batch", selectedLang),
          strAvailableQuantity: Language().getString("Quantity", selectedLang));
    } else {
      return SizedBox();
    }
  }

  void calculateTotal(int index) {
    num invoiceTotal = 0;
    for (var i = 0; i < _productsList.length; i++) {
      for (var j = 0; j < _selectedProducts.length; j++) {
        if (_productsList[i].id == _selectedProducts[j].id) {
          // invoiceTotal += _productsList[i].price!;
          final multiplier =
              AppUtills.getUnitMultiplier(_productsList[i].selectedUnit);
          invoiceTotal += _productsList[i].price! * multiplier;
        }
      }
    }
    // setState(() {
    //   totalInvoicePrice = invoiceTotal;
    // });

    // calculatePercentage();
  }

  Future<void> _scanBarcode() async {
    final scannedBarcode = await Navigator.push<String>(
      context,
      MaterialPageRoute(builder: (_) => BarcodeScanPage()),
    );

    if (scannedBarcode != null && scannedBarcode.isNotEmpty) {
      productAddToCart(scannedBarcode);
    }
  }

  productAddToCart(String? barcode) {
    if (barcode != null && barcode.isNotEmpty) {
      // Find product by barcode
      final productIndex = _productsList.indexWhere((product) {
        // Check batch barcode first
        if (product.batchPriceList != null) {
          for (var batch in product.batchPriceList!) {
            if (batch.barcode == barcode) {
              return true;
            }
          }
        }
        // Check product barcode
        return false;
      });

      if (productIndex != -1) {
        // Product found — ensure batch pricing is initialized before adding
        final product = _productsList[productIndex];
        if (tempBatchPricingList[productIndex] == null &&
            product.batchPriceList != null &&
            product.batchPriceList!.isNotEmpty) {
          final firstBatch = product.batchPriceList!.first;
          tempBatchPricingList[productIndex] = BatchPriceDAO.clone(firstBatch);
          batchPricingDropdownList[productIndex] = firstBatch;
        }

        lastBarcodeProductId = product.id;
        addProductsQuantity(productIndex);
        moveProductToTop(productIndex);
      } else {
        // Product not found
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Product not found for barcode: $barcode'),
            duration: Duration(seconds: 2),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void showBarcodePopup(BuildContext context) {
    final TextEditingController barcodeController =
        TextEditingController(text: "");

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) {
        return Padding(
          padding: EdgeInsets.only(
            left: 16,
            right: 16,
            top: 16,
            bottom: MediaQuery.of(context).viewInsets.bottom + 16,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              /// Drag handle
              Container(
                width: 40,
                height: 4,
                margin: const EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(
                  color: Colors.grey.shade400,
                  borderRadius: BorderRadius.circular(4),
                ),
              ),

              /// Title
              const Text(
                "Enter Barcode",
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 12),

              /// Barcode Field
              TextField(
                controller: barcodeController,
                keyboardType: TextInputType.number,
                autofocus: true,
                decoration: InputDecoration(
                  hintText: "Enter barcode",
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ),

              const SizedBox(height: 16),

              /// Done Button
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: CommonMethods.elevatedButtonStyle(),
                  onPressed: () {
                    final barcode = barcodeController.text.trim();
                    Navigator.pop(context);

                    if (barcode.isNotEmpty) {
                      productAddToCart(barcode);
                    }
                  },
                  child: const Text("Done"),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void moveProductToTop(int index) {
    if (index == 0) return;

    setState(() {
      // Move product
      final product = _productsList.removeAt(index);
      _productsList.insert(0, product);

      // Move controllers in same order
      final qtyCtrl = _enterProductCount.removeAt(index);
      _enterProductCount.insert(0, qtyCtrl);

      final batchCtrl = batchPricingDropdownList.removeAt(index);
      batchPricingDropdownList.insert(0, batchCtrl);

      final tempBatch = tempBatchPricingList.removeAt(index);
      tempBatchPricingList.insert(0, tempBatch);

      final priceCtrl = _finalPriceEditController.removeAt(index);
      _finalPriceEditController.insert(0, priceCtrl);

      final canEdit = canShowPriceEditField.removeAt(index);
      canShowPriceEditField.insert(0, canEdit);
    });
  }

  void updateProductsList(List<ModelProduct> productsList) {
    for (var i = 0; i < productsList.length; i++) {
      ModelProduct itemData = productsList[i];
      final findIndex =
          _selectedProducts.indexWhere((element) => element.id == itemData.id);
      if (findIndex != -1) {
        final sel = _selectedProducts[findIndex];

        // Clone the EXISTING product so all UI fields (offerList, images,
        // isButton, unitMultiplier, quantity, etc.) are preserved.
        final updated = ModelProduct.clone(_productsList[i]);

        // Overlay the selected-product state
        updated.counter = sel.counter;
        updated.counterNew = sel.counterNew;
        updated.price = sel.price;
        updated.batchNumber = sel.batchNumber;
        updated.selectedUnit = sel.selectedUnit;
        updated.unitMultiplier = sel.unitMultiplier ?? 1;
        updated.unitPrice =
            (sel.batchPriceList != null && sel.batchPriceList!.isNotEmpty)
                ? (sel.batchPriceList![0].mrp ?? sel.unitPrice)
                : sel.unitPrice;

        _productsList[i] = updated;

        final counterText = (sel.counterNew != null && sel.counterNew! > 0)
            ? sel.counterNew.toString()
            : "";
        _enterProductCount[i] = TextEditingController(text: counterText);
        _enterProductCount[i].selection = TextSelection.fromPosition(
            TextPosition(offset: _enterProductCount[i].text.length));
      }
    }
    setState(() {
      _productsList = _productsList;
    });
  }
}
