import 'dart:async';
import 'dart:convert';

import 'package:flutter_native_contact_picker/model/contact.dart';
import 'package:vyaparlive/service/organization_service.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
// import 'package:fluttercontactpicker/fluttercontactpicker.dart';
// import 'package:flutter_native_contact_picker/flutter_native_contact_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/offline_connections/OfflineConnections.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/MyDrawer.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/BuBasicDataModel.dart';
import 'package:vyaparlive/model/BuListModel.dart';
import 'package:vyaparlive/model/CitiesDAO.dart';
import 'package:vyaparlive/model/CountryDAO.dart';
import 'package:vyaparlive/model/DepartmentDAO.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/StatesDAO.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:vyaparlive/service/Service.dart';
import 'package:http/http.dart' as http;
import 'package:vyaparlive/service/invitation_services.dart';
import 'package:vyaparlive/utills/SharePref.dart';

class CreateOfflineCustomerPage extends StatefulWidget {
  final String? buName;
  final String? buId;
  final bool isFromDrawer;
  final bool isForUpdate;
  final BuListModel? modelData;
  CreateOfflineCustomerPage(
      {this.buId = "",
      this.buName = "",
      this.isFromDrawer = false,
      this.isForUpdate = false,
      this.modelData});
  @override
  _CreateOfflineCustomerPageState createState() =>
      _CreateOfflineCustomerPageState();
}

class _CreateOfflineCustomerPageState extends State<CreateOfflineCustomerPage> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  StatesDAO? statesDropdownValue;
  List<String> _districtList = [];
  List<StatesDAO> _statesList = [];
  String? districtDropdownValue;
  List<CountryDAO> _countryList = [];
  CountryDAO? countryDropdownValue;
  List<String> _citiesList = [];
  String? citiesDropDownValue;
  late Service _service;
  bool isLoadingProgress = true;
  String progressMessage = Constants.GETTING_DATA;
  List<BuBasicDataModel> _bubasicdatamodel = [];
  BuBasicDataModel? dropdownValue;
  DepartmentDAO? departmentDropdownValue;
  late InvitationService _invitationService;
  final _buildinghouseNumberController = TextEditingController();
  final _buildingNoController = TextEditingController();
  final _buildingStreetNameController = TextEditingController();
  final _colonysectorarealocalityController = TextEditingController();
  final _plotController = TextEditingController();
  final _landmarkController = TextEditingController();
  final _postalCodeController = TextEditingController();
  final _usernamecontroller = TextEditingController();
  final _emailcontroller = TextEditingController();
  final _phonenumbercontroller = TextEditingController();
  final _gstNumberController = TextEditingController();
  String? userId = "";
  String? buId = "";
  String? buName = "";
  late OrganizationService _organizationService;
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _service = Service();
    _invitationService = InvitationService();
    _organizationService = new OrganizationService();
    SharePref().getUserId().then((value) {
      userId = value;
    });
    buId = AppController.instance.getMyBuId;
    buName = widget.buName!.isEmpty
        ? AppController.instance.getBuName
        : widget.buName;
    this.loadAllServiceCalls();
  }

  loadAllServiceCalls() async {
    if (widget.isForUpdate && widget.modelData != null) {
      _usernamecontroller.text = widget.modelData!.name!;
      _emailcontroller.text = widget.modelData!.emailId!;
      _phonenumbercontroller.text = widget.modelData!.contact!;
      _gstNumberController.text = widget.modelData!.gstNo!;
      if (widget.modelData!.address != null) {
        _buildinghouseNumberController.text =
            widget.modelData!.address!.buildinghousenumber!;
        _buildingNoController.text = widget.modelData!.address!.buildingNo!;
        _buildingStreetNameController.text =
            widget.modelData!.address!.buildingstreetname!;
        _colonysectorarealocalityController.text =
            widget.modelData!.address!.colonysectorArealocality!;
        _plotController.text = widget.modelData!.address!.plotNo!;

        _landmarkController.text = widget.modelData!.address!.landmark!;
        _postalCodeController.text = widget.modelData!.address!.postcode!;
      }
    }
    if (await NetworkStatus.getInternetStatus()) {
      await this.getAllBuBusinessData(userId).then((value) {
        setState(() {
          _bubasicdatamodel.clear();
          _bubasicdatamodel.addAll(value);
        });
      });

      await this.getCountries().then((value) {
        setState(() {
          _countryList.clear();
          _countryList.addAll(value);
        });
      });

      if (countryDropdownValue != null) {
        await this.getStates(countryDropdownValue!.name!).then((value) {
          setState(() {
            _statesList.clear();
            _statesList.addAll(value);
          });
        });
      }
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        if (widget.isFromDrawer) {
          return CommonMethods.onBackPress(context);
        } else {
          return true;
        }
      },
      child: AppBackgroundView(
          body: Stack(
        children: [
          SafeArea(
            child: Scaffold(
              key: _scaffoldkey,
              backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
              appBar: AppBar(
                  backgroundColor: Colors.transparent, //(Constants.APP_COLOR),
                  centerTitle: true,
                  elevation: 0,
                  iconTheme: IconThemeData(color: theme.colorScheme.primary),
                  title: AppbarName(
                      title: Language().getString(
                          Constants.ADD_OFFLINE_CUSTOMER, selectedLang),
                      buName: "$buName")),
              bottomNavigationBar: Container(
                  padding: EdgeInsets.symmetric(
                      horizontal: 10.0,
                      vertical: (defaultTargetPlatform == TargetPlatform.iOS)
                          ? 30
                          : 20),
                  child: CommonButtonsView(
                    context: context,
                    b1Text:
                        Language().getString(Constants.STR_CANCEL, selectedLang),
                    b2Text: Language().getString(Constants.CONFIRM, selectedLang),
                    onb1Action: () {
                      Navigator.of(context).pop();
                      departmentDropdownValue = null;
                      dropdownValue = null;
                    },
                    onb2Action: () async {
                      String errorMessage = validatingMandatoryFields();
            
                      if (errorMessage.isNotEmpty) {
                        Dialogs.yesCancelDialog(
                            context,
                            Language().getString(Constants.ERROR, selectedLang),
                            Language().getString(errorMessage, selectedLang),
                            Language()
                                .getString(Constants.OKAY_STR, selectedLang),
                            "",
                            false);
                      } else {
                        if (_emailcontroller.text.isNotEmpty) {
                          if (validateEmail(_emailcontroller.text)) {
                            this.offlineServiceCalls();
                          } else {
                            Dialogs.yesCancelDialog(
                                context,
                                Language()
                                    .getString(Constants.ERROR, selectedLang),
                                Language().getString(
                                    Constants.PLEASE_ENTER_EMAIL, selectedLang),
                                Language()
                                    .getString(Constants.OKAY_STR, selectedLang),
                                "",
                                false);
                          }
                        } else {
                          this.offlineServiceCalls();
                        }
                      }
                    },
                  )),
              drawer: (widget.isFromDrawer) ? MyDrawer() : null,
              body: SingleChildScrollView(
                  child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(children: <Widget>[
                  Container(
                      margin: EdgeInsets.symmetric(vertical: 5.0),
                      decoration: BoxDecoration(
                          border: Border.all(color: Colors.grey),
                          borderRadius: BorderRadius.circular(5)),
                      child: ExpansionTile(
                        initiallyExpanded: true,
                        title: Text(
                          Language()
                              .getString(Constants.OUR_BU_DETAILS, selectedLang),
                        ),
                        children: <Widget>[
                          Column(
                            children: <Widget>[
                              buildParentDetailsDropDown(
                                  Constants.BUSSINESS_INPUT_STRING, setState),
                            ],
                          ),
                        ],
                      )),
                  Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5),
                        border: Border.all(color: Colors.grey),
                      ),
                      child: ExpansionTile(
                          initiallyExpanded: true,
                          title: Text(
                            Language().getString(
                                Constants.CUSTOMER_BU_DETAILS, selectedLang),
                          ),
                          children: <Widget>[
                            Column(children: <Widget>[
                              buildTableContent(Constants.INVITEE_NAME_STRING,
                                  _usernamecontroller, false, true),
                              SizedBox(
                                  height: 1,
                                  child: new Container(
                                      color: Color(Constants.GREY_COLOR))),
                              Container(
                                padding: EdgeInsets.all(1),
                                child: Row(
                                  children: <Widget>[
                                    Expanded(
                                      child: Container(
                                          height: 50,
                                          color:
                                              Color(Constants.GREY_COLOR_LIGHT),
                                          child: Container(
                                            padding: EdgeInsets.only(left: 10),
                                            child: Align(
                                                alignment: Alignment.centerLeft,
                                                child: RichText(
                                                  text: TextSpan(children: [
                                                    TextSpan(
                                                      text: Language().getString(
                                                          Constants.MOBILE_NUMBER,
                                                          selectedLang),
                                                      style: TextStyle(
                                                          fontSize: StyleView
                                                              .FONT_SIZE_15,
                                                          fontFamily: StyleView
                                                              .FONT_TITLE,
                                                          color: Colors.black),
                                                    ),
                                                    TextSpan(
                                                        text: "\*",
                                                        style: TextStyle(
                                                            fontSize: StyleView
                                                                .FONT_SIZE_15,
                                                            color: Colors.red))
                                                  ]),
                                                )),
                                          )),
                                    ),
                                    Expanded(
                                        flex: 2,
                                        child: Row(
                                          children: [
                                            Expanded(
                                              flex: 1,
                                              child: Container(
                                                color: Colors.white70,
                                                padding: EdgeInsets.only(left: 5),
                                                child: TextFormField(
                                                  controller:
                                                      _phonenumbercontroller,
                                                  keyboardType:
                                                      (defaultTargetPlatform ==
                                                              TargetPlatform.iOS)
                                                          ? TextInputType
                                                              .numberWithOptions(
                                                                  signed: true)
                                                          : TextInputType.number,
                                                  textInputAction:
                                                      TextInputAction.next,
                                                  style: TextStyle(
                                                      fontFamily: 'IndianRupee'),
                                                  decoration: InputDecoration(
                                                    hintText: Language()
                                                        .getString(
                                                            Constants
                                                                .MOBILE_NUMBER,
                                                            selectedLang),
                                                    border: InputBorder.none,
                                                  ),
                                                  inputFormatters: [
                                                    CommonMethods
                                                        .inputTextFormatter(
                                                            isNumber: true)
                                                  ],
                                                  onChanged: (text) => {
                                                    text = _phonenumbercontroller
                                                        .text,
                                                  },
                                                ),
                                              ),
                                            ),
                                            Container(
                                              color: Colors.white70,
                                              child: IconButton(
                                                  icon: Icon(Icons.contact_phone),
                                                  onPressed: () async {
                                                    Contact? _contact =
                                                        await AppUtills
                                                            .getContactFromPhoneBook();
            
                                                    // PhoneNumber? number =
                                                    //     _contact.phoneNumber;
                                                    String number = "";
                                                    String fullName = "";
                                                    if(_contact!=null && _contact.phoneNumbers!.isNotEmpty){
                                                      number = _contact.phoneNumbers![0];
                                                    }
                                                    if(_contact!=null){
                                                      fullName = _contact.fullName!;
                                                    }
                                                    setState(() {
                                                      _phonenumbercontroller
                                                          .text = number;
                                                      _usernamecontroller.text =
                                                          fullName;
                                                    });
                                                  }),
                                            )
                                          ],
                                        ))
                                  ],
                                ),
                              ),
                              SizedBox(
                                  height: 1,
                                  child: new Container(
                                      color: Color(Constants.GREY_COLOR))),
                              buildTableContent(Constants.EMAIL, _emailcontroller,
                                  false, false),
                              SizedBox(
                                  height: 1,
                                  child: new Container(
                                      color: Color(Constants.GREY_COLOR))),
                              buildTableContent(Constants.GST_NO,
                                  _gstNumberController, false, false),
                            ]),
                          ])),
                  businessunitAddressDetails(setState),
                ]),
              )),
            ),
          ),
          AppUtills.showLoadingView(
              context: context,
              message: Language().getString(progressMessage, selectedLang),
              isLoading: isLoadingProgress),
        ],
      )),
    );
  }

  Future<List<CountryDAO>> getCountries() async {
    setState(() {
      isLoadingProgress = true;
    });
    http.Response response = await _service.get_countries();
    List<CountryDAO> list = [];
    setState(() {
      isLoadingProgress = false;
    });
    if (response.statusCode == 200) {
      var data = json.decode(response.body);
      if (data['data'] is String) {
        print("No data found");
      } else {
        for (var object in data["data"]) {
          list.add(CountryDAO.fromJaon(object));
        }

        if (list.length > 0 && widget.modelData != null && widget.isForUpdate) {
          for (int i = 0; i < list.length; i++) {
            if (widget.modelData!.address != null) {
              if (widget.modelData!.address!.country == list[i].name) {
                countryDropdownValue = list[i];
              }
            }
          }
        } else {
          for (int i = 0; i < list.length; i++) {
            if (list[i].name == "India") {
              setState(() {
                countryDropdownValue = list[i];
              });
            }
          }
        }
      }
    }
    return list;
  }

  Future<List<CitiesDAO>> getCitiesList(
      String? countryName, String? stateId) async {
    var resposne = await _service.getCities(countryName, stateId);
    List<CitiesDAO> _list = [];
    setState(() {
      isLoadingProgress = false;
    });

    if (resposne.statusCode == 200) {
      var data = json.decode(resposne.body);

      bool isString = false;

      if (data['data'] is String) {
        isString = true;
      }

      if (!isString) {
        for (var object in data['data']) {
          _list.add(CitiesDAO.fromJson(object));
        }

        if (_list.length > 0 &&
            widget.modelData != null &&
            widget.modelData!.address != null &&
            widget.isForUpdate) {
          for (int h = 0; h < _list[0].cities!.length; h++) {
            if (widget.modelData!.address!.villagetowncity ==
                _list[0].cities![h]) {
              setState(() {
                citiesDropDownValue = _list[0].cities![h];
              });
            }
          }
        }
      }
    }

    return _list;
  }

  /// Service callfor States

  Future<List<StatesDAO>> getStates(String countryName) async {
    setState(() {
      isLoadingProgress = true;
      _statesList.clear();
      statesDropdownValue = null;
    });

    http.Response response = await _service
        .getStatesByCountry(countryName)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<StatesDAO> list = [];
    setState(() {
      isLoadingProgress = false;
    });
    if (response.statusCode == 200) {
      var data = json.decode(response.body);
      for (var object in data["data"]) {
        for (var statesObject in object["states"])
          list.add(StatesDAO.fromJson(statesObject));
      }

      if (list.length > 0 &&
          widget.modelData != null &&
          widget.modelData!.address != null &&
          widget.isForUpdate) {
        for (int j = 0; j < list.length; j++) {
          if (widget.modelData!.address!.state == list[j].state) {
            statesDropdownValue = list[j];
            _districtList.clear();
            _districtList.addAll(list[j].cities!);
            this
                .getCitiesList(
                    countryDropdownValue!.name, statesDropdownValue!.id)
                .then((value) {
              if (value.length > 0) {
                setState(() {
                  _citiesList.clear();
                  _citiesList.addAll(value[0].cities!);
                });
              }
            });
          }
        }
      }

      for (int k = 0; k < _districtList.length; k++) {
        if (widget.modelData!.address!.district == _districtList[k]) {
          districtDropdownValue = _districtList[k];
        }
      }
    }

    return list;
  }

  buildParentDetailsDropDown(String textName, StateSetter setState) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                            Language().getString(textName, selectedLang),
                            style: TextStyle(
                                fontSize: StyleView.FONT_SIZE_15,
                                fontFamily: StyleView.FONT_TITLE))),
                  )),
            ),
            Expanded(
                flex: 2,
                child: Container(
                    height: 50,
                    padding: EdgeInsets.all(5),
                    decoration: BoxDecoration(color: Colors.white),
                    child: DropdownButton<BuBasicDataModel>(
                        value: dropdownValue,
                        isExpanded: true,
                        hint: Text(
                          Language()
                              .getString(Constants.SELECT_BU, selectedLang),
                        ),
                        underline: SizedBox(),
                        onChanged: (BuBasicDataModel? data) {
                          setState(() {
                            dropdownValue = data;
                          });
                        },
                        items: _bubasicdatamodel.map((BuBasicDataModel model) {
                          return new DropdownMenuItem<BuBasicDataModel>(
                            child: new Text(
                              model.businessName!,
                              style:
                                  TextStyle(fontFamily: StyleView.FONT_TITLE),
                            ),
                            value: model,
                          );
                        }).toList())))
          ],
        ));
  }

  String validatingMandatoryFields() {
    if (_usernamecontroller.text.isEmpty) {
      return Constants.PLEASE_ENTERPERSON_NAME_STRING;
    } else if (_phonenumbercontroller.text.isEmpty) {
      return Constants.ENTER_MOBILE_NUMBER;
    } else if (countryDropdownValue == null) {
      return Constants.PLEASE_SELECT_COUNTRY;
    } else if (statesDropdownValue == null) {
      return Constants.PLEASE_SELECT_STATE;
    } else if (districtDropdownValue == null) {
      return Constants.PLEASE_SELECT_DISTRICT;
    }
    // else if (citiesDropDownValue == null) {
    //   return Constants.PLEASE_SELECT_CITY;
    // }
    else {
      return "";
    }
  }

  createContact() async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = Constants.GETTING_DATA;
    });

    Map data = {
      "name": _usernamecontroller.text,
      "buId": dropdownValue != null ? dropdownValue!.id : "",
      "contact": _phonenumbercontroller.text,
      "email_id": _emailcontroller.text,
      "GST_No": _gstNumberController.text,
      "address": {
        "addressformat": "",
        "plot_no": _plotController.text,
        "businesslocationnumber": "",
        "buildinghousenumber": _buildinghouseNumberController.text,
        "building_no": _buildingNoController.text,
        "buildingstreetname": _buildingStreetNameController.text,
        "colonysector_arealocality": _colonysectorarealocalityController.text,
        "villagetowncity":
            citiesDropDownValue != null ? citiesDropDownValue : "",
        "taluk": "",
        "landmark": _landmarkController.text,
        "state": statesDropdownValue != null ? statesDropdownValue!.state : "",
        "district": districtDropdownValue != null ? districtDropdownValue : "",
        "postcode": _postalCodeController.text,
        "country":
            countryDropdownValue != null ? countryDropdownValue!.name : "",
      },
      "currency_code": countryDropdownValue != null
          ? countryDropdownValue!.currencyCode
          : "",
      "currency_symbol": countryDropdownValue != null
          ? countryDropdownValue!.currencySymbol
          : ""
    };

    String body = json.encode(data);
    var response = await _invitationService
        .createContact_grpc(body, AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          Language().getString(Constants.CONTACT_CREATED, selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
      if (action == DialogAction.yes) {
        if (widget.isFromDrawer) {
          Navigator.push(context,
              PageTransition(context: context, page: OfflineConnections()));
        } else {
          Navigator.of(context).pop();
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  updateContact() async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = Constants.GETTING_DATA;
    });

    Map data = {
      "id": widget.buId,
      "name": _usernamecontroller.text,
      "buId": dropdownValue != null ? dropdownValue!.id : "",
      "contact": _phonenumbercontroller.text,
      "email_id": _emailcontroller.text,
      "GST_No":_gstNumberController.text,
      "address": {
        "addressformat": "",
        "plot_no": _plotController.text,
        "businesslocationnumber": "",
        "buildinghousenumber": _buildinghouseNumberController.text,
        "building_no": _buildingNoController.text,
        "buildingstreetname": _buildingStreetNameController.text,
        "colonysector_arealocality": _colonysectorarealocalityController.text,
        "villagetowncity":
            citiesDropDownValue != null ? citiesDropDownValue : "",
        "taluk": "",
        "landmark": _landmarkController.text,
        "state": statesDropdownValue != null ? statesDropdownValue!.state : "",
        "district": districtDropdownValue != null ? districtDropdownValue : "",
        "postcode": _postalCodeController.text,
        "country":
            countryDropdownValue != null ? countryDropdownValue!.name : "",
      },
      "currency_code": countryDropdownValue != null
          ? countryDropdownValue!.currencyCode
          : "",
      "currency_symbol": countryDropdownValue != null
          ? countryDropdownValue!.currencySymbol
          : "",
      "country_code":
          countryDropdownValue != null ? countryDropdownValue!.code : ""
    };

    String body = json.encode(data);
    var response = await _invitationService
        .updateContactById(body, AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          Language().getString(Constants.CONNECTION_UPDATED, selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
      if (action == DialogAction.yes) {
        if (widget.isFromDrawer) {
          Navigator.push(context,
              PageTransition(context: context, page: OfflineConnections()));
        } else {
          Navigator.of(context).pop();
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    }

  buildTableContent(String textName, TextEditingController _controller,
      bool isKeyboard, bool isMandatory) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: (isMandatory)
                            ? RichText(
                                text: TextSpan(children: [
                                  TextSpan(
                                    text: Language()
                                        .getString(textName, selectedLang),
                                    style: TextStyle(
                                        fontSize: StyleView.FONT_SIZE_15,
                                        fontFamily: StyleView.FONT_TITLE,
                                        color: Colors.black),
                                  ),
                                  TextSpan(
                                      text: "\*",
                                      style: TextStyle(
                                          fontSize: StyleView.FONT_SIZE_15,
                                          color: Colors.red))
                                ]),
                              )
                            : Text(Language().getString(textName, selectedLang),
                                style: TextStyle(
                                    fontSize: StyleView.FONT_SIZE_15,
                                    fontFamily: 'IndianRupee'))),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5),
                  child: TextFormField(
                    controller: _controller,
                    enabled: (textName == Constants.COUNTRY_CODE_STRING
                        ? false
                        : true),
                    keyboardType: isKeyboard
                        ? TextInputType.numberWithOptions(signed: true)
                        : TextInputType.text,
                    style: TextStyle(fontFamily: 'IndianRupee'),
                    decoration: InputDecoration(
                      suffixIcon: textName == Constants.PHONE_NUMBER
                          ? IconButton(
                              icon: Icon(
                                Icons.contacts,
                                color: Color(Constants.APP_COLOR),
                                size: 20.0,
                              ),
                              onPressed: () async {})
                          : null,
                      hintText: textName == Constants.EMAIL
                          ? "name@business.com"
                          : Language().getString(textName, selectedLang),
                      border: InputBorder.none,
                    ),
                    inputFormatters: (textName == Constants.POST_CODE_STRING)
                        ? [
                            new LengthLimitingTextInputFormatter(6),
                            CommonMethods.inputTextFormatter(isNumber: true)
                          ]
                        : [],
                  )),
            )
          ],
        ));
  }

  Widget businessunitAddressDetails(StateSetter setState) {
    return Container(
      decoration: AppUtills.boxDecoration(),
      margin: EdgeInsets.symmetric(vertical: 10.0),
      child: Column(children: <Widget>[
        buildTableContent(Constants.PLOT_NO, _plotController, false, false),
        SizedBox(
            height: 1,
            child: Container(
              color: Color(Constants.GREY_COLOR),
            )),
        buildTableContent(Constants.BUILDING_HOUSE_NUMBER_STRING,
            _buildinghouseNumberController, false, false),
        SizedBox(
            height: 1,
            child: Container(
              color: Color(Constants.GREY_COLOR),
            )),
        buildTableContent(
            Constants.BULIDING, _buildingNoController, false, false),
        SizedBox(
            height: 1,
            child: Container(
              color: Color(Constants.GREY_COLOR),
            )),
        buildTableContent(Constants.BUILDING_STREET_NAME_STRING,
            _buildingStreetNameController, false, false),
        SizedBox(
            height: 1,
            child: Container(
              color: Color(Constants.GREY_COLOR),
            )),
        buildTableContent(Constants.COLONY_SELECTOR_AREA_LOCALITY_STRING,
            _colonysectorarealocalityController, false, false),
        SizedBox(
            height: 1,
            child: Container(
              color: Color(Constants.GREY_COLOR),
            )),
        buildTableContent(
            Constants.LAND_MARK_STRING, _landmarkController, false, false),
        SizedBox(
            height: 1,
            child: Container(
              color: Color(Constants.GREY_COLOR),
            )),
        buildCountryDropdown(Constants.COUNTRY_NAME_STRING, setState),
        SizedBox(
            height: 1,
            child: Container(
              color: Color(Constants.GREY_COLOR),
            )),
        buildStateDropdown(Constants.STATE_NAME_STRING, setState),
        SizedBox(
            height: 1,
            child: Container(
              color: Color(Constants.GREY_COLOR),
            )),
        buildDistrictDropdown(Constants.DISTRICT_STRING, setState),
        SizedBox(
            height: 1,
            child: Container(
              color: Color(Constants.GREY_COLOR),
            )),
        buildCityDropdown(Constants.CITY_NAME_STRING, setState),
        SizedBox(
            height: 1,
            child: Container(
              color: Color(Constants.GREY_COLOR),
            )),
        buildTableContent(
            Constants.POST_CODE_STRING, _postalCodeController, true, false),
      ]),
    );
  }

  buildCountryDropdown(String text, StateSetter setState) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: RichText(
                          text: TextSpan(children: [
                            TextSpan(
                              text: Language().getString(text, selectedLang),
                              style: TextStyle(
                                  fontSize: StyleView.FONT_SIZE_15,
                                  fontFamily: StyleView.FONT_TITLE,
                                  color: Colors.black),
                            ),
                            TextSpan(
                                text: "\*",
                                style: TextStyle(
                                    fontSize: StyleView.FONT_SIZE_15,
                                    color: Colors.red))
                          ]),
                        )),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5, right: 5),
                  child: GestureDetector(
                      onTap: () {
                        FocusScope.of(context).unfocus();
                        _showSearchDialog<CountryDAO>(
                          items: _countryList,
                          hintText: Language().getString(
                              Constants.SELECT_COUNTRY, selectedLang),
                          getName: (c) => c.name!,
                        ).then((data) {
                          if (data != null) {
                            setState(() {
                              countryDropdownValue = data;
                              statesDropdownValue = null;
                              citiesDropDownValue = null;
                              districtDropdownValue = null;
                              _statesList.clear();
                              _citiesList.clear();
                              _districtList.clear();
                            });
                            this
                                .getStates(countryDropdownValue!.name!)
                                .then((value) {
                              setState(() {
                                _statesList.clear();
                                _statesList.addAll(value);
                              });
                            });
                          }
                        });
                      },
                      child: Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 10, vertical: 14),
                          child: Row(
                            children: [
                              Expanded(
                                child: Text(
                                  countryDropdownValue != null
                                      ? countryDropdownValue!.name!
                                      : Language().getString(
                                          Constants.SELECT_COUNTRY,
                                          selectedLang),
                                  style: TextStyle(
                                    fontFamily: StyleView.FONT_TITLE,
                                    color: countryDropdownValue != null
                                        ? Colors.black
                                        : Colors.grey,
                                  ),
                                ),
                              ),
                              Icon(Icons.arrow_drop_down, color: Colors.grey),
                            ],
                          )))),
            )
          ],
        ));
  }

  buildStateDropdown(String text, StateSetter setState) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: RichText(
                          text: TextSpan(children: [
                            TextSpan(
                              text: Language().getString(text, selectedLang),
                              style: TextStyle(
                                  fontSize: StyleView.FONT_SIZE_15,
                                  fontFamily: StyleView.FONT_TITLE,
                                  color: Colors.black),
                            ),
                            TextSpan(
                                text: "\*",
                                style: TextStyle(
                                    fontSize: StyleView.FONT_SIZE_15,
                                    color: Colors.red))
                          ]),
                        )),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5, right: 5),
                  child: GestureDetector(
                      onTap: () {
                        FocusScope.of(context).unfocus();
                        _showSearchDialog<StatesDAO>(
                          items: _statesList,
                          hintText: Language().getString(
                              Constants.SELECT_STATE, selectedLang),
                          getName: (s) => s.state!,
                        ).then((data) {
                          if (data != null) {
                            _districtList.clear();
                            districtDropdownValue = null;
                            _citiesList.clear();
                            citiesDropDownValue = null;
                            setState(() {
                              statesDropdownValue = data;
                              _districtList.addAll(data.cities!);
                            });
                            this
                                .getCitiesList(countryDropdownValue!.name,
                                    statesDropdownValue!.id)
                                .then((value) {
                              if (value.length > 0) {
                                setState(() {
                                  _citiesList.clear();
                                  _citiesList.addAll(value[0].cities!);
                                });
                              }
                            });
                          }
                        });
                      },
                      child: Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 10, vertical: 14),
                          child: Row(
                            children: [
                              Expanded(
                                child: Text(
                                  statesDropdownValue != null
                                      ? statesDropdownValue!.state!
                                      : Language().getString(
                                          Constants.SELECT_STATE, selectedLang),
                                  style: TextStyle(
                                    fontFamily: StyleView.FONT_TITLE,
                                    color: statesDropdownValue != null
                                        ? Colors.black
                                        : Colors.grey,
                                  ),
                                ),
                              ),
                              Icon(Icons.arrow_drop_down, color: Colors.grey),
                            ],
                          )))),
            )
          ],
        ));
  }

  /// City Dropdown
  buildCityDropdown(String text, StateSetter setState) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: RichText(
                          text: TextSpan(children: [
                            TextSpan(
                              text: Language().getString(text, selectedLang),
                              style: TextStyle(
                                  fontSize: StyleView.FONT_SIZE_15,
                                  fontFamily: StyleView.FONT_TITLE,
                                  color: Colors.black),
                            ),
                            TextSpan(
                                text: "\*",
                                style: TextStyle(
                                    fontSize: StyleView.FONT_SIZE_15,
                                    color: Colors.red))
                          ]),
                        )),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5, right: 5),
                  child: GestureDetector(
                      onTap: () {
                        FocusScope.of(context).unfocus();
                        _showSearchDialog<String>(
                          items: _citiesList,
                          hintText: Language().getString(
                              Constants.SELECT_CITY, selectedLang),
                          getName: (c) => c,
                        ).then((data) {
                          if (data != null) {
                            setState(() {
                              citiesDropDownValue = data;
                            });
                          }
                        });
                      },
                      child: Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 10, vertical: 14),
                          child: Row(
                            children: [
                              Expanded(
                                child: Text(
                                  citiesDropDownValue ??
                                      Language().getString(
                                          Constants.SELECT_CITY, selectedLang),
                                  style: TextStyle(
                                    fontFamily: StyleView.FONT_TITLE,
                                    color: citiesDropDownValue != null
                                        ? Colors.black
                                        : Colors.grey,
                                  ),
                                ),
                              ),
                              Icon(Icons.arrow_drop_down, color: Colors.grey),
                            ],
                          )))),
            )
          ],
        ));
  }

  buildDistrictDropdown(String text, StateSetter setState) {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 50,
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Container(
                    padding: EdgeInsets.only(left: 10),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: RichText(
                          text: TextSpan(children: [
                            TextSpan(
                              text: Language().getString(text, selectedLang),
                              style: TextStyle(
                                  fontSize: StyleView.FONT_SIZE_15,
                                  fontFamily: StyleView.FONT_TITLE,
                                  color: Colors.black),
                            ),
                            TextSpan(
                                text: "\*",
                                style: TextStyle(
                                    fontSize: StyleView.FONT_SIZE_15,
                                    color: Colors.red))
                          ]),
                        )),
                  )),
            ),
            Expanded(
              flex: 2,
              child: Container(
                  color: Colors.white70,
                  padding: EdgeInsets.only(left: 5, right: 5),
                  child: GestureDetector(
                      onTap: () {
                        FocusScope.of(context).unfocus();
                        _showSearchDialog<String>(
                          items: _districtList,
                          hintText: Language().getString(
                              Constants.SELECT_DISTRICT, selectedLang),
                          getName: (d) => d,
                        ).then((data) {
                          if (data != null) {
                            setState(() {
                              districtDropdownValue = data;
                            });
                          }
                        });
                      },
                      child: Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 10, vertical: 14),
                          child: Row(
                            children: [
                              Expanded(
                                child: Text(
                                  districtDropdownValue ??
                                      Language().getString(
                                          Constants.SELECT_DISTRICT,
                                          selectedLang),
                                  style: TextStyle(
                                    fontFamily: StyleView.FONT_TITLE,
                                    color: districtDropdownValue != null
                                        ? Colors.black
                                        : Colors.grey,
                                  ),
                                ),
                              ),
                              Icon(Icons.arrow_drop_down, color: Colors.grey),
                            ],
                          )))),
            )
          ],
        ));
  }

  Future<T?> _showSearchDialog<T>({
    required List<T> items,
    required String hintText,
    required String Function(T) getName,
  }) {
    String query = '';
    return showDialog<T?>(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            List<T> filtered = items
                .where((item) =>
                    getName(item).toLowerCase().contains(query.toLowerCase()))
                .toList();
            return Dialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Padding(
                    padding: EdgeInsets.fromLTRB(12, 12, 12, 0),
                    child: TextField(
                      autofocus: true,
                      decoration: InputDecoration(
                        hintText: hintText,
                        prefixIcon: Icon(Icons.search, color: Colors.grey),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        contentPadding: EdgeInsets.symmetric(vertical: 10),
                      ),
                      onChanged: (value) {
                        setState(() {
                          query = value;
                        });
                      },
                    ),
                  ),
                  SizedBox(
                    height: 300,
                    child: filtered.isEmpty
                        ? Center(
                            child: Text("No results found",
                                style: TextStyle(color: Colors.grey)))
                        : ListView.builder(
                            itemCount: filtered.length,
                            itemBuilder: (context, index) {
                              return ListTile(
                                title: Text(getName(filtered[index]),
                                    style: TextStyle(
                                        fontFamily: StyleView.FONT_TITLE)),
                                onTap: () {
                                  Navigator.of(context).pop(filtered[index]);
                                },
                              );
                            },
                          ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(bottom: 8),
                    child: TextButton(
                      onPressed: () => Navigator.of(context).pop(null),
                      child: Text(
                        Language().getString(Constants.STR_CANCEL, selectedLang),
                        style: TextStyle(color: Colors.red),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  bool validateEmail(String value) {
    Pattern pattern =
        r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
    RegExp regex = new RegExp(pattern as String);
    return (!regex.hasMatch(value)) ? false : true;
  }

  Future<List<BuBasicDataModel>> getAllBuBusinessData(String? userId) async {
    String body = json.encode({"id": userId});
    var response = await _organizationService
        .getBulistByUserId(body: body, token: "")
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    List<BuBasicDataModel> _model = [];
    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var responseBody = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(responseBody)) {
        for (var noteJson in responseBody) {
          _model.add(BuBasicDataModel.fromJson(noteJson));
        }

        if (_model.length > 0 &&
            widget.modelData != null &&
            widget.isForUpdate) {
          for (int i = 0; i < _model.length; i++) {
            if (widget.modelData!.buId == _model[i].id) {
              dropdownValue = _model[i];
            }
          }
        } else {
          for (int i = 0; i < _model.length; i++) {
            if (buId == _model[i].id) {
              dropdownValue = _model[i];
            }
          }
        }
      } else {
        Dialogs.yesCancelDialog(
            context,
            Language().getString(Constants.ERROR, selectedLang),
            _grpcResponse.message,
            Language().getString(Constants.OKAY_STR, selectedLang),
            "",
            false);
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          "$response",
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
    return _model;
  }

  offlineServiceCalls() async {
    if (widget.isForUpdate) {
      if (await NetworkStatus.getInternetStatus()) {
        this.updateContact();
      } else {
        AppUtills.showSnackBar(_scaffoldkey,
            Language().getString(Constants.NO_INTERNET, selectedLang),
            snackBarBgColor: Colors.black,
            messageColor: Colors.white,
            buttonColor: Colors.white);
      }
    } else {
      if (await NetworkStatus.getInternetStatus()) {
        this.createContact();
      } else {
        AppUtills.showSnackBar(_scaffoldkey,
            Language().getString(Constants.NO_INTERNET, selectedLang),
            snackBarBgColor: Colors.black,
            messageColor: Colors.white,
            buttonColor: Colors.white);
      }
    }
  }
}
