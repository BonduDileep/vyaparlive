import 'package:share_plus/share_plus.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:clipboard/clipboard.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
// import 'package:share/share.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/invoice_view/InvoiceDesingView.dart';
import 'package:vyaparlive/model/BuListOrderDataDAO.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:toast/toast.dart';

class OrderStatusPage extends StatelessWidget {
  final String? strDtate;
  final String? strStatus;
  final String? strInvoice;
  final String? strShareInvoice;
  final String? strCancel;
  final String? strOpen;
  final String? strShare;
  final String? strCopy;
  final List<BuListOrderDataDAO>? buListInvoice;
  OrderStatusPage(
      {this.buListInvoice,
      this.strDtate,
      this.strInvoice,
      this.strCopy,
      this.strStatus,
      this.strCancel,
      this.strOpen,
      this.strShare,
      this.strShareInvoice});
  String? selectedLang = "en";
  @override
  Widget build(BuildContext context) {
    return Container(
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(5.0),
            border: Border.all(color: Color(Constants.APP_COLOR))),
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.all(16.0),
              child: Row(
                children: [
                  rowHeaderText(strDtate!, TextAlign.start),
                  rowHeaderText(strStatus!, TextAlign.center),
                  rowHeaderText(strInvoice!, TextAlign.center),
                ],
              ),
            ),
            Divider(color: Color(Constants.APP_COLOR), height: 5.0),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(left: 16, right: 16),
                child: ListView.builder(
                  shrinkWrap: true,
                  itemBuilder: (context, index) {
                    return viewData(index, context);
                  },
                  itemCount: buListInvoice!.length,
                ),
              ),
            )
          ],
        ));
  }

  Widget viewData(int index, BuildContext mContext) {
    return Container(
      padding: EdgeInsets.only(top: 16.0),
      child: Row(
        children: [
          this.bindOrderData(
              AppUtills.getDateFormate(
                  buListInvoice![index].invoiceDetails!.invoiceDate.toString()),
              TextAlign.start,
              1),
          this.bindOrderData(
              buListInvoice![index].invoiceDetails != null
                  ? buListInvoice![index].invoiceDetails!.status!
                  : "",
              TextAlign.center,
              2),
          Expanded(
            child: Container(
              child: InkWell(
                onTap: () {
                  this.shareInvoice(mContext, index);
                },
                child: Text(
                    Language().getString(Constants.INVOICE, selectedLang) +
                        " #${buListInvoice![index].invoiceDetails != null ? buListInvoice![index].invoiceDetails!.billNo : ""}",
                    style: TextStyle(
                      decoration: TextDecoration.underline,
                      fontSize: 13.0,
                      color: Color(Constants.APP_COLOR),
                    )),
              ),
            ),
          ),
        ],
      ),
    );
  }

  shareInvoice(BuildContext context, int index) {
    String url =
        '${Constants.WHATSAPP_INVOICE_URL}${buListInvoice![index].txnId}/invoice-pdf/${buListInvoice![index].invoiceDetails!.billNo}';
    return showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        actions: [
          Container(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: Text(
                    strCancel!,
                    style: TextStyle(
                      fontSize: 15.0,
                      color: Color(
                        Constants.APP_COLOR,
                      ),
                    ),
                  ),
                ),
                TextButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        PageTransition(
                          context: context,
                          page: InvoiceDesingPage(
                            invoiceNo: buListInvoice![index]
                                .invoiceDetails!
                                .billNo
                                .toString(),
                            transactionName: buListInvoice![index].buyer!.name,
                            transactionId: buListInvoice![index].txnId,
                            transactionDate: buListInvoice![index]
                                .invoiceDetails!
                                .invoiceDate
                                .toString(),
                            buyerName: buListInvoice![index].buyer!.name,
                            sellerName: buListInvoice![index].seller!.name,
                            invoiceId: buListInvoice![index].invoiceId,
                          ),
                        ),
                      );
                    },
                    child: Text(strOpen!,
                        style: TextStyle(
                          fontSize: 15.0,
                          color: Color(
                            Constants.APP_COLOR,
                          ),
                        ))),
                TextButton(
                    onPressed: () {
                      String sellerName = '';
                      String buyerName = '';

                      if (buListInvoice![index].buyer!.id ==
                          AppController.instance.getMyBuId) {
                        sellerName = buListInvoice![index].seller!.name!;
                        buyerName = buListInvoice![index].buyer!.name!;
                      } else {
                        sellerName = buListInvoice![index].buyer!.name!;
                        buyerName = buListInvoice![index].seller!.name!;
                      }
                      String message =
                          'Hello $sellerName,\n\n$buyerName has generated a new PO(Purchase Order), please click below url to view the invoice\n\n$url';
                      if (kIsWeb) {
                        this.openCopyAlertDialog(context, message);
                      } else {
                        SharePlus.instance.share(ShareParams(
                          text: message,
                          title: "Vyapar Live PO",
                          subject: "Vyapar Live PO",
                        ));
                        // Share.share(message, subject: "Vyapar Live PO");
                      }
                      // if (kIsWeb) {
                      //   Navigator.of(context).pop();
                      //   this.openCopyAlertDialog(context, url);
                      // } else {
                      //   Share.share(
                      //       Language().getString(
                      //               Constants.YOUR_GENERATE_INVOICE_IS,
                      //               selectedLang) +
                      //           ": $url",
                      //       subject: "${Constants.APANAVYAPAR} INVOICE");
                      // }
                    },
                    child: Text((kIsWeb) ? strCopy! : strShare!,
                        style: TextStyle(
                          fontSize: 15.0,
                          color: Color(
                            Constants.APP_COLOR,
                          ),
                        ))),
              ],
            ),
          )
        ],
        content: Container(
          child: Text(strShareInvoice!),
        ),
      ),
    );
  }

  openCopyAlertDialog(BuildContext context, String url) {
    return showDialog(
        barrierDismissible: false,
        context: context,
        barrierColor: Colors.black54,
        builder: (BuildContext context) {
          return AlertDialog(
            elevation: 100.0,
            contentPadding: EdgeInsets.fromLTRB(15.0, 0, 15.0, 0),
            backgroundColor: Color(0XFFE0E0E0),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(7.0))),
            actions: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  InkWell(
                    onTap: () => {
                      Navigator.of(context).pop(),
                    },
                    child: Text(
                      Language().getString(Constants.STR_CANCEL, selectedLang),
                      style: TextStyle(
                          color: Color(Constants.APP_COLOR),
                          fontSize: 15,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                  InkWell(
                    onTap: () => {
                      FlutterClipboard.copy("$url").then((value) => {
                            print('copied'),
                            Toast.show("copied to clipboard",
                                duration: Toast.lengthShort,
                                gravity: Toast.bottom)
                          }),
                      Navigator.of(context).pop(),
                    },
                    child: Text(
                      Language().getString(Constants.COPY, selectedLang),
                      style: TextStyle(
                          color: Color(Constants.APP_COLOR),
                          fontSize: 15,
                          fontWeight: FontWeight.bold),
                    ),
                  )
                ],
              )
            ],
            titlePadding: EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 10.0),
            title: Text(
              Language().getString(Constants.STR_COPY_TO_SHARE, selectedLang),
              style: TextStyle(
                  color: Color(Constants.APP_COLOR),
                  fontSize: 15,
                  fontWeight: FontWeight.bold),
            ),
            content: Container(
                // height: 70.0,
                child: Text("$url")),
          );
        });
  }

  Widget bindOrderData(String value, TextAlign align, int flex) {
    return Expanded(
      flex: flex,
      child: Container(
        child: Text(
          value,
          textAlign: align,
          style: TextStyle(color: Color(Constants.APP_COLOR), fontSize: 13.0),
        ),
      ),
    );
  }

  Widget rowHeaderText(String text, TextAlign textAlign) {
    return Expanded(
      child: Container(
        child: Text(
          text,
          textAlign: textAlign,
          style: TextStyle(
              color: Color(Constants.APP_COLOR),
              fontSize: 15.0,
              fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}
