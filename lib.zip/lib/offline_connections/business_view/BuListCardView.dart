import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/core/enums/privilleges_enum.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:vyaparlive/Product/products_widget/PopupMenuItemDesign.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';


class BuListCardView extends StatelessWidget {
  final String? name;
  final String? contact;
  final String? email;
  final String? strSellProducts;
  final String? strBuyProducts;
  final String? strEdit;
  final String? strDelete;
  final VoidCallback? editBu;
  final String? connectionId;
  final VoidCallback? deleteBu;
  final VoidCallback? assignToUser;
  final String? strAssignToUser;
  final VoidCallback? onSellProducts;
  final VoidCallback? onBuyProducts;
  final VoidCallback? onTransactionHistory;
  final VoidCallback? onStartDiscussionClick;
  final VoidCallback? onChatClick;
  final String? strTransactionHistory;
  final String? strDiscussion;
  final String? gstNo;

  BuListCardView(
      {this.contact,
      this.email,
      this.name,
      this.editBu,
      this.connectionId,
      this.deleteBu,
      this.strBuyProducts,
      this.strDelete,
      this.strEdit,
      this.strSellProducts,
      this.assignToUser,
      this.strAssignToUser,
      this.onBuyProducts,
      this.onSellProducts,
      this.onTransactionHistory,
      this.strTransactionHistory,
      this.onStartDiscussionClick,
      this.strDiscussion,
      this.onChatClick,
      this.gstNo});
  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 10.0,
      shadowColor: AppTheme.vyaparTheme.colorScheme.primary,
      shape: new RoundedRectangleBorder(
          borderRadius: new BorderRadius.circular(5),
          side: new BorderSide(
              color: AppTheme.vyaparTheme.colorScheme.primaryContainer,
              strokeAlign: 1)),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
            child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  this.rowView(FeatherIcons.home, name!, true),
                  this.rowView(FeatherIcons.phone, contact!, false),
                  this.rowView(FeatherIcons.mail, email!, false),
                  this.rowView(FeatherIcons.edit, "GST No: ${gstNo!}", false),
                ],
              ),
              this.showPopupOptions(context)
            ])),
      ),
    );
  }

  Widget showPopupOptions(BuildContext context) {
    return Container(
      child: PopupMenuButton(
        elevation: 5,
        icon: Icon(
          FeatherIcons.moreVertical,
          color: AppTheme.vyaparTheme.colorScheme.primary,
        ),
        shadowColor: AppTheme.vyaparTheme.colorScheme.primary,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(10.0)),
            side: new BorderSide(
                color: AppTheme.vyaparTheme.colorScheme.primaryContainer,
                strokeAlign: 0.02)),
        itemBuilder: (context) => [
          if (CommonMethods.isPrivillegeExist(
              context,
              PrivillegesActions
                  .KEY_OFFLINE_CONNECTIONS_CARD_MENU_SELL_PRODUCTS))
            PopupMenuItem(
              child: PopupMenuItemDesingView(
                  assetPath: "assets/images/discussion.png",
                  itemName: strSellProducts),
              value: "SELL_PRODUCTS",
            ),
          if (CommonMethods.isPrivillegeExist(
              context,
              PrivillegesActions
                  .KEY_OFFLINE_CONNECTIONS_CARD_MENU_BUY_PRODUCTS))
            PopupMenuItem(
              child: PopupMenuItemDesingView(
                  assetPath: "assets/images/transaction_icon_product.png",
                  itemName: strBuyProducts),
              value: "BUY_PRODUCTS",
            ),
          if (CommonMethods.isPrivillegeExist(context,
              PrivillegesActions.KEY_OFFLINE_CONNECTIONS_CARD_MENU_EDIT))
            PopupMenuItem(
              child: PopupMenuItemDesingView(
                  assetPath: "assets/images/edit_image.png", itemName: strEdit),
              value: "EDIT",
            ),
          // PopupMenuItem(
          //   child: PopupMenuItemDesingView(
          //       assetPath: "assets/images/transaction_icon_product.png",
          //       itemName: strDelete),
          //   value: "DELETE",
          // ),
          if (CommonMethods.isPrivillegeExist(
              context,
              PrivillegesActions
                  .KEY_OFFLINE_CONNECTIONS_CARD_MENU_ASSIGN_TO_USER))
            PopupMenuItem(
              child: PopupMenuItemDesingView(
                  assetPath: "assets/images/social.png",
                  itemName: strAssignToUser),
              value: "ASSIGN_USER",
            ),
          PopupMenuItem(
            child: PopupMenuItemDesingView(
                assetPath: "assets/images/discussion.png",
                itemName: strDiscussion),
            value: "DISCUSSION",
          ),
          PopupMenuItem(
            child: PopupMenuItemDesingView(
                assetPath: "assets/images/transaction_icon_product.png",
                itemName: strTransactionHistory),
            value: "TRANSACTION_HISTORY",
          ),
        ],
        onSelected: (dynamic value) {
          switch (value) {
            case 'SELL_PRODUCTS':
              onSellProducts!();
              break;
            case 'BUY_PRODUCTS':
              onBuyProducts!();
              break;
            case 'EDIT':
              editBu!();

              break;
            case "DELETE":
              deleteBu!();
              break;

            case "ASSIGN_USER":
              assignToUser!();
              break;
            case "TRANSACTION_HISTORY":
              onTransactionHistory!();
              break;
            case "DISCUSSION":
              onStartDiscussionClick!();
              break;
            case "CHAT":
              onChatClick!();
              break;
            default:
          }
        },
      ),
    );
  }

  Widget rowView(IconData icon, String value, bool isTextBold) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 5.0),
      child: Row(
        children: [
          Container(
            margin: EdgeInsets.symmetric(
              horizontal: 5.0,
            ),
            child: Icon(icon,
                size: 18.0, color: Colors.black //(Constants.APP_COLOR),
                ),
          ),
          Container(
            child: Text(
              value,
              style: TextStyle(
                  color: Colors.black, //(Constants.APP_COLOR),
                  fontWeight:
                      (isTextBold) ? StyleView.fontBold : StyleView.fontMedium,
                  fontSize: (isTextBold) ? 16 : 14.0),
            ),
          ),
        ],
      ),
    );
  }
}
