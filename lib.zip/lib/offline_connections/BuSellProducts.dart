import 'package:flutx/state_management/controller_store.dart';
import 'package:vyaparlive/retailer_view/card_view/ProductsCardView.dart';
import 'package:vyaparlive/service/api_service/ProductsApiService.dart';
import 'package:vyaparlive/service/api_service/TransactionApiService.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutx/utils/spacing.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/Transaction/ListOfTransactions.dart';
import 'package:vyaparlive/offline_connections/business_view/OrderStatusView.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/DateFilterUtil.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/invoice_view/BatchPriceDropdownView.dart';
import 'package:vyaparlive/model/BuListOrderDataDAO.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/ModelProduct.dart';
import 'package:vyaparlive/model/product_model/BatchPriceDAO.dart';
import 'package:vyaparlive/model/product_model/OffersDAO.dart';
import 'package:vyaparlive/model/product_model/ProductModel.dart';
import 'dart:convert';
import 'package:vyaparlive/service/bu_list_grpc_service.dart';
import 'package:vyaparlive/utills/SharePref.dart';

import 'controller/controller.dart';

class BuSellProductsPage extends StatefulWidget {
  final String? recordId;
  final String? contactName;

  BuSellProductsPage({this.contactName, this.recordId});
  @override
  _BuSellProductsPageState createState() => _BuSellProductsPageState();
}

class _BuSellProductsPageState extends State<BuSellProductsPage> {
  bool isLoadingProgress = false;
  String? buId = "";
  String? buName = "";
  final _rupeeController = TextEditingController();
  String? offerInPercentage;
  String? radioButtonValue = "";
  String discountType = "";
  List<BuProductModal> responseProducts = [];
  List<ModelProduct> _productsList = [];
  List<ModelProduct> selectedProductsList = [];
  ModelProduct? _selectedProductData;
  List<TextEditingController> _enterProductCount = [];
  String forSaleProducts = "";
  late BuListGrpcService _buListGrpcService;
  String? userName = "";
  String? userId = "";
  List<BuListOrderDataDAO> buListInvoice = [];
  bool isEnableDateFilter = true;
  String startDate = "";
  String endDate = "";
  String convertedDate = "";
  DateFormat formatter = DateFormat("yyyy-MM-dd");
  String todayDate = "";
  String params = "";
  final _searchController = TextEditingController();
  late TextEditingController fromDateController = new TextEditingController();
  late TextEditingController toDateController = new TextEditingController();
  String showLoaderText = Constants.NO_PREVIOUS_ORDERS;
  bool isLoadingProductCompleted = false;
  String? productNameDropdown;
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String showProductText = "";
  bool _isShowNames = false;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  List<BatchPriceDAO?> batchPricingDropdownList = [];
  bool isForSearchParams = false;
  final TextEditingController productNameController = TextEditingController();
  final TextEditingController quantityController = TextEditingController();
  final TextEditingController priceController = TextEditingController();
  final TextEditingController totalPriceController = TextEditingController();
  String? orgCurrencySymbol = "";
  bool isShowFloatButton = false;
  List<String> _checked = [];
  String progressMessage = Constants.GETTING_DATA;
  DateTime mnthStartDate =
      DateTime.utc(DateTime.now().year, DateTime.now().month, 1);

  late ThemeData theme;
  late Controller _controller;

  @override
  void initState() {
    super.initState();
    _controller = FxControllerStore.putOrFind(Controller());
    theme = AppTheme.vyaparTheme;
    _buListGrpcService = BuListGrpcService();
    buId = AppController.instance.getMyBuId;
    buName = AppController.instance.getBuName;
    forSaleProducts = Constants.FOR_SALE_TRUE;
    isLoadingProductCompleted = true;
    startDate = formatter.format(mnthStartDate);
    endDate = formatter.format(DateTime.now());
    fromDateController.text = startDate;
    toDateController.text = endDate;
    // orgCurrencySymbol = AppController.instance.getBuCurrencySymbol;
    String? symbol = AppController.instance.getBuCurrencySymbol;
    orgCurrencySymbol = (symbol != null && symbol.isNotEmpty && symbol != "-")
        ? symbol
        : "\u20B9";
    loadBuListInvoiceData();
    SharePref().getUserId().then((value) {
      setState(() => userId = value);
    });
    SharePref().getUserName().then((value) {
      setState(() => userName = value);
    });
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
        body: Stack(
      children: [
        SafeArea(
          child: Scaffold(
            key: _scaffoldkey,
            backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
            appBar: AppBar(
              centerTitle: true,
              backgroundColor: Colors.transparent,
              elevation: 0,
              iconTheme: IconThemeData(color: theme.colorScheme.primary),
              title: AppbarName(
                  title:
                      Language().getString(Constants.SELL_ORDERS, selectedLang),
                  buName: "${widget.contactName}"),
              actions: [
                IconButton(
                    icon: Icon(Icons.add),
                    onPressed: () =>
                        _controller.navigationFillOrderFormOfflineConnection(
                            context: context,
                            connectionBuName: widget.contactName!,
                            recordId: widget.recordId!))
              ],
            ),
            floatingActionButton: (isShowFloatButton)
                ? FloatingActionButton(
                    backgroundColor: theme.colorScheme.primary,
                    onPressed: () {
                      setState(() {
                        isShowFloatButton = false;
                        isLoadingProgress = true;
                        _searchController.clear();
                        fromDateController.text = startDate;
                        toDateController.text = endDate;
                        buListInvoice.clear();
                      });
                      _checked.clear();
                      loadBuListInvoiceData();
                    },
                    child: Text(
                      Language()
                          .getString(Constants.CLEAR_FILTERS, selectedLang),
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white, fontSize: 11.0),
                    ))
                : null,
            body: Container(
                padding: EdgeInsets.symmetric(horizontal: 16, vertical: 10.0),
                child: Column(
                  children: [
                    Container(
                      padding: EdgeInsets.symmetric(vertical: 10),
                      child: DateFilterUtill(
                        isShowSearchButton: true,
                        fromDate: "",
                        toDate: "",
                        fromDateController: fromDateController,
                        toDateController: toDateController,
                        onFromDateSelected: (value) {
                          setState(() => fromDateController.text = value);
                        },
                        onToDateSelected: (value) {
                          setState(() => toDateController.text = value);
                        },
                        onSearchParms: () {
                          setState(() {
                            isLoadingProgress = true;
                            isShowFloatButton = true;
                          });
                          if (endDate == todayDate) {
                            convertedDate =
                                AppUtills.getOneDayAddedDate(endDate);
                          } else {
                            convertedDate = endDate;
                          }
                          loadBuListInvoiceData();
                        },
                      ),
                    ),
                    Expanded(
                      child: (buListInvoice.length > 0)
                          ? Container(
                              margin: EdgeInsets.only(top: 5),
                              child: OrderStatusPage(
                                strCopy: Language()
                                    .getString(Constants.COPY, selectedLang),
                                strShare: Language()
                                    .getString(Constants.SHARE, selectedLang),
                                strOpen: Language()
                                    .getString(Constants.OPEN, selectedLang),
                                strCancel: Language().getString(
                                    Constants.STR_CANCEL, selectedLang),
                                strShareInvoice: Language().getString(
                                    Constants.SHARE_INVOICE, selectedLang),
                                strDtate: Language()
                                    .getString(Constants.DATE, selectedLang),
                                strStatus: Language().getString(
                                    Constants.STATUS_STRING, selectedLang),
                                strInvoice: Language()
                                    .getString(Constants.INVOICE, selectedLang),
                                buListInvoice: buListInvoice,
                              ),
                            )
                          : Center(
                              child: Text(Language()
                                  .getString(showLoaderText, selectedLang)),
                            ),
                    )
                  ],
                )),
          ),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    ));
  }

  showProductsView() {
    return showDialog(
      context: context,
      barrierColor: Colors.black54,
      barrierDismissible: false,
      builder: (context) => StatefulBuilder(
        builder: (context, StateSetter setState) {
          return Container(
              margin: EdgeInsets.symmetric(vertical: 20.0, horizontal: 10.0),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: AppBackgroundView(
                  body: Scaffold(
                    bottomNavigationBar: bottomView(),
                    backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                    body: Container(
                      margin: EdgeInsets.symmetric(
                          vertical: 10.0, horizontal: 16.0),
                      child: Column(
                        children: [
                          Text(
                              Language().getString(
                                  Constants.FILL_ORDER_FORM, selectedLang),
                              style: TextStyle(
                                  color: theme.colorScheme.primary,
                                  fontFamily: StyleView.FONT_TITLE,
                                  fontSize: 15,
                                  fontWeight: StyleView.fontSemiBold)),
                          FxSpacing.height(16),
                          showProductSearchView(setState),
                          (_productsList.length > 0 && _isShowNames)
                              ? this.showProductNames(setState)
                              : Container(
                                  margin: EdgeInsets.symmetric(vertical: 5.0),
                                  child: (showProductText ==
                                              Language().getString(
                                                  Constants.NO_DATA_FOUND,
                                                  selectedLang) ||
                                          showProductText == "")
                                      ? Text(showProductText)
                                      : Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Text(
                                              Language().getString(
                                                  Constants.LOADING,
                                                  selectedLang),
                                            ),
                                            Container(
                                              height: 10.0,
                                              width: 10.0,
                                              margin: EdgeInsets.symmetric(
                                                  horizontal: 5.0),
                                              child: CircularProgressIndicator(
                                                strokeWidth: 2.0,
                                              ),
                                            )
                                          ],
                                        ),
                                ),
                          (selectedProductsList.length > 0)
                              ? Expanded(
                                  child: Container(
                                    margin: EdgeInsets.only(top: 5.0),
                                    decoration: AppUtills.boxDecoration(),
                                    child: Column(
                                      children: [
                                        Container(
                                          padding: EdgeInsets.all(5.0),
                                          child: Row(
                                            children: [
                                              Expanded(
                                                child: Text(
                                                  Language().getString(
                                                      Constants.PRODUCT_NAME,
                                                      selectedLang),
                                                  style: TextStyle(
                                                      color: Color(
                                                          Constants.APP_COLOR),
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),
                                              ),
                                              Expanded(
                                                child: Text(
                                                  Language().getString(
                                                      Constants.QUANTITY,
                                                      selectedLang),
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                      color: Color(
                                                          Constants.APP_COLOR),
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),
                                              ),
                                              Expanded(
                                                child: Text(
                                                  Language().getString(
                                                          Constants.TOTAL_PRICE,
                                                          selectedLang) +
                                                      "( $orgCurrencySymbol )",
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                      color: Color(
                                                          Constants.APP_COLOR),
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),
                                              )
                                            ],
                                          ),
                                        ),
                                        Divider(
                                            color: Color(Constants.APP_COLOR)),
                                        Expanded(
                                          child: ListView.separated(
                                              shrinkWrap: true,
                                              separatorBuilder: (context,
                                                      index) =>
                                                  new Divider(
                                                    color: Colors.transparent,
                                                    height: 0.0,
                                                  ),
                                              itemCount:
                                                  selectedProductsList.length,
                                              itemBuilder: (context, index) {
                                                _enterProductCount[index] =
                                                    TextEditingController(
                                                        text:
                                                            selectedProductsList[
                                                                    index]
                                                                .counter
                                                                .toString());
                                                _enterProductCount[index]
                                                        .selection =
                                                    TextSelection.fromPosition(
                                                        TextPosition(
                                                            offset:
                                                                _enterProductCount[
                                                                        index]
                                                                    .text
                                                                    .length));
                                                return Card(
                                                  child: Column(
                                                    children: [
                                                      ProductsCardView(
                                                        onRemoveProductQuantit:
                                                            () {
                                                          removeProductsQuantity(
                                                              index, setState);
                                                        },
                                                        onAddProductQuantity:
                                                            () {
                                                          addProductsQuantity(
                                                              index, setState);
                                                        },
                                                        desingQuntityField:
                                                            Container(
                                                          width: 50.0,
                                                          height: 30.0,
                                                          alignment: Alignment
                                                              .bottomCenter,
                                                          decoration: AppUtills
                                                              .boxDecoration(),
                                                          child:
                                                              designQuantityInputField(
                                                                  index,
                                                                  setState),
                                                        ),
                                                        productName:
                                                            selectedProductsList[
                                                                    index]
                                                                .name,
                                                        removeProduct:
                                                            () async {
                                                          this.removeProductsFromSelectedProducts(
                                                              index, setState);
                                                        },
                                                        productTotalPrice:
                                                            selectedProductsList[
                                                                    index]
                                                                .price,
                                                      ),
                                                      (batchPricingDropdownList
                                                                  .length >
                                                              0)
                                                          ? this.batchPricingDropdown(
                                                              selectedProductsList[
                                                                      index]
                                                                  .batchPriceList!,
                                                              index,
                                                              setState)
                                                          : Container(),
                                                      (selectedProductsList[
                                                                      index]
                                                                  .offerData !=
                                                              null)
                                                          ? this.showOfferCheckBox(
                                                              selectedProductsList[
                                                                      index]
                                                                  .offerData,
                                                              index,
                                                              setState)
                                                          : Container()
                                                    ],
                                                  ),
                                                );
                                              }),
                                        )
                                      ],
                                    ),
                                  ),
                                )
                              : Container(),
                        ],
                      ),
                    ),
                  ),
                ),
              ));
        },
      ),
    );
  }

  Widget bottomView() {
    if ((selectedProductsList.length > 0)) {
      return Container(
          padding: EdgeInsets.symmetric(
              horizontal: 10.0,
              vertical:
                  (defaultTargetPlatform == TargetPlatform.iOS) ? 30 : 20),
          child: CommonButtonsView(
            context: context,
            b1Text: Language().getString(Constants.STR_CANCEL, selectedLang),
            b2Text:
                Language().getString(Constants.GENERATE_INVOICE, selectedLang),
            onb1Action: () {
              clearData();
              Navigator.of(context).pop();
            },
            onb2Action: () {
              showConfirmationPopup();
            },
          ));
    } else {
      return Container(
          padding: EdgeInsets.symmetric(
              horizontal: 10.0,
              vertical:
                  (defaultTargetPlatform == TargetPlatform.iOS) ? 30 : 20),
          child: CommonButtonsView(
            context: context,
            b1Text: "",
            b2Text: Language().getString(Constants.STR_CANCEL, selectedLang),
            onb2Action: () {
              clearData();
              Navigator.of(context).pop();
            },
          ));
    }
  }

  Widget listProducts(int index, StateSetter setState) {
    bool isOfferExists = false;
    for (int i = 0; i < _productsList[index].offerList!.length; i++) {
      if (_productsList[index].offerList![i].isOfferActive! &&
          _productsList[index].offerList![i].isOfferActive != null) {
        isOfferExists = true;
      }
    }
    return Container(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            children: <Widget>[
              Expanded(
                  flex: 2,
                  child: Card(
                    elevation: 2.5,
                    child: AppUtills.displayImage(_productsList[index].images,
                        context: context),
                  )),
              Expanded(
                flex: 4,
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 5),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Container(
                        margin: EdgeInsets.symmetric(vertical: 5.0),
                        child: new Text(
                          _productsList[index].name!,
                          style: TextStyle(
                            color: Color(Constants.APP_COLOR),
                            fontSize: 15.0,
                          ),
                        ),
                      ),
                      Container(
                          child: Text(
                        Language().getString(Constants.PRICE, selectedLang) +
                            ' : ${_productsList[index].price}',
                        style: TextStyle(
                            color: Color(
                              Constants.APP_COLOR,
                            ),
                            fontSize: 13.0),
                      )),
                    ],
                  ),
                ),
              ),
              Expanded(
                  flex: 3,
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: <Widget>[
                        Container(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: <Widget>[
                              Container(
                                  child: InkWell(
                                onTap: () {
                                  this.removeProductsQuantity(index, setState);
                                },
                                child: Icon(Icons.remove),
                              )),
                              Container(
                                width: 50.0,
                                height: 30.0,
                                alignment: Alignment.bottomCenter,
                                decoration: AppUtills.boxDecoration(),
                                child: this
                                    .designQuantityInputField(index, setState),
                              ),
                              Container(
                                  child: InkWell(
                                onTap: () {
                                  this.addProductsQuantity(index, setState);
                                },
                                child: Icon(Icons.add),
                              ))
                            ],
                          ),
                        ),
                        (isOfferExists)
                            ? this.showProductOffers(
                                index, isOfferExists, setState)
                            : Container()
                      ]))
            ],
          ),
        ),
      ),
    );
  }

  removeSeletedProduct(int index, StateSetter setState) async {
    final action = await Dialogs.yesCancelDialog(
        context,
        Language().getString(Constants.WARNING, selectedLang),
        Language().getString(Constants.WARNING_TEXT, selectedLang),
        Language().getString(Constants.OKAY_STR, selectedLang),
        "",
        false);

    if (action == DialogAction.yes) {
      setState(() {
        _enterProductCount[index].clear();
        selectedProductsList.removeAt(index);
      });
    }
  }

  removeProductsQuantity(int index, StateSetter setState) {
    int? countDecrement = selectedProductsList[index].counter;
    setState(() {
      if (countDecrement! > 1) {
        countDecrement = countDecrement! - 1;
        setState(() {
          selectedProductsList[index].counter = countDecrement;
          _enterProductCount[index] = TextEditingController(
              text: selectedProductsList[index].counter.toString());
          _enterProductCount[index].selection = TextSelection.fromPosition(
              TextPosition(offset: _enterProductCount[index].text.length));
          calculateProductTotalPrice(
              index, setState, selectedProductsList[index].counter);
        });
      }
    });
  }

  addProductsQuantity(int index, StateSetter setState) {
    int? countIncrement = selectedProductsList[index].counter;

    if (countIncrement == 1) {
      setState(() {
        countIncrement = countIncrement! + 1;

        selectedProductsList[index].counter = countIncrement;
        _enterProductCount[index] = TextEditingController(
            text: selectedProductsList[index].counter.toString());
        _enterProductCount[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _enterProductCount[index].text.length));
        calculateProductTotalPrice(
            index, setState, selectedProductsList[index].counter);
      });
    } else {
      setState(() {
        countIncrement = countIncrement! + 1;

        selectedProductsList[index].counter = countIncrement;

        _enterProductCount[index] = TextEditingController(
            text: selectedProductsList[index].counter.toString());
        _enterProductCount[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _enterProductCount[index].text.length));
        calculateProductTotalPrice(
            index, setState, selectedProductsList[index].counter);
      });
    }
  }

  showProductOffers(int index, bool isOfferExists, StateSetter setState) {
    if (isOfferExists) {
      return Container(
        margin: EdgeInsets.symmetric(
          vertical: 7.0,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            InkWell(
                onTap: () {
                  for (int i = 0;
                      i < _productsList[index].offerList!.length;
                      i++) {
                    if (_productsList[index].offerList![i].isOfferActive!) {
                      Dialogs.showOffer(
                          context,
                          _productsList[index].offerList![i].offerQuantity,
                          _productsList[index].offerList![i].offerName,
                          _productsList[index].offerList![i].minOrder,
                          _productsList[index].offerList![i].maxOrder,
                          _productsList[index].offerList![i].offerType);
                    }
                  }
                },
                child: Container(
                  margin: EdgeInsets.symmetric(
                    horizontal: 5.0,
                  ),
                  child: Text(
                    Language().getString(Constants.OFFER, selectedLang),
                    style: TextStyle(
                        color: StyleView.offerColor,
                        decoration: TextDecoration.underline),
                  ),
                )),
            Container(
              child: SizedBox(
                height: 20.0,
                width: 20.0,
                child: Checkbox(
                    activeColor: StyleView.offerColor,
                    value: _productsList[index].isButton,
                    onChanged: (bool? value) {
                      setState(() {
                        _productsList[index].isButton = value;
                      });
                    }),
              ),
            )
          ],
        ),
      );
    } else {
      return Container();
    }
  }

  designQuantityInputField(int index, StateSetter setState) {
    return Container(
      height: 60.0,
      width: 60.0,
      child: TextFormField(
        enableInteractiveSelection: false,
        textAlign: TextAlign.center,
        controller: _enterProductCount[index],
        decoration: InputDecoration(
          hintText: "",
          border: InputBorder.none,
        ),
        keyboardType: (defaultTargetPlatform == TargetPlatform.iOS)
            ? TextInputType.numberWithOptions(signed: true)
            : TextInputType.number,
        textInputAction: TextInputAction.done,
        style: TextStyle(fontSize: 12.0),
        inputFormatters: [
          new LengthLimitingTextInputFormatter(5),
          FilteringTextInputFormatter.digitsOnly
        ],
        onFieldSubmitted: (value) {
          if (value == "0" || value.isEmpty) {
            selectedProductsList[index].counter = 1;

            calculateProductTotalPrice(
                index, setState, selectedProductsList[index].counter);
          }
        },
        onChanged: (value) {
          setState(() {
            if (selectedProductsList.length > 0) {
              if (value.isEmpty) {
                selectedProductsList[index].counter = 0;

                calculateProductTotalPrice(
                    index, setState, selectedProductsList[index].counter);
              } else {
                selectedProductsList[index].counter = int.parse(value);
                selectedProductsList[index].counter = int.parse(value);

                calculateProductTotalPrice(
                    index, setState, selectedProductsList[index].counter);
              }
            }
          });
        },
      ),
    );
  }

  postBodyForProductsSell() async {
    setState(() {
      isLoadingProgress = true;
      progressMessage =
          Language().getString(Constants.GETTING_DATA, selectedLang);
    });
    Map data = {
      "id": "",
      "is_offline": true,
      "order_type": "offline_direct_sell",
      "buyer": {
        "id": widget.recordId,
        "name": widget.contactName,
        "is_offline": true
      },
      "sender": {
        "id": buId,
      },
      "seller": {
        "id": buId,
        "name": buName,
      },
      "ctr": {"type": "", "Agent": "", "transaction_ref": ""},
      "discussion": {
        "initiator": widget.recordId,
        "initiator_user": widget.contactName,
        "message_start_date": "",
        "confirmation_message": [],
        "confirmation_status": ""
      }
    };
    String body = json.encode(data);

    var response = await _buListGrpcService
        .beginTransaction(body, AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);
      if (await NetworkStatus.getInternetStatus()) {
        prepareTransactionsProductsBody(data);
      } else {
        AppUtills.showSnackBar(_scaffoldkey,
            Language().getString(Constants.NO_INTERNET, selectedLang),
            snackBarBgColor: Colors.black,
            messageColor: Colors.white,
            buttonColor: Colors.white);
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  prepareTransactionsProductsBody(String? transactionId) async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = "Sending products...";
    });

    List<Map<String, dynamic>> productsArray = [];
    var productsObject;
    for (int i = 0; i < selectedProductsList.length; i++) {
      productsObject = {
        "id": selectedProductsList[i].id,
        "unit_price": "",
        "quantity": selectedProductsList[i].counter,
        "total": selectedProductsList[i].price,
        "offer_selected": selectedProductsList[i].offerSelected
      };
      productsArray.add(productsObject);
    }

    Map data = {
      "id": transactionId,
      "order_details": {
        "user_id": userId,
        "user_name": userName,
        "products": productsArray
      }
    };
    String body = json.encode(data);
    // print("BUSELL: createtrans: $body");
    var response = await _buListGrpcService
        .createPlaceOrder(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
        progressMessage = "";
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    setState(() {
      isLoadingProgress = false;
      progressMessage = "";
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      if (await NetworkStatus.getInternetStatus()) {
        serviceCallInvoice(transactionId);
      } else {
        AppUtills.showSnackBar(_scaffoldkey,
            Language().getString(Constants.NO_INTERNET, selectedLang),
            snackBarBgColor: Colors.black,
            messageColor: Colors.white,
            buttonColor: Colors.white);
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  buildSearchBarView() {
    return Container(
      height: 40.0,
      margin: EdgeInsets.symmetric(vertical: 5.0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(5.0),
        border: Border.all(
          color: Colors.grey,
        ),
      ),
      child: Row(
        children: <Widget>[
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.white,
              ),
              padding: EdgeInsets.only(left: 5),
              child: TextFormField(
                controller: _searchController,
                onChanged: onSearchTextChanged,
                style: TextStyle(fontFamily: 'IndianRupee'),
                decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: Language()
                        .getString(Constants.SEARCH_BY_BUSINESS, selectedLang),
                    hintStyle: TextStyle(
                        fontSize: 13.0, fontFamily: StyleView.FONT_TITLE)),
              ),
            ),
          ),
          (_searchController.text.length > 0)
              ? Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topRight: Radius.circular(5.0),
                      bottomRight: Radius.circular(5.0),
                    ),
                  ),
                  child: IconButton(
                      icon: Icon(
                        Icons.close,
                        color: Colors.red,
                        size: 20.0,
                      ),
                      onPressed: () {
                        CommonMethods.hideKeyboard(context);
                        _searchController.clear();
                        onSearchTextChanged(_searchController.text);
                      }),
                )
              : Container(),
          // Container(
          //   decoration: BoxDecoration(
          //     borderRadius: BorderRadius.only(
          //       topRight: Radius.circular(5.0),
          //       bottomRight: Radius.circular(5.0),
          //     ),
          //     color: Colors.white,
          //   ),
          //   child: IconButton(
          //       icon: Icon(Icons.date_range),
          //       onPressed: () {
          //         CommonMethods.hideKeyboard(context);
          //         setState(() {
          //           if (isEnableDateFilter) {
          //             isEnableDateFilter = false;
          //           } else {
          //             isEnableDateFilter = true;
          //           }
          //         });
          //       }),
          // ),
        ],
      ),
    );
  }

  onSearchTextChanged(String text) async {
    showLoaderText = Constants.LOADING;
    if (text.isEmpty) {
      isForSearchParams = false;
      loadBuListInvoiceData();
    } else {
      isForSearchParams = true;
      if (CommonMethods.isNumeric(text)) {
        loadBuListInvoiceData(invoice: text);
      } else {
        loadBuListInvoiceData(name: text);
      }
    }
  }

  calculateProductTotalPrice(int index, StateSetter setState, int? quantity) {
    setState(() {
      selectedProductsList[index].price =
          batchPricingDropdownList[index]!.price! * quantity!;
    });
  }

  Widget showProductNames(StateSetter setState) {
    return Container(
        height: 100.0,
        decoration: BoxDecoration(
          color: Colors.grey[400],
          borderRadius: BorderRadius.circular(5.0),
        ),
        child: ListView.builder(
          itemBuilder: (context, index) {
            return InkWell(
              onTap: () async {
                CommonMethods.hideKeyboard(context);

                if (_productsList[index].batchPriceList!.length > 0) {
                  // if (_selectedProductData != null) {
                  if (_productsList[index].quantity == 0) {
                    Dialogs.yesCancelDialog(
                        context,
                        Language().getString(Constants.ERROR, selectedLang),
                        Language().getString(
                            Constants.THIS_SELECTED_PRODUCT_HAS_NO_QUANTITY,
                            selectedLang),
                        Language().getString(Constants.OKAY_STR, selectedLang),
                        "",
                        false);
                  } else {
                    priceController.text = CommonMethods.getAvailablePrice(
                        _productsList[index].batchPriceList!,
                        isShowCurrencySymbol: false);
                    quantityController.text = "1";
                    _productsList[index].counter =
                        int.parse(quantityController.text);
                    productNameController.text = _productsList[index].name!;
                    totalPriceController.text =
                        (double.parse(priceController.text) *
                                double.parse(quantityController.text))
                            .toString();
                    _isShowNames = false;
                    _selectedProductData = _productsList[index];
                    addToInvoiceProductsArray(setState);
                  }
                }
              },
              child: Card(
                color: Colors.grey[100],
                elevation: 2.5,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(_productsList[index].name!,
                          style: TextStyle(color: Colors.black)),
                      Icon(Icons.arrow_forward, color: Colors.blue, size: 20.0),
                    ],
                  ),
                ),
              ),
            );
          },
          itemCount: _productsList.length,
          shrinkWrap: true,
        ));
  }

  void serviceCallInvoice(String? transactionId) async {
    setState(() {
      isLoadingProgress = true;
      progressMessage =
          Language().getString(Constants.GETTING_DATA, selectedLang);
    });
    List<Map<String, dynamic>?> productArrayList = [];
    var productObject;

    for (int i = 0; i < selectedProductsList.length; i++) {
      if (selectedProductsList[i].counter != 0) {
        productObject = {
          "id": selectedProductsList[i].id,
          "quantity": selectedProductsList[i].counter,
          "unit_price": selectedProductsList[i].unitPrice,
          "offer_selected": selectedProductsList[i].offerSelected,
          "batch_no": batchPricingDropdownList[i]!.batchNumber
        };
      }

      productArrayList.add(productObject);
    }

    List<String> splitValue = [];

    if (radioButtonValue == Constants.OFFER_IN_PERCENTAGE &&
        offerInPercentage != null) {
      splitValue = offerInPercentage!.split(" %");
      // discountValue = splitValue[0];
    } else {
      splitValue
          .add(_rupeeController.text.isEmpty ? "0.0" : _rupeeController.text);
    }

    Map data = {
      "txnId": transactionId,
      "products": productArrayList,
      "term_type": "bu",
      "additional_discount_type": discountType,
      "additional_discount": double.parse(splitValue[0])
    };
    String body = json.encode(data);

    // print("BUSELL: sellinvoice: $body");

    var response = await _buListGrpcService
        .generateTransactionInvoice(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      return showDialog(
        context: context,
        builder: (context) => AlertDialog(
          actions: [
            TextButton(
                onPressed: () {
                  clearData();
                  Navigator.of(context).pop();
                  // Navigator.of(context).pop();
                  Navigator.push(
                      context,
                      new MaterialPageRoute(
                        builder: (context) => ListOfTransactionsPage(
                          transactionId: transactionId,
                        ),
                      )).then((value) => loadBuListInvoiceData());
                },
                child:
                    Text(Language().getString(Constants.OKAY_STR, selectedLang),
                        style: TextStyle(
                          fontSize: 18.0,
                          color: Color(
                            Constants.APP_COLOR,
                          ),
                        ))),
          ],
          content: Container(
            child: Text(
              Language().getString(
                  Constants.INVOICE_GENERATED_SUCCESSFULLY, selectedLang),
              style: TextStyle(
                  color: Colors.black, fontWeight: StyleView.fontRegular),
            ),
          ),
        ),
      );
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  batchPricingDropdown(
      List<BatchPriceDAO> batchNumberList, int index, StateSetter setState) {
    if (batchNumberList.length > 0 && batchPricingDropdownList.length > 0) {
      if (batchPricingDropdownList[index] == null) {
        batchPricingDropdownList[index] = batchNumberList[0];
      }

      return BatchPriceDropDownView(
          canShowPrice: false,
          canShowDynamicPricing: false,
          currentDropdownIndex: index,
          batchPricingList: batchNumberList,
          batchDropdown: batchPricingDropdownList,
          selectedDropdownValue: (data) {
            setState(() {
              batchPricingDropdownList[index] = data;
            });

            calculateProductTotalPrice(
                index, setState, selectedProductsList[index].counter);
          },
          strBatchPricing:
              Language().getString(Constants.BATCH_NO, selectedLang),
          strAvailableQuantity:
              Language().getString(Constants.AVAILABLE_QUANTITY, selectedLang));
    }
  }

  clearData() {
    setState(() {
      _productsList.clear();
      selectedProductsList.clear();
      batchPricingDropdownList.clear();
      productNameDropdown = null;
      _enterProductCount.clear();
      _selectedProductData = null;
      showProductText = "";
      productNameController.clear();
      priceController.clear();
      totalPriceController.clear();
      quantityController.clear();
    });
  }

  Widget showProductSearchView(StateSetter setState) {
    return Container(
      decoration: BoxDecoration(
          border: Border.all(color: Colors.black54),
          borderRadius: BorderRadius.circular(10),
          color: Colors.white),
      margin: EdgeInsets.only(top: 5.0),
      padding: EdgeInsets.only(left: 5, right: 5),
      height: 45.0,
      alignment: Alignment.centerLeft,
      child: Container(
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10), color: Colors.white),
        alignment: Alignment.centerLeft,
        child: Row(
          children: [
            Expanded(
              flex: 2,
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(5.0),
                      bottomLeft: Radius.circular(5.0)),
                  color: Color(Constants.APP_BACKGROUND_COLOR),
                ),
                margin: EdgeInsets.only(right: 1.0),
                child: TextField(
                  controller: productNameController,
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                      hintText: Language()
                          .getString(Constants.SEARCH_BY_PRODUCT, selectedLang),
                      hintStyle: TextStyle(fontSize: 12.0),
                      // contentPadding: EdgeInsets.all(2.0),
                      border: InputBorder.none),
                  maxLines: 2,
                  onChanged: (_text) {
                    if (_text.isNotEmpty) {
                      setState(() {
                        showProductText = Constants.LOADING;
                      });
                      loadProductData(_text, setState);
                    } else {
                      setState(() {
                        showProductText = "";
                        _isShowNames = false;
                        _productsList.clear();
                      });
                    }
                  },
                  style: TextStyle(
                      fontSize: 12.0, decoration: TextDecoration.none),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  addToInvoiceProductsArray(StateSetter setState) {
    setState(() {
      bool isExist = false;
      int index = -1;
      for (int i = 0; i < selectedProductsList.length; i++) {
        if (_selectedProductData!.id == selectedProductsList[i].id) {
          isExist = true;
          index = i;
        }
      }

      if (isExist) {
        selectedProductsList[index].counter =
            selectedProductsList[index].counter! +
                int.parse(quantityController.text);
        calculateProductTotalPrice(
            index, setState, selectedProductsList[index].counter);
        _enterProductCount[index] = TextEditingController(
            text: selectedProductsList[index].counter.toString());
        _enterProductCount[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _enterProductCount[index].text.length));
      } else {
        selectedProductsList.add(ModelProduct(
            name: _selectedProductData!.name,
            id: _selectedProductData!.id,
            price: double.parse(totalPriceController.text),
            counter: int.parse(quantityController.text),
            images: _selectedProductData!.images,
            isButton: _selectedProductData!.isButton,
            isItemSelected: _selectedProductData!.isItemSelected,
            batchPriceList: getAvailableBatches(
                _selectedProductData!), // _selectedProductData.batchPriceList,
            unitPrice: _selectedProductData!.unitPrice,
            quantity: _selectedProductData!.quantity,
            offerData: getActiveOffer(_selectedProductData!.offerList!),
            offerSelected: false));

        _enterProductCount.add(new TextEditingController());
        batchPricingDropdownList.add(null);
      }

      _selectedProductData = null;
      productNameController.clear();
      quantityController.clear();
      priceController.clear();
      totalPriceController.clear();
    });
  }

  List<BatchPriceDAO> getAvailableBatches(ModelProduct productData) {
    List<BatchPriceDAO> _batchNumber = [];
    for (var i = 0; i < productData.batchPriceList!.length; i++) {
      if (productData.batchPriceList![i].quantity != 0 &&
          productData.batchPriceList![i].price != 0) {
        _batchNumber.add(productData.batchPriceList![i]);
      }
    }
    return _batchNumber;
  }

  removeProductsFromSelectedProducts(int index, StateSetter setState) async {
    final action = await Dialogs.yesCancelDialog(
        context,
        Language().getString(Constants.WARNING, selectedLang),
        Language().getString(Constants.WARNING_TEXT, selectedLang),
        Language().getString(Constants.OKAY_STR, selectedLang),
        "",
        false);

    if (action == DialogAction.yes) {
      setState(() {
        selectedProductsList.removeAt(index);
        batchPricingDropdownList.removeAt(index);
      });
    }
  }

  OffersDAO? getActiveOffer(List<OffersDAO> offersList) {
    OffersDAO? _activeOffer;

    for (int i = 0; i < offersList.length; i++) {
      if (offersList[i].isOfferActive! && !offersList[i].isOfferExpired!) {
        _activeOffer = offersList[i];
      }
    }

    return _activeOffer;
  }

  Widget showOfferCheckBox(OffersDAO? offerData, index, StateSetter setState) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 10.0, vertical: 10.0),
      child: Row(
        // crossAxisAlignment: CrossAxisAlignment.end,
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Container(
            height: 25.0,
            width: 25.0,
            child: Checkbox(
              activeColor: Color(Constants.APP_COLOR),
              value: selectedProductsList[index].offerSelected,
              onChanged: (value) {
                setState(() {
                  selectedProductsList[index].offerSelected = value;
                });
              },
            ),
          ),
          Container(
            child: InkWell(
              onTap: () {
                Dialogs.showOffer(
                    context,
                    offerData!.offerQuantity,
                    offerData.offerName,
                    offerData.minOrder,
                    offerData.maxOrder,
                    offerData.offerType);
              },
              child: Text(
                Language().getString(Constants.OFFER, selectedLang),
                style: TextStyle(
                    color: StyleView.offerColor,
                    decoration: TextDecoration.underline),
              ),
            ),
          )
        ],
      ),
    );
  }

  showConfirmationPopup() {
    return showDialog(
      context: context,
      barrierColor: Colors.black54,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        actions: [
          Container(
            child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  TextButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    child: Text(
                      Language().getString(Constants.STR_CANCEL, selectedLang),
                      style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                        fontSize: 18.0,
                      ),
                    ),
                  ),
                  TextButton(
                    onPressed: () async {
                      Navigator.of(context).pop();
                      if (await NetworkStatus.getInternetStatus()) {
                        postBodyForProductsSell();
                      } else {
                        AppUtills.showSnackBar(
                            _scaffoldkey,
                            Language()
                                .getString(Constants.NO_INTERNET, selectedLang),
                            snackBarBgColor: Colors.black,
                            messageColor: Colors.white,
                            buttonColor: Colors.white);
                      }
                    },
                    child: Text(
                      Language().getString(Constants.NO_STRING, selectedLang),
                      style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                        fontSize: 18.0,
                      ),
                    ),
                  ),
                  TextButton(
                    onPressed: () {
                      Navigator.of(context).pop();

                      showInvoiceDiscountPopup();
                    },
                    child: Text(
                      Language().getString(Constants.YES_STRING, selectedLang),
                      style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                        fontSize: 18.0,
                      ),
                    ),
                  ),
                ]),
          )
        ],
        contentPadding: EdgeInsets.fromLTRB(25.0, 25.0, 10.0, 25.0),
        content: Container(
          child: Text(
            Language()
                .getString(Constants.ADD_ADDITIONAL_DISCOUNT, selectedLang),
            style: TextStyle(
                color: Colors.black, fontWeight: StyleView.fontMedium),
          ),
        ),
      ),
    );
  }

  showInvoiceDiscountPopup() {
    radioButtonValue = Constants.OFFER_IN_PERCENTAGE;
    discountType = "percent";
    return showDialog(
        context: context,
        barrierColor: Colors.black54,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    _rupeeController.clear();
                    offerInPercentage = null;
                    radioButtonValue = null;
                  },
                  child: Text(
                    Language().getString(Constants.STR_CANCEL, selectedLang),
                    style: TextStyle(
                      color: Color(Constants.APP_COLOR),
                      fontSize: 18.0,
                    ),
                  ),
                ),
                TextButton(
                  onPressed: () async {
                    Navigator.of(context).pop();
                    if (await NetworkStatus.getInternetStatus()) {
                      postBodyForProductsSell();
                    } else {
                      AppUtills.showSnackBar(
                          _scaffoldkey,
                          Language()
                              .getString(Constants.NO_INTERNET, selectedLang),
                          snackBarBgColor: Colors.black,
                          messageColor: Colors.white,
                          buttonColor: Colors.white);
                    }
                  },
                  child: Text(
                    Language().getString(Constants.OKAY_STR, selectedLang),
                    style: TextStyle(
                      color: Color(Constants.APP_COLOR),
                      fontSize: 18.0,
                    ),
                  ),
                ),
              ],
              contentPadding: EdgeInsets.fromLTRB(25.0, 25.0, 10.0, 25.0),
              content: StatefulBuilder(
                  builder: (BuildContext context, StateSetter setState) {
                return SingleChildScrollView(
                  child: Container(
                    // height: 350.0,
                    child: Column(
                      children: [
                        Container(
                          child: Row(
                            children: [
                              Radio(
                                  activeColor: Color(Constants.APP_COLOR),
                                  value: Constants.OFFER_IN_PERCENTAGE,
                                  groupValue: radioButtonValue,
                                  onChanged: (dynamic value) {
                                    setState(() {
                                      radioButtonValue =
                                          Constants.OFFER_IN_PERCENTAGE;
                                      discountType = "percent";
                                      _rupeeController.clear();
                                    });
                                  }),
                              Expanded(
                                child: Text(
                                  Language().getString(
                                      Constants.OFFER_IN_PERCENTAGE,
                                      selectedLang),
                                  style: TextStyle(
                                      color: Color(Constants.APP_COLOR)),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          child: Row(
                            children: [
                              Radio(
                                  activeColor: Color(Constants.APP_COLOR),
                                  value: Constants.OFFER_IN_AMOUNT,
                                  groupValue: radioButtonValue,
                                  onChanged: (dynamic value) {
                                    setState(() {
                                      radioButtonValue =
                                          Constants.OFFER_IN_AMOUNT;
                                      discountType = "number";

                                      offerInPercentage = null;
                                    });
                                  }),
                              Expanded(
                                child: Text(
                                  Language().getString(
                                          Constants.OFFER_IN_AMOUNT,
                                          selectedLang) +
                                      " ( $orgCurrencySymbol ) ",
                                  style: TextStyle(
                                      color: Color(Constants.APP_COLOR)),
                                ),
                              ),
                            ],
                          ),
                        ),
                        (radioButtonValue == Constants.OFFER_IN_AMOUNT)
                            ? buildInputFieldForAmount()
                            : buildOfferPercentageDropdown(setState)
                      ],
                    ),
                  ),
                );
              }),
            ));
  }

  buildInputFieldForAmount() {
    return Container(
      height: 40.0,
      margin: EdgeInsets.symmetric(
        vertical: 10.0,
      ),
      decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(
            color: Colors.grey,
          ),
          borderRadius: BorderRadius.circular(5.0)),
      child: Padding(
        padding: const EdgeInsets.all(5.0),
        child: TextFormField(
          controller: _rupeeController,
          keyboardType: TextInputType.numberWithOptions(signed: true),
          inputFormatters: [CommonMethods.inputTextFormatter(isNumber: true)],
          decoration: InputDecoration(
              border: InputBorder.none,
              hintText:
                  Language().getString(Constants.ENTER_AMOUNT, selectedLang),
              contentPadding: EdgeInsets.only(bottom: 10.0)),
        ),
      ),
    );
  }

  buildOfferPercentageDropdown(StateSetter setState) {
    return Container(
      margin: EdgeInsets.symmetric(
        vertical: 5.0,
      ),
      height: 50.0,
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(
          color: Colors.grey,
        ),
        borderRadius: BorderRadius.circular(5.0),
      ),
      padding: EdgeInsets.all(5),
      child: DropdownButton<String>(
        onTap: () {
          FocusScope.of(context).unfocus();
        },
        value: offerInPercentage,
        hint: new Text("%"),
        isExpanded: true,
        underline: SizedBox(),
        onChanged: (String? data) {
          setState(() {
            offerInPercentage = data;
          });
        },
        items: Constants.PERCENTAGELIST.map((String model) {
          return new DropdownMenuItem<String>(
            child: new Text(model),
            value: model,
          );
        }).toList(),
      ),
    );
  }

  Future<void> loadBuListInvoiceData(
      {String name = "", String invoice = ""}) async {
    if (await NetworkStatus.getInternetStatus()) {
      if (!isForSearchParams) {
        isLoadingProgress = true;
      }
      Map<String, dynamic> mapData = {
        "name": name,
        "bill_no": invoice,
        "DateFrom": fromDateController.text,
        "DateTo": toDateController.text
      };
      List<BuListOrderDataDAO> fetchInvoiceData =
          await TransactionApiService.instance.getOfflineInvoiceData(
              context: context,
              cooectionBuId: widget.recordId!,
              mapData: mapData,
              langError: Language().getString(Constants.ERROR, selectedLang),
              langOk: Language().getString(Constants.OKAY_STR, selectedLang));
      setState(() {
        isLoadingProgress = false;
        buListInvoice.clear();
      });

      if (fetchInvoiceData.length > 0) {
        for (int i = 0; i < fetchInvoiceData.length; i++) {
          if (fetchInvoiceData[i].seller!.id == buId) {
            buListInvoice.add(fetchInvoiceData[i]);
          }
        }
        setState(() => buListInvoice);
      } else {
        setState(() => showLoaderText =
            Language().getString(Constants.NO_PREVIOUS_ORDERS, selectedLang));
      }
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<void> loadProductData(String parms, StateSetter setState) async {
    if (await NetworkStatus.getInternetStatus()) {
      Map<String, dynamic> mapData = {
        "name": productNameController.text,
        "for_sale": true,
        "from": 0,
        "count": 10,
        "isDesc": true
      };
      List<BuProductModal> fetchProductsData = await ProductsApiService.instance
          .getBuProducts(
              context: context,
              buId: buId,
              mapFilter: mapData,
              langError: Language().getString(Constants.ERROR, selectedLang),
              langOk: Language().getString(Constants.OKAY_STR, selectedLang));
      setState(() {
        isLoadingProgress = false;
        responseProducts.clear();
        _productsList.clear();
      });

      if (fetchProductsData.length > 0) {
        responseProducts.addAll(fetchProductsData);
        for (var itemData in responseProducts) {
          if (itemData.batchPrice!.length > 0) {
            _productsList.add(ModelProduct(
                id: itemData.id,
                name: itemData.name,
                counter: 0,
                isButton: false,
                images: itemData.imageThumbnail!.length > 0
                    ? itemData.imageThumbnail![0].image
                    : null,
                price: 0,
                quantity: itemData.batchPrice![0].quantity,
                isItemSelected: false,
                unitPrice: itemData.batchPrice![0].price,
                batchPriceList: itemData.batchPrice,
                offerList: itemData.offers));
          } else {
            showProductText =
                Language().getString(Constants.NO_DATA_FOUND, selectedLang);
          }
        }
        setState(() {
          _productsList = _productsList;
          showProductText = "";
          _isShowNames = true;
          showProductText = showProductText;
        });
      } else {
        setState(() => showProductText =
            Language().getString(Constants.NO_DATA_FOUND, selectedLang));
      }
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }
}
