import 'dart:io';

import 'package:intl/intl.dart';
import 'package:vyaparlive/core/enums/privilleges_enum.dart';
import 'package:vyaparlive/image_hero/ImageHeroView.dart';
import 'package:vyaparlive/service/Service.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:vyaparlive/utills/webview_page.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:mime/mime.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/invoice_view/BatchPriceDropdownView.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/ModelProduct.dart';
import 'dart:convert';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/model/product_model/BatchPriceDAO.dart';
import 'package:vyaparlive/model/product_model/ProductModel.dart';
import 'package:vyaparlive/service/bu_list_grpc_service.dart';
import 'package:vyaparlive/service/product_services.dart';
import 'package:toast/toast.dart';

class GenerateOfflineInvociePage extends StatefulWidget {
  final List<ModelProduct>? products;
  final String? transactionId;
  final String? offlineBuyer;
  final String? offlineSeller;
  final String? seller_invoice;
  GenerateOfflineInvociePage(
      {this.products,
      this.transactionId,
      required this.offlineBuyer,
      required this.offlineSeller,
      this.seller_invoice});
  @override
  _GenerateOfflineInvociePageState createState() =>
      _GenerateOfflineInvociePageState();
}

class _GenerateOfflineInvociePageState
    extends State<GenerateOfflineInvociePage> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? buName = "";
  String? radioButtonValue = Constants.OFFER_IN_PERCENTAGE;
  String discountType = "percent";
  String termsRadioButtonValue = "";
  final _rupeeController = TextEditingController();
  String? offerInPercentage;
  List<ModelProduct> selectedProductsList = [];
  int? _selectedCount = 0;
  bool isOfferActive = false;
  final List<TextEditingController> unitPriceController = [];
  String termType = "";
  String buttonText = "";
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  String url = "";
  late BuListGrpcService _transactionService;
  List<TextEditingController> _quantityInputController = [];
  bool isEnableTextEditingController = true;
  TextEditingController _invoiceController = TextEditingController();
  List<bool> isShowBatchPrice = [];
  List<Radio> singleSelectionBatchPrice = [];
  List<BatchPriceDAO?> batchPriceDropdown = [];
  List<BuProductModal> _productList = [];
  late ProductService _productService;
  String? buId = "";
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  List<String?> productTypeList = [];
  List<TextEditingController?> _batchNumberController = [];
  late ThemeData theme;
  File? imageFile;
  String? imageBlob = '';
  late Service _service;
  Uint8List? _webImage;
  bool isSelectCaptureChoice = false;
  bool isImageUpdated = false;
  String imageRelativePath = '';
  bool isIncludeGST = true;
  bool addAdditionalDiscount = false;
  @override
  void initState() {
    super.initState();
    _service = Service();
    theme = AppTheme.vyaparTheme;
    _transactionService = BuListGrpcService();
    _productService = ProductService();
    this.renderProductsToList();
    buName = AppController.instance.getBuName;
    buId = AppController.instance.getMyBuId;

    if (widget.seller_invoice != null && widget.seller_invoice!.isNotEmpty) {
      imageRelativePath = widget.seller_invoice!;
    }
  }

  validation() {
    String text = '';
    // if (imageRelativePath.isEmpty) {
    //   return text = Constants.STR_ERROR_IMAGE_RELATIVE_PATH_OFFLINE_INVOICE;
    // }
    if (_invoiceController.text.isEmpty) {
      return text = Constants.INVOICE_NO_PLEASE;
    }
    for (int i = 0; i < selectedProductsList.length; i++) {
      if (selectedProductsList[i].isButton!) {
        String productName = selectedProductsList[i].name!;
        if (unitPriceController[i].text.isEmpty) {
          return text = Language()
                  .getString(Constants.ENTER_UNIT_PRICE_NO, selectedLang) +
              " $productName";
        }

        if (_batchNumberController[i]!.text.isEmpty) {
          return text = Language()
                  .getString(Constants.PLEASE_ENTER_BATCH_NO_, selectedLang) +
              " $productName";
        }

        if (productTypeList[i] == null) {
          return text = Language()
                  .getString(Constants.PLEASE_SELECT_INVENTORY_, selectedLang) +
              " $productName";
        }
      }
    }

    return text;
  }

  openBottomSheet(BuildContext context) {
    return Dialogs.openBottomSheet(
        context: context,
        openCamera: (myPicture) async {
          updateProductImage(myPicture);
        },
        openGallery: (myPicture) async {
          updateProductImage(myPicture);
        });
  }

  updateProductImage(var fileImage) {
    Navigator.of(context).pop();
    if (fileImage != null) {
      setState(() {
        imageFile = fileImage;
        isSelectCaptureChoice = true;
        isImageUpdated = true;
        imageBlob = AppUtills.getBase64Image(fileImage, context);
      });
      List<String> fileName = imageFile!.path.split('/');
      uploadImage(imageFile,
          "${widget.offlineSeller}_offline_invoice_to_${widget.offlineBuyer}_${fileName.last}",
          fileType: lookupMimeType(imageFile!.path)!);
    }
  }

  uploadImage(dynamic imageData, String fileName,
      {String fileType = ''}) async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = "Fetching..";
    });
    Map data = {
      "filename":
          fileName, //(kIsWeb) ? fileName : imageData.path.split("/").last,
      "location": "terms"
    };
    String body = json.encode(data);

    http.Response response = await _service
        .getPresignedUrl(body); //_service.get_file_upload_url(null);

    if (response.statusCode == 200) {
      var responseBody = json.decode(response.body);
      setState(() {
        progressMessage = "Uploading image..";
      });
      print('relative path ${responseBody['relativepath']}');

      var uploadFileRes = await _service
          .uploadToS3Signed(responseBody['url'], imageData, fileType: fileType);
      print(uploadFileRes);
      setState(() {
        imageRelativePath = responseBody['relativepath'];

        isLoadingProgress = false;
      });
      Toast.show(
        Constants.FILE_UPLAODED,
        duration: Toast.lengthShort,
        gravity: Toast.bottom,
      );

      // this.submitInputData(relativePath: responseBody['relativepath']);
    } else {
      setState(() {
        isLoadingProgress = false;
      });
    }
  }

  displayImageView() {
    if (imageRelativePath.isNotEmpty) {
      List<String?> path = imageRelativePath.split('/');
      return InkWell(
        onTap: () {
          if (kIsWeb) {
            AppUtills.launchURL(
                '${Constants.IAMGE_BUCKET_URL}$imageRelativePath');
          } else {
            if (lookupMimeType(imageRelativePath) == 'application/pdf') {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => WebViewPage(
                          url:
                              '${Constants.IAMGE_BUCKET_URL}$imageRelativePath',
                          screenName: "",
                          loadS3PDF: true)));
            } else {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => ImageHeroView(
                            fileUrl:
                                '${Constants.IAMGE_BUCKET_URL}$imageRelativePath',
                            tagName: path[1],
                          )));
            }
          }
        },
        child: Container(
          padding: EdgeInsets.all(10),
          alignment: Alignment.center,
          decoration: BoxDecoration(color: Colors.white70),
          child: Text(
            '${widget.offlineSeller} Offline Invoice To ${widget.offlineBuyer}', // path[1].toString(),
            style: TextStyle(
                color: theme.colorScheme.primary,
                fontWeight: StyleView.fontMedium,
                fontSize: 14,
                decoration: TextDecoration.underline),
          ),
        ),
      );
    } else {
      return SizedBox();
    }
  }

  @override
  Widget build(BuildContext context) {
    ToastContext().init(context);
    return AppBackgroundView(
        body: Stack(
      children: [
        SafeArea(
          child: Scaffold(
            key: _scaffoldkey,
            backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
            appBar: AppBar(
              centerTitle: true,
              backgroundColor: Colors.transparent, //(Constants.APP_COLOR),
              elevation: 0,
              iconTheme: IconThemeData(color: theme.colorScheme.primary),
              title: AppbarName(
                  title: Language()
                      .getString(Constants.GENERATE_INVOICE, selectedLang),
                  buName: "$buName"),
              actions: [
                AppUtills.homeButton(context),
              ],
            ),
            bottomNavigationBar: Container(
              padding: EdgeInsets.only(left: 10, right: 10, bottom: 30),
              child: CommonButtonsView(
                context: context,
                b1Text: "",
                b2Text: Language()
                    .getString(Constants.GENERATE_INVOICE, selectedLang),
                onb2Action: () async {
                  String validationText = validation();
                  if (validationText.isNotEmpty) {
                    Dialogs.yesCancelDialog(
                        context,
                        Language().getString(Constants.ERROR, selectedLang),
                        Language().getString(validationText, selectedLang),
                        Language().getString(Constants.OKAY_STR, selectedLang),
                        "",
                        false);
                  } else {
                    showConfirmationPopup();
                  }
                },
              ),
            ),
            body: Container(
              decoration: AppUtills.appBackgroundWithImage(),
              margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 5.0),
              child: Column(
                children: [
                  Container(
                    margin: EdgeInsets.only(bottom: 10.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          margin: EdgeInsets.symmetric(horizontal: 5.0),
                          child: Text(
                            Language().getString(
                                    Constants.INVOICE_NO, selectedLang) +
                                " : ",
                            style: TextStyle(
                                color: Color(Constants.APP_COLOR),
                                fontSize: 15.0,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                        Container(
                          height: 30.0,
                          width: 60.0,
                          alignment: Alignment.bottomCenter,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5),
                              border: Border.all(color: Colors.grey)),
                          child: TextFormField(
                              textAlign: TextAlign.center,
                              enabled: isEnableTextEditingController,
                              enableInteractiveSelection: false,
                              cursorWidth: 1.0,
                              controller: _invoiceController,
                              decoration: InputDecoration(
                                contentPadding: EdgeInsets.only(
                                    bottom: Constants.CONTENT_PADDING_18_15),
                                hintText: "0",
                                border: InputBorder.none,
                              ),
                              keyboardType:
                                  TextInputType.numberWithOptions(signed: true),
                              style: TextStyle(fontSize: 12.0),
                              inputFormatters: [
                                new LengthLimitingTextInputFormatter(5),
                                CommonMethods.inputTextFormatter(isNumber: true)
                              ],
                              onChanged: (value) async {}),
                        )
                      ],
                    ),
                  ),
                  Container(
                      padding: EdgeInsets.all(8.0),
                      decoration: BoxDecoration(color: Colors.white70),
                      child: Container(
                        padding: EdgeInsets.only(left: 10),
                        child: Align(
                            alignment: Alignment.center,
                            child: Row(
                              children: [
                                Container(
                                  child: Text(
                                    Language().getString(
                                            Constants.UPLOAD_SELLER_INVOICE,
                                            selectedLang) +
                                        " : ",
                                    style: TextStyle(
                                        color: theme.colorScheme.primary,
                                        fontWeight: StyleView.fontMedium),
                                  ),
                                ),
                                SizedBox(width: 10),
                                InkWell(
                                  onTap: () async {
                                    if (kIsWeb) {
                                      PlatformFile? selectedFile;
                                      selectedFile = await CommonMethods()
                                          .getFileUpload(context,
                                              isForMultiFile: true);
                                      if (selectedFile != null) {
                                        Uint8List bytes = selectedFile.bytes!;
                                        setState(() {
                                          isSelectCaptureChoice = true;
                                        });
                                        uploadImage(bytes,
                                            "${widget.offlineSeller}_offline_invoice_to_${widget.offlineBuyer}_${selectedFile.name}", //"${AppController.instance.buName}_offline_invoice_${selectedFile.name}",
                                            fileType: selectedFile.extension ==
                                                    'pdf'
                                                ? 'application/pdf'
                                                : 'image/${selectedFile.extension}');
                                      }
                                    } else {
                                      openBottomSheet(context);
                                    }
                                  },
                                  child: Icon(
                                    Icons.camera_alt,
                                    color: Color(Constants.APP_COLOR),
                                    size: 30.0,
                                  ),
                                ),
                              ],
                            )),
                      )),
                  displayImageView(),
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                          border:
                              Border.all(color: Color(Constants.APP_COLOR))),
                      child: Column(
                        children: [
                          Container(
                            child: Row(
                              children: [
                                Expanded(
                                  // flex: 2,
                                  child: Padding(
                                    padding: const EdgeInsets.all(5.0),
                                    child: Text(
                                      Language().getString(
                                          Constants.PRODUCTS_STR, selectedLang),
                                      style: TextStyle(
                                        color: Color(Constants.APP_COLOR),
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ),
                                Expanded(
                                  // flex: 2,
                                  child: Padding(
                                    padding: const EdgeInsets.all(5.0),
                                    child: Text(
                                      Language().getString(
                                          Constants.QUANTITY, selectedLang),
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: Color(Constants.APP_COLOR),
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: Center(
                                    child: Padding(
                                      padding: const EdgeInsets.all(5.0),
                                      child: Text(
                                        Language().getString(
                                            Constants.PRICE_UNIT, selectedLang),
                                        style: TextStyle(
                                          color: Color(Constants.APP_COLOR),
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Divider(
                            color: Color(Constants.APP_COLOR),
                          ),
                          Expanded(
                            child: Container(
                              child: ListView.separated(
                                separatorBuilder: (context, index) => Divider(
                                  color: Colors.transparent,
                                  height: 5.0,
                                ),
                                itemBuilder: (context, index) {
                                  return Container(
                                    child: renderProductDataDesign(index),
                                  );
                                },
                                itemCount: selectedProductsList.length,
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    ));
  }

  /// Desinging for show products data in ROW
  renderProductDataDesign(int index) {
    return Container(
      child: Card(
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  // flex: 2,
                  child: Padding(
                    padding: const EdgeInsets.all(5.0),
                    child: Row(
                      children: [
                        Container(
                          height: 25.0,
                          width: 25.0,
                          margin: EdgeInsets.symmetric(
                            horizontal: 5.0,
                          ),
                          child: Checkbox(
                              activeColor: Color(Constants.APP_COLOR),
                              value: selectedProductsList[index].isButton,
                              onChanged: (value) {
                                setState(() {
                                  selectedProductsList[index].isButton = value;
                                });
                              }),
                        ),
                        Expanded(
                            child: Text(
                          "${selectedProductsList[index].name}",
                          style: TextStyle(
                            fontSize: 13.0,
                            color: Color(Constants.APP_COLOR),
                            fontWeight: FontWeight.bold,
                          ),
                        )),
                      ],
                    ),
                  ),
                ),
                Expanded(
                  // flex: 3,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      (isEnableTextEditingController)
                          ? InkWell(
                              onTap: () {
                                if (selectedProductsList[index].isButton!) {
                                  this.renderRemoveProductQuantity(
                                      index, setState);
                                } else {
                                  Dialogs.yesCancelDialog(
                                      context,
                                      Language().getString(
                                          Constants.INFO, selectedLang),
                                      Language().getString(
                                          Constants
                                              .SELECT_PRODUCT_FURTHER_ACTION,
                                          selectedLang),
                                      Constants.OKAY_STR,
                                      "",
                                      false);
                                }
                              },
                              child: Icon(Icons.remove),
                            )
                          : Container(),
                      this.designQuantityInputField(index),
                      (isEnableTextEditingController)
                          ? InkWell(
                              onTap: () {
                                if (selectedProductsList[index].isButton!) {
                                  this.renderAddProductQuantity(
                                      index, setState);
                                } else {
                                  Dialogs.yesCancelDialog(
                                      context,
                                      Language().getString(
                                          Constants.INFO, selectedLang),
                                      Language().getString(
                                          Constants
                                              .SELECT_PRODUCT_FURTHER_ACTION,
                                          selectedLang),
                                      Language().getString(
                                          Constants.OKAY_STR, selectedLang),
                                      "",
                                      false);
                                }
                              },
                              child: Icon(Icons.add),
                            )
                          : Container()
                    ],
                  ),
                ),
                this.renderProductUnitPrice(index),
                // this.renderProductOffers(index)
              ],
            ),
            // (selectedProductsList[index].batchPriceList.length > 0)
            //     ? this.batchPriceDropdownView(
            //         selectedProductsList[index].batchPriceList, index)
            //     : Container()

            this.customBatchNumberView(index),
            this.radioButtonsView(index)
          ],
        ),
      ),
    );
  }

  batchPriceDropdownView(List<BatchPriceDAO> batchNubmerList, int index) {
    if (batchNubmerList.length > 0) {
      if (batchPriceDropdown[index] == null) {
        batchPriceDropdown[index] = batchNubmerList[0];
      }

      return BatchPriceDropDownView(
          canShowPrice: false,
          canShowDynamicPricing: false,
          currentDropdownIndex: index,
          batchDropdown: batchPriceDropdown,
          batchPricingList: batchNubmerList,
          selectedDropdownValue: (data) {
            setState(() {
              batchPriceDropdown[index] = data;
              selectedProductsList[index].unitPrice =
                  batchPriceDropdown[index]!.price;
            });
          },
          strBatchPricing:
              Language().getString(Constants.BATCH_NO, selectedLang),
          strAvailableQuantity:
              Language().getString(Constants.AVAILABLE_QUANTITY, selectedLang));
    }
  }

  designQuantityInputField(int index) {
    return Container(
      height: 30.0,
      width: 60.0,
      alignment: Alignment.bottomCenter,
      decoration: BoxDecoration(border: Border.all(color: Colors.grey)),
      child: TextFormField(
        textAlign: TextAlign.center,
        enabled: isEnableTextEditingController,
        enableInteractiveSelection: false,
        cursorWidth: 1.0,
        controller: _quantityInputController[index],
        decoration: InputDecoration(
            hintText: "0",
            border: InputBorder.none,
            contentPadding: CommonMethods.textInputControllerPadding()),
        keyboardType: TextInputType.numberWithOptions(signed: true),
        style: TextStyle(fontSize: 12.0),
        inputFormatters: [
          new LengthLimitingTextInputFormatter(5),
          FilteringTextInputFormatter.digitsOnly
        ],
        onChanged: (value) async {
          /// Adding input value for product counter value
          if (value.isEmpty) {
            final action = await Dialogs.yesCancelDialog(
                context,
                Language().getString(Constants.ERROR, selectedLang),
                Language().getString(
                    Constants.QUANTITY_SHOULD_NOT_BE_EMPTY, selectedLang),
                Language().getString(Constants.OKAY_STR, selectedLang),
                "",
                false);

            if (action == DialogAction.yes) {
              setState(() {
                _quantityInputController[index].text =
                    widget.products![index].quantity.toString();
                selectedProductsList[index].quantity =
                    widget.products![index].quantity;
              });
            }
          } else if (int.parse(value) > selectedProductsList[index].quantity!) {
            final action = await Dialogs.yesCancelDialog(
                context,
                Language().getString(Constants.ERROR, selectedLang),
                Language().getString(
                    Constants.QUANTITY_SHOULD_NOT_BE_MORE_THAN_ACTUAL_QUANTITY,
                    selectedLang),
                Language().getString(Constants.OKAY_STR, selectedLang),
                "",
                false);

            if (action == DialogAction.yes) {
              setState(() {
                selectedProductsList[index].quantity =
                    widget.products![index].quantity;
                _quantityInputController[index] = TextEditingController(
                    text: selectedProductsList[index].quantity.toString());
                _quantityInputController[index].selection =
                    TextSelection.fromPosition(TextPosition(
                        offset: _quantityInputController[index].text.length));
              });
            }
          } else {
            if (selectedProductsList.length > 0) {
              setState(() {
                selectedProductsList[index].quantity = int.parse(value);
              });
            }
          }
        },
      ),
    );
  }

  /// Showing product Offers
  renderProductOffers(int index) {
    return Expanded(
      child: (selectedProductsList[index].offerData != null)
          ? Column(
              children: [
                Container(
                  height: 25.0,
                  width: 25.0,
                  child: Checkbox(
                    activeColor: Color(Constants.APP_COLOR),
                    value: selectedProductsList[index].offerSelected,
                    onChanged: (value) {
                      setState(() {
                        selectedProductsList[index].offerSelected = value;
                      });
                    },
                  ),
                ),
                Container(
                  child: InkWell(
                    onTap: () {
                      Dialogs.showOffer(
                          context,
                          selectedProductsList[index].offerData!.offerQuantity,
                          selectedProductsList[index].offerData!.offerName,
                          selectedProductsList[index].offerData!.minOrder,
                          selectedProductsList[index].offerData!.maxOrder,
                          selectedProductsList[index].offerData!.offerType);
                    },
                    child: Text(
                      "Offer",
                      style: TextStyle(
                          color: StyleView.offerColor,
                          decoration: TextDecoration.underline),
                    ),
                  ),
                )
              ],
            )
          : Center(
              child: Text(
                "No active offer",
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontSize: 11.0,
                    color: StyleView.offerColor,
                    fontWeight: FontWeight.bold),
              ),
            ),
    );
  }

  /// Showing Product unit price
  renderProductUnitPrice(int index) {
    /// Getting unit price from selectedProductsList and adding it to TextEditing Controller
    if (isShowBatchPrice[index]) {
      // unitPriceController[index] = TextEditingController(
      //     text: selectedProductsList[index].batchPriceList[0].price.toString());
      unitPriceController[index].selection = TextSelection.fromPosition(
          TextPosition(offset: unitPriceController[index].text.length));
      isShowBatchPrice[index] = false;
    } else {
      // unitPriceController[index] = TextEditingController(
      //     text: selectedProductsList[index].unitPrice.toString());
      unitPriceController[index].selection = TextSelection.fromPosition(
          TextPosition(offset: unitPriceController[index].text.length));
    }

    return Expanded(
      child: Container(
        height: 25.0,
        width: 0.0,
        margin: EdgeInsets.symmetric(horizontal: 20.0),
        decoration: BoxDecoration(
          border: Border.all(
            color: Colors.grey,
          ),
        ),
        child: TextFormField(
          cursorWidth: 1.0,
          enableInteractiveSelection: false,
          textAlign: TextAlign.center,
          controller: unitPriceController[index],
          keyboardType: TextInputType.numberWithOptions(signed: true),
          style: TextStyle(
            fontSize: 12.0,
            fontWeight: FontWeight.bold,
          ),
          decoration: InputDecoration(
              border: InputBorder.none,
              hintText: "0",
              contentPadding: CommonMethods.textInputControllerPadding()),
          inputFormatters: [
            new LengthLimitingTextInputFormatter(8),
            FilteringTextInputFormatter.digitsOnly
          ],
          onChanged: (value) {
            String data = value.isEmpty ? '0' : value;

            /// Adding updated unit price to selected list
            selectedProductsList[index].unitPrice = double.parse(data);
          },
        ),
      ),
    );
  }

  /// Showing product quantity
  renderProductQuantity(int index) {
    return new Container(
      height: 20.0,
      width: 40.0,
      margin: EdgeInsets.symmetric(
        horizontal: 3.0,
      ),
      decoration: BoxDecoration(border: Border.all(color: Colors.grey)),
      child: Center(
        child: Text(
          "${selectedProductsList[index].quantity}",
          style: TextStyle(fontSize: 11.0, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }

  /// Removing product quantity
  renderRemoveProductQuantity(int index, StateSetter setState) {
    _selectedCount = selectedProductsList[index].quantity as int?;

    if (_selectedCount == 1) {
      setState(() {
        selectedProductsList[index].quantity = _selectedCount;
        _quantityInputController[index] = TextEditingController(
            text: selectedProductsList[index].quantity.toString());
        _quantityInputController[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _quantityInputController[index].text.length));
      });
    } else {
      _selectedCount = _selectedCount! - 1;
      setState(() {
        selectedProductsList[index].quantity = _selectedCount;
        _quantityInputController[index] = TextEditingController(
            text: selectedProductsList[index].quantity.toString());
        _quantityInputController[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _quantityInputController[index].text.length));
      });
    }
  }

  /// Adding product quantiy
  renderAddProductQuantity(int index, StateSetter setState) {
    int? _count = selectedProductsList[index].quantity as int?;

    if (_count == widget.products![index].quantity) {
      setState(() {
        selectedProductsList[index].quantity = _count;
        _quantityInputController[index] = TextEditingController(
            text: selectedProductsList[index].quantity.toString());
        _quantityInputController[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _quantityInputController[index].text.length));
      });
    } else {
      _count = _count! + 1;
      setState(() {
        selectedProductsList[index].quantity = _count;
        _quantityInputController[index] = TextEditingController(
            text: selectedProductsList[index].quantity.toString());
        _quantityInputController[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _quantityInputController[index].text.length));
      });
    }
  }

  renderProductsToList() {
    for (int i = 0; i < widget.products!.length; i++) {
      if (widget.products![i].quantity != 0) {
        /// Adding TextEditingControllers to a list
        unitPriceController.add(new TextEditingController());
        _quantityInputController.add(new TextEditingController());
        batchPriceDropdown.add(null);
        productTypeList.add(Constants.SALABLE_PRODUCTS);
        final String today = DateFormat('yyyy/MM/dd').format(DateTime.now());
        _batchNumberController.add(new TextEditingController(text: today));
        setState(() {
          isEnableTextEditingController = true;
          selectedProductsList.add(
            ModelProduct(
                id: widget.products![i].id,
                images: widget.products![i].images,
                name: widget.products![i].name,
                quantity: widget.products![i].quantity,
                counter: 0,
                isButton: true,
                isItemSelected: false,
                unitPrice: widget.products![i].unitPrice,
                price: widget.products![i].price,
                offerData: widget.products![i].offerData,
                offerSelected: widget.products![i].offerSelected,
                batchPriceList: widget.products![i].batchPriceList,
                offerList: []),
          );

          isShowBatchPrice.add(true);
          singleSelectionBatchPrice
              .add(Radio(value: null, groupValue: null, onChanged: null));
          _quantityInputController[i] = TextEditingController(
              text: widget.products![i].quantity.toString());
          _quantityInputController[i].selection = TextSelection.fromPosition(
            TextPosition(offset: _quantityInputController[i].text.length),
          );
        });
        // this.loadBatchNumbersList(widget.products[i].id);
      }
    }
  }

  showConfirmationPopup() {
    return showDialog(
      context: context,
      barrierColor: Colors.black54,
      barrierDismissible: false,
      builder: (context) => StatefulBuilder(builder: (context, setState) {
        return AlertDialog(
          actions: [
            TextButton(
              onPressed: () async {
                Navigator.of(context).pop();
              },
              child: Text(
                Language().getString(Constants.STR_CANCEL, selectedLang),
                style: TextStyle(
                  color: Color(Constants.APP_COLOR),
                  fontSize: 18.0,
                ),
              ),
            ),
            TextButton(
              onPressed: () async {
                Navigator.of(context).pop();
                if (await NetworkStatus.getInternetStatus()) {
                  setState(() {
                    isLoadingProgress = true;
                  });

                  /// For Create Invoice
                  this.serviceCallInvoice();
                } else {
                  AppUtills.showSnackBar(_scaffoldkey,
                      Language().getString(Constants.NO_INTERNET, selectedLang),
                      snackBarBgColor: Colors.black,
                      messageColor: Colors.white,
                      buttonColor: Colors.white);
                }
              },
              child: Text(
                Language().getString(Constants.GENERATE_INVOICE, selectedLang),
                style: TextStyle(
                  color: Color(Constants.APP_COLOR),
                  fontSize: 18.0,
                ),
              ),
            ),
            // TextButton(
            //   onPressed: () {
            //     Navigator.of(context).pop();
            //     this.showInvoiceDiscountPopup();
            //   },
            //   child: Text(
            //     Language().getString(Constants.YES_STRING, selectedLang),
            //     style: TextStyle(
            //       color: Color(Constants.APP_COLOR),
            //       fontSize: 18.0,
            //     ),
            //   ),
            // ),
          ],
          contentPadding: EdgeInsets.fromLTRB(25.0, 25.0, 10.0, 25.0),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              buildIncludeGSTView(setState),
              SizedBox(
                height: 5.0,
              ),
              Divider(
                color: Colors.grey,
                thickness: 1,
              ),
              SizedBox(
                height: 5.0,
              ),
              buildAdditionalDiscountView(setState),
              SizedBox(
                height: 10.0,
              ),
              addAdditionalDiscount
                  ? buildAdditionalDiscountSelectionView(setState)
                  : Container(),
            ],
          ),
        );
      }),
    );
  }

  buildAdditionalDiscountSelectionView(StateSetter setState) {
    // radioButtonValue = Constants.OFFER_IN_PERCENTAGE;
    // discountType = "percent";
    return Container(
      // height: 350.0,
      child: Column(
        children: [
          Container(
            child: Row(
              children: [
                Radio(
                    activeColor: Color(Constants.APP_COLOR),
                    value: Constants.OFFER_IN_PERCENTAGE,
                    groupValue: radioButtonValue,
                    onChanged: (dynamic value) {
                      setState(() {
                        radioButtonValue = Constants.OFFER_IN_PERCENTAGE;
                        discountType = "percent";
                        _rupeeController.clear();
                      });
                    }),
                Expanded(
                  child: Text(
                    Language()
                        .getString(Constants.OFFER_IN_PERCENTAGE, selectedLang),
                    style: TextStyle(color: Color(Constants.APP_COLOR)),
                  ),
                ),
              ],
            ),
          ),
          Container(
            child: Row(
              children: [
                Radio(
                    activeColor: Color(Constants.APP_COLOR),
                    value: Constants.OFFER_IN_AMOUNT,
                    groupValue: radioButtonValue,
                    onChanged: (dynamic value) {
                      setState(() {
                        radioButtonValue = Constants.OFFER_IN_AMOUNT;
                        discountType = "number";

                        offerInPercentage = null;
                      });
                    }),
                Expanded(
                  child: Text(
                    Language()
                        .getString(Constants.OFFER_IN_AMOUNT, selectedLang),
                    style: TextStyle(color: Color(Constants.APP_COLOR)),
                  ),
                ),
              ],
            ),
          ),
          (radioButtonValue == Constants.OFFER_IN_AMOUNT)
              ? buildInputFieldForAmount()
              : buildOfferPercentageDropdown(setState)
        ],
      ),
    );
  }

  buildAdditionalDiscountView(StateSetter setState) {
    return Container(
        child: Row(
      children: <Widget>[
        Container(
          child: Checkbox(
            activeColor: Color(Constants.APP_COLOR),
            value: addAdditionalDiscount,
            onChanged: (value) {
              setState(
                () {
                  addAdditionalDiscount = value!;
                  if (!value) {
                    radioButtonValue = Constants.OFFER_IN_PERCENTAGE;
                    discountType = "percent";
                    _rupeeController.clear();
                    offerInPercentage = null;
                  }
                },
              );
            },
          ),
        ),
        Expanded(
          child: Text(
            Language()
                .getString(Constants.ADD_ADDITIONAL_DISCOUNT, selectedLang),
            style: TextStyle(
              fontWeight: StyleView.fontMedium,
              color: Color(Constants.APP_COLOR),
              fontSize: 14,
            ),
          ),
        )
      ],
    ));
  }

  buildIncludeGSTView(StateSetter setState) {
    return Container(
        child: Row(
      children: <Widget>[
        Container(
          child: Checkbox(
            activeColor: Color(Constants.APP_COLOR),
            value: isIncludeGST,
            onChanged: (value) {
              setState(
                () {
                  isIncludeGST = value!;
                },
              );
            },
          ),
        ),
        Container(
          child: Text(
            "Include GST",
            style: TextStyle(
              fontWeight: StyleView.fontMedium,
              color: Color(Constants.APP_COLOR),
              fontSize: 14,
            ),
          ),
        )
      ],
    ));
  }

  showInvoiceDiscountPopup() {
    radioButtonValue = Constants.OFFER_IN_PERCENTAGE;
    discountType = "percent";
    return showDialog(
        context: context,
        barrierColor: Colors.black54,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    _rupeeController.clear();
                    offerInPercentage = null;
                    radioButtonValue = null;
                  },
                  child: Text(
                    Language().getString(Constants.STR_CANCEL, selectedLang),
                    style: TextStyle(
                      color: Color(Constants.APP_COLOR),
                      fontSize: 18.0,
                    ),
                  ),
                ),
                TextButton(
                  onPressed: () async {
                    Navigator.of(context).pop();

                    if (await NetworkStatus.getInternetStatus()) {
                      setState(() {
                        isLoadingProgress = true;
                      });

                      /// For Create Invoice
                      this.serviceCallInvoice();
                    } else {
                      AppUtills.showSnackBar(
                          _scaffoldkey,
                          Language()
                              .getString(Constants.NO_INTERNET, selectedLang),
                          snackBarBgColor: Colors.black,
                          messageColor: Colors.white,
                          buttonColor: Colors.white);
                    }
                  },
                  child: Text(
                    Language().getString(Constants.OKAY_STR, selectedLang),
                    style: TextStyle(
                      color: Color(Constants.APP_COLOR),
                      fontSize: 18.0,
                    ),
                  ),
                ),
              ],
              contentPadding: EdgeInsets.fromLTRB(25.0, 25.0, 10.0, 25.0),
              content: StatefulBuilder(
                  builder: (BuildContext context, StateSetter setState) {
                return Container(
                  height: 200.0,
                  child: Column(
                    children: [
                      Container(
                        child: Row(
                          children: [
                            Radio(
                                activeColor: Color(Constants.APP_COLOR),
                                value: Constants.OFFER_IN_PERCENTAGE,
                                groupValue: radioButtonValue,
                                onChanged: (dynamic value) {
                                  setState(() {
                                    radioButtonValue =
                                        Constants.OFFER_IN_PERCENTAGE;
                                    discountType = "percent";
                                    _rupeeController.clear();
                                  });
                                }),
                            Expanded(
                              child: Text(
                                Language().getString(
                                    Constants.OFFER_IN_PERCENTAGE,
                                    selectedLang),
                                style: TextStyle(
                                    color: Color(Constants.APP_COLOR)),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        child: Row(
                          children: [
                            Radio(
                                activeColor: Color(Constants.APP_COLOR),
                                value: Constants.OFFER_IN_AMOUNT,
                                groupValue: radioButtonValue,
                                onChanged: (dynamic value) {
                                  setState(() {
                                    radioButtonValue =
                                        Constants.OFFER_IN_AMOUNT;
                                    discountType = "number";

                                    offerInPercentage = null;
                                  });
                                }),
                            Expanded(
                              child: Text(
                                Language().getString(
                                    Constants.OFFER_IN_AMOUNT, selectedLang),
                                style: TextStyle(
                                    color: Color(Constants.APP_COLOR)),
                              ),
                            ),
                          ],
                        ),
                      ),
                      (radioButtonValue == Constants.OFFER_IN_AMOUNT)
                          ? this.buildInputFieldForAmount()
                          : this.buildOfferPercentageDropdown(setState)
                    ],
                  ),
                );
              }),
            ));
  }

  buildInputFieldForAmount() {
    return Container(
      height: 40.0,
      margin: EdgeInsets.symmetric(
        vertical: 10.0,
      ),
      decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(
            color: Colors.grey,
          ),
          borderRadius: BorderRadius.circular(5.0)),
      child: Padding(
        padding: const EdgeInsets.all(5.0),
        child: TextFormField(
          controller: _rupeeController,
          keyboardType: TextInputType.numberWithOptions(signed: true),
          inputFormatters: [CommonMethods.inputTextFormatter(isNumber: true)],
          decoration: InputDecoration(
              border: InputBorder.none,
              hintText:
                  Language().getString(Constants.ENTER_AMOUNT, selectedLang)),
        ),
      ),
    );
  }

  buildOfferPercentageDropdown(StateSetter setState) {
    return Container(
      margin: EdgeInsets.symmetric(
        vertical: 5.0,
      ),
      height: 50.0,
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(
          color: Colors.grey,
        ),
        borderRadius: BorderRadius.circular(5.0),
      ),
      padding: EdgeInsets.all(5),
      child: DropdownButton<String>(
        onTap: () {
          FocusScope.of(context).unfocus();
        },
        value: offerInPercentage,
        hint: new Text("%"),
        isExpanded: true,
        underline: SizedBox(),
        onChanged: (String? data) {
          setState(() {
            offerInPercentage = data;
          });
        },
        items: Constants.PERCENTAGELIST.map((String model) {
          return new DropdownMenuItem<String>(
            child: new Text(model),
            value: model,
          );
        }).toList(),
      ),
    );
  }

  void serviceCallInvoice() async {
    List<Map<String, dynamic>> productArrayList = [];
    var productObject;

    for (int i = 0; i < selectedProductsList.length; i++) {
      if (selectedProductsList[i].isButton!) {
        if (selectedProductsList[i].quantity != 0) {
          productObject = {
            "product_name": selectedProductsList[i].name,
            "id": selectedProductsList[i].id!.isEmpty
                ? ""
                : selectedProductsList[i].id,
            "quantity": selectedProductsList[i].quantity,
            "unit_price": selectedProductsList[i].unitPrice,
            // "offer_selected": selectedProductsList[i].offerSelected,
            "batch_no": _batchNumberController[i]!.text,
            "conversion_type": productTypeList[i] == Constants.SALABLE_PRODUCTS
                ? "product"
                : productTypeList[i] == Constants.CONSUMABLE_GOODS
                    ? "consumable"
                    : "raw_material"
          };
          productArrayList.add(productObject);
        }
      }
    }

    List<String> splitValue = [];

    if (radioButtonValue == Constants.OFFER_IN_PERCENTAGE &&
        offerInPercentage != null) {
      splitValue = offerInPercentage!.split(" %");
    } else {
      splitValue
          .add(_rupeeController.text.isEmpty ? "0.0" : _rupeeController.text);
    }

    Map data = {
      "bill_no": int.parse(_invoiceController.text),
      "txnId": widget.transactionId,
      "products": productArrayList,
      "additional_discount_type": discountType,
      "additional_discount": double.parse(splitValue[0]),
      "seller_invoice": imageRelativePath,
      "package_details": {"status": "completed"},
      "order_track": {"delivery_status": "Completed"},
      "include_gst": isIncludeGST,
    };
    String body = json.encode(data);

    var response = await _transactionService
        .generateOfflineTransactionInvoice(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      final action = await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.SUCCESS, selectedLang),
          Language().getString(
              Constants.INVOICE_GENERATED_SUCCESSFULLY, selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
      if (action == DialogAction.yes) {
        Navigator.pop(context);
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  loadBatchNumbersList(String productId) async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
        progressMessage = Language()
            .getString(Constants.GETTING_BATCH_PRICING_DATA, selectedLang);
      });
      this.getProuctById(productId).then((onValue) {
        setState(() {
          _productList.clear();
          _productList.addAll(onValue);
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey, "No Internet Connection",
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<BuProductModal>> getProuctById(String productId) async {
    String body = json.encode({"id": productId, "buId": buId});

    var response = await _productService
        .getProductDetailsByProductId_grpc(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<BuProductModal> data = [];

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      data.add(BuProductModal.fromJson(resObj[0]));
      this.addingBatchPricing(data, productId);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }

    return data;
  }

  addingBatchPricing(List<BuProductModal> productData, String productId) {
    for (int i = 0; i < selectedProductsList.length; i++) {
      if (productData[0].id == selectedProductsList[i].id) {
        setState(() {
          batchPriceDropdown[i] = null;
          selectedProductsList[i].batchPriceList = productData[0].batchPrice;
          selectedProductsList[i].offerData = productData[0].offers!.length > 0
              ? productData[0].offers![0]
              : null;
        });
      }
    }
  }

  radioButtonsView(int index) {
    return Container(
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Row(
                  children: [
                    Container(
                      child: Radio(
                          materialTapTargetSize:
                              MaterialTapTargetSize.shrinkWrap,
                          activeColor: Color(Constants.APP_COLOR),
                          value: Constants.SALABLE_PRODUCTS,
                          groupValue: productTypeList[index],
                          onChanged: (dynamic value) {
                            setState(() {
                              productTypeList[index] = value;
                            });
                          }),
                    ),
                    Text(
                        Language().getString(
                            Constants.SALABLE_PRODUCTS, selectedLang),
                        style: TextStyle(
                            color: Color(Constants.APP_COLOR),
                            fontWeight: FontWeight.w100))
                  ],
                ),
              ),
              if (CommonMethods.isPrivillegeExist(
                  context,
                  PrivillegesActions
                      .KEY_CUSTOMERS_OFFLINE_TRANSACTION_PO_RECEIEVE_PRODUCTS_RAW_MATERIALS))
                Container(
                  child: Row(
                    children: [
                      Container(
                        child: Radio(
                            materialTapTargetSize:
                                MaterialTapTargetSize.shrinkWrap,
                            activeColor: Color(Constants.APP_COLOR),
                            value: Constants.RAW_MATERIALS,
                            groupValue: productTypeList[index],
                            onChanged: (dynamic value) {
                              setState(() {
                                productTypeList[index] = value;
                              });
                            }),
                      ),
                      Text(
                          Language()
                              .getString(Constants.RAW_MATERIALS, selectedLang),
                          style: TextStyle(
                              color: Color(Constants.APP_COLOR),
                              fontWeight: FontWeight.w100))
                    ],
                  ),
                ),
            ],
          ),
          Container(
            child: Row(
              children: [
                Container(
                  child: Radio(
                      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      activeColor: Color(Constants.APP_COLOR),
                      value: Constants.CONSUMABLE_GOODS,
                      groupValue: productTypeList[index],
                      onChanged: (dynamic value) {
                        setState(() {
                          productTypeList[index] = value;
                        });
                      }),
                ),
                Text(
                    Language()
                        .getString(Constants.CONSUMABLE_GOODS, selectedLang),
                    style: TextStyle(
                        color: Color(Constants.APP_COLOR),
                        fontWeight: FontWeight.w100))
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget customBatchNumberView(int index) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 10.0, vertical: 5.0),
      child: Row(
        children: [
          Container(
            child: Text(
              Language().getString(Constants.BATCH_NO, selectedLang),
              style: TextStyle(
                  color: Color(Constants.APP_COLOR),
                  fontSize: 14.0,
                  fontWeight: FontWeight.w600),
            ),
          ),
          Text("  : "),
          Container(
              height: 40.0,
              width: MediaQuery.of(context).size.width / 1.9,
              decoration: AppUtills.boxDecoration(),
              child: TextFormField(
                controller: _batchNumberController[index],
                textAlign: TextAlign.center,
                decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText:
                        Language().getString(Constants.BATCH_NO, selectedLang),
                    contentPadding: EdgeInsets.fromLTRB(0, 0, 0, 10)),
              )),
        ],
      ),
    );
  }
}
