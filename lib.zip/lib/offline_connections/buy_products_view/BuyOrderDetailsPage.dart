import 'package:share_plus/share_plus.dart';
import 'package:vyaparlive/offline_connections/buy_products_view/BuyOfflineProductsView.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:clipboard/clipboard.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutx/flutx.dart';
import 'package:intl/intl.dart';
// import 'package:share/share.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/Transaction/ListOfTransactions.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/DateFilterUtil.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/invoice_view/InvoiceDesingView.dart';
import 'package:vyaparlive/model/GRPCResponse.dart';
import 'package:vyaparlive/model/ModelProduct.dart';
import 'package:vyaparlive/model/product_model/BatchPriceDAO.dart';
import 'package:vyaparlive/model/product_model/ProductModel.dart';
import 'package:vyaparlive/model/TransactionsModel.dart';
import 'package:vyaparlive/page_transition/PageTransition.dart';
import 'package:vyaparlive/service/bu_list_grpc_service.dart';
import 'package:vyaparlive/service/product_services.dart';
import 'dart:convert';
import 'package:vyaparlive/utills/SharePref.dart';
import 'package:toast/toast.dart';

class BuyOrderDetailsPage extends StatefulWidget {
  final String? buId;
  final String? buName;
  BuyOrderDetailsPage({this.buId, this.buName});
  @override
  _BuyOrderDetailsPageState createState() => _BuyOrderDetailsPageState();
}

class _BuyOrderDetailsPageState extends State<BuyOrderDetailsPage> {
  List<TransactionsModel> _transactionsList = [];
  List<TransactionsModel> _resTransactionsList = [];
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  late BuListGrpcService _transactionService;
  bool isSearchParam = false;
  bool isLoadingProgress = true;
  String progressMessage = Constants.GETTING_DATA;
  String showLoaderText = Constants.NO_PREVIOUS_ORDERS;
  List<BuProductModal> responseProducts = [];
  List<ModelProduct> _productsList = [];
  List<ModelProduct> selectedProductsList = [];
  ModelProduct? _selectedProductData;
  List<TextEditingController> _enterProductCount = [];
  List<TextEditingController> _productNameController = [];
  String? buId = "";
  String? buName = "";
  String? offerInPercentage;
  String radioButtonValue = "";
  String discountType = "";
  String showProductText = "";
  bool _isShowNames = false;
  String forSaleProducts = "";
  String? userName = "";
  String? userId = "";
  late BuListGrpcService _buListGrpcService;
  String? productNameDropdown;
  List<String?> productsName = [];
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  late ProductService _productService;
  final TextEditingController productNameController = TextEditingController();
  final TextEditingController quantityController = TextEditingController();
  final TextEditingController priceController = TextEditingController();
  final TextEditingController totalPriceController = TextEditingController();
  late TextEditingController fromDateController = new TextEditingController();
  late TextEditingController toDateController = new TextEditingController();
  String? orgCurrencySymbol = "";
  bool isEnableDateFilter = true;
  String startDate = "";
  String endDate = "";
  String convertedDate = "";
  DateFormat formatter = DateFormat("yyyy-MM-dd");
  String todayDate = "";
  String params = "";
  final _searchController = TextEditingController();
  bool isForSearchParams = false;
  DateTime mnthStartDate =
      DateTime.utc(DateTime.now().year, DateTime.now().month, 1);
  bool isShowFloatButton = false;
  late ThemeData theme;

  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    _productService = ProductService();
    _buListGrpcService = BuListGrpcService();
    buId = AppController.instance.getMyBuId;
    buName = AppController.instance.getBuName;
    forSaleProducts = Constants.FOR_SALE_TRUE;
    startDate = formatter.format(mnthStartDate);
    endDate = formatter.format(DateTime.now());
    fromDateController.text = startDate;
    toDateController.text = endDate;
    _transactionService = BuListGrpcService();
    loadTransactionsData();
    SharePref().getUserId().then((value) {
      setState(() {
        userId = value;
      });
    });
    SharePref().getUserName().then((value) {
      setState(() {
        userName = value;
      });
    });

    // orgCurrencySymbol = AppController.instance.getBuCurrencySymbol;
    String? symbol = AppController.instance.getBuCurrencySymbol;
    orgCurrencySymbol = (symbol != null && symbol.isNotEmpty && symbol!="-") ? symbol : "\u20B9";
  }

  loadTransactionsData(
      {String name = "", String status = "", bool isOffline = false}) async {
    if (await NetworkStatus.getInternetStatus()) {
      if (!isForSearchParams) {
        setState(() {
          isLoadingProgress = true;
        });
      }

      _getAllTransactions(name: name, status: status, isOffline: isOffline)
          .then((onValue) {
        setState(() {
          _resTransactionsList.clear();
          _resTransactionsList.addAll(onValue);
          if (_resTransactionsList.length > 0) {
            _transactionsList.clear();
            for (int i = 0; i < _resTransactionsList.length; i++) {
              if (_resTransactionsList[i].seller!.id == widget.buId) {
                _transactionsList.add(_resTransactionsList[i]);
              } else {
                showLoaderText = Language()
                    .getString(Constants.NO_PREVIOUS_ORDERS, selectedLang);
              }
            }
          } else {
            showLoaderText = Language()
                .getString(Constants.NO_PREVIOUS_ORDERS, selectedLang);
          }
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<TransactionsModel>> _getAllTransactions(
      {String name = "", String status = "", bool isOffline = false}) async {
    setState(() {
      _transactionsList.clear();
    });

    String body = json.encode({
      "buId": widget.buId,
      "filters": {
        "DateFrom": fromDateController.text,
        "DateTo": toDateController.text,
        "status": status,
        "name": name
      }
    });

    var response = await _transactionService
        .getAllTransactionByBuId(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          Language().getString(onError, selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<TransactionsModel> _list = [];

    setState(() {
      isLoadingProgress = false;
    });
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      if (!CommonMethods.checkResponseType(resObj)) {
        var resultArray = resObj['results'];
        for (var i in resultArray) {
          _list.add(TransactionsModel.fromJson(i));
        }
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          Language().getString(_grpcResponse.message, selectedLang),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }

    return _list;
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
      body: Stack(
        children: [
          SafeArea(
            child: Scaffold(
                backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
                key: _scaffoldkey,
                appBar: AppBar(
                  backgroundColor: Colors.transparent, //(Constants.APP_COLOR),
                  centerTitle: true,
                  elevation: 0,
                  iconTheme: IconThemeData(color: theme.colorScheme.primary),
                  title: AppbarName(
                      title: Language()
                          .getString(Constants.BUY_ORDERS, selectedLang),
                      buName: '${widget.buName}'),
                  actions: [
                    IconButton(
                        icon: Icon(Icons.add),
                        onPressed: () {
                          // this.showProductsView();
                          Navigator.push(
                              context,
                              new MaterialPageRoute(
                                  builder: (context) => BuyOfflineProductsView(
                                        buId: widget.buId!,
                                        buName: widget.buName!,
                                      )));
                        })
                  ],
                ),
                floatingActionButton: (isShowFloatButton)
                    ? FloatingActionButton(
                        backgroundColor: Color(Constants.APP_COLOR),
                        onPressed: () {
                          setState(() {
                            isShowFloatButton = false;
                            isLoadingProgress = true;
                            _searchController.clear();
                          });
                          startDate = formatter.format(mnthStartDate);
                          endDate = formatter.format(DateTime.now());
            
                          loadTransactionsData();
                        },
                        child: Text(
                          Language()
                              .getString(Constants.CLEAR_FILTERS, selectedLang),
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.white, fontSize: 11.0),
                        ))
                    : null,
                body: Container(
                    padding: EdgeInsets.only(
                        left: 16,
                        right: 16,
                        top: 10.0,
                        bottom: (defaultTargetPlatform == TargetPlatform.iOS)
                            ? 30
                            : 20),
                    child: Column(
                      children: [
                        // this.buildSearchBarView(),
                        if (isEnableDateFilter)
                          Container(
                            padding: EdgeInsets.symmetric(vertical: 10),
                            child: DateFilterUtill(
                              isShowSearchButton: true,
                              fromDate: "",
                              toDate: "",
                              fromDateController: fromDateController,
                              toDateController: toDateController,
                              onFromDateSelected: (value) {
                                setState(() {
                                  fromDateController.text = value;
                                });
                              },
                              onToDateSelected: (value) {
                                setState(() {
                                  toDateController.text = value;
                                });
                              },
                              onSearchParms: () {
                                setState(() {
                                  isLoadingProgress = true;
                                  isShowFloatButton = true;
                                });
            
                                if (endDate == todayDate) {
                                  convertedDate =
                                      AppUtills.getOneDayAddedDate(endDate);
                                } else {
                                  convertedDate = endDate;
                                }
            
                                loadTransactionsData();
                              },
                            ),
                          ),
                        Expanded(
                          child: (_transactionsList.length > 0)
                              ? Container(
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(5.0),
                                      border: Border.all(
                                          color: Color(Constants.APP_COLOR))),
                                  child: Column(children: [
                                    Container(
                                      padding: EdgeInsets.all(16.0),
                                      child: Row(
                                        children: [
                                          this.rowHeaderText(
                                              Language().getString(
                                                  Constants.DATE, selectedLang),
                                              TextAlign.start),
                                          this.rowHeaderText(
                                              Language().getString(
                                                  Constants.PO, selectedLang),
                                              TextAlign.center),
                                          // this.rowHeaderText(
                                          //     Language().getString(
                                          //         Constants.STATUS_STRING,
                                          //         selectedLang),
                                          //     TextAlign.center),
                                          this.rowHeaderText(
                                              Language().getString(
                                                  Constants.INVOICE,
                                                  selectedLang),
                                              TextAlign.center),
                                        ],
                                      ),
                                    ),
                                    Divider(
                                      color: Color(Constants.APP_COLOR),
                                      height: 5.0,
                                    ),
                                    Expanded(
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                            left: 16, right: 16),
                                        child: ListView.builder(
                                          shrinkWrap: true,
                                          itemBuilder: (context, index) {
                                            return viewData(index, context);
                                          },
                                          itemCount: _transactionsList.length,
                                        ),
                                      ),
                                    )
                                  ]),
                                )
                              : Container(
                                  child: Center(
                                    child: Text(Language()
                                        .getString(showLoaderText, selectedLang)),
                                  ),
                                ),
                        )
                      ],
                    ))),
          ),
          AppUtills.showLoadingView(
              context: context,
              message: Language().getString(progressMessage, selectedLang),
              isLoading: isLoadingProgress),
        ],
      ),
    );
  }

  Widget viewData(int index, BuildContext mContext) {
    return Container(
      padding: EdgeInsets.only(top: 16.0, right: 16.0, bottom: 10.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          bindOrderData(
              AppUtills.getDateFormate(
                  _transactionsList[index].modifiedDate.toString()),
              TextAlign.start),
          InkWell(
            onTap: () => shareInvoice(context, index),
            child: Text(
              Language().getString(Constants.ORDER_DETAILS, selectedLang),
              textAlign: TextAlign.end,
              style: TextStyle(
                  decoration: TextDecoration.underline,
                  color: Color(Constants.APP_COLOR),
                  fontSize: 13.0),
            ),
          ),
          // this.bindOrderData(
          //   _transactionsList[index].invoiceDetails!.length > 0
          //       ? _transactionsList[index].invoiceDetails![0].status!
          //       : "",
          //   TextAlign.center,
          // ),
          Expanded(
            child: Container(
              child: (_transactionsList[index].invoiceDetails!.length > 0)
                  ? InkWell(
                      onTap: () {
                        // this.shareInvoice(mContext, index);
                        Navigator.push(
                          context,
                          PageTransition(
                            context: context,
                            page: InvoiceDesingPage(
                                invoiceNo: _transactionsList[index]
                                    .invoiceDetails![0]
                                    .billNo
                                    .toString(),
                                transactionName:
                                    _transactionsList[index].buyer!.name,
                                transactionId: _transactionsList[index].id,
                                transactionDate: _transactionsList[index]
                                    .invoiceDetails![0]
                                    .invoiceDate
                                    .toString(),
                                buyerName: _transactionsList[index].buyer!.name,
                                sellerName:
                                    _transactionsList[index].seller!.name,
                                invoiceId: _transactionsList[index]
                                    .invoiceDetails![0]
                                    .invoiceId),
                          ),
                        );
                      },
                      child: Text(
                          "${Language().getString(Constants.INVOICE, selectedLang)}\n#${_transactionsList[index].invoiceDetails![0].billNo}",
                          textAlign: TextAlign.end,
                          style: TextStyle(
                            decoration: TextDecoration.underline,
                            fontSize: 13.0,
                            color: Color(Constants.APP_COLOR),
                          )))
                  : Text(Language().getString(Constants.PENDING, selectedLang),
                      textAlign: TextAlign.end,
                      style: TextStyle(
                        fontSize: 13.0,
                        color: Color(Constants.APP_COLOR),
                      )),
            ),
          ),
        ],
      ),
    );
  }

  shareInvoice(BuildContext context, int index) {
    String url =
        "${Constants.WHATSAPP_INVOICE_URL}${_transactionsList[index].id}/shared-po";
    return showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        actions: [
          Container(
            width: MediaQuery.of(context).size.width,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: Text(
                    Language().getString(Constants.STR_CANCEL, selectedLang),
                    style: TextStyle(
                      fontSize: 15.0,
                      color: Color(
                        Constants.APP_COLOR,
                      ),
                    ),
                  ),
                ),
                TextButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                      Navigator.push(
                          context,
                          PageTransition(
                              context: context,
                              page: ListOfTransactionsPage(
                                transactionId: _transactionsList[index].id,
                              ))).then((value) => loadTransactionsData());
                    },
                    child:
                        Text(Language().getString(Constants.OPEN, selectedLang),
                            style: TextStyle(
                              fontSize: 15.0,
                              color: Color(
                                Constants.APP_COLOR,
                              ),
                            ))),
                TextButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                      String sellerName = '';
                      String buyerName = '';

                      if (_transactionsList[index].buyer!.id == buId) {
                        sellerName = _transactionsList[index].seller!.name!;
                        buyerName = _transactionsList[index].buyer!.name!;
                      } else {
                        sellerName = _transactionsList[index].buyer!.name!;
                        buyerName = _transactionsList[index].seller!.name!;
                      }
                      String message =
                          'Hello $sellerName,\n\n$buyerName has generated a new PO(Purchase Order), please click below url to view the invoice\n\n$url';
                      if (kIsWeb) {
                        this.openCopyAlertDialog(context, message);
                      } else {
                        SharePlus.instance.share(ShareParams(
                            text: message,
                            title: "${Constants.APANAVYAPAR} PO",
                            subject: "${Constants.APANAVYAPAR} PO",
                          ));
                        // Share.share(message, subject: "Vyapar Live PO");
                      }
                    },
                    child: Text(
                        Language().getString(Constants.SHARE, selectedLang),
                        style: TextStyle(
                          fontSize: 15.0,
                          color: Color(
                            Constants.APP_COLOR,
                          ),
                        ))),
              ],
            ),
          )
        ],
        content: Container(
          child: Text(
            Language().getString(Constants.SHARE_OFFLINE_PO, selectedLang),
          ),
        ),
      ),
    );
  }

  openCopyAlertDialog(BuildContext context, String url) {
    return showDialog(
        barrierDismissible: false,
        context: context,
        barrierColor: Colors.black54,
        builder: (BuildContext context) {
          return AlertDialog(
            elevation: 100.0,
            contentPadding: EdgeInsets.fromLTRB(15.0, 0, 15.0, 0),
            backgroundColor: Colors.white,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(7.0))),
            actions: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  InkWell(
                    onTap: () => {
                      Navigator.of(context).pop(),
                    },
                    child: Text(
                      Language().getString(Constants.STR_CANCEL, selectedLang),
                      style: TextStyle(
                          color: theme.colorScheme.primary,
                          fontSize: 15,
                          fontWeight: StyleView.fontMedium),
                    ),
                  ),
                  InkWell(
                    onTap: () => {
                      FlutterClipboard.copy("$url").then((value) => {
                            print('copied'),
                            Toast.show("copied to clipboard",
                                duration: Toast.lengthShort,
                                gravity: Toast.bottom)
                          }),
                      Navigator.of(context).pop(),
                    },
                    child: Text(
                      "Copy",
                      style: TextStyle(
                          color: theme.colorScheme.primary,
                          fontSize: 15,
                          fontWeight: StyleView.fontMedium),
                    ),
                  )
                ],
              )
            ],
            titlePadding: EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 10.0),
            title: Text(
              Language().getString(Constants.STR_COPY_TO_SHARE, selectedLang),
              style: TextStyle(
                  color: theme.colorScheme.primary,
                  fontSize: 15,
                  fontWeight: StyleView.fontRegular),
            ),
            content: Container(
                padding: EdgeInsets.only(top: 16, bottom: 16),
                child: Text("$url")),
          );
        });
  }

  Widget bindOrderData(String value, TextAlign align) {
    return Expanded(
      child: Container(
        child: Text(
          value,
          textAlign: align,
          style: TextStyle(color: Color(Constants.APP_COLOR), fontSize: 13.0),
        ),
      ),
    );
  }

  Widget rowHeaderText(String text, TextAlign textAlign) {
    return Expanded(
      child: Container(
        child: Text(
          text,
          textAlign: textAlign,
          style: TextStyle(
              color: Color(Constants.APP_COLOR),
              fontSize: 15.0,
              fontWeight: FontWeight.bold),
        ),
      ),
    );
  }

  showProductsView() {
    return showDialog(
        context: context,
        barrierColor: Colors.black54,
        barrierDismissible: false,
        builder: (context) =>
            StatefulBuilder(builder: (context, StateSetter setState) {
              return Container(
                margin: EdgeInsets.symmetric(vertical: 20.0, horizontal: 20.0),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: AppBackgroundView(
                      body: Scaffold(
                          bottomNavigationBar: bottomView(),
                          backgroundColor:
                              Color(Constants.APP_BACKGROUND_COLOR),
                          body: Container(
                              margin: EdgeInsets.only(
                                  top: 20.0, left: 16.0, right: 16.0),
                              child: Column(
                                children: [
                                  Text(
                                      Language().getString(
                                          Constants.PURCHANSE_ORDER,
                                          selectedLang),
                                      style: TextStyle(
                                          color: theme.colorScheme.primary,
                                          fontFamily: StyleView.FONT_TITLE,
                                          fontSize: 15,
                                          fontWeight: StyleView.fontSemiBold)),
                                  FxSpacing.height(16),
                                  showProductSearchView(setState),
                                  (_productsList.length > 0 && _isShowNames)
                                      ? showProductNames(setState)
                                      : Container(
                                          margin: EdgeInsets.symmetric(
                                              vertical: 5.0),
                                          child: (showProductText ==
                                                      Language().getString(
                                                          Constants
                                                              .NO_DATA_FOUND,
                                                          selectedLang) ||
                                                  showProductText == "")
                                              ? Text(showProductText)
                                              : Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    Text(showProductText),
                                                    Container(
                                                      height: 10.0,
                                                      width: 10.0,
                                                      margin:
                                                          EdgeInsets.symmetric(
                                                              horizontal: 5.0),
                                                      child:
                                                          CircularProgressIndicator(
                                                              strokeWidth: 2.0),
                                                    )
                                                  ],
                                                ),
                                        ),
                                  Container(
                                      child: Row(
                                    children: [
                                      Expanded(
                                          flex: (kIsWeb) ? 3 : 1,
                                          child: Container()),
                                      Expanded(
                                          flex: 2,
                                          child: Container(
                                            height: 40,
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                              color: theme.colorScheme.primary,
                                            ),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                TextButton(
                                                    onPressed: () {
                                                      setState(() {
                                                        selectedProductsList
                                                            .add(ModelProduct(
                                                                name: "",
                                                                id: "",
                                                                price: 0,
                                                                counter: 0,
                                                                images: "",
                                                                isButton: false,
                                                                isItemSelected:
                                                                    false,
                                                                batchPriceList: [],
                                                                unitPrice: 0,
                                                                isEditable:
                                                                    false,
                                                                isCustomProduct:
                                                                    true,
                                                                quantity: 0));

                                                        _enterProductCount.add(
                                                            new TextEditingController());
                                                        _productNameController.add(
                                                            new TextEditingController());
                                                      });
                                                    },
                                                    child: Text(
                                                      Language().getString(
                                                          Constants
                                                              .ADD_NEW_PRODUCT,
                                                          selectedLang),
                                                      style: TextStyle(
                                                          color: Colors.white,
                                                          fontWeight: StyleView
                                                              .fontMedium),
                                                    )),
                                                // SizedBox(width: 5),
                                                InkWell(
                                                    onTap: () async {
                                                      Dialogs.yesCancelDialog(
                                                          context,
                                                          Language().getString(
                                                              Constants.INFO,
                                                              selectedLang),
                                                          Language().getString(
                                                              Constants
                                                                  .DO_YOU_WANT_PRODUCT_WHICH_IS_NOT_PRODUCT_LIST,
                                                              selectedLang),
                                                          Language().getString(
                                                              Constants
                                                                  .YES_STRING,
                                                              selectedLang),
                                                          "",
                                                          false);
                                                    },
                                                    child: Icon(Icons.info,
                                                        size: 20.0,
                                                        color: Colors.white))
                                              ],
                                            ),
                                          ))
                                    ],
                                  )),
                                  (selectedProductsList.length > 0)
                                      ? Expanded(
                                          child: Container(
                                          margin: EdgeInsets.only(top: 10.0),
                                          decoration: AppUtills.boxDecoration(),
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                padding: EdgeInsets.all(10.0),
                                                child: Row(
                                                  children: [
                                                    Expanded(
                                                      child: Text(
                                                        Language().getString(
                                                            Constants
                                                                .PRODUCT_NAME,
                                                            selectedLang),
                                                        style: TextStyle(
                                                            color: Color(
                                                                Constants
                                                                    .APP_COLOR),
                                                            fontWeight:
                                                                FontWeight
                                                                    .bold),
                                                      ),
                                                    ),
                                                    Expanded(
                                                      child: Container(
                                                        margin: EdgeInsets.only(
                                                            left: 40.0),
                                                        child: Text(
                                                          Language().getString(
                                                              Constants
                                                                  .QUANTITY,
                                                              selectedLang),
                                                          style: TextStyle(
                                                              color: Color(
                                                                  Constants
                                                                      .APP_COLOR),
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Divider(
                                                  color: Color(
                                                      Constants.APP_COLOR)),
                                              Expanded(
                                                child: ListView.separated(
                                                    shrinkWrap: true,
                                                    separatorBuilder: (context,
                                                            index) =>
                                                        new Divider(
                                                            color: Colors
                                                                .transparent,
                                                            height: 0.0),
                                                    itemCount:
                                                        selectedProductsList
                                                            .length,
                                                    itemBuilder: (context,
                                                            index) =>
                                                        selectedProductsCardView(
                                                            index, setState)),
                                              )
                                            ],
                                          ),
                                        ))
                                      : Container(),
                                ],
                              )))),
                ),
              );
            }));
  }

  loadProductData(String parms, StateSetter setState) async {
    if (await NetworkStatus.getInternetStatus()) {
      getBuProducts(parms).then((onValue) {
        setState(() {
          responseProducts.clear();
          _productsList.clear();
          productsName.clear();
          responseProducts.addAll(onValue);
          if (responseProducts.length > 0) {
            for (int i = 0; i < responseProducts.length; i++) {
              if (responseProducts[i].batchPrice!.length > 0) {
                showProductText = "";
                _productsList.add(ModelProduct(
                    id: responseProducts[i].id,
                    name: responseProducts[i].name,
                    counter: 0,
                    isButton: false,
                    images: responseProducts[i].images,
                    price: 0,
                    quantity: responseProducts[i].batchPrice![0].quantity,
                    isItemSelected: false,
                    unitPrice: responseProducts[i].batchPrice![0].price,
                    offerList: responseProducts[i].offers));
                productsName.add(responseProducts[i].name);
                _isShowNames = true;
              } else {
                showProductText =
                    Language().getString(Constants.NO_DATA_FOUND, selectedLang);
              }
            }
          } else {
            showProductText =
                Language().getString(Constants.NO_DATA_FOUND, selectedLang);
          }
        });
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Widget bottomView() {
    if (selectedProductsList.length > 0) {
      return Container(
          padding: EdgeInsets.symmetric(
              horizontal: 10.0,
              vertical:
                  (defaultTargetPlatform == TargetPlatform.iOS) ? 30 : 20),
          child: CommonButtonsView(
            context: context,
            b1Text: Language().getString(Constants.STR_CANCEL, selectedLang),
            b2Text:
                Language().getString(Constants.PLACE_ORDER_STR, selectedLang),
            onb1Action: () {
              clearData();
              Navigator.of(context).pop();
            },
            onb2Action: () async {
              if (selectedProductsList.length == 0) {
                Dialogs.yesCancelDialog(
                    context,
                    Language().getString(Constants.ERROR, selectedLang),
                    Language()
                        .getString(Constants.SELECT_PRODUCTS, selectedLang),
                    Language().getString(Constants.OKAY_STR, selectedLang),
                    "",
                    false);
              } else {
                if (await NetworkStatus.getInternetStatus()) {
                  Navigator.of(context).pop();
                  this.postBodyForProductsBuy();
                } else {
                  AppUtills.showSnackBar(_scaffoldkey,
                      Language().getString(Constants.NO_INTERNET, selectedLang),
                      snackBarBgColor: Colors.black,
                      messageColor: Colors.white,
                      buttonColor: Colors.white);
                }
              }
            },
          ));
    } else {
      return Container(
          padding: EdgeInsets.symmetric(
              horizontal: 10.0,
              vertical:
                  (defaultTargetPlatform == TargetPlatform.iOS) ? 30 : 20),
          child: CommonButtonsView(
            context: context,
            b2Text: Language().getString(Constants.STR_CANCEL, selectedLang),
            b1Text: "",
            onb2Action: () {
              clearData();
              Navigator.of(context).pop();
            },
            onb1Action: () {},
          ));
    }
  }

  Widget listProducts(int index, StateSetter setState) {
    bool isOfferExists = false;
    for (int i = 0; i < _productsList[index].offerList!.length; i++) {
      if (_productsList[index].offerList![i].isOfferActive! &&
          _productsList[index].offerList![i].isOfferActive != null) {
        isOfferExists = true;
      }
    }
    return Container(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            children: <Widget>[
              Expanded(
                  flex: 2,
                  child: Card(
                    elevation: 2.5,
                    child: AppUtills.displayImage(_productsList[index].images,
                        context: context),
                  )),
              Expanded(
                flex: 4,
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 5),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Container(
                        margin: EdgeInsets.symmetric(vertical: 5.0),
                        child: new Text(
                          _productsList[index].name!,
                          style: TextStyle(
                            color: Color(Constants.APP_COLOR),
                            fontSize: 15.0,
                          ),
                        ),
                      ),
                      Container(
                          child: Text(
                        Language().getString(Constants.PRICE, selectedLang) +
                            ' : ${_productsList[index].price}',
                        style: TextStyle(
                            color: Color(
                              Constants.APP_COLOR,
                            ),
                            fontSize: 13.0),
                      )),
                    ],
                  ),
                ),
              ),
              Expanded(
                  flex: 3,
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: <Widget>[
                        Container(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: <Widget>[
                              Container(
                                  child: InkWell(
                                onTap: () {
                                  this.removeProductsQuantity(index, setState);
                                },
                                child: Icon(Icons.remove),
                              )),
                              Container(
                                width: 50.0,
                                height: 30.0,
                                alignment: Alignment.bottomCenter,
                                decoration: AppUtills.boxDecoration(),
                                child:
                                    designQuantityInputField(index, setState),
                              ),
                              Container(
                                  child: InkWell(
                                onTap: () {
                                  this.addProductsQuantity(index, setState);
                                },
                                child: Icon(Icons.add),
                              ))
                            ],
                          ),
                        ),
                        (isOfferExists)
                            ? this.showProductOffers(
                                index, isOfferExists, setState)
                            : Container()
                      ]))
            ],
          ),
        ),
      ),
    );
  }

  showProductOffers(int index, bool isOfferExists, StateSetter setState) {
    if (isOfferExists) {
      return Container(
        margin: EdgeInsets.symmetric(
          vertical: 7.0,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            InkWell(
                onTap: () {
                  for (int i = 0;
                      i < _productsList[index].offerList!.length;
                      i++) {
                    if (_productsList[index].offerList![i].isOfferActive!) {
                      Dialogs.showOffer(
                          context,
                          _productsList[index].offerList![i].offerQuantity,
                          _productsList[index].offerList![i].offerName,
                          _productsList[index].offerList![i].minOrder,
                          _productsList[index].offerList![i].maxOrder,
                          _productsList[index].offerList![i].offerType);
                    }
                  }
                },
                child: Container(
                  margin: EdgeInsets.symmetric(
                    horizontal: 5.0,
                  ),
                  child: Text(
                    Language().getString(Constants.OFFER, selectedLang),
                    style: TextStyle(
                        color: StyleView.offerColor,
                        decoration: TextDecoration.underline),
                  ),
                )),
            Container(
              child: SizedBox(
                height: 20.0,
                width: 20.0,
                child: Checkbox(
                    activeColor: StyleView.offerColor,
                    value: _productsList[index].isButton,
                    onChanged: (bool? value) {
                      setState(() {
                        _productsList[index].isButton = value;
                      });
                    }),
              ),
            )
          ],
        ),
      );
    } else {
      return Container();
    }
  }

  Widget designProductNameInputField(int index, StateSetter setState) {
    return Container(
      decoration: AppUtills.boxDecoration(),
      child: TextFormField(
        enableInteractiveSelection: false,
        textAlign: TextAlign.center,
        // enabled: selectedProductsList[index].isEditable,
        readOnly: selectedProductsList[index].isEditable,
        controller: _productNameController[index],
        decoration: InputDecoration(
          hintText:
              Language().getString(Constants.ENTER_PRODUCT_NAME, selectedLang),
          border: InputBorder.none,
        ),
        keyboardType: TextInputType.text,
        style: TextStyle(fontSize: 12.0),
        onChanged: (value) {
          selectedProductsList[index].name = value;
        },
      ),
    );
  }

  Widget designQuantityInputField(int index, StateSetter setState) {
    return Container(
      child: TextFormField(
        enableInteractiveSelection: false,
        textAlign: TextAlign.center,
        controller: _enterProductCount[index],
        decoration: InputDecoration(
            hintText: "",
            border: InputBorder.none,
            contentPadding: CommonMethods.textInputControllerPadding()),
        keyboardType: (defaultTargetPlatform == TargetPlatform.iOS)
            ? TextInputType.numberWithOptions(signed: true)
            : TextInputType.number,
        style: TextStyle(fontSize: 12.0),
        inputFormatters: [
          new LengthLimitingTextInputFormatter(5),
          FilteringTextInputFormatter.digitsOnly
        ],
        onFieldSubmitted: (value) {
          if (value == "0" || value.isEmpty) {
            selectedProductsList[index].counter = 1;

            calculateProductTotalPrice(
                index, setState, selectedProductsList[index].counter);
          }
        },
        onChanged: (value) {
          setState(() {
            if (selectedProductsList.length > 0) {
              if (value.isEmpty) {
                selectedProductsList[index].counter = 0;

                calculateProductTotalPrice(
                    index, setState, selectedProductsList[index].counter);
              } else {
                selectedProductsList[index].counter = int.parse(value);
                selectedProductsList[index].counter = int.parse(value);

                calculateProductTotalPrice(
                    index, setState, selectedProductsList[index].counter);
              }
            }
          });
        },
      ),
    );
  }

  removeSeletedProduct(int index, StateSetter setState) async {
    final action = await Dialogs.yesCancelDialog(
        context,
        Language().getString(Constants.WARNING, selectedLang),
        Language().getString(Constants.WARNING_TEXT, selectedLang),
        Language().getString(Constants.OKAY_STR, selectedLang),
        "",
        false);

    if (action == DialogAction.yes) {
      setState(() {
        selectedProductsList.removeAt(index);
        _enterProductCount[index].clear();
        selectedProductsList.removeAt(index);
      });
    }
  }

  removeProductsQuantity(int index, StateSetter setState) {
    int? countDecrement = selectedProductsList[index].counter;
    setState(() {
      if (countDecrement! > 1) {
        countDecrement = countDecrement! - 1;
        setState(() {
          selectedProductsList[index].counter = countDecrement;
          _enterProductCount[index] = TextEditingController(
              text: selectedProductsList[index].counter.toString());
          _enterProductCount[index].selection = TextSelection.fromPosition(
              TextPosition(offset: _enterProductCount[index].text.length));
          calculateProductTotalPrice(
              index, setState, selectedProductsList[index].counter);
        });
      }
    });
  }

  addProductsQuantity(int index, StateSetter setState) {
    int? countIncrement = selectedProductsList[index].counter;

    if (countIncrement == 1) {
      setState(() {
        countIncrement = countIncrement! + 1;
        selectedProductsList[index].counter = countIncrement;
        _enterProductCount[index] = TextEditingController(
            text: selectedProductsList[index].counter.toString());
        _enterProductCount[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _enterProductCount[index].text.length));
        calculateProductTotalPrice(
            index, setState, selectedProductsList[index].counter);
      });
    } else {
      setState(() {
        countIncrement = countIncrement! + 1;
        selectedProductsList[index].counter = countIncrement;

        _enterProductCount[index] =
            TextEditingController(text: countIncrement.toString());
        _enterProductCount[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _enterProductCount[index].text.length));
        calculateProductTotalPrice(
            index, setState, selectedProductsList[index].counter);
      });
    }
  }

  calculateProductTotalPrice(int index, StateSetter setState, int? quantity) {
    setState(() {
      selectedProductsList[index].price =
          selectedProductsList[index].unitPrice! * quantity!;
    });
  }

  Widget showProductNames(StateSetter setState) {
    return Container(
        height: 100.0,
        decoration: BoxDecoration(
          color: Colors.grey[400],
          borderRadius: BorderRadius.circular(5.0),
        ),
        child: ListView.builder(
          itemBuilder: (context, index) {
            return InkWell(
              onTap: () {
                CommonMethods.hideKeyboard(context);

                // setState(() {
                priceController.text =
                    _productsList[index].unitPrice.toString();
                quantityController.text = "1";
                _productsList[index].counter =
                    int.parse(quantityController.text);
                productNameController.text = _productsList[index].name!;
                totalPriceController.text =
                    (double.parse(priceController.text) *
                            double.parse(quantityController.text))
                        .toString();
                _isShowNames = false;
                _selectedProductData = _productsList[index];
                addToInvoiceProductsArray(setState);
                // });
              },
              child: Card(
                color: Colors.grey[100],
                elevation: 2.5,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(_productsList[index].name!,
                          style: TextStyle(color: Colors.black)),
                      Icon(Icons.arrow_forward, color: Colors.blue, size: 20.0),
                    ],
                  ),
                ),
              ),
            );
          },
          itemCount: _productsList.length,
          shrinkWrap: true,
        ));
  }

  postBodyForProductsBuy() async {
    setState(() {
      isLoadingProgress = true;
    });
    Map data = {
      "id": "",
      "is_offline": true,
      "order_type":"offline_direct_buy",
      "buyer": {
        "id": buId,
        "name": buName,
      },
      "seller": {
        "id": widget.buId,
        "name": widget.buName,
        "is_offline": true,
      },
      "sender":{
        "id": buId,
      },
      "ctr": {"type": "", "Agent": "", "transaction_ref": ""},
      "discussion": {
        "initiator": widget.buId,
        "initiator_user": widget.buName,
        "message_start_date": "",
        "confirmation_message": [],
        "confirmation_status": ""
      }
    };
    String body = json.encode(data);
    var response = await _buListGrpcService
        .beginTransaction(body, AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() => isLoadingProgress = false);
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    setState(() => isLoadingProgress = false);

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var data = json.decode(_grpcResponse.message!);
      prepareTransactionsProductsBody(data, true);
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  prepareTransactionsProductsBody(
      String? transactionId, bool isForBuyProudcts) async {
    setState(() {
      isLoadingProgress = true;
      progressMessage = "Sending products..";
    });

    List<Map<String, dynamic>> productsArray = [];
    var productsObject;
    for (int i = 0; i < selectedProductsList.length; i++) {
      if (selectedProductsList[i].name!.isNotEmpty &&
          selectedProductsList[i].counter != 0) {
        productsObject = {
          // "id": selectedProductsList[i].id,
          "unit_price": selectedProductsList[i].unitPrice,
          "quantity": selectedProductsList[i].counter,
          "total": selectedProductsList[i].price,
          "offer_selected": selectedProductsList[i].isButton
        };
        if (selectedProductsList[i].isCustomProduct) {
          productsObject['product_name'] = selectedProductsList[i].name;
        } else {
          productsObject['id'] = selectedProductsList[i].id;
        }
        productsArray.add(productsObject);
      }
    }

    Map data = {
      "id": transactionId,
      "order_details": {
        "user_id": userId,
        "user_name": userName,
        "products": productsArray
      }
    };
    String body = json.encode(data);

    var response = await _buListGrpcService
        .createPlaceOrder(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      setState(() {
        isLoadingProgress = false;
        progressMessage = "";
      });
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    setState(() {
      isLoadingProgress = false;
      progressMessage = "";
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      String url =
          Constants.NEW_BASE_URL + "transaction/$transactionId/shared-po";
      return showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
          actions: [
            Container(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  TextButton(
                      onPressed: () {
                        clearData();
                        if (kIsWeb) {
                          this.openCopyAlertDialog(context, url);
                        } else {
                          SharePlus.instance.share(ShareParams(
                            text: "Your generated PO is : $url",
                            title: "${Constants.APANAVYAPAR} PO",
                            subject: "${Constants.APANAVYAPAR} PO",
                          ));
                          // Share.share("Your generated PO is : $url",
                          //     subject: "${Constants.APANAVYAPAR} PO");
                        }
                      },
                      child: Text(
                          Language().getString(Constants.SHARE, selectedLang),
                          style: TextStyle(
                            fontSize: 18.0,
                            color: Color(
                              Constants.APP_COLOR,
                            ),
                          ))),
                  TextButton(
                      onPressed: () {
                        clearData();
                        Navigator.of(context).pop();
                        Navigator.push(
                            context,
                            new MaterialPageRoute(
                              builder: (context) => ListOfTransactionsPage(
                                transactionId: transactionId,
                              ),
                            )).then((value) => loadTransactionsData());
                      },
                      child: Text(
                          Language()
                              .getString(Constants.OKAY_STR, selectedLang),
                          style: TextStyle(
                            fontSize: 18.0,
                            color: Color(
                              Constants.APP_COLOR,
                            ),
                          ))),
                ],
              ),
            )
          ],
          content: Container(
            child: Text(
              Language().getString(
                  Constants.ORDER_PLACED_SUCCSESSFULLY_ALERT_STRING,
                  selectedLang),
            ),
          ),
        ),
      );
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  }

  clearData() {
    setState(() {
      _productsList.clear();
      selectedProductsList.clear();
      productNameDropdown = null;
      _enterProductCount.clear();
      _selectedProductData = null;
      showProductText = "";
      productNameController.clear();
      quantityController.clear();
      priceController.clear();
      totalPriceController.clear();
    });
  }

  Future<List<BuProductModal>> getBuProducts(parmsurl) async {
    String body = json.encode({
      "id": buId,
      "filter": {
        "name": parmsurl,
        "for_sale": true,
      }
    });

    var response = await _productService
        .getProductByBuId_v2(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) async {
      await Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<BuProductModal> _products = [];
    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      var data = resObj['results'];
      for (var i in data) {
        _products.add(BuProductModal.fromJson(i));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }

    return _products;
  }

  Widget showProductSearchView(StateSetter setState) {
    return Container(
      decoration: BoxDecoration(
          border: Border.all(color: Colors.black54),
          borderRadius: BorderRadius.circular(10),
          color: Colors.white),
      margin: EdgeInsets.only(top: 5.0),
      padding: EdgeInsets.only(left: 5, right: 5),
      height: 45.0,
      alignment: Alignment.centerLeft,
      child: Container(
        decoration: BoxDecoration(
            // border: Border.all(color: Colors.black54),
            borderRadius: BorderRadius.circular(10),
            color: Colors.white),
        alignment: Alignment.centerLeft,
        child: Row(
          children: [
            Expanded(
              flex: 2,
              child: Container(
                margin: EdgeInsets.only(right: 1.0),
                child: TextField(
                  controller: productNameController,
                  keyboardType: TextInputType.text,
                  // focusNode: FocusNode(),
                  decoration: InputDecoration(
                    hintText: Language().getString(
                        Constants.SEARCH_AND_ADD_PRODUCT_ORDER, selectedLang),
                    hintStyle: TextStyle(fontSize: 12.0),
                    border: InputBorder.none,
                    // contentPadding: EdgeInsets.all(2.0),
                  ),
                  maxLines: 3,
                  onChanged: (_text) {
                    if (_text.isNotEmpty) {
                      setState(() {
                        showProductText = Language()
                            .getString(Constants.LOADING, selectedLang);
                      });
                      loadProductData(_text, setState);
                    } else {
                      setState(() {
                        showProductText = "";
                        _isShowNames = false;
                        _productsList.clear();
                      });
                    }
                  },
                  style: TextStyle(
                      fontSize: 12.0, decoration: TextDecoration.none),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  addToInvoiceProductsArray(StateSetter setState) {
    setState(() {
      bool isExist = false;
      int index = -1;
      for (int i = 0; i < selectedProductsList.length; i++) {
        if (_selectedProductData!.id == selectedProductsList[i].id) {
          isExist = true;
          index = i;
        }
      }

      if (isExist) {
        selectedProductsList[index].counter =
            selectedProductsList[index].counter! +
                int.parse(quantityController.text);
        calculateProductTotalPrice(
            index, setState, selectedProductsList[index].counter);
        _enterProductCount[index] = TextEditingController(
            text: selectedProductsList[index].counter.toString());
        _enterProductCount[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _enterProductCount[index].text.length));
        _productNameController[index] =
            TextEditingController(text: selectedProductsList[index].name);
        _productNameController[index].selection = TextSelection.fromPosition(
            TextPosition(offset: _productNameController[index].text.length));
      } else {
        selectedProductsList.add(ModelProduct(
            name: _selectedProductData!.name,
            id: _selectedProductData!.id,
            price: double.parse(totalPriceController.text),
            counter: int.parse(quantityController.text),
            images: _selectedProductData!.images,
            isButton: _selectedProductData!.isButton,
            isItemSelected: _selectedProductData!.isItemSelected,
            batchPriceList: _selectedProductData!.batchPriceList,
            unitPrice: _selectedProductData!.unitPrice,
            isEditable: true,
            quantity: _selectedProductData!.quantity));
        _enterProductCount.add(new TextEditingController());
        _productNameController.add(new TextEditingController());
      }

      _selectedProductData = null;
      productNameController.clear();
      quantityController.clear();
      priceController.clear();
      totalPriceController.clear();
    });
  }

  buildSearchBarView() {
    return Container(
      height: 40.0,
      margin: EdgeInsets.symmetric(vertical: 5.0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(5.0),
        border: Border.all(
          color: Colors.grey,
        ),
      ),
      child: Row(
        children: <Widget>[
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.white,
              ),
              padding: EdgeInsets.only(left: 5),
              child: TextFormField(
                controller: _searchController,
                onChanged: onSearchTextChanged,
                style: TextStyle(fontFamily: 'IndianRupee'),
                decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: Language()
                        .getString(Constants.SEARCH_BY_BUSINESS, selectedLang),
                    hintStyle: TextStyle(
                        fontSize: 13.0, fontFamily: StyleView.FONT_TITLE)),
              ),
            ),
          ),
          (_searchController.text.length > 0)
              ? Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Colors.white,
                  ),
                  // color: Colors.white,
                  child: IconButton(
                      icon: Icon(
                        Icons.close,
                        color: Colors.red,
                        size: 20.0,
                      ),
                      onPressed: () {
                        CommonMethods.hideKeyboard(context);
                        _searchController.clear();
                        onSearchTextChanged(_searchController.text);
                      }),
                )
              : Container(),
          // Container(
          //   decoration: BoxDecoration(
          //     borderRadius: BorderRadius.only(
          //       topRight: Radius.circular(5.0),
          //       bottomRight: Radius.circular(5.0),
          //     ),
          //     color: Colors.white,
          //   ),
          //   child: IconButton(
          //       icon: Icon(Icons.date_range),
          //       onPressed: () {
          //         CommonMethods.hideKeyboard(context);
          //         setState(() {
          //           if (isEnableDateFilter) {
          //             isEnableDateFilter = false;
          //           } else {
          //             isEnableDateFilter = true;
          //           }
          //         });
          //       }),
          // ),
        ],
      ),
    );
  }

  onSearchTextChanged(String text) async {
    showLoaderText = Language().getString(Constants.LOADING, selectedLang);
    if (text.isEmpty) {
      isForSearchParams = false;
      loadTransactionsData();
    } else {
      isForSearchParams = true;

      loadTransactionsData(name: text);
    }
  }

  List<BatchPriceDAO> getAvailableBatches(ModelProduct productData) {
    List<BatchPriceDAO> _batchNumber = [];
    for (var i = 0; i < productData.batchPriceList!.length; i++) {
      if (productData.batchPriceList![i].quantity != 0 &&
          productData.batchPriceList![i].price != 0) {
        _batchNumber.add(productData.batchPriceList![i]);
      }
    }
    return _batchNumber;
  }

  removeProductsFromSelectedProducts(int index, StateSetter setState) async {
    final action = await Dialogs.yesCancelDialog(
        context,
        Language().getString(Constants.WARNING, selectedLang),
        Language().getString(Constants.WARNING_TEXT, selectedLang),
        Language().getString(Constants.OKAY_STR, selectedLang),
        "",
        false);

    if (action == DialogAction.yes) {
      setState(() {
        selectedProductsList.removeAt(index);
      });
    }
  }

  updateTextEditingControllers(int index) {
    _enterProductCount[index] = TextEditingController(
        text: selectedProductsList[index].counter.toString());
    _enterProductCount[index].selection = TextSelection.fromPosition(
        TextPosition(offset: _enterProductCount[index].text.length));
    _productNameController[index] =
        TextEditingController(text: selectedProductsList[index].name);
    _productNameController[index].selection = TextSelection.fromPosition(
        TextPosition(offset: _productNameController[index].text.length));
  }

  Widget selectedProductsCardView(int index, StateSetter setState) {
    updateTextEditingControllers(index);
    return Container(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Row(
          children: <Widget>[
            Expanded(
                flex: 2, child: designProductNameInputField(index, setState)),
            Expanded(
              flex: 2,
              child: Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Container(
                        child: InkWell(
                      onTap: () {
                        removeProductsQuantity(index, setState);
                      },
                      child: Icon(Icons.remove),
                    )),
                    Container(
                      width: 50.0,
                      height: 30.0,
                      decoration: AppUtills.boxDecoration(),
                      child: designQuantityInputField(index, setState),
                    ),
                    Container(
                        child: InkWell(
                      onTap: () {
                        addProductsQuantity(index, setState);
                      },
                      child: Icon(Icons.add),
                    ))
                  ],
                ),
              ),
            ),
            InkWell(
              onTap: () {
                removeProductsFromSelectedProducts(index, setState);
              },
              child: Icon(Icons.delete, color: Colors.red),
            )
          ],
        ),
      ),
    );

    // RetailSearchProductsPage(
    //   isFromRawProductIssuePage: true,
    //   onRemoveProductQuantit: () {
    //     removeProductsQuantity(index, setState);
    //   },
    //   onAddProductQuantity: () {
    //     addProductsQuantity(index, setState);
    //   },
    //   desingQuntityField: Container(
    //     width: 50.0,
    //     height: 30.0,
    //     decoration: AppUtills.boxDecoration(),
    //     child: designQuantityInputField(index, setState),
    //   ),
    //   productName: selectedProductsList[index].name,
    //   removeProduct: () async {
    //     removeProductsFromSelectedProducts(index, setState);
    //   },
    //   productTotalPrice: selectedProductsList[index].price,
    // );
  }
}
