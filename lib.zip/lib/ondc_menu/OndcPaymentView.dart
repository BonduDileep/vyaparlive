import 'dart:convert';
import 'dart:io';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:toast/toast.dart';
import '../components/AppController.dart';
import '../components/AppUtills.dart';
import '../components/CommonNavigation.dart';
import '../components/Constants.dart';
import '../components/Dialog.dart';
import '../components/NetworkStatus.dart';
import '../components/TransactionDetailsView.dart';
import '../components/common_methods.dart';
import '../config/Language.dart';
import '../model/GRPCResponse.dart';
import '../model/TransactionsModel.dart';
import '../model/UserModel.dart';
import '../model/transaction/InvoiceDataDAO.dart';
import '../model/transaction/InvoiceDetailsModel.dart';
import '../model/transaction/ReceivedPaymnetDAO.dart';
import '../model/transaction/TrackingDetailsDAO.dart';
import '../service/bu_list_grpc_service.dart';
import '../theme/app_theme.dart';
import '../utills/AppBackgroundView.dart';
import '../utills/AppBarName.dart';
import '../utills/SharePref.dart';

class OndcPaymentView extends StatefulWidget {
  final String transactionName;
  final String transactionId;
  final String reconciliationName;
  const OndcPaymentView(
      {super.key,
      required this.transactionId,
      required this.transactionName,
      required this.reconciliationName});

  @override
  State<OndcPaymentView> createState() => _OndcPaymentViewState();
}

class _OndcPaymentViewState extends State<OndcPaymentView> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? buName = "";
  DateFormat formatter = DateFormat("yyyy-MM-d");
  String? buId = "";
  static DateTime selectedDate = DateTime.now();
  String todayDate = DateFormat('yyyy-MM-d').format(selectedDate);
  String deliveryDate = Constants.SELECT_DATE;
  List<String> deliveryDateList = [];
  List<TransactionsModel> _transactionsList = [];
  List<InvoiceDetails> _invoiceList = [];
  bool isTransactionBuyer = false;
  UserModel? userDropdownvalue;
  List<UserModel> _usersList = [];
  TimeOfDay selectedTime = TimeOfDay.now();
  String actualDeliveryTime = Constants.SELECT_TIME;
  bool isLoadingProgress = false;
  String progressMessage = Constants.GETTING_DATA;
  String? receivedBy = "";
  late BuListGrpcService _transactionService;
  TextEditingController _payAmount = TextEditingController();
  String datePicker = "";
  String showSelectedDate = Constants.SELECT_DATE;
  List<ReceivedPaymentDAO> receivedList = [];
  bool isShowSmallCircularIndicator = false;
  num totalPendingAmount = 0;
  bool isTransactionRequestSuccess = false;
  File? pickedFile;
  bool isReady = false;
  int pages = 0;
  List<InvoiceDataDAO> invoiceDetailsList = [];
  bool isFileSelected = false;
  String? actualProductsRadioButionVaue;
  String? rawMaterialRadioButtonValue;
  String? orgCurrencySymbol = "";
  List<InvoiceDetails?> appendInvoiceData = [];
  String selectedLang = AppController.instance.getSelectedlanguage;
  SharedPreferences? sharedPreferences;
  List<Map> _namesData = [];
  List<String?> productsConversionTypeList = [];
  String? userId = "";
  String? userName = "";
  List<TrackingDetailsDAO?> _trackingDropdownValueUpdate = [];
  final String imageName = "stock_received_web.png";
  String? relativePath = "";
  late ThemeData theme;
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    this.getLoadLanguage();
    SharePref().getUserName().then((value) {
      userName = value;
    });
    SharePref().getUserId().then((value) {
      userId = value;
    });
    _transactionService = BuListGrpcService();
    buId = AppController.instance.getMyBuId;
    buName = AppController.instance.getBuName;
    this.loadTransactionData();
    // orgCurrencySymbol = AppController.instance.getBuCurrencySymbol;
    String? symbol = AppController.instance.getBuCurrencySymbol;
    orgCurrencySymbol = (symbol != null && symbol.isNotEmpty && symbol!="-") ? symbol : "\u20B9";
  }

  getLoadLanguage() async {
    _namesData = [
      {"name": Language().getString(Constants.NAME_STRING, selectedLang)},
      {"name": Language().getString(Constants.TXN_ID, selectedLang)},
      {"name": Language().getString(Constants.TXN_INITIATED_DATE, selectedLang)}
    ];
  }

  loadTransactionData({bool updatePendingAmount = false}) async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() {
        isLoadingProgress = true;
      });
      // updateUserDropdownValue.clear();
      invoiceDetailsList.clear();
      // trackingDropdownValue = null;
      _trackingDropdownValueUpdate.clear();
      _transactionsList.clear();
      getAllDiscussionData().then((value) {
        _transactionsList.addAll(value);
        this.bindingGeneratedInvoiceList();
      });
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  Future<List<TransactionsModel>> getAllDiscussionData(
      {bool updatePendingAmount = false}) async {
    _transactionsList.clear();
    _invoiceList.clear();
    _usersList.clear();
    receivedList.clear();
    String body = json.encode({"id": widget.transactionId});
    var response = await _transactionService
        .getTransactionDataById(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<TransactionsModel> _discussionsData = [];
    setState(() {
      isLoadingProgress = false;
      isShowSmallCircularIndicator = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      _discussionsData.add(TransactionsModel.fromJson(resObj[0]));
      if (updatePendingAmount) {
        receivedList.add(ReceivedPaymentDAO(
            receivedDate: showSelectedDate,
            receivedAmount: double.parse(_payAmount.text.trim())));
        isTransactionRequestSuccess = false;
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return _discussionsData;
  }

  @override
  void setState(VoidCallback fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  Widget build(BuildContext context) {
    ToastContext().init(context);
    return AppBackgroundView(
        body: Stack(
      children: [
        SafeArea(
          child: Scaffold(
              key: _scaffoldkey,
              backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
              appBar: AppBar(
                  centerTitle: true,
                  elevation: 0,
                  iconTheme: IconThemeData(color: theme.colorScheme.primary),
                  title: AppbarName(
                      title: Language()
                          .getString(widget.reconciliationName, selectedLang),
                      buName: "$buName"),
                  actions: [
                    AppUtills.homeButton(context),
                  ],
                  backgroundColor: Colors.transparent),
              body: Container(
                decoration: AppUtills.appBackgroundWithImage(),
                padding: EdgeInsets.all(10.0),
                child: Column(children: <Widget>[
                  TransactionDetailsViewPage(
                      transactionName: widget.transactionName,
                      transactionId: widget.transactionId,
                      transactionDate: _transactionsList.length > 0
                          ? _transactionsList[0].transactionDate.toString()
                          : null,
                      namesData: _namesData),
                  (_invoiceList.length > 0)
                      ? Expanded(
                          child: Container(
                              padding: EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(5.0),
                                  color: Colors.white,
                                  boxShadow: [
                                    BoxShadow(
                                        offset: Offset(0.0, 5.0),
                                        blurRadius: 5.0,
                                        color: Colors.grey)
                                  ]),
                              child: designForPaymentReconciliation()),
                        )
                      : AppUtills.showTransactionStageMessage()
                ]),
              )),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    ));
  }

  Widget designForPaymentReconciliation() {
    bool isAllInvoicesCancelled = false;
    for (int i = 0; i < _invoiceList.length; i++) {
      isAllInvoicesCancelled = false;
      if (_invoiceList[i].status == Constants.CANCELLED) {
        isAllInvoicesCancelled = true;
      }
    }

    if (isAllInvoicesCancelled) {
      return AppUtills.showTransactionStageMessage();
    } else {
      return Container(
        child: SingleChildScrollView(
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                for (int i = 0; i < _invoiceList.length; i++)
                  if (_invoiceList[i].status != "cancelled")
                    buildInvoicePaymentExpansionTile(_invoiceList[i], i)
              ]),
        ),
      );
    }
  }

  Widget buildInvoicePaymentExpansionTile(
      InvoiceDetails invoiceDetails, int index) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 2.0),
      decoration: AppUtills.boxDecoration(customBorderColor: Colors.black),
      child: ExpansionTile(
          title: Container(
            alignment: Alignment.centerLeft,
            child: InkWell(
              onTap: () {
                CommonNavigation.navigationToInvoiceDesign(
                    context,
                    widget.transactionName,
                    widget.transactionId,
                    _transactionsList.length > 0
                        ? _transactionsList[0].transactionDate.toString()
                        : null,
                    invoiceDetails.billNo.toString(),
                    invoiceDetails.invoiceId);
              },
              child: Text(
                Language().getString(Constants.INVOICE, selectedLang) +
                    " #${invoiceDetails.billNo}",
                style: TextStyle(
                    color: Colors.black,
                    fontWeight: StyleView.fontSemiBold,
                    decoration: TextDecoration.underline),
              ),
            ),
          ),
          subtitle: Text(
            Language().getString(Constants.RESOLUTION, selectedLang) +
                " : ${invoiceDetails.paymentReconciliation != null ? invoiceDetails.paymentReconciliation!.status : ""}",
            style: TextStyle(
                fontSize: 13.0,
                color: Colors.black,
                fontWeight: StyleView.fontRegular),
          ),
          onExpansionChanged: (value) {
            if (value) {
              getInvoiceDetailsByInvoiceId(invoiceDetails.invoiceId)
                  .then((value) {
                setState(() {
                  invoiceDetailsList.clear();
                  invoiceDetailsList.addAll(value);
                  if (invoiceDetailsList.length > 0) {
                    appendInvoiceData[index] =
                        invoiceDetailsList[0].invoiceDetails;
                  }
                });
              });
            }
          },
          children: paymentInvoiceDetailsView(
              appendInvoiceData.length > index
                  ? appendInvoiceData[index]
                  : null,
              index,
              invoiceDetails.invoiceId)),
    );
  }

  List<Widget> paymentInvoiceDetailsView(
      InvoiceDetails? invoiceDetails, int index, String? invoiceId) {
    if (invoiceDetails != null) {
      String paymentDueDate = "";
      if (invoiceDetails.paymentDueDate != null) {
        paymentDueDate = formatter.format(invoiceDetails.paymentDueDate!);
      }
      bool isTransactionOffline = false;
      if (_transactionsList[0].isOffline!) {
        isTransactionOffline = true;
      }

      return <Widget>[
        Divider(color: Colors.black),
        showInvoiceAmountView(paymentDueDate,
            invoiceDetails.finalTotal != null ? invoiceDetails.finalTotal : 0),
        showResolutionStatusView(
            isTransactionOffline, invoiceDetails, invoiceId),
        showPendingAmountView(invoiceDetails.pendingAmount != null
            ? invoiceDetails.pendingAmount
            : 0),
        Container(
          margin: EdgeInsets.symmetric(vertical: 8.0, horizontal: 5.0),
          alignment: Alignment.centerLeft,
          child: Text(
            Language().getString(Constants.PAYMENT_RECEIVED, selectedLang),
            style: TextStyle(
                color: Colors.black, fontWeight: StyleView.fontSemiBold),
          ),
        ),
        (_transactionsList[0].seller!.id == buId &&
                invoiceDetailsList.length > 0)
            ? this.designPaymentReceiveFunctionality(
                invoiceDetails.billNo, invoiceId)
            : Container(),
        this.showReceivedPaymentData(
            appendInvoiceData.length > index
                ? appendInvoiceData[index]!.receivedPayments
                : [],
            index)
      ];
    } else {
      return <Widget>[
        Container(
            child: Text(
                Language().getString(Constants.NO_DATA_FOUND, selectedLang)))
      ];
    }
  }

  Widget designPaymentReceiveFunctionality(dynamic billNo, String? invoiceId) {
    return Container(
      padding: EdgeInsets.all(8),
      height: 40.0,
      margin: EdgeInsets.symmetric(horizontal: 10),
      decoration: AppUtills.boxDecoration(customBorderColor: Colors.black),
      child: Row(
        children: [
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(5.0),
                      bottomLeft: Radius.circular(5.0))),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("$showSelectedDate"),
                  Container(
                    child: InkWell(
                        onTap: () async {
                          datePicker = await AppUtills.getSelectedDate(context,
                              isShowTodayDate: true);
                          setState(() => showSelectedDate = datePicker);
                        },
                        child: Icon(Icons.date_range, color: Colors.black)),
                  ),
                ],
              ),
            ),
          ),
          new SizedBox(width: 8),
          Expanded(
              child: Container(
            child: TextField(
              controller: _payAmount,
              keyboardType: TextInputType.numberWithOptions(signed: true),
              enableInteractiveSelection: false,
              cursorWidth: 1.0,
              inputFormatters: [
                CommonMethods.inputTextFormatter(isNumber: true)
              ],
              decoration: InputDecoration(
                  contentPadding: EdgeInsets.only(bottom: 10),
                  border: InputBorder.none,
                  hintText:
                      Language().getString(Constants.AMOUNT, selectedLang)),
            ),
          )),
          Container(
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                    topRight: Radius.circular(5.0),
                    bottomRight: Radius.circular(5.0))),
            height: 40.0,
            margin: EdgeInsets.only(left: 2.0),
            child: InkWell(
              onTap: () async {
                Dialogs.yesCancelDialog(
                    context,
                    Language().getString(Constants.ERROR, selectedLang),
                    Language()
                        .getString(Constants.PAYMENT_FAILED, selectedLang),
                    Language().getString(Constants.OKAY_STR, selectedLang),
                    "",
                    false);
              },
              child: Icon(Icons.add),
            ),
          )
        ],
      ),
    );
  }

  Widget buildRowPaymentText(
      String title, String value, int firseFlex, int secondFlex) {
    return Container(
      child: Row(
        children: [
          Expanded(
              flex: firseFlex,
              child: Text(
                Language().getString(title, selectedLang),
                style: TextStyle(
                    color: Colors.black, fontWeight: StyleView.fontSemiBold),
              )),
          Expanded(
              flex: secondFlex,
              child: Text(
                ":  $value",
                style: TextStyle(
                    fontSize: 13.0,
                    color: Colors.black,
                    fontWeight: StyleView.fontMedium),
              )),
        ],
      ),
    );
  }

  Future<List<InvoiceDataDAO>> getInvoiceDetailsByInvoiceId(
      String? invoiceId) async {
    setState(() {
      isLoadingProgress = true;
    });
    String body = json.encode({"id": invoiceId});

    var response = await _transactionService
        .getInvoiceDetailsByInvoiceId(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((onError) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          onError.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    setState(() {
      isLoadingProgress = false;
    });
    List<InvoiceDataDAO> list = [];
    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var resObj = json.decode(_grpcResponse.message!);
      bool isString = false;
      if (resObj is String) {
        isString = true;
      }
      if (!isString) {
        list.add(InvoiceDataDAO.fromJson(resObj[0]));
      }
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return list;
  }

  bindingGeneratedInvoiceList() {
    setState(() {
      /// Checking Your bu id seller or buyer for handing views
      for (int j = 0; j < _transactionsList.length; j++) {
        if (_transactionsList[j].buyer!.id == buId) {
          isTransactionBuyer = true;
        }
      }
      if (_transactionsList[0].ctrDetails != null &&
          _transactionsList[0].ctrDetails!.type == Constants.CTR1) {
        for (int i = 0; i < _transactionsList[0].invoiceDetails!.length; i++) {
          if (_transactionsList[0].invoiceDetails![i].ctrTransactionDetails !=
              null) {
            _invoiceList.add(_transactionsList[0].invoiceDetails!.last);
            appendInvoiceData.add(InvoiceDetails());
            _trackingDropdownValueUpdate.add(null);
          }
        }
      } else {
        for (int i = 0; i < _transactionsList[0].invoiceDetails!.length; i++) {
          // if (_transactionsList[0].invoiceDetails[i].assignPackingDetails !=
          //     null) {
          //   _invoiceList.add(_transactionsList[0].invoiceDetails[i]);
          //   appendInvoiceData.add(InvoiceDetails());
          // } else

          if (_transactionsList[0].invoiceDetails![i].invoiceType ==
                  Constants.CTR3 &&
              _transactionsList[0].invoiceDetails![i].ctrTransactionDetails !=
                  null) {
            if (_transactionsList[0].invoiceDetails![i].packageDetails !=
                null) {
              _invoiceList.add(_transactionsList[0].invoiceDetails![i]);
              appendInvoiceData.add(InvoiceDetails());
              _trackingDropdownValueUpdate.add(null);
            }
          } else {
            if (_transactionsList[0].invoiceDetails![i].orderTrackDetails !=
                    null &&
                (_transactionsList[0].invoiceDetails![i].packageDetails !=
                        null ||
                    _transactionsList[0]
                            .invoiceDetails![i]
                            .assignPackingDetails !=
                        null)) {
              //
              _invoiceList.add(_transactionsList[0].invoiceDetails![i]);
              appendInvoiceData.add(InvoiceDetails());
              _trackingDropdownValueUpdate.add(null);
            }
          }
        }
      }
    });
  }

  showReceivedPaymentData(List<ReceivedPaymentDAO>? paymentData, int index) {
    if (paymentData != null && paymentData.length > 0) {
      return ListView.separated(
        shrinkWrap: true,
        reverse: true,
        physics: NeverScrollableScrollPhysics(),
        itemBuilder: (context, index) {
          return Container(
            margin: EdgeInsets.symmetric(horizontal: 10.0),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(children: [
                  Expanded(
                      child: Text(paymentData[index].receivedDate!,
                          style: TextStyle(
                              color: Color(Constants.APP_COLOR),
                              fontWeight: FontWeight.bold))),
                  Expanded(
                      child: Text(
                    "$orgCurrencySymbol" +
                        CommonMethods.getCurrencyValues(
                            paymentData[index].receivedAmount),
                    style: TextStyle(color: Color(Constants.APP_COLOR)),
                  )),
                ]),
              ),
            ),
          );
        },
        itemCount: paymentData.length,
        separatorBuilder: (context, index) =>
            new Divider(height: 0.0, color: Colors.transparent),
      );
    } else {
      return Container(height: 40.0);
    }
  }

  Widget showPendingAmountView(num? pendingAmount) {
    return Container(
      padding: EdgeInsets.all(5.0),
      child: Row(
        children: [
          Expanded(
            child: Text(
              Language().getString(Constants.PENDING_AMOUNT, selectedLang),
              style: TextStyle(
                  color: Colors.black, fontWeight: StyleView.fontSemiBold),
            ),
          ),
          Expanded(
              child: Row(
            children: [
              Container(
                child: Text(
                  ": $orgCurrencySymbol" +
                      CommonMethods.getCurrencyValues(pendingAmount),
                  style: TextStyle(
                      fontSize: 13.0,
                      color: Colors.black,
                      fontWeight: StyleView.fontMedium),
                ),
              ),
              (isShowSmallCircularIndicator)
                  ? Container(
                      margin: EdgeInsets.symmetric(horizontal: 5.0),
                      height: 15.0,
                      width: 15.0,
                      child: CircularProgressIndicator(
                        strokeWidth: 2.0,
                        valueColor: new AlwaysStoppedAnimation<Color?>(
                            Colors.greenAccent[700]),
                      ),
                    )
                  : Container()
            ],
          )),
        ],
      ),
    );
  }

  Widget showInvoiceAmountView(String paymentDueDate, num? finalAmount) {
    return Container(
      child: Column(children: [
        Container(
            padding: EdgeInsets.all(5.0),
            margin: EdgeInsets.symmetric(vertical: 5.0),
            child: buildRowPaymentText(
                Constants.INVOICE_AMOUNT,
                "$orgCurrencySymbol" +
                    CommonMethods.getCurrencyValues(finalAmount),
                1,
                1)),
        Container(
            padding: EdgeInsets.all(5.0),
            margin: EdgeInsets.symmetric(
              vertical: 5.0,
            ),
            child: buildRowPaymentText(
                Constants.PAYMENT_DUE_DATE, "$paymentDueDate", 1, 1)),
      ]),
    );
  }

  Widget showResolutionStatusView(bool isTransactionOffline,
      InvoiceDetails invoiceDetails, String? invoiceId) {
    return Container(
      padding: EdgeInsets.all(5.0),
      margin: EdgeInsets.symmetric(vertical: 5.0),
      child: Row(
        children: [
          Expanded(
            child: Text(
              Language().getString(Constants.RESOLUTION, selectedLang),
              style: TextStyle(
                  color: Colors.black, fontWeight: StyleView.fontSemiBold),
            ),
          ),
          Expanded(
            flex: 1,
            child: Container(
              child: Text(
                ": ${invoiceDetails.paymentReconciliation != null ? invoiceDetails.paymentReconciliation!.status : ""}",
                style: TextStyle(
                    fontSize: 13.0,
                    color: Colors.black,
                    fontWeight: StyleView.fontMedium),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
