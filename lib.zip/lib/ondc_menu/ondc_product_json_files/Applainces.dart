class Appliances {
  static const List<Map<String, dynamic>> appliances = [
    {
      "sub_category": "Air Purifier",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": "",
      "length": "",
      "breadth": "",
      "height": ""
    },
    {
      "sub_category": "Dehumidifier",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": "",
      "length": "",
      "breadth": "",
      "height": ""
    },
    {
      "sub_category": "Humidifier",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": "",
      "length": "",
      "breadth": "",
      "height": ""
    },
    {
      "sub_category": "Air Cleaner Accessories",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": ""
    },
    {
      "sub_category": "Air Conditioner",
      "brand": "",
      "model": "",
      "type": "",
      "special feature": "",
      "includes": "",
      "weight": "",
      "length": "",
      "breadth": "",
      "height": ""
    },
    {
      "sub_category": "Air Conditioner Accessories",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": ""
    },
    {
      "sub_category": "Air Cooler",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": ""
    },
    {
      "sub_category": "Smart TV",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": "",
      "length": "",
      "breadth": "",
      "height": "",
      "warranty": "",
      "os type": "",
      "os version": ""
    },
    {
      "sub_category": "Standard TV",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": "",
      "length": "",
      "breadth": "",
      "height": "",
      "warranty": ""
    },
    {"sub_category": "TV Mount", "brand": ""},
    {"sub_category": "Remote", "brand": ""},
    {
      "sub_category": "Streaming Device",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": ""
    },
    {"sub_category": "TV Accessories", "brand": "", "special feature": ""},
    {
      "sub_category": "Home Theatre Projector",
      "brand": "",
      "special feature": "",
      "includes": "",
      "warranty": ""
    },
    {"sub_category": "TV Part", "brand": "", "special feature": ""},
    {"sub_category": "TV Remote", "brand": "", "special feature": ""},
    {
      "sub_category": "Set Top Box",
      "brand": "",
      "special feature": "",
      "includes": "",
      "warranty": ""
    },
    {"sub_category": "TV Stand", "brand": ""},
    {
      "sub_category": "Electric Brush",
      "brand": "",
      "model": "",
      "colour": "",
      "colour name": "",
      "special feature": "",
      "includes": "",
      "weight": "",
      "length": "",
      "breadth": "",
      "height": ""
    },
    {
      "sub_category": "Electric Iron",
      "brand": "",
      "model": "",
      "colour": "",
      "colour name": "",
      "special feature": "",
      "includes": "",
      "weight": "",
      "length": "",
      "breadth": "",
      "height": ""
    },
    {
      "sub_category": "Electric Sewing Machine",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": "",
      "length": "",
      "breadth": "",
      "height": ""
    },
    {
      "sub_category": "Water Heater",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": "",
      "length": "",
      "breadth": "",
      "height": ""
    },
    {
      "sub_category": "Heater Cables",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": "",
      "length": "",
      "breadth": "",
      "height": ""
    },
    {
      "sub_category": "Air Heater",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": "",
      "length": "",
      "breadth": "",
      "height": ""
    },
    {
      "sub_category": "Coffee Maker",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": "",
      "length": "",
      "breadth": "",
      "height": ""
    },
    {
      "sub_category": "Beverage Maker",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": "",
      "length": "",
      "breadth": "",
      "height": ""
    },
    {
      "sub_category": "Roti Maker",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": "",
      "length": "",
      "breadth": "",
      "height": ""
    },
    {
      "sub_category": "Induction Cooktop",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": "",
      "length": "",
      "breadth": "",
      "height": ""
    },
    {
      "sub_category": "Sandwich Maker",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": "",
      "length": "",
      "breadth": "",
      "height": ""
    },
    {
      "sub_category": "Electric Cooker",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": "",
      "length": "",
      "breadth": "",
      "height": ""
    },
    {
      "sub_category": "Electric Kettle",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": "",
      "length": "",
      "breadth": "",
      "height": ""
    },
    {
      "sub_category": "Microwave Oven",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": "",
      "length": "",
      "breadth": "",
      "height": ""
    },
    {
      "sub_category": "OTG",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": "",
      "length": "",
      "breadth": "",
      "height": ""
    },
    {
      "sub_category": "Toaster",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": "",
      "length": "",
      "breadth": "",
      "height": ""
    },
    {
      "sub_category": "Electric Air Fryer",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": "",
      "length": "",
      "breadth": "",
      "height": ""
    },
    {
      "sub_category": "Cooking Appliance Accessories",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": "",
      "length": "",
      "breadth": "",
      "height": ""
    },
    {
      "sub_category": "Coffee Grinder",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": "",
      "length": "",
      "breadth": "",
      "height": ""
    },
    {
      "sub_category": "Food Processor",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": "",
      "length": "",
      "breadth": "",
      "height": ""
    },
    {
      "sub_category": "Pasta Maker",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": ""
    },
    {
      "sub_category": "Food Processor Accessories",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": ""
    },
    {
      "sub_category": "Blender",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": ""
    },
    {
      "sub_category": "Juicer",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": "",
      "length": "",
      "breadth": "",
      "height": ""
    },
    {
      "sub_category": "Mixer Grinder",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": "",
      "length": "",
      "breadth": "",
      "height": ""
    },
    {
      "sub_category": "Wet Grinder",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": ""
    },
    {
      "sub_category": "Dishwasher",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": "",
      "length": "",
      "breadth": "",
      "height": ""
    },
    {
      "sub_category": "Dishwasher Accessories",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": ""
    },
    {
      "sub_category": "Electric Chimney",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": ""
    },
    {
      "sub_category": "Kitchen Accessories",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": ""
    },
    {
      "sub_category": "Freezer",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": ""
    },
    {
      "sub_category": "Refrigerator",
      "brand": "",
      "model": "",
      "colour": "",
      "colour name": "",
      "type": "",
      "special feature": "",
      "includes": "",
      "weight": "",
      "length": "",
      "breadth": "",
      "height": ""
    },
    {
      "sub_category": "Refrigerator Accessories",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": ""
    },
    {
      "sub_category": "Vaccum Cleaner",
      "brand": "",
      "model": "",
      "type": "",
      "special feature": "",
      "includes": "",
      "weight": ""
    },
    {
      "sub_category": "Vaccum Cleaner Parts and Accessories",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": ""
    },
    {
      "sub_category": "Washing Machine",
      "brand": "",
      "model": "",
      "colour": "",
      "colour name": "",
      "type": "",
      "special feature": "",
      "includes": "",
      "weight": "",
      "length": "",
      "breadth": "",
      "height": ""
    },
    {
      "sub_category": "Washing Machine Accessories",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": ""
    },
    {
      "sub_category": "Water Purifier",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": ""
    },
    {
      "sub_category": "Water Cooler",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": ""
    },
    {
      "sub_category": "Water Dispenser",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": ""
    },
    {
      "sub_category": "Water Purifier Service Kit",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": ""
    },
    {
      "sub_category": "Water Purifier filter",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": ""
    },
    {
      "sub_category": "Water Purifier Candle",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": ""
    },
    {
      "sub_category": "Water Purifier Pipe",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": ""
    },
    {
      "sub_category": "Water Purifier Accessories",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": ""
    },
    {
      "sub_category": "Water Cooler Accessories",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": ""
    },
    {
      "sub_category": "Inverter",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": ""
    },
    {
      "sub_category": "Inverter Batteries",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": ""
    },
    {
      "sub_category": "Battery Tray",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": ""
    },
    {
      "sub_category": "Voltage Stabilizer",
      "brand": "",
      "model": "",
      "special feature": "",
      "includes": "",
      "weight": ""
    },
  ];
}
