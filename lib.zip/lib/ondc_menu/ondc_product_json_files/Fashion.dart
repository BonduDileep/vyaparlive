class Fashion {
  static const List<Map<String, dynamic>> fashion = [
    {
      "sub_category": "Shirts",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "T Shirts",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Kurtas & Kurta Sets",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Jackets & Coats",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Sweaters",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Stoles & Scarves",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Mufflers",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Suits",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Sherwanis",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Track Shirts",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Unstitched Fabrics",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "fabric": ""
    },
    {
      "sub_category": "Dresses",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Tops",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Trousers",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Capris",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Coordinates",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Playsuits",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Jumpsuits",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Shrugs & blouses",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Blazzers & Waistcoats",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Tights,Leggings & Jeggings",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Track Pants",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Jeans",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Shorts",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Joggers",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Dhotis & Dhoti Pants",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Churidars",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Salwars",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Dungarees & Jumpsuits",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Skirts",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Cothing Sets",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Belts",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "material": "",
      "reversible": ""
    },
    {
      "sub_category": "Caps & Hats",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "material": ""
    },
    {
      "sub_category": "Kurtis & Tunics",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Sarees",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Ethnic Wear",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Palazzos",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Dress Materials",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Lehenga Cholis",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Duppatas & Shawls",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Burqas & Hijabs",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Blouses",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Blouse Pieces",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Briefs",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Boxers",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Vests",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Robes",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Night Suits",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Thermal Wear",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Swim Bottoms",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Swimwear",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Bra",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Shapewear",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Sleepwear & Loungewear",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Camisoles",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Lingerie Sets & Accessories",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Bath Robes",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Towels",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
    },
    {
      "sub_category": "Pyjamas",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Party Wear",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Innerwear & Sleepwear",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Nightwear & Loungewear",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Watches",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "strap material": "",
      "water resistant": "",
      "display": "",
      "glass material": ""
    },
    {
      "sub_category": "Gloves",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
    },
    {
      "sub_category": "Socks",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Stockings",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "fabric": ""
    },
    {
      "sub_category": "Laces",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "fabric": ""
    },
    {
      "sub_category": "Soles & Charms",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
    },
    {
      "sub_category": "Shoe Racks & Organisers",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
    },
    {
      "sub_category": "Shoe Care- Accessories",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
    },
    {
      "sub_category": "Flip-Flop & Flats",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Sandals & Floaters",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Backpacks",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "fabric": ""
    },
    {
      "sub_category": "HandBag",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
    },
    {
      "sub_category": "Trolley,Luggage & Suitcases",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "fabric": ""
    },
    {
      "sub_category": "Formal Shoes",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Casual Shoes",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Sports Shoes",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": "",
      "sport type": ""
    },
    {
      "sub_category": "Outdoor Shoes",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
    },
    {
      "sub_category": "Work & Safety Shoes",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
    },
    {
      "sub_category": "Ethnic Shoes",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Boots",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
    },
    {
      "sub_category": "Heels",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "size chart": "",
      "fabric": ""
    },
    {
      "sub_category": "Contact Lenses",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
    },
    {
      "sub_category": "Eye Glasses",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
    },
    {
      "sub_category": "Eye Glass Frames",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
    },
    {
      "sub_category": "Sunglasses",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
    },
    {
      "sub_category": "Contact Lens Cases",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
    },
    {
      "sub_category": "Contact Lens Solutions",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
    },
    {
      "sub_category": "Contact Lens Tweezers",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
    },
    {
      "sub_category": "Eyeglasse Pouches & Cases",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
    },
    {
      "sub_category": "Microfiber Wipes",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
    },
    {
      "sub_category": "Eyewear Slings",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
    },
    {
      "sub_category": "Bracelets",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "base metal": "",
      "plating": ""
    },
    {
      "sub_category": "Chains",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "base metal": "",
      "plating": ""
    },
    {
      "sub_category": "Mangalsutra",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "base metal": "",
      "plating": ""
    },
    {
      "sub_category": "Anklets",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "base metal": "",
      "plating": ""
    },
    {
      "sub_category": "Bangles & Bracelets",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
    },
    {
      "sub_category": "Necklaces",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "base metal": "",
      "plating": ""
    },
    {
      "sub_category": "Earrings",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "base metal": "",
      "plating": ""
    },
    {
      "sub_category": "Jewellery Sets",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "base metal": "",
      "plating": ""
    },
    {
      "sub_category": "Nosepins & Noserings",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "base metal": "",
      "plating": ""
    },
    {
      "sub_category": "Pendants",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "base metal": "",
      "plating": ""
    },
    {
      "sub_category": "Rings",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "base metal": "",
      "plating": ""
    },
    {
      "sub_category": "Toe Rings",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "base metal": "",
      "plating": ""
    },
    {
      "sub_category": "Gold Coins",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "base metal": "",
      "plating": ""
    },
    {
      "sub_category": "Brooch",
      "gender": "",
      "colour": "",
      "size": "",
      "brand": "",
      "base metal": "",
      "plating": ""
    },
  ];
}
