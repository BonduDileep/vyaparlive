class HomeAndKitchen {
  static const List<Map<String, dynamic>> home_kitchen = [
    {
      "sub_category": "Home Decor",
      "brand": "",
      "colour": "",
      "colour name": "",
      "material": ""
    },
    {
      "sub_category": "Furniture",
      "brand": "",
      "colour": "",
      "colour name": "",
      "material": ""
    },
    {
      "sub_category": "Home Furnishing - Bedding and Lenin",
      "brand": "",
      "colour": "",
      "colour name": "",
      "material": ""
    },
    {"sub_category": "Bins and Bathroom", "brand": "", "material": ""},
    {
      "sub_category": "Car and Shoe Care",
      "brand": "",
    },
    {
      "sub_category": "Disposables and Garbage Bags",
      "brand": "",
      "colour": "",
      "colour name": "",
      "material": ""
    },
    {
      "sub_category": "Fresheners and Repellents",
      "brand": "",
    },
    {"sub_category": "Mops,Brushes and Scrubs", "brand": "", "material": ""},
    {
      "sub_category": "Part and Festive Needs",
      "brand": "",
    },
    {
      "sub_category": "Flowers",
      "brand": "",
      "colour": "",
      "colour name": "",
    },
    {
      "sub_category": "Pooja Needs",
      "brand": "",
    },
    {
      "sub_category": "Paint and Wallpapers",
      "brand": "",
      "colour": "",
      "colour name": "",
      "material": ""
    },
    {
      "sub_category": "Hardware,Tools and Home Safety",
      "brand": "",
      "material": ""
    },
    {
      "sub_category": "Electricals",
      "brand": "",
      "colour": "",
      "colour name": "",
      "material": ""
    },
    {
      "sub_category": "Bathroom and Kitchen fixtures",
      "brand": "",
      "colour": "",
      "colour name": "",
      "material": ""
    },
    {"sub_category": "Garden and Outdoor", "brand": "", "material": ""},
    {
      "sub_category": "Sports and Fitness Equipment",
      "brand": "",
      "colour": "",
      "colour name": "",
      "material": ""
    },
    {
      "sub_category": "Cookware",
      "brand": "",
      "colour": "",
      "colour name": "",
      "material": ""
    },
    {
      "sub_category": "Serveware",
      "brand": "",
      "colour": "",
      "colour name": "",
      "material": ""
    },
    {
      "sub_category": "Kitchen Storage and Containers",
      "brand": "",
      "colour": "",
      "colour name": "",
      "material": ""
    },
    {
      "sub_category": "Kitchen Tools",
      "brand": "",
      "colour": "",
      "colour name": "",
      "material": ""
    },
    {
      "sub_category": "Closet/Laundry/Shoe Organization",
      "brand": "",
      "colour": "",
      "colour name": "",
      "material": ""
    },
    {
      "sub_category": "Toys and Games",
      "brand": "",
      "colour": "",
      "colour name": "",
      "material": ""
    },
    {
      "sub_category": "Stationery",
      "brand": "",
      "colour": "",
      "colour name": "",
      "material": ""
    },
    {
      "sub_category": "Home Furnishings",
      "brand": "",
      "colour": "",
      "colour name": "",
      "material": ""
    },
    {
      "sub_category": "Garden and Outdoor Products",
      "brand": "",
      "colour": "",
      "colour name": "",
      "material": ""
    },
    {
      "sub_category": "Home Improvement",
      "brand": "",
      "colour": "",
      "colour name": "",
      "material": ""
    },
    {
      "sub_category": "Cookware and Dining",
      "brand": "",
      "colour": "",
      "colour name": "",
      "material": ""
    },
    {
      "sub_category": "Storage and Organisation",
      "brand": "",
      "colour": "",
      "colour name": "",
      "material": ""
    },
  ];
}
