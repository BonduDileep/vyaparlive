class HealthAndWellness {
  static const List<Map<String, dynamic>> health_wellness = [
    {"sub_category": "Pain Relief", "brand": "", "prescription required": ""},
    {
      "sub_category": "Nutrition and Fitness Supplements",
      "brand": "",
      "prescription required": ""
    },
    {
      "sub_category": "Speciality Care",
      "brand": "",
      "prescription required": ""
    },
    {
      "sub_category": "Covid Essentials",
      "brand": "",
      "prescription required": ""
    },
    {
      "sub_category": "Diabetes Control",
      "brand": "",
      "prescription required": ""
    },
    {
      "sub_category": "Healthcare & Fitness Devices",
      "brand": "",
      "prescription required": ""
    },
    {"sub_category": "Ayurvedic", "brand": "", "prescription required": ""},
    {"sub_category": "Homeopathy", "brand": "", "prescription required": ""},
    {
      "sub_category": "Unani and Siddha",
      "brand": "",
      "prescription required": ""
    },
    {"sub_category": "Elder Care", "brand": "", "prescription required": ""},
    {"sub_category": "Baby Care", "brand": "", "prescription required": ""},
    {
      "sub_category": "Orthopaedic Care",
      "brand": "",
      "prescription required": ""
    },
    {"sub_category": "Mobility Aids", "brand": "", "prescription required": ""},
    {
      "sub_category": "Medicated Hair Care",
      "brand": "",
      "prescription required": ""
    },
    {
      "sub_category": "Medicated Skin Care",
      "brand": "",
      "prescription required": ""
    },
    {
      "sub_category": "Speciality Face Cleansers",
      "brand": "",
      "prescription required": ""
    },
    {"sub_category": "Gastric Care", "brand": "", "prescription required": ""},
    {"sub_category": "ENT Care", "brand": "", "prescription required": ""},
    {"sub_category": "Eye Care", "brand": "", "prescription required": ""},
    {
      "sub_category": "Cold and Cough",
      "brand": "",
      "prescription required": ""
    },
    {
      "sub_category": "Sexual Wellness",
      "brand": "",
      "prescription required": ""
    },
    {"sub_category": "Feminine Care", "brand": "", "prescription required": ""},
    {
      "sub_category": "Maternity Care",
      "brand": "",
      "prescription required": ""
    },
    {
      "sub_category": "Nursing and Feeding",
      "brand": "",
      "prescription required": ""
    },
    {"sub_category": "Hand Wash", "brand": "", "prescription required": ""},
    {"sub_category": "Sanitizers", "brand": "", "prescription required": ""},
    {
      "sub_category": "Baby Care-Wipes and Buds",
      "brand": "",
      "prescription required": ""
    },
    {
      "sub_category": "Baby Care-Rash Creams",
      "brand": "",
      "prescription required": ""
    },
    {
      "sub_category": "Baby Care-Diapers and Accessories",
      "brand": "",
      "prescription required": ""
    },
    {
      "sub_category": "Health and Safety",
      "brand": "",
      "prescription required": ""
    },
    {"sub_category": "Oral Care", "brand": "", "prescription required": ""},
    {
      "sub_category": "Contraceptives",
      "brand": "",
      "prescription required": ""
    },
    {"sub_category": "Breathe Easy", "brand": "", "prescription required": ""},
    {
      "sub_category": "Health Foods and Drinks",
      "brand": "",
      "prescription required": ""
    },
    {
      "sub_category": "Wound Care and Dressings",
      "brand": "",
      "prescription required": ""
    },
    {"sub_category": "Surgicals", "brand": "", "prescription required": ""},
    {
      "sub_category": "Mental Wellness",
      "brand": "",
      "prescription required": ""
    },
    {"sub_category": "Gift Voucher", "brand": "", "prescription required": ""},
    {"sub_category": "Personal Care", "brand": "", "prescription required": ""},
    {
      "sub_category": "Healthcare Devices",
      "brand": "",
      "prescription required": ""
    },
    {"sub_category": "Ayush", "brand": "", "prescription required": ""}
  ];
}
