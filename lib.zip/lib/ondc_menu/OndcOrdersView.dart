import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/ondc_menu/OndcTransactionSteps.dart';
import 'package:vyaparlive/service/api_service/TransactionApiService.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../components/AppController.dart';
import '../components/AppUtills.dart';
import '../components/DateFilterUtil.dart';
import '../components/MyDrawer.dart';
import '../components/common_methods.dart';
import '../config/Language.dart';
import '../model/TransactionsModel.dart';
import '../page_transition/PageTransition.dart';
import '../theme/app_theme.dart';
import '../utills/AppBarName.dart';

class OndcOrdersView extends StatefulWidget {
  const OndcOrdersView({super.key});

  @override
  State<OndcOrdersView> createState() => _OndcOrdersViewState();
}

class _OndcOrdersViewState extends State<OndcOrdersView> {
  late ThemeData theme;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  String? buName = "";
  bool isLoadingProgress = false;
  String progressMessage = Constants.LOADING;
  late TextEditingController fromDateController = new TextEditingController();
  late TextEditingController toDateController = new TextEditingController();
  late TextEditingController _searchController = new TextEditingController();
  DateFormat formatter = DateFormat("yyyy-MM-dd");
  DateTime mnthStartDate =
      DateTime.utc(DateTime.now().year, DateTime.now().month, 1);
  late bool isShowFloatButton = false;
  List<TransactionsModel> transactionList = [];
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    buName = AppController.instance.getBuName;
    fromDateController.text = formatter.format(mnthStartDate);
    toDateController.text = formatter.format(DateTime.now());
    Future.delayed(Duration(seconds: 500))
        .then((value) => isLoadingProgress = true);
    fetchTransactionData();
  }

  renderOrdersTableView() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Table(
        defaultVerticalAlignment: TableCellVerticalAlignment.middle,
        border: TableBorder.all(
            color: Color(Constants.APP_COLOR),
            borderRadius: BorderRadius.circular(5)),
        defaultColumnWidth: FixedColumnWidth(90),
        children: [
          TableRow(children: [
            renderTableHeaders(
                Language().getString(Constants.DATE, selectedLang)),
            renderTableHeaders(
                Language().getString(Constants.NAME_STRING, selectedLang)),
            renderTableHeaders(
                Language().getString(Constants.BUYER_APP, selectedLang)),
            renderTableHeaders(
                Language().getString(Constants.STATUS_STRING, selectedLang)),
            renderTableHeaders(
                Language().getString(Constants.ORDER_DETAILS, selectedLang)),
          ]),
          for (int i = 0; i < transactionList.length; i++) renderTableRowText(i)
        ],
      ),
    );
  }

  Widget renderTableData(String value, {bool isNew = false}) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            Container(
              padding: const EdgeInsets.all(4.0),
              child: Text(
                value,
                style: TextStyle(
                  fontSize: 13,
                  color: Colors.black,
                  fontWeight: StyleView.fontMedium,
                ),
              ),
            ),
            if (isNew)
              Positioned(
                top: -6,
                right: -6,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 3, vertical: 1),
                  decoration: BoxDecoration(
                    color: Colors.red,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    'New',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 7,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _renderTableData(String value) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          child: Text("$value",
              style: TextStyle(
                  fontSize: 13,
                  color: Colors.black,
                  fontWeight: StyleView.fontMedium)),
        ),
      ),
    );
  }

  TableRow renderTableRowText(int index) {
    String? name = "";
    if (transactionList[index].seller!.id == AppController.instance.getMyBuId) {
      name = transactionList[index].buyer!.name;
    }

    return TableRow(
      children: [
        renderTableData(AppUtills.getDateFormate(
            transactionList[index].transactionDate.toString())),
        renderTableData(name!,isNew:transactionList[index].buyerApp!.hasIgm!),
        renderTableData(transactionList[index].buyerApp != null
            ? transactionList[index].buyerApp!.buyerApp!
            : ""),
        renderTableData(transactionList[index].status!),
        InkWell(
          child: Icon(
            Icons.open_in_new,
            size: 20,
          ),
          onTap: () {
            Navigator.push(
                    context,
                    PageTransition(
                        context: context,
                        page: OndcTransactionSteps(
                            transactionId: transactionList[index].id!)))
                .then((value) => fetchTransactionData());
          },
        )
      ],
    );
  }

  Widget renderTableHeaders(String? headerText) {
    return Container(
      alignment: Alignment.center,
      padding: EdgeInsets.all(8.0),
      child: Text(
        Language().getString(headerText, selectedLang),
        style: TextStyle(
            color: Colors.black,
            fontWeight: StyleView.fontSemiBold,
            fontSize: 15.0),
      ),
    );
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  void setState(VoidCallback fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
      body: Stack(
        children: [
          SafeArea(
            child: Scaffold(
              key: _scaffoldkey,
              backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
              appBar: AppBar(
                elevation: 0,
                iconTheme: IconThemeData(color: theme.colorScheme.primary),
                backgroundColor: Colors.transparent,
                title: AppbarName(
                    title: Language().getString(Constants.ORDERS, selectedLang),
                    buName: "$buName"),
                centerTitle: true,
              ),
              floatingActionButton: (isShowFloatButton)
                  ? FloatingActionButton(
                      backgroundColor: theme.colorScheme.primary,
                      onPressed: () {
                        CommonMethods.hideKeyboard(context);
                        setState(() {
                          isShowFloatButton = false;
                          fromDateController.text =
                              formatter.format(mnthStartDate);
                          toDateController.text =
                              formatter.format(DateTime.now());
                          _searchController.clear();
                        });
                        fetchTransactionData();
                      },
                      child: Text(
                        Language()
                            .getString(Constants.CLEAR_FILTERS, selectedLang),
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white, fontSize: 11.0),
                      ))
                  : null,
              drawer: MyDrawer(),
              body: Container(
                padding: EdgeInsets.all(10.0),
                child: Column(
                  children: [
                    Container(
                      height: 50.0,
                      child: Padding(
                        padding: const EdgeInsets.only(left: 10),
                        child: Card(
                          elevation: 2.5,
                          shadowColor: theme.colorScheme.primary,
                          shape: new RoundedRectangleBorder(
                              borderRadius: new BorderRadius.circular(15),
                              side: new BorderSide(
                                  color: theme.colorScheme.primary,
                                  strokeAlign: 0.01)),
                          child: Row(
                            children: <Widget>[
                              Expanded(
                                child: Container(
                                  padding: EdgeInsets.only(left: 15),
                                  child: TextFormField(
                                    controller: _searchController,
                                    onChanged: (value) {
                                      print(value);
                                      if (value.isEmpty) {
                                        Future.delayed(Duration(seconds: 500))
                                            .then((value) => setState(() {
                                                  isLoadingProgress = true;
                                                }));
                                        fetchTransactionData();
                                      } else {
                                        Future.delayed(Duration(seconds: 500))
                                            .then((value) => setState(() {
                                                  isLoadingProgress = false;
                                                }));
                                        fetchTransactionData();
                                      }
                                    },
                                    style: TextStyle(
                                        fontWeight: StyleView.fontSemiBold),
                                    decoration: InputDecoration(
                                        contentPadding:
                                            EdgeInsets.only(bottom: 10),
                                        border: InputBorder.none,
                                        hintText: Language().getString(
                                            Constants.SEARCH_BY_NAME,
                                            selectedLang),
                                        hintStyle: TextStyle(
                                            fontSize: 13.0,
                                            fontWeight: StyleView.fontSemiBold)),
                                  ),
                                ),
                              ),
                              (_searchController.text.length > 0)
                                  ? Container(
                                      color: Colors.white,
                                      child: IconButton(
                                          icon: Icon(
                                            Icons.close,
                                            color: Colors.red,
                                            size: 20.0,
                                          ),
                                          onPressed: () {
                                            CommonMethods.hideKeyboard(context);
                                            _searchController.clear();
                                            fetchTransactionData();
                                          }),
                                    )
                                  : Container(),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding:
                          const EdgeInsets.only(left: 0.0, top: 10, bottom: 16),
                      child: DateFilterUtill(
                        fromDate: "",
                        toDate: "",
                        fromDateController: fromDateController,
                        toDateController: toDateController,
                        onFromDateSelected: (value) {
                          setState(() => fromDateController.text = value);
                        },
                        onToDateSelected: (value) {
                          setState(() => toDateController.text = value);
                        },
                        isShowSearchButton: true,
                        onSearchParms: () {
                          setState(() {
                            isShowFloatButton = true;
                            isLoadingProgress = true;
                          });
                          fetchTransactionData();
                        },
                      ),
                    ),
                    (transactionList.length > 0)
                        ? Expanded(
                            child: SingleChildScrollView(
                              scrollDirection: Axis.vertical,
                              child: renderOrdersTableView(),
                            ),
                          )
                        : Expanded(
                            child: Center(
                                child: Text(
                                    Language().getString(
                                        Constants.NO_DATAFOUND_STRING,
                                        selectedLang),
                                    style: TextStyle(
                                        color: Colors.black,
                                        fontWeight: StyleView.fontMedium)))),
                  ],
                ),
              ),
            ),
          ),
          AppUtills.showLoadingView(
              context: context,
              message: Language().getString(progressMessage, selectedLang),
              isLoading: isLoadingProgress),
        ],
      ),
    );
  }

  Future<void> fetchTransactionData() async {
    if (await NetworkStatus.getInternetStatus()) {
      Map<String, dynamic> mapData = {
        "DateFrom": fromDateController.text,
        "DateTo": toDateController.text,
        "status": "",
        "name": _searchController.text.trim(),
        "transaction_type": "",
        "offline": false
      };
      setState(() {
        transactionList.clear();
      });
      List<TransactionsModel> fetchData = await TransactionApiService.instance
          .getAllTransactions(
              context: context,
              buId: AppController.instance.getMyBuId,
              mapData: mapData,
              ondcTransaction: true,
              langError: Language().getString(Constants.ERROR, selectedLang),
              langOk: Language().getString(Constants.OKAY_STR, selectedLang));
      setState(() {
        isLoadingProgress = false;
      });
      if (fetchData.length > 0) {
        setState(() {
          transactionList.addAll(fetchData);
        });
      }
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }
}
