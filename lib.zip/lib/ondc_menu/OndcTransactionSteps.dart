import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/ondc_menu/OndcPaymentView.dart';
import 'package:vyaparlive/service/api_service/TransactionApiService.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:im_animations/im_animations.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'IGMTicketDetailsPage.dart';
import 'ond_delivery_page/OndcDeliveryPage.dart';
import '../Transaction/seller/InvoiceList.dart';
import '../Transaction/seller/PackingPage.dart';
import '../Transaction/seller/PurchaseOrderPage.dart';
import '../components/AppUtills.dart';
import '../components/Constants.dart';
import '../components/StyleView.dart';
import '../components/TransactionDetailsView.dart';
import '../config/Language.dart';
import '../model/TransactionsModel.dart';
import '../model/transaction/InvoiceDetailsModel.dart';
import '../model/transaction/StockDetailsModel.dart';
import '../page_transition/PageTransition.dart';
import '../theme/app_theme.dart';
import '../utills/animation/list_loader/ListLoader.dart';

class OndcTransactionSteps extends StatefulWidget {
  final String transactionId;
  const OndcTransactionSteps({super.key, required this.transactionId});

  @override
  State<OndcTransactionSteps> createState() => _OndcTransactionStepsState();
}

class _OndcTransactionStepsState extends State<OndcTransactionSteps> {
  List<String> _transactionItems = [];
  List<int> cardColors = [
    0xff00ffa5,
    0xffd300a9,
    0xff8f00f8,
    0xffffa500,
    0xff00ffa5,
    0xffd300a9,
  ];
  TransactionsModel? transactionData;
  bool isLoadingProgress = false;
  List<String> transactionStatusList = [];
  ScrollController? scrollController;
  late ThemeData theme;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  String? strComplete = Constants.TOTAL_COMPLETED;
  String? strPending = Constants.PENDING;
  String? strCancelledInvoices = Constants.CANCELLED_INVOICES;
  String? strResolved = Constants.RESOLVED;
  String? strNotResolved = Constants.NOT_RESOLVED;
  String? strNoOfInvoices = Constants.NO_OF_INVOICES;
  String strTotalStockCompleted = "Stock Deliveries Received";
  List<Map> _namesData = [];
  @override
  void initState() {
    super.initState();
    getLoadLanguage();
    theme = AppTheme.vyaparTheme;
    scrollController = new ScrollController();
    fetchTransactionData();
  }

  getLoadLanguage() {
    strCancelledInvoices =
        Language().getString(Constants.CANCELLED_INVOICES, selectedLang);
    strComplete = Language().getString(Constants.TOTAL_COMPLETED, selectedLang);
    strPending = Language().getString(Constants.PENDING, selectedLang);
    strNotResolved = Language().getString(Constants.NOT_RESOLVED, selectedLang);
    strResolved = Language().getString(Constants.RESOLVED, selectedLang);
    strNoOfInvoices =
        Language().getString(Constants.NO_OF_INVOICES, selectedLang);

    setState(() {
      _namesData = [
        {"name": Language().getString(Constants.NAME_STRING, selectedLang)},
        {"name": Language().getString(Constants.TXN_ID, selectedLang)},
        {
          "name":
              Language().getString(Constants.TXN_INITIATED_DATE, selectedLang)
        }
      ];
    });
  }

  listItems(String text) {
    switch (text) {
      case Constants.PURCHANSE_ORDER:
        Navigator.push(
                context,
                PageTransition(
                    context: context,
                    page: PurchaseOrderPage(
                        transactionName:
                            "${transactionData?.buyer!.name} ( Buyer )",
                        transactionId: widget.transactionId)))
            .then((value) => {fetchTransactionData()});

        break;
      case Constants.INVOICE:
        Navigator.push(
            context,
            PageTransition(
                context: context,
                page: InvoiceListPage(
                  transactionName: "${transactionData?.buyer!.name} ( Buyer )",
                  transactionId: widget.transactionId,
                ))).then((value) => {fetchTransactionData()});

        break;
      case Constants.PACKING_INSPECTION:
        Navigator.push(
                context,
                PageTransition(
                    context: context,
                    page: PackingPage(
                        transactionName:
                            "${transactionData?.buyer!.name} ( Buyer )",
                        transactionId: widget.transactionId)))
            .then((value) => {fetchTransactionData()});

        break;
      case Constants.DELIVERY_TRACKING:
        Navigator.push(
                context,
                new MaterialPageRoute(
                    builder: (context) => OndcDirectDeliveryPage(
                        transactionId: widget.transactionId,
                        transactionName:
                            "${transactionData?.buyer!.name} ( Buyer )")))
            .then((value) => fetchTransactionData());

        break;

      case Constants.PAYMENT_RECONCILIATION:
        Navigator.push(
            context,
            PageTransition(
                context: context,
                page: OndcPaymentView(
                  transactionName: "${transactionData?.buyer!.name} ( Buyer )",
                  transactionId: widget.transactionId,
                  reconciliationName: Constants.PAYMENT_RECONCILIATION,
                ))).then((value) => {fetchTransactionData()});

        break;

      case Constants.ISSUE_GRIEVANCE:
        Navigator.push(
                context,
                PageTransition(
                    context: context,
                    page: IGMTicketDetailsPage(transactionId: widget.transactionId,)))
            .then((value) => {fetchTransactionData()});

        break;

      default:
    }
  }

  updateStatus(int index, String status) {
    transactionStatusList[index] = status;
  }

  updateTabView(int index, String validateTabHeadingValue) {
    if (validateTabHeadingValue == Constants.PURCHANSE_ORDER) {
      if (transactionData!.invoiceDetails!.length > 0) {
        updateStatus(index, "PO & Invoice Generation Complete");
      } else if (transactionData!.offerDetails != null &&
          transactionData!.offerDetails!.status == "Order Rejected") {
        updateStatus(index, "Purchase Order Rejected");
      } else {
        updateStatus(index, "");
      }
    } else if (validateTabHeadingValue == Constants.INVOICE) {
      if (transactionData!.invoiceDetails!.length > 0) {
        updateStatus(
            index,
            "Invoices Generated\n" +
                "$strNoOfInvoices :  ${transactionData!.invoiceDetails!.length}");
      } else {
        updateStatus(index, "");
      }
    } else if (validateTabHeadingValue == Constants.PACKING_INSPECTION) {
      if (transactionData!.invoiceDetails!.length == 0) {
        return;
      }
      bool isPackingDetailsUpdated = false;
      for (var element in transactionData!.invoiceDetails!) {
        if (element.packageDetails != null) {
          isPackingDetailsUpdated = true;
        }
      }
      if (isPackingDetailsUpdated) {
        updateStatus(index, "Packing Completed");
      } else {
        updateStatus(index, "Packing not Completed");
      }
    } else if (validateTabHeadingValue == Constants.DELIVERY_TRACKING) {
      if (transactionData!.invoiceDetails!.length == 0) {
        return;
      }
      bool isDeliveryDetailsUpdated = false;
      for (var element in transactionData!.invoiceDetails!) {
        InvoiceDetails indexInvoiceDeliveryData = element;
        if (indexInvoiceDeliveryData.packageDetails != null &&
            indexInvoiceDeliveryData.orderTrackDetails != null) {
          isDeliveryDetailsUpdated = true;
        }
      }
      if (isDeliveryDetailsUpdated) {
        updateStatus(index, "Delivery details updated");
      }
    } else if (validateTabHeadingValue == Constants.PAYMENT_RECONCILIATION) {
      if (transactionData!.invoiceDetails!.length == 0) {
        return;
      }
      bool isPaymentResolved = false;
      for (var element in transactionData!.invoiceDetails!) {
        StockReconciliation? indexPaymentData = element.paymentReconciliation;
        if (indexPaymentData != null && indexPaymentData.status == "resolved") {
          isPaymentResolved = true;
        }
      }
      if (isPaymentResolved) {
        updateStatus(index, "Payment Resolved");
      }
    }
  }

  renderTabStatusText(int index, String tabHeadingValue) {
    updateTabView(index, tabHeadingValue);
    if (transactionStatusList.length > 0 &&
        transactionStatusList[index] != "") {
      return Container(
        child: Row(
          children: [
            Text(
              Language().getString(Constants.STATUS_STRING, selectedLang) +
                  " : ${transactionStatusList[index]}",
              style: TextStyle(
                fontSize: 12.0,
                fontWeight: StyleView.fontRegular,
                color: Colors.black,
              ),
            ),
          ],
        ),
      );
    } else {
      return Container();
    }
  }

  showCompletedIcon(Color color) {
    return Icon(
      Icons.check_circle,
      size: 20.0,
      color: color,
    );
  }

  showCircularContainer() {
    return ColorSonar(
      contentAreaRadius: 6.0,
      waveFall: 3.0,
      waveMotion: WaveMotion.synced,
      duration: Duration(seconds: 1),
      innerWaveColor: Colors.orange,
      middleWaveColor: Colors.orange.withOpacity(0.6),
      outerWaveColor: Colors.orange.withOpacity(0.6),
      child: Container(
        width: 15.0,
        height: 10.0,
        decoration: new BoxDecoration(
          color: Colors.orange,
          shape: BoxShape.circle,
        ),
      ),
    );
  }

  colorHandlingByStatus(int index, String tabHeading) {
    if (tabHeading == Constants.PURCHANSE_ORDER) {
      if (transactionData?.invoiceDetails!.length == 0) {
        return showCircularContainer();
      } else {
        if (transactionData?.offerDetails != null &&
                transactionData?.offerDetails!.status != "pending" &&
                transactionData?.offerDetails!.status !=
                    Constants.ORDER_REJECTED ||
            transactionData!.invoiceDetails!.length > 0) {
          return showCompletedIcon(Colors.green);
        } else {
          if (transactionData?.transactionType == "direct") {
            return showCircularContainer();
          } else {
            return showCompletedIcon(Colors.transparent);
          }
        }
      }
    } else if (tabHeading == Constants.INVOICE) {
      if (transactionData!.invoiceDetails!.length > 0) {
        return showCompletedIcon(Colors.green);
      } else {
        return showCompletedIcon(Colors.transparent);
      }
    } else if (tabHeading == Constants.PACKING_INSPECTION) {
      if (transactionData?.status == Constants.INVOICE_GENERATED) {
        return showCircularContainer();
      } else {
        bool isPackingDetailsUpdated = false;
        for (var element in transactionData!.invoiceDetails!) {
          if (element.packageDetails != null) {
            isPackingDetailsUpdated = true;
          }
        }
        if (isPackingDetailsUpdated) {
          return showCompletedIcon(Colors.green);
        } else {
          return showCompletedIcon(Colors.transparent);
        }
      }
    } else if (tabHeading == Constants.DELIVERY_TRACKING) {
      if (transactionData?.status == Constants.PACKING_COMPLETED ||
          transactionData?.status == Constants.READY_FOR_DELIVERY) {
        return showCircularContainer();
      } else {
        bool isDeliveryDetailsUpdated = false;
        for (var element in transactionData!.invoiceDetails!) {
          if (element.orderTrackDetails != null) {
            isDeliveryDetailsUpdated = true;
          }
        }

        if (isDeliveryDetailsUpdated) {
          return showCompletedIcon(Colors.green);
        } else {
          return showCompletedIcon(Colors.transparent);
        }
      }
    } else if (tabHeading == Constants.PAYMENT_RECONCILIATION) {
      if (transactionData?.status == "Stocks dispatched") {
        return showCircularContainer();
      }
      bool isPaymentReconciliationResolved = false;
      if (transactionData?.status == Constants.PAYMENT_RESOLVED) {
        for (var element in transactionData!.invoiceDetails!) {
          if (element.paymentReconciliation != null &&
              element.paymentReconciliation!.status == "resolved") {
            isPaymentReconciliationResolved = true;
          }
        }
        if (isPaymentReconciliationResolved) {
          return showCompletedIcon(Colors.green);
        } else {
          return showCircularContainer();
        }
      } else {
        return showCompletedIcon(Colors.transparent);
      }
    } else if (tabHeading == Constants.ISSUE_GRIEVANCE) {
      return showCompletedIcon(Colors.transparent);
    }
  }

  Widget renderBody() {
    if (isLoadingProgress) {
      return ListLoader();
    }

    if (!isLoadingProgress && transactionData == null) {
      return Expanded(
          child: Center(
              child: new Text(Language()
                  .getString(Constants.NO_DATAFOUND_STRING, selectedLang))));
    }

    return Container(
      padding: EdgeInsets.all(10),
      child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            TransactionDetailsViewPage(
              transactionName: "${transactionData?.buyer!.name} ( Buyer )",
              transactionId: transactionData?.id,
              transactionDate: transactionData?.transactionDate.toString(),
              namesData: _namesData,
            ),
            SizedBox(height: 5.0),
            Expanded(
              child: Container(
                child: AnimationLimiter(
                  child: ListView.separated(
                      controller: scrollController,
                      shrinkWrap: true,
                      physics: const BouncingScrollPhysics(
                          parent: AlwaysScrollableScrollPhysics()),
                      itemBuilder: (context, index) {
                        return AnimationConfiguration.staggeredList(
                          position: index,
                          duration: Duration(milliseconds: 500),
                          child: SlideAnimation(
                            verticalOffset: 50.0,
                            child: FadeInAnimation(
                              child: InkWell(
                                onTap: () {
                                  listItems(_transactionItems[index]);
                                },
                                child: Container(
                                  child: Card(
                                      elevation: 7.0,
                                      shadowColor: theme.colorScheme.primary,
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Container(
                                          padding: EdgeInsets.all(10.0),
                                          child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: <Widget>[
                                                Container(
                                                  child: Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      Container(
                                                        child: Text(
                                                          _transactionItems[
                                                              index],
                                                          style: TextStyle(
                                                              color: theme
                                                                  .colorScheme
                                                                  .primary,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w700),
                                                        ),
                                                      ),
                                                      renderTabStatusText(
                                                          index,
                                                          _transactionItems[
                                                              index])
                                                    ],
                                                  ),
                                                ),
                                                colorHandlingByStatus(index,
                                                    _transactionItems[index])
                                              ]),
                                        ),
                                      )),
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                      separatorBuilder: (context, index) =>
                          new Divider(height: 0.0, color: Colors.transparent),
                      itemCount: _transactionItems.length),
                ),
              ),
            )
          ]),
    );
  }

  @override
  void setState(VoidCallback fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
        body: Stack(
      children: [
        SafeArea(
          child: Scaffold(
            backgroundColor: Colors.transparent,
            appBar: AppBar(
              centerTitle: true,
              elevation: 0,
              backgroundColor: Colors.transparent,
              title: AppbarName(
                  title: Language()
                      .getString(Constants.TRANSACTIONS_STR, selectedLang),
                  buName: AppController.instance.getBuName),
              iconTheme: IconThemeData(color: theme.colorScheme.primary),
              actions: [
                AppUtills.homeButton(context),
              ],
            ),
            body: renderBody(),
          ),
        )
      ],
    ));
  }

  Future<void> fetchTransactionData() async {
    setState(() => isLoadingProgress = true);
    final List<TransactionsModel> fetchData =
        await TransactionApiService.instance.getTransactionDataById(
            context: context,
            transactionId: widget.transactionId,
            langError: Language().getString(Constants.ERROR, selectedLang),
            langOk: Language().getString(Constants.OKAY_STR, selectedLang));
    setState(() => isLoadingProgress = false);
    if (fetchData.length > 0) {
      setState(() {
        transactionData = fetchData[0];
        _transactionItems = [
            Constants.PURCHANSE_ORDER,
            Constants.INVOICE,
            Constants.PACKING_INSPECTION,
            Constants.DELIVERY_TRACKING,
            Constants.PAYMENT_RECONCILIATION
          ];

        if (fetchData[0].buyerApp!.igmDao != null) {
           _transactionItems.add(Constants.ISSUE_GRIEVANCE);
        }
        for (var element in _transactionItems) {
          transactionStatusList.add("");
        }
      });
    }
  }
}
