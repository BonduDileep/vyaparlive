import 'dart:convert';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:vyaparlive/model/ondc_dao/IgmDao.dart';

import '../components/AppController.dart';
import '../components/AppUtills.dart';
import '../components/Constants.dart';
import '../components/Dialog.dart';
import '../components/common_methods.dart';
import '../config/Language.dart';
import '../model/BusinessUnitModel.dart';
import '../model/GRPCResponse.dart';
import '../model/TransactionsModel.dart';
import '../model/transaction/ProductDetailsModel.dart';
import '../service/Service.dart';
import '../service/api_service/TransactionApiService.dart';
import '../service/organization_service.dart';
import '../theme/app_theme.dart';
import '../utills/AppBackgroundView.dart';
import '../utills/AppBarName.dart';
import '../utills/animation/list_loader/ListLoader.dart';

class IGMTicketDetailsPage extends StatefulWidget {
  final String transactionId;
  const IGMTicketDetailsPage({super.key, required this.transactionId});

  @override
  State<IGMTicketDetailsPage> createState() => _IGMTicketDetailsPageState();
}

class _IGMTicketDetailsPageState extends State<IGMTicketDetailsPage> {
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  TransactionsModel? transactionData;
  bool isLoadingProgress = false;
  late Service _service;
  late OrganizationService _organizationService;
  BusinessUnitModel? buDetails;

  String? selectedAction;
  final TextEditingController _replyMessageController = TextEditingController();
  final TextEditingController _resolutionRefundAmountController =
      TextEditingController();
  final TextEditingController _resolutionDescriptionController =
      TextEditingController();
  late ThemeData theme;

  final List<String> actionItems = [
    'Select your action',
    'Processing',
    'Need-More-Info',
    'Cascaded',
    'Resolved'
  ];

  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    _service = Service();
    _organizationService = OrganizationService();
    theme = AppTheme.vyaparTheme;
    fetchTransactionData();
  }

  Future<List<BusinessUnitModel>> getBuData(
      TransactionsModel transactionModel) async {
    setState(() {
      isLoadingProgress = true;
    });
    String body = json.encode({
      "id": AppController.instance.getMyBuId
      // transactionModel
      //     .buyerApp!.igmDao!.message!.issue!.orderDetails!.providerId
    });

    var response = await _organizationService
        .getOrganizationDataById(
            body: body, token: AppController.instance.getAuthorizationKey)
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });

    List<BusinessUnitModel> _list = [];

    setState(() {
      isLoadingProgress = false;
    });

    GRPCResponse _grpcResponse = response;
    if (!_grpcResponse.getIsError! && !_grpcResponse.getIsException!) {
      var object = json.decode(_grpcResponse.message!);
      _list.add(BusinessUnitModel.fromJson(object[0]));
      setState(() {
        buDetails = _list[0];
      });
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          _grpcResponse.message,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    }
  
    return _list;
  }

  Future<void> fetchTransactionData() async {
    setState(() => isLoadingProgress = true);
    final List<TransactionsModel> fetchData =
        await TransactionApiService.instance.getTransactionDataById(
            context: context,
            transactionId: widget.transactionId,
            langError: Language().getString(Constants.ERROR, selectedLang),
            langOk: Language().getString(Constants.OKAY_STR, selectedLang));
    setState(() => isLoadingProgress = false);
    if (fetchData.length > 0) {
      setState(() {
        transactionData = fetchData[0];
      });
      getBuData(fetchData[0]);
    }
  }

  Future<bool> onReplyProcessing(String message, String? id) async {
    Map data = {
      "action": "PROCESSING",
      "id": transactionData!.buyerApp!.igmDao!.id,
      "reason": message,
      "additional_req_id": id != null ? id : null
    };

    setState(() {
      isLoadingProgress = true;
    });
    http.Response response = await _service
        .postIgmReplyProcessing(json.encode(data))
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    setState(() {
      isLoadingProgress = false;
    });
    if (response.statusCode == 200) {
      var object = json.decode(response.body);
      Navigator.of(context).pop();
    } else if (response.statusCode == 401) {
      CommonMethods.handleUnauthorizedAccess(context);
      return false;
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          response.body,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
      return false;
    }

    return true;
  }

  Future<bool> onReplyNeedMoreInfo(String message, String? id) async {
    Map data = {
      "action": "INFO_REQUESTED",
      "id": transactionData!.buyerApp!.igmDao!.id,
      "requested_info": message,
      "additional_req_id": id != null ? id : null
    };
    setState(() {
      isLoadingProgress = true;
    });
    http.Response response = await _service
        .postIgmReplyNeedMoreInfo(json.encode(data))
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    setState(() {
      isLoadingProgress = false;
    });
    if (response.statusCode == 200) {
      var object = json.decode(response.body);
      Navigator.of(context).pop();
    } else if (response.statusCode == 401) {
      CommonMethods.handleUnauthorizedAccess(context);
      return false;
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          response.body,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
      return false;
    }

    return true;
  }

  Future<bool> onSendResolution(String amount, String description) async {
    Map data = {
      "id": transactionData!.buyerApp!.igmDao!.id,
      "item": selectedItem,
      "refund_amt": amount,
      "description": description
    };
    setState(() {
      isLoadingProgress = true;
    });
    http.Response response = await _service
        .post_sendIGMResolution(json.encode(data))
        .catchError((value) {
      setState(() {
        isLoadingProgress = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    setState(() {
      isLoadingProgress = false;
    });
    if (response.statusCode == 200) {
      var object = json.decode(response.body);
      Navigator.of(context).pop();
    } else if (response.statusCode == 401) {
      CommonMethods.handleUnauthorizedAccess(context);
      return false;
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          response.body,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
      return false;
    }

    return true;
  }

  Future<bool> onResolve() async {
    Map data = {
      "id": transactionData!.buyerApp!.igmDao!.id,
    };
    setState(() {
      isLoading = true;
    });
    http.Response response =
        await _service.post_IGMResolve(json.encode(data)).catchError((value) {
      setState(() {
        isLoading = false;
      });
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          value.toString(),
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    });
    setState(() {
      isLoading = false;
    });
    if (response.statusCode == 200) {
      var object = json.decode(response.body);
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ALERT, selectedLang),
          "Resolved successfully.",
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
    } else if (response.statusCode == 401) {
      CommonMethods.handleUnauthorizedAccess(context);
      return false;
    } else {
      Dialogs.yesCancelDialog(
          context,
          Language().getString(Constants.ERROR, selectedLang),
          response.body,
          Language().getString(Constants.OKAY_STR, selectedLang),
          "",
          false);
      return false;
    }

    return true;
  }

  Widget renderProducts(ProductDetails productDetails) {
    return Row(
      children: [
        ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: productDetails.productImage != null
                ? CachedNetworkImage(
                    imageUrl:
                        '${Constants.IAMGE_BUCKET_URL}${productDetails.productImage}',
                    width: MediaQuery.of(context).size.width * 0.2,
                    height: MediaQuery.of(context).size.height * 0.1,
                    fit: BoxFit.cover,
                    errorWidget: (context, url, error) => Image.asset(
                      'assets/images/no_image.jpg',
                      width: MediaQuery.of(context).size.width * 0.2,
                      height: MediaQuery.of(context).size.height * 0.1,
                      fit: BoxFit.cover,
                    ),
                  )
                : Image.asset(
                    'assets/images/no_image.jpg',
                    width: MediaQuery.of(context).size.width * 0.2,
                    height: MediaQuery.of(context).size.height * 0.1,
                    fit: BoxFit.cover,
                  )),
        const SizedBox(width: 10),
        Text(
          "${productDetails.productName!}",
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
      ],
    );
  }

  Widget renderBody() {
    if (isLoadingProgress) {
      return ListLoader();
    }

    if (!isLoadingProgress && transactionData == null) {
      return Expanded(
          child: Center(
              child: new Text(Language()
                  .getString(Constants.NO_DATAFOUND_STRING, selectedLang))));
    }
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          sectionCard(
            "Ticket details",
            [
              infoRow("Ticket ID", transactionData!.buyerApp!.igmDao!.id!),
              infoRow("Created", transactionData!.buyerApp!.igmDao!.createdDt!),
              infoRow(
                  "Issue Type",
                  transactionData!
                      .buyerApp!.igmDao!.message!.issue!.issueType!),
              infoRow("Transaction Id", widget.transactionId),
            ],
          ),
          const SizedBox(height: 16),
          sectionCard(
            "Order Details",
            [
              infoRow("Order Id", transactionData!.buyerApp!.ondcOrder!.id!),
              infoRow("Provider Name", buDetails!.businessName!),
              infoRow("Provider Contact", buDetails!.mobileNumber!),
              const SizedBox(height: 10),
              for (int i = 0;
                  i < transactionData!.offerDetails!.productDetails!.length;
                  i++)
                renderProducts(
                    transactionData!.offerDetails!.productDetails![i]),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Expanded(
                child: Container(
                  margin: EdgeInsets.only(right: 5.0),
                  height: 30.0,
                  child: ElevatedButton(
                      style: CommonMethods.elevatedButtonStyle(),
                      onPressed: () {
                        showReplyActionDialog(null);
                      },
                      child: Text(
                        Language().getString(Constants.STR_REPLY, selectedLang),
                        style: TextStyle(color: Colors.white, fontSize: 12.0),
                      )),
                ),
              ),
              Expanded(
                child: Container(
                  margin: EdgeInsets.only(right: 2.0, left: 5.0),
                  height: 30.0,
                  child: ElevatedButton(
                      style: CommonMethods.elevatedButtonStyle(),
                      onPressed: () {
                        onResolve();
                      },
                      child: Text(
                        Language()
                            .getString(Constants.STR_RESOLVE, selectedLang),
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 12.0,
                        ),
                      )),
                ),
              ),
              Expanded(
                child: Container(
                  margin: EdgeInsets.only(right: 2.0),
                  height: 30.0,
                  child: ElevatedButton(
                      style: CommonMethods.elevatedButtonStyle(),
                      onPressed: () {
                        showSendResolutionActionDialog();
                      },
                      child: Text(
                        Language().getString(
                            Constants.STR_SEND_RESOLUTION, selectedLang),
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 12.0,
                        ),
                      )),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          sectionCard(
            "",
            [
              infoRowHeading(transactionData!
                          .buyerApp!.igmDao!.message!.issue!.description !=
                      null
                  ? transactionData!
                      .buyerApp!.igmDao!.message!.issue!.description!.shortDesc!
                  : ""),
              infoRow(
                  "long description",
                  transactionData!
                              .buyerApp!.igmDao!.message!.issue!.description !=
                          null
                      ? transactionData!.buyerApp!.igmDao!.message!.issue!
                          .description!.longDesc!
                      : ""),
              infoRow("additional description", ""),
              if (transactionData!
                          .buyerApp!.igmDao!.message!.issue!.description !=
                      null &&
                  transactionData!.buyerApp!.igmDao!.message!.issue!
                          .description!.additionalDesc !=
                      null &&
                  transactionData!.buyerApp!.igmDao!.message!.issue!
                          .description!.additionalDesc!.contentType ==
                      "image/png")
                CachedNetworkImage(
                  imageUrl: transactionData!.buyerApp!.igmDao!.message!.issue!
                      .description!.additionalDesc!.url!,
                  width: MediaQuery.of(context).size.width * 0.2,
                  height: MediaQuery.of(context).size.height * 0.1,
                  fit: BoxFit.cover,
                  errorWidget: (context, url, error) => Image.asset(
                    'assets/images/no_image.jpg',
                    width: MediaQuery.of(context).size.width * 0.2,
                    height: MediaQuery.of(context).size.height * 0.1,
                    fit: BoxFit.cover,
                  ),
                ),
              const SizedBox(height: 20),
              if (transactionData!
                      .buyerApp!.igmDao!.message!.issue!.complainantInfo !=
                  null)
                Column(
                  children: [
                    const Divider(),
                    Text(
                        "${transactionData!.buyerApp!.igmDao!.message!.issue!.complainantInfo!.person!.name!}",
                        style: TextStyle(fontWeight: FontWeight.bold)),
                    Text(
                        "${ transactionData!.buyerApp!.igmDao!.message!.issue!.complainantInfo!.contact!.phone!}"),
                    Text(
                        "${transactionData!.buyerApp!.igmDao!.message!.issue!.complainantInfo!.contact!.email!}"),
                  ],
                )
            ],
          ),
          if (transactionData!.buyerApp!.igmDao!.additionalReqs != null)
            for (var i = 0;
                i < transactionData!.buyerApp!.igmDao!.additionalReqs!.length;
                i++)
              renderAdditionalRequests(
                  transactionData!.buyerApp!.igmDao!.additionalReqs![i]),
        ],
      ),
    );
  }

  renderAdditionalRequests(AdditionalReqs additionalReq) {
    return Container(
      child: Column(
        children: [
          sectionCard(
            "",
            [
              infoRowHeading(additionalReq.message!.issue!.description != null
                  ? additionalReq.message!.issue!.description!.shortDesc!
                  : ""),
              infoRow(
                  "long description",
                  additionalReq.message!.issue!.description != null
                      ? additionalReq.message!.issue!.description!.longDesc!
                      : ""),
              if (additionalReq.message!.issue!.description != null &&
                  additionalReq.message!.issue!.description!.additionalDesc !=
                      null &&
                  additionalReq.message!.issue!.description!.additionalDesc!
                          .contentType ==
                      "image/png")
                CachedNetworkImage(
                  imageUrl: transactionData!.buyerApp!.igmDao!.message!.issue!
                      .description!.additionalDesc!.url!,
                  width: MediaQuery.of(context).size.width * 0.2,
                  height: MediaQuery.of(context).size.height * 0.1,
                  fit: BoxFit.cover,
                  errorWidget: (context, url, error) => Image.asset(
                    'assets/images/no_image.jpg',
                    width: MediaQuery.of(context).size.width * 0.2,
                    height: MediaQuery.of(context).size.height * 0.1,
                    fit: BoxFit.cover,
                  ),
                ),
              const SizedBox(height: 20),
              const Divider(),
              if (additionalReq.message!.issue!.complainantInfo != null)
                Column(
                  children: [
                    Text(
                        "${additionalReq.message!.issue!.complainantInfo!.person!.name!}",
                        style: TextStyle(fontWeight: FontWeight.bold)),
                    Text(
                        "${additionalReq.message!.issue!.complainantInfo!.contact!.phone!}"),
                    Text(
                        "${additionalReq.message!.issue!.complainantInfo!.contact!.email!}"),
                  ],
                ),
              Align(
                alignment: Alignment.centerRight,
                child: Container(
                  margin: EdgeInsets.only(right: 5.0),
                  height: 30.0,
                  child: ElevatedButton(
                      style: CommonMethods.elevatedButtonStyle(),
                      onPressed: () {
                        showReplyActionDialog(additionalReq.additionalReqId!);
                      },
                      child: Text(
                        Language().getString(Constants.STR_REPLY, selectedLang),
                        style: TextStyle(color: Colors.white, fontSize: 12.0),
                      )),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void showReplyActionDialog(String? additionalReqId) {
    showDialog(
      context: context,
      barrierColor: Colors.black54,
      barrierDismissible: false,
      builder: (context) {
        return StatefulBuilder(builder: (context, setState) {
          String? dialogAction = selectedAction;
          TextEditingController dialogController =
              TextEditingController(text: _replyMessageController.text);
          return AlertDialog(
            // shape:
            //     RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            contentPadding: const EdgeInsets.all(16),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Align(
                    alignment: Alignment.centerLeft,
                    child: const Text("Action",
                        style: TextStyle(fontWeight: FontWeight.bold))),
                const SizedBox(height: 8),
                DropdownButtonFormField<String>(
                  isExpanded: true,
                  initialValue: dialogAction ?? actionItems[0],
                  items: actionItems.map((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8)),
                    contentPadding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 12),
                  ),
                  onChanged: (value) {
                    dialogAction = value;
                  },
                ),
                const SizedBox(height: 20),
                Align(
                    alignment: Alignment.centerLeft,
                    child: const Text("Write your reply here",
                        style: TextStyle(fontWeight: FontWeight.bold))),
                const SizedBox(height: 8),
                TextFormField(
                  controller: dialogController,
                  maxLines: 4,
                  decoration: InputDecoration(
                    hintText: "Enter your message here",
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8)),
                  ),
                ),
              ],
            ),
            actions: [
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(Constants.APP_COLOR),
                ),
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: Text(
                    Language().getString(Constants.STR_CANCEL, selectedLang)),
              ),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(Constants.APP_COLOR),
                ),
                onPressed: () async {
                  if (dialogAction == 'Processing') {
                    await onReplyProcessing(dialogController.text,
                        additionalReqId != null ? additionalReqId : null);
                  } else if (dialogAction == "Need-More-Info") {
                    await onReplyNeedMoreInfo(dialogController.text,
                        additionalReqId != null ? additionalReqId : null);
                  }
                },
                child: Text(Language()
                    .getString(Constants.SUBMIT_STRING, selectedLang)),
              ),
            ],
          );
        });
      },
    );
  }

  int tempSelectedIndex = -1;
  int selectedProductIndex = -1;
  String selectedItem = "";
  Widget renderProductRadio(
      index, ProductDetails productDetails, StateSetter setState) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Radio(
        value: index,
        activeColor: Color(Constants.APP_COLOR),
        groupValue: selectedProductIndex,
        onChanged: (value) {
          setState(() {
            selectedItem = productDetails.id!;
            selectedProductIndex = value!;
          });
        },
      ),
      title: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: productDetails.productImage != null
                ? CachedNetworkImage(
                    imageUrl:
                        '${Constants.IAMGE_BUCKET_URL}${productDetails.productImage}',
                    width: 50.0,
                    height: 50.0,
                    fit: BoxFit.cover,
                    errorWidget: (context, url, error) => Image.asset(
                      'assets/images/no_image.jpg',
                      width: 50.0,
                      height: 50.0,
                      fit: BoxFit.cover,
                    ),
                  )
                : Image.asset(
                    'assets/images/no_image.jpg',
                    width: 50.0,
                    height: 50.0,
                    fit: BoxFit.cover,
                  ),
          ),
          const SizedBox(width: 10),
          Text(productDetails.productName ?? ""),
        ],
      ),
    );
  }

  void showSendResolutionActionDialog() {
    showDialog(
      context: context,
      barrierColor: Colors.black54,
      barrierDismissible: false,
      builder: (context) {
        return StatefulBuilder(builder: (context, setState) {
          return AlertDialog(
            contentPadding: const EdgeInsets.all(16),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Align(
                    alignment: Alignment.centerLeft,
                    child: const Text("Select Product",
                        style: TextStyle(fontWeight: FontWeight.bold))),
                const SizedBox(height: 10),
                for (int i = 0;
                    i < transactionData!.offerDetails!.productDetails!.length;
                    i++)
                  renderProductRadio(
                      i,
                      transactionData!.offerDetails!.productDetails![i],
                      setState),
                // Align(
                //     alignment: Alignment.centerLeft,
                //     child: const Text("Action",
                //         style: TextStyle(fontWeight: FontWeight.bold))),
                // const SizedBox(height: 8),

                const SizedBox(height: 20),
                Align(
                    alignment: Alignment.centerLeft,
                    child: const Text("Item Id",
                        style: TextStyle(fontWeight: FontWeight.bold))),
                // const SizedBox(height: 8),
                // TextFormField(
                //   controller: _resolutionMessageController,
                //   decoration: InputDecoration(
                //     hintText: "Item Id",
                //     border: OutlineInputBorder(
                //         borderRadius: BorderRadius.circular(8)),
                //   ),
                // ),
                SizedBox(
                  height: 10,
                ),
                Align(
                    alignment: Alignment.centerLeft,
                    child: const Text("Refund Amount",
                        style: TextStyle(fontWeight: FontWeight.bold))),
                TextField(
                  controller: _resolutionRefundAmountController,
                  decoration: InputDecoration(
                    hintText: "please enter refund amount",
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8)),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Align(
                    alignment: Alignment.centerLeft,
                    child: const Text("Description",
                        style: TextStyle(fontWeight: FontWeight.bold))),
                TextField(
                  controller: _resolutionDescriptionController,
                  maxLines: 4,
                  decoration: InputDecoration(
                    hintText: "enter description",
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8)),
                  ),
                ),
              ],
            ),
            actions: [
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(Constants.APP_COLOR),
                ),
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: Text(
                    Language().getString(Constants.STR_CANCEL, selectedLang)),
              ),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(Constants.APP_COLOR),
                ),
                onPressed: () async {
                  await onSendResolution(_resolutionRefundAmountController.text,
                      _resolutionDescriptionController.text);
                },
                child: Text(Language()
                    .getString(Constants.SUBMIT_STRING, selectedLang)),
              ),
            ],
          );
        });
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
      body: Stack(
        children: [
          SafeArea(
            child: Scaffold(
                backgroundColor: Colors.grey[100],
                appBar: AppBar(
                  centerTitle: true,
                  elevation: 0,
                  backgroundColor: Colors.transparent,
                  title: AppbarName(
                      title: Language()
                          .getString(Constants.ISSUE_GRIEVANCE, selectedLang),
                      buName: AppController.instance.getBuName),
                  iconTheme: IconThemeData(color: theme.colorScheme.primary),
                  actions: [
                    AppUtills.homeButton(context),
                  ],
                ),
                body: renderBody()),
          ),
          AppUtills.showLoadingView(
              context: context,
              message: Language().getString("Loading...", selectedLang),
              isLoading: isLoading),
        ],
      ),
    );
  }

  Widget sectionCard(String title, List<Widget> children) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (title.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Text(title,
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.bold)),
              ),
            ...children,
          ],
        ),
      ),
    );
  }

  Widget infoRowHeading(String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Text("$label: ", style: const TextStyle(fontWeight: FontWeight.bold)),
          Expanded(
              child: Text(
            value,
            style: TextStyle(fontWeight: FontWeight.bold),
          )),
        ],
      ),
    );
  }

  Widget infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Text("$label: ", style: const TextStyle(fontWeight: FontWeight.bold)),
          Expanded(child: Text(value)),
        ],
      ),
    );
  }
}
