import 'dart:io';

import 'package:flutx/flutx.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:vyaparlive/model/ondc_dao/ListOfInvoiceProvidersDAO.dart';
import 'package:vyaparlive/model/transaction/invoice_dao/InvoiceDataByIdDao.dart';
import 'package:vyaparlive/service/api_service/TransactionApiService.dart';
import 'package:vyaparlive/service/api_service/UserApiService.dart';
import 'package:vyaparlive/theme/app_theme.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:vyaparlive/utills/AppBarName.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:date_format/date_format.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:mime/mime.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyaparlive/components/AppController.dart';
import 'package:vyaparlive/components/AppUtills.dart';
import 'package:vyaparlive/components/CommonNavigation.dart';
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/NetworkStatus.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/components/TextView.dart';
import 'package:vyaparlive/components/TransactionDetailsView.dart';
import 'package:vyaparlive/components/common_methods.dart';
import 'package:vyaparlive/components/dialog.dart';
import 'package:vyaparlive/config/Language.dart';
import 'package:vyaparlive/model/BuBasicDataModel.dart';
import 'package:vyaparlive/model/TransactionsModel.dart';
import 'package:vyaparlive/model/UserModel.dart';
import 'package:vyaparlive/model/transaction/DeliveryDetailsModel.dart';
import 'package:vyaparlive/model/transaction/InvoiceDetailsModel.dart';
import 'package:vyaparlive/model/transaction/TrackingDetailsModel.dart';
import 'package:vyaparlive/utills/CommonButtonsView.dart';
import 'package:toast/toast.dart';
import '../../image_hero/ImageHeroView.dart';
import '../../model/ondc_dao/LogisticProvider.dart';
import '../../model/ondc_dao/OndcDao.dart';
import '../../model/ondc_dao/logistic_confirmation/LogisticOrdersDao.dart';
import '../../service/api_service/UploadImageApiService.dart';
import '../../utills/webview_page.dart';

class OndcDirectDeliveryPage extends StatefulWidget {
  OndcDirectDeliveryPage({this.transactionName, this.transactionId});
  final String? transactionName;
  final String? transactionId;
  @override
  _OndcDirectDeliveryPageState createState() => _OndcDirectDeliveryPageState();
}

class _OndcDirectDeliveryPageState extends State<OndcDirectDeliveryPage> {
  String? buName = "";
  List<String> deliveryStatusList = [
    "Pending",
    "Pickup",
    "Dispatched",
    "Out for delivery",
    "Completed",
    "Cancel"
  ];
  List<TransactionsModel> _transactionsList = [];
  List<InvoiceDetails> _invoiceList = [];
  InvoiceDetails? selectedInvoice;
  List<bool> isItemChecked = [];
  List<BuBasicDataModel>? _buList = [];
  BuBasicDataModel? buDropdownValue;
  List<UserModel> _usersList = [];
  UserModel? userDropdownvalue;
  DateFormat formatter = DateFormat("yyyy-MM-dd");
  String? deliveryDate = "";
  String? dropDownValue;
  String? dropDownDeliveryType;
  final _deliveryTypeNumberController = TextEditingController();
  final _deliveryStatusController = TextEditingController();
  TimeOfDay selectedTime = TimeOfDay(hour: 00, minute: 00);
  String? pickedTime = "";
  String? dispatchDateTime = "";
  String? dispatchDateTimeFormat = "";
  ScrollController? _scrollController;
  bool isLoadingProgress = true;
  String progressMessage = Constants.GETTING_DATA;
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  String? deliveryStatusDropdownValue;
  List<TrackingDetailsModel> _trackingList = [];
  final _grnNumnerController = new TextEditingController();
  InvoiceDetails? invoiceDeliveryData;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  List<Map> _namesData = [];
  late ThemeData theme;
  String? dispatchTime = '';
  String dispatchDate = '';
  File? imageFile;
  String imageRelativePath = '';
  String? showLogisticProvider = Constants.LOGISTIC_PROVIDER;
  String? showSelfDelivery; //Constants.SELF;
  LogisticProvider? logisticProvider;
  LogisticOrdersDao? logisticOrdersDao;
  OndcDao? ondcDao;
  List<LogisticProvider>? providersList = [];
  String selectedLspId = "";
  LogisticProvider? providerData;
  bool canShowReasonField = false;
  final _cancellationReasonController = new TextEditingController();

  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    this.getLoadLanguage();
    _scrollController = ScrollController();
    buName = AppController.instance.getBuName;
    _buList = AppController.instance.getBuList;
    _deliveryStatusController.text = "Pending";
    deliveryDate = formatter.format(DateTime.now());
    selectedTime = TimeOfDay.now();
    pickedTime = formatDate(
        DateTime(2019, 08, 1, selectedTime.hour, selectedTime.minute),
        [hh, ':', nn, " ", am]).toString();
    dispatchDateTime = formatter.format(DateTime.now()) + ' ' + pickedTime!;
    dispatchDateTimeFormat = AppUtills.convertDateTimeToUtc(
        selectedDate: "${formatter.format(DateTime.now())}",
        selectedTime: "$pickedTime");
    loadTransactionData();
  }

  getLoadLanguage() {
    _namesData = [
      {"name": Language().getString(Constants.NAME_STRING, selectedLang)},
      {"name": Language().getString(Constants.TXN_ID, selectedLang)},
      {"name": Language().getString(Constants.TXN_INITIATED_DATE, selectedLang)}
    ];
  }

  loadTransactionData() async {
    if (await NetworkStatus.getInternetStatus()) {
      setState(() => isLoadingProgress = true);
      final List<TransactionsModel> fetchTransactionData =
          await TransactionApiService.instance.getTransactionDataById(
              context: context,
              transactionId: widget.transactionId!,
              langError: Language().getString(Constants.ERROR, selectedLang),
              langOk: Language().getString(Constants.OKAY_STR, selectedLang));
      setState(() => isLoadingProgress = false);
      if (fetchTransactionData.length > 0) {
        setState(() {
          clearAllDeliveryData();
          _invoiceList.clear();
          isItemChecked.clear();
          _transactionsList.clear();
          _transactionsList.addAll(fetchTransactionData);
        });
        for (var element in _transactionsList[0].invoiceDetails!) {
          if (element.invoiceType != Constants.CTR3 &&
              element.packageDetails != null) {
            setState(() {
              _invoiceList.add(element);
              isItemChecked.add(false);
            });
          }
        }
      }

      if (_invoiceList.length > 0) {
        selectedInvoice = _invoiceList[0];
        isItemChecked[0] = true;
        Future.delayed(Duration(milliseconds: 500));
        serviceCallGetInvoiceDataById();
      }
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }

  @override
  void setState(VoidCallback fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  Widget build(BuildContext context) {
    ToastContext().init(context);
    return AppBackgroundView(
        body: Stack(
      children: [
        SafeArea(
          child: Scaffold(
              key: _scaffoldkey,
              backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
              appBar: AppBar(
                backgroundColor: Colors.transparent, //Color(Constants.APP_COLOR),
                centerTitle: true,
                elevation: 0,
                iconTheme: IconThemeData(color: theme.colorScheme.primary),
                title: AppbarName(
                    title: Language()
                        .getString(Constants.DIRECT_DELIVERY, selectedLang),
                    buName: "$buName"),
              ),
              bottomNavigationBar: this.handlingBottomView(),
              body: this.showDeliveryData()),
        ),
        AppUtills.showLoadingView(
            context: context,
            message: Language().getString(progressMessage, selectedLang),
            isLoading: isLoadingProgress),
      ],
    ));
  }

  Widget showInvoiceList(int i) {
    return Container(
      child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Container(
              child: Row(children: <Widget>[
                Container(
                    height: 30.0,
                    width: 30.0,
                    margin: EdgeInsets.only(left: 5.0),
                    child: Checkbox(
                        tristate: true,
                        activeColor: Colors.green,
                        value: isItemChecked[i],
                        onChanged: (bool? value) async {})),
                Container(
                    child: InkWell(
                  onTap: () {
                    CommonNavigation.navigationToInvoiceDesign(
                        context,
                        widget.transactionName,
                        widget.transactionId,
                        _transactionsList.length > 0
                            ? _transactionsList[0].transactionDate.toString()
                            : null,
                        _invoiceList[i].billNo.toString(),
                        _invoiceList[i].invoiceId);
                  },
                  child: Text(
                      Language().getString(Constants.INVOICE_NO, selectedLang) +
                          " : " +
                          _invoiceList[i].billNo.toString(),
                      style: TextStyle(
                          color: Colors.blue,
                          fontWeight: StyleView.fontMedium,
                          decoration: TextDecoration.underline)),
                )),
              ]),
            ),
            updateTickMark(i),
          ]),
    );
    // }
  }

  updateTickMark(int index) {
    if (_invoiceList[index].status == Constants.CANCELLED) {
      return Container(
        margin: EdgeInsets.symmetric(horizontal: 5.0),
        child: Text("${_invoiceList[index].status}",
            style: TextStyle(color: Colors.red)),
      );
    } else if (_invoiceList[index].orderTrackDetails != null) {
      return CommonMethods.invoiceUpdateTickMark(isUpdated: true);
    } else {
      return CommonMethods.invoiceUpdateTickMark(isUpdated: false);
    }
  }

  showCancellationReasonInputField() {
    return Container(
        child: Column(
      children: <Widget>[
        SizedBox(
            height: 1.0, child: Container(color: Color(Constants.GREY_COLOR))),
        buildCancellationReasonTextField(),
      ],
    ));
  }

  buildDeliveryStatusDropdown(String status) {
    return Container(
        child: Column(children: <Widget>[
      Container(
          child: Row(
        children: <Widget>[
          Expanded(
            child: Container(
                height: 50,
                color: Color(Constants.GREY_COLOR_LIGHT),
                child: Container(
                  padding: EdgeInsets.only(left: 10),
                  child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(Language().getString(status, selectedLang),
                          style: TextStyle(
                              fontSize: StyleView.FONT_SIZE_15,
                              fontFamily: StyleView.FONT_TITLE))),
                )),
          ),
          Expanded(
            flex: 2,
            child: Container(
                color: Colors.white70,
                padding: EdgeInsets.only(left: 5, right: 5),
                child: DropdownButton<String>(
                    value: deliveryStatusDropdownValue,
                    hint: new Text(Language()
                        .getString(Constants.SELECT_STATUS, selectedLang)),
                    isExpanded: true,
                    underline: SizedBox(),
                    onChanged: (String? data) {
                      setState(() {
                        deliveryStatusDropdownValue = data;
                        canShowReasonField = (data == "Cancel");
                      });
                    },
                    items: deliveryStatusList.map((String model) {
                      return new DropdownMenuItem<String>(
                        child: new Text(model),
                        value: model,
                      );
                    }).toList())),
          )
        ],
      ))
    ]));
  }

  String bottomNaviButton2Functionality() {
    if (showLogisticProvider == Constants.LOGISTIC_PROVIDER &&
        logisticProvider == null) {
      return "";
    }
    if (invoiceDeliveryData != null) {
      if (invoiceDeliveryData!.orderTrackDetails == null) {
        return Language().getString(Constants.CONFIRM, selectedLang);
      }
      return Language().getString(Constants.UPDATE_STRING, selectedLang);
    }

    return "";
  }

  handlingBottomView() {
    return Container(
        margin: EdgeInsets.only(left: 10.0, right: 10.0),
        width: MediaQuery.of(context).size.width,
        padding: EdgeInsets.only(bottom: 10),
        child: CommonButtonsView(
          context: context,
          b1Text: Language().getString(Constants.MENU, selectedLang),
          b2Text: bottomNaviButton2Functionality(),
          onb1Action: () {
            Navigator.of(context).pop();
          },
          onb2Action: () async {
            String errorMessage = "";
            if (showLogisticProvider != Constants.LOGISTIC_PROVIDER) {
              errorMessage = validateMandatoryFields();
            }

            if (errorMessage.isNotEmpty) {
              Dialogs.yesCancelDialog(
                  context,
                  Language().getString(Constants.ERROR, selectedLang),
                  Language().getString(errorMessage, selectedLang),
                  Language().getString(Constants.OKAY_STR, selectedLang),
                  "",
                  false);
            } else {
              if (await NetworkStatus.getInternetStatus()) {
                this.serviceCallDeliveryDetails();
              } else {
                AppUtills.showSnackBar(_scaffoldkey,
                    Language().getString(Constants.NO_INTERNET, selectedLang),
                    snackBarBgColor: Colors.black,
                    messageColor: Colors.white,
                    buttonColor: Colors.white);
              }
            }
          },
        ));
  }

  String validateMandatoryFields() {
    if (selectedInvoice == null) {
      return Constants.PLEASE_SELECT_INVOICE;
    } else if (buDropdownValue == null) {
      return Constants.SELECT_BUSINESS_UNIT;
    } else if (selectedInvoice == null) {
      return Constants.INVOICE_NOT_SELECTED;
    } else if (userDropdownvalue == null) {
      return Constants.PLEASE_SELECT_USER;
    } else if (dispatchDateTimeFormat!.isEmpty) {
      return Constants.PLEASE_SELECT_DISPATCH_DATE_TIME;
    } else if (deliveryStatusDropdownValue == null) {
      return Constants.PLEASE_SELECT_TRACKING_STATUS;
    } else {
      return "";
    }
  }

  bool renderInvoiceCheckFunctionaity() {
    bool isInvoiceSecected = false;
    for (int i = 0; i < isItemChecked.length; i++) {
      if (isItemChecked[i]) {
        isInvoiceSecected = true;
      }
    }
    return isInvoiceSecected;
  }

  buildTimeFormat() {
    return Container(
        padding: EdgeInsets.all(1),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Container(
                  color: Color(Constants.GREY_COLOR_LIGHT),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Container(
                      child: Text(
                          Language()
                              .getString(Constants.DELIVERY_TIME, selectedLang),
                          style: TextStyle(
                              fontSize: StyleView.FONT_SIZE_15,
                              fontFamily: StyleView.FONT_TITLE)),
                    ),
                  )),
            ),
            Expanded(
                flex: 2,
                child: Container(
                  color: Colors.white,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            elevation: 0,
                            backgroundColor: Colors.white,
                            shadowColor: Colors.transparent),
                        onPressed: () async {
                          pickedTime = await AppUtills.getSelectedTime(context);
                          setState(() {
                            pickedTime = pickedTime;
                          });
                        },
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Text(
                              pickedTime!,
                              style: TextStyle(color: Colors.black),
                            ),
                            Icon(Icons.access_time,
                                color: Color(Constants.APP_COLOR)),
                          ],
                        )),
                  ),
                ))
          ],
        ));
  }

  buildDispatchDateTime(
      {String title = Constants.DISPATCH_DELIVERY_DATE_TIME,
      Color bgColor = const Color(0xffd8d8d8)}) {
    return Container(
        child: Row(
      children: <Widget>[
        Expanded(
          child: Container(
              color: bgColor, //Color(Constants.GREY_COLOR_LIGHT),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  child: Text(Language().getString(title, selectedLang),
                      style: (title == "Pickup date time")
                          ? TextStyle(
                              fontSize: 14.0,
                              color: Colors.black,
                              fontWeight: StyleView.fontSemiBold)
                          : TextStyle(
                              fontSize: StyleView.FONT_SIZE_15,
                              fontFamily: StyleView.FONT_TITLE)),
                ),
              )),
        ),
        Expanded(
            flex: 2,
            child: Container(
              color: Colors.white,
              child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      elevation: 0,
                      backgroundColor: Colors.white,
                      shadowColor: Colors.transparent),
                  onPressed: () async {
                    dynamic time;
                    dynamic date = await AppUtills.getSelectedDate(context,
                        isShowIntialDate: true);
                    if (date != null) {
                      time = await AppUtills.getSelectedTime(context);
                    }
                    if (date == null || time == null) {
                      return;
                    }

                    setState(() {
                      dispatchDateTimeFormat = AppUtills.convertDateTimeToUtc(
                          selectedDate: "$date", selectedTime: "$time");
                      dispatchDateTime = '$date ' + '$time';
                    });
                  },
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Text(
                        (title == "Pickup date time")
                            ? ": " + dispatchDateTime!
                            : dispatchDateTime!,
                        style: TextStyle(color: Colors.black),
                      ),
                      Icon(Icons.access_time,
                          color: Color(Constants.APP_COLOR)),
                    ],
                  )),
            ))
      ],
    ));
  }

  handleSelectedInvoiceFunctionality() async {
    if (invoiceDeliveryData!.orderTrackDetails != null &&
        invoiceDeliveryData!.orderTrackDetails!.deliveryDetails != null &&
        invoiceDeliveryData!.orderTrackDetails!.deliveryDetails!.deliveryType ==
            Constants.KEY_SELF_DELIVERY) {
      ///bu drop doen
      if (invoiceDeliveryData!.orderTrackDetails!.assignedBu != null) {
        for (int i = 0; i < _buList!.length; i++) {
          if (_buList![i].businessName ==
              invoiceDeliveryData!.orderTrackDetails!.assignedBu) {
            setState(() => buDropdownValue = _buList![i]);
            break;
          }
        }

        if (await NetworkStatus.getInternetStatus()) {
          final List<UserModel> fetchUsersList = await UserApiService.instance
              .getUsersByBuId(context, buDropdownValue!.id!,
                  langError:
                      Language().getString(Constants.ERROR, selectedLang),
                  langOk:
                      Language().getString(Constants.OKAY_STR, selectedLang));
          setState(() => isLoadingProgress = false);
          if (fetchUsersList.length > 0) {
            setState(() => _usersList.addAll(fetchUsersList));
            if (invoiceDeliveryData!.orderTrackDetails!.assignedUser != null) {
              for (int i = 0; i < _usersList.length; i++) {
                if (_usersList[i].name ==
                    invoiceDeliveryData!.orderTrackDetails!.assignedUser) {
                  setState(() => userDropdownvalue = _usersList[i]);
                  break;
                }
              }
            } else {
              userDropdownvalue = null;
            }
          }
        } else {
          AppUtills.showSnackBar(_scaffoldkey,
              Language().getString(Constants.NO_INTERNET, selectedLang),
              snackBarBgColor: Colors.black,
              messageColor: Colors.white,
              buttonColor: Colors.white);
        }
      } else {
        buDropdownValue = null;
        userDropdownvalue = null;
      }

      /// delivery date
      if (invoiceDeliveryData!.orderTrackDetails!.deliveryDate != null) {
        setState(() {
          deliveryDate = invoiceDeliveryData!.orderTrackDetails!.deliveryDate;
        });
      } else {
        deliveryDate = formatter.format(DateTime.now());
      }

      /// Delivery time
      if (invoiceDeliveryData!.orderTrackDetails!.deliveryTime != null) {
        setState(() {
          pickedTime = invoiceDeliveryData!.orderTrackDetails!.deliveryTime;
        });
      } else {
        selectedTime = TimeOfDay.now();
        pickedTime = formatDate(
            DateTime(2019, 08, 1, selectedTime.hour, selectedTime.minute),
            [hh, ':', nn, " ", am]).toString();
      }

      if (invoiceDeliveryData!
          .orderTrackDetails!.dispatchDeliveryDateTime!.isNotEmpty) {
        dispatchDateTime =
            invoiceDeliveryData!.orderTrackDetails!.dispatchDeliveryDateTime!;
      } else {
        dispatchDateTime = formatter.format(DateTime.now()) +
            ' ' +
            formatDate(
                DateTime(2019, 08, 1, selectedTime.hour, selectedTime.minute),
                [hh, ':', nn, " ", am]).toString();
      }

      ///  Delivery details

      if (invoiceDeliveryData!.orderTrackDetails!.deliveryDetails != null &&
          invoiceDeliveryData!
                  .orderTrackDetails!.deliveryDetails!.deliveryType !=
              null) {
        setState(() {
          for (int i = 0; i < Constants.DELIVERY_TYPE.length; i++) {
            if (invoiceDeliveryData!
                    .orderTrackDetails!.deliveryDetails!.deliveryType ==
                Constants.DELIVERY_TYPE[i]) {
              dropDownDeliveryType = Constants.DELIVERY_TYPE[i];
            }
          }

          _deliveryTypeNumberController.text =
              invoiceDeliveryData!.orderTrackDetails!.deliveryDetails!.number!;
        });
      } else {
        dropDownDeliveryType = null;
      }

      /// Delivery Status Details

      for (int i = 0; i < deliveryStatusList.length; i++) {
        if (invoiceDeliveryData!.orderTrackDetails!.deliveryStatus ==
            deliveryStatusList[i]) {
          setState(() {
            deliveryStatusDropdownValue = deliveryStatusList[i];
            canShowReasonField = (deliveryStatusList[i] == "Cancel");
          });
        }
      }

      _grnNumnerController.text =
          invoiceDeliveryData!.orderTrackDetails!.grnNumber!;

      _cancellationReasonController.text = invoiceDeliveryData!
          .orderTrackDetails!.deliveryDetails!.cancelReason!;

      /// Tracking detaills
      if (invoiceDeliveryData!.orderTrackDetails!.deliveryTrackingList!.length >
          0) {
        for (int t = 0;
            t <
                invoiceDeliveryData!
                    .orderTrackDetails!.deliveryTrackingList!.length;
            t++) {
          setState(() {
            _trackingList.add(TrackingDetailsModel(
                docNumber: invoiceDeliveryData!
                    .orderTrackDetails!.deliveryTrackingList![t].docNumber,
                docType: invoiceDeliveryData!
                    .orderTrackDetails!.deliveryTrackingList![t].docType));
          });
        }
      } else {
        _trackingList.clear();
      }
    } else {
      this.clearAllDeliveryData();
    }
  }

  buildDropdownDeliveryType(StateSetter setState) {
    return Container(
      padding: EdgeInsets.all(1),
      decoration: AppUtills.boxDecoration(),
      child: Container(
        color: Colors.white70,
        padding: EdgeInsets.only(left: 5, right: 5),
        child: DropdownButton<String>(
          value: dropDownDeliveryType,
          hint: new Text(
              Language().getString(Constants.SELECT_TYPE, selectedLang)),
          isExpanded: true,
          underline: SizedBox(),
          onChanged: (String? data) {
            setState(() {
              dropDownDeliveryType = data;
            });
          },
          items: Constants.DELIVERY_TYPE.map((String model) {
            return new DropdownMenuItem<String>(
              child: new Text(model),
              value: model,
            );
          }).toList(),
        ),
      ),
    );
  }

  buildTableContent() {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 10.0),
      decoration: AppUtills.boxDecoration(),
      padding: EdgeInsets.only(left: 5),
      child: TextFormField(
        controller: _deliveryTypeNumberController,
        style: TextStyle(fontFamily: 'IndianRupee'),
        decoration: InputDecoration(
            border: InputBorder.none,
            hintText: Language().getString(Constants.NUMBER, selectedLang)),
      ),
    );
  }

  buildDateFormat(bool isForDelivery) {
    return Container(
        child: Row(
      children: <Widget>[
        Expanded(
          child: Container(
              color: Color(Constants.GREY_COLOR_LIGHT),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  child: Text(
                      Language()
                          .getString(Constants.DELIVERY_DATE, selectedLang),
                      style: TextStyle(
                          fontSize: StyleView.FONT_SIZE_15,
                          fontFamily: StyleView.FONT_TITLE)),
                ),
              )),
        ),
        Expanded(
            flex: 2,
            child: Container(
              color: Colors.white,
              child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      elevation: 0,
                      backgroundColor: Colors.white,
                      shadowColor: Colors.transparent),
                  onPressed: () async {
                    deliveryDate = await AppUtills.getSelectedDate(context,
                        isShowIntialDate: true);

                    setState(() {
                      deliveryDate = deliveryDate;
                    });
                  },
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Text(
                        deliveryDate!,
                        style: TextStyle(color: Colors.black),
                      ),
                      Image.asset('assets/images/calander.png', height: 30)
                    ],
                  )),
            ))
      ],
    ));
  }

  buildDropDownUser(String _title) {
    return Container(
        child: Column(children: <Widget>[
      Container(
          child: Row(
        children: <Widget>[
          Expanded(
            child: Container(
                height: 50,
                color: Color(Constants.GREY_COLOR_LIGHT),
                child: Container(
                  padding: EdgeInsets.only(left: 10),
                  child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(Language().getString(_title, selectedLang),
                          style: TextStyle(
                              fontSize: StyleView.FONT_SIZE_15,
                              fontFamily: StyleView.FONT_TITLE))),
                )),
          ),
          Expanded(
            flex: 2,
            child: Container(
                color: Colors.white70,
                padding: EdgeInsets.only(left: 5, right: 5),
                child: DropdownButton<UserModel>(
                    value: userDropdownvalue,
                    hint: new Text(
                        Language().getString(Constants.SELECT, selectedLang)),
                    isExpanded: true,
                    underline: SizedBox(),
                    onChanged: (UserModel? data) {
                      setState(() {
                        userDropdownvalue = data;
                      });
                    },
                    items: _usersList.map((UserModel model) {
                      return new DropdownMenuItem<UserModel>(
                        child: new Text(model.name!),
                        value: model,
                      );
                    }).toList())),
          )
        ],
      ))
    ]));
  }

  buildDropDownBu(String _title) {
    return Container(
        child: Column(children: <Widget>[
      Container(
          padding: EdgeInsets.all(1),
          child: Row(
            children: <Widget>[
              Expanded(
                child: Container(
                    height: 50,
                    color: Color(Constants.GREY_COLOR_LIGHT),
                    child: Container(
                      padding: EdgeInsets.only(left: 10),
                      child: Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                              Language().getString(_title, selectedLang),
                              style: TextStyle(
                                  fontSize: StyleView.FONT_SIZE_15,
                                  fontFamily: StyleView.FONT_TITLE))),
                    )),
              ),
              Expanded(
                flex: 2,
                child: Container(
                    color: Colors.white70,
                    padding: EdgeInsets.only(left: 5, right: 5),
                    child: DropdownButton<BuBasicDataModel>(
                        value: buDropdownValue,
                        hint: new Text(Language()
                            .getString(Constants.SELECT, selectedLang)),
                        isExpanded: true,
                        underline: SizedBox(),
                        onChanged: (BuBasicDataModel? data) async {
                          setState(() {
                            buDropdownValue = data;
                            userDropdownvalue = null;
                          });
                          final List<UserModel> fetchUsersList =
                              await UserApiService.instance.getUsersByBuId(
                                  context, buDropdownValue!.id!,
                                  langError: Language()
                                      .getString(Constants.ERROR, selectedLang),
                                  langOk: Language().getString(
                                      Constants.OKAY_STR, selectedLang));
                          setState(() => isLoadingProgress = false);
                          if (fetchUsersList.length > 0) {
                            setState(() => _usersList.addAll(fetchUsersList));
                          }
                        },
                        items: _buList!.map((BuBasicDataModel model) {
                          return new DropdownMenuItem<BuBasicDataModel>(
                            child: new Text(model.businessName!),
                            value: model,
                          );
                        }).toList())),
              )
            ],
          ))
    ]));
  }

  Future<void> serviceCallDeliveryDetails() async {
    setState(() => isLoadingProgress = true);
    List<Map<String, dynamic>> trackingArray = [];
    var trackingObj;

    if (_trackingList.length > 0) {
      for (int i = 0; i < _trackingList.length; i++) {
        trackingObj = {
          "delivery_type": _trackingList[i].docType,
          "value": _trackingList[i].docNumber
        };

        trackingArray.add(trackingObj);
      }
    }

    Map<String, dynamic> mapData;
    if (showLogisticProvider == Constants.LOGISTIC_PROVIDER) {
      mapData = {
        "assigned_to_bu": "",
        "assigned_to_user": "",
        "assigned_user_mobile_number": "",
        "assigned_to": "",
        "packing_date": "",
        "despatch_date": "",
        "delivery_date": deliveryDate,
        "delivery_time": pickedTime,
        "accptence_date": "",
        "delivery_status": "",
        "GRN_No": "",
        "delivery_details_arr": [],
        "delivery_details": {
          "delivery_type": Constants.KEY_LOGISTIC_PROVIDER,
          "value": "",
          "delivery_status": ""
        },
        "delivery_date_time": AppUtills.convertDateTimeToUtc(
            selectedDate: "$deliveryDate", selectedTime: "$pickedTime"),
        "dispatch_date_time_format": dispatchDateTimeFormat,
        "dispatch_date_time": dispatchDateTime,
        "delivery_image": ""
      };
    } else {
      mapData = {
        "assigned_to_bu":
            buDropdownValue != null ? buDropdownValue!.businessName : "",
        "assigned_to_user":
            userDropdownvalue != null ? userDropdownvalue!.name : "",
        "assigned_user_mobile_number":
            userDropdownvalue != null ? userDropdownvalue!.contact : "",
        "assigned_to": "",
        "packing_date": "",
        "despatch_date": "",
        "delivery_date": deliveryDate,
        "delivery_time": pickedTime,
        "accptence_date": "",
        "delivery_status": deliveryStatusDropdownValue != null
            ? deliveryStatusDropdownValue
            : "",
        "GRN_No": _grnNumnerController.text,
        "delivery_details_arr": trackingArray,
        "delivery_details": {
          "delivery_type": Constants.KEY_SELF_DELIVERY,
          "value": "",
          "delivery_status": "",
          "cancel_reason": _cancellationReasonController.text
        },
        "delivery_date_time": AppUtills.convertDateTimeToUtc(
            selectedDate: "$deliveryDate", selectedTime: "$pickedTime"),
        "dispatch_date_time_format": dispatchDateTimeFormat,
        "dispatch_date_time": dispatchDateTime,
        "delivery_image": imageRelativePath
      };
    }

    final bool isDeliveryComplete = await TransactionApiService.instance
        .updateDirectDeliveryDetails(
            context: context,
            transactionId: widget.transactionId!,
            invoiceId: selectedInvoice!.invoiceId!,
            invoiceNo: selectedInvoice!.billNo!,
            mapOrderTrack: mapData,
            langError: Language().getString(Constants.ERROR, selectedLang),
            langOk: Language().getString(Constants.OKAY_STR, selectedLang));
    setState(() => isLoadingProgress = false);
    if (isDeliveryComplete) {
      setState(() {
        selectedInvoice = null;
        invoiceDeliveryData = null;
        imageRelativePath = "";
      });
      loadTransactionData();
    }
  }

  Widget trackingDetailsView() {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 16.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            child: Text(
              Language().getString(Constants.TRACKING_DETAILS, selectedLang),
              style: TextStyle(
                  color: Colors.black, fontWeight: StyleView.fontSemiBold),
            ),
          ),
          (selectedInvoice!.status == Constants.CANCELLED ||
                  selectedInvoice!.stockReceivedStatus == 'received')
              ? SizedBox()
              : InkWell(
                  onTap: () {
                    this.trackingDetailsFieldsView(
                        false, -1, new TrackingDetailsModel());
                  },
                  child: Container(
                    margin: EdgeInsets.only(right: 5),
                    decoration:
                        BoxDecoration(shape: BoxShape.circle, boxShadow: [
                      BoxShadow(
                        color: Colors.grey,
                        blurRadius: 5.0,
                      ),
                    ]),
                    child: ClipOval(
                      child: Material(
                        color: Color(Constants.APP_COLOR),
                        child: SizedBox(
                            width: 25.0,
                            height: 25.0,
                            child: Icon(Icons.add,
                                size: 13.0, color: Colors.white)),
                      ),
                    ),
                  ),
                )
        ],
      ),
    );
  }

  trackingDetailsFieldsView(
      bool isUpdateItem, int index, TrackingDetailsModel _trackingModel) {
    if (isUpdateItem) {
      setState(() {
        dropDownDeliveryType = _trackingModel.docType;
        _deliveryTypeNumberController.text = _trackingModel.docNumber!;
      });
    } else {
      dropDownDeliveryType = null;
      _deliveryTypeNumberController.clear();
    }
    return showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) {
          return Container(
            margin: EdgeInsets.symmetric(horizontal: 20.0, vertical: 70.0),
            child: AppBackgroundView(
                body: Scaffold(
              backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
              body: StatefulBuilder(builder: (context, StateSetter setState) {
                return Container(
                  margin: EdgeInsets.symmetric(horizontal: 10.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: EdgeInsets.symmetric(vertical: 10.0),
                        child: Text(
                          Language()
                              .getString(Constants.DOCUMENT_TYPE, selectedLang),
                          style: TextStyle(
                              color: Color(Constants.APP_COLOR),
                              fontWeight: FontWeight.bold,
                              fontSize: 15.0),
                        ),
                      ),
                      buildDropdownDeliveryType(setState),
                      buildTableContent(),
                    ],
                  ),
                );
              }),
              bottomNavigationBar: Container(
                padding: EdgeInsets.only(left: 10, right: 10, bottom: 20),
                child: CommonButtonsView(
                  context: context,
                  b1Text:
                      Language().getString(Constants.STR_CANCEL, selectedLang),
                  b2Text:
                      Language().getString(Constants.CONTINUE, selectedLang),
                  onb1Action: () {
                    Navigator.of(context).pop();
                  },
                  onb2Action: () {
                    String errorMessage = validatingTrackingDetails();
                    if (errorMessage.isEmpty) {
                      Navigator.of(context).pop();

                      this.saveTrackingDetails(
                          isUpdateItem, index, _trackingModel);
                    } else {
                      Dialogs.yesCancelDialog(
                          context,
                          Language().getString(Constants.WARNING, selectedLang),
                          Language().getString(errorMessage, selectedLang),
                          Language()
                              .getString(Constants.OKAY_STR, selectedLang),
                          "",
                          false);
                    }
                  },
                ),
              ),
            )),
          );
        });
  }

  String validatingTrackingDetails() {
    if (dropDownDeliveryType == null) {
      return Constants.PLEASE_SELECT_DOCUMENT_TYPE;
    } else if (_deliveryTypeNumberController.text.isEmpty) {
      return Constants.PLEASE_SELECT_DOCUMENT_NUMBER;
    } else {
      return "";
    }
  }

  saveTrackingDetails(
      bool isUpdateItem, int index, TrackingDetailsModel _modelData) {
    if (isUpdateItem) {
      _trackingList[index] = TrackingDetailsModel(
          docNumber: _deliveryTypeNumberController.text,
          docType: dropDownDeliveryType);
    } else {
      _trackingList.add(TrackingDetailsModel(
          docType: dropDownDeliveryType,
          docNumber: _deliveryTypeNumberController.text));
    }

    setState(() {
      _trackingList.reversed;
    });
  }

  Widget createDynamicTrackingDetails() {
    return Container(
      child: ListView.separated(
        physics: NeverScrollableScrollPhysics(),
        separatorBuilder: (context, index) =>
            Divider(height: 5.0, color: Colors.transparent),
        shrinkWrap: true,
        itemBuilder: (context, index) {
          return Container(
              padding: EdgeInsets.all(8.0),
              decoration: BoxDecoration(
                  border: Border.all(color: Colors.black),
                  borderRadius: BorderRadius.circular(5.0)),
              child: Row(
                children: [
                  Expanded(
                      child: Container(
                    child: Column(
                      children: [
                        showSavedTrackingDetails(Constants.DOCUMENT_TYPE,
                            _trackingList[index].docType!),
                        showSavedTrackingDetails(Constants.DOCUMENT_NUMBER,
                            _trackingList[index].docNumber!)
                      ],
                    ),
                  )),
                  (selectedInvoice!.status == Constants.CANCELLED)
                      ? SizedBox()
                      : Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: InkWell(
                            onTap: () {
                              trackingDetailsFieldsView(
                                  true, index, _trackingList[index]);
                            },
                            child: Icon(
                              Icons.edit,
                              color: Color(Constants.APP_COLOR),
                            ),
                          ),
                        )
                ],
              ));
        },
        itemCount: _trackingList.length,
      ),
    );
  }

  Widget showSavedTrackingDetails(String title, String value) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 5.0),
      child: Row(
        children: [
          Expanded(
            child: Container(
              child: Text(
                Language().getString(title, selectedLang),
                style: TextStyle(
                  color: Colors.black,
                  fontWeight: StyleView.fontSemiBold,
                ),
              ),
            ),
          ),
          Expanded(
            child: Container(
              child: Text(
                " : " + value,
                style: TextStyle(
                    color: Colors.black, fontWeight: StyleView.fontRegular),
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget buildGrnNumberTextField() {
    return Container(
        child: Column(children: <Widget>[
      Container(
          child: Row(
        children: <Widget>[
          Expanded(
            child: Container(
                height: 50,
                color: Color(Constants.GREY_COLOR_LIGHT),
                child: Container(
                  padding: EdgeInsets.only(left: 10),
                  child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                          Language()
                              .getString(Constants.GRN_NUMBER, selectedLang),
                          style: TextStyle(
                              fontSize: StyleView.FONT_SIZE_15,
                              fontFamily: StyleView.FONT_TITLE))),
                )),
          ),
          Expanded(
              flex: 2,
              child: Container(
                color: Colors.white,
                padding: EdgeInsets.only(left: 5),
                child: TextFormField(
                  controller: _grnNumnerController,
                  style: TextStyle(fontFamily: 'IndianRupee'),
                  decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: Language()
                          .getString(Constants.GRN_NUMBER, selectedLang)),
                ),
              ))
        ],
      ))
    ]));
  }

  Widget buildCancellationReasonTextField() {
    return Container(
        child: Column(children: <Widget>[
      Container(
          child: Row(
        children: <Widget>[
          Expanded(
            child: Container(
                height: 50,
                color: Color(Constants.GREY_COLOR_LIGHT),
                child: Container(
                  padding: EdgeInsets.only(left: 10),
                  child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                          Language()
                              .getString(Constants.CANCEL_REASON, selectedLang),
                          style: TextStyle(
                              fontSize: StyleView.FONT_SIZE_15,
                              fontFamily: StyleView.FONT_TITLE))),
                )),
          ),
          Expanded(
              flex: 2,
              child: Container(
                color: Colors.white,
                padding: EdgeInsets.only(left: 5),
                child: TextFormField(
                  controller: _cancellationReasonController,
                  style: TextStyle(fontFamily: 'IndianRupee'),
                  decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: Language()
                          .getString(Constants.CANCEL_REASON, selectedLang)),
                ),
              ))
        ],
      ))
    ]));
  }

  showTransactionInfoCard() {
    return TransactionDetailsViewPage(
        transactionName: widget.transactionName,
        transactionId: widget.transactionId,
        transactionDate: _transactionsList.length > 0
            ? _transactionsList[0].transactionDate.toString()
            : null,
        namesData: _namesData);
  }

  Widget showGeneratedInvoiceList() {
    return Expanded(
      flex: 1,
      child: Container(
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(5.0),
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                  offset: Offset(0.0, 5.0), blurRadius: 5.0, color: Colors.grey)
            ]),
        height: MediaQuery.of(context).size.height * 0.10,
        child: Scrollbar(
          controller: _scrollController,
          thumbVisibility: true,
          child: ListView.builder(
            controller: _scrollController,
            shrinkWrap: true,
            itemBuilder: (context, i) {
              return this.showInvoiceList(i);
            },
            itemCount: _invoiceList.length,
          ),
        ),
      ),
    );
  }

  showDeliveryBasicDetails() {
    if (selectedInvoice!.status == Constants.CANCELLED ||
        selectedInvoice!.stockReceivedStatus == 'received') {
      return this.showCancelledInvoiceData(selectedInvoice!.orderTrackDetails);
    } else {
      return Container(
        decoration: BoxDecoration(
            border: Border.all(color: Colors.grey),
            borderRadius: BorderRadius.circular(5.0)),
        child: Column(
          children: [
            if (_buList != null)
              buildDropDownBu(Constants.BUSINESS_UNIT_STRING),
            SizedBox(
                height: 1.0,
                child: Container(color: Color(Constants.GREY_COLOR))),
            buildDropDownUser(Constants.CONTACT_PERSON),
            SizedBox(
                height: 1.0,
                child: Container(color: Color(Constants.GREY_COLOR))),
            buildDispatchDateTime(),
            SizedBox(
                height: 1.0,
                child: Container(color: Color(Constants.GREY_COLOR))),
            buildDateFormat(true),
            SizedBox(
                height: 1.0,
                child: Container(color: Color(Constants.GREY_COLOR))),
            buildTimeFormat(),
            SizedBox(
                height: 1.0,
                child: Container(color: Color(Constants.GREY_COLOR))),
            buildGrnNumberTextField(),
            SizedBox(
                height: 1.0,
                child: Container(color: Color(Constants.GREY_COLOR))),
            buildDeliveryStatusDropdown(Constants.STATUS_STRING),
            if (canShowReasonField) showCancellationReasonInputField()
          ],
        ),
      );
    }
  }

  showDeliveryData() {
    if (_invoiceList.length > 0 && selectedInvoice != null) {
      return Container(
        decoration: AppUtills.appBackgroundWithImage(),
        margin: EdgeInsets.all(10.0),
        child: Column(children: <Widget>[
          this.showTransactionInfoCard(),
          SizedBox(height: 10.0),
          Expanded(
            child: Column(
              children: [
                // showGeneratedInvoiceList(),
                Expanded(
                    flex: 3,
                    child: (_invoiceList.length > 0)
                        ? SingleChildScrollView(
                            child: Container(
                              padding: EdgeInsets.all(8.0),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(5.0),
                                  color: Colors.white,
                                  boxShadow: [
                                    BoxShadow(
                                        offset: Offset(0.0, 5.0),
                                        blurRadius: 5.0,
                                        color: Colors.grey)
                                  ]),
                              margin: EdgeInsets.symmetric(vertical: 10.0),
                              child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    showInvoiceList(0),
                                    SizedBox(height: 16),
                                    showRadioButtonsView(),
                                    SizedBox(height: 16),
                                    renderBodyView()
                                  ]),
                            ),
                          )
                        : Container(
                            child: Center(
                              child: Text(
                                Language().getString(
                                    Constants.NO_DATAFOUND_STRING,
                                    selectedLang),
                                style: TextStyle(
                                    fontWeight: StyleView.fontMedium,
                                    color: theme.colorScheme.primary),
                              ),
                            ),
                          )),
              ],
            ),
          )
        ]),
      );
    } else {
      return AppUtills.showTransactionStageMessage();
    }
  }

  SingleChildScrollView logisticOrderDetails() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Table(
        defaultVerticalAlignment: TableCellVerticalAlignment.middle,
        border: TableBorder.all(
            color: Colors.black, borderRadius: BorderRadius.circular(10)),
        defaultColumnWidth: FixedColumnWidth(110),
        children: [
          TableRow(children: [
            renderTableHeaders(
                Language().getString(Constants.INVOICE, selectedLang)),
            renderTableHeaders(
                Language().getString(Constants.BUYER_APP, selectedLang)),
            renderTableHeaders(Language()
                .getString(Constants.LOGISTIC_PROVIDER, selectedLang)),
            renderTableHeaders(
                Language().getString("Invoice products", selectedLang)),
          ]),

          TableRow(children: [
            renderTableValue(
                Constants.INVOICE + " #${selectedInvoice?.billNo}"),
            (_transactionsList.length > 0 &&
                    _transactionsList[0].buyerApp != null)
                ? renderTableValue(_transactionsList[0].buyerApp!.buyerApp!)
                : Container(),
            (logisticProvider != null && logisticProvider!.descriptor != null)
                ? renderTableValue(logisticProvider!.descriptor?.name)
                : Container(),
            (_transactionsList.length > 0 &&
                    _transactionsList[0].offerDetails != null)
                ? InkWell(
                    onTap: () {
                      CommonNavigation.navigationToInvoiceDesign(
                          context,
                          widget.transactionName,
                          widget.transactionId,
                          _transactionsList.length > 0
                              ? _transactionsList[0].transactionDate.toString()
                              : null,
                          selectedInvoice!.billNo.toString(),
                          selectedInvoice!.invoiceId);
                    },
                    child: Container(
                      alignment: Alignment.center,
                      padding: EdgeInsets.all(8.0),
                      child: Text(
                        "Total : " +
                            _transactionsList[0]
                                .offerDetails!
                                .productDetails!
                                .length
                                .toString(),
                        style: TextStyle(
                            decoration: TextDecoration.underline,
                            color: Colors.blue,
                            fontWeight: StyleView.fontRegular,
                            fontSize: 15.0),
                      ),
                    ),
                  )
                : Container()
          ]),
          // for (int i = 0; i < salesList.length; i++) this.renderTableRowText(i)
        ],
      ),
    );
  }

  Widget renderTableHeaders(String? headerText) {
    return Container(
      alignment: Alignment.center,
      padding: EdgeInsets.all(8.0),
      child: Text(
        Language().getString(headerText, selectedLang),
        style: TextStyle(
            color: Colors.black,
            fontWeight: StyleView.fontSemiBold,
            fontSize: 15.0),
      ),
    );
  }

  Widget renderTableValue(String? headerText) {
    return Container(
      alignment: Alignment.center,
      padding: EdgeInsets.all(8.0),
      child: Text(
        Language().getString(headerText, selectedLang),
        style: TextStyle(
            color: Colors.black,
            fontWeight: StyleView.fontRegular,
            fontSize: 14.0),
      ),
    );
  }

  clearAllDeliveryData() {
    buDropdownValue = null;
    userDropdownvalue = null;
    deliveryDate = formatter.format(DateTime.now());
    selectedTime = TimeOfDay.now();
    pickedTime = formatDate(
        DateTime(2019, 08, 1, selectedTime.hour, selectedTime.minute),
        [hh, ':', nn, " ", am]).toString();
    dropDownDeliveryType = null;
    deliveryStatusDropdownValue = null;
    _grnNumnerController.clear();
    _trackingList.clear();
    imageRelativePath = "";
  }

  showCancelledInvoiceData(OrderTrack? orderData) {
    if (orderData != null) {
      return Container(
          decoration: AppUtills.boxDecoration(),
          child: Column(
            children: [
              TextView(
                title: Language()
                    .getString(Constants.BUSINESS_UNIT_STRING, selectedLang),
                value: orderData.assignedBu,
              ),
              SizedBox(
                  height: 1.0,
                  child: Container(color: Color(Constants.GREY_COLOR))),
              TextView(
                title: Language()
                    .getString(Constants.CONTACT_PERSON, selectedLang),
                value: orderData.assignedUser,
              ),
              SizedBox(
                  height: 1.0,
                  child: Container(color: Color(Constants.GREY_COLOR))),
              TextView(
                title: Language()
                    .getString(Constants.EXPECTED_DELIVERY_DATE, selectedLang),
                value: orderData.deliveryDate,
              ),
              SizedBox(
                  height: 1.0,
                  child: Container(color: Color(Constants.GREY_COLOR))),
              TextView(
                title: Language()
                    .getString(Constants.EXPECTED_DELIVERY_TIME, selectedLang),
                value: orderData.deliveryTime,
              ),
              SizedBox(
                  height: 1.0,
                  child: Container(color: Color(Constants.GREY_COLOR))),
              TextView(
                title: Language().getString(Constants.GRN_NUMBER, selectedLang),
                value: orderData.grnNumber,
              ),
              SizedBox(
                  height: 1.0,
                  child: Container(color: Color(Constants.GREY_COLOR))),
              TextView(
                title:
                    Language().getString(Constants.STATUS_STRING, selectedLang),
                value: orderData.deliveryStatus,
              ),
            ],
          ));
    } else {
      return Container(
        child: Center(
          child: Text(
            Language().getString(Constants.NO_DATA_FOUND, selectedLang),
            style: TextStyle(
                color: Color(Constants.APP_COLOR), fontWeight: FontWeight.w700),
          ),
        ),
      );
    }
  }

  Widget fileAttachment() {
    return Column(
      children: [
        Container(
            padding: EdgeInsets.only(top: 18),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  Language().getString(Constants.ATTACH_FILE_OR_PHOTO, selectedLang),
                  style: TextStyle(
                      fontWeight: StyleView.fontSemiBold, color: Colors.black),
                ),
                SizedBox(
                    height: 25.0,
                    width: 25.0,
                    child: FloatingActionButton(
                      onPressed: () async {
                        if (kIsWeb) {
                          uploadWebAttachment();
                        } else {
                          openBottomSheet(context, pdfRead: true);
                        }
                      },
                      child: Icon(Icons.add, size: 18),
                      backgroundColor: Color(Constants.APP_COLOR),
                    ))
              ],
            )),
        Container(child: displayImageView()),
      ],
    );
  }

  Future<void> uploadWebAttachment() async {
    PlatformFile? selectedFile;
    selectedFile =
        await CommonMethods().getFileUpload(context, isForMultiFile: true);
    if (selectedFile != null) {
      Uint8List bytes = selectedFile.bytes!;
      setState(() {
        isLoadingProgress = true;
      });
      final String fetchRelativeImagePath = await UploadImageApiService.instance
          .fileUpload(
              imageData: bytes,
              fileName: "delivery_image_${selectedFile.name}",
              fileType: selectedFile.extension == 'pdf'
                  ? 'application/pdf'
                  : 'image/${selectedFile.extension}',
              location: widget.transactionId!);
      setState(() => isLoadingProgress = false);
      if (fetchRelativeImagePath.isNotEmpty) {
        imageRelativePath = fetchRelativeImagePath;
        Toast.show(
          Constants.FILE_UPLAODED,
          duration: Toast.lengthShort,
          gravity: Toast.bottom,
        );
      }
    }
  }

  openBottomSheet(BuildContext context, {bool pdfRead = false}) {
    return Dialogs.openBottomSheet(
        pdfRead: pdfRead,
        context: context,
        openCamera: (myPicture) async {
          updateProductImage(myPicture);
        },
        openGallery: (myPicture) async {
          updateProductImage(myPicture);
        });
  }

  Future<void> updateProductImage(var fileImage) async {
    Navigator.of(context).pop();
    if (fileImage != null) {
      setState(() {
        imageFile = fileImage;
        isLoadingProgress = true;
      });
      List<String> fileName = imageFile!.path.split('/');
      final String fetchRelativeImagePath = await UploadImageApiService.instance
          .fileUpload(
              imageData: imageFile,
              fileName: "delivery_image_${fileName.last}",
              fileType: lookupMimeType(imageFile!.path)!,
              location: widget.transactionId!);
      setState(() => isLoadingProgress = false);
      if (fetchRelativeImagePath.isNotEmpty) {
        imageRelativePath = fetchRelativeImagePath;
        Toast.show(
          Constants.FILE_UPLAODED,
          duration: Toast.lengthShort,
          gravity: Toast.bottom,
        );
      }
    }
  }

  Widget displayImageView() {
    if (imageRelativePath.isNotEmpty) {
      List<String?> path = imageRelativePath.split('/');
      return Column(
        children: [
          new SizedBox(height: 10),
          InkWell(
            onTap: () {
              if (kIsWeb) {
                AppUtills.launchURL(
                    '${Constants.IAMGE_BUCKET_URL}$imageRelativePath');
              } else {
                if (lookupMimeType(imageRelativePath) == 'application/pdf') {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => WebViewPage(
                              url:
                                  '${Constants.IAMGE_BUCKET_URL}$imageRelativePath',
                              screenName: "",
                              loadS3PDF: true)));
                } else {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => ImageHeroView(
                                fileUrl:
                                    '${Constants.IAMGE_BUCKET_URL}$imageRelativePath',
                                tagName: path[1],
                              )));
                }
              }
            },
            child: (lookupMimeType(imageRelativePath) == 'application/pdf')
                ? Text(
                    path[1].toString(),
                    style: TextStyle(
                        decoration: TextDecoration.underline,
                        color: Colors.black,
                        fontWeight: StyleView.fontRegular),
                  )
                : Container(
                    child: ClipRRect(
                    borderRadius: BorderRadius.all(Radius.circular(8)),
                    child: CachedNetworkImage(
                      imageUrl:
                          '${Constants.IAMGE_BUCKET_URL}$imageRelativePath',
                      height: MediaQuery.of(context).size.height * 0.2,
                      errorWidget: (context, url, error) => Icon(Icons.error),
                    ),
                  )),
          ),
          TextButton(
              onPressed: () {
                setState(() => isLoadingProgress = true);
                Future.delayed(Duration(seconds: 1));
                setState(() {
                  isLoadingProgress = false;
                  imageRelativePath = "";
                });
              },
              child: Text(
                Language().getString("Remove", selectedLang),
                style: TextStyle(
                    decoration: TextDecoration.underline,
                    color: Colors.red,
                    fontWeight: StyleView.fontMedium),
              ))
        ],
      );
    } else {
      return SizedBox();
    }
  }

  Widget showRadioButtonsView() {
    return Container(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Radio(
                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                value: Constants.LOGISTIC_PROVIDER,
                activeColor: Color(Constants.APP_COLOR),
                groupValue: showLogisticProvider,
                onChanged: (dynamic value) {
                  setState(() {
                    dispatchDateTime =
                        formatter.format(DateTime.now()) + ' ' + pickedTime!;
                    showSelfDelivery = null;
                    showLogisticProvider = value;
                  });
                },
              ),
              Text(
                  Language()
                      .getString(Constants.LOGISTIC_PROVIDER, selectedLang),
                  style: TextStyle(
                      color: Colors.black, fontWeight: StyleView.fontRegular)),
            ],
          ),
          Padding(
            padding: const EdgeInsets.only(right: 10.0),
            child: Row(
              children: [
                Radio(
                  materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  value: Constants.SELF_DELIVERY,
                  activeColor: Color(Constants.APP_COLOR),
                  groupValue: showSelfDelivery,
                  onChanged: (dynamic value) {
                          setState(() {
                            dispatchDateTime =
                                formatter.format(DateTime.now()) +
                                    ' ' +
                                    pickedTime!;
                            showLogisticProvider = null;
                            showSelfDelivery = value;
                          });
                        },
                ),
                Text(
                  Language().getString(Constants.SELF_DELIVERY, selectedLang),
                  style: TextStyle(
                      color: Colors.black, fontWeight: StyleView.fontRegular),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget logisticProviderRowWidget(
      {required String title, required String value}) {
    return Container(
      child: Row(
        children: <Widget>[
          Expanded(
            flex: 2,
            child: Container(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                      child: FxText.displayMedium("$title",
                          style: TextStyle(
                              fontSize: 14.0,
                              color: Colors.black,
                              fontWeight: StyleView.fontSemiBold))),
                )),
          ),
          Text(" : "),
          Expanded(
              flex: 3,
              child: Container(
                alignment: Alignment.centerLeft,
                child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: FxText.displayMedium(value,
                        style: TextStyle(
                            fontSize: 14.0,
                            color: Colors.black,
                            fontWeight: StyleView.fontMedium))),
              )),
        ],
      ),
    );
  }

  Widget logisticProviderWidget() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
            decoration: BoxDecoration(
                border: Border.all(color: Colors.black),
                borderRadius: BorderRadius.circular(5.0)),
            child: ExpansionTile(
              title: Text(
                  Language().getString(
                      Constants.DELIVERY_PARTNER_DETAILS, selectedLang),
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 15,
                      fontWeight: StyleView.fontMedium)),
              children: [
                SizedBox(
                    height: 1.0,
                    child: Container(color: Color(Constants.GREY_COLOR))),
                logisticProviderRowWidget(
                    title: Constants.NAME_STRING,
                    value: logisticProvider!.descriptor!.name!),
                if (logisticProvider!.categories!.length > 0 &&
                    logisticProvider!.categories![0].time != null)
                  Column(
                    children: [
                      SizedBox(
                          height: 1.0,
                          child: Container(color: Color(Constants.GREY_COLOR))),
                      logisticProviderRowWidget(
                          title: "Duration",
                          value:
                              logisticProvider!.categories![0].time!.duration!),
                      SizedBox(
                          height: 1.0,
                          child: Container(color: Color(Constants.GREY_COLOR))),
                      logisticProviderRowWidget(
                        title: "Type",
                        value: logisticProvider!.categories![0].id!,
                      ),
                    ],
                  ),
                if (logisticOrdersDao != null &&
                    logisticOrdersDao!.quoteDao != null &&
                    logisticOrdersDao!.quoteDao!.priceDao != null)
                  Column(
                    children: [
                      SizedBox(
                          height: 1.0,
                          child: Container(color: Color(Constants.GREY_COLOR))),
                      logisticProviderRowWidget(
                        title: "Charges",
                        value: AppController.instance.getBuCurrencySymbol +
                            " " +
                            logisticOrdersDao!.quoteDao!.priceDao!.value!
                                .toString(),
                      ),
                    ],
                  ),
                if (logisticProvider!.location!.length > 0 &&
                    logisticProvider!.location![0].addressDao != null)
                  Column(children: [
                    SizedBox(
                        height: 1.0,
                        child: Container(color: Color(Constants.GREY_COLOR))),
                    logisticProviderRowWidget(
                        title: Constants.ADDRESS,
                        value:
                            "${logisticProvider!.location![0].addressDao!.street!}, ${logisticProvider!.location![0].addressDao!.city!}, ${logisticProvider!.location![0].addressDao!.state!}, ${logisticProvider!.location![0].addressDao!.areaCode!}")
                  ]),
                if (logisticOrdersDao != null &&
                    logisticOrdersDao!.fullfillmentDao!.length > 0 &&
                    logisticOrdersDao!.fullfillmentDao![0].deliveryDetails !=
                        null &&
                    logisticOrdersDao!
                            .fullfillmentDao![0].deliveryDetails!.time !=
                        null &&
                    logisticOrdersDao!.fullfillmentDao![0].deliveryDetails!
                            .time!.rangeDao!.startTime !=
                        null)
                  Column(
                    children: [
                      SizedBox(
                          height: 1.0,
                          child: Container(color: Color(Constants.GREY_COLOR))),
                      logisticProviderRowWidget(
                        title: "Pickup date time",
                        value: AppUtills.getDateFormate(logisticOrdersDao!
                            .fullfillmentDao![0]
                            .deliveryDetails!
                            .time!
                            .rangeDao!
                            .startTime
                            .toString()),
                      ),
                    ],
                  ),
                if (logisticOrdersDao != null &&
                    logisticOrdersDao!.fullfillmentDao!.length > 0 &&
                    logisticOrdersDao!.fullfillmentDao![0].deliveryDetails !=
                        null &&
                    logisticOrdersDao!
                            .fullfillmentDao![0].deliveryDetails!.time !=
                        null &&
                    logisticOrdersDao!.fullfillmentDao![0].deliveryDetails!
                            .time!.rangeDao!.endTime !=
                        null)
                  Column(
                    children: [
                      SizedBox(
                          height: 1.0,
                          child: Container(color: Color(Constants.GREY_COLOR))),
                      logisticProviderRowWidget(
                        title: "Delivery date time",
                        value: AppUtills.getDateFormate(logisticOrdersDao!
                            .fullfillmentDao![0]
                            .deliveryDetails!
                            .time!
                            .rangeDao!
                            .endTime
                            .toString()),
                      ),
                    ],
                  ),
                if (logisticOrdersDao != null &&
                    logisticOrdersDao!.fullfillmentDao!.length > 0 &&
                    logisticOrdersDao!.fullfillmentDao![0].agentDao != null)
                  Column(
                    children: [
                      SizedBox(
                          height: 1.0,
                          child: Container(color: Color(Constants.GREY_COLOR))),
                      logisticProviderRowWidget(
                          title: "Agent name",
                          value: logisticOrdersDao!
                              .fullfillmentDao![0].agentDao!.name!),
                      SizedBox(
                          height: 1.0,
                          child: Container(color: Color(Constants.GREY_COLOR))),
                      InkWell(
                        onTap: () {
                          if (!kIsWeb) {
                            String phone = logisticOrdersDao!
                                .fullfillmentDao![0].agentDao!.phone!;
                            launchUrl(Uri.parse("tel:$phone"));
                          }
                        },
                        child: logisticProviderRowWidget(
                            title: "Agent mobile",
                            value: logisticOrdersDao!
                                .fullfillmentDao![0].agentDao!.phone!),
                      )
                    ],
                  ),
                if (logisticOrdersDao != null)
                  Column(
                    children: [
                      SizedBox(
                          height: 1.0,
                          child: Container(color: Color(Constants.GREY_COLOR))),
                      logisticProviderRowWidget(
                          title: Constants.STATUS_STRING,
                          value: logisticOrdersDao!.state!),
                    ],
                  ),
                // buildDispatchDateTime(
                //     title: "Pickup date time", bgColor: Colors.white)
              ],
            )),
        Container(
          padding: EdgeInsets.only(top: 16, right: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(Language().getString(Constants.ORDER_DETAILS, selectedLang),
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 15,
                      fontWeight: StyleView.fontSemiBold)),
              SizedBox(height: 16),
              logisticOrderDetails()
            ],
          ),
        )
      ],
    );
  }

  Widget renderBodyView() {
    if (showLogisticProvider == Constants.LOGISTIC_PROVIDER) {
      if (logisticProvider == null) {
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child:
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text(
              "Logistic provider\ndid not accepted order",
              style: TextStyle(
                  color: Colors.black,
                  fontWeight: StyleView.fontRegular,
                  fontSize: 14),
            ),
            InkWell(
              onTap: () async {
                if (ondcDao != null) {
                  setState(() => isLoadingProgress = true);
                  final List<ListOfInvoiceProvidersDAO> list =
                      await TransactionApiService.instance
                          .getInvoiceLogisticsProviderData(
                              context: context,
                              invoiceId: ondcDao!.transactionId!,
                              langError: Language()
                                  .getString(Constants.ERROR, selectedLang),
                              langOk: Language()
                                  .getString(Constants.OKAY_STR, selectedLang));
                  setState(() => isLoadingProgress = false);
                  if (list.length > 0) {
                    for (var j = 0; j < list.length; j++) {
                      for (var i = 0; i < list[j].providers!.length; i++) {
                        setState(() => providersList!.add(LogisticProvider(
                            id: list[j].providers![i].id,
                            lspId: list[j].id,
                            isChecked: false,
                            descriptor: list[j].providers![i].descriptor,
                            categories: list[j].providers![i].categories,
                            products: list[j].providers![i].products,
                            fullfillmentDao:
                                list[j].providers![i].fullfillmentDao)));
                      }
                    }
                    if (providersList != null && providersList!.length > 0) {
                      providersListPopup();
                    }
                  }
                }
              },
              child: Text(
                Language().getString(Constants.GET_NEW_PROVIDER, selectedLang),
                style: TextStyle(
                    color: Colors.blue,
                    decoration: TextDecoration.underline,
                    fontWeight: StyleView.fontMedium,
                    fontSize: 14),
              ),
            )
          ]),
        );
      } else {
        return logisticProviderWidget();
      }
    }

    if (showSelfDelivery == Constants.SELF_DELIVERY) {
      return Column(
        children: [
          showDeliveryBasicDetails(),
          trackingDetailsView(),
          (_trackingList.length > 0)
              ? createDynamicTrackingDetails()
              : SizedBox(),
          fileAttachment(),
          SizedBox(height: 16)
        ],
      );
    }

    return Container();
  }

  Future<void> serviceCallGetInvoiceDataById() async {
    setState(() {
      providersList!.clear();
      isLoadingProgress = true;
      providerData = null;
    });
    final InvoiceDataByIdDao? fetchInvoiceData =
        await TransactionApiService.instance.getInvoiceDataById_ondc(
            context: context,
            invoiceId: selectedInvoice!.invoiceId!,
            langError: Language().getString(Constants.ERROR, selectedLang),
            langOk: Language().getString(Constants.OKAY_STR, selectedLang));
    setState(() => isLoadingProgress = false);
    if (fetchInvoiceData != null && fetchInvoiceData.invoiceDetails != null) {
      invoiceDeliveryData = fetchInvoiceData.invoiceDetails;
      ondcDao = fetchInvoiceData.ondcDao;
      if (fetchInvoiceData.logisticProvider != null) {
        logisticProvider = fetchInvoiceData.logisticProvider;
      }
      if (fetchInvoiceData.logisticConfirmationDao != null &&
          fetchInvoiceData.logisticConfirmationDao!.messagesDao != null &&
          fetchInvoiceData.logisticConfirmationDao!.messagesDao!.ordersDao !=
              null) {
        logisticOrdersDao =
            fetchInvoiceData.logisticConfirmationDao!.messagesDao!.ordersDao;
      }
      handleSelectedInvoiceFunctionality();
    }
  }

  providersListPopup() {
    return showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) =>
            StatefulBuilder(builder: (context, StateSetter setState) {
              return Container(
                  margin:
                      EdgeInsets.symmetric(horizontal: 20.0, vertical: 20.0),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(10.0),
                    child: AppBackgroundView(
                      body: Scaffold(
                        backgroundColor: Colors.transparent,
                        bottomNavigationBar: Container(
                          margin: EdgeInsets.symmetric(horizontal: 5.0),
                          padding: EdgeInsets.only(bottom: 20, top: 10),
                          child: CommonButtonsView(
                              context: context,
                              b1Text: Language().getString(
                                  Constants.STR_CANCEL, selectedLang),
                              b2Text: Language()
                                  .getString(Constants.CONTINUE, selectedLang),
                              onb1Action: () {
                                setState(() {
                                  providerData = null;
                                });
                                Navigator.of(context).pop();
                              },
                              onb2Action: () async {
                                if (ondcDao != null) {
                                  bool isExist = false;
                                  int index = -1;
                                  for (var i = 0;
                                      i < providersList!.length;
                                      i++) {
                                    if (providersList![i].isChecked) {
                                      isExist = true;
                                      index = i;
                                    }
                                  }

                                  // providerData = providersList!.firstWhere(
                                  //     (element) => element.isChecked);
                                  // print(providerData);

                                  if (isExist) {
                                    Navigator.of(context).pop();
                                    final bool isLspUpdate =
                                        await TransactionApiService.instance
                                            .updateInvoiceLSPById(
                                                context: context,
                                                tnxId: ondcDao!.transactionId!,
                                                lspId: providersList![index]
                                                    .lspId!,
                                                lspProviderId:
                                                    providersList![index].id!,
                                                langError: Language().getString(
                                                    Constants.ERROR,
                                                    selectedLang),
                                                langOk: Language().getString(
                                                    Constants.OKAY_STR,
                                                    selectedLang));

                                    Future.delayed(Duration(seconds: 2));
                                    serviceCallGetInvoiceDataById();
                                  } else {
                                    await Dialogs.yesCancelDialog(
                                        context,
                                        Language().getString(
                                            Constants.ERROR, selectedLang),
                                        Language().getString(
                                            Constants.PLEASE_SELECT_PROVIDER,
                                            selectedLang),
                                        Language().getString(
                                            Constants.OKAY_STR, selectedLang),
                                        "",
                                        false);
                                  }
                                } else {
                                  print("invoice ondc getting null");
                                }
                              }),
                        ),
                        body: SingleChildScrollView(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                  margin: EdgeInsets.symmetric(
                                      vertical: 20.0, horizontal: 10.0),
                                  child: Text(
                                      Language().getString(
                                          Constants.AVAILABLE_PROVIDERS,
                                          selectedLang),
                                      style: TextStyle(
                                          color: Colors
                                              .black, //(Constants.APP_COLOR),
                                          fontSize: 15.0,
                                          fontWeight: FontWeight.bold))),
                              Container(
                                margin: EdgeInsets.symmetric(
                                  vertical: 10,
                                  horizontal: 10.0,
                                ),
                                child: Column(
                                  children: [
                                    for (int i = 0;
                                        i < providersList!.length;
                                        i++)
                                      showAvailableProviders(i, setState)
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ));
            }));
  }

  Widget showAvailableProviders(int index, StateSetter setState) {
    return Container(
      margin: EdgeInsets.only(top: (index == 0) ? 0 : 10),
      padding: EdgeInsets.all(8.0),
      decoration: BoxDecoration(
          border: Border.all(color: Colors.black),
          borderRadius: BorderRadius.circular(5)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
        InkWell(
          child: Icon(
            (providersList![index].isChecked)
                ? Icons.radio_button_checked
                : Icons.radio_button_unchecked,
            color:
                (providersList![index].isChecked) ? Colors.blue : Colors.black,
          ),
          onTap: () {
            for (int j = 0; j < providersList!.length; j++) {
              if (index == j) {
                providersList![j].isChecked = true;
              } else {
                providersList![j].isChecked = false;
              }
            }
            setState(() => providersList);
          },
        ),
        logisticProviderRowWidget(
            title: "id", value: providersList![index].id!),
        logisticProviderRowWidget(
            title: Constants.NAME_STRING,
            value: providersList![index].descriptor!.name!),
        if (providersList![index].categories!.length > 0 &&
            providersList![index].categories![0].time != null)
          Column(
            children: [
              SizedBox(
                  height: 1.0,
                  child: Container(color: Color(Constants.GREY_COLOR))),
              logisticProviderRowWidget(
                  title: "Duration",
                  value: providersList![index].categories![0].time!.duration!),
              SizedBox(
                  height: 1.0,
                  child: Container(color: Color(Constants.GREY_COLOR))),
              logisticProviderRowWidget(
                title: "Type",
                value: providersList![index].categories![0].id!,
              ),
            ],
          ),
        if (providersList![index].products!.length > 0)
          Column(
            children: [
              SizedBox(
                  height: 1.0,
                  child: Container(color: Color(Constants.GREY_COLOR))),
              logisticProviderRowWidget(
                title: "Charges",
                value: AppController.instance.getBuCurrencySymbol +
                    " " +
                    providersList![index].products![0].price!.value!.toString(),
              ),
            ],
          ),
      ]),
    );
  }
}
