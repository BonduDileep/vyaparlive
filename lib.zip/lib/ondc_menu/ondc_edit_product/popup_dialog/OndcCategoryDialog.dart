import 'dart:async';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/model/ProductCategoryDAO.dart';
import 'package:flutter/material.dart';
import '../../../components/Constants.dart';

enum OndcCategoryDialogActions { yes, no }

class OndcCategoryDialog {
  static Future<OndcCategoryDialogActions> showProductCategoryDialog(
      {required BuildContext context,
      required List<ProductCategoryDAO> categoryList,
      required Function(ProductCategoryDAO) onYesPress,
      required VoidCallback? onCacelPress}) async {
    final action = await showDialog(
      context: context,
      builder: (context) => Container(
        margin: EdgeInsets.symmetric(vertical: 15.0, horizontal: 10.0),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(5.0), color: Colors.white),
        child: Scaffold(
          backgroundColor: Colors.transparent,
          bottomNavigationBar: Container(
              height: 50.0,
              alignment: Alignment.centerRight,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: InkWell(
                    onTap: () => onCacelPress!(),
                    child: Text(Constants.CLOSE,
                        style: TextStyle(
                            color: Color(Constants.APP_COLOR),
                            fontSize: 15.0,
                            fontWeight: FontWeight.bold))),
              )),
          body: Container(
              child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                Expanded(
                  child: Container(
                    margin: EdgeInsets.only(top: 10.0),
                    child: ListView.builder(
                      shrinkWrap: true,
                      itemBuilder: (context, index) {
                        return InkWell(
                            onTap: () {
                              onYesPress(categoryList[index]);
                            },
                            child: OndcCategoryDialog.bindCategoryItems(
                                categoryList[index]));
                      },
                      itemCount: categoryList.length,
                    ),
                  ),
                )
              ],
            ),
          )),
        ),
      ),
    );

    return (action != null
        ? action as FutureOr<OndcCategoryDialogActions>
        : OndcCategoryDialogActions.no);
  }

  static Widget bindCategoryItems(ProductCategoryDAO name) {
    return Container(
        margin: EdgeInsets.only(bottom: 8.0, left: 8.0, right: 8.0),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(5.0),
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                  offset: Offset(0.0, 1.0), blurRadius: 2.5, color: Colors.grey)
            ]),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(children: [
            Expanded(
                child: Container(
              child: Text(
                "${name.name}",
                textAlign: TextAlign.start,
                style: TextStyle(
                    fontSize: 15.0,
                    fontWeight: StyleView.fontMedium,
                    color: Colors.black),
              ),
            ))
          ]),
        ));
  }
}
