
import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/model/transaction/InvoiceDetailsModel.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../components/AppController.dart';
import '../components/AppUtills.dart';
import '../components/DateFilterUtil.dart';
import '../components/MyDrawer.dart';
import '../components/NetworkStatus.dart';
import '../components/common_methods.dart';
import '../config/Language.dart';
import '../model/TransactionsModel.dart';
import '../page_transition/PageTransition.dart';
import '../service/api_service/TransactionApiService.dart';
import '../theme/app_theme.dart';
import '../utills/AppBarName.dart';
import 'OndcTransactionSteps.dart';

class OndcInvoiceView extends StatefulWidget {
  const OndcInvoiceView({super.key});

  @override
  State<OndcInvoiceView> createState() => _OndcInvoiceViewState();
}

class _OndcInvoiceViewState extends State<OndcInvoiceView> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey<ScaffoldState>();
  late ThemeData theme;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  String? buName = "";
  late TextEditingController fromDateController = new TextEditingController();
  late TextEditingController toDateController = new TextEditingController();
  late TextEditingController _searchController = new TextEditingController();
  DateFormat formatter = DateFormat("yyyy-MM-dd");
  DateTime mnthStartDate =
      DateTime.utc(DateTime.now().year, DateTime.now().month, 1);
  late bool isShowFloatButton = false;
  bool isLoadingProgress = false;
  List<InvoiceDetails> invoiceList = [];
  List<TransactionsModel> transactionData = [];
  String progressMessage = "";
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    buName = AppController.instance.getBuName;
    fromDateController.text = formatter.format(mnthStartDate);
    toDateController.text = formatter.format(DateTime.now());
    Future.delayed(Duration(seconds: 500))
        .then((value) => isLoadingProgress = true);
    fetchInvoiceData();
  }

  renderOrdersTableView() {
    if (invoiceList.length == 0) {
      return Container(
        child: Text(
          Language().getString(Constants.NO_DATAFOUND_STRING, selectedLang),
          style:
              TextStyle(color: Colors.black, fontWeight: StyleView.fontMedium),
        ),
      );
    }
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Table(
        defaultVerticalAlignment: TableCellVerticalAlignment.middle,
        border: TableBorder.all(
            color: Color(Constants.APP_COLOR),
            borderRadius: BorderRadius.circular(5)),
        defaultColumnWidth: FixedColumnWidth(100),
        children: [
          TableRow(children: [
            renderTableHeaders(
                Language().getString(Constants.DATE, selectedLang)),
            renderTableHeaders(
                Language().getString(Constants.SOLD_TO, selectedLang)),
            renderTableHeaders(
                Language().getString(Constants.BUYER_APP, selectedLang)),
            renderTableHeaders(
                Language().getString(Constants.INVOICE, selectedLang)),
            renderTableHeaders(
                Language().getString(Constants.INVOICE_AMOUNT, selectedLang)),
            renderTableHeaders(
                Language().getString(Constants.PACKING_STATUS, selectedLang)),
            renderTableHeaders(
                Language().getString(Constants.DELIVERY_STATUS, selectedLang)),
            renderTableHeaders(
                Language().getString(Constants.PAYMENT_STATUS, selectedLang)),
            renderTableHeaders(
                Language().getString(Constants.ORDER_DETAILS, selectedLang)),
          ]),
          for (int i = 0; i < invoiceList.length; i++) renderTableRowText(i)
        ],
      ),
    );
  }

  Widget renderTableData(String value) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          child: Text("$value",
              style: TextStyle(
                  fontSize: 13,
                  color: Colors.black,
                  fontWeight: StyleView.fontMedium)),
        ),
      ),
    );
  }

  TableRow renderTableRowText(int index) {
    String? name = "";
    if (transactionData[index].seller!.id == AppController.instance.getMyBuId) {
      name = transactionData[index].buyer!.name;
    }

    return TableRow(
      children: [
        renderTableData(AppUtills.getDateFormate(
            invoiceList[index].invoiceDate.toString())),
        renderTableData(name!),
        renderTableData(transactionData[index].buyerApp != null
            ? transactionData[index].buyerApp!.buyerApp!
            : ""),
        InkWell(
          child: Text(
              Language().getString(Constants.INVOICE, selectedLang) +
                  "  #" +
                  invoiceList[index].billNo.toString(),
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: Colors.black,
                  fontWeight: StyleView.fontMedium,
                  decoration: TextDecoration.underline)),
          onTap: () {
            Navigator.push(
                    context,
                    PageTransition(
                        context: context,
                        page: OndcTransactionSteps(
                            transactionId: transactionData[index].id!)))
                .then((value) => fetchInvoiceData());
          },
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
            child: Text(
                AppController.instance.getBuCurrencySymbol +
                    " " +
                    CommonMethods.getCurrencyValues(
                        invoiceList[index].finalTotal),
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontSize: 13.0,
                    color: Colors.black,
                    fontWeight: StyleView.fontMedium)),
          ),
        ),
        renderTableData(invoiceList[index].packageDetails == null
            ? "packing pending"
            : "packing completed"),
        renderTableData(invoiceList[index].orderTrackDetails == null
            ? "delivery pending"
            : "delivery completed"),
        renderTableData("payment pending"),
        InkWell(
          child: Icon(Icons.open_in_new, size: 20),
          onTap: () {
            Navigator.push(
                    context,
                    PageTransition(
                        context: context,
                        page: OndcTransactionSteps(
                            transactionId: transactionData[index].id!)))
                .then((value) => fetchInvoiceData());
          },
        )
      ],
    );
  }

  Widget renderTableHeaders(String? headerText) {
    return Container(
      alignment: Alignment.center,
      padding: EdgeInsets.all(8.0),
      child: Text(
        Language().getString(headerText, selectedLang),
        style: TextStyle(
            color: Colors.black,
            fontWeight: StyleView.fontSemiBold,
            fontSize: 15.0),
      ),
    );
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  void setState(VoidCallback fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
      body: Stack(
        children: [
          SafeArea(
            child: Scaffold(
              key: _scaffoldkey,
              backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
              appBar: AppBar(
                elevation: 0,
                iconTheme: IconThemeData(color: theme.colorScheme.primary),
                backgroundColor: Colors.transparent,
                title: AppbarName(
                    title: Language()
                        .getString(Constants.INVOICE_LIST, selectedLang),
                    buName: "$buName"),
                centerTitle: true,
              ),
              floatingActionButton: (isShowFloatButton)
                  ? FloatingActionButton(
                      backgroundColor: theme.colorScheme.primary,
                      onPressed: () {
                        CommonMethods.hideKeyboard(context);
                        setState(() {
                          isShowFloatButton = false;
                          fromDateController.text =
                              formatter.format(mnthStartDate);
                          toDateController.text =
                              formatter.format(DateTime.now());
                          _searchController.clear();
                        });
                        fetchInvoiceData();
                      },
                      child: Text(
                        Language()
                            .getString(Constants.CLEAR_FILTERS, selectedLang),
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white, fontSize: 11.0),
                      ))
                  : null,
              drawer: MyDrawer(),
              body: Container(
                padding: EdgeInsets.all(10.0),
                child: Column(
                  children: [
                    Container(
                      height: 50.0,
                      child: Padding(
                        padding: const EdgeInsets.only(left: 10),
                        child: Card(
                          elevation: 2.5,
                          shadowColor: theme.colorScheme.primary,
                          shape: new RoundedRectangleBorder(
                              borderRadius: new BorderRadius.circular(15),
                              side: new BorderSide(
                                  color: theme.colorScheme.primary,
                                  strokeAlign: 0.01)),
                          child: Row(
                            children: <Widget>[
                              Expanded(
                                child: Container(
                                  padding: EdgeInsets.only(left: 15),
                                  child: TextFormField(
                                    controller: _searchController,
                                    onChanged: (value) {
                                      print(value);
                                      if (value.isEmpty) {
                                        Future.delayed(Duration(seconds: 500))
                                            .then((value) => setState(() {
                                                  isLoadingProgress = true;
                                                }));
                                        fetchInvoiceData();
                                      } else {
                                        Future.delayed(Duration(seconds: 500))
                                            .then((value) => setState(() {
                                                  isLoadingProgress = false;
                                                }));
                                        fetchInvoiceData();
                                      }
                                    },
                                    style: TextStyle(
                                        fontWeight: StyleView.fontSemiBold),
                                    decoration: InputDecoration(
                                        contentPadding:
                                            EdgeInsets.only(bottom: 10),
                                        border: InputBorder.none,
                                        hintText: Language().getString(
                                            Constants.SEARCH_BY_NAME,
                                            selectedLang),
                                        hintStyle: TextStyle(
                                            fontSize: 13.0,
                                            fontWeight: StyleView.fontSemiBold)),
                                  ),
                                ),
                              ),
                              (_searchController.text.length > 0)
                                  ? Container(
                                      color: Colors.white,
                                      child: IconButton(
                                          icon: Icon(
                                            Icons.close,
                                            color: Colors.red,
                                            size: 20.0,
                                          ),
                                          onPressed: () {
                                            CommonMethods.hideKeyboard(context);
                                            _searchController.clear();
                                            fetchInvoiceData();
                                          }),
                                    )
                                  : Container(),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding:
                          const EdgeInsets.only(left: 0.0, top: 10, bottom: 16),
                      child: DateFilterUtill(
                        fromDate: "",
                        toDate: "",
                        fromDateController: fromDateController,
                        toDateController: toDateController,
                        onFromDateSelected: (value) {
                          setState(() => fromDateController.text = value);
                        },
                        onToDateSelected: (value) {
                          setState(() => toDateController.text = value);
                        },
                        isShowSearchButton: true,
                        onSearchParms: () {
                          setState(() {
                            isLoadingProgress = true;
                            isShowFloatButton = true;
                          });
                          fetchInvoiceData();
                        },
                      ),
                    ),
                    (invoiceList.length > 0)
                        ? Expanded(
                            child: Padding(
                                padding: const EdgeInsets.only(left: 0),
                                child: SingleChildScrollView(
                                  scrollDirection: Axis.vertical,
                                  child: renderOrdersTableView(),
                                )),
                          )
                        : Expanded(
                            child: Center(
                            child: Text(
                              Constants.NO_DATAFOUND_STRING,
                              style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: StyleView.fontMedium),
                            ),
                          )),
                  ],
                ),
              ),
            ),
          ),
          AppUtills.showLoadingView(
              context: context,
              message: Language().getString(progressMessage, selectedLang),
              isLoading: isLoadingProgress),
        ],
      ),
    );
  }

  Future<void> fetchInvoiceData() async {
    if (await NetworkStatus.getInternetStatus()) {
      Map<String, dynamic> mapData = {
        "DateFrom": fromDateController.text,
        "DateTo": toDateController.text,
        "status": "",
        "name": _searchController.text.trim(),
        "transaction_type": "",
        "offline": false
      };
      setState(() {
        invoiceList.clear();
        transactionData.clear();
      });
      List<TransactionsModel> fetchData = await TransactionApiService.instance
          .getAllTransactions(
              context: context,
              buId: AppController.instance.getMyBuId,
              mapData: mapData,
              ondcTransaction: true,
              langError: Language().getString(Constants.ERROR, selectedLang),
              langOk: Language().getString(Constants.OKAY_STR, selectedLang));
      setState(() => isLoadingProgress = false);
      if (fetchData.length > 0) {
        setState(() {
          transactionData.addAll(fetchData);
          for (var element in fetchData) {
            if (element.invoiceDetails!.length > 0) {
              invoiceList.addAll(element.invoiceDetails!);
            }
          }
        });
      }
    } else {
      AppUtills.showSnackBar(_scaffoldkey,
          Language().getString(Constants.NO_INTERNET, selectedLang),
          snackBarBgColor: Colors.black,
          messageColor: Colors.white,
          buttonColor: Colors.white);
    }
  }
}
