import 'package:vyaparlive/components/Constants.dart';
import 'package:vyaparlive/components/StyleView.dart';
import 'package:vyaparlive/utills/AppBackgroundView.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../components/AppController.dart';
import '../components/MyDrawer.dart';
import '../config/Language.dart';
import '../theme/app_theme.dart';
import '../utills/AppBarName.dart';

class OndcProfileView extends StatefulWidget {
  const OndcProfileView({super.key});

  @override
  State<OndcProfileView> createState() => _OndcProfileViewState();
}

class _OndcProfileViewState extends State<OndcProfileView> {
  late ThemeData theme;
  String? selectedLang = AppController.instance.getSelectedlanguage; //'en';
  late SharedPreferences sharedPreferences;
  String? buName = "";
  @override
  void initState() {
    super.initState();
    theme = AppTheme.vyaparTheme;
    buName = AppController.instance.getBuName;
  }

  @override
  void setState(VoidCallback fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBackgroundView(
      body: Stack(
        children: [
          SafeArea(
            child: Scaffold(
              backgroundColor: Color(Constants.APP_BACKGROUND_COLOR),
              appBar: AppBar(
                elevation: 0,
                iconTheme: IconThemeData(color: theme.colorScheme.primary),
                backgroundColor: Colors.transparent,
                title: AppbarName(
                    title: Language()
                        .getString(Constants.ONDC_PROFILE, selectedLang),
                    buName: "$buName"),
                centerTitle: true,
              ),
              drawer: MyDrawer(),
              body: Column(
                children: [
                  Expanded(
                      child: Center(
                          child: Text(
                    Constants.NO_DATAFOUND_STRING,
                    style: TextStyle(
                        color: Colors.black, fontWeight: StyleView.fontMedium),
                  ))),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
