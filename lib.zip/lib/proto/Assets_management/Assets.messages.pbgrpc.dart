///
//  Generated code. Do not modify.
//  source: proto/assets/Assets.messages.proto
//

// ignore_for_file: annotate_overrides,camel_case_types,unnecessary_const,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name,return_of_invalid_type,unnecessary_this,prefer_final_fields

import 'dart:async' as $async;

import 'dart:core' as $core;

import 'package:grpc/service_api.dart' as $grpc;
import 'Assets.messages.pb.dart' as $0;
export 'Assets.messages.pb.dart';

class AssetsServiceClient extends $grpc.Client {
  static final _$getAll = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/AssetsService/getAll',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$findById = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/AssetsService/findById',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$findByBuId =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/AssetsService/findByBuId',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$remove = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/AssetsService/remove',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$createAssets =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/AssetsService/createAssets',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$update = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/AssetsService/update',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$createAssetGroup =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/AssetsService/createAssetGroup',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$updateAssetGroup =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/AssetsService/updateAssetGroup',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$deleteAssetGroup =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/AssetsService/deleteAssetGroup',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$findAssetGroupById =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/AssetsService/findAssetGroupById',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$findAssetGroupByBuId =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/AssetsService/findAssetGroupByBuId',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$findLiabilityListByBuId =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/AssetsService/findLiabilityListByBuId',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$findScrapListByBuId =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/AssetsService/findScrapListByBuId',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));

  AssetsServiceClient($grpc.ClientChannel channel, {$grpc.CallOptions? options})
      : super(channel, options: options);

  $grpc.ResponseFuture<$0.GrpcMessage> getAll($0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    final call = $createCall(_$getAll, $async.Stream.fromIterable([request]),
        options: options);
    return $grpc.ResponseFuture(call);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findById($0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    final call = $createCall(_$findById, $async.Stream.fromIterable([request]),
        options: options);
    return $grpc.ResponseFuture(call);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findByBuId($0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    final call = $createCall(
        _$findByBuId, $async.Stream.fromIterable([request]),
        options: options);
    return $grpc.ResponseFuture(call);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> remove($0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    final call = $createCall(_$remove, $async.Stream.fromIterable([request]),
        options: options);
    return $grpc.ResponseFuture(call);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createAssets($0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    final call = $createCall(
        _$createAssets, $async.Stream.fromIterable([request]),
        options: options);
    return $grpc.ResponseFuture(call);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> update($0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    final call = $createCall(_$update, $async.Stream.fromIterable([request]),
        options: options);
    return $grpc.ResponseFuture(call);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createAssetGroup($0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    final call = $createCall(
        _$createAssetGroup, $async.Stream.fromIterable([request]),
        options: options);
    return $grpc.ResponseFuture(call);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateAssetGroup($0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    final call = $createCall(
        _$updateAssetGroup, $async.Stream.fromIterable([request]),
        options: options);
    return $grpc.ResponseFuture(call);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> deleteAssetGroup($0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    final call = $createCall(
        _$deleteAssetGroup, $async.Stream.fromIterable([request]),
        options: options);
    return $grpc.ResponseFuture(call);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findAssetGroupById(
      $0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    final call = $createCall(
        _$findAssetGroupById, $async.Stream.fromIterable([request]),
        options: options);
    return $grpc.ResponseFuture(call);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findAssetGroupByBuId(
      $0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    final call = $createCall(
        _$findAssetGroupByBuId, $async.Stream.fromIterable([request]),
        options: options);
    return $grpc.ResponseFuture(call);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findLiabilityListByBuId(
      $0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    final call = $createCall(
        _$findLiabilityListByBuId, $async.Stream.fromIterable([request]),
        options: options);
    return $grpc.ResponseFuture(call);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findScrapListByBuId(
      $0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    final call = $createCall(
        _$findScrapListByBuId, $async.Stream.fromIterable([request]),
        options: options);
    return $grpc.ResponseFuture(call);
  }
}

abstract class AssetsServiceBase extends $grpc.Service {
  $core.String get $name => 'AssetsService';

  AssetsServiceBase() {
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getAll',
        getAll_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findById',
        findById_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findByBuId',
        findByBuId_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'remove',
        remove_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createAssets',
        createAssets_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'update',
        update_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createAssetGroup',
        createAssetGroup_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateAssetGroup',
        updateAssetGroup_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'deleteAssetGroup',
        deleteAssetGroup_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findAssetGroupById',
        findAssetGroupById_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findAssetGroupByBuId',
        findAssetGroupByBuId_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findLiabilityListByBuId',
        findLiabilityListByBuId_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findScrapListByBuId',
        findScrapListByBuId_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
  }

  $async.Future<$0.GrpcMessage> getAll_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return getAll(call, await request);
  }

  $async.Future<$0.GrpcMessage> findById_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return findById(call, await request);
  }

  $async.Future<$0.GrpcMessage> findByBuId_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return findByBuId(call, await request);
  }

  $async.Future<$0.GrpcMessage> remove_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return remove(call, await request);
  }

  $async.Future<$0.GrpcMessage> createAssets_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return createAssets(call, await request);
  }

  $async.Future<$0.GrpcMessage> update_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return update(call, await request);
  }

  $async.Future<$0.GrpcMessage> createAssetGroup_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return createAssetGroup(call, await request);
  }

  $async.Future<$0.GrpcMessage> updateAssetGroup_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return updateAssetGroup(call, await request);
  }

  $async.Future<$0.GrpcMessage> deleteAssetGroup_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return deleteAssetGroup(call, await request);
  }

  $async.Future<$0.GrpcMessage> findAssetGroupById_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return findAssetGroupById(call, await request);
  }

  $async.Future<$0.GrpcMessage> findAssetGroupByBuId_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return findAssetGroupByBuId(call, await request);
  }

  $async.Future<$0.GrpcMessage> findLiabilityListByBuId_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return findLiabilityListByBuId(call, await request);
  }

  $async.Future<$0.GrpcMessage> findScrapListByBuId_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return findScrapListByBuId(call, await request);
  }

  $async.Future<$0.GrpcMessage> getAll(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> findById(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> findByBuId(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> remove(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> createAssets(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> update(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> createAssetGroup(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> updateAssetGroup(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> deleteAssetGroup(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> findAssetGroupById(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> findAssetGroupByBuId(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> findLiabilityListByBuId(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> findScrapListByBuId(
      $grpc.ServiceCall call, $0.GrpcMessage request);
}
