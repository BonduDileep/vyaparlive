///
//  Generated code. Do not modify.
//  source: proto/assets/Assets.messages.proto
//

// ignore_for_file: annotate_overrides,camel_case_types,unnecessary_const,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name,return_of_invalid_type,unnecessary_this,prefer_final_fields

const GrpcMessage$json = const {
  '1': 'GrpcMessage',
  '2': const [
    const {'1': 'data', '3': 1, '4': 1, '5': 9, '10': 'data'},
    const {'1': 'Authorization', '3': 2, '4': 1, '5': 9, '10': 'Authorization'},
  ],
};

