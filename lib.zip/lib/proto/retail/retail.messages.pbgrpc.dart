// This is a generated file - do not edit.
//
// Generated from proto/retail/retail.messages.proto.

// @dart = 3.3

// ignore_for_file: annotate_overrides, camel_case_types, comment_references
// ignore_for_file: constant_identifier_names
// ignore_for_file: curly_braces_in_flow_control_structures
// ignore_for_file: deprecated_member_use_from_same_package, library_prefixes
// ignore_for_file: non_constant_identifier_names, prefer_relative_imports

import 'dart:async' as $async;
import 'dart:core' as $core;

import 'package:grpc/service_api.dart' as $grpc;
import 'package:protobuf/protobuf.dart' as $pb;

import 'retail.messages.pb.dart' as $0;

export 'retail.messages.pb.dart';

@$pb.GrpcServiceName('RetailerService')
class RetailerServiceClient extends $grpc.Client {
  /// The hostname for this service.
  static const $core.String defaultHost = '';

  /// OAuth scopes needed for the client.
  static const $core.List<$core.String> oauthScopes = [
    '',
  ];

  RetailerServiceClient(super.channel, {super.options, super.interceptors});

  $grpc.ResponseFuture<$0.GrpcMessage> getAll(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getAll, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findById(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findById, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findByBuId(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findByBuId, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> remove(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$remove, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> create(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$create, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> update(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$update, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getAllInvoices(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getAllInvoices, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findInvoiceById(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findInvoiceById, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> removeInvoice(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$removeInvoice, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createInvoice(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$createInvoice, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateInvoice(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateInvoice, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findInvoicesByBuId(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findInvoicesByBuId, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> viewInvoiceWeb(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$viewInvoiceWeb, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findBuyerSalesReports(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findBuyerSalesReports, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findSellerSalesReports(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findSellerSalesReports, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findBuyerSalesReports_v2(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findBuyerSalesReports_v2, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findSellerSalesReports_v2(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findSellerSalesReports_v2, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createNewInvoice(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$createNewInvoice, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> makePayment(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$makePayment, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getInvoices(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getInvoices, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> sendRetailOTP(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$sendRetailOTP, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getPendingInvoiceAmount(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getPendingInvoiceAmount, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getTotalInvoices(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getTotalInvoices, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> cancelInvoice(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$cancelInvoice, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getPayments(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getPayments, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> generateQrCode(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$generateQrCode, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findSellOrdersByProductId(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findSellOrdersByProductId, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> checkRetailerUser(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$checkRetailerUser, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> retail_list_v1(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$retail_list_v1, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getAllRetailInvoiceList(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getAllRetailInvoiceList, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> sendPaymentRemainder(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$sendPaymentRemainder, request, options: options);
  }

  // method descriptors

  static final _$getAll = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/RetailerService/getAll',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      $0.GrpcMessage.fromBuffer);
  static final _$findById = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/RetailerService/findById',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      $0.GrpcMessage.fromBuffer);
  static final _$findByBuId =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/RetailerService/findByBuId',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$remove = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/RetailerService/remove',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      $0.GrpcMessage.fromBuffer);
  static final _$create = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/RetailerService/create',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      $0.GrpcMessage.fromBuffer);
  static final _$update = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/RetailerService/update',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      $0.GrpcMessage.fromBuffer);
  static final _$getAllInvoices =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/RetailerService/getAllInvoices',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findInvoiceById =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/RetailerService/findInvoiceById',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$removeInvoice =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/RetailerService/removeInvoice',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$createInvoice =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/RetailerService/createInvoice',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateInvoice =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/RetailerService/updateInvoice',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findInvoicesByBuId =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/RetailerService/findInvoicesByBuId',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$viewInvoiceWeb =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/RetailerService/viewInvoiceWeb',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findBuyerSalesReports =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/RetailerService/findBuyerSalesReports',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findSellerSalesReports =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/RetailerService/findSellerSalesReports',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findBuyerSalesReports_v2 =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/RetailerService/findBuyerSalesReports_v2',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findSellerSalesReports_v2 =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/RetailerService/findSellerSalesReports_v2',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$createNewInvoice =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/RetailerService/createNewInvoice',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$makePayment =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/RetailerService/makePayment',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getInvoices =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/RetailerService/getInvoices',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$sendRetailOTP =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/RetailerService/sendRetailOTP',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getPendingInvoiceAmount =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/RetailerService/getPendingInvoiceAmount',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getTotalInvoices =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/RetailerService/getTotalInvoices',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$cancelInvoice =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/RetailerService/cancelInvoice',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getPayments =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/RetailerService/getPayments',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$generateQrCode =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/RetailerService/generateQrCode',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findSellOrdersByProductId =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/RetailerService/findSellOrdersByProductId',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$checkRetailerUser =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/RetailerService/checkRetailerUser',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$retail_list_v1 =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/RetailerService/retail_list_v1',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getAllRetailInvoiceList =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/RetailerService/getAllRetailInvoiceList',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$sendPaymentRemainder =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/RetailerService/sendPaymentRemainder',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
}

@$pb.GrpcServiceName('RetailerService')
abstract class RetailerServiceBase extends $grpc.Service {
  $core.String get $name => 'RetailerService';

  RetailerServiceBase() {
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getAll',
        getAll_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findById',
        findById_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findByBuId',
        findByBuId_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'remove',
        remove_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'create',
        create_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'update',
        update_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getAllInvoices',
        getAllInvoices_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findInvoiceById',
        findInvoiceById_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'removeInvoice',
        removeInvoice_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createInvoice',
        createInvoice_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateInvoice',
        updateInvoice_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findInvoicesByBuId',
        findInvoicesByBuId_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'viewInvoiceWeb',
        viewInvoiceWeb_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findBuyerSalesReports',
        findBuyerSalesReports_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findSellerSalesReports',
        findSellerSalesReports_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findBuyerSalesReports_v2',
        findBuyerSalesReports_v2_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findSellerSalesReports_v2',
        findSellerSalesReports_v2_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createNewInvoice',
        createNewInvoice_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'makePayment',
        makePayment_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getInvoices',
        getInvoices_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'sendRetailOTP',
        sendRetailOTP_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getPendingInvoiceAmount',
        getPendingInvoiceAmount_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getTotalInvoices',
        getTotalInvoices_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'cancelInvoice',
        cancelInvoice_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getPayments',
        getPayments_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'generateQrCode',
        generateQrCode_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findSellOrdersByProductId',
        findSellOrdersByProductId_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'checkRetailerUser',
        checkRetailerUser_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'retail_list_v1',
        retail_list_v1_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getAllRetailInvoiceList',
        getAllRetailInvoiceList_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'sendPaymentRemainder',
        sendPaymentRemainder_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
  }

  $async.Future<$0.GrpcMessage> getAll_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getAll($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getAll(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findById_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findById($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findById(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findByBuId_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findByBuId($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findByBuId(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> remove_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return remove($call, await $request);
  }

  $async.Future<$0.GrpcMessage> remove(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> create_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return create($call, await $request);
  }

  $async.Future<$0.GrpcMessage> create(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> update_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return update($call, await $request);
  }

  $async.Future<$0.GrpcMessage> update(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getAllInvoices_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getAllInvoices($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getAllInvoices(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findInvoiceById_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findInvoiceById($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findInvoiceById(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> removeInvoice_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return removeInvoice($call, await $request);
  }

  $async.Future<$0.GrpcMessage> removeInvoice(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> createInvoice_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return createInvoice($call, await $request);
  }

  $async.Future<$0.GrpcMessage> createInvoice(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateInvoice_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateInvoice($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateInvoice(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findInvoicesByBuId_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findInvoicesByBuId($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findInvoicesByBuId(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> viewInvoiceWeb_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return viewInvoiceWeb($call, await $request);
  }

  $async.Future<$0.GrpcMessage> viewInvoiceWeb(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findBuyerSalesReports_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findBuyerSalesReports($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findBuyerSalesReports(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findSellerSalesReports_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findSellerSalesReports($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findSellerSalesReports(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findBuyerSalesReports_v2_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findBuyerSalesReports_v2($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findBuyerSalesReports_v2(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findSellerSalesReports_v2_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findSellerSalesReports_v2($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findSellerSalesReports_v2(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> createNewInvoice_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return createNewInvoice($call, await $request);
  }

  $async.Future<$0.GrpcMessage> createNewInvoice(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> makePayment_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return makePayment($call, await $request);
  }

  $async.Future<$0.GrpcMessage> makePayment(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getInvoices_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getInvoices($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getInvoices(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> sendRetailOTP_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return sendRetailOTP($call, await $request);
  }

  $async.Future<$0.GrpcMessage> sendRetailOTP(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getPendingInvoiceAmount_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getPendingInvoiceAmount($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getPendingInvoiceAmount(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getTotalInvoices_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getTotalInvoices($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getTotalInvoices(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> cancelInvoice_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return cancelInvoice($call, await $request);
  }

  $async.Future<$0.GrpcMessage> cancelInvoice(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getPayments_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getPayments($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getPayments(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> generateQrCode_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return generateQrCode($call, await $request);
  }

  $async.Future<$0.GrpcMessage> generateQrCode(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findSellOrdersByProductId_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findSellOrdersByProductId($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findSellOrdersByProductId(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> checkRetailerUser_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return checkRetailerUser($call, await $request);
  }

  $async.Future<$0.GrpcMessage> checkRetailerUser(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> retail_list_v1_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return retail_list_v1($call, await $request);
  }

  $async.Future<$0.GrpcMessage> retail_list_v1(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getAllRetailInvoiceList_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getAllRetailInvoiceList($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getAllRetailInvoiceList(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> sendPaymentRemainder_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return sendPaymentRemainder($call, await $request);
  }

  $async.Future<$0.GrpcMessage> sendPaymentRemainder(
      $grpc.ServiceCall call, $0.GrpcMessage request);
}
