// This is a generated file - do not edit.
//
// Generated from proto/product_proto/Products.messages.proto.

// @dart = 3.3

// ignore_for_file: annotate_overrides, camel_case_types, comment_references
// ignore_for_file: constant_identifier_names
// ignore_for_file: curly_braces_in_flow_control_structures
// ignore_for_file: deprecated_member_use_from_same_package, library_prefixes
// ignore_for_file: non_constant_identifier_names, prefer_relative_imports
// ignore_for_file: unused_import

import 'dart:convert' as $convert;
import 'dart:core' as $core;
import 'dart:typed_data' as $typed_data;

@$core.Deprecated('Use grpcMessageDescriptor instead')
const GrpcMessage$json = {
  '1': 'GrpcMessage',
  '2': [
    {'1': 'data', '3': 1, '4': 1, '5': 9, '10': 'data'},
    {'1': 'Authorization', '3': 2, '4': 1, '5': 9, '10': 'Authorization'},
  ],
};

/// Descriptor for `GrpcMessage`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List grpcMessageDescriptor = $convert.base64Decode(
    'CgtHcnBjTWVzc2FnZRISCgRkYXRhGAEgASgJUgRkYXRhEiQKDUF1dGhvcml6YXRpb24YAiABKA'
    'lSDUF1dGhvcml6YXRpb24=');

@$core.Deprecated('Use uploadImageRequestDescriptor instead')
const UploadImageRequest$json = {
  '1': 'UploadImageRequest',
  '2': [
    {
      '1': 'info',
      '3': 1,
      '4': 1,
      '5': 11,
      '6': '.ImageInfo',
      '9': 0,
      '10': 'info'
    },
    {'1': 'chunk_data', '3': 2, '4': 1, '5': 12, '9': 0, '10': 'chunkData'},
  ],
  '8': [
    {'1': 'data'},
  ],
};

/// Descriptor for `UploadImageRequest`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List uploadImageRequestDescriptor = $convert.base64Decode(
    'ChJVcGxvYWRJbWFnZVJlcXVlc3QSIAoEaW5mbxgBIAEoCzIKLkltYWdlSW5mb0gAUgRpbmZvEh'
    '8KCmNodW5rX2RhdGEYAiABKAxIAFIJY2h1bmtEYXRhQgYKBGRhdGE=');

@$core.Deprecated('Use imageInfoDescriptor instead')
const ImageInfo$json = {
  '1': 'ImageInfo',
  '2': [
    {'1': 'image_id', '3': 1, '4': 1, '5': 9, '10': 'imageId'},
    {'1': 'image_type', '3': 2, '4': 1, '5': 9, '10': 'imageType'},
  ],
};

/// Descriptor for `ImageInfo`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List imageInfoDescriptor = $convert.base64Decode(
    'CglJbWFnZUluZm8SGQoIaW1hZ2VfaWQYASABKAlSB2ltYWdlSWQSHQoKaW1hZ2VfdHlwZRgCIA'
    'EoCVIJaW1hZ2VUeXBl');

@$core.Deprecated('Use uploadImageResponseDescriptor instead')
const UploadImageResponse$json = {
  '1': 'UploadImageResponse',
  '2': [
    {'1': 'id', '3': 1, '4': 1, '5': 9, '10': 'id'},
    {'1': 'size', '3': 2, '4': 1, '5': 13, '10': 'size'},
  ],
};

/// Descriptor for `UploadImageResponse`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List uploadImageResponseDescriptor = $convert.base64Decode(
    'ChNVcGxvYWRJbWFnZVJlc3BvbnNlEg4KAmlkGAEgASgJUgJpZBISCgRzaXplGAIgASgNUgRzaX'
    'pl');
