// This is a generated file - do not edit.
//
// Generated from proto/product_proto/Products.messages.proto.

// @dart = 3.3

// ignore_for_file: annotate_overrides, camel_case_types, comment_references
// ignore_for_file: constant_identifier_names
// ignore_for_file: curly_braces_in_flow_control_structures
// ignore_for_file: deprecated_member_use_from_same_package, library_prefixes
// ignore_for_file: non_constant_identifier_names, prefer_relative_imports

import 'dart:async' as $async;
import 'dart:core' as $core;

import 'package:grpc/service_api.dart' as $grpc;
import 'package:protobuf/protobuf.dart' as $pb;

import 'Products.messages.pb.dart' as $0;

export 'Products.messages.pb.dart';

@$pb.GrpcServiceName('ProductService')
class ProductServiceClient extends $grpc.Client {
  /// The hostname for this service.
  static const $core.String defaultHost = '';

  /// OAuth scopes needed for the client.
  static const $core.List<$core.String> oauthScopes = [
    '',
  ];

  ProductServiceClient(super.channel, {super.options, super.interceptors});

  $grpc.ResponseFuture<$0.GrpcMessage> getAll(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getAll, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findProductList(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findProductList, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findList(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findList, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getById(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getById, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> addProductsInConnectionsBu(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$addProductsInConnectionsBu, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateSuppliers(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateSuppliers, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateOffers(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateOffers, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateQuantity(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateQuantity, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> remove(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$remove, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> create(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$create, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> update(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$update, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getBuProductImage(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getBuProductImage, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findProductList_v2(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findProductList_v2, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findProductList_v4(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findProductList_v4, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findProductsBuyReportsList(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findProductsBuyReportsList, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findProductsSellReportsList(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findProductsSellReportsList, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createIssue(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$createIssue, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateIssue(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateIssue, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findIssueById(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findIssueById, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getIssuesByBuId(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getIssuesByBuId, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getIssuesReportsByBuId(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getIssuesReportsByBuId, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findIssueByBuidAndId(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findIssueByBuidAndId, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getProductLogReports(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getProductLogReports, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateBatchPricingOnInvoiceGeneration(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateBatchPricingOnInvoiceGeneration, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getProductsQuantityReports(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getProductsQuantityReports, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createRawMaterialRequestForm(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$createRawMaterialRequestForm, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getRawMaterialFormByBuId(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getRawMaterialFormByBuId, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> acceptRawMaterialRequest(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$acceptRawMaterialRequest, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> rejectRawMaterialRequest(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$rejectRawMaterialRequest, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getRawMaterialIssues(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getRawMaterialIssues, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findRawMaterialByIssueId(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findRawMaterialByIssueId, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getRawMaterialIssuesReports(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getRawMaterialIssuesReports, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createRawMaterialTemplate(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$createRawMaterialTemplate, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getRawMaterialTemplate(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getRawMaterialTemplate, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateRawMaterialTemplate(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateRawMaterialTemplate, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findRawMaterialTemplateId(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findRawMaterialTemplateId, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getRawmaterialQuantityReports(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getRawmaterialQuantityReports, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getRawmaterialIssuesByProductId(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getRawmaterialIssuesByProductId, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> moveToRawmaterial(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$moveToRawmaterial, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> productQuantityAdjustment(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$productQuantityAdjustment, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getQuantityAdjustments(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getQuantityAdjustments, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> addSellerProducts(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$addSellerProducts, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getMyDistributers(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getMyDistributers, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createWithStr(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$createWithStr, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateWithStr(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateWithStr, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getRootProducts(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getRootProducts, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> addNewProducts(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$addNewProducts, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findProductList_v3(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findProductList_v3, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getProductsListAndFlow(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getProductsListAndFlow, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findBUsProductList(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findBUsProductList, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getRawmaterialIOReports(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getRawmaterialIOReports, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> deleteProduct(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$deleteProduct, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getStockDetails(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getStockDetails, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getProductsList_v5(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getProductsList_v5, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getAllProductsCollections(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getAllProductsCollections, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createQuickProduct(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$createQuickProduct, request, options: options);
  }

  // method descriptors

  static final _$getAll = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/ProductService/getAll',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      $0.GrpcMessage.fromBuffer);
  static final _$findProductList =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/findProductList',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findList = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/ProductService/findList',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      $0.GrpcMessage.fromBuffer);
  static final _$getById = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/ProductService/getById',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      $0.GrpcMessage.fromBuffer);
  static final _$addProductsInConnectionsBu =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/addProductsInConnectionsBu',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateSuppliers =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/updateSuppliers',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateOffers =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/updateOffers',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateQuantity =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/updateQuantity',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$remove = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/ProductService/remove',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      $0.GrpcMessage.fromBuffer);
  static final _$create = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/ProductService/create',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      $0.GrpcMessage.fromBuffer);
  static final _$update = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/ProductService/update',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      $0.GrpcMessage.fromBuffer);
  static final _$getBuProductImage =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/getBuProductImage',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findProductList_v2 =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/findProductList_v2',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findProductList_v4 =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/findProductList_v4',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findProductsBuyReportsList =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/findProductsBuyReportsList',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findProductsSellReportsList =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/findProductsSellReportsList',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$createIssue =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/createIssue',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateIssue =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/updateIssue',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findIssueById =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/findIssueById',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getIssuesByBuId =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/getIssuesByBuId',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getIssuesReportsByBuId =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/getIssuesReportsByBuId',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findIssueByBuidAndId =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/findIssueByBuidAndId',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getProductLogReports =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/getProductLogReports',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateBatchPricingOnInvoiceGeneration =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/updateBatchPricingOnInvoiceGeneration',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getProductsQuantityReports =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/getProductsQuantityReports',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$createRawMaterialRequestForm =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/createRawMaterialRequestForm',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getRawMaterialFormByBuId =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/getRawMaterialFormByBuId',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$acceptRawMaterialRequest =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/acceptRawMaterialRequest',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$rejectRawMaterialRequest =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/rejectRawMaterialRequest',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getRawMaterialIssues =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/getRawMaterialIssues',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findRawMaterialByIssueId =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/findRawMaterialByIssueId',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getRawMaterialIssuesReports =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/getRawMaterialIssuesReports',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$createRawMaterialTemplate =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/createRawMaterialTemplate',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getRawMaterialTemplate =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/getRawMaterialTemplate',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateRawMaterialTemplate =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/updateRawMaterialTemplate',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findRawMaterialTemplateId =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/findRawMaterialTemplateId',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getRawmaterialQuantityReports =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/getRawmaterialQuantityReports',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getRawmaterialIssuesByProductId =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/getRawmaterialIssuesByProductId',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$moveToRawmaterial =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/moveToRawmaterial',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$productQuantityAdjustment =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/productQuantityAdjustment',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getQuantityAdjustments =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/getQuantityAdjustments',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$addSellerProducts =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/addSellerProducts',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getMyDistributers =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/getMyDistributers',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$createWithStr =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/createWithStr',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateWithStr =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/updateWithStr',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getRootProducts =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/getRootProducts',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$addNewProducts =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/addNewProducts',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findProductList_v3 =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/findProductList_v3',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getProductsListAndFlow =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/getProductsListAndFlow',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findBUsProductList =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/findBUsProductList',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getRawmaterialIOReports =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/getRawmaterialIOReports',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$deleteProduct =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/deleteProduct',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getStockDetails =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/getStockDetails',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getProductsList_v5 =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/getProductsList_v5',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getAllProductsCollections =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/getAllProductsCollections',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$createQuickProduct =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ProductService/createQuickProduct',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
}

@$pb.GrpcServiceName('ProductService')
abstract class ProductServiceBase extends $grpc.Service {
  $core.String get $name => 'ProductService';

  ProductServiceBase() {
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getAll',
        getAll_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findProductList',
        findProductList_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findList',
        findList_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getById',
        getById_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'addProductsInConnectionsBu',
        addProductsInConnectionsBu_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateSuppliers',
        updateSuppliers_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateOffers',
        updateOffers_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateQuantity',
        updateQuantity_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'remove',
        remove_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'create',
        create_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'update',
        update_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getBuProductImage',
        getBuProductImage_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findProductList_v2',
        findProductList_v2_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findProductList_v4',
        findProductList_v4_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findProductsBuyReportsList',
        findProductsBuyReportsList_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findProductsSellReportsList',
        findProductsSellReportsList_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createIssue',
        createIssue_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateIssue',
        updateIssue_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findIssueById',
        findIssueById_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getIssuesByBuId',
        getIssuesByBuId_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getIssuesReportsByBuId',
        getIssuesReportsByBuId_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findIssueByBuidAndId',
        findIssueByBuidAndId_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getProductLogReports',
        getProductLogReports_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateBatchPricingOnInvoiceGeneration',
        updateBatchPricingOnInvoiceGeneration_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getProductsQuantityReports',
        getProductsQuantityReports_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createRawMaterialRequestForm',
        createRawMaterialRequestForm_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getRawMaterialFormByBuId',
        getRawMaterialFormByBuId_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'acceptRawMaterialRequest',
        acceptRawMaterialRequest_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'rejectRawMaterialRequest',
        rejectRawMaterialRequest_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getRawMaterialIssues',
        getRawMaterialIssues_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findRawMaterialByIssueId',
        findRawMaterialByIssueId_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getRawMaterialIssuesReports',
        getRawMaterialIssuesReports_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createRawMaterialTemplate',
        createRawMaterialTemplate_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getRawMaterialTemplate',
        getRawMaterialTemplate_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateRawMaterialTemplate',
        updateRawMaterialTemplate_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findRawMaterialTemplateId',
        findRawMaterialTemplateId_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getRawmaterialQuantityReports',
        getRawmaterialQuantityReports_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getRawmaterialIssuesByProductId',
        getRawmaterialIssuesByProductId_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'moveToRawmaterial',
        moveToRawmaterial_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'productQuantityAdjustment',
        productQuantityAdjustment_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getQuantityAdjustments',
        getQuantityAdjustments_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'addSellerProducts',
        addSellerProducts_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getMyDistributers',
        getMyDistributers_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createWithStr',
        createWithStr_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateWithStr',
        updateWithStr_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getRootProducts',
        getRootProducts_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'addNewProducts',
        addNewProducts_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findProductList_v3',
        findProductList_v3_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getProductsListAndFlow',
        getProductsListAndFlow_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findBUsProductList',
        findBUsProductList_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getRawmaterialIOReports',
        getRawmaterialIOReports_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'deleteProduct',
        deleteProduct_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getStockDetails',
        getStockDetails_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getProductsList_v5',
        getProductsList_v5_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getAllProductsCollections',
        getAllProductsCollections_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createQuickProduct',
        createQuickProduct_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
  }

  $async.Future<$0.GrpcMessage> getAll_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getAll($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getAll(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findProductList_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findProductList($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findProductList(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findList_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findList($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findList(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getById_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getById($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getById(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> addProductsInConnectionsBu_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return addProductsInConnectionsBu($call, await $request);
  }

  $async.Future<$0.GrpcMessage> addProductsInConnectionsBu(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateSuppliers_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateSuppliers($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateSuppliers(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateOffers_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateOffers($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateOffers(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateQuantity_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateQuantity($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateQuantity(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> remove_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return remove($call, await $request);
  }

  $async.Future<$0.GrpcMessage> remove(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> create_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return create($call, await $request);
  }

  $async.Future<$0.GrpcMessage> create(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> update_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return update($call, await $request);
  }

  $async.Future<$0.GrpcMessage> update(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getBuProductImage_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getBuProductImage($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getBuProductImage(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findProductList_v2_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findProductList_v2($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findProductList_v2(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findProductList_v4_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findProductList_v4($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findProductList_v4(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findProductsBuyReportsList_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findProductsBuyReportsList($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findProductsBuyReportsList(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findProductsSellReportsList_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findProductsSellReportsList($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findProductsSellReportsList(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> createIssue_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return createIssue($call, await $request);
  }

  $async.Future<$0.GrpcMessage> createIssue(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateIssue_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateIssue($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateIssue(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findIssueById_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findIssueById($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findIssueById(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getIssuesByBuId_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getIssuesByBuId($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getIssuesByBuId(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getIssuesReportsByBuId_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getIssuesReportsByBuId($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getIssuesReportsByBuId(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findIssueByBuidAndId_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findIssueByBuidAndId($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findIssueByBuidAndId(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getProductLogReports_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getProductLogReports($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getProductLogReports(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateBatchPricingOnInvoiceGeneration_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateBatchPricingOnInvoiceGeneration($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateBatchPricingOnInvoiceGeneration(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getProductsQuantityReports_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getProductsQuantityReports($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getProductsQuantityReports(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> createRawMaterialRequestForm_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return createRawMaterialRequestForm($call, await $request);
  }

  $async.Future<$0.GrpcMessage> createRawMaterialRequestForm(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getRawMaterialFormByBuId_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getRawMaterialFormByBuId($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getRawMaterialFormByBuId(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> acceptRawMaterialRequest_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return acceptRawMaterialRequest($call, await $request);
  }

  $async.Future<$0.GrpcMessage> acceptRawMaterialRequest(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> rejectRawMaterialRequest_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return rejectRawMaterialRequest($call, await $request);
  }

  $async.Future<$0.GrpcMessage> rejectRawMaterialRequest(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getRawMaterialIssues_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getRawMaterialIssues($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getRawMaterialIssues(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findRawMaterialByIssueId_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findRawMaterialByIssueId($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findRawMaterialByIssueId(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getRawMaterialIssuesReports_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getRawMaterialIssuesReports($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getRawMaterialIssuesReports(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> createRawMaterialTemplate_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return createRawMaterialTemplate($call, await $request);
  }

  $async.Future<$0.GrpcMessage> createRawMaterialTemplate(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getRawMaterialTemplate_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getRawMaterialTemplate($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getRawMaterialTemplate(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateRawMaterialTemplate_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateRawMaterialTemplate($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateRawMaterialTemplate(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findRawMaterialTemplateId_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findRawMaterialTemplateId($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findRawMaterialTemplateId(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getRawmaterialQuantityReports_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getRawmaterialQuantityReports($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getRawmaterialQuantityReports(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getRawmaterialIssuesByProductId_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getRawmaterialIssuesByProductId($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getRawmaterialIssuesByProductId(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> moveToRawmaterial_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return moveToRawmaterial($call, await $request);
  }

  $async.Future<$0.GrpcMessage> moveToRawmaterial(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> productQuantityAdjustment_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return productQuantityAdjustment($call, await $request);
  }

  $async.Future<$0.GrpcMessage> productQuantityAdjustment(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getQuantityAdjustments_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getQuantityAdjustments($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getQuantityAdjustments(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> addSellerProducts_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return addSellerProducts($call, await $request);
  }

  $async.Future<$0.GrpcMessage> addSellerProducts(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getMyDistributers_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getMyDistributers($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getMyDistributers(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> createWithStr_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return createWithStr($call, await $request);
  }

  $async.Future<$0.GrpcMessage> createWithStr(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateWithStr_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateWithStr($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateWithStr(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getRootProducts_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getRootProducts($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getRootProducts(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> addNewProducts_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return addNewProducts($call, await $request);
  }

  $async.Future<$0.GrpcMessage> addNewProducts(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findProductList_v3_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findProductList_v3($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findProductList_v3(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getProductsListAndFlow_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getProductsListAndFlow($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getProductsListAndFlow(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findBUsProductList_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findBUsProductList($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findBUsProductList(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getRawmaterialIOReports_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getRawmaterialIOReports($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getRawmaterialIOReports(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> deleteProduct_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return deleteProduct($call, await $request);
  }

  $async.Future<$0.GrpcMessage> deleteProduct(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getStockDetails_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getStockDetails($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getStockDetails(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getProductsList_v5_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getProductsList_v5($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getProductsList_v5(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getAllProductsCollections_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getAllProductsCollections($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getAllProductsCollections(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> createQuickProduct_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return createQuickProduct($call, await $request);
  }

  $async.Future<$0.GrpcMessage> createQuickProduct(
      $grpc.ServiceCall call, $0.GrpcMessage request);
}
