///
//  Generated code. Do not modify.
//  source: proto/Invitation.messages.proto
//
// @dart = 2.12
// ignore_for_file: annotate_overrides,camel_case_types,unnecessary_const,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name,return_of_invalid_type,unnecessary_this,prefer_final_fields,deprecated_member_use_from_same_package

import 'dart:core' as $core;
import 'dart:convert' as $convert;
import 'dart:typed_data' as $typed_data;
@$core.Deprecated('Use grpcMessageDescriptor instead')
const GrpcMessage$json = const {
  '1': 'GrpcMessage',
  '2': const [
    const {'1': 'data', '3': 1, '4': 1, '5': 9, '10': 'data'},
    const {'1': 'Authorization', '3': 2, '4': 1, '5': 9, '10': 'Authorization'},
  ],
};

/// Descriptor for `GrpcMessage`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List grpcMessageDescriptor = $convert.base64Decode('CgtHcnBjTWVzc2FnZRISCgRkYXRhGAEgASgJUgRkYXRhEiQKDUF1dGhvcml6YXRpb24YAiABKAlSDUF1dGhvcml6YXRpb24=');
