///
//  Generated code. Do not modify.
//  source: proto/product_consumption/product_consumption.messages.proto
//

// ignore_for_file: annotate_overrides,camel_case_types,unnecessary_const,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name,return_of_invalid_type,unnecessary_this,prefer_final_fields

import 'dart:async' as $async;

import 'dart:core' as $core;

import 'package:grpc/service_api.dart' as $grpc;
import 'product_consumption.messages.pb.dart' as $0;
export 'product_consumption.messages.pb.dart';

class ConsumableProductServiceClient extends $grpc.Client {
  static final _$getProductsByBuId =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ConsumableProductService/getProductsByBuId',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$findById = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/ConsumableProductService/findById',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$remove = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/ConsumableProductService/remove',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$createProduct =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ConsumableProductService/createProduct',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$update = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/ConsumableProductService/update',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$getProductsReportsByBuId =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ConsumableProductService/getProductsReportsByBuId',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));

  ConsumableProductServiceClient($grpc.ClientChannel channel,
      {$grpc.CallOptions? options})
      : super(channel, options: options);

  $grpc.ResponseFuture<$0.GrpcMessage> getProductsByBuId($0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    final call = $createCall(
        _$getProductsByBuId, $async.Stream.fromIterable([request]),
        options: options);
    return $grpc.ResponseFuture(call);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findById($0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    final call = $createCall(_$findById, $async.Stream.fromIterable([request]),
        options: options);
    return $grpc.ResponseFuture(call);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> remove($0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    final call = $createCall(_$remove, $async.Stream.fromIterable([request]),
        options: options);
    return $grpc.ResponseFuture(call);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createProduct($0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    final call = $createCall(
        _$createProduct, $async.Stream.fromIterable([request]),
        options: options);
    return $grpc.ResponseFuture(call);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> update($0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    final call = $createCall(_$update, $async.Stream.fromIterable([request]),
        options: options);
    return $grpc.ResponseFuture(call);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getProductsReportsByBuId(
      $0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    final call = $createCall(
        _$getProductsReportsByBuId, $async.Stream.fromIterable([request]),
        options: options);
    return $grpc.ResponseFuture(call);
  }
}

abstract class ConsumableProductServiceBase extends $grpc.Service {
  $core.String get $name => 'ConsumableProductService';

  ConsumableProductServiceBase() {
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getProductsByBuId',
        getProductsByBuId_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findById',
        findById_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'remove',
        remove_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createProduct',
        createProduct_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'update',
        update_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getProductsReportsByBuId',
        getProductsReportsByBuId_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
  }

  $async.Future<$0.GrpcMessage> getProductsByBuId_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return getProductsByBuId(call, await request);
  }

  $async.Future<$0.GrpcMessage> findById_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return findById(call, await request);
  }

  $async.Future<$0.GrpcMessage> remove_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return remove(call, await request);
  }

  $async.Future<$0.GrpcMessage> createProduct_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return createProduct(call, await request);
  }

  $async.Future<$0.GrpcMessage> update_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return update(call, await request);
  }

  $async.Future<$0.GrpcMessage> getProductsReportsByBuId_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return getProductsReportsByBuId(call, await request);
  }

  $async.Future<$0.GrpcMessage> getProductsByBuId(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> findById(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> remove(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> createProduct(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> update(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> getProductsReportsByBuId(
      $grpc.ServiceCall call, $0.GrpcMessage request);
}
