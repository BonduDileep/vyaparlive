// This is a generated file - do not edit.
//
// Generated from proto/bu_proto/BU.messages.proto.

// @dart = 3.3

// ignore_for_file: annotate_overrides, camel_case_types, comment_references
// ignore_for_file: constant_identifier_names
// ignore_for_file: curly_braces_in_flow_control_structures
// ignore_for_file: deprecated_member_use_from_same_package, library_prefixes
// ignore_for_file: non_constant_identifier_names, prefer_relative_imports

import 'dart:async' as $async;
import 'dart:core' as $core;

import 'package:grpc/service_api.dart' as $grpc;
import 'package:protobuf/protobuf.dart' as $pb;

import 'BU.messages.pb.dart' as $0;

export 'BU.messages.pb.dart';

@$pb.GrpcServiceName('OrganizationService')
class OrganizationServiceClient extends $grpc.Client {
  /// The hostname for this service.
  static const $core.String defaultHost = '';

  /// OAuth scopes needed for the client.
  static const $core.List<$core.String> oauthScopes = [
    '',
  ];

  OrganizationServiceClient(super.channel, {super.options, super.interceptors});

  $grpc.ResponseFuture<$0.GrpcMessage> getAll(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getAll, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getTotalBus(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getTotalBus, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findByUser(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findByUser, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findById(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findById, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getMyChildren(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getMyChildren, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createRole(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$createRole, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateRole(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateRole, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> remove(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$remove, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> deleteRole(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$deleteRole, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findLocationById(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findLocationById, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createSubscription(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$createSubscription, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateSubscription(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateSubscription, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> addUserSubscription(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$addUserSubscription, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> removeUserSubscription(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$removeUserSubscription, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getSubscriptionStatus(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getSubscriptionStatus, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createLocation(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$createLocation, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateLocation(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateLocation, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> addExpenses(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$addExpenses, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateExpense(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateExpense, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createBu(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$createBu, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> update(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$update, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> confirmSubscription(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$confirmSubscription, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updatePayment(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updatePayment, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findParentBu(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findParentBu, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findAllRootBu(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findAllRootBu, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> deleteExpense(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$deleteExpense, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> update_v2(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$update_v2, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getExpensesByBuId(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getExpensesByBuId, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> addInvoiceTemplate(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$addInvoiceTemplate, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findTerms(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findTerms, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getONDCEnabledBUs(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getONDCEnabledBUs, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createYrInvoice(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$createYrInvoice, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> pendingSubscriptions(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$pendingSubscriptions, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getPaymentsList(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getPaymentsList, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findBuByBuId(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findBuByBuId, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findOrgByUser_v2(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findOrgByUser_v2, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getOrgDetails(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getOrgDetails, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getOrgMenuSystem(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getOrgMenuSystem, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateOrgMenuSystem(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateOrgMenuSystem, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateOrgFeatures(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateOrgFeatures, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getFeaturePermissions(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getFeaturePermissions, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getOrgMenuSystemHierarchy(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getOrgMenuSystemHierarchy, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getOrgRoleById(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getOrgRoleById, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createdEmployee(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$createdEmployee, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getEmployees(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getEmployees, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> deleteEmployee(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$deleteEmployee, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateEmployee(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateEmployee, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> buBasedEmployeeActivity(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$buBasedEmployeeActivity, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> buBasedEmployeePayment(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$buBasedEmployeePayment, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getEmployeeAttendance(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getEmployeeAttendance, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getProfitLossReport(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getProfitLossReport, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getBuDetails(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getBuDetails, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createSubscriptionPayment(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$createSubscriptionPayment, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> subscriptionPaymentStatus(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$subscriptionPaymentStatus, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> subscriptionPaymentWebhook(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$subscriptionPaymentWebhook, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> fetchPayments(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$fetchPayments, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> fetchSubscriptionPlans(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$fetchSubscriptionPlans, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createSubscriptionPlan(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$createSubscriptionPlan, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateSubscriptionPlan(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateSubscriptionPlan, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> deleteSubscriptionPlan(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$deleteSubscriptionPlan, request,
        options: options);
  }

  // method descriptors

  static final _$getAll = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/OrganizationService/getAll',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      $0.GrpcMessage.fromBuffer);
  static final _$getTotalBus =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/getTotalBus',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findByUser =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/findByUser',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findById = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/OrganizationService/findById',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      $0.GrpcMessage.fromBuffer);
  static final _$getMyChildren =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/getMyChildren',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$createRole =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/createRole',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateRole =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/updateRole',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$remove = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/OrganizationService/remove',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      $0.GrpcMessage.fromBuffer);
  static final _$deleteRole =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/deleteRole',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findLocationById =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/findLocationById',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$createSubscription =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/createSubscription',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateSubscription =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/updateSubscription',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$addUserSubscription =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/addUserSubscription',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$removeUserSubscription =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/removeUserSubscription',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getSubscriptionStatus =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/getSubscriptionStatus',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$createLocation =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/createLocation',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateLocation =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/updateLocation',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$addExpenses =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/addExpenses',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateExpense =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/updateExpense',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$createBu = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/OrganizationService/createBu',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      $0.GrpcMessage.fromBuffer);
  static final _$update = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/OrganizationService/update',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      $0.GrpcMessage.fromBuffer);
  static final _$confirmSubscription =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/confirmSubscription',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updatePayment =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/updatePayment',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findParentBu =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/findParentBu',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findAllRootBu =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/findAllRootBu',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$deleteExpense =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/deleteExpense',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$update_v2 = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/OrganizationService/update_v2',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      $0.GrpcMessage.fromBuffer);
  static final _$getExpensesByBuId =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/getExpensesByBuId',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$addInvoiceTemplate =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/addInvoiceTemplate',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findTerms = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/OrganizationService/findTerms',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      $0.GrpcMessage.fromBuffer);
  static final _$getONDCEnabledBUs =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/getONDCEnabledBUs',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$createYrInvoice =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/createYrInvoice',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$pendingSubscriptions =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/pendingSubscriptions',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getPaymentsList =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/getPaymentsList',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findBuByBuId =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/findBuByBuId',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findOrgByUser_v2 =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/findOrgByUser_v2',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getOrgDetails =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/getOrgDetails',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getOrgMenuSystem =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/getOrgMenuSystem',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateOrgMenuSystem =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/updateOrgMenuSystem',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateOrgFeatures =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/updateOrgFeatures',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getFeaturePermissions =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/getFeaturePermissions',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getOrgMenuSystemHierarchy =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/getOrgMenuSystemHierarchy',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getOrgRoleById =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/getOrgRoleById',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$createdEmployee =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/createdEmployee',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getEmployees =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/getEmployees',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$deleteEmployee =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/deleteEmployee',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateEmployee =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/updateEmployee',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$buBasedEmployeeActivity =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/BuBasedEmployeeActivity',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$buBasedEmployeePayment =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/BuBasedEmployeePayment',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getEmployeeAttendance =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/getEmployeeAttendance',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getProfitLossReport =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/getProfitLossReport',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getBuDetails =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/getBuDetails',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$createSubscriptionPayment =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/createSubscriptionPayment',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$subscriptionPaymentStatus =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/subscriptionPaymentStatus',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$subscriptionPaymentWebhook =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/subscriptionPaymentWebhook',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$fetchPayments =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/fetchPayments',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$fetchSubscriptionPlans =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/fetchSubscriptionPlans',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$createSubscriptionPlan =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/createSubscriptionPlan',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateSubscriptionPlan =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/updateSubscriptionPlan',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$deleteSubscriptionPlan =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/OrganizationService/deleteSubscriptionPlan',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
}

@$pb.GrpcServiceName('OrganizationService')
abstract class OrganizationServiceBase extends $grpc.Service {
  $core.String get $name => 'OrganizationService';

  OrganizationServiceBase() {
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getAll',
        getAll_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getTotalBus',
        getTotalBus_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findByUser',
        findByUser_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findById',
        findById_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getMyChildren',
        getMyChildren_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createRole',
        createRole_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateRole',
        updateRole_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'remove',
        remove_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'deleteRole',
        deleteRole_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findLocationById',
        findLocationById_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createSubscription',
        createSubscription_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateSubscription',
        updateSubscription_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'addUserSubscription',
        addUserSubscription_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'removeUserSubscription',
        removeUserSubscription_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getSubscriptionStatus',
        getSubscriptionStatus_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createLocation',
        createLocation_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateLocation',
        updateLocation_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'addExpenses',
        addExpenses_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateExpense',
        updateExpense_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createBu',
        createBu_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'update',
        update_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'confirmSubscription',
        confirmSubscription_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updatePayment',
        updatePayment_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findParentBu',
        findParentBu_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findAllRootBu',
        findAllRootBu_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'deleteExpense',
        deleteExpense_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'update_v2',
        update_v2_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getExpensesByBuId',
        getExpensesByBuId_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'addInvoiceTemplate',
        addInvoiceTemplate_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findTerms',
        findTerms_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getONDCEnabledBUs',
        getONDCEnabledBUs_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createYrInvoice',
        createYrInvoice_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'pendingSubscriptions',
        pendingSubscriptions_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getPaymentsList',
        getPaymentsList_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findBuByBuId',
        findBuByBuId_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findOrgByUser_v2',
        findOrgByUser_v2_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getOrgDetails',
        getOrgDetails_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getOrgMenuSystem',
        getOrgMenuSystem_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateOrgMenuSystem',
        updateOrgMenuSystem_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateOrgFeatures',
        updateOrgFeatures_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getFeaturePermissions',
        getFeaturePermissions_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getOrgMenuSystemHierarchy',
        getOrgMenuSystemHierarchy_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getOrgRoleById',
        getOrgRoleById_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createdEmployee',
        createdEmployee_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getEmployees',
        getEmployees_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'deleteEmployee',
        deleteEmployee_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateEmployee',
        updateEmployee_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'BuBasedEmployeeActivity',
        buBasedEmployeeActivity_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'BuBasedEmployeePayment',
        buBasedEmployeePayment_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getEmployeeAttendance',
        getEmployeeAttendance_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getProfitLossReport',
        getProfitLossReport_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getBuDetails',
        getBuDetails_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createSubscriptionPayment',
        createSubscriptionPayment_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'subscriptionPaymentStatus',
        subscriptionPaymentStatus_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'subscriptionPaymentWebhook',
        subscriptionPaymentWebhook_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'fetchPayments',
        fetchPayments_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'fetchSubscriptionPlans',
        fetchSubscriptionPlans_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createSubscriptionPlan',
        createSubscriptionPlan_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateSubscriptionPlan',
        updateSubscriptionPlan_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'deleteSubscriptionPlan',
        deleteSubscriptionPlan_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
  }

  $async.Future<$0.GrpcMessage> getAll_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getAll($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getAll(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getTotalBus_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getTotalBus($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getTotalBus(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findByUser_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findByUser($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findByUser(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findById_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findById($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findById(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getMyChildren_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getMyChildren($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getMyChildren(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> createRole_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return createRole($call, await $request);
  }

  $async.Future<$0.GrpcMessage> createRole(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateRole_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateRole($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateRole(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> remove_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return remove($call, await $request);
  }

  $async.Future<$0.GrpcMessage> remove(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> deleteRole_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return deleteRole($call, await $request);
  }

  $async.Future<$0.GrpcMessage> deleteRole(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findLocationById_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findLocationById($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findLocationById(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> createSubscription_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return createSubscription($call, await $request);
  }

  $async.Future<$0.GrpcMessage> createSubscription(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateSubscription_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateSubscription($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateSubscription(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> addUserSubscription_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return addUserSubscription($call, await $request);
  }

  $async.Future<$0.GrpcMessage> addUserSubscription(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> removeUserSubscription_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return removeUserSubscription($call, await $request);
  }

  $async.Future<$0.GrpcMessage> removeUserSubscription(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getSubscriptionStatus_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getSubscriptionStatus($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getSubscriptionStatus(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> createLocation_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return createLocation($call, await $request);
  }

  $async.Future<$0.GrpcMessage> createLocation(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateLocation_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateLocation($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateLocation(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> addExpenses_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return addExpenses($call, await $request);
  }

  $async.Future<$0.GrpcMessage> addExpenses(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateExpense_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateExpense($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateExpense(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> createBu_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return createBu($call, await $request);
  }

  $async.Future<$0.GrpcMessage> createBu(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> update_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return update($call, await $request);
  }

  $async.Future<$0.GrpcMessage> update(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> confirmSubscription_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return confirmSubscription($call, await $request);
  }

  $async.Future<$0.GrpcMessage> confirmSubscription(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updatePayment_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updatePayment($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updatePayment(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findParentBu_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findParentBu($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findParentBu(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findAllRootBu_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findAllRootBu($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findAllRootBu(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> deleteExpense_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return deleteExpense($call, await $request);
  }

  $async.Future<$0.GrpcMessage> deleteExpense(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> update_v2_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return update_v2($call, await $request);
  }

  $async.Future<$0.GrpcMessage> update_v2(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getExpensesByBuId_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getExpensesByBuId($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getExpensesByBuId(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> addInvoiceTemplate_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return addInvoiceTemplate($call, await $request);
  }

  $async.Future<$0.GrpcMessage> addInvoiceTemplate(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findTerms_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findTerms($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findTerms(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getONDCEnabledBUs_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getONDCEnabledBUs($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getONDCEnabledBUs(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> createYrInvoice_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return createYrInvoice($call, await $request);
  }

  $async.Future<$0.GrpcMessage> createYrInvoice(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> pendingSubscriptions_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return pendingSubscriptions($call, await $request);
  }

  $async.Future<$0.GrpcMessage> pendingSubscriptions(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getPaymentsList_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getPaymentsList($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getPaymentsList(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findBuByBuId_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findBuByBuId($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findBuByBuId(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findOrgByUser_v2_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findOrgByUser_v2($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findOrgByUser_v2(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getOrgDetails_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getOrgDetails($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getOrgDetails(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getOrgMenuSystem_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getOrgMenuSystem($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getOrgMenuSystem(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateOrgMenuSystem_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateOrgMenuSystem($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateOrgMenuSystem(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateOrgFeatures_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateOrgFeatures($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateOrgFeatures(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getFeaturePermissions_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getFeaturePermissions($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getFeaturePermissions(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getOrgMenuSystemHierarchy_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getOrgMenuSystemHierarchy($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getOrgMenuSystemHierarchy(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getOrgRoleById_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getOrgRoleById($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getOrgRoleById(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> createdEmployee_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return createdEmployee($call, await $request);
  }

  $async.Future<$0.GrpcMessage> createdEmployee(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getEmployees_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getEmployees($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getEmployees(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> deleteEmployee_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return deleteEmployee($call, await $request);
  }

  $async.Future<$0.GrpcMessage> deleteEmployee(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateEmployee_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateEmployee($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateEmployee(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> buBasedEmployeeActivity_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return buBasedEmployeeActivity($call, await $request);
  }

  $async.Future<$0.GrpcMessage> buBasedEmployeeActivity(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> buBasedEmployeePayment_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return buBasedEmployeePayment($call, await $request);
  }

  $async.Future<$0.GrpcMessage> buBasedEmployeePayment(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getEmployeeAttendance_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getEmployeeAttendance($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getEmployeeAttendance(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getProfitLossReport_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getProfitLossReport($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getProfitLossReport(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getBuDetails_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getBuDetails($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getBuDetails(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> createSubscriptionPayment_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return createSubscriptionPayment($call, await $request);
  }

  $async.Future<$0.GrpcMessage> createSubscriptionPayment(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> subscriptionPaymentStatus_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return subscriptionPaymentStatus($call, await $request);
  }

  $async.Future<$0.GrpcMessage> subscriptionPaymentStatus(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> subscriptionPaymentWebhook_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return subscriptionPaymentWebhook($call, await $request);
  }

  $async.Future<$0.GrpcMessage> subscriptionPaymentWebhook(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> fetchPayments_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return fetchPayments($call, await $request);
  }

  $async.Future<$0.GrpcMessage> fetchPayments(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> fetchSubscriptionPlans_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return fetchSubscriptionPlans($call, await $request);
  }

  $async.Future<$0.GrpcMessage> fetchSubscriptionPlans(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> createSubscriptionPlan_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return createSubscriptionPlan($call, await $request);
  }

  $async.Future<$0.GrpcMessage> createSubscriptionPlan(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateSubscriptionPlan_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateSubscriptionPlan($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateSubscriptionPlan(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> deleteSubscriptionPlan_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return deleteSubscriptionPlan($call, await $request);
  }

  $async.Future<$0.GrpcMessage> deleteSubscriptionPlan(
      $grpc.ServiceCall call, $0.GrpcMessage request);
}
