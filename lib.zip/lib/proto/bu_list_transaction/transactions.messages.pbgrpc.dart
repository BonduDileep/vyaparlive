// This is a generated file - do not edit.
//
// Generated from proto/bu_list_transaction/transactions.messages.proto.

// @dart = 3.3

// ignore_for_file: annotate_overrides, camel_case_types, comment_references
// ignore_for_file: constant_identifier_names
// ignore_for_file: curly_braces_in_flow_control_structures
// ignore_for_file: deprecated_member_use_from_same_package, library_prefixes
// ignore_for_file: non_constant_identifier_names, prefer_relative_imports

import 'dart:async' as $async;
import 'dart:core' as $core;

import 'package:grpc/service_api.dart' as $grpc;
import 'package:protobuf/protobuf.dart' as $pb;

import 'transactions.messages.pb.dart' as $0;

export 'transactions.messages.pb.dart';

@$pb.GrpcServiceName('TransactionService')
class TransactionServiceClient extends $grpc.Client {
  /// The hostname for this service.
  static const $core.String defaultHost = '';

  /// OAuth scopes needed for the client.
  static const $core.List<$core.String> oauthScopes = [
    '',
  ];

  TransactionServiceClient(super.channel, {super.options, super.interceptors});

  $grpc.ResponseFuture<$0.GrpcMessage> getAll(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getAll, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getById(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getById, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getById_v2(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getById_v2, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> update(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$update, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> create(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$create, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> connectionTransaction(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$connectionTransaction, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createMessage(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$createMessage, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createConfirmationMessage(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$createConfirmationMessage, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> resolveReconciliation(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$resolveReconciliation, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findOrdersById(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findOrdersById, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findInvoiceByNo(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findInvoiceByNo, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> editInvoiceByBillNo(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$editInvoiceByBillNo, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> assignPackingToUser(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$assignPackingToUser, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> packingByInvoiceNo(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$packingByInvoiceNo, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> deliveryByInvoiceNo(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$deliveryByInvoiceNo, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateStockReceiveByInvoiceNo(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateStockReceiveByInvoiceNo, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> stockReconciliationByInvoiceNo(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$stockReconciliationByInvoiceNo, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> paymentReconciliationByInvoiceNo(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$paymentReconciliationByInvoiceNo, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> resolveInvoiceReconciliation(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$resolveInvoiceReconciliation, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> indirectDelivery(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$indirectDelivery, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> deliveryReturnReconciliation(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$deliveryReturnReconciliation, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findByTransactionBuId(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findByTransactionBuId, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findTransactions_v2(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findTransactions_v2, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findTransactionsByProductId(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findTransactionsByProductId, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateOrder(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateOrder, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> editOrdersById(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$editOrdersById, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateOrderStatus(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateOrderStatus, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateAcceptedStatus(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateAcceptedStatus, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateCtrStatus(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateCtrStatus, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateInvoice(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateInvoice, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> makeInvoicePayment(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$makeInvoicePayment, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createOrderTrack(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$createOrderTrack, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> remove(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$remove, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findSellerProductReports(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findSellerProductReports, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findBuyerProductReports(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findBuyerProductReports, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findInvoice(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findInvoice, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findPendingOrders(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findPendingOrders, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findInvoicesByTxnId(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findInvoicesByTxnId, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findSellerSalesReports(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findSellerSalesReports, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findBuyerSalesReports(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findBuyerSalesReports, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findSellerGSTReports(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findSellerGSTReports, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findBuyerGSTReports(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findBuyerGSTReports, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findBuStockDelivery(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findBuStockDelivery, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findBuyerPendingDeliveryInvoices(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findBuyerPendingDeliveryInvoices, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findSellerPendingDeliveryInvoices(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findSellerPendingDeliveryInvoices, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findBuyerPendingPackingInvoices(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findBuyerPendingPackingInvoices, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findSellerPendingPackingInvoices(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findSellerPendingPackingInvoices, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findBuyerPaymentRemainderInvoices(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findBuyerPaymentRemainderInvoices, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findSellerPaymentRemainderInvoices(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findSellerPaymentRemainderInvoices, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findDeliveryMissedInvoices(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findDeliveryMissedInvoices, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findProductPendingOrders(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findProductPendingOrders, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createMenuOrder(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$createMenuOrder, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findAllMenuOrders(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findAllMenuOrders, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateMenuOrder(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateMenuOrder, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> removeMenuOrder(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$removeMenuOrder, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findMenuOrderById(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findMenuOrderById, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findOrderByBuId(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findOrderByBuId, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findMenuOrderByBuId(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findMenuOrderByBuId, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateMenuOrderStatus(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateMenuOrderStatus, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> generateBUInvoice(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$generateBUInvoice, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findBuInvoicesByBuList(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findBuInvoicesByBuList, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> directTransaction(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$directTransaction, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateBalanceAmount(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateBalanceAmount, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createDistributorOrder(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$createDistributorOrder, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getReports(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getReports, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getMySales(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getMySales, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> offlineInvoice(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$offlineInvoice, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findBuyerPendingDeliveryInvoices_v2(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findBuyerPendingDeliveryInvoices_v2, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findSellerPendingDeliveryInvoices_v2(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findSellerPendingDeliveryInvoices_v2, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findBuyerPendingPackingInvoices_v2(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findBuyerPendingPackingInvoices_v2, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findSellerPendingPackingInvoices_v2(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findSellerPendingPackingInvoices_v2, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findSellerSalesReports_v2(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findSellerSalesReports_v2, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findBuyerSalesReports_v2(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findBuyerSalesReports_v2, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> deliveryByInvoiceNo_v2(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$deliveryByInvoiceNo_v2, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> finInvoiceById(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$finInvoiceById, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getReports_v2(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getReports_v2, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> ctrTrackingByInvoiceNo(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$ctrTrackingByInvoiceNo, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getReports_api(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getReports_api, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getMySales_api(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getMySales_api, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findSellerSalesReports_download(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findSellerSalesReports_download, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findBuyerSalesReports_download(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findBuyerSalesReports_download, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage>
      findSellerPendingDeliveryInvoices_download(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(
        _$findSellerPendingDeliveryInvoices_download, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findBuyerPendingPackingInvoices_download(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findBuyerPendingPackingInvoices_download, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage>
      findBuyerPendingDeliveryInvoices_download(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(
        _$findBuyerPendingDeliveryInvoices_download, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage>
      findSellerPendingPackingInvoices_download(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(
        _$findSellerPendingPackingInvoices_download, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findBuyerGSTReports_download(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findBuyerGSTReports_download, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findSellerGSTReports_download(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findSellerGSTReports_download, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> regenerateInvoiceForProduct(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$regenerateInvoiceForProduct, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findBuyTransactionsByProductId(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findBuyTransactionsByProductId, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findSellTransactionsByProductId(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findSellTransactionsByProductId, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findTransactionPendingProducts(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findTransactionPendingProducts, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findCTRInvoiceById(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findCTRInvoiceById, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findBuCancelledInvoices(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findBuCancelledInvoices, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findStockResolvedDiscrepencies(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findStockResolvedDiscrepencies, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findPaymentResolvedDiscrepencies(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findPaymentResolvedDiscrepencies, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getFastMovingProductReports(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getFastMovingProductReports, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getSlowMovingProductReports(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getSlowMovingProductReports, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getStockDeliveryDelays(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getStockDeliveryDelays, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getPaymentDeliveryDelays(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getPaymentDeliveryDelays, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> stockNotResolved(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$stockNotResolved, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> paymentNotResolved(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$paymentNotResolved, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getFieldSalesReport(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getFieldSalesReport, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getFieldSalesReportByProduct(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getFieldSalesReportByProduct, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getProductTransit(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getProductTransit, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getInvoiceAndGroupedProducts(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getInvoiceAndGroupedProducts, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> adjustProductAndRegenerateInvoice(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$adjustProductAndRegenerateInvoice, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updatePaymentReceived(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updatePaymentReceived, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createGoodsReturn(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$createGoodsReturn, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateGoodsReturnMsg(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateGoodsReturnMsg, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getGoodsReturnByID(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getGoodsReturnByID, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getGoodsReturnsList_Buyer(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getGoodsReturnsList_Buyer, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getGoodsReturnsList_Seller(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getGoodsReturnsList_Seller, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getReturningProducts(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getReturningProducts, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getReturningProductInvoices(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getReturningProductInvoices, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createGoodsReturnDocument(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$createGoodsReturnDocument, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getGoodsReturnDocuments(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getGoodsReturnDocuments, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getGoodsReturnsList_By_GR(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getGoodsReturnsList_By_GR, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getGoodsReturnDocumentByID(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getGoodsReturnDocumentByID, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateGRDPacking(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateGRDPacking, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateGRDDirectDelivery(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateGRDDirectDelivery, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createGRDraftNote(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$createGRDraftNote, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getGRDraftNote(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getGRDraftNote, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> addStockReconciliationMsg(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$addStockReconciliationMsg, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createFinalCreditNote(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$createFinalCreditNote, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getFinalCreditNotes(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getFinalCreditNotes, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getFinalCreditNotes_By_Seller(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getFinalCreditNotes_By_Seller, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getFinalCreditNoteByID(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getFinalCreditNoteByID, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getFinalCreditNotes_Buyer(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getFinalCreditNotes_Buyer, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateGRDStockRecieved(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateGRDStockRecieved, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateGRDStockReconciliationStatus(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateGRDStockReconciliationStatus, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateDraftnoteAcceptance(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateDraftnoteAcceptance, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getFinalCreditNoteByGR(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getFinalCreditNoteByGR, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getCRNReports_Buyer(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getCRNReports_Buyer, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getInvoicesByTxnId(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getInvoicesByTxnId, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> shareBuListPO(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$shareBuListPO, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getProductSoldQuantities(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getProductSoldQuantities, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> sendOfflineCustomerOTP(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$sendOfflineCustomerOTP, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> sendRemainderMessage(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$sendRemainderMessage, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createONDCTransaction(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$createONDCTransaction, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateProductsONDCTransaction(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateProductsONDCTransaction, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getOndcTransactionStatus(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getOndcTransactionStatus, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createOrderFormTransaction(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$createOrderFormTransaction, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createBUOrderFormTransaction(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$createBUOrderFormTransaction, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateInvoiceLogisticsConfirmation(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateInvoiceLogisticsConfirmation, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> deleteLogisticsInformation(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$deleteLogisticsInformation, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findInvoiceLogistics(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findInvoiceLogistics, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getInvoiceLogistics(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getInvoiceLogistics, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateInvoiceLSP(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateInvoiceLSP, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> cancelOndcOrder(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$cancelOndcOrder, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateOndcReturnReq(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateOndcReturnReq, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateInvoiceFields(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateInvoiceFields, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> totalTransactions(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$totalTransactions, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createQuotation(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$createQuotation, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getQuotations(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getQuotations, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> sentQuotations(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$sentQuotations, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> sentQuotations_v1(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$sentQuotations_v1, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> receivedQuotations(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$receivedQuotations, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> receivedQuotations_v1(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$receivedQuotations_v1, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> sendQuotationMsg(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$sendQuotationMsg, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> acceptQuotation(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$acceptQuotation, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> ignoreQuotation(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$ignoreQuotation, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createChallan(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$createChallan, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getChallans(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getChallans, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> sendBuyerPOAcceptedRemainder(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$sendBuyerPOAcceptedRemainder, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createBUOrderForm(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$createBUOrderForm, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getBuBasedOrders(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getBuBasedOrders, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getOrdersById(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getOrdersById, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateOrderForm(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateOrderForm, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getOrdersByContact(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getOrdersByContact, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> transaction_list_V3(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$transaction_list_V3, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getAllInvoices(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getAllInvoices, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> uploadSellerInvoice(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$uploadSellerInvoice, request, options: options);
  }

  // method descriptors

  static final _$getAll = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/TransactionService/getAll',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      $0.GrpcMessage.fromBuffer);
  static final _$getById = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/TransactionService/getById',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      $0.GrpcMessage.fromBuffer);
  static final _$getById_v2 =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getById_v2',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$update = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/TransactionService/update',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      $0.GrpcMessage.fromBuffer);
  static final _$create = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/TransactionService/create',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      $0.GrpcMessage.fromBuffer);
  static final _$connectionTransaction =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/connectionTransaction',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$createMessage =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/createMessage',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$createConfirmationMessage =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/createConfirmationMessage',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$resolveReconciliation =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/resolveReconciliation',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findOrdersById =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findOrdersById',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findInvoiceByNo =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findInvoiceByNo',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$editInvoiceByBillNo =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/editInvoiceByBillNo',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$assignPackingToUser =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/assignPackingToUser',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$packingByInvoiceNo =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/packingByInvoiceNo',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$deliveryByInvoiceNo =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/deliveryByInvoiceNo',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateStockReceiveByInvoiceNo =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/updateStockReceiveByInvoiceNo',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$stockReconciliationByInvoiceNo =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/stockReconciliationByInvoiceNo',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$paymentReconciliationByInvoiceNo =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/paymentReconciliationByInvoiceNo',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$resolveInvoiceReconciliation =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/resolveInvoiceReconciliation',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$indirectDelivery =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/indirectDelivery',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$deliveryReturnReconciliation =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/deliveryReturnReconciliation',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findByTransactionBuId =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findByTransactionBuId',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findTransactions_v2 =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findTransactions_v2',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findTransactionsByProductId =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findTransactionsByProductId',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateOrder =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/updateOrder',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$editOrdersById =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/editOrdersById',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateOrderStatus =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/updateOrderStatus',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateAcceptedStatus =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/updateAcceptedStatus',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateCtrStatus =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/updateCtrStatus',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateInvoice =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/updateInvoice',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$makeInvoicePayment =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/makeInvoicePayment',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$createOrderTrack =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/createOrderTrack',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$remove = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/TransactionService/remove',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      $0.GrpcMessage.fromBuffer);
  static final _$findSellerProductReports =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findSellerProductReports',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findBuyerProductReports =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findBuyerProductReports',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findInvoice =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findInvoice',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findPendingOrders =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findPendingOrders',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findInvoicesByTxnId =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findInvoicesByTxnId',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findSellerSalesReports =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findSellerSalesReports',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findBuyerSalesReports =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findBuyerSalesReports',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findSellerGSTReports =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findSellerGSTReports',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findBuyerGSTReports =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findBuyerGSTReports',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findBuStockDelivery =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findBuStockDelivery',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findBuyerPendingDeliveryInvoices =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findBuyerPendingDeliveryInvoices',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findSellerPendingDeliveryInvoices =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findSellerPendingDeliveryInvoices',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findBuyerPendingPackingInvoices =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findBuyerPendingPackingInvoices',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findSellerPendingPackingInvoices =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findSellerPendingPackingInvoices',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findBuyerPaymentRemainderInvoices =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findBuyerPaymentRemainderInvoices',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findSellerPaymentRemainderInvoices =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findSellerPaymentRemainderInvoices',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findDeliveryMissedInvoices =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findDeliveryMissedInvoices',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findProductPendingOrders =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findProductPendingOrders',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$createMenuOrder =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/createMenuOrder',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findAllMenuOrders =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findAllMenuOrders',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateMenuOrder =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/updateMenuOrder',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$removeMenuOrder =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/removeMenuOrder',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findMenuOrderById =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findMenuOrderById',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findOrderByBuId =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findOrderByBuId',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findMenuOrderByBuId =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findMenuOrderByBuId',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateMenuOrderStatus =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/updateMenuOrderStatus',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$generateBUInvoice =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/generateBUInvoice',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findBuInvoicesByBuList =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findBuInvoicesByBuList',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$directTransaction =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/directTransaction',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateBalanceAmount =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/updateBalanceAmount',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$createDistributorOrder =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/createDistributorOrder',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getReports =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getReports',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getMySales =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getMySales',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$offlineInvoice =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/offlineInvoice',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findBuyerPendingDeliveryInvoices_v2 =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findBuyerPendingDeliveryInvoices_v2',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findSellerPendingDeliveryInvoices_v2 =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findSellerPendingDeliveryInvoices_v2',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findBuyerPendingPackingInvoices_v2 =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findBuyerPendingPackingInvoices_v2',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findSellerPendingPackingInvoices_v2 =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findSellerPendingPackingInvoices_v2',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findSellerSalesReports_v2 =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findSellerSalesReports_v2',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findBuyerSalesReports_v2 =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findBuyerSalesReports_v2',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$deliveryByInvoiceNo_v2 =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/deliveryByInvoiceNo_v2',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$finInvoiceById =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/finInvoiceById',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getReports_v2 =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getReports_v2',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$ctrTrackingByInvoiceNo =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/ctrTrackingByInvoiceNo',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getReports_api =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getReports_api',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getMySales_api =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getMySales_api',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findSellerSalesReports_download =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findSellerSalesReports_download',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findBuyerSalesReports_download =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findBuyerSalesReports_download',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findSellerPendingDeliveryInvoices_download =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findSellerPendingDeliveryInvoices_download',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findBuyerPendingPackingInvoices_download =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findBuyerPendingPackingInvoices_download',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findBuyerPendingDeliveryInvoices_download =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findBuyerPendingDeliveryInvoices_download',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findSellerPendingPackingInvoices_download =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findSellerPendingPackingInvoices_download',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findBuyerGSTReports_download =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findBuyerGSTReports_download',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findSellerGSTReports_download =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findSellerGSTReports_download',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$regenerateInvoiceForProduct =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/regenerateInvoiceForProduct',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findBuyTransactionsByProductId =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findBuyTransactionsByProductId',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findSellTransactionsByProductId =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findSellTransactionsByProductId',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findTransactionPendingProducts =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findTransactionPendingProducts',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findCTRInvoiceById =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findCTRInvoiceById',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findBuCancelledInvoices =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findBuCancelledInvoices',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findStockResolvedDiscrepencies =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findStockResolvedDiscrepencies',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findPaymentResolvedDiscrepencies =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findPaymentResolvedDiscrepencies',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getFastMovingProductReports =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getFastMovingProductReports',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getSlowMovingProductReports =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getSlowMovingProductReports',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getStockDeliveryDelays =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getStockDeliveryDelays',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getPaymentDeliveryDelays =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getPaymentDeliveryDelays',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$stockNotResolved =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/stockNotResolved',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$paymentNotResolved =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/paymentNotResolved',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getFieldSalesReport =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getFieldSalesReport',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getFieldSalesReportByProduct =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getFieldSalesReportByProduct',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getProductTransit =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getProductTransit',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getInvoiceAndGroupedProducts =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getInvoiceAndGroupedProducts',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$adjustProductAndRegenerateInvoice =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/adjustProductAndRegenerateInvoice',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updatePaymentReceived =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/updatePaymentReceived',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$createGoodsReturn =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/createGoodsReturn',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateGoodsReturnMsg =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/updateGoodsReturnMsg',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getGoodsReturnByID =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getGoodsReturnByID',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getGoodsReturnsList_Buyer =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getGoodsReturnsList_Buyer',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getGoodsReturnsList_Seller =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getGoodsReturnsList_Seller',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getReturningProducts =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getReturningProducts',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getReturningProductInvoices =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getReturningProductInvoices',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$createGoodsReturnDocument =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/createGoodsReturnDocument',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getGoodsReturnDocuments =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getGoodsReturnDocuments',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getGoodsReturnsList_By_GR =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getGoodsReturnsList_By_GR',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getGoodsReturnDocumentByID =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getGoodsReturnDocumentByID',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateGRDPacking =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/updateGRDPacking',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateGRDDirectDelivery =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/updateGRDDirectDelivery',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$createGRDraftNote =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/createGRDraftNote',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getGRDraftNote =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getGRDraftNote',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$addStockReconciliationMsg =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/addStockReconciliationMsg',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$createFinalCreditNote =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/createFinalCreditNote',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getFinalCreditNotes =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getFinalCreditNotes',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getFinalCreditNotes_By_Seller =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getFinalCreditNotes_By_Seller',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getFinalCreditNoteByID =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getFinalCreditNoteByID',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getFinalCreditNotes_Buyer =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getFinalCreditNotes_Buyer',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateGRDStockRecieved =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/updateGRDStockRecieved',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateGRDStockReconciliationStatus =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/updateGRDStockReconciliationStatus',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateDraftnoteAcceptance =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/updateDraftnoteAcceptance',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getFinalCreditNoteByGR =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getFinalCreditNoteByGR',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getCRNReports_Buyer =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getCRNReports_Buyer',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getInvoicesByTxnId =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getInvoicesByTxnId',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$shareBuListPO =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/shareBuListPO',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getProductSoldQuantities =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getProductSoldQuantities',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$sendOfflineCustomerOTP =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/sendOfflineCustomerOTP',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$sendRemainderMessage =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/sendRemainderMessage',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$createONDCTransaction =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/createONDCTransaction',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateProductsONDCTransaction =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/updateProductsONDCTransaction',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getOndcTransactionStatus =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getOndcTransactionStatus',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$createOrderFormTransaction =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/createOrderFormTransaction',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$createBUOrderFormTransaction =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/createBUOrderFormTransaction',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateInvoiceLogisticsConfirmation =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/updateInvoiceLogisticsConfirmation',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$deleteLogisticsInformation =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/deleteLogisticsInformation',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findInvoiceLogistics =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/findInvoiceLogistics',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getInvoiceLogistics =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getInvoiceLogistics',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateInvoiceLSP =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/updateInvoiceLSP',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$cancelOndcOrder =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/cancelOndcOrder',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateOndcReturnReq =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/updateOndcReturnReq',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateInvoiceFields =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/updateInvoiceFields',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$totalTransactions =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/totalTransactions',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$createQuotation =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/createQuotation',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getQuotations =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getQuotations',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$sentQuotations =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/sentQuotations',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$sentQuotations_v1 =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/sentQuotations_v1',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$receivedQuotations =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/receivedQuotations',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$receivedQuotations_v1 =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/receivedQuotations_v1',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$sendQuotationMsg =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/sendQuotationMsg',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$acceptQuotation =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/acceptQuotation',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$ignoreQuotation =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/ignoreQuotation',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$createChallan =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/createChallan',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getChallans =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getChallans',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$sendBuyerPOAcceptedRemainder =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/sendBuyerPOAcceptedRemainder',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$createBUOrderForm =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/createBUOrderForm',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getBuBasedOrders =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getBuBasedOrders',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getOrdersById =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getOrdersById',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateOrderForm =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/updateOrderForm',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getOrdersByContact =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getOrdersByContact',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$transaction_list_V3 =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/transaction_list_V3',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getAllInvoices =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/getAllInvoices',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$uploadSellerInvoice =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/TransactionService/uploadSellerInvoice',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
}

@$pb.GrpcServiceName('TransactionService')
abstract class TransactionServiceBase extends $grpc.Service {
  $core.String get $name => 'TransactionService';

  TransactionServiceBase() {
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getAll',
        getAll_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getById',
        getById_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getById_v2',
        getById_v2_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'update',
        update_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'create',
        create_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'connectionTransaction',
        connectionTransaction_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createMessage',
        createMessage_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createConfirmationMessage',
        createConfirmationMessage_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'resolveReconciliation',
        resolveReconciliation_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findOrdersById',
        findOrdersById_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findInvoiceByNo',
        findInvoiceByNo_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'editInvoiceByBillNo',
        editInvoiceByBillNo_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'assignPackingToUser',
        assignPackingToUser_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'packingByInvoiceNo',
        packingByInvoiceNo_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'deliveryByInvoiceNo',
        deliveryByInvoiceNo_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateStockReceiveByInvoiceNo',
        updateStockReceiveByInvoiceNo_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'stockReconciliationByInvoiceNo',
        stockReconciliationByInvoiceNo_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'paymentReconciliationByInvoiceNo',
        paymentReconciliationByInvoiceNo_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'resolveInvoiceReconciliation',
        resolveInvoiceReconciliation_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'indirectDelivery',
        indirectDelivery_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'deliveryReturnReconciliation',
        deliveryReturnReconciliation_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findByTransactionBuId',
        findByTransactionBuId_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findTransactions_v2',
        findTransactions_v2_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findTransactionsByProductId',
        findTransactionsByProductId_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateOrder',
        updateOrder_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'editOrdersById',
        editOrdersById_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateOrderStatus',
        updateOrderStatus_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateAcceptedStatus',
        updateAcceptedStatus_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateCtrStatus',
        updateCtrStatus_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateInvoice',
        updateInvoice_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'makeInvoicePayment',
        makeInvoicePayment_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createOrderTrack',
        createOrderTrack_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'remove',
        remove_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findSellerProductReports',
        findSellerProductReports_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findBuyerProductReports',
        findBuyerProductReports_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findInvoice',
        findInvoice_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findPendingOrders',
        findPendingOrders_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findInvoicesByTxnId',
        findInvoicesByTxnId_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findSellerSalesReports',
        findSellerSalesReports_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findBuyerSalesReports',
        findBuyerSalesReports_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findSellerGSTReports',
        findSellerGSTReports_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findBuyerGSTReports',
        findBuyerGSTReports_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findBuStockDelivery',
        findBuStockDelivery_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findBuyerPendingDeliveryInvoices',
        findBuyerPendingDeliveryInvoices_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findSellerPendingDeliveryInvoices',
        findSellerPendingDeliveryInvoices_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findBuyerPendingPackingInvoices',
        findBuyerPendingPackingInvoices_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findSellerPendingPackingInvoices',
        findSellerPendingPackingInvoices_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findBuyerPaymentRemainderInvoices',
        findBuyerPaymentRemainderInvoices_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findSellerPaymentRemainderInvoices',
        findSellerPaymentRemainderInvoices_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findDeliveryMissedInvoices',
        findDeliveryMissedInvoices_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findProductPendingOrders',
        findProductPendingOrders_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createMenuOrder',
        createMenuOrder_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findAllMenuOrders',
        findAllMenuOrders_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateMenuOrder',
        updateMenuOrder_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'removeMenuOrder',
        removeMenuOrder_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findMenuOrderById',
        findMenuOrderById_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findOrderByBuId',
        findOrderByBuId_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findMenuOrderByBuId',
        findMenuOrderByBuId_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateMenuOrderStatus',
        updateMenuOrderStatus_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'generateBUInvoice',
        generateBUInvoice_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findBuInvoicesByBuList',
        findBuInvoicesByBuList_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'directTransaction',
        directTransaction_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateBalanceAmount',
        updateBalanceAmount_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createDistributorOrder',
        createDistributorOrder_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getReports',
        getReports_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getMySales',
        getMySales_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'offlineInvoice',
        offlineInvoice_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findBuyerPendingDeliveryInvoices_v2',
        findBuyerPendingDeliveryInvoices_v2_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findSellerPendingDeliveryInvoices_v2',
        findSellerPendingDeliveryInvoices_v2_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findBuyerPendingPackingInvoices_v2',
        findBuyerPendingPackingInvoices_v2_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findSellerPendingPackingInvoices_v2',
        findSellerPendingPackingInvoices_v2_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findSellerSalesReports_v2',
        findSellerSalesReports_v2_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findBuyerSalesReports_v2',
        findBuyerSalesReports_v2_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'deliveryByInvoiceNo_v2',
        deliveryByInvoiceNo_v2_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'finInvoiceById',
        finInvoiceById_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getReports_v2',
        getReports_v2_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'ctrTrackingByInvoiceNo',
        ctrTrackingByInvoiceNo_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getReports_api',
        getReports_api_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getMySales_api',
        getMySales_api_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findSellerSalesReports_download',
        findSellerSalesReports_download_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findBuyerSalesReports_download',
        findBuyerSalesReports_download_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findSellerPendingDeliveryInvoices_download',
        findSellerPendingDeliveryInvoices_download_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findBuyerPendingPackingInvoices_download',
        findBuyerPendingPackingInvoices_download_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findBuyerPendingDeliveryInvoices_download',
        findBuyerPendingDeliveryInvoices_download_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findSellerPendingPackingInvoices_download',
        findSellerPendingPackingInvoices_download_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findBuyerGSTReports_download',
        findBuyerGSTReports_download_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findSellerGSTReports_download',
        findSellerGSTReports_download_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'regenerateInvoiceForProduct',
        regenerateInvoiceForProduct_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findBuyTransactionsByProductId',
        findBuyTransactionsByProductId_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findSellTransactionsByProductId',
        findSellTransactionsByProductId_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findTransactionPendingProducts',
        findTransactionPendingProducts_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findCTRInvoiceById',
        findCTRInvoiceById_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findBuCancelledInvoices',
        findBuCancelledInvoices_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findStockResolvedDiscrepencies',
        findStockResolvedDiscrepencies_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findPaymentResolvedDiscrepencies',
        findPaymentResolvedDiscrepencies_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getFastMovingProductReports',
        getFastMovingProductReports_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getSlowMovingProductReports',
        getSlowMovingProductReports_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getStockDeliveryDelays',
        getStockDeliveryDelays_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getPaymentDeliveryDelays',
        getPaymentDeliveryDelays_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'stockNotResolved',
        stockNotResolved_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'paymentNotResolved',
        paymentNotResolved_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getFieldSalesReport',
        getFieldSalesReport_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getFieldSalesReportByProduct',
        getFieldSalesReportByProduct_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getProductTransit',
        getProductTransit_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getInvoiceAndGroupedProducts',
        getInvoiceAndGroupedProducts_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'adjustProductAndRegenerateInvoice',
        adjustProductAndRegenerateInvoice_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updatePaymentReceived',
        updatePaymentReceived_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createGoodsReturn',
        createGoodsReturn_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateGoodsReturnMsg',
        updateGoodsReturnMsg_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getGoodsReturnByID',
        getGoodsReturnByID_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getGoodsReturnsList_Buyer',
        getGoodsReturnsList_Buyer_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getGoodsReturnsList_Seller',
        getGoodsReturnsList_Seller_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getReturningProducts',
        getReturningProducts_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getReturningProductInvoices',
        getReturningProductInvoices_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createGoodsReturnDocument',
        createGoodsReturnDocument_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getGoodsReturnDocuments',
        getGoodsReturnDocuments_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getGoodsReturnsList_By_GR',
        getGoodsReturnsList_By_GR_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getGoodsReturnDocumentByID',
        getGoodsReturnDocumentByID_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateGRDPacking',
        updateGRDPacking_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateGRDDirectDelivery',
        updateGRDDirectDelivery_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createGRDraftNote',
        createGRDraftNote_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getGRDraftNote',
        getGRDraftNote_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'addStockReconciliationMsg',
        addStockReconciliationMsg_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createFinalCreditNote',
        createFinalCreditNote_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getFinalCreditNotes',
        getFinalCreditNotes_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getFinalCreditNotes_By_Seller',
        getFinalCreditNotes_By_Seller_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getFinalCreditNoteByID',
        getFinalCreditNoteByID_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getFinalCreditNotes_Buyer',
        getFinalCreditNotes_Buyer_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateGRDStockRecieved',
        updateGRDStockRecieved_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateGRDStockReconciliationStatus',
        updateGRDStockReconciliationStatus_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateDraftnoteAcceptance',
        updateDraftnoteAcceptance_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getFinalCreditNoteByGR',
        getFinalCreditNoteByGR_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getCRNReports_Buyer',
        getCRNReports_Buyer_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getInvoicesByTxnId',
        getInvoicesByTxnId_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'shareBuListPO',
        shareBuListPO_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getProductSoldQuantities',
        getProductSoldQuantities_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'sendOfflineCustomerOTP',
        sendOfflineCustomerOTP_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'sendRemainderMessage',
        sendRemainderMessage_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createONDCTransaction',
        createONDCTransaction_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateProductsONDCTransaction',
        updateProductsONDCTransaction_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getOndcTransactionStatus',
        getOndcTransactionStatus_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createOrderFormTransaction',
        createOrderFormTransaction_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createBUOrderFormTransaction',
        createBUOrderFormTransaction_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateInvoiceLogisticsConfirmation',
        updateInvoiceLogisticsConfirmation_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'deleteLogisticsInformation',
        deleteLogisticsInformation_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findInvoiceLogistics',
        findInvoiceLogistics_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getInvoiceLogistics',
        getInvoiceLogistics_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateInvoiceLSP',
        updateInvoiceLSP_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'cancelOndcOrder',
        cancelOndcOrder_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateOndcReturnReq',
        updateOndcReturnReq_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateInvoiceFields',
        updateInvoiceFields_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'totalTransactions',
        totalTransactions_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createQuotation',
        createQuotation_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getQuotations',
        getQuotations_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'sentQuotations',
        sentQuotations_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'sentQuotations_v1',
        sentQuotations_v1_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'receivedQuotations',
        receivedQuotations_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'receivedQuotations_v1',
        receivedQuotations_v1_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'sendQuotationMsg',
        sendQuotationMsg_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'acceptQuotation',
        acceptQuotation_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'ignoreQuotation',
        ignoreQuotation_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createChallan',
        createChallan_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getChallans',
        getChallans_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'sendBuyerPOAcceptedRemainder',
        sendBuyerPOAcceptedRemainder_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createBUOrderForm',
        createBUOrderForm_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getBuBasedOrders',
        getBuBasedOrders_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getOrdersById',
        getOrdersById_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateOrderForm',
        updateOrderForm_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getOrdersByContact',
        getOrdersByContact_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'transaction_list_V3',
        transaction_list_V3_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getAllInvoices',
        getAllInvoices_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'uploadSellerInvoice',
        uploadSellerInvoice_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
  }

  $async.Future<$0.GrpcMessage> getAll_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getAll($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getAll(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getById_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getById($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getById(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getById_v2_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getById_v2($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getById_v2(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> update_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return update($call, await $request);
  }

  $async.Future<$0.GrpcMessage> update(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> create_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return create($call, await $request);
  }

  $async.Future<$0.GrpcMessage> create(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> connectionTransaction_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return connectionTransaction($call, await $request);
  }

  $async.Future<$0.GrpcMessage> connectionTransaction(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> createMessage_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return createMessage($call, await $request);
  }

  $async.Future<$0.GrpcMessage> createMessage(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> createConfirmationMessage_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return createConfirmationMessage($call, await $request);
  }

  $async.Future<$0.GrpcMessage> createConfirmationMessage(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> resolveReconciliation_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return resolveReconciliation($call, await $request);
  }

  $async.Future<$0.GrpcMessage> resolveReconciliation(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findOrdersById_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findOrdersById($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findOrdersById(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findInvoiceByNo_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findInvoiceByNo($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findInvoiceByNo(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> editInvoiceByBillNo_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return editInvoiceByBillNo($call, await $request);
  }

  $async.Future<$0.GrpcMessage> editInvoiceByBillNo(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> assignPackingToUser_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return assignPackingToUser($call, await $request);
  }

  $async.Future<$0.GrpcMessage> assignPackingToUser(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> packingByInvoiceNo_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return packingByInvoiceNo($call, await $request);
  }

  $async.Future<$0.GrpcMessage> packingByInvoiceNo(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> deliveryByInvoiceNo_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return deliveryByInvoiceNo($call, await $request);
  }

  $async.Future<$0.GrpcMessage> deliveryByInvoiceNo(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateStockReceiveByInvoiceNo_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateStockReceiveByInvoiceNo($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateStockReceiveByInvoiceNo(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> stockReconciliationByInvoiceNo_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return stockReconciliationByInvoiceNo($call, await $request);
  }

  $async.Future<$0.GrpcMessage> stockReconciliationByInvoiceNo(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> paymentReconciliationByInvoiceNo_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return paymentReconciliationByInvoiceNo($call, await $request);
  }

  $async.Future<$0.GrpcMessage> paymentReconciliationByInvoiceNo(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> resolveInvoiceReconciliation_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return resolveInvoiceReconciliation($call, await $request);
  }

  $async.Future<$0.GrpcMessage> resolveInvoiceReconciliation(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> indirectDelivery_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return indirectDelivery($call, await $request);
  }

  $async.Future<$0.GrpcMessage> indirectDelivery(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> deliveryReturnReconciliation_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return deliveryReturnReconciliation($call, await $request);
  }

  $async.Future<$0.GrpcMessage> deliveryReturnReconciliation(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findByTransactionBuId_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findByTransactionBuId($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findByTransactionBuId(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findTransactions_v2_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findTransactions_v2($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findTransactions_v2(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findTransactionsByProductId_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findTransactionsByProductId($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findTransactionsByProductId(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateOrder_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateOrder($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateOrder(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> editOrdersById_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return editOrdersById($call, await $request);
  }

  $async.Future<$0.GrpcMessage> editOrdersById(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateOrderStatus_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateOrderStatus($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateOrderStatus(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateAcceptedStatus_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateAcceptedStatus($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateAcceptedStatus(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateCtrStatus_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateCtrStatus($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateCtrStatus(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateInvoice_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateInvoice($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateInvoice(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> makeInvoicePayment_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return makeInvoicePayment($call, await $request);
  }

  $async.Future<$0.GrpcMessage> makeInvoicePayment(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> createOrderTrack_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return createOrderTrack($call, await $request);
  }

  $async.Future<$0.GrpcMessage> createOrderTrack(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> remove_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return remove($call, await $request);
  }

  $async.Future<$0.GrpcMessage> remove(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findSellerProductReports_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findSellerProductReports($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findSellerProductReports(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findBuyerProductReports_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findBuyerProductReports($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findBuyerProductReports(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findInvoice_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findInvoice($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findInvoice(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findPendingOrders_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findPendingOrders($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findPendingOrders(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findInvoicesByTxnId_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findInvoicesByTxnId($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findInvoicesByTxnId(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findSellerSalesReports_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findSellerSalesReports($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findSellerSalesReports(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findBuyerSalesReports_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findBuyerSalesReports($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findBuyerSalesReports(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findSellerGSTReports_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findSellerGSTReports($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findSellerGSTReports(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findBuyerGSTReports_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findBuyerGSTReports($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findBuyerGSTReports(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findBuStockDelivery_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findBuStockDelivery($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findBuStockDelivery(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findBuyerPendingDeliveryInvoices_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findBuyerPendingDeliveryInvoices($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findBuyerPendingDeliveryInvoices(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findSellerPendingDeliveryInvoices_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findSellerPendingDeliveryInvoices($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findSellerPendingDeliveryInvoices(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findBuyerPendingPackingInvoices_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findBuyerPendingPackingInvoices($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findBuyerPendingPackingInvoices(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findSellerPendingPackingInvoices_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findSellerPendingPackingInvoices($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findSellerPendingPackingInvoices(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findBuyerPaymentRemainderInvoices_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findBuyerPaymentRemainderInvoices($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findBuyerPaymentRemainderInvoices(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findSellerPaymentRemainderInvoices_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findSellerPaymentRemainderInvoices($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findSellerPaymentRemainderInvoices(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findDeliveryMissedInvoices_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findDeliveryMissedInvoices($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findDeliveryMissedInvoices(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findProductPendingOrders_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findProductPendingOrders($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findProductPendingOrders(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> createMenuOrder_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return createMenuOrder($call, await $request);
  }

  $async.Future<$0.GrpcMessage> createMenuOrder(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findAllMenuOrders_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findAllMenuOrders($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findAllMenuOrders(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateMenuOrder_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateMenuOrder($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateMenuOrder(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> removeMenuOrder_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return removeMenuOrder($call, await $request);
  }

  $async.Future<$0.GrpcMessage> removeMenuOrder(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findMenuOrderById_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findMenuOrderById($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findMenuOrderById(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findOrderByBuId_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findOrderByBuId($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findOrderByBuId(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findMenuOrderByBuId_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findMenuOrderByBuId($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findMenuOrderByBuId(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateMenuOrderStatus_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateMenuOrderStatus($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateMenuOrderStatus(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> generateBUInvoice_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return generateBUInvoice($call, await $request);
  }

  $async.Future<$0.GrpcMessage> generateBUInvoice(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findBuInvoicesByBuList_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findBuInvoicesByBuList($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findBuInvoicesByBuList(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> directTransaction_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return directTransaction($call, await $request);
  }

  $async.Future<$0.GrpcMessage> directTransaction(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateBalanceAmount_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateBalanceAmount($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateBalanceAmount(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> createDistributorOrder_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return createDistributorOrder($call, await $request);
  }

  $async.Future<$0.GrpcMessage> createDistributorOrder(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getReports_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getReports($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getReports(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getMySales_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getMySales($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getMySales(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> offlineInvoice_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return offlineInvoice($call, await $request);
  }

  $async.Future<$0.GrpcMessage> offlineInvoice(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findBuyerPendingDeliveryInvoices_v2_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findBuyerPendingDeliveryInvoices_v2($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findBuyerPendingDeliveryInvoices_v2(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findSellerPendingDeliveryInvoices_v2_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findSellerPendingDeliveryInvoices_v2($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findSellerPendingDeliveryInvoices_v2(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findBuyerPendingPackingInvoices_v2_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findBuyerPendingPackingInvoices_v2($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findBuyerPendingPackingInvoices_v2(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findSellerPendingPackingInvoices_v2_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findSellerPendingPackingInvoices_v2($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findSellerPendingPackingInvoices_v2(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findSellerSalesReports_v2_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findSellerSalesReports_v2($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findSellerSalesReports_v2(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findBuyerSalesReports_v2_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findBuyerSalesReports_v2($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findBuyerSalesReports_v2(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> deliveryByInvoiceNo_v2_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return deliveryByInvoiceNo_v2($call, await $request);
  }

  $async.Future<$0.GrpcMessage> deliveryByInvoiceNo_v2(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> finInvoiceById_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return finInvoiceById($call, await $request);
  }

  $async.Future<$0.GrpcMessage> finInvoiceById(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getReports_v2_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getReports_v2($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getReports_v2(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> ctrTrackingByInvoiceNo_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return ctrTrackingByInvoiceNo($call, await $request);
  }

  $async.Future<$0.GrpcMessage> ctrTrackingByInvoiceNo(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getReports_api_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getReports_api($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getReports_api(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getMySales_api_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getMySales_api($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getMySales_api(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findSellerSalesReports_download_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findSellerSalesReports_download($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findSellerSalesReports_download(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findBuyerSalesReports_download_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findBuyerSalesReports_download($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findBuyerSalesReports_download(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findSellerPendingDeliveryInvoices_download_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findSellerPendingDeliveryInvoices_download($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findSellerPendingDeliveryInvoices_download(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findBuyerPendingPackingInvoices_download_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findBuyerPendingPackingInvoices_download($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findBuyerPendingPackingInvoices_download(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findBuyerPendingDeliveryInvoices_download_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findBuyerPendingDeliveryInvoices_download($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findBuyerPendingDeliveryInvoices_download(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findSellerPendingPackingInvoices_download_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findSellerPendingPackingInvoices_download($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findSellerPendingPackingInvoices_download(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findBuyerGSTReports_download_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findBuyerGSTReports_download($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findBuyerGSTReports_download(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findSellerGSTReports_download_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findSellerGSTReports_download($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findSellerGSTReports_download(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> regenerateInvoiceForProduct_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return regenerateInvoiceForProduct($call, await $request);
  }

  $async.Future<$0.GrpcMessage> regenerateInvoiceForProduct(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findBuyTransactionsByProductId_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findBuyTransactionsByProductId($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findBuyTransactionsByProductId(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findSellTransactionsByProductId_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findSellTransactionsByProductId($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findSellTransactionsByProductId(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findTransactionPendingProducts_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findTransactionPendingProducts($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findTransactionPendingProducts(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findCTRInvoiceById_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findCTRInvoiceById($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findCTRInvoiceById(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findBuCancelledInvoices_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findBuCancelledInvoices($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findBuCancelledInvoices(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findStockResolvedDiscrepencies_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findStockResolvedDiscrepencies($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findStockResolvedDiscrepencies(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findPaymentResolvedDiscrepencies_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findPaymentResolvedDiscrepencies($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findPaymentResolvedDiscrepencies(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getFastMovingProductReports_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getFastMovingProductReports($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getFastMovingProductReports(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getSlowMovingProductReports_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getSlowMovingProductReports($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getSlowMovingProductReports(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getStockDeliveryDelays_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getStockDeliveryDelays($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getStockDeliveryDelays(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getPaymentDeliveryDelays_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getPaymentDeliveryDelays($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getPaymentDeliveryDelays(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> stockNotResolved_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return stockNotResolved($call, await $request);
  }

  $async.Future<$0.GrpcMessage> stockNotResolved(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> paymentNotResolved_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return paymentNotResolved($call, await $request);
  }

  $async.Future<$0.GrpcMessage> paymentNotResolved(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getFieldSalesReport_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getFieldSalesReport($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getFieldSalesReport(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getFieldSalesReportByProduct_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getFieldSalesReportByProduct($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getFieldSalesReportByProduct(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getProductTransit_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getProductTransit($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getProductTransit(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getInvoiceAndGroupedProducts_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getInvoiceAndGroupedProducts($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getInvoiceAndGroupedProducts(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> adjustProductAndRegenerateInvoice_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return adjustProductAndRegenerateInvoice($call, await $request);
  }

  $async.Future<$0.GrpcMessage> adjustProductAndRegenerateInvoice(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updatePaymentReceived_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updatePaymentReceived($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updatePaymentReceived(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> createGoodsReturn_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return createGoodsReturn($call, await $request);
  }

  $async.Future<$0.GrpcMessage> createGoodsReturn(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateGoodsReturnMsg_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateGoodsReturnMsg($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateGoodsReturnMsg(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getGoodsReturnByID_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getGoodsReturnByID($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getGoodsReturnByID(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getGoodsReturnsList_Buyer_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getGoodsReturnsList_Buyer($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getGoodsReturnsList_Buyer(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getGoodsReturnsList_Seller_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getGoodsReturnsList_Seller($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getGoodsReturnsList_Seller(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getReturningProducts_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getReturningProducts($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getReturningProducts(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getReturningProductInvoices_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getReturningProductInvoices($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getReturningProductInvoices(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> createGoodsReturnDocument_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return createGoodsReturnDocument($call, await $request);
  }

  $async.Future<$0.GrpcMessage> createGoodsReturnDocument(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getGoodsReturnDocuments_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getGoodsReturnDocuments($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getGoodsReturnDocuments(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getGoodsReturnsList_By_GR_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getGoodsReturnsList_By_GR($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getGoodsReturnsList_By_GR(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getGoodsReturnDocumentByID_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getGoodsReturnDocumentByID($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getGoodsReturnDocumentByID(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateGRDPacking_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateGRDPacking($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateGRDPacking(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateGRDDirectDelivery_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateGRDDirectDelivery($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateGRDDirectDelivery(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> createGRDraftNote_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return createGRDraftNote($call, await $request);
  }

  $async.Future<$0.GrpcMessage> createGRDraftNote(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getGRDraftNote_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getGRDraftNote($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getGRDraftNote(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> addStockReconciliationMsg_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return addStockReconciliationMsg($call, await $request);
  }

  $async.Future<$0.GrpcMessage> addStockReconciliationMsg(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> createFinalCreditNote_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return createFinalCreditNote($call, await $request);
  }

  $async.Future<$0.GrpcMessage> createFinalCreditNote(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getFinalCreditNotes_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getFinalCreditNotes($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getFinalCreditNotes(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getFinalCreditNotes_By_Seller_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getFinalCreditNotes_By_Seller($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getFinalCreditNotes_By_Seller(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getFinalCreditNoteByID_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getFinalCreditNoteByID($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getFinalCreditNoteByID(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getFinalCreditNotes_Buyer_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getFinalCreditNotes_Buyer($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getFinalCreditNotes_Buyer(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateGRDStockRecieved_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateGRDStockRecieved($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateGRDStockRecieved(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateGRDStockReconciliationStatus_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateGRDStockReconciliationStatus($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateGRDStockReconciliationStatus(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateDraftnoteAcceptance_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateDraftnoteAcceptance($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateDraftnoteAcceptance(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getFinalCreditNoteByGR_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getFinalCreditNoteByGR($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getFinalCreditNoteByGR(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getCRNReports_Buyer_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getCRNReports_Buyer($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getCRNReports_Buyer(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getInvoicesByTxnId_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getInvoicesByTxnId($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getInvoicesByTxnId(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> shareBuListPO_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return shareBuListPO($call, await $request);
  }

  $async.Future<$0.GrpcMessage> shareBuListPO(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getProductSoldQuantities_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getProductSoldQuantities($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getProductSoldQuantities(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> sendOfflineCustomerOTP_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return sendOfflineCustomerOTP($call, await $request);
  }

  $async.Future<$0.GrpcMessage> sendOfflineCustomerOTP(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> sendRemainderMessage_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return sendRemainderMessage($call, await $request);
  }

  $async.Future<$0.GrpcMessage> sendRemainderMessage(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> createONDCTransaction_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return createONDCTransaction($call, await $request);
  }

  $async.Future<$0.GrpcMessage> createONDCTransaction(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateProductsONDCTransaction_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateProductsONDCTransaction($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateProductsONDCTransaction(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getOndcTransactionStatus_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getOndcTransactionStatus($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getOndcTransactionStatus(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> createOrderFormTransaction_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return createOrderFormTransaction($call, await $request);
  }

  $async.Future<$0.GrpcMessage> createOrderFormTransaction(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> createBUOrderFormTransaction_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return createBUOrderFormTransaction($call, await $request);
  }

  $async.Future<$0.GrpcMessage> createBUOrderFormTransaction(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateInvoiceLogisticsConfirmation_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateInvoiceLogisticsConfirmation($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateInvoiceLogisticsConfirmation(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> deleteLogisticsInformation_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return deleteLogisticsInformation($call, await $request);
  }

  $async.Future<$0.GrpcMessage> deleteLogisticsInformation(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findInvoiceLogistics_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findInvoiceLogistics($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findInvoiceLogistics(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getInvoiceLogistics_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getInvoiceLogistics($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getInvoiceLogistics(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateInvoiceLSP_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateInvoiceLSP($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateInvoiceLSP(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> cancelOndcOrder_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return cancelOndcOrder($call, await $request);
  }

  $async.Future<$0.GrpcMessage> cancelOndcOrder(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateOndcReturnReq_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateOndcReturnReq($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateOndcReturnReq(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateInvoiceFields_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateInvoiceFields($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateInvoiceFields(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> totalTransactions_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return totalTransactions($call, await $request);
  }

  $async.Future<$0.GrpcMessage> totalTransactions(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> createQuotation_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return createQuotation($call, await $request);
  }

  $async.Future<$0.GrpcMessage> createQuotation(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getQuotations_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getQuotations($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getQuotations(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> sentQuotations_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return sentQuotations($call, await $request);
  }

  $async.Future<$0.GrpcMessage> sentQuotations(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> sentQuotations_v1_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return sentQuotations_v1($call, await $request);
  }

  $async.Future<$0.GrpcMessage> sentQuotations_v1(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> receivedQuotations_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return receivedQuotations($call, await $request);
  }

  $async.Future<$0.GrpcMessage> receivedQuotations(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> receivedQuotations_v1_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return receivedQuotations_v1($call, await $request);
  }

  $async.Future<$0.GrpcMessage> receivedQuotations_v1(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> sendQuotationMsg_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return sendQuotationMsg($call, await $request);
  }

  $async.Future<$0.GrpcMessage> sendQuotationMsg(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> acceptQuotation_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return acceptQuotation($call, await $request);
  }

  $async.Future<$0.GrpcMessage> acceptQuotation(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> ignoreQuotation_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return ignoreQuotation($call, await $request);
  }

  $async.Future<$0.GrpcMessage> ignoreQuotation(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> createChallan_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return createChallan($call, await $request);
  }

  $async.Future<$0.GrpcMessage> createChallan(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getChallans_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getChallans($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getChallans(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> sendBuyerPOAcceptedRemainder_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return sendBuyerPOAcceptedRemainder($call, await $request);
  }

  $async.Future<$0.GrpcMessage> sendBuyerPOAcceptedRemainder(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> createBUOrderForm_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return createBUOrderForm($call, await $request);
  }

  $async.Future<$0.GrpcMessage> createBUOrderForm(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getBuBasedOrders_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getBuBasedOrders($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getBuBasedOrders(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getOrdersById_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getOrdersById($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getOrdersById(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateOrderForm_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateOrderForm($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateOrderForm(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getOrdersByContact_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getOrdersByContact($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getOrdersByContact(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> transaction_list_V3_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return transaction_list_V3($call, await $request);
  }

  $async.Future<$0.GrpcMessage> transaction_list_V3(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getAllInvoices_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getAllInvoices($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getAllInvoices(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> uploadSellerInvoice_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return uploadSellerInvoice($call, await $request);
  }

  $async.Future<$0.GrpcMessage> uploadSellerInvoice(
      $grpc.ServiceCall call, $0.GrpcMessage request);
}
