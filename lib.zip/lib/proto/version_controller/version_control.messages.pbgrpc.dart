///
//  Generated code. Do not modify.
//  source: proto/version_control/version_control.messages.proto
//

// ignore_for_file: annotate_overrides,camel_case_types,unnecessary_const,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name,return_of_invalid_type,unnecessary_this,prefer_final_fields

import 'dart:async' as $async;

import 'dart:core' as $core;

import 'package:grpc/service_api.dart' as $grpc;
import 'version_control.messages.pb.dart' as $0;
export 'version_control.messages.pb.dart';

class AppServiceClient extends $grpc.Client {
  static final _$checkVersion =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/AppService/checkVersion',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$getAll = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/AppService/getAll',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$findById = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/AppService/findById',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$remove = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/AppService/remove',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$create = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/AppService/create',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$update = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/AppService/update',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));

  AppServiceClient($grpc.ClientChannel channel, {$grpc.CallOptions? options})
      : super(channel, options: options);

  $grpc.ResponseFuture<$0.GrpcMessage> checkVersion($0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    final call = $createCall(
        _$checkVersion, $async.Stream.fromIterable([request]),
        options: options);
    return $grpc.ResponseFuture(call);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getAll($0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    final call = $createCall(_$getAll, $async.Stream.fromIterable([request]),
        options: options);
    return $grpc.ResponseFuture(call);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findById($0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    final call = $createCall(_$findById, $async.Stream.fromIterable([request]),
        options: options);
    return $grpc.ResponseFuture(call);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> remove($0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    final call = $createCall(_$remove, $async.Stream.fromIterable([request]),
        options: options);
    return $grpc.ResponseFuture(call);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> create($0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    final call = $createCall(_$create, $async.Stream.fromIterable([request]),
        options: options);
    return $grpc.ResponseFuture(call);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> update($0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    final call = $createCall(_$update, $async.Stream.fromIterable([request]),
        options: options);
    return $grpc.ResponseFuture(call);
  }
}

abstract class AppServiceBase extends $grpc.Service {
  $core.String get $name => 'AppService';

  AppServiceBase() {
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'checkVersion',
        checkVersion_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getAll',
        getAll_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findById',
        findById_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'remove',
        remove_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'create',
        create_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'update',
        update_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
  }

  $async.Future<$0.GrpcMessage> checkVersion_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return checkVersion(call, await request);
  }

  $async.Future<$0.GrpcMessage> getAll_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return getAll(call, await request);
  }

  $async.Future<$0.GrpcMessage> findById_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return findById(call, await request);
  }

  $async.Future<$0.GrpcMessage> remove_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return remove(call, await request);
  }

  $async.Future<$0.GrpcMessage> create_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return create(call, await request);
  }

  $async.Future<$0.GrpcMessage> update_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return update(call, await request);
  }

  $async.Future<$0.GrpcMessage> checkVersion(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> getAll(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> findById(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> remove(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> create(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> update(
      $grpc.ServiceCall call, $0.GrpcMessage request);
}
