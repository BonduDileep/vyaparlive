// This is a generated file - do not edit.
//
// Generated from proto/user/User.messages.proto.

// @dart = 3.3

// ignore_for_file: annotate_overrides, camel_case_types, comment_references
// ignore_for_file: constant_identifier_names
// ignore_for_file: curly_braces_in_flow_control_structures
// ignore_for_file: deprecated_member_use_from_same_package, library_prefixes
// ignore_for_file: non_constant_identifier_names

import 'dart:async' as $async;
import 'dart:core' as $core;

import 'package:grpc/service_api.dart' as $grpc;
import 'package:protobuf/protobuf.dart' as $pb;

import 'User.messages.pb.dart' as $0;

export 'User.messages.pb.dart';

@$pb.GrpcServiceName('UserService')
class UserServiceClient extends $grpc.Client {
  /// The hostname for this service.
  static const $core.String defaultHost = '';

  /// OAuth scopes needed for the client.
  static const $core.List<$core.String> oauthScopes = [
    '',
  ];

  UserServiceClient(super.channel, {super.options, super.interceptors});

  $grpc.ResponseFuture<$0.GrpcMessage> getAll(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getAll, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getById(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getById, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> update(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$update, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateStatus(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateStatus, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateBuStatus(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateBuStatus, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateBuRole(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateBuRole, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> delete(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$delete, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> login(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$login, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> adminLogin(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$adminLogin, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updatePassword(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updatePassword, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createOrgUser(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$createOrgUser, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findByBuId(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findByBuId, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateFirebaseToken(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$updateFirebaseToken, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> create(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$create, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> forgotPassword(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$forgotPassword, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getUserSharableInfo(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getUserSharableInfo, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getUsersBasicInfo(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getUsersBasicInfo, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> verifyJWT(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$verifyJWT, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> sendForgotPWDOTP(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$sendForgotPWDOTP, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> requestAccountDelete(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$requestAccountDelete, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> sendUserOTP(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$sendUserOTP, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> confirmUserDeleteWithOTP(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$confirmUserDeleteWithOTP, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getAllUsers(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getAllUsers, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> sendSupportMsg(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$sendSupportMsg, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getMessages(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getMessages, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getAdminMessages(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getAdminMessages, request, options: options);
  }

  // method descriptors

  static final _$getAll = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/UserService/getAll',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      $0.GrpcMessage.fromBuffer);
  static final _$getById = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/UserService/getById',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      $0.GrpcMessage.fromBuffer);
  static final _$update = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/UserService/update',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      $0.GrpcMessage.fromBuffer);
  static final _$updateStatus =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/UserService/updateStatus',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateBuStatus =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/UserService/updateBuStatus',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateBuRole =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/UserService/updateBuRole',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$delete = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/UserService/delete',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      $0.GrpcMessage.fromBuffer);
  static final _$login = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/UserService/login',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      $0.GrpcMessage.fromBuffer);
  static final _$adminLogin =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/UserService/adminLogin',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updatePassword =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/UserService/updatePassword',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$createOrgUser =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/UserService/createOrgUser',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$findByBuId =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/UserService/findByBuId',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$updateFirebaseToken =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/UserService/updateFirebaseToken',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$create = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/UserService/create',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      $0.GrpcMessage.fromBuffer);
  static final _$forgotPassword =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/UserService/forgotPassword',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getUserSharableInfo =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/UserService/getUserSharableInfo',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getUsersBasicInfo =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/UserService/getUsersBasicInfo',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$verifyJWT = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/UserService/verifyJWT',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      $0.GrpcMessage.fromBuffer);
  static final _$sendForgotPWDOTP =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/UserService/sendForgotPWDOTP',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$requestAccountDelete =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/UserService/requestAccountDelete',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$sendUserOTP =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/UserService/sendUserOTP',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$confirmUserDeleteWithOTP =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/UserService/confirmUserDeleteWithOTP',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getAllUsers =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/UserService/getAllUsers',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$sendSupportMsg =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/UserService/sendSupportMsg',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getMessages =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/UserService/getMessages',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getAdminMessages =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/UserService/getAdminMessages',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
}

@$pb.GrpcServiceName('UserService')
abstract class UserServiceBase extends $grpc.Service {
  $core.String get $name => 'UserService';

  UserServiceBase() {
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getAll',
        getAll_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getById',
        getById_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'update',
        update_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateStatus',
        updateStatus_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateBuStatus',
        updateBuStatus_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateBuRole',
        updateBuRole_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'delete',
        delete_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'login',
        login_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'adminLogin',
        adminLogin_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updatePassword',
        updatePassword_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createOrgUser',
        createOrgUser_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findByBuId',
        findByBuId_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateFirebaseToken',
        updateFirebaseToken_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'create',
        create_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'forgotPassword',
        forgotPassword_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getUserSharableInfo',
        getUserSharableInfo_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getUsersBasicInfo',
        getUsersBasicInfo_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'verifyJWT',
        verifyJWT_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'sendForgotPWDOTP',
        sendForgotPWDOTP_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'requestAccountDelete',
        requestAccountDelete_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'sendUserOTP',
        sendUserOTP_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'confirmUserDeleteWithOTP',
        confirmUserDeleteWithOTP_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getAllUsers',
        getAllUsers_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'sendSupportMsg',
        sendSupportMsg_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getMessages',
        getMessages_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getAdminMessages',
        getAdminMessages_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
  }

  $async.Future<$0.GrpcMessage> getAll_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getAll($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getAll(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getById_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getById($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getById(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> update_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return update($call, await $request);
  }

  $async.Future<$0.GrpcMessage> update(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateStatus_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateStatus($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateStatus(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateBuStatus_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateBuStatus($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateBuStatus(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateBuRole_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateBuRole($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateBuRole(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> delete_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return delete($call, await $request);
  }

  $async.Future<$0.GrpcMessage> delete(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> login_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return login($call, await $request);
  }

  $async.Future<$0.GrpcMessage> login(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> adminLogin_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return adminLogin($call, await $request);
  }

  $async.Future<$0.GrpcMessage> adminLogin(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updatePassword_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updatePassword($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updatePassword(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> createOrgUser_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return createOrgUser($call, await $request);
  }

  $async.Future<$0.GrpcMessage> createOrgUser(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findByBuId_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findByBuId($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findByBuId(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> updateFirebaseToken_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return updateFirebaseToken($call, await $request);
  }

  $async.Future<$0.GrpcMessage> updateFirebaseToken(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> create_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return create($call, await $request);
  }

  $async.Future<$0.GrpcMessage> create(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> forgotPassword_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return forgotPassword($call, await $request);
  }

  $async.Future<$0.GrpcMessage> forgotPassword(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getUserSharableInfo_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getUserSharableInfo($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getUserSharableInfo(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getUsersBasicInfo_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getUsersBasicInfo($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getUsersBasicInfo(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> verifyJWT_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return verifyJWT($call, await $request);
  }

  $async.Future<$0.GrpcMessage> verifyJWT(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> sendForgotPWDOTP_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return sendForgotPWDOTP($call, await $request);
  }

  $async.Future<$0.GrpcMessage> sendForgotPWDOTP(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> requestAccountDelete_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return requestAccountDelete($call, await $request);
  }

  $async.Future<$0.GrpcMessage> requestAccountDelete(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> sendUserOTP_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return sendUserOTP($call, await $request);
  }

  $async.Future<$0.GrpcMessage> sendUserOTP(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> confirmUserDeleteWithOTP_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return confirmUserDeleteWithOTP($call, await $request);
  }

  $async.Future<$0.GrpcMessage> confirmUserDeleteWithOTP(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getAllUsers_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getAllUsers($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getAllUsers(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> sendSupportMsg_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return sendSupportMsg($call, await $request);
  }

  $async.Future<$0.GrpcMessage> sendSupportMsg(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getMessages_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getMessages($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getMessages(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getAdminMessages_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getAdminMessages($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getAdminMessages(
      $grpc.ServiceCall call, $0.GrpcMessage request);
}
