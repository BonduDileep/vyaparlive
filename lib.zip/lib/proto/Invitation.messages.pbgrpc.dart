///
//  Generated code. Do not modify.
//  source: proto/Invitation.messages.proto
//
// @dart = 2.12
// ignore_for_file: annotate_overrides,camel_case_types,unnecessary_const,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name,return_of_invalid_type,unnecessary_this,prefer_final_fields

import 'dart:async' as $async;

import 'dart:core' as $core;

import 'package:grpc/service_api.dart' as $grpc;
import 'Invitation.messages.pb.dart' as $0;
export 'Invitation.messages.pb.dart';

class InvitationServiceClient extends $grpc.Client {
  static final _$getById = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/InvitationService/getById',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$getByContact =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/InvitationService/getByContact',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$getInviterInvitations =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/InvitationService/getInviterInvitations',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$getByCode = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/InvitationService/getByCode',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$getAll = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/InvitationService/getAll',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$acceptInvitation =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/InvitationService/acceptInvitation',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$rejectInvitation =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/InvitationService/rejectInvitation',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$acceptInvitationByCode =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/InvitationService/acceptInvitationByCode',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$findAllConnections =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/InvitationService/findAllConnections',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$findConnectionDetailsById =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/InvitationService/findConnectionDetailsById',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$rejectAcceptedConnection =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/InvitationService/rejectAcceptedConnection',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$updateTermsInConnection =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/InvitationService/updateTermsInConnection',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$acceptFirstBuConnection =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/InvitationService/acceptFirstBuConnection',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$createInvitation =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/InvitationService/createInvitation',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$deleteInvitation =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/InvitationService/deleteInvitation',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$createContact =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/InvitationService/createContact',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$findAllContactByBuId =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/InvitationService/findAllContactByBuId',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$updateContactById =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/InvitationService/updateContactById',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$deleteContactById =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/InvitationService/deleteContactById',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$getContactById =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/InvitationService/getContactById',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$updateUsersInConnection =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/InvitationService/updateUsersInConnection',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$findAllConnectionsByUsers =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/InvitationService/findAllConnectionsByUsers',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$updateUsersInContact =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/InvitationService/updateUsersInContact',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$findAllContactByUsers =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/InvitationService/findAllContactByUsers',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$setAsDistributer =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/InvitationService/setAsDistributer',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$getConnectionByID =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/InvitationService/getConnectionByID',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));
  static final _$getUserConnections =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/InvitationService/getUserConnections',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value));

  InvitationServiceClient($grpc.ClientChannel channel,
      {$grpc.CallOptions? options,
      $core.Iterable<$grpc.ClientInterceptor>? interceptors})
      : super(channel, options: options, interceptors: interceptors);

  $grpc.ResponseFuture<$0.GrpcMessage> getById($0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    return $createUnaryCall(_$getById, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getByContact($0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    return $createUnaryCall(_$getByContact, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getInviterInvitations(
      $0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    return $createUnaryCall(_$getInviterInvitations, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getByCode($0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    return $createUnaryCall(_$getByCode, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getAll($0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    return $createUnaryCall(_$getAll, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> acceptInvitation($0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    return $createUnaryCall(_$acceptInvitation, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> rejectInvitation($0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    return $createUnaryCall(_$rejectInvitation, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> acceptInvitationByCode(
      $0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    return $createUnaryCall(_$acceptInvitationByCode, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findAllConnections(
      $0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    return $createUnaryCall(_$findAllConnections, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findConnectionDetailsById(
      $0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    return $createUnaryCall(_$findConnectionDetailsById, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> rejectAcceptedConnection(
      $0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    return $createUnaryCall(_$rejectAcceptedConnection, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateTermsInConnection(
      $0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    return $createUnaryCall(_$updateTermsInConnection, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> acceptFirstBuConnection(
      $0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    return $createUnaryCall(_$acceptFirstBuConnection, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createInvitation($0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    return $createUnaryCall(_$createInvitation, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> deleteInvitation($0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    return $createUnaryCall(_$deleteInvitation, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> createContact($0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    return $createUnaryCall(_$createContact, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findAllContactByBuId(
      $0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    return $createUnaryCall(_$findAllContactByBuId, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateContactById($0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    return $createUnaryCall(_$updateContactById, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> deleteContactById($0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    return $createUnaryCall(_$deleteContactById, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getContactById($0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    return $createUnaryCall(_$getContactById, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateUsersInConnection(
      $0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    return $createUnaryCall(_$updateUsersInConnection, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findAllConnectionsByUsers(
      $0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    return $createUnaryCall(_$findAllConnectionsByUsers, request,
        options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> updateUsersInContact(
      $0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    return $createUnaryCall(_$updateUsersInContact, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findAllContactByUsers(
      $0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    return $createUnaryCall(_$findAllContactByUsers, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> setAsDistributer($0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    return $createUnaryCall(_$setAsDistributer, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getConnectionByID($0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    return $createUnaryCall(_$getConnectionByID, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getUserConnections(
      $0.GrpcMessage request,
      {$grpc.CallOptions? options}) {
    return $createUnaryCall(_$getUserConnections, request, options: options);
  }
}

abstract class InvitationServiceBase extends $grpc.Service {
  $core.String get $name => 'InvitationService';

  InvitationServiceBase() {
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getById',
        getById_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getByContact',
        getByContact_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getInviterInvitations',
        getInviterInvitations_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getByCode',
        getByCode_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getAll',
        getAll_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'acceptInvitation',
        acceptInvitation_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'rejectInvitation',
        rejectInvitation_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'acceptInvitationByCode',
        acceptInvitationByCode_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findAllConnections',
        findAllConnections_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findConnectionDetailsById',
        findConnectionDetailsById_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'rejectAcceptedConnection',
        rejectAcceptedConnection_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateTermsInConnection',
        updateTermsInConnection_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'acceptFirstBuConnection',
        acceptFirstBuConnection_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createInvitation',
        createInvitation_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'deleteInvitation',
        deleteInvitation_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'createContact',
        createContact_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findAllContactByBuId',
        findAllContactByBuId_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateContactById',
        updateContactById_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'deleteContactById',
        deleteContactById_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getContactById',
        getContactById_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateUsersInConnection',
        updateUsersInConnection_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findAllConnectionsByUsers',
        findAllConnectionsByUsers_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'updateUsersInContact',
        updateUsersInContact_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findAllContactByUsers',
        findAllContactByUsers_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'setAsDistributer',
        setAsDistributer_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getConnectionByID',
        getConnectionByID_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getUserConnections',
        getUserConnections_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
  }

  $async.Future<$0.GrpcMessage> getById_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return getById(call, await request);
  }

  $async.Future<$0.GrpcMessage> getByContact_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return getByContact(call, await request);
  }

  $async.Future<$0.GrpcMessage> getInviterInvitations_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return getInviterInvitations(call, await request);
  }

  $async.Future<$0.GrpcMessage> getByCode_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return getByCode(call, await request);
  }

  $async.Future<$0.GrpcMessage> getAll_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return getAll(call, await request);
  }

  $async.Future<$0.GrpcMessage> acceptInvitation_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return acceptInvitation(call, await request);
  }

  $async.Future<$0.GrpcMessage> rejectInvitation_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return rejectInvitation(call, await request);
  }

  $async.Future<$0.GrpcMessage> acceptInvitationByCode_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return acceptInvitationByCode(call, await request);
  }

  $async.Future<$0.GrpcMessage> findAllConnections_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return findAllConnections(call, await request);
  }

  $async.Future<$0.GrpcMessage> findConnectionDetailsById_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return findConnectionDetailsById(call, await request);
  }

  $async.Future<$0.GrpcMessage> rejectAcceptedConnection_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return rejectAcceptedConnection(call, await request);
  }

  $async.Future<$0.GrpcMessage> updateTermsInConnection_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return updateTermsInConnection(call, await request);
  }

  $async.Future<$0.GrpcMessage> acceptFirstBuConnection_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return acceptFirstBuConnection(call, await request);
  }

  $async.Future<$0.GrpcMessage> createInvitation_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return createInvitation(call, await request);
  }

  $async.Future<$0.GrpcMessage> deleteInvitation_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return deleteInvitation(call, await request);
  }

  $async.Future<$0.GrpcMessage> createContact_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return createContact(call, await request);
  }

  $async.Future<$0.GrpcMessage> findAllContactByBuId_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return findAllContactByBuId(call, await request);
  }

  $async.Future<$0.GrpcMessage> updateContactById_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return updateContactById(call, await request);
  }

  $async.Future<$0.GrpcMessage> deleteContactById_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return deleteContactById(call, await request);
  }

  $async.Future<$0.GrpcMessage> getContactById_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return getContactById(call, await request);
  }

  $async.Future<$0.GrpcMessage> updateUsersInConnection_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return updateUsersInConnection(call, await request);
  }

  $async.Future<$0.GrpcMessage> findAllConnectionsByUsers_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return findAllConnectionsByUsers(call, await request);
  }

  $async.Future<$0.GrpcMessage> updateUsersInContact_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return updateUsersInContact(call, await request);
  }

  $async.Future<$0.GrpcMessage> findAllContactByUsers_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return findAllContactByUsers(call, await request);
  }

  $async.Future<$0.GrpcMessage> setAsDistributer_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return setAsDistributer(call, await request);
  }

  $async.Future<$0.GrpcMessage> getConnectionByID_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return getConnectionByID(call, await request);
  }

  $async.Future<$0.GrpcMessage> getUserConnections_Pre(
      $grpc.ServiceCall call, $async.Future<$0.GrpcMessage> request) async {
    return getUserConnections(call, await request);
  }

  $async.Future<$0.GrpcMessage> getById(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> getByContact(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> getInviterInvitations(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> getByCode(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> getAll(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> acceptInvitation(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> rejectInvitation(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> acceptInvitationByCode(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> findAllConnections(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> findConnectionDetailsById(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> rejectAcceptedConnection(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> updateTermsInConnection(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> acceptFirstBuConnection(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> createInvitation(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> deleteInvitation(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> createContact(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> findAllContactByBuId(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> updateContactById(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> deleteContactById(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> getContactById(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> updateUsersInConnection(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> findAllConnectionsByUsers(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> updateUsersInContact(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> findAllContactByUsers(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> setAsDistributer(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> getConnectionByID(
      $grpc.ServiceCall call, $0.GrpcMessage request);
  $async.Future<$0.GrpcMessage> getUserConnections(
      $grpc.ServiceCall call, $0.GrpcMessage request);
}
