// This is a generated file - do not edit.
//
// Generated from proto/services/services.messages.proto.

// @dart = 3.3

// ignore_for_file: annotate_overrides, camel_case_types, comment_references
// ignore_for_file: constant_identifier_names
// ignore_for_file: curly_braces_in_flow_control_structures
// ignore_for_file: deprecated_member_use_from_same_package, library_prefixes
// ignore_for_file: non_constant_identifier_names, prefer_relative_imports

import 'dart:async' as $async;
import 'dart:core' as $core;

import 'package:grpc/service_api.dart' as $grpc;
import 'package:protobuf/protobuf.dart' as $pb;

import 'services.messages.pb.dart' as $0;

export 'services.messages.pb.dart';

@$pb.GrpcServiceName('ServicesService')
class ServicesServiceClient extends $grpc.Client {
  /// The hostname for this service.
  static const $core.String defaultHost = '';

  /// OAuth scopes needed for the client.
  static const $core.List<$core.String> oauthScopes = [
    '',
  ];

  ServicesServiceClient(super.channel, {super.options, super.interceptors});

  $grpc.ResponseFuture<$0.GrpcMessage> create(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$create, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getById(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getById, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> findServices(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$findServices, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> update(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$update, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> remove(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$remove, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> changeStatus(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$changeStatus, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getServiceCategories(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getServiceCategories, request, options: options);
  }

  $grpc.ResponseFuture<$0.GrpcMessage> getServiceSubCategories(
    $0.GrpcMessage request, {
    $grpc.CallOptions? options,
  }) {
    return $createUnaryCall(_$getServiceSubCategories, request,
        options: options);
  }

  // method descriptors

  static final _$create = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/ServicesService/create',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      $0.GrpcMessage.fromBuffer);
  static final _$getById = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/ServicesService/getById',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      $0.GrpcMessage.fromBuffer);
  static final _$findServices =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ServicesService/findServices',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$update = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/ServicesService/update',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      $0.GrpcMessage.fromBuffer);
  static final _$remove = $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
      '/ServicesService/remove',
      ($0.GrpcMessage value) => value.writeToBuffer(),
      $0.GrpcMessage.fromBuffer);
  static final _$changeStatus =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ServicesService/changeStatus',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getServiceCategories =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ServicesService/getServiceCategories',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
  static final _$getServiceSubCategories =
      $grpc.ClientMethod<$0.GrpcMessage, $0.GrpcMessage>(
          '/ServicesService/getServiceSubCategories',
          ($0.GrpcMessage value) => value.writeToBuffer(),
          $0.GrpcMessage.fromBuffer);
}

@$pb.GrpcServiceName('ServicesService')
abstract class ServicesServiceBase extends $grpc.Service {
  $core.String get $name => 'ServicesService';

  ServicesServiceBase() {
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'create',
        create_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getById',
        getById_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'findServices',
        findServices_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'update',
        update_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'remove',
        remove_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'changeStatus',
        changeStatus_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getServiceCategories',
        getServiceCategories_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
    $addMethod($grpc.ServiceMethod<$0.GrpcMessage, $0.GrpcMessage>(
        'getServiceSubCategories',
        getServiceSubCategories_Pre,
        false,
        false,
        ($core.List<$core.int> value) => $0.GrpcMessage.fromBuffer(value),
        ($0.GrpcMessage value) => value.writeToBuffer()));
  }

  $async.Future<$0.GrpcMessage> create_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return create($call, await $request);
  }

  $async.Future<$0.GrpcMessage> create(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getById_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getById($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getById(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> findServices_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return findServices($call, await $request);
  }

  $async.Future<$0.GrpcMessage> findServices(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> update_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return update($call, await $request);
  }

  $async.Future<$0.GrpcMessage> update(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> remove_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return remove($call, await $request);
  }

  $async.Future<$0.GrpcMessage> remove(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> changeStatus_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return changeStatus($call, await $request);
  }

  $async.Future<$0.GrpcMessage> changeStatus(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getServiceCategories_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getServiceCategories($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getServiceCategories(
      $grpc.ServiceCall call, $0.GrpcMessage request);

  $async.Future<$0.GrpcMessage> getServiceSubCategories_Pre(
      $grpc.ServiceCall $call, $async.Future<$0.GrpcMessage> $request) async {
    return getServiceSubCategories($call, await $request);
  }

  $async.Future<$0.GrpcMessage> getServiceSubCategories(
      $grpc.ServiceCall call, $0.GrpcMessage request);
}
